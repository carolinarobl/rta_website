import{parse as Vn}from"marked";const Br=!0,Ar=!1;/**
 * @license
 * @builder.io/qwik 1.2.19
 * Copyright Builder.io, Inc. All Rights Reserved.
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/BuilderIO/qwik/blob/main/LICENSE
 */const Qt=t=>t&&typeof t.nodeType=="number",Yn=t=>t.nodeType===9,Ft=t=>t.nodeType===1,Vt=t=>{const e=t.nodeType;return e===1||e===111},qr=t=>{const e=t.nodeType;return e===1||e===111||e===3},Lt=t=>t.nodeType===111,Ja=t=>t.nodeType===3,Oe=t=>t.nodeType===8,_e=(t,...e)=>Ka(!0,t,...e),Nr=(t,...e)=>{throw Ka(!1,t,...e)},Xa=(t,...e)=>Ka(!0,t,...e),Te=()=>{},zr=t=>t,Ka=(t,e,...a)=>{const l=e instanceof Error?e:new Error(e);return console.error("%cQWIK ERROR","",l.stack||l.message,...zr(a)),t&&setTimeout(()=>{throw l},0),l},lt=(t,...e)=>{const a=ha(t);return Xa(a,...e)},ha=t=>`Code(${t})`,Rr=()=>({isServer:Br,importSymbol(t,e,a){var i;{const c=lr(a),d=(i=globalThis.__qwik_reg_symbols)==null?void 0:i.get(c);if(d)return d}if(!e)throw lt(31,a);if(!t)throw lt(30,e,a);const l=Gr(t.ownerDocument,t,e).toString(),r=new URL(l);return r.hash="",r.search="",import(r.href).then(c=>c[a])},raf:t=>new Promise(e=>{requestAnimationFrame(()=>{e(t())})}),nextTick:t=>new Promise(e=>{setTimeout(()=>{e(t())})}),chunkForSymbol:(t,e)=>[t,e??"_"]}),Gr=(t,e,a)=>{const l=t.baseURI,r=new URL(e.getAttribute("q:base")??l,l);return new URL(a,r)};let tl=Rr();const jh=t=>tl=t,ba=()=>tl,It=()=>tl.isServer;const Be=t=>{const e=Object.getPrototypeOf(t);return e===Object.prototype||e===null},Mt=t=>t&&typeof t=="object",tt=t=>Array.isArray(t),Yt=t=>typeof t=="string",mt=t=>typeof t=="function",rt=t=>t&&typeof t.then=="function",va=(t,e,a)=>{try{const l=t();return rt(l)?l.then(e,a):e(l)}catch(l){return a(l)}},Y=(t,e)=>rt(t)?t.then(e):e(t),el=t=>t.some(rt)?Promise.all(t):t,Ke=t=>t.length>0?Promise.all(t):t,Zn=t=>t!=null,Qr=t=>new Promise(e=>{setTimeout(e,t)}),Dt=[],ct={},Ae=t=>typeof document<"u"?document:t.nodeType===9?t:t.ownerDocument,$t="q:slot",ya="q:style",qa=Symbol("proxy target"),te=Symbol("proxy flags"),Pt=Symbol("proxy manager"),s=Symbol("IMMUTABLE"),wa="_qc_",xt=(t,e,a)=>t.setAttribute(e,a),Tt=(t,e)=>t.getAttribute(e),al=t=>t.replace(/([A-Z])/g,"-$1").toLowerCase(),Fr=t=>t.replace(/-./g,e=>e[1].toUpperCase()),Hr=/^(on|window:|document:)/,Na="preventdefault:",ta=t=>t.endsWith("$")&&Hr.test(t),ll=t=>{if(t.length===0)return Dt;if(t.length===1){const a=t[0];return[[a[0],[a[1]]]]}const e=[];for(let a=0;a<t.length;a++){const l=t[a][0];e.includes(l)||e.push(l)}return e.map(a=>[a,t.filter(l=>l[0]===a).map(l=>l[1])])},ea=(t,e,a,l)=>{if(e.endsWith("$"),e=za(e.slice(0,-1)),a)if(tt(a)){const r=a.flat(1/0).filter(i=>i!=null).map(i=>[e,yn(i,l)]);t.push(...r)}else t.push([e,yn(a,l)]);return e},vn=["on","window:on","document:on"],Wr=["on","on-window","on-document"],za=t=>{let e="on";for(let a=0;a<vn.length;a++){const l=vn[a];if(t.startsWith(l)){e=Wr[a],t=t.slice(l.length);break}}return e+":"+(t=t.startsWith("-")?al(t.slice(1)):t.toLowerCase())},yn=(t,e)=>(t.$setContainer$(e),t),Ur=(t,e)=>{const a=t.$element$.attributes,l=[];for(let r=0;r<a.length;r++){const{name:i,value:c}=a.item(r);if(i.startsWith("on:")||i.startsWith("on-window:")||i.startsWith("on-document:")){const d=c.split(`
`);for(const p of d){const g=La(p,e);g.$capture$&&Ys(g,t),l.push([i,g])}}}return l},wn=Symbol("ContainerState"),ce=t=>{let e=t[wn];return e||(t[wn]=e=Jn(t,Tt(t,"q:base")??"/")),e},Jn=(t,e)=>{const a={$containerEl$:t,$elementIndex$:0,$styleMoved$:!1,$proxyMap$:new WeakMap,$opsNext$:new Set,$taskNext$:new Set,$taskStaging$:new Set,$hostsNext$:new Set,$hostsStaging$:new Set,$styleIds$:new Set,$events$:new Set,$serverData$:{},$base$:e,$renderPromise$:void 0,$hostsRendering$:void 0,$pauseCtx$:void 0,$subsManager$:null};return a.$subsManager$=qu(a),a},nl=(t,e)=>{if(mt(t))return t(e);if(Mt(t)&&"value"in t)return t.value=e;throw lt(32,t)},Vr=t=>Ft(t)&&t.hasAttribute("q:container"),Rt=t=>t.toString(36),St=t=>parseInt(t,36),Xn=t=>{const e=t.indexOf(":");return t&&Fr(t.slice(e+1))},Yr=(t,e)=>{rl(sl(t,void 0),e)},_n=(t,e)=>{rl(sl(t,"document"),e)},Zr=(t,e)=>{rl(sl(t,"window"),e)},sl=(t,e)=>{const a=e!==void 0?e+":":"";return Array.isArray(t)?t.map(l=>`${a}on-${l}`):`${a}on-${t}`},rl=(t,e)=>{if(e){const a=ws(),l=vt(a.$hostElement$,a.$renderCtx$.$static$.$containerState$);typeof t=="string"?l.li.push([za(t),e]):l.li.push(...t.map(r=>[za(r),e])),l.$flags$|=Gt}},Jr=(t,e,a,l)=>{typeof CustomEvent=="function"&&t&&t.dispatchEvent(new CustomEvent(e,{detail:a,bubbles:l,composed:l}))},u=(t,e,a)=>new Ra(t,e,a),Xr=t=>{const e=t.$funcStr$;let a="";for(let l=0;l<t.$args$.length;l++)a+=`p${l},`;return`(${a})=>(${e})`};var Kn;const Kr=(t,e,a,l)=>{const r=e.$subsManager$.$createManager$(l);return new De(t,r,a)},Se=Symbol("proxy manager"),ts=Symbol("unassigned signal");class qe{}class De extends qe{constructor(e,a,l){super(),this[Kn]=0,this.untrackedValue=e,this[Pt]=a,this[Se]=l}valueOf(){}toString(){return`[Signal ${String(this.value)}]`}toJSON(){return{value:this.value}}get value(){var a;if(2&this[Se])throw ts;const e=(a=wt())==null?void 0:a.$subscriber$;return e&&this[Pt].$addSub$(e),this.untrackedValue}set value(e){const a=this[Pt];a&&this.untrackedValue!==e&&(this.untrackedValue=e,a.$notifySubs$())}}Kn=Se;class Ra extends qe{constructor(e,a,l){super(),this.$func$=e,this.$args$=a,this.$funcStr$=l}get value(){return this.$func$.apply(void 0,this.$args$)}}class Ga extends qe{constructor(e,a){super(),this.ref=e,this.prop=a}get[Pt](){return dt(this.ref)}get value(){return this.ref[this.prop]}set value(e){this.ref[this.prop]=e}}const ht=t=>t instanceof qe,f=(t,e)=>{var r,i;if(!Mt(t))return t[e];if(t instanceof qe)return t;const a=Jt(t);if(a){const c=a["$$"+e];if(c)return c;if(((r=a[s])==null?void 0:r[e])!==!0)return new Ga(t,e)}const l=(i=t[s])==null?void 0:i[e];return ht(l)?l:s},y=(t,e)=>{const a=f(t,e);return a===s?t[e]:a},il=(t,e,a=0)=>e.$proxyMap$.get(t)||(a!==0&&Ta(t,a),Ne(t,e,void 0)),Ne=(t,e,a)=>{He(t),e.$proxyMap$.has(t);const l=e.$subsManager$.$createManager$(a),r=new Proxy(t,new es(e,l));return e.$proxyMap$.set(t,r),r},_a=()=>{const t={};return Ta(t,2),t},Ta=(t,e)=>{Object.defineProperty(t,te,{value:e,enumerable:!1})},ti=(t,e)=>{const a={};for(const l in t)e.includes(l)||(a[l]=t[l]);return a};class es{constructor(e,a){this.$containerState$=e,this.$manager$=a}deleteProperty(e,a){if(2&e[te])throw lt(17);return typeof a=="string"&&delete e[a]&&(this.$manager$.$notifySubs$(tt(e)?void 0:a),!0)}get(e,a){var g;if(typeof a=="symbol")return a===qa?e:a===Pt?this.$manager$:e[a];const l=e[te]??0,r=wt(),i=(1&l)!=0,c=e["$$"+a];let d,p;if(r&&(d=r.$subscriber$),!(2&l)||a in e&&!ei((g=e[s])==null?void 0:g[a])||(d=null),c?(p=c.value,d=null):p=e[a],d){const $=tt(e);this.$manager$.$addSub$(d,$?void 0:a)}return i?ai(p,this.$containerState$):p}set(e,a,l){if(typeof a=="symbol")return e[a]=l,!0;const r=e[te]??0;if(2&r)throw lt(17);const i=1&r?He(l):l;if(tt(e))return e[a]=i,this.$manager$.$notifySubs$(),!0;const c=e[a];return e[a]=i,c!==i&&this.$manager$.$notifySubs$(a),!0}has(e,a){if(a===qa)return!0;const l=Object.prototype.hasOwnProperty;return!!l.call(e,a)||!(typeof a!="string"||!l.call(e,"$$"+a))}ownKeys(e){if(!(2&(e[te]??0))){let l=null;const r=wt();r&&(l=r.$subscriber$),l&&this.$manager$.$addSub$(l)}return tt(e)?Reflect.ownKeys(e):Reflect.ownKeys(e).map(l=>typeof l=="string"&&l.startsWith("$$")?l.slice(2):l)}getOwnPropertyDescriptor(e,a){return tt(e)||typeof a=="symbol"?Object.getOwnPropertyDescriptor(e,a):{enumerable:!0,configurable:!0}}}const ei=t=>t===s||ht(t),ai=(t,e)=>{if(Mt(t)){if(Object.isFrozen(t))return t;const a=He(t);if(a!==t||Ks(a))return t;if(Be(a)||tt(a))return e.$proxyMap$.get(a)||il(a,e,1)}return t},ol=Symbol("skip render"),as=()=>null,ls=()=>null,Zt=()=>{const t=ws(),e=vt(t.$hostElement$,t.$renderCtx$.$static$.$containerState$),a=e.$seq$||(e.$seq$=[]),l=t.$i$++;return{val:a[l],set:r=>a[l]=r,i:l,iCtx:t,elCtx:e}},qt=t=>Object.freeze({id:al(t)}),zt=(t,e)=>{const{val:a,set:l,elCtx:r}=Zt();if(a!==void 0)return;(r.$contexts$||(r.$contexts$=new Map)).set(t.id,e),l(!0)},de=(t,e)=>{const{val:a,set:l,iCtx:r,elCtx:i}=Zt();if(a!==void 0)return a;const c=ns(t,i,r.$renderCtx$.$static$.$containerState$);if(typeof e=="function")return l(pt(void 0,e,c));if(c!==void 0)return l(c);if(e!==void 0)return l(e);throw lt(13,t.id)},li=(t,e)=>{var r;let a=t,l=1;for(;a&&!((r=a.hasAttribute)!=null&&r.call(a,"q:container"));){for(;a=a.previousSibling;)if(Oe(a)){const i=a.__virtual;if(i){const c=i[wa];if(a===i.open)return c??vt(i,e);if(c!=null&&c.$parentCtx$)return c.$parentCtx$;a=i;continue}if(a.data==="/qv")l++;else if(a.data.startsWith("qv ")&&(l--,l===0))return vt(Fe(a),e)}a=t.parentElement,t=a}return null},ni=(t,e)=>(t.$parentCtx$===void 0&&(t.$parentCtx$=li(t.$element$,e)),t.$parentCtx$),ns=(t,e,a)=>{var i;const l=t.id;if(!e)return;let r=e;for(;r;){const c=(i=r.$contexts$)==null?void 0:i.get(l);if(c)return c;r=ni(r,a)}},si=qt("qk-error"),ul=(t,e,a)=>{const l=bt(e);if(It())throw t;{const r=ns(si,l,a.$static$.$containerState$);if(r===void 0)throw t;r.error=t}},ri=new Set(["animationIterationCount","aspectRatio","borderImageOutset","borderImageSlice","borderImageWidth","boxFlex","boxFlexGroup","boxOrdinalGroup","columnCount","columns","flex","flexGrow","flexShrink","gridArea","gridRow","gridRowEnd","gridRowStart","gridColumn","gridColumnEnd","gridColumnStart","fontWeight","lineClamp","lineHeight","opacity","order","orphans","scale","tabSize","widows","zIndex","zoom","MozAnimationIterationCount","MozBoxFlex","msFlex","msFlexPositive","WebkitAnimationIterationCount","WebkitBoxFlex","WebkitBoxOrdinalGroup","WebkitColumnCount","WebkitColumns","WebkitFlex","WebkitFlexGrow","WebkitFlexShrink","WebkitLineClamp"]),ii=t=>ri.has(t),aa=(t,e)=>{e.$flags$&=~re,e.$flags$|=ml,e.$slots$=[],e.li.length=0;const a=e.$element$,l=e.$componentQrl$,r=e.$props$,i=_t(t.$static$.$locale$,a,void 0,"qRender"),c=i.$waitOn$=[],d=ze(t);d.$cmpCtx$=e,d.$slotCtx$=null,i.$subscriber$=[0,a],i.$renderCtx$=t,l.$setContainer$(t.$static$.$containerState$.$containerEl$);const p=l.getFn(i);return va(()=>p(r),g=>Y(Ke(c),()=>e.$flags$&re?aa(t,e):{node:g,rCtx:d}),g=>g===ts?Y(Ke(c),()=>aa(t,e)):(ul(g,a,t),{node:ol,rCtx:d}))},ss=(t,e)=>({$static$:{$doc$:t,$locale$:e.$serverData$.locale,$containerState$:e,$hostElements$:new Set,$operations$:[],$postOperations$:[],$roots$:[],$addSlots$:[],$rmSlots$:[],$visited$:[]},$cmpCtx$:null,$slotCtx$:null}),ze=t=>({$static$:t.$static$,$cmpCtx$:t.$cmpCtx$,$slotCtx$:t.$slotCtx$}),cl=(t,e)=>e&&e.$scopeIds$?e.$scopeIds$.join(" ")+" "+la(t):la(t),la=t=>{if(!t)return"";if(Yt(t))return t.trim();const e=[];if(tt(t))for(const a of t){const l=la(a);l&&e.push(l)}else for(const[a,l]of Object.entries(t))l&&e.push(a.trim());return e.join(" ")},Sa=t=>{if(t==null)return"";if(typeof t=="object"){if(tt(t))throw lt(0,t,"style");{const e=[];for(const a in t)if(Object.prototype.hasOwnProperty.call(t,a)){const l=t[a];l!=null&&(a.startsWith("--")?e.push(a+":"+l):e.push(al(a)+":"+oi(a,l)))}return e.join(";")}}return String(t)},oi=(t,e)=>typeof e!="number"||e===0||ii(t)?e:e+"px",Pe=t=>Rt(t.$static$.$containerState$.$elementIndex$++),rs=(t,e)=>{const a=Pe(t);e.$id$=a},se=t=>ht(t)?se(t.value):t==null||typeof t=="boolean"?"":String(t);function is(t){return t.startsWith("aria-")}const os=(t,e)=>!!e.key&&(!pe(t)||!mt(t.type)&&t.key!=e.key),ot="dangerouslySetInnerHTML",dl=(t,e,a)=>{const l=!(e.$flags$&ml),r=e.$element$,i=t.$static$.$containerState$;return i.$hostsStaging$.delete(e),i.$subsManager$.$clearSub$(r),Y(aa(t,e),c=>{const d=t.$static$,p=c.rCtx,g=_t(t.$static$.$locale$,r);if(d.$hostElements$.add(r),g.$subscriber$=[0,r],g.$renderCtx$=p,l&&e.$appendStyles$)for(const h of e.$appendStyles$)Po(d,h);const $=ke(c.node,g);return Y($,h=>{const w=ui(r,h),T=pl(e);return Y(ua(p,T,w,a),()=>{e.$vdom$=w})})})},pl=t=>(t.$vdom$||(t.$vdom$=ca(t.$element$)),t.$vdom$);class jt{constructor(e,a,l,r,i,c){this.$type$=e,this.$props$=a,this.$immutableProps$=l,this.$children$=r,this.$flags$=i,this.$key$=c,this.$elm$=null,this.$text$="",this.$signal$=null,this.$id$=e+(c?":"+c:"")}}const us=(t,e)=>{const{key:a,type:l,props:r,children:i,flags:c,immutableProps:d}=t;let p="";if(Yt(l))p=l;else{if(l!==Ut){if(mt(l)){const $=pt(e,l,r,a,c,t.dev);return os($,t)?us(o(Ut,{children:$},0,a),e):ke($,e)}throw lt(25,l)}p=ie}let g=Dt;return i!=null?Y(ke(i,e),$=>($!==void 0&&(g=tt($)?$:[$]),new jt(p,r,d,g,c,a))):new jt(p,r,d,g,c,a)},ui=(t,e)=>{const a=e===void 0?Dt:tt(e)?e:[e],l=new jt(":virtual",{},null,a,0,null);return l.$elm$=t,l},ke=(t,e)=>{if(t!=null&&typeof t!="boolean"){if(cs(t)){const a=new jt("#text",ct,null,Dt,0,null);return a.$text$=String(t),a}if(pe(t))return us(t,e);if(ht(t)){const a=new jt("#text",ct,null,Dt,0,null);return a.$signal$=t,a}if(tt(t)){const a=el(t.flatMap(l=>ke(l,e)));return Y(a,l=>l.flat(100).filter(Zn))}return rt(t)?t.then(a=>ke(a,e)):t===ol?new jt(ra,ct,null,Dt,0,null):void Te()}},cs=t=>Yt(t)||typeof t=="number",ds=t=>{Tt(t,"q:container")==="paused"&&(di(t),mi(t))},ci=t=>{const e=Ae(t),a=gs(t===e.documentElement?e.body:t,"type");if(a)return JSON.parse(gi(a.firstChild.data)||"{}")},Ih=(t,e)=>{const a=JSON.parse(t);if(typeof a!="object")return null;const{_objs:l,_entry:r}=a;if(l===void 0||r===void 0)return null;let i={},c={};if(Qt(e)&&Vt(e)){const g=$l(e);g&&(c=ce(g),i=g.ownerDocument)}const d=Js(c,i);for(let g=0;g<l.length;g++){const $=l[g];Yt($)&&(l[g]=$===Ma?void 0:d.prepare($))}const p=g=>l[St(g)];for(const g of l)ps(g,p,d);return p(r)},di=t=>{if(!Vr(t))return void Te();const e=t._qwikjson_??ci(t);if(t._qwikjson_=null,!e)return void Te();const a=Ae(t),l=t===a.documentElement?a.body:t,r=fi(l),i=ce(t),c=new Map,d=new Map;let p=null,g=0;const $=a.createTreeWalker(t,128);for(;p=$.nextNode();){const b=p.data;if(g===0){if(b.startsWith("qv ")){const j=$i(b);j>=0&&c.set(j,p)}else if(b.startsWith("t=")){const j=b.slice(2),k=St(j),_=xi(p);c.set(k,_),d.set(k,_.data)}}b==="cq"?g++:b==="/cq"&&g--}const h=t.getElementsByClassName("qc📦").length!==0;t.querySelectorAll("[q\\:id]").forEach(b=>{if(h&&b.closest("[q\\:container]")!==t)return;const j=Tt(b,"q:id"),k=St(j);c.set(k,b)});const w=Js(i,a),T=new Map,D=new Set,P=b=>(typeof b=="string"&&b.length>0,T.has(b)?T.get(b):S(b)),S=b=>{if(b.startsWith("#")){const E=b.slice(1),L=St(E);c.has(L);const M=c.get(L);if(Oe(M)){if(!M.isConnected)return void T.set(b,void 0);const B=Fe(M);return T.set(b,B),vt(B,i),B}return Ft(M)?(T.set(b,M),vt(M,i),M):(T.set(b,M),M)}if(b.startsWith("@")){const E=b.slice(1),L=St(E);return r[L]}if(b.startsWith("*")){const E=b.slice(1),L=St(E);c.has(L);const M=d.get(L);return T.set(b,M),M}const j=St(b),k=e.objs;k.length>j;let _=k[j];Yt(_)&&(_=_===Ma?void 0:w.prepare(_));let C=_;for(let E=b.length-1;E>=0;E--){const L=Cu[b[E]];if(!L)break;C=L(C,i)}return T.set(b,C),cs(_)||D.has(j)||(D.add(j),pi(_,j,e.subs,P,i,w),ps(_,P,w)),C};i.$elementIndex$=1e5,i.$pauseCtx$={getObject:P,meta:e.ctx,refs:e.refs},xt(t,"q:container","resumed"),Jr(t,"qresume",void 0,!0)},pi=(t,e,a,l,r,i)=>{const c=a[e];if(c){const d=[];let p=0;for(const g of c)if(g.startsWith("_"))p=parseInt(g.slice(1),10);else{const $=Au(g,l);$&&d.push($)}if(p>0&&Ta(t,p),!i.subs(t,d)){const g=r.$proxyMap$.get(t);g?dt(g).$addSubs$(d):Ne(t,r,d)}}},ps=(t,e,a)=>{if(!a.fill(t,e)&&t&&typeof t=="object"){if(tt(t))for(let l=0;l<t.length;l++)t[l]=e(t[l]);else if(Be(t))for(const l in t)t[l]=e(t[l])}},gi=t=>t.replace(/\\x3C(\/?script)/g,"<$1"),fi=t=>{const e=gs(t,"q:func");return(e==null?void 0:e.qFuncs)??Dt},gs=(t,e)=>{let a=t.lastElementChild;for(;a;){if(a.tagName==="SCRIPT"&&Tt(a,e)==="qwik/json")return a;a=a.previousElementSibling}},xi=t=>{const e=t.nextSibling;if(Ja(e))return e;{const a=t.ownerDocument.createTextNode("");return t.parentElement.insertBefore(a,t),a}},mi=t=>{t.qwik={pause:()=>Qo(t),state:ce(t)}},$i=t=>{const e=t.indexOf("q:id=");return e>0?St(t.slice(e+5)):-1},et=()=>{const t=qi();let e=t.$qrl$;if(e)e.$captureRef$;else{const a=t.$element$,l=$l(a);e=La(decodeURIComponent(String(t.$url$)),l),ds(l);const r=vt(a,ce(l));Ys(e,r)}return e.$captureRef$},hi=(t,e)=>{try{const a=e[0];switch(a){case 1:case 2:{let l,r;a===1?(l=e[1],r=e[3]):(l=e[3],r=e[1]);const i=bt(l);if(i==null)return;const c=e[4],d=l.namespaceURI===Qe;t.$containerState$.$subsManager$.$clearSignal$(e);let p=Et(e[2],e.slice(0,-1));c==="class"?p=cl(p,bt(r)):c==="style"&&(p=Sa(p));const g=pl(i);return c in g.$props$&&g.$props$[c]===p?void 0:(g.$props$[c]=p,yl(t,l,c,p,d))}case 3:case 4:{const l=e[3];if(!t.$visited$.includes(l)){t.$containerState$.$subsManager$.$clearSignal$(e);const r=Et(e[2],e.slice(0,-1));return Ot(t,l,"data",se(r))}}}}catch{}},bi=(t,e)=>{if(t[0]===0){const a=t[1];xl(a)?gl(a,e):vi(a,e)}else yi(t,e)},vi=(t,e)=>{const a=It();a||ds(e.$containerEl$);const l=vt(t,e);if(l.$componentQrl$,!(l.$flags$&re))if(l.$flags$|=re,e.$hostsRendering$!==void 0)e.$hostsStaging$.add(l);else{if(a)return void Te();e.$hostsNext$.add(l),fl(e)}},yi=(t,e)=>{const a=e.$hostsRendering$!==void 0;e.$opsNext$.add(t),a||fl(e)},gl=(t,e)=>{t.$flags$&Wt||(t.$flags$|=Wt,e.$hostsRendering$!==void 0?e.$taskStaging$.add(t):(e.$taskNext$.add(t),fl(e)))},fl=t=>(t.$renderPromise$===void 0&&(t.$renderPromise$=ba().nextTick(()=>fs(t))),t.$renderPromise$),wi=()=>{const[t]=et();gl(t,ce($l(t.$el$)))},fs=async t=>{const e=t.$containerEl$,a=Ae(e);try{const l=ss(a,t),r=l.$static$,i=t.$hostsRendering$=new Set(t.$hostsNext$);t.$hostsNext$.clear(),await Ti(t,l),t.$hostsStaging$.forEach(p=>{i.add(p)}),t.$hostsStaging$.clear();const c=Array.from(t.$opsNext$);t.$opsNext$.clear();const d=Array.from(i);Di(d),!t.$styleMoved$&&d.length>0&&(t.$styleMoved$=!0,(e===a.documentElement?a.body:e).querySelectorAll("style[q\\:style]").forEach(p=>{t.$styleIds$.add(Tt(p,ya)),Rs(r,a.head,p)}));for(const p of d){const g=p.$element$;if(!r.$hostElements$.has(g)&&p.$componentQrl$){g.isConnected,r.$roots$.push(p);try{await dl(l,p,_i(g.parentElement))}catch($){_e($)}}}return c.forEach(p=>{hi(r,p)}),r.$operations$.push(...r.$postOperations$),r.$operations$.length===0?(In(r),void await Tn(t,l)):(await vo(r),In(r),Tn(t,l))}catch(l){_e(l)}},_i=t=>{let e=0;return t&&(t.namespaceURI===Qe&&(e|=ft),t.tagName==="HEAD"&&(e|=ia)),e},Tn=async(t,e)=>{const a=e.$static$.$hostElements$;await Si(t,e,(l,r)=>(l.$flags$&xs)!=0&&(!r||a.has(l.$el$))),t.$hostsStaging$.forEach(l=>{t.$hostsNext$.add(l)}),t.$hostsStaging$.clear(),t.$hostsRendering$=void 0,t.$renderPromise$=void 0,t.$hostsNext$.size+t.$taskNext$.size+t.$opsNext$.size>0&&(t.$renderPromise$=fs(t))},Ti=async(t,e)=>{const a=t.$containerEl$,l=[],r=[],i=d=>(d.$flags$&ms)!=0,c=d=>(d.$flags$&$s)!=0;t.$taskNext$.forEach(d=>{i(d)&&(r.push(Y(d.$qrl$.$resolveLazy$(a),()=>d)),t.$taskNext$.delete(d)),c(d)&&(l.push(Y(d.$qrl$.$resolveLazy$(a),()=>d)),t.$taskNext$.delete(d))});do if(t.$taskStaging$.forEach(d=>{i(d)?r.push(Y(d.$qrl$.$resolveLazy$(a),()=>d)):c(d)?l.push(Y(d.$qrl$.$resolveLazy$(a),()=>d)):t.$taskNext$.add(d)}),t.$taskStaging$.clear(),r.length>0){const d=await Promise.all(r);Qa(d),await Promise.all(d.map(p=>Fa(p,t,e))),r.length=0}while(t.$taskStaging$.size>0);if(l.length>0){const d=await Promise.all(l);Qa(d),d.forEach(p=>Fa(p,t,e))}},Si=async(t,e,a)=>{const l=[],r=t.$containerEl$;t.$taskNext$.forEach(i=>{a(i,!1)&&(i.$el$.isConnected&&l.push(Y(i.$qrl$.$resolveLazy$(r),()=>i)),t.$taskNext$.delete(i))});do if(t.$taskStaging$.forEach(i=>{i.$el$.isConnected&&(a(i,!0)?l.push(Y(i.$qrl$.$resolveLazy$(r),()=>i)):t.$taskNext$.add(i))}),t.$taskStaging$.clear(),l.length>0){const i=await Promise.all(l);Qa(i);for(const c of i)Fa(c,t,e);l.length=0}while(t.$taskStaging$.size>0)},Di=t=>{t.sort((e,a)=>2&e.$element$.compareDocumentPosition(pa(a.$element$))?1:-1)},Qa=t=>{t.sort((e,a)=>e.$el$===a.$el$?e.$index$<a.$index$?-1:1:2&e.$el$.compareDocumentPosition(pa(a.$el$))?1:-1)},xs=1,ms=2,$s=4,Wt=16,hs=(t,e)=>{const{val:a,set:l,iCtx:r,i,elCtx:c}=Zt();if(a)return;const d=r.$renderCtx$.$static$.$containerState$,p=new Da(Wt|ms,i,c.$element$,t,void 0);l(!0),t.$resolveLazy$(d.$containerEl$),c.$tasks$||(c.$tasks$=[]),c.$tasks$.push(p),Ni(r,()=>vs(p,d,r.$renderCtx$)),It()&&Ha(p,e==null?void 0:e.eagerness)},Re=(t,e)=>{const{val:a,set:l,i:r,iCtx:i,elCtx:c}=Zt(),d=(e==null?void 0:e.strategy)??"intersection-observer";if(a)return void(It()&&Ha(a,d));const p=new Da(xs,r,c.$element$,t,void 0),g=i.$renderCtx$.$static$.$containerState$;c.$tasks$||(c.$tasks$=[]),c.$tasks$.push(p),l(p),Ha(p,d),It()||(t.$resolveLazy$(g.$containerEl$),gl(p,g))},bs=t=>(t.$flags$&$s)!=0,Pi=t=>(8&t.$flags$)!=0,Fa=async(t,e,a)=>(t.$flags$&Wt,bs(t)?ki(t,e,a):Pi(t)?Li(t,e,a):vs(t,e,a)),ki=(t,e,a,l)=>{t.$flags$&=~Wt,Le(t);const r=_t(a.$static$.$locale$,t.$el$,void 0,"TaskEvent"),{$subsManager$:i}=e;r.$renderCtx$=a;const c=t.$qrl$.getFn(r,()=>{i.$clearSub$(t)}),d=[],p=t.$state$,g=He(p),$={track:(b,j)=>{if(mt(b)){const _=_t();return _.$renderCtx$=a,_.$subscriber$=[0,t],pt(_,b)}const k=dt(b);return k?k.$addSub$([0,t],j):Xa(ha(26),b),j?b[j]:ht(b)?b.value:b},cleanup(b){d.push(b)},cache(b){let j=0;j=b==="immutable"?1/0:b,p._cache=j},previous:g._resolved};let h,w,T=!1;const D=(b,j)=>!T&&(T=!0,b?(T=!0,p.loading=!1,p._state="resolved",p._resolved=j,p._error=void 0,h(j)):(T=!0,p.loading=!1,p._state="rejected",p._error=j,w(j)),!0);pt(r,()=>{p._state="pending",p.loading=!It(),p.value=new Promise((b,j)=>{h=b,w=j})}),t.$destroy$=ja(()=>{T=!0,d.forEach(b=>b())});const P=va(()=>Y(l,()=>c($)),b=>{D(!0,b)},b=>{D(!1,b)}),S=g._timeout;return S>0?Promise.race([P,Qr(S).then(()=>{D(!1,new Error("timeout"))&&Le(t)})]):P},vs=(t,e,a)=>{t.$flags$&=~Wt,Le(t);const l=t.$el$,r=_t(a.$static$.$locale$,l,void 0,"TaskEvent");r.$renderCtx$=a;const{$subsManager$:i}=e,c=t.$qrl$.getFn(r,()=>{i.$clearSub$(t)}),d=[];t.$destroy$=ja(()=>{d.forEach(g=>g())});const p={track:(g,$)=>{if(mt(g)){const w=_t();return w.$subscriber$=[0,t],pt(w,g)}const h=dt(g);return h?h.$addSub$([0,t],$):Xa(ha(26),g),$?g[$]:g},cleanup(g){d.push(g)}};return va(()=>c(p),g=>{mt(g)&&d.push(g)},g=>{ul(g,l,a)})},Li=(t,e,a)=>{t.$state$,t.$flags$&=~Wt,Le(t);const l=t.$el$,r=_t(a.$static$.$locale$,l,void 0,"ComputedEvent");r.$subscriber$=[0,t],r.$renderCtx$=a;const{$subsManager$:i}=e,c=t.$qrl$.getFn(r,()=>{i.$clearSub$(t)});return va(c,d=>na(()=>{const p=t.$state$;p[Se]&=-3,p.untrackedValue=d,p[Pt].$notifySubs$()}),d=>{ul(d,l,a)})},Le=t=>{const e=t.$destroy$;if(e){t.$destroy$=void 0;try{e()}catch(a){_e(a)}}},ys=t=>{32&t.$flags$?(t.$flags$&=-33,(0,t.$qrl$)()):Le(t)},Ha=(t,e)=>{e==="visible"||e==="intersection-observer"?Yr("qvisible",Oa(t)):e==="load"||e==="document-ready"?_n("qinit",Oa(t)):e!=="idle"&&e!=="document-idle"||_n("qidle",Oa(t))},Oa=t=>{const e=t.$qrl$;return Ia(e.$chunk$,"_hW",wi,null,null,[t],e.$symbol$)},xl=t=>Mt(t)&&t instanceof Da,Mi=(t,e)=>{let a=`${Rt(t.$flags$)} ${Rt(t.$index$)} ${e(t.$qrl$)} ${e(t.$el$)}`;return t.$state$&&(a+=` ${e(t.$state$)}`),a},Ci=t=>{const[e,a,l,r,i]=t.split(" ");return new Da(St(e),St(a),r,l,i)};class Da{constructor(e,a,l,r,i){this.$flags$=e,this.$index$=a,this.$el$=l,this.$qrl$=r,this.$state$=i}}function ji(t){return Ii(t)&&t.nodeType===1}function Ii(t){return t&&typeof t.nodeType=="number"}const re=1,Gt=2,ml=4,bt=t=>t[wa],vt=(t,e)=>{const a=bt(t);if(a)return a;const l=Pa(t),r=Tt(t,"q:id");if(r){const i=e.$pauseCtx$;if(l.$id$=r,i){const{getObject:c,meta:d,refs:p}=i;if(ji(t)){const g=p[r];g&&(l.$refMap$=g.split(" ").map(c),l.li=Ur(l,e.$containerEl$))}else{const g=t.getAttribute("q:sstyle");l.$scopeIds$=g?g.split("|"):null;const $=d[r];if($){const h=$.s,w=$.h,T=$.c,D=$.w;if(h&&(l.$seq$=h.split(" ").map(c)),D&&(l.$tasks$=D.split(" ").map(c)),T){l.$contexts$=new Map;for(const P of T.split(" ")){const[S,b]=P.split("=");l.$contexts$.set(S,c(b))}}if(w){const[P,S]=w.split(" ");if(l.$flags$=ml,P&&(l.$componentQrl$=c(P)),S){const b=c(S);l.$props$=b,Ta(b,2),b[s]=Ei(b)}else l.$props$=Ne(_a(),e)}}}}}return l},Ei=t=>{const e={},a=Jt(t);for(const l in a)l.startsWith("$$")&&(e[l.slice(2)]=a[l]);return e},Pa=t=>{const e={$flags$:0,$id$:"",$element$:t,$refMap$:[],li:[],$tasks$:null,$seq$:null,$slots$:null,$scopeIds$:null,$appendStyles$:null,$props$:null,$vdom$:null,$componentQrl$:null,$contexts$:null,$dynamicSlots$:null,$parentCtx$:void 0};return t[wa]=e,e},Oi=(t,e)=>{var a;(a=t.$tasks$)==null||a.forEach(l=>{e.$clearSub$(l),ys(l)}),t.$componentQrl$=null,t.$seq$=null,t.$tasks$=null};let ae;function Bi(t){if(ae===void 0){const e=wt();if(e&&e.$locale$)return e.$locale$;if(t!==void 0)return t;throw new Error("Reading `locale` outside of context.")}return ae}function Sn(t,e){const a=ae;try{return ae=t,e()}finally{ae=a}}function Ai(t){ae=t}let be;const wt=()=>{if(!be){const t=typeof document<"u"&&document&&document.__q_context__;return t?tt(t)?document.__q_context__=_s(t):t:void 0}return be},qi=()=>{const t=wt();if(!t)throw lt(14);return t},ws=()=>{const t=wt();if(!t||t.$event$!=="qRender")throw lt(20);return t.$hostElement$,t.$waitOn$,t.$renderCtx$,t.$subscriber$,t};function pt(t,e,...a){const l=be;let r;try{be=t,r=e.apply(this,a)}finally{be=l}return r}const Ni=(t,e)=>{const a=t.$waitOn$;if(a.length===0){const l=e();rt(l)&&a.push(l)}else a.push(Promise.all(a).then(e))},_s=t=>{const e=t[0],a=e.closest("[q\\:container]"),l=(a==null?void 0:a.getAttribute("q:locale"))||void 0;return l&&Ai(l),_t(l,void 0,e,t[1],t[2])},_t=(t,e,a,l,r)=>({$url$:r,$i$:0,$hostElement$:e,$element$:a,$event$:l,$qrl$:void 0,$waitOn$:void 0,$subscriber$:void 0,$renderCtx$:void 0,$locale$:t}),$l=t=>t.closest("[q\\:container]"),na=t=>pt(void 0,t),Dn=_t(void 0,void 0,void 0,"qRender"),Et=(t,e)=>(Dn.$subscriber$=e,pt(Dn,()=>t.value)),zi=()=>{var e;const t=wt();if(t)return t.$element$??t.$hostElement$??((e=t.$qrl$)==null?void 0:e.$setContainer$(void 0))},Ri=()=>{const t=wt();if(t)return t.$event$},Z=t=>{const e=wt();return e&&e.$hostElement$&&e.$renderCtx$&&(vt(e.$hostElement$,e.$renderCtx$.$static$.$containerState$).$flags$|=8),t},Gi=(t,e=0)=>{for(let a=0;a<t.length;a++)e=(e<<5)-e+t.charCodeAt(a),e|=0;return Number(Math.abs(e)).toString(36)},Qi=(t,e)=>`${Gi(t.$hash$)}-${e}`,Fi=t=>"⭐️"+t,Ts=t=>{const e=t.join("|");if(e.length>0)return e};var Ss;const Ze="<!--qkssr-f-->";class Ds{constructor(e){this.nodeType=e,this[Ss]=null}}Ss=wa;const Hi=()=>new Ds(9),Eh=async(t,e)=>{var w,T,D;const a=e.containerTagName,l=sa(1).$element$,r=Jn(l,e.base??"/");r.$serverData$.locale=(w=e.serverData)==null?void 0:w.locale;const i=Hi(),c=ss(i,r),d=e.beforeContent??[],p={$static$:{$contexts$:[],$headNodes$:a==="html"?d:[],$locale$:(T=e.serverData)==null?void 0:T.locale,$textNodes$:new Map},$projectedChildren$:void 0,$projectedCtxs$:void 0,$invocationContext$:void 0};let g="ssr";e.containerAttributes["q:render"]&&(g=`${e.containerAttributes["q:render"]}-${g}`);const $={...e.containerAttributes,"q:container":"paused","q:version":"1.2.19","q:render":g,"q:base":e.base,"q:locale":(D=e.serverData)==null?void 0:D.locale,"q:manifest-hash":e.manifestHash},h=a==="html"?[t]:[d,t];a!=="html"&&($.class="qc📦"+($.class?" "+$.class:"")),e.serverData&&(r.$serverData$=e.serverData),t=n(a,null,$,h,re|Gt,null),r.$hostsRendering$=new Set,await Promise.resolve().then(()=>Wi(t,c,p,e.stream,r,e))},Wi=async(t,e,a,l,r,i)=>{const c=i.beforeClose;return await bl(t,e,a,l,0,c?d=>{const p=c(a.$static$.$contexts$,r,!1,a.$static$.$textNodes$);return kt(p,e,a,d,0,void 0)}:void 0),e},Ui=async(t,e,a,l,r)=>{l.write(Ze);const i=t.props.children;let c;if(mt(i)){const d=i({write(p){l.write(p),l.write(Ze)}});if(rt(d))return d;c=d}else c=i;for await(const d of c)await kt(d,e,a,l,r,void 0),l.write(Ze)},Ps=(t,e,a,l,r,i,c,d)=>{var P;const p=t.props,g=p["q:renderFn"];if(g)return e.$componentQrl$=g,Zi(l,r,i,e,t,c,d);let $="<!--qv"+Yi(p);const h="q:s"in p,w=t.key!=null?String(t.key):null;h&&((P=l.$cmpCtx$)==null||P.$id$,$+=" q:sref="+l.$cmpCtx$.$id$),w!=null&&($+=" q:key="+w),$+="-->",i.write($);const T=t.props[ot];if(T)return i.write(T),void i.write(Ba);if(a)for(const S of a)hl(S.type,S.props,i);const D=ks(t.children,l,r,i,c);return Y(D,()=>{var b;if(!h&&!d)return void i.write(Ba);let S;if(h){const j=(b=r.$projectedChildren$)==null?void 0:b[w];if(j){const[k,_]=r.$projectedCtxs$,C=ze(k);C.$slotCtx$=e,r.$projectedChildren$[w]=void 0,S=kt(j,C,_,i,c)}}return d&&(S=Y(S,()=>d(i))),Y(S,()=>{i.write(Ba)})})},Ba="<!--/qv-->",Vi=t=>{let e="";for(const a in t){if(a===ot)continue;const l=t[a];l!=null&&(e+=" "+(l===""?a:a+'="'+l+'"'))}return e},Yi=t=>{let e="";for(const a in t){if(a==="children"||a===ot)continue;const l=t[a];l!=null&&(e+=" "+(l===""?a:a+"="+l))}return e},hl=(t,e,a)=>{if(a.write("<"+t+Vi(e)+">"),Cs[t])return;const l=e[ot];l!=null&&a.write(l),a.write(`</${t}>`)},Zi=(t,e,a,l,r,i,c)=>(Xi(t,l,r.props.props),Y(aa(t,l),d=>{const p=l.$element$,g=d.rCtx,$=_t(e.$static$.$locale$,p,void 0);$.$subscriber$=[0,p],$.$renderCtx$=g;const h={$static$:e.$static$,$projectedChildren$:Ji(r.children,e),$projectedCtxs$:[t,e],$invocationContext$:$},w=[];if(l.$appendStyles$){const S=4&i?e.$static$.$headNodes$:w;for(const b of l.$appendStyles$)S.push(n("style",{[ya]:b.styleId,[ot]:b.content,hidden:""},null,null,0,null))}const T=Pe(t),D=l.$scopeIds$?Ts(l.$scopeIds$):void 0,P=o(r.type,{"q:sstyle":D,"q:id":T,children:d.node},0,r.key);return l.$id$=T,e.$static$.$contexts$.push(l),Ps(P,l,w,g,h,a,i,S=>{if(l.$flags$&Gt){const k=sa(1),_=k.li;_.push(...l.li),l.$flags$&=~Gt,k.$id$=Pe(t);const C={type:"placeholder",hidden:"","q:id":k.$id$};e.$static$.$contexts$.push(k);const E=ll(_);for(const L of E){const M=js(L[0]);C[M]=Dl(L[1],k),Je(M,t.$static$.$containerState$)}hl("script",C,S)}const b=h.$projectedChildren$;let j;if(b){const k=Object.keys(b).map(L=>{const M=b[L];if(M)return n("q:template",{[$t]:L,hidden:"","aria-hidden":"true"},null,M,0,null)}),[_,C]=h.$projectedCtxs$,E=ze(_);E.$slotCtx$=l,j=kt(k,E,C,S,0,void 0)}return c?Y(j,()=>c(S)):j})})),Ji=(t,e)=>{const a=Ls(t,e);if(a===null)return;const l={};for(const r of a){let i="";pe(r)&&(i=r.props[$t]??""),(l[i]||(l[i]=[])).push(r)}return l},sa=t=>{const e=new Ds(t);return Pa(e)},bl=(t,e,a,l,r,i)=>{var g;const c=t.type,d=e.$cmpCtx$;if(typeof c=="string"){const $=t.key,h=t.props,w=t.immutableProps,T=sa(1),D=T.$element$,P=c==="head";let S="<"+c,b=!1,j=!1,k="",_=null;if(w)for(const L in w){let M=w[L];if(ta(L)){ea(T.li,L,M,void 0);continue}const B=Pn(L);if(ht(M)&&(M=Et(M,[1,D,M,d.$element$,B]),b=!0),L===ot){_=M;continue}L.startsWith(Na)&&Je(L.slice(15),e.$static$.$containerState$);const W=kn(B,M);W!=null&&(B==="class"?k=W:B==="value"&&c==="textarea"?_=ve(W):Ln(B)||(S+=" "+(M===""?B:B+'="'+Ve(W)+'"')))}for(const L in h){let M=h[L];if(L==="ref"){M!==void 0&&(nl(M,D),j=!0);continue}if(ta(L)){ea(T.li,L,M,void 0);continue}const B=Pn(L);if(ht(M)&&(M=Et(M,[2,d.$element$,M,D,B]),b=!0),L===ot){_=M;continue}L.startsWith(Na)&&Je(L.slice(15),e.$static$.$containerState$);const W=kn(B,M);W!=null&&(B==="class"?k=W:B==="value"&&c==="textarea"?_=ve(W):Ln(B)||(S+=" "+(M===""?B:B+'="'+Ve(W)+'"')))}const C=T.li;if(d){if((g=d.$scopeIds$)!=null&&g.length){const L=d.$scopeIds$.join(" ");k=k?`${L} ${k}`:L}d.$flags$&Gt&&(C.push(...d.li),d.$flags$&=~Gt)}if(P&&(r|=1),c in Ki&&(r|=16),c in to&&(r|=8),k&&(S+=' class="'+Ve(k)+'"'),C.length>0){const L=ll(C),M=(16&r)!=0;for(const B of L){const W=M?js(B[0]):B[0];S+=" "+W+'="'+Dl(B[1],T)+'"',Je(W,e.$static$.$containerState$)}}if($!=null&&(S+=' q:key="'+Ve($)+'"'),j||b||C.length>0){if(j||b||no(C)){const L=Pe(e);S+=' q:id="'+L+'"',T.$id$=L}a.$static$.$contexts$.push(T)}if(1&r&&(S+=" q:head"),S+=">",l.write(S),c in Cs)return;if(_!=null)return l.write(String(_)),void l.write(`</${c}>`);c==="html"?r|=4:r&=-5,2&t.flags&&(r|=1024);const E=kt(t.children,e,a,l,r);return Y(E,()=>{if(P){for(const L of a.$static$.$headNodes$)hl(L.type,L.props,l);a.$static$.$headNodes$.length=0}if(i)return Y(i(l),()=>{l.write(`</${c}>`)});l.write(`</${c}>`)})}if(c===Ut){const $=sa(111);return $.$parentCtx$=e.$slotCtx$||e.$cmpCtx$,d&&8&d.$flags$&&so(d,$),Ps(t,$,void 0,e,a,l,r,i)}if(c===as)return void l.write(t.props.data);if(c===ls)return Ui(t,e,a,l,r);const p=pt(a.$invocationContext$,c,t.props,t.key,t.flags,t.dev);return os(p,t)?bl(o(Ut,{children:p},0,t.key),e,a,l,r,i):kt(p,e,a,l,r,i)},kt=(t,e,a,l,r,i)=>{var c;if(t!=null&&typeof t!="boolean"){if(!Yt(t)&&typeof t!="number"){if(pe(t))return bl(t,e,a,l,r,i);if(tt(t))return ks(t,e,a,l,r);if(ht(t)){const d=8&r,p=(c=e.$cmpCtx$)==null?void 0:c.$element$;let g;if(p){if(!d){const $=Pe(e);g=Et(t,1024&r?[3,"#"+$,t,"#"+$]:[4,p,t,"#"+$]);const h=se(g);return a.$static$.$textNodes$.set(h,$),void l.write(`<!--t=${$}-->${ve(h)}<!---->`)}g=pt(a.$invocationContext$,()=>t.value)}return void l.write(ve(se(g)))}return rt(t)?(l.write(Ze),t.then(d=>kt(d,e,a,l,r,i))):void Te()}l.write(ve(String(t)))}},ks=(t,e,a,l,r)=>{if(t==null)return;if(!tt(t))return kt(t,e,a,l,r);const i=t.length;if(i===1)return kt(t[0],e,a,l,r);if(i===0)return;let c=0;const d=[];return t.reduce((p,g,$)=>{const h=[];d.push(h);const w=kt(g,e,a,p?{write(D){c===$?l.write(D):h.push(D)}}:l,r),T=()=>{c++,d.length>c&&d[c].forEach(D=>l.write(D))};return rt(w)&&p?Promise.all([w,p]).then(T):rt(w)?w.then(T):p?p.then(T):void c++},void 0)},Ls=(t,e)=>{if(t==null)return null;const a=Ms(t,e),l=tt(a)?a:[a];return l.length===0?null:l},Ms=(t,e)=>{if(t==null)return null;if(tt(t))return t.flatMap(a=>Ms(a,e));if(pe(t)&&mt(t.type)&&t.type!==as&&t.type!==ls&&t.type!==Ut){const a=pt(e.$invocationContext$,t.type,t.props,t.key,t.flags);return Ls(a,e)}return t},Xi=(t,e,a)=>{const l=Object.keys(a),r=_a();if(e.$props$=Ne(r,t.$static$.$containerState$),l.length===0)return;const i=r[s]=a[s]??ct;for(const c of l)c!=="children"&&c!==$t&&(ht(i[c])?r["$$"+c]=i[c]:r[c]=a[c])},Pn=t=>t==="htmlFor"?"for":t,kn=(t,e)=>t==="class"?la(e):t==="style"?Sa(e):is(t)||t==="draggable"||t==="spellcheck"?e!=null?String(e):e:e===!1||e==null?null:e===!0?"":String(e),Ki={head:!0,style:!0,script:!0,link:!0,meta:!0},to={title:!0,style:!0,script:!0,noframes:!0,textarea:!0},Cs={area:!0,base:!0,basefont:!0,bgsound:!0,br:!0,col:!0,embed:!0,frame:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0},eo=/[&<>]/g,ao=/[&"]/g,Je=(t,e)=>{e.$events$.add(Xn(t))},ve=t=>t.replace(eo,e=>{switch(e){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";default:return""}}),Ve=t=>t.replace(ao,e=>{switch(e){case"&":return"&amp;";case'"':return"&quot;";default:return""}}),lo=/[>/="'\u0009\u000a\u000c\u0020]/,Ln=t=>lo.test(t),no=t=>t.some(e=>e[1].$captureRef$&&e[1].$captureRef$.length>0),so=(t,e)=>{const a=t.$dynamicSlots$||(t.$dynamicSlots$=[]);a.includes(e)||a.push(e)},js=t=>t==="on:qvisible"?"on-document:qinit":t,n=(t,e,a,l,r,i)=>{const c=i==null?null:String(i);return new Ge(t,e??ct,a,l,r,c)},J=(t,e,a,l,r,i)=>{let c=null;return e&&"children"in e&&(c=e.children,delete e.children),n(t,e,a,c,l,r)},o=(t,e,a,l,r)=>{const i=l==null?null:String(l),c=e??ct;if(typeof t=="string"&&s in c){const p={};for(const[g,$]of Object.entries(c[s]))p[g]=$===s?c[g]:$;return n(t,null,p,c.children,a,l)}const d=new Ge(t,c,null,c.children,a,i);return typeof t=="string"&&e&&delete e.children,d},Oh=(t,e,a)=>{const l=a==null?null:String(a),r=na(()=>{const c=e.children;return typeof t=="string"&&delete e.children,c});return Yt(t)&&"className"in e&&(e.class=e.className,delete e.className),new Ge(t,e,null,r,0,l)},ra=":skipRender";class Ge{constructor(e,a,l,r,i,c=null){this.type=e,this.props=a,this.immutableProps=l,this.children=r,this.flags=i,this.key=c}}const Ut=t=>t.children,pe=t=>t instanceof Ge,Q=t=>t.children,Qe="http://www.w3.org/2000/svg",ft=1,ia=2,oa=[],ua=(t,e,a,l)=>{e.$elm$;const r=a.$children$;if(r.length===1&&r[0].$type$===ra)return void(a.$children$=e.$children$);const i=e.$elm$;let c=da;e.$children$===oa&&i.nodeName==="HEAD"&&(c=uo,l|=ia);const d=ro(e,c);return d.length>0&&r.length>0?io(t,i,d,r,l):d.length>0&&r.length===0?vl(t.$static$,d,0,d.length-1):r.length>0?Os(t,i,null,r,0,r.length-1,l):void 0},ro=(t,e)=>{const a=t.$children$;return a===oa?t.$children$=Is(t.$elm$,e):a},io=(t,e,a,l,r)=>{let i=0,c=0,d=a.length-1,p=a[0],g=a[d],$=l.length-1,h=l[0],w=l[$],T,D,P;const S=[],b=t.$static$;for(;i<=d&&c<=$;)if(p==null)p=a[++i];else if(g==null)g=a[--d];else if(h==null)h=l[++c];else if(w==null)w=l[--$];else if(p.$id$===h.$id$)S.push(xe(t,p,h,r)),p=a[++i],h=l[++c];else if(g.$id$===w.$id$)S.push(xe(t,g,w,r)),g=a[--d],w=l[--$];else if(p.$key$&&p.$id$===w.$id$)p.$elm$,g.$elm$,S.push(xe(t,p,w,r)),Do(b,e,p.$elm$,g.$elm$),p=a[++i],w=l[--$];else if(g.$key$&&g.$id$===h.$id$)p.$elm$,g.$elm$,S.push(xe(t,g,h,r)),$e(b,e,g.$elm$,p.$elm$),g=a[--d],h=l[++c];else{if(T===void 0&&(T=_o(a,i,d)),D=T[h.$key$],D===void 0){const k=Me(t,h,r,S);$e(b,e,k,p==null?void 0:p.$elm$)}else if(P=a[D],P.$type$!==h.$type$){const k=Me(t,h,r,S);Y(k,_=>{$e(b,e,_,p==null?void 0:p.$elm$)})}else S.push(xe(t,P,h,r)),a[D]=void 0,P.$elm$,$e(b,e,P.$elm$,p.$elm$);h=l[++c]}c<=$&&S.push(Os(t,e,l[$+1]==null?null:l[$+1].$elm$,l,c,$,r));let j=el(S);return i<=d&&(j=Y(j,()=>{vl(b,a,i,d)})),j},ee=(t,e)=>{const a=Lt(t)?t.close:null,l=[];let r=t.firstChild;for(;(r=_l(r))&&(e(r)&&l.push(r),r=r.nextSibling,r!==a););return l},Is=(t,e)=>ee(t,e).map(oo),oo=t=>{var e;return Ft(t)?((e=bt(t))==null?void 0:e.$vdom$)??ca(t):ca(t)},ca=t=>{if(Vt(t)){const e=new jt(t.localName,{},null,oa,0,Ua(t));return e.$elm$=t,e}if(Ja(t)){const e=new jt(t.nodeName,ct,null,oa,0,null);return e.$text$=t.data,e.$elm$=t,e}},uo=t=>{const e=t.nodeType;return e===1?t.hasAttribute("q:head"):e===111},Wa=t=>t.nodeName==="Q:TEMPLATE",da=t=>{const e=t.nodeType;if(e===3||e===111)return!0;if(e!==1)return!1;const a=t.nodeName;return a!=="Q:TEMPLATE"&&(a==="HEAD"?t.hasAttribute("q:head"):a!=="STYLE"||!t.hasAttribute(ya))},Es=t=>{const e={};for(const a of t){const l=co(a);(e[l]??(e[l]=new jt(ie,{"q:s":""},null,[],0,l))).$children$.push(a)}return e},xe=(t,e,a,l)=>{e.$type$,a.$type$,e.$key$,a.$key$,e.$id$,a.$id$;const r=e.$elm$,i=a.$type$,c=t.$static$,d=c.$containerState$,p=t.$cmpCtx$;if(a.$elm$=r,i==="#text"){c.$visited$.push(r);const w=a.$signal$;return w&&(a.$text$=se(Et(w,[4,p.$element$,w,r]))),void Ot(c,r,"data",a.$text$)}const g=a.$props$,$=a.$flags$,h=vt(r,d);if(i!==ie){let w=(l&ft)!=0;if(w||i!=="svg"||(l|=ft,w=!0),g!==ct){!(1&$)&&(h.li.length=0);const T=e.$props$;a.$props$=T;for(const D in g){let P=g[D];if(D!=="ref")if(ta(D)){const S=ea(h.li,D,P,d.$containerEl$);qs(c,r,S)}else ht(P)&&(P=Et(P,[1,p.$element$,P,r,D])),D==="class"?P=cl(P,p):D==="style"&&(P=Sa(P)),T[D]!==P&&(T[D]=P,yl(c,r,D,P,w));else P!==void 0&&nl(P,r)}}return 2&$||(w&&i==="foreignObject"&&(l&=~ft),g[ot]!==void 0)||i==="textarea"?void 0:ua(t,e,a,l)}if("q:renderFn"in g){const w=g.props;bo(d,h,w);let T=!!(h.$flags$&re);return T||h.$componentQrl$||h.$element$.hasAttribute("q:id")||(rs(t,h),h.$componentQrl$=w["q:renderFn"],h.$componentQrl$,T=!0),T?Y(dl(t,h,l),()=>Mn(t,h,a,l)):Mn(t,h,a,l)}if("q:s"in g)return p.$slots$,void p.$slots$.push(a);if(ot in g)Ot(c,r,"innerHTML",g[ot]);else if(!(2&$))return ua(t,e,a,l)},Mn=(t,e,a,l)=>{if(2&a.$flags$)return;const r=t.$static$,i=Es(a.$children$),c=As(e);for(const d in c.slots)if(!i[d]){const p=c.slots[d],g=Is(p,da);if(g.length>0){const $=bt(p);$&&$.$vdom$&&($.$vdom$.$children$=[]),vl(r,g,0,g.length-1)}}for(const d in c.templates){const p=c.templates[d];p&&!i[d]&&(c.templates[d]=void 0,Gs(r,p))}return el(Object.keys(i).map(d=>{const p=i[d],g=Bs(r,c,e,d,t.$static$.$containerState$),$=pl(g),h=ze(t),w=g.$element$;h.$slotCtx$=g,g.$vdom$=p,p.$elm$=w;let T=l&~ft;w.isSvg&&(T|=ft);const D=r.$addSlots$.findIndex(P=>P[0]===w);return D>=0&&r.$addSlots$.splice(D,1),ua(h,$,p,T)}))},Os=(t,e,a,l,r,i,c)=>{const d=[];for(;r<=i;++r){const p=l[r],g=Me(t,p,c,d);$e(t.$static$,e,g,a)}return Ke(d)},vl=(t,e,a,l)=>{for(;a<=l;++a){const r=e[a];r&&(r.$elm$,Gs(t,r.$elm$))}},Bs=(t,e,a,l,r)=>{const i=e.slots[l];if(i)return vt(i,r);const c=e.templates[l];if(c)return vt(c,r);const d=Qs(t.$doc$,l),p=Pa(d);return p.$parentCtx$=a,Lo(t,a.$element$,d),e.templates[l]=d,p},co=t=>t.$props$[$t]??"",Me=(t,e,a,l)=>{const r=e.$type$,i=t.$static$.$doc$,c=t.$cmpCtx$;if(r==="#text"){const S=e.$signal$,b=i.createTextNode(e.$text$);return S&&(b.data=e.$text$=se(Et(S,4&a?[3,b,S,b]:[4,c.$element$,S,b]))),e.$elm$=b}let d,p=!!(a&ft);p||r!=="svg"||(a|=ft,p=!0);const g=r===ie,$=e.$props$,h=t.$static$,w=h.$containerState$;g?d=Oo(i,p):r==="head"?(d=i.head,a|=ia):(d=wl(i,r,p),a&=~ia),2&e.$flags$&&(a|=4),e.$elm$=d;const T=Pa(d);if(T.$parentCtx$=t.$slotCtx$??t.$cmpCtx$,g){if("q:renderFn"in $){const S=$["q:renderFn"],b=_a(),j=w.$subsManager$.$createManager$(),k=new Proxy(b,new es(w,j)),_=$.props;if(w.$proxyMap$.set(b,k),T.$props$=k,_!==ct){const E=b[s]=_[s]??ct;for(const L in _)if(L!=="children"&&L!==$t){const M=E[L];ht(M)?b["$$"+L]=M:b[L]=_[L]}}rs(t,T),T.$componentQrl$=S;const C=Y(dl(t,T,a),()=>{let E=e.$children$;if(E.length===0)return;E.length===1&&E[0].$type$===ra&&(E=E[0].$children$);const L=As(T),M=[],B=Es(E);for(const W in B){const ut=B[W],it=Bs(h,L,T,W,h.$containerState$),Ct=ze(t),Kt=it.$element$;Ct.$slotCtx$=it,it.$vdom$=ut,ut.$elm$=Kt;let gt=a&~ft;Kt.isSvg&&(gt|=ft);for(const nt of ut.$children$){const fe=Me(Ct,nt,gt,M);nt.$elm$,nt.$elm$,Rs(h,Kt,fe)}}return Ke(M)});return rt(C)&&l.push(C),d}if("q:s"in $)c.$slots$,Io(d,e.$key$),xt(d,"q:sref",c.$id$),xt(d,"q:s",""),c.$slots$.push(e),h.$addSlots$.push([d,c.$element$]);else if(ot in $)return Ot(h,d,"innerHTML",$[ot]),d}else{if(e.$immutableProps$&&jn(h,T,c,e.$immutableProps$,p,!0),$!==ct&&(T.$vdom$=e,e.$props$=jn(h,T,c,$,p,!1)),p&&r==="foreignObject"&&(p=!1,a&=~ft),c){const S=c.$scopeIds$;S&&S.forEach(b=>{d.classList.add(b)}),c.$flags$&Gt&&(T.li.push(...c.li),c.$flags$&=~Gt)}for(const S of T.li)qs(h,d,S[0]);if($[ot]!==void 0)return d;p&&r==="foreignObject"&&(p=!1,a&=~ft)}let D=e.$children$;if(D.length===0)return d;D.length===1&&D[0].$type$===ra&&(D=D[0].$children$);const P=D.map(S=>Me(t,S,a,l));for(const S of P)Ce(d,S);return d},po=t=>{const e=t.$slots$;return e||(t.$element$.parentElement,t.$slots$=go(t))},As=t=>{const e=po(t),a={},l={},r=Array.from(t.$element$.childNodes).filter(Wa);for(const i of e)i.$elm$,a[i.$key$??""]=i.$elm$;for(const i of r)l[Tt(i,$t)??""]=i;return{slots:a,templates:l}},go=t=>{const e=t.$element$.parentElement;return No(e,"q:sref",t.$id$).map(ca)},fo=(t,e,a)=>(Ot(t,e.style,"cssText",a),!0),xo=(t,e,a)=>(e.namespaceURI===Qe?je(t,e,"class",a):Ot(t,e,"className",a),!0),Cn=(t,e,a,l)=>(l in e&&e[l]!==a&&(e.tagName==="SELECT"?So(t,e,l,a):Ot(t,e,l,a)),!0),me=(t,e,a,l)=>(je(t,e,l.toLowerCase(),a),!0),mo=(t,e,a)=>(Ot(t,e,"innerHTML",a),!0),$o=()=>!0,ho={style:fo,class:xo,value:Cn,checked:Cn,href:me,list:me,form:me,tabIndex:me,download:me,innerHTML:$o,[ot]:mo},yl=(t,e,a,l,r)=>{if(is(a))return void je(t,e,a,l!=null?String(l):l);const i=ho[a];i&&i(t,e,l,a)||(r||!(a in e)?(a.startsWith(Na)&&Ns(a.slice(15)),je(t,e,a,l)):Ot(t,e,a,l))},jn=(t,e,a,l,r,i)=>{const c={},d=e.$element$;for(const p in l){let g=l[p];if(p!=="ref")if(ta(p))ea(e.li,p,g,t.$containerState$.$containerEl$);else{if(ht(g)&&(g=Et(g,i?[1,d,g,a.$element$,p]:[2,a.$element$,g,d,p])),p==="class"){if(g=cl(g,a),!g)continue}else p==="style"&&(g=Sa(g));c[p]=g,yl(t,d,p,g,r)}else g!==void 0&&nl(g,d)}return c},bo=(t,e,a)=>{let l=e.$props$;if(l||(e.$props$=l=Ne(_a(),t)),a===ct)return;const r=dt(l),i=Jt(l),c=i[s]=a[s]??ct;for(const d in a)if(d!=="children"&&d!==$t&&!c[d]){const p=a[d];i[d]!==p&&(i[d]=p,r.$notifySubs$(d))}},ye=(t,e,a,l)=>{if(a.$clearSub$(t),Vt(t)){if(l&&t.hasAttribute("q:s"))return void e.$rmSlots$.push(t);const r=bt(t);r&&Oi(r,a);const i=Lt(t)?t.close:null;let c=t.firstChild;for(;(c=_l(c))&&(ye(c,e,a,!0),c=c.nextSibling,c!==i););}},vo=async t=>{jo(t)},Ce=(t,e)=>{Lt(e)?e.appendTo(t):t.appendChild(e)},yo=(t,e)=>{Lt(e)?e.remove():t.removeChild(e)},wo=(t,e,a)=>{Lt(e)?e.insertBeforeTo(t,(a==null?void 0:a.nextSibling)??null):t.insertBefore(e,(a==null?void 0:a.nextSibling)??null)},ka=(t,e,a)=>{Lt(e)?e.insertBeforeTo(t,pa(a)):t.insertBefore(e,pa(a))},_o=(t,e,a)=>{const l={};for(let r=e;r<=a;++r){const i=t[r].$key$;i!=null&&(l[i]=r)}return l},qs=(t,e,a)=>{a.startsWith("on:")||je(t,e,a,""),Ns(a)},Ns=t=>{var e;{const a=Xn(t);try{((e=globalThis).qwikevents||(e.qwikevents=[])).push(a)}catch{}}},je=(t,e,a,l)=>{t.$operations$.push({$operation$:To,$args$:[e,a,l]})},To=(t,e,a)=>{if(a==null||a===!1)t.removeAttribute(e);else{const l=a===!0?"":String(a);xt(t,e,l)}},Ot=(t,e,a,l)=>{t.$operations$.push({$operation$:zs,$args$:[e,a,l]})},So=(t,e,a,l)=>{t.$postOperations$.push({$operation$:zs,$args$:[e,a,l]})},zs=(t,e,a)=>{try{t[e]=a??"",a==null&&Qt(t)&&Ft(t)&&t.removeAttribute(e)}catch(l){_e(ha(6),{node:t,key:e,value:a},l)}},wl=(t,e,a)=>a?t.createElementNS(Qe,e):t.createElement(e),$e=(t,e,a,l)=>(t.$operations$.push({$operation$:ka,$args$:[e,a,l||null]}),a),Do=(t,e,a,l)=>(t.$operations$.push({$operation$:wo,$args$:[e,a,l||null]}),a),Rs=(t,e,a)=>(t.$operations$.push({$operation$:Ce,$args$:[e,a]}),a),Po=(t,e)=>{t.$containerState$.$styleIds$.add(e.styleId),t.$postOperations$.push({$operation$:ko,$args$:[t.$containerState$,e]})},ko=(t,e)=>{const a=t.$containerEl$,l=Ae(a),r=l.documentElement===a,i=l.head,c=l.createElement("style");xt(c,ya,e.styleId),xt(c,"hidden",""),c.textContent=e.content,r&&i?Ce(i,c):ka(a,c,a.firstChild)},Lo=(t,e,a)=>{t.$operations$.push({$operation$:Mo,$args$:[e,a]})},Mo=(t,e)=>{ka(t,e,t.firstChild)},Gs=(t,e)=>{Vt(e)&&ye(e,t,t.$containerState$.$subsManager$,!0),t.$operations$.push({$operation$:Co,$args$:[e,t]})},Co=t=>{const e=t.parentElement;e&&yo(e,t)},Qs=(t,e)=>{const a=wl(t,"q:template",!1);return xt(a,$t,e),xt(a,"hidden",""),xt(a,"aria-hidden","true"),a},jo=t=>{for(const e of t.$operations$)e.$operation$.apply(void 0,e.$args$);Eo(t)},Ua=t=>Tt(t,"q:key"),Io=(t,e)=>{e!==null&&xt(t,"q:key",e)},Eo=t=>{const e=t.$containerState$.$subsManager$;for(const a of t.$rmSlots$){const l=Ua(a),r=ee(a,da);if(r.length>0){const i=a.getAttribute("q:sref"),c=t.$roots$.find(d=>d.$id$===i);if(c){const d=c.$element$;if(d.isConnected)if(ee(d,Wa).some(p=>Tt(p,$t)===l))ye(a,t,e,!1);else{const p=Qs(t.$doc$,l);for(const g of r)Ce(p,g);ka(d,p,d.firstChild)}else ye(a,t,e,!1)}else ye(a,t,e,!1)}}for(const[a,l]of t.$addSlots$){const r=Ua(a),i=ee(l,Wa).find(c=>c.getAttribute($t)===r);i&&(ee(i,da).forEach(c=>{Ce(a,c)}),i.remove())}},In=()=>{},Oo=(t,e)=>{const a=t.createComment("qv "),l=t.createComment("/qv");return new Fs(a,l,e)},Bo=t=>{if(!t)return{};const e=t.split(" ");return Object.fromEntries(e.map(a=>{const l=a.indexOf("=");return l>=0?[a.slice(0,l),Ro(a.slice(l+1))]:[a,""]}))},Ao=t=>{const e=[];return Object.entries(t).forEach(([a,l])=>{e.push(l?`${a}=${zo(l)}`:`${a}`)}),e.join(" ")},qo=(t,e,a)=>t.ownerDocument.createTreeWalker(t,128,{acceptNode(l){const r=Fe(l);return r&&Tt(r,e)===a?1:2}}),No=(t,e,a)=>{const l=qo(t,e,a),r=[];let i=null;for(;i=l.nextNode();)r.push(Fe(i));return r},zo=t=>t.replace(/ /g,"+"),Ro=t=>t.replace(/\+/g," "),ie=":virtual";class Fs{constructor(e,a,l){this.open=e,this.close=a,this.isSvg=l,this._qc_=null,this.nodeType=111,this.localName=ie,this.nodeName=ie;const r=this.ownerDocument=e.ownerDocument;this.$template$=wl(r,"template",!1),this.$attributes$=Bo(e.data.slice(3)),e.data.startsWith("qv "),e.__virtual=this,a.__virtual=this}insertBefore(e,a){const l=this.parentElement;return l?l.insertBefore(e,a||this.close):this.$template$.insertBefore(e,a),e}remove(){const e=this.parentElement;if(e){const a=this.childNodes;this.$template$.childElementCount,e.removeChild(this.open);for(let l=0;l<a.length;l++)this.$template$.appendChild(a[l]);e.removeChild(this.close)}}appendChild(e){return this.insertBefore(e,null)}insertBeforeTo(e,a){const l=this.childNodes;e.insertBefore(this.open,a);for(const r of l)e.insertBefore(r,a);e.insertBefore(this.close,a),this.$template$.childElementCount}appendTo(e){this.insertBeforeTo(e,null)}get namespaceURI(){var e;return((e=this.parentElement)==null?void 0:e.namespaceURI)??""}removeChild(e){this.parentElement?this.parentElement.removeChild(e):this.$template$.removeChild(e)}getAttribute(e){return this.$attributes$[e]??null}hasAttribute(e){return e in this.$attributes$}setAttribute(e,a){this.$attributes$[e]=a,this.open.data=En(this.$attributes$)}removeAttribute(e){delete this.$attributes$[e],this.open.data=En(this.$attributes$)}matches(e){return!1}compareDocumentPosition(e){return this.open.compareDocumentPosition(e)}closest(e){const a=this.parentElement;return a?a.closest(e):null}querySelectorAll(e){const a=[];return ee(this,qr).forEach(l=>{Vt(l)&&(l.matches(e)&&a.push(l),a.concat(Array.from(l.querySelectorAll(e))))}),a}querySelector(e){for(const a of this.childNodes)if(Ft(a)){if(a.matches(e))return a;const l=a.querySelector(e);if(l!==null)return l}return null}get innerHTML(){return""}set innerHTML(e){const a=this.parentElement;a?(this.childNodes.forEach(l=>this.removeChild(l)),this.$template$.innerHTML=e,a.insertBefore(this.$template$.content,this.close)):this.$template$.innerHTML=e}get firstChild(){if(this.parentElement){const e=this.open.nextSibling;return e===this.close?null:e}return this.$template$.firstChild}get nextSibling(){return this.close.nextSibling}get previousSibling(){return this.open.previousSibling}get childNodes(){if(!this.parentElement)return Array.from(this.$template$.childNodes);const e=[];let a=this.open;for(;(a=a.nextSibling)&&a!==this.close;)e.push(a);return e}get isConnected(){return this.open.isConnected}get parentElement(){return this.open.parentElement}}const En=t=>`qv ${Ao(t)}`,_l=t=>{if(t==null)return null;if(Oe(t)){const e=Fe(t);if(e)return e}return t},Go=t=>{let e=t,a=1;for(;e=e.nextSibling;)if(Oe(e)){const l=e.__virtual;if(l)e=l;else if(e.data.startsWith("qv "))a++;else if(e.data==="/qv"&&(a--,a===0))return e}},Fe=t=>{var a;const e=t.__virtual;if(e)return e;if(t.data.startsWith("qv ")){const l=Go(t);return new Fs(t,l,((a=t.parentElement)==null?void 0:a.namespaceURI)===Qe)}return null},pa=t=>t==null?null:Lt(t)?t.open:t,Bh=async t=>{const e={},a=Hs(e);let l;for(V(t,a,!1);(l=a.$promises$).length>0;)a.$promises$=[],await Promise.all(l);const r=Array.from(a.$objSet$.keys());let i=0;const c=new Map;for(const g of r)c.set(g,Rt(i)),i++;if(a.$noSerialize$.length>0){const g=c.get(void 0);for(const $ of a.$noSerialize$)c.set($,g)}const d=g=>{let $="";if(rt(g)){const w=Ws(g);if(!w)throw lt(27,g);g=w.value,$+=w.resolved?"~":"_"}if(Mt(g)){const w=Jt(g);w&&($+="!",g=w)}const h=c.get(g);if(h===void 0)throw lt(27,g);return h+$},p=Vs(r,d,null,a,e);return JSON.stringify({_entry:d(t),_objs:p})},Qo=async(t,e)=>{const a=Ae(t),l=a.documentElement,r=Yn(t)?l:t;if(Tt(r,"q:container")==="paused")throw lt(21);const i=e??(r===a.documentElement?a.body:r),c=ce(r),d=Ho(r,Xo);xt(r,"q:container","paused");for(const w of d){const T=w.$element$,D=w.li;if(w.$scopeIds$){const P=Ts(w.$scopeIds$);P&&T.setAttribute("q:sstyle",P)}if(w.$id$&&T.setAttribute("q:id",w.$id$),Ft(T)&&D.length>0){const P=ll(D);for(const S of P)T.setAttribute(S[0],Dl(S[1],w))}}const p=await Fo(d,c,w=>Qt(w)&&Ja(w)?eu(w,c):null),g=a.createElement("script");xt(g,"type","qwik/json"),g.textContent=Yo(JSON.stringify(p.state,void 0,void 0)),i.appendChild(g);const $=Array.from(c.$events$,w=>JSON.stringify(w)),h=a.createElement("script");return h.textContent=`window.qwikevents||=[];window.qwikevents.push(${$.join(", ")})`,i.appendChild(h),p},Fo=async(t,e,a,l)=>{var k;const r=Hs(e);l==null||l.forEach((_,C)=>{r.$seen$.add(C)});let i=!1;for(const _ of t)if(_.$tasks$)for(const C of _.$tasks$)bs(C)&&r.$resources$.push(C.$state$),ys(C);for(const _ of t){const C=_.$element$,E=_.li;for(const L of E)if(Ft(C)){const M=L[1],B=M.$captureRef$;if(B)for(const W of B)V(W,r,!0);r.$qrls$.push(M),i=!0}}if(!i)return{state:{refs:{},ctx:{},objs:[],subs:[]},objs:[],funcs:[],qrls:[],resources:r.$resources$,mode:"static"};let c;for(;(c=r.$promises$).length>0;)r.$promises$=[],await Promise.all(c);const d=r.$elements$.length>0;if(d){for(const _ of r.$deferElements$)Tl(_,r,_.$element$);for(const _ of t)Wo(_,r)}for(;(c=r.$promises$).length>0;)r.$promises$=[],await Promise.all(c);const p=new Map,g=Array.from(r.$objSet$.keys()),$=new Map,h=_=>{let C="";if(rt(_)){const M=Ws(_);if(!M)return null;_=M.value,C+=M.resolved?"~":"_"}if(Mt(_)){const M=Jt(_);if(M)C+="!",_=M;else if(Vt(_)){const B=(W=>{let ut=p.get(W);return ut===void 0&&(ut=tu(W),ut||console.warn("Missing ID",W),p.set(W,ut)),ut})(_);return B?"#"+B+C:null}}const E=$.get(_);if(E)return E+C;const L=l==null?void 0:l.get(_);return L?"*"+L:a?a(_):null},w=_=>{const C=h(_);if(C===null){if(ar(_)){const E=Rt($.size);return $.set(_,E),E}throw lt(27,_)}return C},T=new Map;for(const _ of g){const C=(k=Ko(_,e))==null?void 0:k.$subs$;if(!C)continue;const E=er(_)??0,L=[];1&E&&L.push(E);for(const M of C){const B=M[1];M[0]===0&&Qt(B)&&Lt(B)&&!r.$elements$.includes(bt(B))||L.push(M)}L.length>0&&T.set(_,L)}g.sort((_,C)=>(T.has(_)?0:1)-(T.has(C)?0:1));let D=0;for(const _ of g)$.set(_,Rt(D)),D++;if(r.$noSerialize$.length>0){const _=$.get(void 0);for(const C of r.$noSerialize$)$.set(C,_)}const P=[];for(const _ of g){const C=T.get(_);if(C==null)break;P.push(C.map(E=>typeof E=="number"?`_${E}`:Bu(E,h)).filter(Zn))}P.length,T.size;const S=Vs(g,w,h,r,e),b={},j={};for(const _ of t){const C=_.$element$,E=_.$id$,L=_.$refMap$,M=_.$props$,B=_.$contexts$,W=_.$tasks$,ut=_.$componentQrl$,it=_.$seq$,Ct={},Kt=Lt(C)&&r.$elements$.includes(_);if(L.length>0){const gt=Ht(L,w," ");gt&&(j[E]=gt)}else if(d){let gt=!1;if(Kt){const nt=h(M);Ct.h=w(ut)+(nt?" "+nt:""),gt=!0}else{const nt=h(M);nt&&(Ct.h=" "+nt,gt=!0)}if(W&&W.length>0){const nt=Ht(W,h," ");nt&&(Ct.w=nt,gt=!0)}if(Kt&&it&&it.length>0){const nt=Ht(it,w," ");Ct.s=nt,gt=!0}if(B){const nt=[];B.forEach((Er,Or)=>{const bn=h(Er);bn&&nt.push(`${Or}=${bn}`)});const fe=nt.join(" ");fe&&(Ct.c=fe,gt=!0)}gt&&(b[E]=Ct)}}return{state:{refs:j,ctx:b,objs:S,subs:P},objs:g,funcs:r.$inlinedFunctions$,resources:r.$resources$,qrls:r.$qrls$,mode:d?"render":"listeners"}},Ht=(t,e,a)=>{let l="";for(const r of t){const i=e(r);i!==null&&(l!==""&&(l+=a),l+=i)}return l},Ho=(t,e)=>{const a=[],l=e(t);l!==void 0&&a.push(l);const r=t.ownerDocument.createTreeWalker(t,129,{acceptNode(i){if(Jo(i))return 2;const c=e(i);return c!==void 0&&a.push(c),3}});for(;r.nextNode(););return a},Wo=(t,e)=>{var r;const a=t.$parentCtx$,l=t.$props$;if(a&&l&&!Us(l)&&e.$elements$.includes(a)){const i=(r=dt(l))==null?void 0:r.$subs$,c=t.$element$;if(i)for(const[d,p]of i)d===0?(p!==c&&oe(dt(l),e,!1),Qt(p)?Vo(p,e):V(p,e,!0)):(V(l,e,!1),oe(dt(l),e,!1))}},Hs=t=>({$containerState$:t,$seen$:new Set,$objSet$:new Set,$prefetch$:0,$noSerialize$:[],$inlinedFunctions$:[],$resources$:[],$elements$:[],$qrls$:[],$deferElements$:[],$promises$:[]}),Uo=(t,e)=>{const a=bt(t);e.$elements$.includes(a)||(e.$elements$.push(a),e.$prefetch$++,8&a.$flags$?Tl(a,e,!0):e.$deferElements$.push(a),e.$prefetch$--)},Vo=(t,e)=>{const a=bt(t);if(a){if(e.$elements$.includes(a))return;e.$elements$.push(a),Tl(a,e,t)}},Tl=(t,e,a)=>{if(t.$props$&&!Us(t.$props$)&&(V(t.$props$,e,a),oe(dt(t.$props$),e,a)),t.$componentQrl$&&V(t.$componentQrl$,e,a),t.$seq$)for(const l of t.$seq$)V(l,e,a);if(t.$tasks$){const l=e.$containerState$.$subsManager$.$groupToManagers$;for(const r of t.$tasks$)l.has(r)&&V(r,e,a)}if(a===!0&&(On(t,e),t.$dynamicSlots$))for(const l of t.$dynamicSlots$)On(l,e)},On=(t,e)=>{for(;t;){if(t.$contexts$)for(const a of t.$contexts$.values())V(a,e,!0);t=t.$parentCtx$}},Yo=t=>t.replace(/<(\/?script)/g,"\\x3C$1"),oe=(t,e,a)=>{if(e.$seen$.has(t))return;e.$seen$.add(t);const l=t.$subs$;for(const r of l){const i=r[0];if(i>0&&V(r[2],e,a),a===!0){const c=r[1];Qt(c)&&Lt(c)?i===0&&Uo(c,e):V(c,e,!0)}}},Va=Symbol(),Zo=t=>t.then(e=>(t[Va]={resolved:!0,value:e},e),e=>(t[Va]={resolved:!1,value:e},e)),Ws=t=>t[Va],V=(t,e,a)=>{if(t!==null){const l=typeof t;switch(l){case"function":case"object":{const r=e.$seen$;if(r.has(t))return;if(r.add(t),Ks(t))return e.$objSet$.add(void 0),void e.$noSerialize$.push(t);const i=t,c=Jt(t);if(c){const d=(2&er(t=c))==0;if(a&&d&&oe(dt(i),e,a),tr(i))return void e.$objSet$.add(t)}if(Lu(t,e,a))return void e.$objSet$.add(t);if(rt(t))return void e.$promises$.push(Zo(t).then(d=>{V(d,e,a)}));if(l==="object"){if(Qt(t))return;if(tt(t))for(let d=0;d<t.length;d++)V(i[d],e,a);else if(Be(t))for(const d in t)V(i[d],e,a)}break}case"string":if(e.$seen$.has(t))return}}e.$objSet$.add(t)},Jo=t=>Ft(t)&&t.hasAttribute("q:container"),Xo=t=>{const e=_l(t);if(Vt(e)){const a=bt(e);if(a&&a.$id$)return a}},Ko=(t,e)=>{if(!Mt(t))return;if(t instanceof De)return dt(t);const a=e.$proxyMap$.get(t);return a?dt(a):void 0},tu=t=>{const e=bt(t);return e?e.$id$:null},eu=(t,e)=>{const a=t.previousSibling;if(a&&Oe(a)&&a.data.startsWith("t="))return"#"+a.data.slice(2);const l=t.ownerDocument,r=Rt(e.$elementIndex$++),i=l.createComment(`t=${r}`),c=l.createComment(""),d=t.parentElement;return d.insertBefore(i,t),d.insertBefore(c,t.nextSibling),"#"+r},Us=t=>Object.keys(t).length===0;function Vs(t,e,a,l,r){return t.map(i=>{if(i===null)return null;const c=typeof i;switch(c){case"undefined":return Ma;case"number":if(!Number.isFinite(i))break;return i;case"string":if(i.charCodeAt(0)<32)break;return i;case"boolean":return i}const d=Mu(i,e,l,r);if(d!==void 0)return d;if(c==="object"){if(tt(i))return i.map(e);if(Be(i)){const p={};for(const g in i)if(a){const $=a(i[g]);$!==null&&(p[g]=$)}else p[g]=e(i[g]);return p}}throw lt(3,i)})}const x=(t,e,a=Dt)=>Ia(null,e,t,null,null,a,null),F=(t,e=Dt)=>Ia(null,t,null,null,null,e,null),Sl=(t,e={})=>{let a=t.$symbol$,l=t.$chunk$;const r=t.$refSymbol$??a,i=ba();if(i){const g=i.chunkForSymbol(r,l);g&&(l=g[1],t.$refSymbol$||(a=g[0]))}if(!l)throw lt(31,t.$symbol$);l.startsWith("./")&&(l=l.slice(2));let c=`${l}#${a}`;const d=t.$capture$,p=t.$captureRef$;return p&&p.length?e.$getObjId$?c+=`[${Ht(p,e.$getObjId$," ")}]`:e.$addRefMap$&&(c+=`[${Ht(p,e.$addRefMap$," ")}]`):d&&d.length>0&&(c+=`[${d.join(" ")}]`),c},Dl=(t,e)=>{e.$element$;const a={$addRefMap$:l=>au(e.$refMap$,l)};return Ht(t,l=>Sl(l,a),`
`)},La=(t,e)=>{const a=t.length,l=Bn(t,0,"#"),r=Bn(t,l,"["),i=Math.min(l,r),c=t.substring(0,i),d=l==a?l:l+1,p=d==r?"default":t.substring(d,r),g=r===a?Dt:t.substring(r+1,a-1).split(" "),$=Ia(c,p,null,null,g,null,null);return e&&$.$setContainer$(e),$},Bn=(t,e,a)=>{const l=t.length,r=t.indexOf(a,e==l?0:e);return r==-1?l:r},au=(t,e)=>{const a=t.indexOf(e);return a===-1?(t.push(e),String(t.length-1)):String(a)},Ys=(t,e)=>(t.$capture$,t.$captureRef$=t.$capture$.map(a=>{const l=parseInt(a,10),r=e.$refMap$[l];return e.$refMap$.length>l,r})),Ah=(t,e)=>(globalThis.__qwik_reg_symbols===void 0&&(globalThis.__qwik_reg_symbols=new Map),globalThis.__qwik_reg_symbols.set(e,t),t),lu=t=>({__brand:"resource",value:void 0,loading:!It(),_resolved:void 0,_error:void 0,_state:"pending",_timeout:(t==null?void 0:t.timeout)??-1,_cache:0}),nu=t=>Mt(t)&&t.__brand==="resource",su=(t,e)=>{const a=t._state;return a==="resolved"?`0 ${e(t._resolved)}`:a==="pending"?"1":`2 ${e(t._error)}`},ru=t=>{const[e,a]=t.split(" "),l=lu(void 0);return l.value=Promise.resolve(),e==="0"?(l._state="resolved",l._resolved=a,l.loading=!1):e==="1"?(l._state="pending",l.value=new Promise(()=>{}),l.loading=!0):e==="2"&&(l._state="rejected",l._error=a,l.loading=!1),l},st=t=>o(Ut,{"q:s":""},0,t.name??""),Ma="";function at(t){return{$prefixCode$:t.$prefix$.charCodeAt(0),$prefixChar$:t.$prefix$,$test$:t.$test$,$serialize$:t.$serialize$,$prepare$:t.$prepare$,$fill$:t.$fill$,$collect$:t.$collect$,$subs$:t.$subs$}}const iu=at({$prefix$:"",$test$:t=>ar(t),$collect$:(t,e,a)=>{if(t.$captureRef$)for(const l of t.$captureRef$)V(l,e,a);e.$prefetch$===0&&e.$qrls$.push(t)},$serialize$:(t,e)=>Sl(t,{$getObjId$:e}),$prepare$:(t,e)=>La(t,e.$containerEl$),$fill$:(t,e)=>{t.$capture$&&t.$capture$.length>0&&(t.$captureRef$=t.$capture$.map(e),t.$capture$=null)}}),ou=at({$prefix$:"",$test$:t=>xl(t),$collect$:(t,e,a)=>{V(t.$qrl$,e,a),t.$state$&&(V(t.$state$,e,a),a===!0&&t.$state$ instanceof De&&oe(t.$state$[Pt],e,!0))},$serialize$:(t,e)=>Mi(t,e),$prepare$:t=>Ci(t),$fill$:(t,e)=>{t.$el$=e(t.$el$),t.$qrl$=e(t.$qrl$),t.$state$&&(t.$state$=e(t.$state$))}}),uu=at({$prefix$:"",$test$:t=>nu(t),$collect$:(t,e,a)=>{V(t.value,e,a),V(t._resolved,e,a)},$serialize$:(t,e)=>su(t,e),$prepare$:t=>ru(t),$fill$:(t,e)=>{if(t._state==="resolved")t._resolved=e(t._resolved),t.value=Promise.resolve(t._resolved);else if(t._state==="rejected"){const a=Promise.reject(t._error);a.catch(()=>null),t._error=e(t._error),t.value=a}}}),cu=at({$prefix$:"",$test$:t=>t instanceof URL,$serialize$:t=>t.href,$prepare$:t=>new URL(t),$fill$:void 0}),du=at({$prefix$:"",$test$:t=>t instanceof Date,$serialize$:t=>t.toISOString(),$prepare$:t=>new Date(t),$fill$:void 0}),pu=at({$prefix$:"\x07",$test$:t=>t instanceof RegExp,$serialize$:t=>`${t.flags} ${t.source}`,$prepare$:t=>{const e=t.indexOf(" "),a=t.slice(e+1),l=t.slice(0,e);return new RegExp(a,l)},$fill$:void 0}),gu=at({$prefix$:"",$test$:t=>t instanceof Error,$serialize$:t=>t.message,$prepare$:t=>{const e=new Error(t);return e.stack=void 0,e},$fill$:void 0}),fu=at({$prefix$:"",$test$:t=>Yn(t),$serialize$:void 0,$prepare$:(t,e,a)=>a,$fill$:void 0}),ga=Symbol("serializable-data"),xu=at({$prefix$:"",$test$:t=>nr(t),$serialize$:(t,e)=>{const[a]=t[ga];return Sl(a,{$getObjId$:e})},$prepare$:(t,e)=>{const a=La(t,e.$containerEl$);return m(a)},$fill$:(t,e)=>{const[a]=t[ga];a.$capture$&&a.$capture$.length>0&&(a.$captureRef$=a.$capture$.map(e),a.$capture$=null)}}),mu=at({$prefix$:"",$test$:t=>t instanceof Ra,$collect$:(t,e,a)=>{if(t.$args$)for(const l of t.$args$)V(l,e,a)},$serialize$:(t,e,a)=>{const l=Xr(t);let r=a.$inlinedFunctions$.indexOf(l);return r<0&&(a.$inlinedFunctions$.push(l),r=a.$inlinedFunctions$.length-1),Ht(t.$args$,e," ")+" @"+Rt(r)},$prepare$:t=>{const e=t.split(" "),a=e.slice(0,-1),l=e[e.length-1];return new Ra(l,a,l)},$fill$:(t,e)=>{t.$func$,t.$func$=e(t.$func$),t.$args$=t.$args$.map(e)}}),$u=at({$prefix$:"",$test$:t=>t instanceof De,$collect$:(t,e,a)=>(V(t.untrackedValue,e,a),a===!0&&!(1&t[Se])&&oe(t[Pt],e,!0),t),$serialize$:(t,e)=>e(t.untrackedValue),$prepare$:(t,e)=>{var a;return new De(t,(a=e==null?void 0:e.$subsManager$)==null?void 0:a.$createManager$(),0)},$subs$:(t,e)=>{t[Pt].$addSubs$(e)},$fill$:(t,e)=>{t.untrackedValue=e(t.untrackedValue)}}),hu=at({$prefix$:"",$test$:t=>t instanceof Ga,$collect$(t,e,a){if(V(t.ref,e,a),tr(t.ref)){const l=dt(t.ref);ju(e.$containerState$.$subsManager$,l,a)&&V(t.ref[t.prop],e,a)}return t},$serialize$:(t,e)=>`${e(t.ref)} ${t.prop}`,$prepare$:t=>{const[e,a]=t.split(" ");return new Ga(e,a)},$fill$:(t,e)=>{t.ref=e(t.ref)}}),bu=at({$prefix$:"",$test$:t=>typeof t=="number",$serialize$:t=>String(t),$prepare$:t=>Number(t),$fill$:void 0}),vu=at({$prefix$:"",$test$:t=>t instanceof URLSearchParams,$serialize$:t=>t.toString(),$prepare$:t=>new URLSearchParams(t),$fill$:void 0}),yu=at({$prefix$:"",$test$:t=>typeof FormData<"u"&&t instanceof globalThis.FormData,$serialize$:t=>{const e=[];return t.forEach((a,l)=>{e.push(typeof a=="string"?[l,a]:[l,a.name])}),JSON.stringify(e)},$prepare$:t=>{const e=JSON.parse(t),a=new FormData;for(const[l,r]of e)a.append(l,r);return a},$fill$:void 0}),wu=at({$prefix$:"",$test$:t=>pe(t),$collect$:(t,e,a)=>{V(t.children,e,a),V(t.props,e,a),V(t.immutableProps,e,a);let l=t.type;l===st?l=":slot":l===Q&&(l=":fragment"),V(l,e,a)},$serialize$:(t,e)=>{let a=t.type;return a===st?a=":slot":a===Q&&(a=":fragment"),`${e(a)} ${e(t.props)} ${e(t.immutableProps)} ${e(t.children)} ${t.flags}`},$prepare$:t=>{const[e,a,l,r,i]=t.split(" ");return new Ge(e,a,l,r,parseInt(i,10))},$fill$:(t,e)=>{t.type=Iu(e(t.type)),t.props=e(t.props),t.immutableProps=e(t.immutableProps),t.children=e(t.children)}}),_u=at({$prefix$:"",$test$:t=>typeof t=="bigint",$serialize$:t=>t.toString(),$prepare$:t=>BigInt(t),$fill$:void 0}),le=Symbol(),Tu=at({$prefix$:"",$test$:t=>t instanceof Set,$collect$:(t,e,a)=>{t.forEach(l=>V(l,e,a))},$serialize$:(t,e)=>Array.from(t).map(e).join(" "),$prepare$:t=>{const e=new Set;return e[le]=t,e},$fill$:(t,e)=>{const a=t[le];t[le]=void 0;const l=a.length===0?[]:a.split(" ");for(const r of l)t.add(e(r))}}),Su=at({$prefix$:"",$test$:t=>t instanceof Map,$collect$:(t,e,a)=>{t.forEach((l,r)=>{V(l,e,a),V(r,e,a)})},$serialize$:(t,e)=>{const a=[];return t.forEach((l,r)=>{a.push(e(r)+" "+e(l))}),a.join(" ")},$prepare$:t=>{const e=new Map;return e[le]=t,e},$fill$:(t,e)=>{const a=t[le];t[le]=void 0;const l=a.length===0?[]:a.split(" ");l.length%2;for(let r=0;r<l.length;r+=2)t.set(e(l[r]),e(l[r+1]))}}),Du=at({$prefix$:"\x1B",$test$:t=>!!Zs(t)||t===Ma,$serialize$:t=>t,$prepare$:t=>t,$fill$:void 0}),Ca=[iu,ou,uu,cu,du,pu,gu,fu,xu,mu,$u,hu,bu,vu,yu,wu,_u,Tu,Su,Du],An=(()=>{const t=[];return Ca.forEach(e=>{const a=e.$prefixCode$;for(;t.length<a;)t.push(void 0);t.push(e)}),t})();function Zs(t){if(typeof t=="string"){const e=t.charCodeAt(0);if(e<An.length)return An[e]}}const Pu=Ca.filter(t=>t.$collect$),ku=t=>{for(const e of Ca)if(e.$test$(t))return!0;return!1},Lu=(t,e,a)=>{for(const l of Pu)if(l.$test$(t))return l.$collect$(t,e,a),!0;return!1},Mu=(t,e,a,l)=>{for(const r of Ca)if(r.$test$(t)){let i=r.$prefixChar$;return r.$serialize$&&(i+=r.$serialize$(t,e,a,l)),i}if(typeof t=="string")return t},Js=(t,e)=>{const a=new Map,l=new Map;return{prepare(r){const i=Zs(r);if(i){const c=i.$prepare$(r.slice(1),t,e);return i.$fill$&&a.set(c,i),i.$subs$&&l.set(c,i),c}return r},subs(r,i){const c=l.get(r);return!!c&&(c.$subs$(r,i,t),!0)},fill(r,i){const c=a.get(r);return!!c&&(c.$fill$(r,i,t),!0)}}},Cu={"!":(t,e)=>e.$proxyMap$.get(t)??il(t,e),"~":t=>Promise.resolve(t),_:t=>Promise.reject(t)},ju=(t,e,a)=>{if(typeof a=="boolean")return a;const l=t.$groupToManagers$.get(a);return!!(l&&l.length>0)&&(l.length!==1||l[0]!==e)},Iu=t=>t===":slot"?st:t===":fragment"?Q:t,qh=(t,e)=>Ya(t,new Set,"_",e),Ya=(t,e,a,l)=>{const r=He(t);if(r==null)return t;if(Eu(r)){if(e.has(r)||(e.add(r),ku(r)))return t;const i=typeof r;switch(i){case"object":if(rt(r)||Qt(r))return t;if(tt(r)){let d=0;return r.forEach((p,g)=>{if(g!==d)throw lt(3,r);Ya(p,e,a+"["+g+"]"),d=g+1}),t}if(Be(r)){for(const[d,p]of Object.entries(r))Ya(p,e,a+"."+d);return t}break;case"boolean":case"string":case"number":return t}let c="";if(c=l||"Value cannot be serialized",a!=="_"&&(c+=` in ${a},`),i==="object")c+=` because it's an instance of "${t==null?void 0:t.constructor.name}". You might need to use 'noSerialize()' or use an object literal instead. Check out https://qwik.builder.io/docs/advanced/dollar/`;else if(i==="function"){const d=t.name;c+=` because it's a function named "${d}". You might need to convert it to a QRL using $(fn):

const ${d} = $(${String(t)});

Please check out https://qwik.builder.io/docs/advanced/qrl/ for more information.`}console.error("Trying to serialize",t),Nr(c)}return t},Pl=new WeakSet,Xs=new WeakSet,Eu=t=>!Mt(t)&&!mt(t)||!Pl.has(t),Ks=t=>Pl.has(t),tr=t=>Xs.has(t),ja=t=>(t!=null&&Pl.add(t),t),Ou=t=>(Xs.add(t),t),He=t=>Mt(t)?Jt(t)??t:t,Jt=t=>t[qa],dt=t=>t[Pt],er=t=>t[te],Bu=(t,e)=>{const a=t[0],l=typeof t[1]=="string"?t[1]:e(t[1]);if(!l)return;let r=a+" "+l,i;if(a===0)i=t[2];else{const c=e(t[2]);if(!c)return;a<=2?(i=t[5],r+=` ${c} ${qn(e(t[3]))} ${t[4]}`):a<=4&&(i=t[4],r+=` ${c} ${typeof t[3]=="string"?t[3]:qn(e(t[3]))}`)}return i&&(r+=` ${encodeURI(i)}`),r},Au=(t,e)=>{const a=t.split(" "),l=parseInt(a[0],10);a.length>=2;const r=e(a[1]);if(!r||xl(r)&&!r.$el$)return;const i=[l,r];return l===0?(a.length<=3,i.push(Aa(a[2]))):l<=2?(a.length===5||a.length,i.push(e(a[2]),e(a[3]),a[4],Aa(a[5]))):l<=4&&(a.length===4||a.length,i.push(e(a[2]),e(a[3]),Aa(a[4]))),i},Aa=t=>{if(t!==void 0)return decodeURI(t)},qu=t=>{const e=new Map;return{$groupToManagers$:e,$createManager$:l=>new Nu(e,t,l),$clearSub$:l=>{const r=e.get(l);if(r){for(const i of r)i.$unsubGroup$(l);e.delete(l),r.length=0}},$clearSignal$:l=>{const r=e.get(l[1]);if(r)for(const i of r)i.$unsubEntry$(l)}}};class Nu{constructor(e,a,l){this.$groupToManagers$=e,this.$containerState$=a,this.$subs$=[],l&&this.$addSubs$(l)}$addSubs$(e){this.$subs$.push(...e);for(const a of this.$subs$)this.$addToGroup$(a[1],this)}$addToGroup$(e,a){let l=this.$groupToManagers$.get(e);l||this.$groupToManagers$.set(e,l=[]),l.includes(a)||l.push(a)}$unsubGroup$(e){const a=this.$subs$;for(let l=0;l<a.length;l++)a[l][1]===e&&(a.splice(l,1),l--)}$unsubEntry$(e){const[a,l,r,i]=e,c=this.$subs$;if(a===1||a===2){const d=e[4];for(let p=0;p<c.length;p++){const g=c[p];g[0]===a&&g[1]===l&&g[2]===r&&g[3]===i&&g[4]===d&&(c.splice(p,1),p--)}}else if(a===3||a===4)for(let d=0;d<c.length;d++){const p=c[d];p[0]===a&&p[1]===l&&p[2]===r&&p[3]===i&&(c.splice(d,1),d--)}}$addSub$(e,a){const l=this.$subs$,r=e[1];e[0]===0&&l.some(([i,c,d])=>i===0&&c===r&&d===a)||(l.push([...e,a]),this.$addToGroup$(r,this))}$notifySubs$(e){const a=this.$subs$;for(const l of a){const r=l[l.length-1];e&&r&&r!==e||bi(l,this.$containerState$)}}}const qn=t=>{if(t==null)throw _e("must be non null",t);return t},ar=t=>typeof t=="function"&&typeof t.getSymbol=="function",Ia=(t,e,a,l,r,i,c)=>{let d;const p=async function(...S){return await w.call(this,wt())(...S)},g=S=>(d||(d=S),d),$=async S=>{if(S&&g(S),a!==null)return a;if(l!==null)return a=l().then(b=>p.resolved=a=b[e]);{const b=ba().importSymbol(d,t,e);return a=Y(b,j=>p.resolved=a=j)}},h=S=>a!==null?a:$(S);function w(S,b){return(...j)=>{const k=Gu(),_=h();return Y(_,C=>{if(mt(C)){if(b&&b()===!1)return;const E={...T(S),$qrl$:p};return E.$event$===void 0&&(E.$event$=this),zu(e,E.$element$,k),pt.call(this,E,C,...j)}throw lt(10)})}}const T=S=>S==null?_t():tt(S)?_s(S):S,D=c??e,P=lr(D);return Object.assign(p,{getSymbol:()=>D,getHash:()=>P,getCaptured:()=>i,resolve:$,$resolveLazy$:h,$setContainer$:g,$chunk$:t,$symbol$:e,$refSymbol$:c,$hash$:P,getFn:w,$capture$:r,$captureRef$:i,dev:null,resolved:void 0}),p},lr=t=>{const e=t.lastIndexOf("_");return e>-1?t.slice(e+1):t};const Nn=new Set,zu=(t,e,a)=>{Nn.has(t)||(Nn.add(t),Ru("qsymbol",{symbol:t,element:e,reqTime:a}))},Ru=(t,e)=>{It()||typeof document!="object"||document.dispatchEvent(new CustomEvent(t,{bubbles:!1,detail:e}))},Gu=()=>It()?0:typeof performance=="object"?performance.now():0,zn=t=>t,m=t=>{function e(a,l,r){const i=t.$hash$.slice(0,4);return o(Ut,{"q:renderFn":t,[$t]:a[$t],[s]:a[s],children:a.children,props:a},r,i+":"+(l||""))}return e[ga]=[t],e},nr=t=>typeof t=="function"&&t[ga]!==void 0,he=(t,e)=>{const{val:a,set:l,iCtx:r}=Zt();if(a!=null)return a;const i=mt(t)?pt(void 0,t):t;if((e==null?void 0:e.reactive)===!1)return l(i),i;{const c=il(i,r.$renderCtx$.$static$.$containerState$,(e==null?void 0:e.deep)??!0?1:0);return l(c),c}};function kl(t,e){var l;const a=wt();return((l=a==null?void 0:a.$renderCtx$)==null?void 0:l.$static$.$containerState$.$serverData$[t])??e}const Qu=t=>{Fu(t,e=>e,!1)},Fu=(t,e,a)=>{const{val:l,set:r,iCtx:i,i:c,elCtx:d}=Zt();if(l)return l;const p=Qi(t,c),g=i.$renderCtx$.$static$.$containerState$;if(r(p),d.$appendStyles$||(d.$appendStyles$=[]),d.$scopeIds$||(d.$scopeIds$=[]),a&&d.$scopeIds$.push(Fi(p)),g.$styleIds$.has(p))return p;g.$styleIds$.add(p);const $=t.$resolveLazy$(g.$containerEl$),h=w=>{d.$appendStyles$,d.$appendStyles$.push({styleId:p,content:e(w,p)})};return rt($)?i.$waitOn$.push($.then(h)):h($),p},U=t=>{const{val:e,set:a,iCtx:l}=Zt();if(e!=null)return e;const r=l.$renderCtx$.$static$.$containerState$,i=mt(t)&&!nr(t)?pt(void 0,t):t;return a(Kr(i,r,0,void 0))},Rn={defaultLocale:{lang:"en",currency:"USD",timeZone:"America/Los_Angeles"},supportedLocales:[{lang:"en",currency:"USD",timeZone:"America/Los_Angeles"},{lang:"es",currency:"USD",timeZone:"America/Los_Angeles"}],assets:["app"]},Hu=({params:t,locale:e})=>{const a=Rn.supportedLocales.find(r=>r.lang===t.lang);console.log(t);const l=a?a.lang:!t.lang&&Rn.defaultLocale.lang;l&&e(l)},Wu=Object.freeze(Object.defineProperty({__proto__:null,onRequest:Hu},Symbol.toStringTag,{value:"Module"})),Uu='((i,a,r,s)=>{r=e=>{const t=document.querySelector("[q\\\\:base]");t&&a.active&&a.active.postMessage({type:"qprefetch",base:t.getAttribute("q:base"),...e})},document.addEventListener("qprefetch",e=>{const t=e.detail;a?r(t):i.push(t)}),navigator.serviceWorker.register("/service-worker.js").then(e=>{s=()=>{a=e,i.forEach(r),r({bundles:i})},e.installing?e.installing.addEventListener("statechange",t=>{t.target.state=="activated"&&s()}):e.active&&s()}).catch(e=>console.error(e))})([])',sr=qt("qc-s"),Vu=qt("qc-c"),rr=qt("qc-ic"),ir=qt("qc-h"),or=qt("qc-l"),ur=qt("qc-n"),cr=qt("qc-a"),Yu=qt("qc-ir"),Zu=t=>{const e=window,a=location.pathname+location.search,l="_qCitySPA",r="_qCityHistoryPatch",i="_qCityBootstrap",c="_qCityInitPopstate",d="_qCityInitAnchors",p="_qCityInitVisibility",g="_qCityInitScroll",$="_qCityScrollEnabled",h="_qCityScrollDebounce",w="_qCityScroll",T=S=>{S&&e.scrollTo(S.x,S.y)},D=()=>{const S=document.documentElement;return{x:S.scrollLeft,y:S.scrollTop,w:Math.max(S.scrollWidth,S.clientWidth),h:Math.max(S.scrollHeight,S.clientHeight)}},P=S=>{const b=history.state||{};b[w]=S||D(),history.replaceState(b,"")};if(!e[l]&&!e[c]&&!e[d]&&!e[p]&&!e[g]){if(P(),e[c]=()=>{var S;if(!e[l]){if(e[$]=!1,clearTimeout(e[h]),a!==location.pathname+location.search){const j=t.closest("[q\\:container]").querySelector('a[q\\:key="AD_1"]');if(j){const k=j.closest("[q\\:container]"),_=j.cloneNode();_.setAttribute("q:nbs",""),_.style.display="none",k.appendChild(_),e[i]=_,_.click()}else location.reload()}else if(history.scrollRestoration==="manual"){const b=(S=history.state)==null?void 0:S[w];T(b),e[$]=!0}}},!e[r]){e[r]=!0;const S=history.pushState,b=history.replaceState,j=k=>(k===null||typeof k>"u"?k={}:(k==null?void 0:k.constructor)!==Object&&(k={_data:k}),k._qCityScroll=k._qCityScroll||D(),k);history.pushState=(k,_,C)=>(k=j(k),S.call(history,k,_,C)),history.replaceState=(k,_,C)=>(k=j(k),b.call(history,k,_,C))}e[d]=S=>{if(e[l]||S.defaultPrevented)return;const b=S.target.closest("a[href]");if(b&&!b.hasAttribute("preventdefault:click")){const j=b.getAttribute("href"),k=new URL(location.href),_=new URL(j,k),C=_.origin===k.origin,E=_.pathname+_.search===k.pathname+k.search;if(C&&E)if(S.preventDefault(),_.href!==k.href&&history.pushState(null,"",_),!_.hash)_.href.endsWith("#")?window.scrollTo(0,0):(e[$]=!1,clearTimeout(e[h]),P({...D(),x:0,y:0}),location.reload());else{const L=_.hash.slice(1),M=document.getElementById(L);M&&M.scrollIntoView()}}},e[p]=()=>{!e[l]&&e[$]&&document.visibilityState==="hidden"&&P()},e[g]=()=>{e[l]||!e[$]||(clearTimeout(e[h]),e[h]=setTimeout(()=>{P(),e[h]=void 0},200))},e[$]=!0,setTimeout(()=>{addEventListener("popstate",e[c]),addEventListener("scroll",e[g],{passive:!0}),document.body.addEventListener("click",e[d]),e.navigation||document.addEventListener("visibilitychange",e[p],{passive:!0})},0)}},Ju=x(Zu,"s_DyVc0YBIqQU"),Xu=()=>{{const[t,e]=ba().chunkForSymbol(Ju.getSymbol(),null),a=Ir+"build/"+e;return`(${Ku.toString()})('${a}','${t}');`}},Ku=async(t,e)=>{var a;if(!window._qcs&&history.scrollRestoration==="manual"){window._qcs=!0;const l=(a=history.state)==null?void 0:a._qCityScroll;l&&window.scrollTo(l.x,l.y);const r=document.currentScript;(await import(t))[e](r)}},tc=()=>{const t=Xu();Z();const e=kl("nonce"),a=de(rr);if(a.value&&a.value.length>0){const l=a.value.length;let r=null;for(let i=l-1;i>=0;i--)a.value[i].default&&(r=o(a.value[i].default,{children:r},1,"zl_0"));return o(Q,{children:[r,n("script",{dangerouslySetInnerHTML:t},{nonce:e},null,3,null)]},1,"zl_1")}return ol},Nh=m(x(tc,"s_e0ssiDXoeAM")),ec="qaction",Gn=t=>t.pathname+t.search+t.hash,ne=(t,e)=>new URL(t,e.href),dr=(t,e)=>t.origin===e.origin,ac=(t,e)=>t.pathname+t.search===e.pathname+e.search,lc=(t,e)=>t.pathname===e.pathname,nc=(t,e)=>t.search===e.search,sc=(t,e)=>{const a=t.href;if(typeof a=="string"&&typeof t.target!="string"&&!t.reload)try{const l=ne(a.trim(),e.url),r=ne("",e.url);if(dr(l,r))return Gn(l)}catch(l){console.error(l)}else if(t.reload)return Gn(ne("",e.url));return null},rc=(t,e,a)=>{if(t.prefetch===!0&&e){const l=ne(e,a.url),r=ne("",a.url);if(!lc(l,r)||!nc(l,r))return""}return null},ic=t=>t&&typeof t.then=="function",oc=(t,e,a,l)=>{const r=pr(),c={head:r,withLocale:d=>Sn(l,d),resolveValue:d=>{const p=d.__id;if(d.__brand==="server_loader"&&!(p in t.loaders))throw new Error("You can not get the returned data of a loader that has not been executed for this request.");const g=t.loaders[p];if(ic(g))throw new Error("Loaders returning a function can not be referred to in the head function.");return g},...e};for(let d=a.length-1;d>=0;d--){const p=a[d]&&a[d].head;p&&(typeof p=="function"?Qn(r,Sn(l,()=>p(c))):typeof p=="object"&&Qn(r,p))}return c.head},Qn=(t,e)=>{typeof e.title=="string"&&(t.title=e.title),Ye(t.meta,e.meta),Ye(t.links,e.links),Ye(t.styles,e.styles),Ye(t.scripts,e.scripts),Object.assign(t.frontmatter,e.frontmatter)},Ye=(t,e)=>{if(Array.isArray(e))for(const a of e){if(typeof a.key=="string"){const l=t.findIndex(r=>r.key===a.key);if(l>-1){t[l]=a;continue}}t.push(a)}},pr=()=>({title:"",meta:[],links:[],styles:[],scripts:[],frontmatter:{}});let Fn;(function(t){t[t.EOL=0]="EOL",t[t.OPEN_BRACKET=91]="OPEN_BRACKET",t[t.CLOSE_BRACKET=93]="CLOSE_BRACKET",t[t.DOT=46]="DOT",t[t.SLASH=47]="SLASH"})(Fn||(Fn={}));const zh=()=>de(ir),We=()=>de(or),gr=()=>de(ur),uc=()=>de(cr),fr=()=>ja(kl("qwikcity")),cc=":root{view-transition-name:none}",dc=async(t,e)=>{const[a,l,r,i]=et(),{type:c="link",forceReload:d=t===void 0,replaceState:p=!1,scroll:g=!0}=typeof e=="object"?e:{forceReload:e},$=r.value.dest,h=t===void 0?$:ne(t,i.url);if(dr(h,$)&&!(!d&&ac(h,$)))return r.value={type:c,dest:h,forceReload:d,replaceState:p,scroll:g},a.value=void 0,i.isNavigating=!0,new Promise(w=>{l.r=w})},pc=({track:t})=>{const[e,a,l,r,i,c,d,p,g,$,h]=et();async function w(){const[D,P]=t(()=>[$.value,e.value]),S=Bi(""),b=h.url,j=P?"form":D.type;D.replaceState;let k,_,C=null;if(k=new URL(D.dest,h.url),C=i.loadedRoute,_=i.response,C){const[E,L,M,B]=C,W=M,ut=W[W.length-1];h.prevUrl=b,h.url=k,h.params={...L},$.untrackedValue={type:j,dest:k};const it=oc(_,h,W,S);a.headings=ut.headings,a.menu=B,l.value=ja(W),r.links=it.links,r.meta=it.meta,r.styles=it.styles,r.scripts=it.scripts,r.title=it.title,r.frontmatter=it.frontmatter}}return w()},gc=t=>{Qu(x(cc,"s_RPDJAz33WLA"));const e=fr();if(!(e!=null&&e.params))throw new Error("Missing Qwik City Env Data");const a=kl("url");if(!a)throw new Error("Missing Qwik URL Env Data");const l=new URL(a),r=he({url:l,params:e.params,isNavigating:!1,prevUrl:void 0},{deep:!1}),i={},c=Ou(he(e.response.loaders,{deep:!1})),d=U({type:"initial",dest:l,forceReload:!1,replaceState:!1,scroll:!0}),p=he(pr),g=he({headings:void 0,menu:void 0}),$=U(),h=e.response.action,w=h?e.response.loaders[h]:void 0,T=U(w?{id:h,data:e.response.formData,output:{result:w,status:e.response.status}}:void 0),D=x(dc,"s_fX0bDjeJa0E",[T,i,d,r]);return zt(Vu,g),zt(rr,$),zt(ir,p),zt(or,r),zt(ur,D),zt(sr,c),zt(cr,T),zt(Yu,d),hs(x(pc,"s_02wMImzEAbk",[T,g,$,p,e,D,c,i,t,d,r])),o(st,null,3,"qY_0")},Rh=m(x(gc,"s_TxCFOy819ag")),fc=t=>{const e=gr(),a=We(),{onClick$:l,reload:r,replaceState:i,scroll:c,...d}=(()=>t)(),p=na(()=>sc({...d,reload:r},a)),g=na(()=>rc(t,p,a));d["preventdefault:click"]=!!p,d.href=p||t.href;const $=g!=null?zn(F("s_eBQ0vFsFKsk")):void 0,h=zn(F("s_i1Cv0pYJNR0",[e,r,i,c]));return J("a",{...d,children:o(st,null,3,"AD_0"),"data-prefetch":g,onClick$:[l,h],onFocus$:$,onMouseOver$:$,onQVisible$:$},null,0,"AD_1")},we=m(x(fc,"s_8gdLBszqbaM")),Gh=t=>n("script",{nonce:y(t,"nonce")},{dangerouslySetInnerHTML:Uu},null,3,"1Z_0"),xc=(t={})=>{throw et(),new Error(`Actions can not be invoked within the server during SSR.
Action.run() can only be called on the browser, for example when a user clicks a button, or submits a form.`)},mc=(t,...e)=>{const{id:a,validators:l}=xr(e,t);function r(){const i=We(),c=uc(),d={actionPath:`?${ec}=${a}`,isRunning:!1,status:void 0,value:void 0,formData:void 0},p=he(()=>{const $=c.value;if($&&($==null?void 0:$.id)===a){const h=$.data;if(h instanceof FormData&&(d.formData=h),$.output){const{status:w,result:T}=$.output;d.status=w,d.value=T}}return d}),g=x(xc,"s_A5bZC7WO00A",[c,a,i,p]);return d.submit=g,p}return r.__brand="server_action",r.__validators=l,r.__qrl=t,r.__id=a,Object.freeze(r),r},Ll=(t,...e)=>{const a=mc(t,...e);return typeof globalThis._qwikActionsMap>"u"&&(globalThis._qwikActionsMap=new Map),globalThis._qwikActionsMap.set(a.__id,a),a},A=(t,...e)=>{const{id:a,validators:l}=xr(e,t);function r(){return de(sr,i=>{if(!(a in i))throw new Error(`routeLoader$ "${t.getSymbol()}" was invoked in a route where it was not declared.
    This is because the routeLoader$ was not exported in a 'layout.tsx' or 'index.tsx' file of the existing route.
    For more information check: https://qwik.builder.io/qwikcity/route-loader/`);return y(i,a)})}return r.__brand="server_loader",r.__qrl=t,r.__validators=l,r.__id=a,Object.freeze(r),r},$c=async function(...t){var a;const[e]=et();t.length>0&&t[0]instanceof AbortSignal&&t.shift();{const l=[(a=fr())==null?void 0:a.ev,this,Ri()].find(r=>r&&Object.prototype.hasOwnProperty.call(r,"sharedMap")&&Object.prototype.hasOwnProperty.call(r,"cookie"));return e.apply(l,t)}},Qh=t=>{{const a=t.getCaptured();if(a&&a.length>0&&!zi())throw new Error("For security reasons, we cannot serialize QRLs that capture lexical scope.")}function e(){return x($c,"s_wOIPfiQ04l4",[t])}return e()},xr=(t,e)=>{let a;const l=[];if(t.length===1){const r=t[0];r&&typeof r=="object"&&("validate"in r?l.push(r):(a=r.id,r.validation&&l.push(...r.validation)))}else t.length>1&&l.push(...t.filter(r=>!!r));return typeof a=="string"?a=`id_${a}`:a=e.getHash(),{validators:l.reverse(),id:a}},mr=({action:t,spaReset:e,reloadDocument:a,onSubmit$:l,...r},i)=>(Z(),t?J("form",{...r,action:y(t,"actionPath"),"preventdefault:submit":!a,"data-spa-reset":e?"true":void 0,onSubmit$:[a?void 0:t.submit,l]},{method:"post"},0,i):o(vc,{onSubmit$:l,reloadDocument:a,spaReset:e,...r},0,i)),hc=async(t,e)=>{const[a]=et(),l=new FormData(e),r=new URLSearchParams;l.forEach((i,c)=>{typeof i=="string"&&r.append(c,i)}),a("?"+r.toString(),{type:"form",forceReload:!0}).then(()=>{e.getAttribute("data-spa-reset")==="true"&&e.reset(),e.dispatchEvent(new CustomEvent("submitcompleted",{bubbles:!1,cancelable:!1,composed:!1,detail:{status:200}}))})},bc=t=>{const e=ti(t,["action","spaReset","reloadDocument","onSubmit$"]),a=gr();return J("form",{...e,children:o(st,null,3,"BC_0"),onSubmit$:x(hc,"s_p9MSze0ojs4",[a])},{action:"get","data-spa-reset":u(l=>l.spaReset?"true":void 0,[t],'p0.spaReset?"true":undefined'),"preventdefault:submit":u(l=>!l.reloadDocument,[t],"!p0.reloadDocument")},0,"BC_1")},vc=m(x(bc,"s_Nk9PlpjQm9Y")),yc=t=>n("div",null,{class:"w-fit h-fit flex items-center justify-center",role:"status"},n("svg",null,{"aria-hidden":"true",class:u(e=>`w-[${e.size}] h-[${e.size}] text-gray-200 animate-spin dark:text-blue-300 fill-primary-blue`,[t],"`w-[${p0.size}] h-[${p0.size}] text-gray-200 animate-spin dark:text-blue-300 fill-primary-blue`"),fill:"none",viewBox:"0 0 100 101",xmlns:"http://www.w3.org/2000/svg"},[n("path",null,{d:"M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",fill:"currentColor"},null,3,null),n("path",null,{d:"M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",fill:"currentFill"},null,3,null)],3,null),3,"73_0"),ue=m(x(yc,"s_kpSoQCQrots")),wc=()=>n("div",null,{class:"flex absolute flex-col items-center justify-center m-auto gap-2 h-full w-full bg-gradient-radial from-white via-slate-200 to-slate-300"},[n("img",null,{alt:"RTA image loading",height:200,src:"https://strapi.rtatel.com/uploads/RTA_db22afd96e.webp",width:250},null,3,null),o(ue,{size:"150px",[s]:{size:s}},3,"yL_0")],1,"yL_1"),_c=m(x(wc,"s_BeMhGs9mjvk")),Tc=async({cacheControl:t})=>{t({staleWhileRevalidate:604800,maxAge:5})},Sc=()=>({date:new Date().toISOString()}),Dc=A(x(Sc,"s_GQamrjryd1Y")),Pc=()=>{const[t]=et();t.value=!0},kc=()=>{Z();const t=U(!0);return hs(x(Pc,"s_lROQwus8zWc",[t])),Re(F("s_Ku7AU0gi0Go",[t])),o(Q,{children:t.value?n("div",null,{class:"h-full w-full flex",id:"splash"},o(_c,null,3,"XF_0"),1,"XF_1"):o(st,null,3,"XF_2")},1,"XF_3")},Lc=m(x(kc,"s_VkLNXphUh5s")),Mc=Object.freeze(Object.defineProperty({__proto__:null,default:Lc,onGet:Tc,useServerTimeLoader:Dc},Symbol.toStringTag,{value:"Module"})),Cc=()=>{const t=["https://images.unsplash.com/photo-1693825948507-acd866203fae?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8MXx8fGVufDB8fHx8fA%3D%3D","https://images.unsplash.com/photo-1694476053120-d729a3f6a7ed?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8fA%3D%3D","https://images.unsplash.com/photo-1695256294687-5df561945542?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8MTB8fHxlbnwwfHx8fHw%3D"],e=U(0);return Re(F("s_aXdoh0xz8cQ",[t,e])),n("div",null,null,n("img",{src:t[e.value]},{alt:"Slider",class:"transition-opacity duration-2000 ease-in-out opacity-100",height:150,width:150},null,3,null),1,"Sz_0")},jc=m(x(Cc,"s_X6NIVA8H4IM")),Ic=()=>o(Q,{children:o(jc,null,3,"Ch_0")},1,"Ch_1"),Ec=m(x(Ic,"s_nUdxvD3SCSo")),Oc=Object.freeze(Object.defineProperty({__proto__:null,default:Ec},Symbol.toStringTag,{value:"Module"})),Bc=async t=>{const e=await t.parseBody(),a="https://api.emailjs.com/api/v1.0/email/send/";console.log(e);const r={...{service_id:"service_3c06k96",user_id:"IYZz-W8oLRewKg_p0",accessToken:"6I-rPRtBvWRubnBm_GLdd"},template_id:e.template_id,template_params:e},i=await fetch(a,{method:"POST",body:JSON.stringify(r),headers:{"Content-Type":"application/json"}});t.json(200,{resp:await i.text()})},Ac=Object.freeze(Object.defineProperty({__proto__:null,onPost:Bc},Symbol.toStringTag,{value:"Module"})),qc=async(t,e,a)=>{const r=await fetch(`https://autosuggest.search.hereapi.com/v1/autosuggest?apiKey=-plDP_dR7XAGxBSiHgTFyxkxNdjFFHqjQK9ge8b92CE&q=${t}&at=${e},${a}&in=countryCode:USA&types=street`);return r.status!==200?[]:(await r.json()).items.map(d=>({address:d.title,zip:d.title.split(", ")[2].split(" ")[1]}))},Nc=async({json:t,query:e})=>{const a=e.get("q");if(!a)t(400,{message:"Bad request (need ?q param)"});else{const l=await qc(a,29.62540053919014,-95.39478748016545);t(200,{data:l})}},zc=Object.freeze(Object.defineProperty({__proto__:null,onGet:Nc},Symbol.toStringTag,{value:"Module"})),Ml="https://strapi.rtatel.com",Rc=`${Ml}/graphql`,G=t=>`${Ml}${t}`,fa=t=>t==="es"?"es-419":t,v=`
data {
    attributes {
        url
        alternativeText
        caption
    }
}
`,H=t=>{let e=[];return t.schema&&(e=t.schema.split('<script type="application/ld+json">').flatMap(a=>a.split("<script type='application/ld+json'>")).flatMap(a=>a.replace("<\/script>",""))),{title:t.MetaTitle,scripts:[...e.map(a=>({props:{type:"application/ld+json"},script:a}))],meta:[{name:"description",content:t.MetaDescription},{name:"robots",content:t.preventIndexing?"noindex":"index"},{name:"keywords",content:t.Keywords}]}},R=`
SEO {
    MetaTitle
    MetaDescription
    Keywords
    preventIndexing
    schema
}
`,Ue=`
data{
      attributes{
       	Content{
          Titles{
            Text
          }
          TextContent
        }
`,$r=`
MembersGrid{
           Picture{
         ${v}
        }
        FirstName
        LastName
        Position
        SocialMedia{
          Icon{
            ${v}
          }
          Link
        }
      }
`,Gc=t=>`
sectionNetwork (locale:"${t}"){
  data {
    attributes {
      Map {
        MapPicture {
          data {
            attributes {
              url
            }
          }
        }
        ServersTitle
        Servers {
          Text
          Link
          Icon{
            data{
              attributes{
                url
              }
            }
          }
        }
      }
      Description{
        Title
        Paragraph
      }
    }
  }
}
`,Qc=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],Fc=["January","February","March","April","May","June","July","August","September","October","November","December"];function Xe(t,e=!0){const a=new Date(t),l=Qc[a.getDay()],r=a.getDate(),i=Fc[a.getMonth()],c=a.getFullYear();return`${e?l+", ":""}${e?i:i.slice(0,3)} ${r}, ${c}`}const Hc=t=>n("img",{src:`${Ml}${t.url}`},{alt:u(e=>e.alt??"",[t],'p0.alt??""'),class:u(e=>(e.toWhite??!1?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(e.clasN??""),[t],'(p0.toWhite??false?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(p0.clasN??"")'),height:u(e=>e.height??300,[t],"p0.height??300"),title:u(e=>e.title??"",[t],'p0.title??""'),width:u(e=>e.width??300,[t],"p0.width??300")},null,3,"cI_0"),z=m(x(Hc,"s_LQFPgtOeNdI")),Wc=t=>J("svg",{...t,children:n("path",null,{d:"M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"xG_0"),Uc=t=>J("svg",{...t,children:n("path",null,{d:"M201.4 342.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 274.7 86.6 137.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"xH_0"),Vc=t=>J("svg",{...t,children:n("path",null,{d:"M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"GB_0"),Yc=t=>J("svg",{...t,children:n("path",null,{d:"M96 32V64H48C21.5 64 0 85.5 0 112v48H448V112c0-26.5-21.5-48-48-48H352V32c0-17.7-14.3-32-32-32s-32 14.3-32 32V64H160V32c0-17.7-14.3-32-32-32S96 14.3 96 32zM448 192H0V464c0 26.5 21.5 48 48 48H400c26.5 0 48-21.5 48-48V192z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"nO_0"),Zc=t=>J("svg",{...t,children:n("path",null,{d:"M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"p8_0"),Jc=t=>J("svg",{...t,children:n("path",null,{d:"M0 256a256 256 0 1 0 512 0A256 256 0 1 0 0 256zM281 385c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l71-71L136 280c-13.3 0-24-10.7-24-24s10.7-24 24-24l182.1 0-71-71c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0L393 239c9.4 9.4 9.4 24.6 0 33.9L281 385z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 512 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"tx_0"),Xc=t=>J("svg",{...t,children:n("path",null,{d:"M256 448c141.4 0 256-93.1 256-208S397.4 32 256 32S0 125.1 0 240c0 45.1 17.7 86.8 47.7 120.9c-1.9 24.5-11.4 46.3-21.4 62.9c-5.5 9.2-11.1 16.6-15.2 21.6c-2.1 2.5-3.7 4.4-4.9 5.7c-.6 .6-1 1.1-1.3 1.4l-.3 .3 0 0 0 0 0 0 0 0c-4.6 4.6-5.9 11.4-3.4 17.4c2.5 6 8.3 9.9 14.8 9.9c28.7 0 57.6-8.9 81.6-19.3c22.9-10 42.4-21.9 54.3-30.6c31.8 11.5 67 17.9 104.1 17.9zM128 208a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 0a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm96 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 512 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Bu_0"),Cl=t=>J("svg",{...t,children:n("path",null,{d:"M429.6 92.1c4.9-11.9 2.1-25.6-7-34.7s-22.8-11.9-34.7-7l-352 144c-14.2 5.8-22.2 20.8-19.3 35.8s16.1 25.8 31.4 25.8H224V432c0 15.3 10.8 28.4 25.8 31.4s30-5.1 35.8-19.3l144-352z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"ak_0"),Kc=t=>J("svg",{...t,children:n("path",null,{d:"M384 192c0 87.4-117 243-168.3 307.2c-12.3 15.3-35.1 15.3-47.4 0C117 435 0 279.4 0 192C0 86 86 0 192 0S384 86 384 192z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 384 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"6Z_0"),hr=t=>J("svg",{...t,children:n("path",null,{d:"M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 384 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"4m_0"),td=t=>{const e=U(!1);return n("div",null,{class:"relative w-fit"},[n("span",null,{class:u(a=>`${a.containerClass??""} flex cursor-pointer items-center gap-2`,[t],'`${p0.containerClass??""} flex cursor-pointer items-center gap-2`'),onClick$:F("s_F3aQ057DSxY",[e]),onFocusout$:F("s_eygkshVHA6I",[e])},[n("span",null,null,u(a=>a.title,[t],"p0.title"),3,null),o(Uc,null,3,"bO_0")],1,null),n("div",null,{class:u(a=>`absolute bottom-0 left-0 right-0 top-full z-10 min-w-[140px]  rounded-md bg-white shadow-lg transition-all duration-300 ${a.value?"":"hidden"}`,[e],'`absolute bottom-0 left-0 right-0 top-full z-10 min-w-[140px]  rounded-md bg-white shadow-lg transition-all duration-300 ${p0.value?"":"hidden"}`')},o(st,null,3,"bO_1"),1,null)],1,"bO_2")},xa=m(x(td,"s_f0Yr0C5H5Es")),ed=()=>{const[t]=et();let e="";t?e="/"+window.location.pathname.split("/es/")[1]:e="/es"+window.location.pathname,window.location.pathname=e},ad=t=>{var r;const a=(r=We().prevUrl)==null?void 0:r.pathname.includes("/es/");return n("div",null,{class:"relative flex cursor-pointer items-center justify-center self-center rounded-full bg-gray-100 shadow-sm",onClick$:x(ed,"s_W5KXXUmo6j8",[a])},[o(z,{get url(){return t.data[0].Icon.data.attributes.url},clasN:`h-[36px] w-[36px] m-1 rounded-full ${a?"opacity-30":"border-2 border-primary-blue border-opacity-50"}`,[s]:{url:u(i=>i.data[0].Icon.data.attributes.url,[t],'p0.data[0]["Icon"]["data"]["attributes"]["url"]')}},3,"tf_0"),o(z,{get url(){return t.data[1].Icon.data.attributes.url},clasN:`h-[36px] w-[36px] m-1 rounded-full ${a?"border-2 border-primary-blue border-opacity-50":"opacity-30"}  `,[s]:{url:u(i=>i.data[1].Icon.data.attributes.url,[t],'p0.data[1]["Icon"]["data"]["attributes"]["url"]')}},3,"tf_1")],1,"tf_2")},ld=m(x(ad,"s_mIn2RUIc9QU")),nd=t=>J("svg",{...t,children:n("path",null,{d:"M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.5a1 1 0 0 0-.8.4l-1.9 2.533a1 1 0 0 1-1.6 0L5.3 12.4a1 1 0 0 0-.8-.4H2a2 2 0 0 1-2-2V2zm3.5 1a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm0 2.5a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm0 2.5a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5z"},null,3,null)},{class:"bi bi-chat-square-text-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"yq_0"),br=t=>J("svg",{...t,children:n("path",null,{d:"M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"},null,3,null)},{class:"bi bi-check-circle-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Dp_0"),Hn=t=>J("svg",{...t,children:n("path",null,{d:"M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"},null,3,null)},{class:"bi bi-check","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"0U_0"),vr=t=>J("svg",{...t,children:[n("path",null,{d:"M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"},null,3,null),n("path",null,{d:"M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"},null,3,null)]},{class:"bi bi-download","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"ME_0"),sd=t=>J("svg",{...t,children:[n("path",null,{d:"M2 2A2 2 0 0 0 .05 3.555L8 8.414l7.95-4.859A2 2 0 0 0 14 2H2Zm-2 9.8V4.698l5.803 3.546L0 11.801Zm6.761-2.97-6.57 4.026A2 2 0 0 0 2 14h6.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.606-3.446l-.367-.225L8 9.586l-1.239-.757ZM16 9.671V4.697l-5.803 3.546.338.208A4.482 4.482 0 0 1 12.5 8c1.414 0 2.675.652 3.5 1.671Z"},null,3,null),n("path",null,{d:"M15.834 12.244c0 1.168-.577 2.025-1.587 2.025-.503 0-1.002-.228-1.12-.648h-.043c-.118.416-.543.643-1.015.643-.77 0-1.259-.542-1.259-1.434v-.529c0-.844.481-1.4 1.26-1.4.585 0 .87.333.953.63h.03v-.568h.905v2.19c0 .272.18.42.411.42.315 0 .639-.415.639-1.39v-.118c0-1.277-.95-2.326-2.484-2.326h-.04c-1.582 0-2.64 1.067-2.64 2.724v.157c0 1.867 1.237 2.654 2.57 2.654h.045c.507 0 .935-.07 1.18-.18v.731c-.219.1-.643.175-1.237.175h-.044C10.438 16 9 14.82 9 12.646v-.214C9 10.36 10.421 9 12.485 9h.035c2.12 0 3.314 1.43 3.314 3.034v.21Zm-4.04.21v.227c0 .586.227.8.581.8.31 0 .564-.17.564-.743v-.367c0-.516-.275-.708-.572-.708-.346 0-.573.245-.573.791Z"},null,3,null)]},{class:"bi bi-envelope-at-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"9e_0"),yr=t=>J("svg",{...t,children:n("path",null,{d:"M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"},null,3,null)},{class:"bi bi-geo-alt-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"62_0"),rd=t=>J("svg",{...t,children:n("path",null,{d:"M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"},null,3,null)},{class:"bi bi-info-circle-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"SU_0"),id=t=>J("svg",{...t,children:n("path",null,{d:"M2 6a6 6 0 1 1 10.174 4.31c-.203.196-.359.4-.453.619l-.762 1.769A.5.5 0 0 1 10.5 13h-5a.5.5 0 0 1-.46-.302l-.761-1.77a1.964 1.964 0 0 0-.453-.618A5.984 5.984 0 0 1 2 6zm3 8.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1l-.224.447a1 1 0 0 1-.894.553H6.618a1 1 0 0 1-.894-.553L5.5 15a.5.5 0 0 1-.5-.5z"},null,3,null)},{class:"bi bi-lightbulb-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"IC_0"),od=t=>J("svg",{...t,children:n("path",null,{d:"M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"},null,3,null)},{class:"bi bi-person-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"iB_0"),ud=t=>J("svg",{...t,children:n("path",null,{d:"M2 1a1 1 0 0 0-1 1v4.586a1 1 0 0 0 .293.707l7 7a1 1 0 0 0 1.414 0l4.586-4.586a1 1 0 0 0 0-1.414l-7-7A1 1 0 0 0 6.586 1H2zm4 3.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"},null,3,null)},{class:"bi bi-tag-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"vL_0"),cd=t=>J("svg",{...t,children:n("path",null,{d:"M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z","fill-rule":"evenodd"},null,3,null)},{class:"bi bi-telephone-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"nW_0"),dd=t=>J("svg",{...t,children:[n("path",null,{d:"M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"},null,3,null),n("path",null,{d:"M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"},null,3,null)]},{class:"bi bi-upload","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"pX_0"),pd=async t=>(console.log(t),{success:!0}),gd=Ll(x(pd,"s_SofV6zUr2So")),fd=()=>{const t=gd();return n("div",null,{class:"flex flex-col w-full md:w-1/2 h-[560px] bg-blue-100 rounded-2xl p-4"},[n("p",null,{class:"text-center font-medium text-color-Primary"},"Fill out the form below and attach your resume to contact us today",3,null),o(mr,{action:t,children:[n("div",null,{class:"flex-col sm:flex-row flex justify-between"},[n("div",null,{class:"mb-4 gap-2 flex flex-col"},[n("label",null,{class:"block font-medium text-color-Primary",for:"name"},"Name",3,null),n("input",null,{class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",name:"name",type:"text"},null,3,null)],3,null),n("div",null,{class:"mb-4 gap-2 flex flex-col"},[n("label",null,{class:"block font-medium text-color-Primary",for:"phone"},"Phone",3,null),n("input",null,{class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",maxLength:10,name:"phone",type:"tel"},null,3,null)],3,null)],3,null),n("div",null,{class:"mb-4 gap-2 flex flex-col"},[n("label",null,{class:"block font-medium text-color-Primary",for:"email"},"Email",3,null),n("input",null,{class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",name:"email",required:!0,type:"email"},null,3,null)],3,null),n("div",null,{class:"mb-4 gap-2 flex flex-col"},[n("label",null,{class:"block  font-medium text-color-Primary",for:"message"},"Message",3,null),n("textarea",null,{class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",name:"message",required:!0,rows:4},null,3,null)],3,null),n("label",null,{class:"flex w-[200px] text-color-Primary p-2 justify-evenly rounded-md font-medium",for:"file"},["Upload resume",o(dd,{class:"text-center font-bold",[s]:{class:s}},3,"Tf_0")],1,null),n("input",null,{accept:".pdf, .doc",class:"w-full",name:"file",type:"file"},null,3,null),n("button",null,{class:"mt-4 bg-secondary-red text-white w-full font-semibold px-4 py-2 rounded-xl hover:bg-blue-600 focus:outline-none",type:"submit"},"Submit",3,null)],class:"mt-2 overflow-y-auto",[s]:{action:s,class:s}},1,"Tf_1")],1,"Tf_2")},wr=m(x(fd,"s_HQgeb700od8")),xd=t=>{Z();const e=U(!0);return n("div",null,{class:"bg-blue-900 h-[550px] w-full sm:w-4/5 flex flex-col justify-between items-center p-6 rounded-2xl"},[n("h2",null,{class:"text-white font-bold text-xl md:text-4xl mb-2"},"Get in contact with us",3,null),e.value?o(ue,{size:"250px",[s]:{size:s}},3,"iV_0"):null,n("iframe",null,{class:"w-full h-full overflow-x-visible overflow-y-visible",onLoad$:F("s_fXnkVThI4oM",[e]),src:u(a=>a.link,[t],"p0.link")},null,3,null)],1,"iV_1")},md=m(x(xd,"s_fvFnDV0yuRY")),$d=()=>n("div",null,{class:"mx-auto flex max-w-lg flex-col rounded-xl bg-white p-6"},n("form",null,{class:"mt-2",id:"s_form"},[n("div",null,{class:"flex flex-wrap"},[n("div",null,{class:"mb-4 w-full sm:w-2/3"},[n("label",null,{class:"block font-medium text-[#2e5899]",for:"name"},["Name ",n("strong",null,{class:"text-xl font-bold text-red-600"},"*",3,null)," "],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},o(od,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"Pz_0"),1,null),n("input",null,{class:"w-full rounded-xl border border-[#2e5899] p-2 focus:border-blue-500 focus:outline-none",name:"from_name",required:!0,type:"text"},null,3,null)],1,null)],1,null),n("div",null,{class:"mb-4 w-2/3 sm:w-1/3"},[n("label",null,{class:"block font-medium text-[#2e5899]",for:"zip_code"},["Zip Code ",n("strong",null,{class:"text-xl font-bold text-red-600"},"*",3,null)," "],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},o(yr,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"Pz_1"),1,null),n("input",null,{class:"w-full rounded-xl border border-[#2e5899] p-2 focus:border-blue-500 focus:outline-none",maxLength:5,name:"zip_code",required:!0,type:"tel"},null,3,null)],1,null)],1,null)],1,null),n("div",null,{class:"flex flex-wrap items-center md:flex-row"},[n("div",null,{class:"mb-4 w-full sm:w-1/2"},[n("label",null,{class:"block font-medium text-[#2e5899]",for:"email"},["Email ",n("strong",null,{class:"font-bold text-red-600"},"*",3,null)],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},o(sd,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"Pz_2"),1,null),n("input",null,{class:"w-full rounded-xl border border-[#2e5899] p-2 focus:border-blue-500 focus:outline-none",name:"from_email",required:!0,type:"email"},null,3,null)],1,null)],1,null),n("div",null,{class:"mb-4 w-full md:w-1/2"},[n("label",null,{class:"block font-medium text-[#2e5899]",for:"tel"},"Phone",3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},o(cd,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"Pz_3"),1,null),n("input",null,{class:"w-full rounded-xl border border-[#2e5899] p-2 focus:border-blue-500 focus:outline-none",maxLength:14,name:"tel",type:"tel"},null,3,null)],1,null)],1,null)],1,null),n("div",null,{class:"mb-4"},[n("label",null,{class:"block  font-medium text-[#2e5899]",for:"message"},["Message",n("strong",null,{class:"text-xl font-bold text-red-600"},"*",3,null)],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},o(nd,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"Pz_4"),1,null),n("textarea",null,{class:"w-full rounded-xl border border-[#2e5899] p-2 focus:border-blue-500 focus:outline-none",name:"message",required:!0,rows:4},null,3,null)],1,null)],1,null),n("button",null,{class:"w-full rounded-xl bg-secondary-red px-4 py-2 font-semibold text-white hover:bg-blue-600 focus:outline-none",onClick$:F("s_mdlst2IazIg"),type:"button"},"Submit",3,null)],1,null),1,"Pz_5"),hd=m(x($d,"s_Km3fJEAS38s")),bd=()=>{const[t,e]=et();e.value=t},vd=t=>{var T;const e=new Set(t.data.map(D=>D.attributes.Category)),a=[],l=[],r=[],i=[],c=[],d=(T=t.planId)==null?void 0:T.slice(0,2),p=U(0);let g=!1,$=!1;t.data.map(D=>{D.attributes.Category=="Sports"&&a.push(D),D.attributes.Category=="Movies"&&l.push(D),D.attributes.Category=="News"&&r.push(D),D.attributes.Category=="Music"&&i.push(D),D.attributes.Category=="Kids"&&c.push(D)});const h=D=>D.map((P,S)=>(P.attributes.package_tvs.data.map(b=>{b.attributes.package.includes(d)?g=!0:b.attributes.package.includes("comingSoon")&&($=!0)}),n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",{class:`h-[50px] md:h-[80px] w-[50px] md:w-[80px] ${g?"":"opacity-20"} border-2 p-1 rounded-full flex flex-col`},null,n("img",{alt:y(P.attributes.Image.data.attributes,"alterbativeText"),src:G(P.attributes.Image.data.attributes.url)},{height:80,width:80},null,3,null),1,null),$?n("div",null,{class:"bg-primary-blue text-center p-0.5 text-xs text-white rounded-full"},"Coomig Soon",3,"wr_0"):null,n("p",null,{class:"text-xs text-center text-primary-blue"},y(P.attributes,"Channel_name"),1,null)],1,S))),w=Array.from(e).map((D,P)=>n("div",null,{class:"grid grid-cols-3 py-4 xl:grid-cols-8 lg:grid-cols-6 md:grid-cols-5 sm:grid-cols-4 gap-2"},D=="General"?h(t.data):D=="Sports"?h(a):D=="News"?h(r):D=="Music"?h(i):D=="Movies"?h(l):D=="Kids"?h(c):null,1,P));return n("div",null,{class:"h-full md:h-[500px] p-5 md:p-10 w-full md:w-3/4 rounded-3xl bg-blue-700"},[n("div",null,{class:"flex flex-col md:flex-row items-center justify-start md:justify-between"},[n("h1",null,{class:"text-white font-semibold text-2xl md:text-4xl"},u(D=>D.planId,[t],"p0.planId"),3,null),n("p",null,{class:"text-white font-light text-xl md:text-2xl"},u(D=>D.channels,[t],"p0.channels"),3,null)],3,null),n("div",null,{class:"flex flex-row md:overflow-clip overflow-x-auto gap-4 bg-white text-primary-blue font-bold h-fit my-1 rounded-t-2xl py-2 px-2 md:items-center items-start md:justify-between justify-start"},Array.from(e).map((D,P)=>n("button",{class:`${p.value==P?"bg-gray-200":""} p-2 rounded-xl`,onClick$:x(bd,"s_jPiPOXcEB6E",[P,p])},null,D,0,P)),1,null),n("div",null,{class:"flex h-3/4 w-full items-center justify-center p-6 bg-white rounded-b-3xl"},Array.from(e).map((D,P)=>p.value==P?n("div",null,{class:"flex h-full py-4 w-full bg-white overflow-y-auto border-2 rounded-2xl border-primary-blue"},w[P],1,P):null),1,null)],1,"wr_1")},yd=m(x(vd,"s_bUc7uFb70ZI")),wd=t=>`query {
        offices (filters:{locations:{ZipCode:{eq:${t}}}}) {
          data {
            attributes {
              InstanceLink
            }
          }
        }
      }`,_r=t=>`
query QueryLayout {
    generalMenu(locale: "${t}") {
      data {
        attributes {
          TopOptions {
            Icon {
              ${v}
            }
            Text
            Link
          }
  
          localizations {
            data {
              attributes {
                MainOptions {
                  Text
                  Link
                  SubOption {
                    Text
                    Link
                  }
                }
              }
            }
          }
  
          MainMenu {
            Logo {
              ${v}
            }
            Switcher {
              Text
              Link
              Icon {
                ${v}
              }
            }
          }
          MainOptions {
            Text
            Link
            SubOption {
              Text
              Link
              MenuOption {
                data {
                  attributes {
                    SubOption {
                      Text
                      Link
                    }
                  }
                }
              }
            }
          }
          ClientOptions {
            Text
            Link
          }
          gigfastOptions {
            Text
            Link
            Icon {
              ${v}
            }
          }
        }
      }
    }
    generalFooter(locale: "${t}") {
      data {
        attributes {
          SupportSection {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          CorpInfo {
            Media {
              ${v}
            }
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          Menus {
            Text
            SubOption {
              Text
              Link
            }
          }
          SocialMedia {
            Text
            SubOption {
              Icon {
                ${v}
              }
              Link
            }
          }
        }
      }
    }
    generalHeader {
      data {
        attributes {
          Slide {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
        }
      }
    }
  } 
`;async function ma(t){return await(await fetch(Rc,{method:"POST",cache:"no-cache",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:t})})).json()}async function q(t,e="en",a=!0){let l={};a&&(l=await ma(_r(fa(e))));const r=await ma(t(fa(e)));return{layoutData:l,pageData:r}}async function Ea(t,e="en",a=!0){let l={};a&&(l=await ma(_r(fa(e))));const r=await ma(t);return{layoutData:l,pageData:r}}const _d=t=>`query {
        offices(filters: { locations: { ZipCode: { eq: ${t} } } }) {
          data {
            attributes {
              Location
              Phone {
                Link
                Text
              }
            }
          }
        }
      }`,Td=async t=>{let e=null;const a=await Ea(wd(t["zip-code"].toString()));return a.pageData.data.offices.data.length>0&&(e=await a.pageData.data.offices.data[0].attributes.InstanceLink),e};Ll(x(Td,"s_Aa7HFHe6DLE"));const Sd=async t=>{let e=null;const a=await Ea(_d(t["zip-code"].toString()));return a.pageData.data.offices.data.length>0&&(e=await a.pageData.data.offices.data[0].attributes),e},Dd=Ll(x(Sd,"s_txZGYKoQ0E8")),Pd=()=>{},kd=t=>{Z();const e=Dd(),a=U(!1);return n("div",null,{class:"w-1/2 h-fit rounded-full p-8 flex flex-col gap-4 bg-blue-100 items-center justify-center"},[n("h1",null,{class:"text-center text-primary-blue font-bold text-4xl"},u(l=>l.title,[t],"p0.title"),3,null),n("p",null,{class:"font-light"},u(l=>l.description,[t],"p0.description"),3,null),o(mr,{action:e,children:n("div",null,{class:"px-4 flex flex-row items-center justify-center gap-4"},[n("div",null,{class:"flex items-center p-2 rounded"},[n("div",null,{class:"mr-2"},o(yr,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"PA_0"),1,null),n("input",null,{class:"border border-gray-300 placeholder:text-primary-blue p-2 rounded-full focus:outline-none focus:border-blue-500",maxLength:5,name:"zip-code",placeholder:"Zip-code",required:!0,type:"text"},null,3,null)],1,null),n("button",null,{class:"py-2 w-1/4 border-2 text-teal-500 px-4 bg-white font-bold border-teal-500 rounded-full hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:F("s_odOkENLwWr0",[a,e]),type:"submit"},u(l=>l.btnText,[t],"p0.btnText"),3,null)],1,null),class:"w-full",onSubmit$:x(Pd,"s_SuMdNt0qey8"),[s]:{action:s,class:s,onSubmit$:s}},1,"PA_1"),t.popup=="login"?e.isRunning?o(ue,{size:"50px",[s]:{size:s}},3,"PA_2"):e.value!=null?n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,null,"Portal found",3,null),n("a",null,{href:u(l=>l.value.toString(),[e],"p0.value.toString()")},n("button",null,{class:"py-2 w-full border-2 text-teal-500 px-4 bg-white font-bold border-teal-500 rounded-full hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"},"Go to portal",3,null),3,null)],3,"PA_3"):e.value==null&&e.isRunning==!1&&a.value?n("p",null,{class:"text-2xl text-secondary-red"},"Portal not found",3,"PA_4"):null:e.isRunning?o(ue,{size:"50px",[s]:{size:s}},3,"PA_5"):e.value!=null?n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,null,e.value.Location.toString(),1,null),n("a",null,{href:u(l=>l.value.Phone.Link.toString(),[e],'p0.value["Phone"]["Link"].toString()')},n("button",null,{class:"py-2 w-full border-2 text-teal-500 px-4 bg-white font-bold border-teal-500 rounded-full hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"},u(l=>l.value.Phone.Text,[e],'p0.value["Phone"]["Text"]'),3,null),3,null)],1,"PA_6"):e.value==null&&e.isRunning==!1&&a.value?n("p",null,{class:"text-xs text-primary-blue"},u(l=>l.notFountText,[t],"p0.notFountText"),3,"PA_7"):null],1,"PA_8")},Wn=m(x(kd,"s_7GiaINstLc4")),Ld=t=>{var i,c,d;Z();const a=(i=We().prevUrl)==null?void 0:i.pathname.includes("/es/");let l=null;if(t.link.includes("=pConf="))l=o(wr,null,3,"Y1_0");else if(t.link.includes("=pContactEmail="))l=o(hd,null,3,"Y1_1");else if(t.link.includes("=pIFrame=")){const p=t.link.replaceAll("=pIFrame=","");l=o(md,{link:p},3,"Y1_2")}else t.link.includes("=pChannelLineup=")?l=o(yd,{get channels(){return t.channels},get planId(){return t.planId},get data(){return t.dataChannels},[s]:{channels:u(p=>p.channels,[t],"p0.channels"),data:u(p=>p.dataChannels,[t],"p0.dataChannels"),planId:u(p=>p.planId,[t],"p0.planId")}},3,"Y1_3"):t.link.includes("=pLogin")?l=o(Wn,{btnText:a?"Ir ahora":"Go Now",description:a?"Simplemente ingrese su código postal.":"Just enter your Zip code.",popup:"login",title:a?"Inicia sesión en el portal de tu zona":"Log into the portal of your area",[s]:{popup:s}},3,"Y1_4"):t.link.includes("=pOfficeCall")&&(l=o(Wn,{btnText:a?"Comprobar ahora":"Check Now",description:a?"Descubra exactamente qué servicios ofrece RTA en su ciudad natal. Ingrese su código postal para el número de teléfono de su oficina local.":"Find out exactly what services RTA has to offer in your hometown. Input your zip code for your local office phone number.",notFountText:a?"Desafortunadamente, RTA no está disponible actualmente en su área. Sin embargo, RTA continúa expandiéndose en todo Estados Unidos. Si está interesado en los servicios de RTA en su área, envíenos un correo electrónico o llame a nuestra oficina principal.":"Find out exactly what services RTA has to offer in your hometown. Input your zip code for your local office phone number.",popup:"location",title:a?"Llame a su oficina local":"Call your local office",[s]:{popup:s}},3,"Y1_5"));const r=U(!1);return n("div",null,{class:"relative flex"},[t.link.includes("=pConf=")&&((c=t.text)!=null&&c.includes("Buy now")||(d=t.text)!=null&&d.includes("Comprar ahora"))?n("div",null,{class:"my-4 flex h-[80px] w-full cursor-pointer flex-col items-center justify-center"},[n("div",null,{class:"border-gary-500 my-4 h-[1px] w-full border-t-2"},null,3,null),n("div",null,{class:"flex h-[50px] w-full flex-row items-center justify-center rounded-full border-2 border-teal-500 bg-transparent p-1 px-6 text-btn-green hover:bg-teal-500 hover:text-white",onClick$:F("s_gYWamsOXj7w",[r])},[n("p",null,{class:"mx-4 font-bold"},u(p=>p.text,[t],"p0.text"),3,null),n("div",null,{class:"flex h-[25px] w-[25px] items-center justify-center rounded-full bg-teal-500 "},o(ud,{class:"fill-white",[s]:{class:s}},3,"Y1_6"),1,null)],1,null)],1,"Y1_7"):t.link.includes("=pLogin")?n("div",null,{onClick$:F("s_gRyPmBMRMEM",[r])},[o(st,null,3,"Y1_8")," "],1,"Y1_9"):n("button",{class:`flex w-fit items-center justify-center gap-2 ${t.link.includes("=pChannelLineup=")?"":"rounded-full border-2 border-teal-500 p-1 px-7 shadow-md transition-all  hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"}  bg-white  text-[15px] font-[600]  text-btn-green opacity-80 max-md:text-[14px] max-sm:text-[13px] `},{onClick$:F("s_LMY0q14Gz9I",[r])},u(p=>p.text,[t],"p0.text"),3,null),r.value&&n("div",null,{"aria-modal":"true",class:"fixed inset-0 z-50 flex flex-col items-end justify-center bg-gray-700 p-6 bg-opacity-40 rounded-lg shadow-md",role:"dialog",tabIndex:-1},[n("button",null,{"aria-label":"Close popup",class:"bg-secondary-red flex items-center justify-center text-white p-4 rounded-full w-[30px] h-[30px] focus:outline-none",onClick$:F("s_fxKxUVszfHA",[r])},"X",3,null),n("div",null,{class:"flex p-4 flex-wrap overflow-hidden items-center justify-center w-full animate-zoomIn"},l,1,null)],1,"Y1_10")],1,"Y1_11")},$a=m(x(Ld,"s_G7PwpIAJKRA")),Md=t=>(Z(),t.link.startsWith("/")||t.link.startsWith("http")?o(we,{get class(){return t.classN??""},get href(){return t.link},prefetch:!0,get target(){return t.link.startsWith("https")?"_blank":"_self"},children:o(st,null,3,"8s_0"),[s]:{class:u(e=>e.classN??"",[t],'p0.classN??""'),href:u(e=>e.link,[t],"p0.link"),prefetch:s,target:u(e=>e.link.startsWith("https")?"_blank":"_self",[t],'p0.link.startsWith("https")?"_blank":"_self"')}},1,"8s_1"):t.link.includes("=pLogin")?o($a,{get link(){return t.link},children:n("div",null,{class:u(e=>`${e.classN??""} cursor-pointer`,[t],'`${p0.classN??""} cursor-pointer`')},o(st,null,3,"8s_2"),1,null),[s]:{link:u(e=>e.link,[t],"p0.link")}},1,"8s_3"):n("div",null,{class:u(e=>e.classN??"",[t],'p0.classN??""')},o(st,null,3,"8s_4"),1,null)),yt=m(x(Md,"s_nqL2AObZq60")),Cd=()=>{const[t]=et();t.mobMenuOpen.value=!t.mobMenuOpen.value;const e=document.getElementsByTagName("body")[0];t.mobMenuOpen.value?e.classList.add("overflow-y-hidden"):e.classList.remove("overflow-y-hidden")},jd=t=>n("div",null,{class:"sticky top-0 z-30 shadow-[0_5px_40px_-25px_rgba(0,0,0,0.2)]"},[n("div",null,{class:"flex h-[28px] flex-row items-center justify-end gap-4 bg-primary-blue px-5 py-[4px] text-[12px] font-bold text-white max-sm:justify-evenly max-sm:text-[10px] max-sm:font-normal max-[400px]:text-[9px]"},t.data.TopOptions.map((e,a)=>(e.Link.includes("=p")&&(e.Link=""),o(yt,{get link(){return e.Link},children:n("div",null,{class:"flex flex-row items-center gap-2"},[n("div",null,{class:"w-[12px]"},o(z,{get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},height:"16",toWhite:!0,width:"16",[s]:{alt:f(e.Icon.data.attributes,"alternativeText"),height:s,title:f(e.Icon.data.attributes,"caption"),toWhite:s,url:f(e.Icon.data.attributes,"url"),width:s}},3,"Qt_0"),1,null),y(e,"Text")],1,null),[s]:{link:f(e,"Link")}},1,a))),1,null),n("div",null,{class:"grid grid-cols-3 items-center justify-evenly bg-white py-1 min-[1200px]:flex"},[n("div",null,{class:"flex items-center justify-center min-[1200px]:hidden"},o(Vc,{class:"min-[1200px]:hidden",onClick$:x(Cd,"s_y230Df800sE",[t]),[s]:{class:s,onClick$:s}},3,"Qt_1"),1,null),n("div",null,{class:"flex items-center justify-center"},n("div",null,{class:"w-[125px] py-1"},o(yt,{children:o(z,{get url(){return t.data.MainMenu.Logo.data.attributes.url},get alt(){return t.data.MainMenu.Logo.data.attributes.alternativeText},get title(){return t.data.MainMenu.Logo.data.attributes.caption},height:80,width:150,[s]:{alt:u(e=>e.data.MainMenu.Logo.data.attributes.alternativeText,[t],'p0.data["MainMenu"]["Logo"]["data"]["attributes"]["alternativeText"]'),height:s,title:u(e=>e.data.MainMenu.Logo.data.attributes.caption,[t],'p0.data["MainMenu"]["Logo"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.MainMenu.Logo.data.attributes.url,[t],'p0.data["MainMenu"]["Logo"]["data"]["attributes"]["url"]'),width:s}},3,"Qt_2"),link:"/",[s]:{link:s}},1,"Qt_3"),1,null),1,null),n("div",null,{class:"flex items-center justify-center gap-4 max-[1200px]:hidden"},t.data.MainOptions.map(function(e,a){Z();const l=e.SubOption.length>0;return n("div",null,{class:"text-[15px] font-bold text-primary-blue "},l?o(xa,{get title(){return e.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},e.SubOption.map((r,i)=>{Z();const c=r.MenuOption.data;return c?o(xa,{get title(){return r.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},c.attributes.SubOption.map((d,p)=>o(yt,{get link(){return d.Link},children:y(d,"Text"),[s]:{link:f(d,"Link")}},1,p)),1,null),[s]:{title:f(r,"Text")}},1,"Qt_5"):o(yt,{classN:"text-primary-blue",get link(){return r.Link},children:y(r,"Text"),[s]:{classN:s,link:f(r,"Link")}},1,i)}),1,null),[s]:{title:f(e,"Text")}},1,"Qt_6"):o(yt,{classN:"text-primary-blue",get link(){return e.Link},children:y(e,"Text"),[s]:{classN:s,link:f(e,"Link")}},1,"Qt_4"),1,a)}),1,null),n("div",null,{class:"flex items-center justify-center"},o(ld,{get data(){return t.data.MainMenu.Switcher},[s]:{data:u(e=>e.data.MainMenu.Switcher,[t],'p0.data["MainMenu"]["Switcher"]')}},3,"Qt_7"),1,null)],1,null),n("div",null,{class:"flex h-[32px] flex-row items-center justify-center gap-6 bg-secondary-red py-[2px] text-[14px] font-semibold tracking-[1px] text-white max-sm:text-[11px]"},t.data.ClientOptions.map((e,a)=>o(yt,{get link(){return e.Link},children:y(e,"Text"),[s]:{link:f(e,"Link")}},1,a)),1,null),n("div",null,{class:"flex flex-row items-center justify-evenly bg-white py-1 max-[1200px]:hidden"},t.data.gigfastOptions.map((e,a)=>o(yt,{get link(){return e.Link},children:n("div",null,{class:"w-[130px] rounded-md p-1 hover:bg-slate-50"},o(z,{get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},height:"60",width:"311",[s]:{alt:f(e.Icon.data.attributes,"alternativeText"),height:s,title:f(e.Icon.data.attributes,"caption"),url:f(e.Icon.data.attributes,"url"),width:s}},3,"Qt_8"),1,null),[s]:{link:f(e,"Link")}},1,a)),1,null)],1,"Qt_9"),Id=m(x(jd,"s_qJ0s4sH5iHo")),Ed=t=>{Z();const e=U(!1);return n("div",null,{class:"my-8 mb-2 w-full"},[n("div",{class:`flex cursor-pointer flex-row items-center transition ${t.inFooter??!1?"":e.value?"rounded-b-none rounded-t-2xl":"rounded-full"} justify-between ${t.classContainer} p-2 `},{onClick$:F("s_n7LVHyx9gZ0",[e])},[n("span",null,{class:"flex w-full items-center justify-center font-bold"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:u(a=>`flex h-[20px] w-[20px] items-center justify-center ${a.inFooter??!1?"":"rounded-full bg-secondary-red text-white"}`,[t],'`flex h-[20px] w-[20px] items-center justify-center ${p0.inFooter??false?"":"rounded-full bg-secondary-red text-white"}`')},n("span",null,{class:"w-1/8 flex items-center justify-end text-xs"},u(a=>a.value?"▲":"▼",[e],'p0.value?"▲":"▼"'),3,null),3,null)],3,null),e.value&&n("div",null,{class:u(a=>`${a.classChild} ${a.inFooter??!1?"":"rounded-b-2xl rounded-t-none border-t-2 bg-white"} p-2 text-center transition-all duration-500 ease-in-out`,[t],'`${p0.classChild} ${p0.inFooter??false?"":"rounded-b-2xl rounded-t-none border-t-2 bg-white"} p-2 text-center transition-all duration-500 ease-in-out`')},o(st,null,3,"vV_0"),1,"vV_1")],1,"vV_2")},ge=m(x(Ed,"s_znBlgckysPY")),Od=()=>{const[t]=et();t.link&&(window.location.href=t.link),(t.onClick??(()=>{}))()},Bd=t=>{var a;Z();const e=x(Od,"s_5VUQoQPBpDA",[t]);return(t.type??"link")==="link"?(a=t.link)!=null&&a.startsWith("=")&&t.link?o($a,{get link(){return t.link},get text(){return t.text},[s]:{link:u(l=>l.link,[t],"p0.link"),text:u(l=>l.text,[t],"p0.text")}},3,"ky_0"):n("div",null,{class:"flex w-fit items-center justify-center gap-2 rounded-full border-2 border-teal-500 bg-white p-0.5 px-7 text-btn-green opacity-90 shadow-md transition-all hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:F("s_v30BEZ050tM",[e])},n("span",null,{class:"text-[15px] font-[600] max-md:text-[14px] max-sm:text-[13px] "},u(l=>l.text,[t],"p0.text"),3,null),3,"ky_1"):n("div",null,{class:"flex w-fit items-center justify-center gap-2 rounded-full bg-button-green p-0.5 pl-2 text-white hover:cursor-pointer",onClick$:F("s_eSPP9CLbtZw",[e])},n("span",null,{class:"text-[16px]"},u(l=>l.text,[t],"p0.text"),3,null),3,"ky_2")},X=m(x(Bd,"s_FRLwbQyPTTI")),Ad=t=>n("div",null,{class:"",id:"footer"},[n("div",null,{class:"flex flex-col items-center bg-primary-blue px-4 py-3 text-white"},[n("h3",null,{class:"text-[22px] font-semibold"},u(e=>e.data.SupportSection.Title,[t],'p0.data["SupportSection"]["Title"]'),3,null),n("p",null,{class:"text-s lm:w-1/2 text-center sm:w-3/4"},u(e=>e.data.SupportSection.Paragraph,[t],'p0.data["SupportSection"]["Paragraph"]'),3,null)],3,null),n("div",null,{class:"flex flex-col flex-wrap justify-around bg-primary-dark-blue px-3 py-3 text-white lg:flex-row"},[n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"mb-4 w-[180px]"},o(z,{height:359,width:970,get url(){return t.data.CorpInfo.Media.data.attributes.url},get alt(){return t.data.CorpInfo.Media.data.attributes.alternativeText},get title(){return t.data.CorpInfo.Media.data.attributes.caption},[s]:{alt:u(e=>e.data.CorpInfo.Media.data.attributes.alternativeText,[t],'p0.data["CorpInfo"]["Media"]["data"]["attributes"]["alternativeText"]'),height:s,title:u(e=>e.data.CorpInfo.Media.data.attributes.caption,[t],'p0.data["CorpInfo"]["Media"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.CorpInfo.Media.data.attributes.url,[t],'p0.data["CorpInfo"]["Media"]["data"]["attributes"]["url"]'),width:s}},3,"Zn_0"),1,null),n("p",null,{class:"mb-4 max-w-sm text-center"},u(e=>e.data.CorpInfo.Paragraph,[t],'p0.data["CorpInfo"]["Paragraph"]'),3,null),o(X,{type:"action",get link(){return t.data.CorpInfo.Buttons[0].Link},get text(){return t.data.CorpInfo.Buttons[0].Text},[s]:{link:u(e=>e.data.CorpInfo.Buttons[0].Link,[t],'p0.data["CorpInfo"]["Buttons"][0]["Link"]'),text:u(e=>e.data.CorpInfo.Buttons[0].Text,[t],'p0.data["CorpInfo"]["Buttons"][0]["Text"]'),type:s}},3,"Zn_1")],1,null),n("div",null,{class:"container sm:hidden"},t.data.Menus.map((e,a)=>o(ge,{inFooter:!0,get title(){return e.Text},children:e.SubOption.map((l,r)=>o(we,{get href(){return l.Link},children:n("h3",null,null,y(l,"Text"),1,null),class:"mb-4 hover:text-blue-600",[s]:{class:s,href:f(l,"Link")}},1,r)),classContainer:"text-xl text-primary-light-blue font-semibold border-b-2 border-t-2 border-primary-light-blue",[s]:{classContainer:s,inFooter:s,title:f(e,"Text")}},1,a)),1,null),n("div",null,{class:"flex justify-around"},t.data.Menus.map((e,a)=>n("div",null,{class:"hidden w-1/4 sm:block"},[n("h2",null,{class:"text-2xl text-primary-light-blue font-semibold"},y(e,"Text"),1,null),e.SubOption.map((l,r)=>o(we,{get href(){return l.Link},children:n("h3",null,null,y(l,"Text"),1,null),class:"hover:text-blue-600",[s]:{class:s,href:f(l,"Link")}},1,r))],1,a)),1,null)],1,null),n("div",null,{class:"flex flex-col items-center gap-2 bg-primary-dark-blue px-4 py-4 text-white"},[n("p",null,{class:"text-[14px]"},u(e=>e.data.SocialMedia.Text,[t],'p0.data["SocialMedia"]["Text"]'),3,null),n("div",null,{class:"flex flex-row gap-4"},t.data.SocialMedia.SubOption.map((e,a)=>Z(o(we,{get href(){return e.Link},children:[e.Link.includes("facebook")&&n("div",null,{class:"flex h-7 w-7 items-center justify-center rounded-full bg-primary-blue p-2"},o(z,{height:20,width:20,get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},toWhite:!0,[s]:{alt:f(e.Icon.data.attributes,"alternativeText"),height:s,title:f(e.Icon.data.attributes,"caption"),toWhite:s,url:f(e.Icon.data.attributes,"url"),width:s}},3,"Zn_2"),1,"Zn_3"),!e.Link.includes("facebook")&&n("div",null,{class:"flex h-7 w-7 items-center justify-center rounded-full bg-primary-blue p-1"},o(z,{height:20,width:20,get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},toWhite:!0,[s]:{alt:f(e.Icon.data.attributes,"alternativeText"),height:s,title:f(e.Icon.data.attributes,"caption"),toWhite:s,url:f(e.Icon.data.attributes,"url"),width:s}},3,"Zn_4"),1,"Zn_5")],[s]:{href:f(e,"Link")}},1,a))),1,null)],1,null)],1,"Zn_6"),qd=m(x(Ad,"s_ecsQS6so2H0")),Nd=t=>n("div",{class:`flex list-inside flex-col gap-3 text-primary-blue [&>*>a]:text-secondary-red [&>h1]:text-[36px] [&>h1]:font-[600] [&>h2]:text-[32px] [&>h3]:text-[26px] ${t.classN??""}`,dangerouslySetInnerHTML:Vn(t.text)},null,null,3,"Cb_0"),I=m(x(Nd,"s_RjmVkFh5HBg")),Tr=({qty:t})=>{if(t!==void 0)return t;if(typeof window<"u"){const e=window.innerWidth;return e>1200?3:e>800?2:1}else return 1},zd=()=>{const[t,e]=et();t.value=Tr({qty:e})},Rd=()=>{const[t]=et();t()},Gd=({slidesQty:t})=>{const e=U(Tr({qty:t})),a=x(zd,"s_zVG057gY2pI",[e,t]);return Re(F("s_hQsoJzDpgeo",[a])),Zr("resize",x(Rd,"s_WB2t7tmOijA",[a])),e};const Qd=t=>{const e=Gd({slidesQty:t.slidesQty});return Re(F("s_xmo13ab0hsk",[e,t])),o(Q,{children:n("section",null,{"aria-label":"Componente Carousel",class:"splide max-w-screen overflow-hidden",id:u(a=>`${a.id?a.id:""}`,[t],'`${p0.id?p0.id:""}`')},n("div",null,{class:u(a=>` splide__track  ${a.addSpace??!0?"p-8":""}`,[t],'` splide__track  ${p0.addSpace??true?"p-8":""}`')},n("div",null,{class:"splide__list justify-between "},t.slides.map((a,l)=>n("div",null,{class:"splide__slide w-full items-center"},n("div",null,{class:u(r=>` flex items-center object-center ${r.addSpace??!0?"mx-10":""}  justify-center`,[t],'` flex items-center object-center ${p0.addSpace??true?"mx-10":""}  justify-center`')},a,1,null),1,l)),1,null),1,null),1,null)},1,"cE_0")},Bt=m(x(Qd,"s_UuwASfcxtbw")),Fd=t=>n("div",null,{class:"flex flex-col items-center justify-between"},[n("div",null,{class:"z-20 mb-1 flex flex-col justify-center"},[n("span",null,{class:"text-center text-[20px] font-semibold"},u(e=>e.slide.Title,[t],'p0.slide["Title"]'),3,null),n("span",null,{class:"text-[14px] font-light"},o(I,{classN:"text-white",get text(){return t.slide.Paragraph},[s]:{classN:s,text:u(e=>e.slide.Paragraph,[t],'p0.slide["Paragraph"]')}},3,"DG_0"),1,null)],1,null),o(X,{get link(){return t.slide.Buttons[0].Link},get text(){return t.slide.Buttons[0].Text},[s]:{link:u(e=>e.slide.Buttons[0].Link,[t],'p0.slide["Buttons"][0]["Link"]'),text:u(e=>e.slide.Buttons[0].Text,[t],'p0.slide["Buttons"][0]["Text"]')}},3,"DG_1")],1,"DG_2"),Hd=t=>{const e=m(x(Fd,"s_3lZ1awB53As")),a=t.data.Slide.map((l,r)=>o(e,{slide:l},3,r));return n("div",null,{class:"mb-4 flex w-[40%] min-w-[350px] max-w-[500px] flex-col items-center justify-center overflow-hidden rounded-full rounded-t-none bg-[#0E4FB0] px-8 py-1 text-white max-[400px]:w-[98%] max-[400px]:min-w-[200px] max-[400px]:pb-10 "},o(Bt,{addSpace:!1,duration:4e3,hasPagination:!1,id:"headerCarousel",slides:a,[s]:{addSpace:s,duration:s,hasPagination:s,id:s}},3,"DG_3"),1,"DG_4")},Wd=m(x(Hd,"s_BIrsaZMr3LY")),Ud=t=>n("div",null,{class:"flex flex-col gap-4 px-4 py-6 text-[15px] tracking-tight text-white"},[t.data.MainOptions.map(function(e,a){Z();const l=e.SubOption.length>0;return n("div",null,{class:""},l?o(xa,{get title(){return e.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},e.SubOption.map((r,i)=>{Z();const c=r.MenuOption.data;return c?o(xa,{get title(){return r.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},c.attributes.SubOption.map((d,p)=>o(yt,{get link(){return d.Link},children:y(d,"Text"),[s]:{link:f(d,"Link")}},1,p)),1,null),[s]:{title:f(r,"Text")}},1,"Ux_1"):o(yt,{get link(){return r.Link},children:y(r,"Text"),[s]:{link:f(r,"Link")}},1,i)}),1,null),[s]:{title:f(e,"Text")}},1,"Ux_2"):o(yt,{get link(){return e.Link},children:y(e,"Text"),[s]:{link:f(e,"Link")}},1,"Ux_0"),1,a)}),n("div",null,{class:"w-full border border-white border-opacity-40"},null,3,null),n("div",null,{class:"flex w-fit flex-col gap-5"},t.data.gigfastOptions.map((e,a)=>o(yt,{get link(){return e.Link},children:n("div",null,{class:"w-[130px] rounded-md p-1"},o(z,{get url(){return e.Icon.data.attributes.url},height:"60",width:"311",[s]:{height:s,url:f(e.Icon.data.attributes,"url"),width:s}},3,"Ux_3"),1,null),classN:"rounded-full bg-white px-4 py-1 shadow-lg",[s]:{classN:s,link:f(e,"Link")}},1,a)),1,null)],1,"Ux_4"),Vd=m(x(Ud,"s_jSaadUqLWqI")),Yd=t=>{Z();const e=U(!1);return n("div",null,{class:u(a=>`relative overflow-x-hidden transition-all duration-500 ${a.value?"overflow-y-hidden":""}`,[e],'`relative overflow-x-hidden transition-all duration-500 ${p0.value?"overflow-y-hidden":""}`'),style:u(a=>a.value?{perspective:"9000px"}:{},[e],'p0.value?{perspective:"9000px"}:{}')},[n("div",null,{class:u(a=>`absolute inset-0 -z-[200] bg-gradient-to-l from-[#2e599a] to-[#182d4d] ${a.value?"overflow-y-hidden":""}`,[e],'`absolute inset-0 -z-[200] bg-gradient-to-l from-[#2e599a] to-[#182d4d] ${p0.value?"overflow-y-hidden":""}`')},o(Vd,{get data(){return t.data.data.generalMenu.data.attributes},[s]:{data:u(a=>a.data.data.generalMenu.data.attributes,[t],'p0.data["data"]["generalMenu"]["data"]["attributes"]')}},3,"m8_0"),1,null),n("div",null,{class:u(a=>`relative transition-all duration-500 ${a.value?"overflow-y-hidden":""}`,[e],'`relative transition-all duration-500 ${p0.value?"overflow-y-hidden":""}`'),style:u(a=>a.value?{transform:"rotateY(-30deg) translateX(250px) translateY(200px)",transformStyle:"preserve-3d"}:{},[e],'p0.value?{transform:"rotateY(-30deg) translateX(250px) translateY(200px)",transformStyle:"preserve-3d"}:{}')},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-10 bg-gradient-to-l from-[#FFFFFF] to-[#C8D8ED]"},null,3,null),o(Id,{get data(){return t.data.data.generalMenu.data.attributes},mobMenuOpen:e,[s]:{data:u(a=>a.data.data.generalMenu.data.attributes,[t],'p0.data["data"]["generalMenu"]["data"]["attributes"]'),mobMenuOpen:s}},3,"m8_1"),n("div",null,{class:u(a=>`${a.value?"overflow-y-hidden":""}`,[e],'`${p0.value?"overflow-y-hidden":""}`')},[(t.showHeader??!0)&&n("div",null,{class:"flex w-full items-center justify-center"},o(Wd,{get data(){return t.data.data.generalHeader.data.attributes},[s]:{data:u(a=>a.data.data.generalHeader.data.attributes,[t],'p0.data["data"]["generalHeader"]["data"]["attributes"]')}},3,"m8_2"),1,"m8_3"),o(st,null,3,"m8_4"),o(qd,{get data(){return t.data.data.generalFooter.data.attributes},[s]:{data:u(a=>a.data.data.generalFooter.data.attributes,[t],'p0.data["data"]["generalFooter"]["data"]["attributes"]')}},3,"m8_5")],1,null)],1,null)],1,"m8_6")},N=m(x(Yd,"s_vumpf0PbXbo")),Zd=t=>{const e=t.customText?t.customText:t.SEOdata.MetaTitle.split(" |")[0];return!t.SEOdata&&!t.customText?n("h1",null,{class:"absolute opacity-0"},"RTA",3,"Yj_0"):n("h1",null,{class:"absolute opacity-0"},e,1,"Yj_1")},K=m(x(Zd,"s_SOxRNst40is")),Jd=t=>n("div",{class:`flex w-full flex-col items-center justify-center ${t.alt??!1?"bg-white":"bg-[#e2eefa]"}
        ${t.backgroundColor&&`bg-${t.backgroundColor}`}`},null,[(t.alt??!1)&&o(Q,{children:[n("div",null,{class:"h-8 w-full bg-[#ebf4fc]"},null,3,null),n("div",null,{class:"h-8 w-full bg-[#f7fafe]"},null,3,null)]},3,"9K_0"),n("div",null,{class:u(e=>`my-4 flex ${e.reverse??!1?"flex-row-reverse":""} max-w-[1200px] items-center justify-center max-[800px]:flex-col`,[t],'`my-4 flex ${p0.reverse??false?"flex-row-reverse":""} max-w-[1200px] items-center justify-center max-[800px]:flex-col`')},[n("div",null,{class:u(e=>`flex ${e.image&&`min-[800px]:w-[${(e.textPercentage??70).toString()}%]`}  flex-col items-center justify-center gap-4 px-10`,[t],"`flex ${p0.image&&`min-[800px]:w-[${(p0.textPercentage??70).toString()}%]`}  flex-col items-center justify-center gap-4 px-10`")},[t.logo&&n("div",null,{class:"max-w-[470px]"},n("img",{src:G(t.logo.url)},{alt:u(e=>e.logo.alternativeText,[t],'p0.logo["alternativeText"]'),height:"230",title:u(e=>e.logo.caption,[t],'p0.logo["caption"]'),width:"1230"},null,3,null),1,"9K_1"),n("div",null,{class:u(e=>`flex ${!(e.hasPricing??!0)&&"flex-col"} justify-center gap-2 text-${e.color??"primary-blue"}`,[t],'`flex ${!(p0.hasPricing??true)&&"flex-col"} justify-center gap-2 text-${p0.color??"primary-blue"}`')},[t.title&&n("h2",null,{class:"text-center text-[38px]  font-bold max-sm:text-[28px]"},u(e=>e.title,[t],"p0.title"),3,"9K_2"),t.subtitle&&n("h3",{class:`text-[28px] font-bold
                  ${t.backgroundColor&&t.backgroundColor.trim()!==""?"text-white":"text-secondary-red"}
                  ${t.hasPricing??!0?"":"text-center "} max-sm:text-[20px]`},null,u(e=>e.subtitle,[t],"p0.subtitle"),3,"9K_3")],1,null),o(I,{get text(){return t.text},get classN(){return`text-[18px] max-sm:text-[15px] text-${t.color??"primary-blue"}`},[s]:{classN:u(e=>`text-[18px] max-sm:text-[15px] text-${e.color??"primary-blue"}`,[t],'`text-[18px] max-sm:text-[15px] text-${p0.color??"primary-blue"}`'),text:u(e=>e.text,[t],"p0.text")}},3,"9K_4"),n("div",null,{class:"flex gap-4"},t.buttons&&t.buttons.map((e,a)=>o(X,{get text(){return e.Text},get link(){return e.Link},children:o(Jc,{class:"text-[21px] opacity-60",color:"#13B295",[s]:{class:s,color:s}},3,"9K_5"),[s]:{link:f(e,"Link"),text:f(e,"Text")}},1,a)),1,null)],1,null),t.image&&n("div",{class:`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${(100-(t.textPercentage??70)).toString()}%] ${t.imageLink&&"cursor-pointer"}`},{onClick$:F("s_0a2swupHwgA",[t])},n("img",{src:G(t.image.url)},{alt:u(e=>e.image.alternativeText,[t],'p0.image["alternativeText"]'),height:"300",title:u(e=>e.image.caption,[t],'p0.image["caption"]'),width:"597"},null,3,null),1,"9K_6"),t.customComponent&&n("div",null,{class:u(e=>`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${(100-(e.textPercentage??70)).toString()}%]`,[t],"`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${(100-(p0.textPercentage??70)).toString()}%]`")},u(e=>e.customComponent,[t],"p0.customComponent"),3,"9K_7")],1,null),(t.alt??!1)&&o(Q,{children:[n("div",null,{class:"h-8 w-full bg-[#f7fafe]"},null,3,null),n("div",null,{class:"h-8 w-full bg-[#ebf4fc]"},null,3,null)]},3,"9K_8")],1,"9K_9"),At=m(x(Jd,"s_QAc0HW5bNAE")),Xd=t=>o(At,{get logo(){return t.data.Logo&&t.data.Logo.data&&t.data.Logo.data.attributes},get image(){return t.data.Media&&t.data.Media.data&&t.data.Media.data.attributes},get title(){return t.data.Title},get subtitle(){return t.data.Subtitle},get text(){return t.data.Paragraph},get buttons(){return t.data.Buttons},get reverse(){return t.reverse??!1},get color(){return t.color??"primary-blue"},get alt(){return t.alt??!1},get hasPricing(){return t.hasPricing??!0},get textPercentage(){return t.textPercentage??70},get customComponent(){return t.customComponent},get backgroundColor(){return t.backgroundColor},imageLink:t.data.Media&&t.data.Media.data&&t.data.Media.data.attributes.caption.includes("http")?t.data.Media.data.attributes.caption:t.imageLink,[s]:{alt:u(e=>e.alt??!1,[t],"p0.alt??false"),backgroundColor:u(e=>e.backgroundColor,[t],"p0.backgroundColor"),buttons:u(e=>e.data.Buttons,[t],'p0.data["Buttons"]'),color:u(e=>e.color??"primary-blue",[t],'p0.color??"primary-blue"'),customComponent:u(e=>e.customComponent,[t],"p0.customComponent"),hasPricing:u(e=>e.hasPricing??!0,[t],"p0.hasPricing??true"),image:u(e=>e.data.Media&&e.data.Media.data&&e.data.Media.data.attributes,[t],'p0.data["Media"]&&p0.data["Media"]["data"]&&p0.data["Media"]["data"]["attributes"]'),logo:u(e=>e.data.Logo&&e.data.Logo.data&&e.data.Logo.data.attributes,[t],'p0.data["Logo"]&&p0.data["Logo"]["data"]&&p0.data["Logo"]["data"]["attributes"]'),reverse:u(e=>e.reverse??!1,[t],"p0.reverse??false"),subtitle:u(e=>e.data.Subtitle,[t],'p0.data["Subtitle"]'),text:u(e=>e.data.Paragraph,[t],'p0.data["Paragraph"]'),textPercentage:u(e=>e.textPercentage??70,[t],"p0.textPercentage??70"),title:u(e=>e.data.Title,[t],'p0.data["Title"]')}},3,"9K_10"),Nt=m(x(Xd,"s_Itm0b43i6oU")),Kd=t=>o(Q,{children:t.data.map((e,a)=>o(Nt,{alt:a%2===0,data:e,reverse:a%2===0,get color(){return t.color??"primary-blue"},[s]:{color:u(l=>l.color??"primary-blue",[t],'p0.color??"primary-blue"')}},3,a))},1,"9K_11"),Xt=m(x(Kd,"s_0DQ5Kmfc4bA")),tp=t=>n("div",null,{class:"flex max-w-[1200px] items-center justify-center self-center max-[800px]:flex-col"},[n("div",null,{class:"flex w-[300px] flex-col items-center justify-center self-center p-4 min-[800px]:w-[40%]"},[n("iframe",null,{allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",allowFullScreen:!0,class:"mb-5 rounded-[30px] shadow-md",frameBorder:"0",height:"250px",src:u(e=>`https://www.youtube.com/embed/${e.video.Link.split("v=")[1]}`,[t],'`https://www.youtube.com/embed/${p0.video["Link"].split("v=")[1]}`'),width:"100%"},null,3,null),o(I,{get text(){return t.video.Paragraph},classN:"px-3 max-sm:text-[14px] text-[16px] text-primary-blue text-justify",[s]:{classN:s,text:u(e=>e.video.Paragraph,[t],'p0.video["Paragraph"]')}},3,"tX_0")],1,null),n("div",null,{class:"flex flex-col items-center justify-center gap-4 px-10 min-[800px]:w-[60%]"},[n("h3",null,{class:"text-center text-[38px] font-bold text-primary-blue max-sm:text-[28px]"},u(e=>e.info.Title,[t],'p0.info["Title"]'),3,null),n("h4",null,{class:"text-center text-[38px] font-bold text-secondary-red max-sm:text-[28px]"},u(e=>e.info.Subtitle,[t],'p0.info["Subtitle"]'),3,null),n("div",null,null,o(I,{classN:"max-sm:text-[15px] text-[18px] text-primary-blue",get text(){return t.info.Paragraph},[s]:{classN:s,text:u(e=>e.info.Paragraph,[t],'p0.info["Paragraph"]')}},3,"tX_1"),1,null)],1,null)],1,"tX_2"),ep=m(x(tp,"s_ndQUOpucQqo")),ap=t=>n("div",null,{class:"relative flex h-full w-full items-center justify-center overflow-hidden"},[!(t.isFirst??!1)&&n("div",null,{class:"absolute bottom-[calc(50%+20px)] top-0 border-l-2 border-secondary-red"},null,3,"9r_0"),!(t.isLast??!1)&&n("div",null,{class:"absolute bottom-0 top-[calc(50%+20px)] border-l-2 border-secondary-red"},null,3,"9r_1"),n("div",null,{class:"flex h-[36px] w-[36px] items-center justify-center self-center rounded-full border border-secondary-red bg-transparent"},n("div",null,{class:"flex h-[30px] w-[30px] items-center justify-center rounded-full bg-secondary-red text-white"},u(e=>e.caption,[t],"p0.caption"),3,null),3,null)],1,"9r_2"),lp=t=>{const e=m(x(ap,"s_2AZJZ0GqJyo"));return(t.direction??"vertical")==="vertical"?n("div",null,{class:"grid w-fit items-center justify-around",style:u(a=>({gridTemplateColumns:(a.align??"start")==="center"?"1fr 60px 1fr":(a.align??"start")==="end"?"1fr 60px":"60px 1fr"}),[t],'{gridTemplateColumns:(p0.align??"start")==="center"?"1fr 60px 1fr":(p0.align??"start")==="end"?"1fr 60px":"60px 1fr"}')},t.steps.map((a,l)=>Z(o(Q,{children:[(t.align??"start")!=="center"&&o(Q,{children:[(t.align??"start")==="start"&&o(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_3"),n("div",null,{class:u(r=>`my-[20px] ${(r.align??"start")==="end"&&"ml-auto"} flex w-full flex-row items-center justify-center rounded-[50px] bg-white p-6 shadow-xl`,[t],'`my-[20px] ${(p0.align??"start")==="end"&&"ml-auto"} flex w-full flex-row items-center justify-center rounded-[50px] bg-white p-6 shadow-xl`')},o(I,{classN:"text-center",text:a,[s]:{classN:s}},3,"9r_4"),1,l),(t.align??"start")==="end"&&o(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_5")]},1,"9r_6"),(t.align??"start")==="center"&&o(Q,{children:[n("div",null,{class:"flex w-fit flex-row items-center rounded-[50px] bg-white px-6 py-10 shadow-lg"},o(I,{classN:"text-center",text:a,[s]:{classN:s}},3,"9r_7"),1,l),l%2===0?o(Q,{children:[o(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_8"),n("div",null,null,null,3,null),n("div",null,null,null,3,null),l+1<t.steps.length&&o(e,{caption:(l+2).toString(),isLast:l===t.steps.length},3,"9r_9")]},1,"9r_10"):o(Q,null,3,"9r_11")]},1,"9r_12")]},1,"9r_13"))),1,"9r_14"):n("div",null,{class:"flex flex-row justify-between"},t.steps.map((a,l)=>n("div",null,{class:"flex flex-col items-center"},[n("div",null,{class:"h-2 w-2 rounded-full bg-primary-blue"},null,3,null),n("div",null,{class:"text-primary-blue"},a,1,null)],1,l)),1,null)},Ie=m(x(lp,"s_Zd6X64AupUo")),np=t=>{const e=t.data.pageAcp.data.attributes,a=e.Steps.Bullets.map(l=>l.Text);return n("div",null,{onClick$:F("s_ey5yETkFTzM")},[o(Nt,{get data(){return e.SummaryPar},alt:!0,hasPricing:!1,textPercentage:50,[s]:{alt:s,data:f(e,"SummaryPar"),hasPricing:s,textPercentage:s}},3,"ai_0"),n("div",null,{class:"flex w-full items-center justify-center"},o(ep,{get info(){return e.InfoHowItWorks},get video(){return e.ACPVideo},[s]:{info:f(e,"InfoHowItWorks"),video:f(e,"ACPVideo")}},3,"ai_1"),1,null),n("div",null,{class:"mt-5 flex flex-col items-center justify-center bg-[#f2f6fb] pb-8"},[n("div",null,{class:"h-[32px] w-full bg-white opacity-70"},null,3,null),n("div",null,{class:"h-[32px] w-full bg-white opacity-40"},null,3,null),n("h2",null,{class:"px-6 pt-8 text-center text-[36px] font-[500] leading-9 text-primary-blue"},y(e.Steps,"Title"),1,null),n("div",null,{class:"px-6"},o(Ie,{steps:a},3,"ai_2"),1,null)],1,null)],1,"ai_3")},sp=m(x(np,"s_00vzGmbsaMs")),rp=t=>`
  query QueryACP {
    pageAcp(locale:"${t}"){    
      data{
        attributes{
        
          SummaryPar{
            Title
            Subtitle
            Paragraph
            Media{
              ${v}
            }
          }
          
          ACPVideo{
            Link
            Paragraph
          }
          
          InfoHowItWorks{
            Title
            Subtitle
            Paragraph
          
          }
          
          Steps{
            Title
            Bullets{
              Title
              Text
            }
          }
          
          ${R}
        }
      }
    }
  }
    `,ip=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(rp,e)},jl=A(x(ip,"s_R1neS1rgBX0")),op=()=>{const t=jl();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageAcp.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAcp.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAcp"]["data"]["attributes"]["SEO"]')}},3,"lm_0"),o(sp,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"lm_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"lm_2")},up=m(x(op,"s_clXmi6bmYdI")),cp=({resolveValue:t})=>{const a=t(jl).pageData.data.pageAcp.data.attributes.SEO;return H(a)},dp=Object.freeze(Object.defineProperty({__proto__:null,default:up,head:cp,usePageData:jl},Symbol.toStringTag,{value:"Module"})),pp=t=>{Z();const e=U(!0);return n("div",null,{class:"h-[550px] w-full  flex flex-col items-center justify-center"},[e.value?o(ue,{size:"250px",[s]:{size:s}},3,"a3_0"):null,n("iframe",null,{class:"w-3/4 my-4 h-full rounded-3xl",loading:"lazy",onLoad$:F("s_b0xkTBodv54",[e]),src:u(a=>a.data.iFrame_link,[t],'p0.data["iFrame_link"]')},null,3,null)],1,"a3_1")},gp=m(x(pp,"s_VzseIswtUxM")),fp=t=>`query QueryAprGive {
        pageAprGive(locale:"${t}"){
          data{
            attributes{
              iFrame_link
              ${R}
            }
          }
        }
        }`,xp=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(fp,e)},Il=A(x(xp,"s_xcQxq8lbgb0")),mp=()=>{const t=Il();return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageAprGive.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAprGive.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAprGive"]["data"]["attributes"]["SEO"]')}},3,"kA_0"),o(gp,{get data(){return t.value.pageData.data.pageAprGive.data.attributes},[s]:{data:u(e=>e.value.pageData.data.pageAprGive.data.attributes,[t],'p0.value["pageData"]["data"]["pageAprGive"]["data"]["attributes"]')}},3,"kA_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"kA_2")},1,"kA_3")},$p=m(x(mp,"s_Py5O2s07X3c")),hp=({resolveValue:t})=>{const a=t(Il).pageData.data.pageAprGive.data.attributes.SEO;return H(a)},bp=Object.freeze(Object.defineProperty({__proto__:null,default:$p,head:hp,usePageData:Il},Symbol.toStringTag,{value:"Module"})),vp=t=>{Z();const e=t.data.data.pageAprLead.data.attributes,a=U(!0);return n("div",null,{class:"flex flex-wrap px-8 items-center justify-center"},[n("div",null,{class:"flex flex-col items-center justify-center w-full md:w-1/2"},[n("div",null,{class:"relative h-[600px] w-[80%] flex flex-col items-center justify-center"},[n("img",{alt:y(e.zane_lead.bg_pic.data.attributes,"alternativeText"),src:G(e.zane_lead.bg_pic.data.attributes.url),title:y(e.zane_lead.bg_pic.data.attributes,"caption")},{class:"",height:"650",width:"650"},null,3,null),n("img",{alt:y(e.zane_lead.zane_pic.data.attributes,"alternativeText"),src:G(e.zane_lead.zane_pic.data.attributes.url)},{class:"absolute flex rounded-full h-3/4 w-auto",height:250,width:250},null,3,null),n("img",{src:G(e.zane_lead.tv_pic.data.attributes.url)},{alt:"",class:"absolute h-[10%] w-auto top-20 right-10",height:"50",width:"50"},null,3,null),n("img",{src:G(e.zane_lead.wifi_pic.data.attributes.url)},{alt:"",class:"absolute bottom-10 h-[10%] w-auto left-5",height:"50",width:"50"},null,3,null),n("img",{src:G(e.zane_lead.phone_pic.data.attributes.url)},{alt:"",class:"absolute top-10 left-10 h-[10%] w-auto",height:"50",width:"50"},null,3,null),n("div",null,{class:"absolute left-1/2 top-5 flex flex-row text-primary-blue bg-white items-center justify-center p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},o(z,{height:20,toWhite:!0,width:20,get url(){return e.zane_lead.give_pic.data.attributes.url},get alt(){return e.zane_lead.give_pic.data.attributes.alternativeText},[s]:{alt:f(e.zane_lead.give_pic.data.attributes,"alternativeText"),height:s,toWhite:s,url:f(e.zane_lead.give_pic.data.attributes,"url"),width:s}},3,"q7_0"),1,null),"Price"],1,null),n("div",null,{class:"absolute w-fit h-fit bottom-0 left-1/2 flex flex-row text-primary-blue bg-white items-center justify-evenly p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},o(z,{height:20,toWhite:!0,width:20,get url(){return e.zane_lead.auto_pic.data.attributes.url},get alt(){return e.zane_lead.auto_pic.data.attributes.alternativeText},[s]:{alt:f(e.zane_lead.auto_pic.data.attributes,"alternativeText"),height:s,toWhite:s,url:f(e.zane_lead.auto_pic.data.attributes,"url"),width:s}},3,"q7_1"),1,null),"Live Events"],1,null),n("div",null,{class:"absolute w-fit h-fit flex flex-row left-3/4 bottom-1/4 text-primary-blue bg-white items-center justify-evenly p-2 rounded-full"},[n("div",null,{class:"h-[25px] w-[25px] rounded-full  bg-secondary-red p-1"},o(z,{height:20,toWhite:!0,width:20,get url(){return e.zane_lead.cota_pic.data.attributes.url},get alt(){return e.zane_lead.cota_pic.data.attributes.alternativeText},[s]:{alt:f(e.zane_lead.cota_pic.data.attributes,"alternativeText"),height:s,toWhite:s,url:f(e.zane_lead.cota_pic.data.attributes,"url"),width:s}},3,"q7_2"),1,null),"Discounts"],1,null),n("div",null,{class:"absolute w-fit h-fit flex flex-row justify-evenly left-0  text-primary-blue bg-white items-center p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},o(z,{height:20,toWhite:!0,width:20,get url(){return e.zane_lead.auto_pic.data.attributes.url},get alt(){return e.zane_lead.auto_pic.data.attributes.alternativeText},[s]:{alt:f(e.zane_lead.auto_pic.data.attributes,"alternativeText"),height:s,toWhite:s,url:f(e.zane_lead.auto_pic.data.attributes,"url"),width:s}},3,"q7_3"),1,null),"Live Events"],1,null)],1,null),n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,{class:"text-xl text-center font-medium text-primary-blue"},y(e,"zane_description"),1,null),n("img",{src:G(e.zane_banner.banner_pic.data.attributes.url)},{alt:"",height:"78",width:"400"},null,3,null),n("div",null,{class:"flex flex-row items-center gap-5 justify-evenly my-5"},[n("div",null,{class:"bg-primary-blue text-white flex flex-col rounded-full items-center justify-center w-fit px-10 py-2"},[n("h2",null,{class:"text-sm text-center font-bold"},y(e.date_race,"Text"),1,null),n("p",null,{class:"text-sm text-center"},y(e.date_race,"Link"),1,null)],1,null),o(X,{get text(){return e.button_promo.text},get link(){return e.button_promo.link},[s]:{link:f(e.button_promo,"link"),text:f(e.button_promo,"text")}},3,"q7_4")],1,null)],1,null)],1,null),n("div",null,{class:"w-full md:w-2/6 shadow-2xl rounded-2xl h-[500px]"},[a.value?o(ue,{size:"250px",[s]:{size:s}},3,"q7_5"):null,n("iframe",{src:y(e,"iFrame_link")},{class:"w-full  rounded-2xl h-full",loading:"lazy",onLoad$:F("s_M94pZoIEeB0",[a])},null,3,null)],1,null)],1,"q7_6")},yp=m(x(vp,"s_0jvpiBD6mW4")),wp=t=>`query QueryPageAprLead {
        pageAprLead(locale:"${t}"){
          data {
            attributes {
              zane_lead {
                zane_pic {
                    ${v}
                }
                give_pic {
                    ${v}
                }
                cota_pic {
                    ${v}
                }
                auto_pic {
                    ${v}
                }
                live_pic {
                    ${v}
                }
                phone_pic {
                    ${v}
                }
                tv_pic {
                    ${v}
                }
                wifi_pic {
                    ${v}
                }
                bg_pic {
                    ${v}
                }
              }
              zane_banner {
                banner_pic {
                    ${v}
                }
              }
              zane_description
              iFrame_link
              date_race {
                Text
                Link
                Icon {
                  ${v}
                }
              }
              button_promo {
                text
                icon {
                  ${v}
                }
                link
              }
              pricing_box {
                Title
                Subtitle
                Pricing
                Period
                bg {
                  ${v}
                }
                Icon {
                  ${v}
                }
              }
              car {
                car_pic {
                  ${v}
                }
              }
              ${R}
              
            }
          }
        }
      }`,_p=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(wp,e)},El=A(x(_p,"s_05Sy9vG0VbY")),Tp=()=>{const t=El();return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageAprLead.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAprLead.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAprLead"]["data"]["attributes"]["SEO"]')}},3,"LY_0"),o(yp,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"LY_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"LY_2")},1,"LY_3")},Sp=m(x(Tp,"s_32Qq7YbePEg")),Dp=({resolveValue:t})=>{const a=t(El).pageData.data.pageAprLead.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},Pp=Object.freeze(Object.defineProperty({__proto__:null,default:Sp,head:Dp,usePageData:El},Symbol.toStringTag,{value:"Module"})),kp=t=>n("div",null,{class:"text-center"},[n("div",null,{class:"bg-primary-blue bg-opacity-40 p-6 h-[310px] w-[310px] inline-block items-center justify-center rounded-full"},n("div",null,{class:"bg-primary-blue flex h-full w-full items-center justify-center  rounded-full bg-opacity-60 px-6 py-6 shadow-md"},n("div",null,{class:"bg-primary-blue flex flex-col h-full w-full items-center justify-around rounded-full shadow-md"},[n("div",null,{class:"flex flex-col items-center"},[n("img",{src:G(t.award.Icon.data.attributes.url)},{alt:u(e=>e.award.Icon.data.attributes.alternativeText,[t],'p0.award["Icon"]["data"]["attributes"]["alternativeText"]'),height:40,title:u(e=>e.award.Icon.data.attributes.caption,[t],'p0.award["Icon"]["data"]["attributes"]["caption"]'),width:40},null,3,null),n("h2",null,{class:"text-l text-white font-semibold text-center"},u(e=>e.award.Title,[t],'p0.award["Title"]'),3,null),n("p",null,{class:"text-center text-sm font-light text-white leading-8"},u(e=>e.award.Award,[t],'p0.award["Award"]'),3,null)],1,null),n("a",null,{class:"text-white font-semibold",href:u(e=>e.award.Button.Link,[t],'p0.award["Button"]["Link"]'),target:"_blank"},u(e=>e.award.Button.Text,[t],'p0.award["Button"]["Text"]'),3,null)],1,null),1,null),1,null),n("h2",null,{class:"text-3xl font-semibold text-primary-blue"},u(e=>e.award.Year,[t],'p0.award["Year"]'),3,null)],1,"5M_0"),Lp=t=>{const e=t.data.data.pageAward.data.attributes,a=m(x(kp,"s_fwfHmjnV3nY")),l=e.Awards.map((r,i)=>o(a,{award:r},3,i));return n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"w-3/4"},[n("h1",null,{class:"text-center text-4xl font-bold text-primary-blue"},y(e,"Title"),1,null),o(I,{classN:"text-center",get text(){return e.Description},[s]:{classN:s,text:f(e,"Description")}},3,"5M_1")],1,null),n("div",null,{class:"w-full h-[500px] relative items-center justify-center overflow-hidden"},[n("div",null,{class:"h-full w-full absolute bg-opacity-50"},n("img",{alt:y(e.Background.data.attributes,"alternativeText"),src:G(e.Background.data.attributes.url)},{class:"object-fill opacity-50",height:500,width:1200},null,3,null),1,null),n("div",null,{class:"h-full w-full flex items-center justify-center absolute"},o(Bt,{duration:3e3,hasPagination:!0,id:"awardsSlider",slides:l,[s]:{duration:s,hasPagination:s,id:s}},3,"5M_2"),1,null)],1,null)],1,"5M_3")},Mp=m(x(Lp,"s_DHWUiZRKjUc")),Cp=t=>`query {
        pageAward(locale:"${t}"){
          data {
            attributes {
              Title
              Description
              
              Background {
                ${v}
              }
              
              Awards {
                Title
                Award
                Year
                Background {
                  ${v}
                }
                Icon {
                  ${v}
                }
                Button{
                  Text
                  Link
                }
              }
      
              ${R}
            }
          }
        }
      }`,jp=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(Cp,e)},Ol=A(x(jp,"s_sqeXWQdLNKw")),Ip=()=>{const t=Ol();return o(N,{get data(){return t.value.layoutData},children:o(Mp,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"Q2_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Q2_1")},Ep=m(x(Ip,"s_YOAlBnNiDxQ")),Op=({resolveValue:t})=>{const a=t(Ol).pageData.data.pageAward.data.attributes.SEO;return H(a)},Bp=Object.freeze(Object.defineProperty({__proto__:null,default:Ep,head:Op,usePageData:Ol},Symbol.toStringTag,{value:"Module"})),Ap=t=>{const e=(a,l)=>a.slice(0,l)+"...";return n("div",null,{class:"flex max-w-[1200px] flex-row-reverse items-center justify-center self-center px-8 py-4 max-[800px]:flex-col-reverse"},[n("div",null,{class:"flex  flex-col items-center justify-start  gap-4 px-10 min-[800px]:w-[60%]"},[n("div",null,{class:""},[n("div",null,{class:"text-[32px] font-[600] leading-10 text-[#2E5899] max-sm:text-[24px] max-sm:leading-7"},u(a=>a.post.Title,[t],'p0.post["Title"]'),3,null),n("div",null,null,o(I,{classN:"max-sm:text-[13px] text-[16px] text-[#2E5899] text-justify ",text:e(t.post.Description,500),[s]:{classN:s}},3,"su_0"),1,null)],1,null),o(X,{text:"Read More",get link(){return`/${t.post.Slug}/`},[s]:{link:u(a=>`/${a.post.Slug}/`,[t],'`/${p0.post["Slug"]}/`'),text:s}},3,"su_1")],1,null),n("div",null,{class:"flex w-full items-center justify-center self-center p-4 min-[800px]:w-[40%]"},o(z,{get url(){return t.post.Cover.data.attributes.url},get alt(){return t.post.Cover.data.attributes.alternativeText},get title(){return t.post.Cover.data.attributes.caption},clasN:"rounded-[50px] shadow-2xl",height:"894",width:"1184",[s]:{alt:u(a=>a.post.Cover.data.attributes.alternativeText,[t],'p0.post["Cover"]["data"]["attributes"]["alternativeText"]'),clasN:s,height:s,title:u(a=>a.post.Cover.data.attributes.caption,[t],'p0.post["Cover"]["data"]["attributes"]["caption"]'),url:u(a=>a.post.Cover.data.attributes.url,[t],'p0.post["Cover"]["data"]["attributes"]["url"]'),width:s}},3,"su_2"),1,null)],1,"su_3")},Sr=m(x(Ap,"s_KKagOAzP0DM")),qp=t=>{const e=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],a=["January","February","March","April","May","June","July","August","September","October","November","December"];function l(i){const c=e[i.getDay()],d=i.getDate(),p=a[i.getMonth()],g=i.getFullYear();return`${c}, ${p} ${d}, ${g}`}const r=(i,c)=>i.slice(0,c)+"...";return n("div",null,{class:"mb-8 flex max-w-[300px] flex-col",id:u(i=>i.id,[t],"p0.id")},[o(z,{clasN:"rounded-2xl self-center object-cover h-[200px] w-[300px]",height:"894",width:"1184",get url(){return t.post.attributes.Cover.data.attributes.url},get alt(){return t.post.attributes.Cover.data.attributes.alternativeText},get title(){return t.post.attributes.Cover.data.attributes.caption},[s]:{alt:u(i=>i.post.attributes.Cover.data.attributes.alternativeText,[t],'p0.post["attributes"]["Cover"]["data"]["attributes"]["alternativeText"]'),clasN:s,height:s,title:u(i=>i.post.attributes.Cover.data.attributes.caption,[t],'p0.post["attributes"]["Cover"]["data"]["attributes"]["caption"]'),url:u(i=>i.post.attributes.Cover.data.attributes.url,[t],'p0.post["attributes"]["Cover"]["data"]["attributes"]["url"]'),width:s}},3,"j0_0"),n("span",null,{class:"px-3 py-1 font-[600] text-primary-blue opacity-70"},l(new Date(t.post.attributes.Date)),1,null),n("span",null,{class:"px-3 text-primary-blue"},n("div",{dangerouslySetInnerHTML:Vn(r(t.post.attributes.Description,120))},{class:"flex list-inside flex-col gap-3 text-justify text-sm"},null,3,null),1,null),n("div",null,{class:"mt-2 self-center"},o(X,{text:"Read More",get link(){return`/${[t.post.attributes.Slug]}`},[s]:{link:u(i=>`/${[i.post.attributes.Slug]}`,[t],'`/${[p0.post["attributes"]["Slug"]]}`'),text:s}},3,"j0_1"),1,null)],1,"j0_2")},Np=m(x(qp,"s_KUqCzJ00kfw")),zp=t=>{var c;const a=(c=We().prevUrl)!=null&&c.pathname.includes("/es/")?"es-419":"en",l=U(t.posts.slice(1,(t.loadSize??6)+1)),r=U(!1),i=U(1);return n("div",{"document:onscroll$":F("s_t0DoAQDJl4Y",[a,r,i,t,l])},{class:"grid w-full max-w-[1200px] grid-cols-3 justify-evenly gap-4 max-[800px]:grid-cols-1 [&>*]:justify-self-center",id:"postLoader"},l.value.map((d,p)=>o(Np,{id:`post-${p.toString()}`,post:d},3,p)),0,"4a_0")},Dr=m(x(zp,"s_HS0GyQ0UHYM")),Rp=t=>n("div",null,{class:"flex flex-col items-center justify-center w-fit "},n("div",null,{class:"  px-2 mb-8  md:max-h-[150px]  overflow-y-scroll"},o(I,{classN:"text-[12.5px]",get text(){return t.slide.attributes.Content},[s]:{classN:s,text:u(e=>e.slide.attributes.Content,[t],'p0.slide["attributes"]["Content"]')}},3,"9l_0"),1,null),1,"9l_1"),Gp=t=>{const e=t.data.TechTips.data,a=m(x(Rp,"s_0D1CtJAueP4")),l=e.map((r,i)=>o(a,{slide:r},3,i));return n("div",null,{class:" gap-2 flex flex-row bg-white p-3 md:rounded-full rounded-3xl md:w-[750px] w-[90%] shadow-lg items-center"},[n("div",null,null,n("div",null,{class:"bg-[#2e5899] p-5 rounded-full shadow-lg md:min-h-[130px] md:max-w-[130px] md:max-h-[130px] max-w-[80px] flex justify-center items-center max-[768px]:hidden	"},n("div",null,{class:"bg-white md:p-5 p-2 w-fit h-fit items-center rounded-full shadow-lg shadow-inner"},o(id,{class:" md:w-[45px] md:h-[45px] w-[20px] h-[20px] fill-[#2e5899]",[s]:{class:s}},3,"9l_2"),1,null),1,null),1,null),n("div",null,{class:" justify-center items-center  md:w-[650px] max-w-[100%]"},[n("div",null,{class:"text-[18px] tracking-wide font-[600] leading-10 text-[#2E5899]"},u(r=>r.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"h-fit relative flex md:w-[650px] max-w-[90%]  items-center justify-center overflow-hidden   "},o(Bt,{addSpace:!1,hasArrows:!1,id:"techTipsCarousel",slides:l,slidesQty:1,[s]:{addSpace:s,hasArrows:s,id:s,slidesQty:s}},3,"9l_3"),1,null)],1,null)],1,"9l_4")},Qp=m(x(Gp,"s_600c5npFpQo")),Fp=t=>{const e=t.data.pageBlog.data.attributes,a=e.Posts.data[0].attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[o(Qp,{get data(){return e.Tips},[s]:{data:f(e,"Tips")}},3,"LH_0"),o(Sr,{post:a},3,"LH_1"),n("div",null,{class:"my-4"},null,3,null),o(Dr,{get posts(){return e.Posts.data},loadSize:3,type:"Blog",[s]:{loadSize:s,posts:f(e.Posts,"data"),type:s}},3,"LH_2")],1,"LH_3")},Hp=m(x(Fp,"s_lTYqJJcPHc4")),Wp=t=>` query QueryBlog {
        pageBlog(locale:"${t}"){    
          data{
          attributes{
            Tips{
              Title
              TechTips(sort: "Date:desc", pagination: { limit: 10 }){
                data{
                  attributes{
                    Content
                  }
                }
              }
            }
            Posts(sort: "Date:desc", pagination: { limit: 100 }){
                data{
                  attributes{
                    Title
                    Date
                    Cover{
                      ${v}
                    }
                    Description
                    VideoLink
                    Gallery{
                      ${v}
                    }
                    Slug
                  }
                }
              }
          
            ${R}
          }
        }
        }
      }`,Up=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(Wp,e)},Bl=A(x(Up,"s_PlB05JNPqRo")),Vp=()=>{const t=Bl();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageBlog.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageBlog.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBlog"]["data"]["attributes"]["SEO"]')}},3,"Yn_0"),o(Hp,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Yn_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Yn_2")},Yp=m(x(Vp,"s_WiOXv30Ec4Y")),Zp=({resolveValue:t})=>{const a=t(Bl).pageData.data.pageBlog.data.attributes.SEO;return H(a)},Jp=Object.freeze(Object.defineProperty({__proto__:null,default:Yp,head:Zp,usePageData:Bl},Symbol.toStringTag,{value:"Module"})),Xp=t=>n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} bg-opacity-40 p-6 ${e.height??""} ${e.width??""} inline-block items-center justify-center rounded-full`,[t],'`${p0.color??"bg-[#2E5899]"} bg-opacity-40 p-6 ${p0.height??""} ${p0.width??""} inline-block items-center justify-center rounded-full`')},n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md`,[t],'`${p0.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md`')},n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md`,[t],'`${p0.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md`')},n("img",{src:G(t.url)},{alt:u(e=>e.alt??"",[t],'p0.alt??""'),class:"h-full w-full rounded-full object-cover",height:250,title:u(e=>e.title??"",[t],'p0.title??""'),width:250},null,3,null),1,null),1,null),1,"03_0"),Ee=m(x(Xp,"s_CA0rJqJDom0")),Kp=t=>n("div",null,{class:"flex w-fit flex-wrap gap-12 md:gap-20 m-5 items-center justify-center"},t.data.MembersGrid.map((e,a)=>Z(n("div",null,{class:"w-[300px] h-[300px] items-center justify-around flex flex-col"},[o(Ee,{height:"h-[200px]",width:"w-[200px]",get url(){return e.Picture.data.attributes.url},get alt(){return e.Picture.data.attributes.alternativeText},get title(){return e.Picture.data.attributes.caption},[s]:{alt:f(e.Picture.data.attributes,"alternativeText"),height:s,title:f(e.Picture.data.attributes,"caption"),url:f(e.Picture.data.attributes,"url"),width:s}},3,"Q1_0"),n("h2",null,{class:"font-bold text-primary-blue text-xl"},[y(e,"FirstName")," ",y(e,"LastName")],1,null),n("p",null,{class:"text-sm text-primary-blue"},y(e,"Position"),1,null),e.SocialMedia.length>0&&n("a",{href:y(e.SocialMedia[0],"Link")},null,n("div",null,{class:"h-[30px] w-[30px] flex items-center justify-center bg-white shadow rounded-full p-1.5"},o(Wc,{class:"fill-primary-blue",[s]:{class:s}},3,"Q1_1"),1,null),1,"Q1_2")],1,a))),1,"Q1_3"),Pr=m(x(Kp,"s_fHxbC9gELko")),t0=t=>`query QueryBoardOfDirectors{
        pageBDirectors(locale:"${t}"){
          data{
            attributes{
              ${$r}
              ${R}
              }
            }
          }
        }`,e0=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(t0,e)},Al=A(x(e0,"s_zIMYdRdJ00w")),a0=()=>{const t=Al(),e=t.value.pageData.data.pageBDirectors.data.attributes;return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageBDirectors.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageBDirectors.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBDirectors"]["data"]["attributes"]["SEO"]')}},3,"ts_0"),o(Pr,{data:e},3,"ts_1")],showHeader:!0,[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"ts_2")},1,"ts_3")},l0=m(x(a0,"s_IBN44L8LT0g")),n0=({resolveValue:t})=>{const a=t(Al).pageData.data.pageBDirectors.data.attributes.SEO;return H(a)},s0=Object.freeze(Object.defineProperty({__proto__:null,default:l0,head:n0,usePageData:Al},Symbol.toStringTag,{value:"Module"})),r0=t=>{const e=t.data.pageBusiness.data.attributes.Services;return n("div",null,null,o(Xt,{data:e},3,"zl_0"),1,"zl_1")},i0=m(x(r0,"s_u188pr8UG0M")),o0=t=>`query QueryBusiness {
    pageBusiness(locale:"${t}"){    
      data{
        attributes{
          Services{
            Logo{
              ${v}
            }
            Media{
              ${v}
            }
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
             ${R}
  
        }
      }
    }
  }`,u0=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(o0,e)},ql=A(x(u0,"s_oQUmv8Ne7NI")),c0=()=>{const t=ql();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageBusiness.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageBusiness.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBusiness"]["data"]["attributes"]["SEO"]')}},3,"Uj_0"),o(i0,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Uj_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Uj_2")},d0=m(x(c0,"s_JufSC5OrOV4")),p0=({resolveValue:t})=>{const a=t(ql).pageData.data.pageBusiness.data.attributes.SEO;return H(a)},g0=Object.freeze(Object.defineProperty({__proto__:null,default:d0,head:p0,usePageData:ql},Symbol.toStringTag,{value:"Module"})),f0=t=>n("div",null,{class:"relative flex w-full items-center justify-center"},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 z-10 grid",style:{gridTemplateRows:"35px 35px 1fr 35px 35px",gridTemplateColumns:"100%"}},[n("div",null,{class:"bg-white opacity-50"},null,3,null),n("div",null,{class:"bg-white opacity-80"},null,3,null),n("div",null,{class:"bg-white "},null,3,null),n("div",null,{class:"bg-white opacity-80"},null,3,null),n("div",null,{class:"bg-white opacity-50"},null,3,null)],3,null),n("div",null,{class:"z-10 flex flex-wrap items-center justify-center px-8 text-center text-[30px] font-[700] text-primary-blue"},[o(z,{clasN:"w-[300px] max-[1000px]:hidden",get url(){return t.data.HeaderPictures.data[0].attributes.url},get alt(){return t.data.HeaderPictures.data[0].attributes.alternativeText},get title(){return t.data.HeaderPictures.data[0].attributes.caption},[s]:{alt:u(e=>e.data.HeaderPictures.data[0].attributes.alternativeText,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]["alternativeText"]'),clasN:s,title:u(e=>e.data.HeaderPictures.data[0].attributes.caption,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]["caption"]'),url:u(e=>e.data.HeaderPictures.data[0].attributes.url,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]["url"]')}},3,"bE_0"),n("div",null,{class:"flex flex-col"},[n("span",null,null,"Join the",3,null),o(z,{clasN:"w-[200px]",get url(){return t.data.HeaderLogo.data.attributes.url},get alt(){return t.data.HeaderLogo.data.attributes.alternativeText},get title(){return t.data.HeaderLogo.data.attributes.caption},[s]:{alt:u(e=>e.data.HeaderLogo.data.attributes.alternativeText,[t],'p0.data["HeaderLogo"]["data"]["attributes"]["alternativeText"]'),clasN:s,title:u(e=>e.data.HeaderLogo.data.attributes.caption,[t],'p0.data["HeaderLogo"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.HeaderLogo.data.attributes.url,[t],'p0.data["HeaderLogo"]["data"]["attributes"]["url"]')}},3,"bE_1"),n("span",null,null,"Family",3,null)],1,null),o(z,{clasN:"w-[300px]",get url(){return t.data.HeaderPictures.data[1].attributes.url},get alt(){return t.data.HeaderPictures.data[1].attributes.alternativeText},get title(){return t.data.HeaderPictures.data[1].attributes.caption},[s]:{alt:u(e=>e.data.HeaderPictures.data[1].attributes.alternativeText,[t],'p0.data["HeaderPictures"]["data"][1]["attributes"]["alternativeText"]'),clasN:s,title:u(e=>e.data.HeaderPictures.data[1].attributes.caption,[t],'p0.data["HeaderPictures"]["data"][1]["attributes"]["caption"]'),url:u(e=>e.data.HeaderPictures.data[1].attributes.url,[t],'p0.data["HeaderPictures"]["data"][1]["attributes"]["url"]')}},3,"bE_2")],1,null)],1,"bE_3"),x0=m(x(f0,"s_YWCAmY4twe0")),m0=t=>n("div",null,{class:"flex h-[250px] w-[170px] flex-col items-center justify-start gap-3 rounded-[16px] bg-white p-3 text-center shadow-lg"},[o(z,{clasN:"h-[80px] w-[100%] object-cover rounded-[16px] bg-primary-blue bg-opacity-10",get url(){return t.offer.Media.data.attributes.url},get alt(){return t.offer.Media.data.attributes.alternativeText},get title(){return t.offer.Media.data.attributes.caption},height:"120",width:"240",[s]:{alt:u(e=>e.offer.Media.data.attributes.alternativeText,[t],'p0.offer["Media"]["data"]["attributes"]["alternativeText"]'),clasN:s,height:s,title:u(e=>e.offer.Media.data.attributes.caption,[t],'p0.offer["Media"]["data"]["attributes"]["caption"]'),url:u(e=>e.offer.Media.data.attributes.url,[t],'p0.offer["Media"]["data"]["attributes"]["url"]'),width:s}},3,"IA_0"),n("h3",null,{class:"text-[18px] font-[600]"},u(e=>e.offer.Title,[t],'p0.offer["Title"]'),3,null),n("p",null,{class:"text-[14px] font-[400]"},u(e=>e.offer.Paragraph,[t],'p0.offer["Paragraph"]'),3,null)],1,"IA_1"),$0=t=>{const e=m(x(m0,"s_7vgX9wWJy0Y"));return n("div",null,{class:"flex w-full justify-center px-8"},n("div",null,{class:"mt-10 flex max-w-[1400px] items-center justify-center gap-8 px-8 text-center text-primary-blue max-[1000px]:flex-col"},[n("div",null,{class:"flex w-[50%] flex-col max-[1000px]:w-[100%]"},[n("h3",null,{class:"mt-3 text-[40px] font-[700]"},u(a=>a.data.BeliefsTitle,[t],'p0.data["BeliefsTitle"]'),3,null),n("span",null,{class:"text-[28px] font-[600]"},u(a=>a.data.BeliefsSubtitle,[t],'p0.data["BeliefsSubtitle"]'),3,null),n("span",null,{class:"text-[26px] font-[600] text-secondary-red"},u(a=>a.data.Beliefs[0].Text,[t],'p0.data["Beliefs"][0]["Text"]'),3,null),n("p",null,{class:"mt-3 text-[20px]"},u(a=>a.data.BeliefsDescription,[t],'p0.data["BeliefsDescription"]'),3,null)],3,null),n("div",null,{class:"flex w-[50%] flex-col items-center justify-center max-[1000px]:w-[100%]"},[n("h4",null,{class:"text-[40px] font-[700]"},u(a=>a.data.OfferingTitle,[t],'p0.data["OfferingTitle"]'),3,null),n("div",null,{class:"mt-4 flex flex-wrap justify-center gap-6"},t.data.Offerings.map((a,l)=>o(e,{offer:a},3,l)),1,null)],1,null)],1,null),1,"IA_2")},h0=m(x($0,"s_rLVOk7WyC5I")),b0=()=>{const[t]=et();t.showSignal.value=!1},v0=t=>n("div",{class:`fixed inset-0 z-[500] flex items-center justify-center bg-primary-dark-blue bg-opacity-20 transition-all duration-300 ${t.showSignal.value?"":"hidden"}`},null,[o(hr,{class:"absolute right-2 top-2 rounded-full bg-secondary-red p-1 text-[30px] font-[200] text-white hover:cursor-pointer",onClick$:x(b0,"s_AR3wQHs8a3I",[t]),[s]:{class:s,onClick$:s}},3,"kj_0"),o(st,null,3,"kj_1")],1,"kj_2"),Un=m(x(v0,"s_oHrF0mun03M")),y0=t=>{const e=U("duties");return n("div",null,{class:"flex w-[60%] min-w-[310px] max-w-[550px] flex-col items-center rounded-[50px] bg-white p-8 text-primary-blue"},[n("div",null,{class:"mb-2 flex items-center gap-1"},[o(Cl,{class:"text-secondary-red",[s]:{class:s}},3,"H3_0"),n("span",null,{class:"text-[14px] opacity-60"},u(a=>a.data.Location,[t],'p0.data["Location"]'),3,null)],1,null),n("h4",null,{class:"mb-4 text-center text-[20px] font-[600] leading-7 text-primary-dark-blue"},u(a=>a.data.Name,[t],'p0.data["Name"]'),3,null),n("div",null,{class:"relative my-4 flex w-[300px] justify-between gap-2 overflow-hidden rounded-[30px] border border-primary-blue border-opacity-60 px-6 py-2"},[n("div",{class:`absolute bottom-0 transition-all ${e.value==="duties"?"left-0 right-[55%]":"left-[45%] right-0"} top-0 z-[1] rounded-[30px] bg-primary-blue shadow-sm`},null,null,3,null),n("div",null,{class:"z-[2] flex w-[45%] cursor-pointer items-center gap-1 px-2",onClick$:F("s_m2mi5sfy3GQ",[e])},[n("div",null,{class:"flex h-6 w-6 items-center justify-center rounded-full bg-white p-1"},o(Yc,{class:"text-secondary-red",[s]:{class:s}},3,"H3_1"),1,null),n("span",null,{class:u(a=>`font-[400] text-${a.value==="duties"?"white":"primary-blue"}`,[e],'`font-[400] text-${p0.value==="duties"?"white":"primary-blue"}`')},"Duties",3,null)],1,null),n("div",null,{class:"z-[2] flex w-[55%] cursor-pointer items-center gap-1 px-2",onClick$:F("s_ynhdzdQwHCA",[e])},[n("div",null,{class:"flex h-6 w-6 items-center justify-center rounded-full bg-white p-1"},o(Zc,{class:"text-secondary-red",[s]:{class:s}},3,"H3_2"),1,null),n("span",null,{class:u(a=>`font-[400] text-${a.value==="qualifications"?"white":"primary-blue"}`,[e],'`font-[400] text-${p0.value==="qualifications"?"white":"primary-blue"}`')},"Qualifications",3,null)],1,null)],1,null),n("div",null,{class:"relative flex h-[200px] w-full overflow-x-hidden text-[13px] leading-4 transition-all "},[n("div",null,{class:u(a=>`absolute h-[200px] w-full p-4 transition-all ${a.value!=="duties"?"right-full":" right-0"}`,[e],'`absolute h-[200px] w-full p-4 transition-all ${p0.value!=="duties"?"right-full":" right-0"}`')},o(I,{get text(){return t.data.Duties},[s]:{text:u(a=>a.data.Duties,[t],'p0.data["Duties"]')}},3,"H3_3"),1,null),n("div",null,{class:u(a=>`absolute h-[200px] w-full p-4 transition-all ${a.value!=="qualifications"?"left-full":"left-0"}`,[e],'`absolute h-[200px] w-full p-4 transition-all ${p0.value!=="qualifications"?"left-full":"left-0"}`')},o(I,{get text(){return t.data.Qualifications},[s]:{text:u(a=>a.data.Qualifications,[t],'p0.data["Qualifications"]')}},3,"H3_4"),1,null)],1,null)],1,"H3_5")},w0=m(x(y0,"s_kNPEZsb0EOk")),_0=()=>{const[t]=et();t.value=!0},T0=t=>{const[e,a,l]=et();return n("div",null,{class:"flex h-[380px] w-[460px] flex-col justify-between rounded-[30px] bg-white p-6 text-center shadow-lg max-[800px]:h-[280px] "},[n("div",null,{class:"flex-col items-center"},[n("div",null,{class:"flex items-center justify-center gap-2"},[o(Cl,null,3,"At_0"),n("span",null,{class:"font-[500] opacity-60"},u(r=>r.position.Location,[t],'p0.position["Location"]'),3,null)],1,null),n("h4",null,{class:"mt-2 text-[19px] font-[700] text-primary-dark-blue"},u(r=>r.position.Name,[t],'p0.position["Name"]'),3,null),o(I,{classN:"text-[15px] max-[800px]:text-[13px]",get text(){return t.position.Summary},[s]:{classN:s,text:u(r=>r.position.Summary,[t],'p0.position["Summary"]')}},3,"At_1")],1,null),n("div",null,{class:"flex flex-col items-center gap-2"},[n("div",null,{class:"flex gap-1 text-[15px]"},[n("span",null,{class:"text-btn-green hover:cursor-pointer",onClick$:F("s_d5LXfHtAyog",[a,t,l])},"Learn more",3,null)," ",n("span",null,{class:"text-black"},"or",3,null)],3,null),o(X,{onClick:e,text:"Submit Resume",[s]:{onClick:s,text:s}},3,"At_2")],1,null)],1,"At_3")},S0=t=>{const e=U(!1),a=U(!1),l=U(t.data.Positions[0].attributes),i=m(x(T0,"s_MLxpYci0h0Y",[x(_0,"s_DxkiX1SABig",[e]),a,l])),c=t.data.Positions.map((d,p)=>o(i,{get position(){return d.attributes},[s]:{position:f(d,"attributes")}},3,p));return n("div",null,{class:"my-8 flex justify-center text-primary-blue"},[o(Un,{children:o(wr,null,3,"At_4"),showSignal:e,[s]:{showSignal:s}},1,"At_5"),o(Un,{children:o(w0,{get data(){return l.value},[s]:{data:u(d=>d.value,[l],"p0.value")}},3,"At_6"),showSignal:a,[s]:{showSignal:s}},1,"At_7"),n("div",null,{class:"flex flex-col "},[n("h3",null,{class:"text-center text-[44px] font-[600]"},u(d=>d.data.PositionsTitle,[t],'p0.data["PositionsTitle"]'),3,null),n("div",null,{class:"flex-column flex w-[1200px] "},o(Bt,{hasArrows:!0,hasPagination:!1,id:"carPositions",slides:c,slidesQty:3,[s]:{hasArrows:s,hasPagination:s,id:s,slidesQty:s}},3,"At_8"),1,null)],1,null)],1,"At_9")},D0=m(x(S0,"s_Su5lXmtHgW0")),P0=t=>{const e=t.data.pageCareers.data.attributes;return n("div",null,{onClick$:F("s_yJsNttxIAPY")},[o(x0,{data:{HeaderLogo:t.data.pageCareers.data.attributes.HeaderLogo,HeaderTitle:t.data.pageCareers.data.attributes.HeaderTitle,HeaderPictures:t.data.pageCareers.data.attributes.HeaderPictures}},3,"a0_0"),o(h0,{data:{Beliefs:t.data.pageCareers.data.attributes.Beliefs,BeliefsDescription:t.data.pageCareers.data.attributes.BeliefsDescription,BeliefsSubtitle:t.data.pageCareers.data.attributes.BeliefsSubtitle,BeliefsTitle:t.data.pageCareers.data.attributes.BeliefsTitle,Offerings:t.data.pageCareers.data.attributes.Offerings,OfferingTitle:t.data.pageCareers.data.attributes.OfferingTitle}},3,"a0_1"),n("div",null,{class:"flex w-full justify-center px-8"},n("div",null,{class:"max-w-[1200px] text-center text-primary-blue"},[n("h3",null,{class:"mb-4 mt-16 text-[38px] font-[800]"},y(e.FormParagraph,"Title"),1,null),o(I,{get text(){return e.FormParagraph.Paragraph},classN:"text-[18px] font-[400]",[s]:{classN:s,text:f(e.FormParagraph,"Paragraph")}},3,"a0_2")],1,null),1,null),o(D0,{data:{Positions:e.Positions.data,PositionsTitle:e.PositionsTitle}},3,"a0_3")],1,"a0_4")},k0=m(x(P0,"s_CHSZKaaPR2c")),L0=t=>`query QueryCareers {
    pageCareers(locale:"${t}"){    
      data{
        attributes{
                  HeaderLogo{
                    ${v}
                  }
          HeaderPictures{
            ${v}
          }
          HeaderBackground{
           ${v}
          }
          HeaderTitle{
            Text
          }
          
          
          BeliefsTitle
          BeliefsSubtitle
          Beliefs{
            Text
          }
          BeliefsDescription
          
          
          OfferingTitle
          Offerings{
            Title
            Paragraph
            Media{
              ${v}
            }
          }
          
          PositionsTitle
          Positions(sort: "Name:Asc"){
            data{
              attributes{
                Location
                Name
                Summary
                Duties
                Qualifications
              }
            }
          }
          
          FormParagraph{
            Title
            Paragraph
          }
          FormCareers{
            Title
            Fields{
              Label
              Icon{
                ${v}
              }
            }
            ActionButton{
              Text
              Link
            }
          }
        ${R}
        }
      }
    }
  }`,M0=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(L0,e)},Nl=A(x(M0,"s_bBcTtiHl1Tw")),C0=()=>{const t=Nl();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageCareers.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageCareers.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageCareers"]["data"]["attributes"]["SEO"]')}},3,"sa_0"),o(k0,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"sa_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"sa_2")},j0=m(x(C0,"s_KylSGhTDLNs")),I0=({resolveValue:t})=>{const a=t(Nl).pageData.data.pageCareers.data.attributes.SEO;return H(a)},E0=Object.freeze(Object.defineProperty({__proto__:null,default:j0,head:I0,usePageData:Nl},Symbol.toStringTag,{value:"Module"})),O0=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),o(I,{get text(){return t.data.TextContent},classN:"markdownTitle markdownh3 markdownHyper tracking-wider flex text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"27_0")],1,"27_1"),B0=m(x(O0,"s_qLAYw5vO9og")),A0=t=>`query QuerySupplement {
        pageSuppleTerms(locale:"${t}"){    
          ${Ue}
          ${R}
            }
          }
        }
      }`,q0=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(A0,e)},zl=A(x(q0,"s_LHhYaz4wQcQ")),N0=()=>{const t=zl(),e=t.value.pageData.data.pageSuppleTerms.data.attributes.Content;return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:o(B0,{data:e},3,"NP_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"NP_1")},1,"NP_2")},z0=m(x(N0,"s_2WfoIGYZZ0E")),R0=({resolveValue:t})=>{const a=t(zl).pageData.data.pageSuppleTerms.data.attributes.SEO;return H(a)},G0=Object.freeze(Object.defineProperty({__proto__:null,default:z0,head:R0,usePageData:zl},Symbol.toStringTag,{value:"Module"})),Q0=t=>n("div",null,{class:"flex flex-col py-10 items-center justify-center"},[n("h1",null,{class:"text-2xl sm:text-4xl font-bold text-primary-blue"},u(e=>e.data.Introduction.Title,[t],'p0.data["Introduction"]["Title"]'),3,null),n("p",null,{class:"text-primary-blue text-center text-[16px] md:text-[18px] m-5"},u(e=>e.data.Introduction.Paragraph,[t],'p0.data["Introduction"]["Paragraph"]'),3,null),o(X,{get text(){return t.data.Introduction.Buttons[0].Text},get link(){return t.data.Introduction.Buttons[0].Link},[s]:{link:u(e=>e.data.Introduction.Buttons[0].Link,[t],'p0.data["Introduction"]["Buttons"][0]["Link"]'),text:u(e=>e.data.Introduction.Buttons[0].Text,[t],'p0.data["Introduction"]["Buttons"][0]["Text"]')}},3,"wL_0"),n("div",null,{class:"flex flex-col items-center gap-2 px-4 py-4 my-10"},[n("p",null,{class:"text-xl sm:text-2xl font-bold text-primary-blue"},u(e=>e.data.SocialMedia.Text,[t],'p0.data["SocialMedia"]["Text"]'),3,null),n("div",null,{class:"flex flex-row gap-4"},t.data.SocialMedia.SubOption.map((e,a)=>Z(o(we,{get href(){return e.Link},children:[e.Link.includes("facebook")&&n("div",null,{class:"flex w-[50px] h-[50px] items-center justify-center rounded-full bg-primary-blue p-4"},o(z,{get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},toWhite:!0,[s]:{alt:f(e.Icon.data.attributes,"alternativeText"),title:f(e.Icon.data.attributes,"caption"),toWhite:s,url:f(e.Icon.data.attributes,"url")}},3,"wL_1"),1,"wL_2"),!e.Link.includes("facebook")&&n("div",null,{class:"flex w-[50px] h-[50px] items-center justify-center rounded-full bg-primary-blue p-3"},o(z,{get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},toWhite:!0,[s]:{alt:f(e.Icon.data.attributes,"alternativeText"),title:f(e.Icon.data.attributes,"caption"),toWhite:s,url:f(e.Icon.data.attributes,"url")}},3,"wL_3"),1,"wL_4")],[s]:{href:f(e,"Link")}},1,a))),1,null)],1,null),n("div",null,{class:"flex flex-col items-center justify-center"},[n("h2",null,{class:"text-xl sm:text-2xl font-bold text-primary-blue"},u(e=>e.data.OfficesTitle,[t],'p0.data["OfficesTitle"]'),3,null),n("div",null,{class:"flex flex-wrap gap-8 mt-5 justify-center items-start"},t.data.OfficesLocation.map((e,a)=>n("div",null,{class:"flex flex-col w-[200px]"},[n("a",{href:y(e.Buttons[0],"Link")},{class:"font-bold text-secondary-red"},y(e.Buttons[0],"Text"),1,null),n("a",{href:y(e.Buttons[1],"Link")},{class:"font-bold text-primary-blue"},y(e.Buttons[1],"Text"),1,null),n("p",null,{class:"tracking-wide font-normal text-sm text-primary-blue"},y(e,"Paragraph"),1,null)],1,a)),1,null)],1,null)],1,"wL_5"),F0=m(x(Q0,"s_5L0HuXf9QnQ")),H0=t=>`query QueryContactUs{
        pageContact(locale:"${t}"){
          data{
            attributes{
              Introduction{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              SocialMedia{
                Text
                SubOption{
                  Text
                  Link
                  Icon{
                    ${v}
                  }
                }
              }
              
              OfficesTitle
              OfficesLocation{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              ${R}
            }
          }
        }
      }`,W0=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(H0,e)},Rl=A(x(W0,"s_QdheZerij2w")),U0=()=>{const t=Rl(),e=t.value.pageData.data.pageContact.data.attributes;return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:o(F0,{data:e},3,"yX_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"yX_1")},1,"yX_2")},V0=m(x(U0,"s_FZeWA02p0TI")),Y0=({resolveValue:t})=>{const a=t(Rl).pageData.data.pageContact.data.attributes.SEO;return H(a)},Z0=Object.freeze(Object.defineProperty({__proto__:null,default:V0,head:Y0,usePageData:Rl},Symbol.toStringTag,{value:"Module"})),J0=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),o(I,{get text(){return t.data.TextContent},classN:"markdownTitle markdownHyper tracking-wider text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"NS_0")],1,"NS_1"),X0=m(x(J0,"s_gvsFRD0Vfkk")),K0=t=>`
query QueryCookies {
  pageCookies(locale:"${t}"){    
    ${Ue}
    ${R}
      }
    }
  }
}`,tg=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(K0,e)},Gl=A(x(tg,"s_IqhWiqyXb00")),eg=()=>{const t=Gl(),e=t.value.pageData.data.pageCookies.data.attributes.Content;return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:o(X0,{data:e},3,"wB_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"wB_1")},1,"wB_2")},ag=m(x(eg,"s_OmN9OIo5qbs")),lg=({resolveValue:t})=>{const a=t(Gl).pageData.data.pageCookies.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},ng=Object.freeze(Object.defineProperty({__proto__:null,default:ag,head:lg,usePageData:Gl},Symbol.toStringTag,{value:"Module"})),sg=t=>(Z(),t.url.includes(".mp4")?n("video",{src:G(t.url)},{autoPlay:u(e=>e.autoplay??!1,[t],"p0.autoplay??false"),class:u(e=>(e.toWhite??!1?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(e.clasN??""),[t],'(p0.toWhite??false?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(p0.clasN??"")'),controls:u(e=>e.controls??!1,[t],"p0.controls??false"),height:u(e=>e.height,[t],"p0.height"),loop:u(e=>e.loop??!0,[t],"p0.loop??true"),muted:u(e=>e.muted??!0,[t],"p0.muted??true"),width:u(e=>e.width,[t],"p0.width")},null,3,"kf_0"):o(z,{get url(){return t.url},get width(){return t.width},get height(){return t.height},get alt(){return t.alt??""},get title(){return t.title??""},get toWhite(){return t.toWhite??!1},get clasN(){return t.clasN??""},[s]:{alt:u(e=>e.alt??"",[t],'p0.alt??""'),clasN:u(e=>e.clasN??"",[t],'p0.clasN??""'),height:u(e=>e.height,[t],"p0.height"),title:u(e=>e.title??"",[t],'p0.title??""'),toWhite:u(e=>e.toWhite??!1,[t],"p0.toWhite??false"),url:u(e=>e.url,[t],"p0.url"),width:u(e=>e.width,[t],"p0.width")}},3,"kf_1")),Za=m(x(sg,"s_GG0oZTUUfNc")),rg=t=>n("div",null,{class:"flex w-full flex-col items-center justify-center text-primary-blue"},n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center px-10 min-[800px]:w-[70%]"},[n("span",null,{class:"text-center text-[38px] font-[800] text-secondary-red max-[800px]:text-[30px]"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),o(I,{classN:"mb-3 w-full bg-primary-blue p-2 font-[600] text-[26px] max-[800px]:text-[20px] text-white text-center mx-4 rounded-full",get text(){return t.data.Description},[s]:{classN:s,text:u(e=>e.data.Description,[t],'p0.data["Description"]')}},3,"Sf_0"),o(I,{classN:"text-center text-[26px]",get text(){return t.data.Deal},[s]:{classN:s,text:u(e=>e.data.Deal,[t],'p0.data["Deal"]')}},3,"Sf_1"),o(I,{classN:"text-center text-[18px] mb-3",get text(){return t.data.Deals_description},[s]:{classN:s,text:u(e=>e.data.Deals_description,[t],'p0.data["Deals_description"]')}},3,"Sf_2"),n("div",null,{class:"mb-3 flex items-start justify-evenly gap-4 max-[600px]:flex-col"},t.data.Services.map((e,a)=>n("div",null,{class:"flex items-center justify-center gap-1"},[o(Za,{get url(){return e.Icon.data.attributes.url},clasN:"w-[100px] max-[1000px]:w-[80px] ",muted:!0,[s]:{clasN:s,muted:s,url:f(e.Icon.data.attributes,"url")}},3,"Sf_3"),n("span",null,{class:"font-[600]"},y(e,"Title"),1,null)],1,a)),1,null),o(X,{get text(){return t.data.Button.Text},get link(){return t.data.Button.Link},[s]:{link:u(e=>e.data.Button.Link,[t],'p0.data["Button"]["Link"]'),text:u(e=>e.data.Button.Text,[t],'p0.data["Button"]["Text"]')}},3,"Sf_4")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 max-[600px]:hidden min-[800px]:w-[30%]"},o(Za,{get url(){return t.data.Media.data.attributes.url},autoplay:!0,clasN:"rounded-full  mr-[30px]",loop:!0,muted:!0,[s]:{autoplay:s,clasN:s,loop:s,muted:s,url:u(e=>e.data.Media.data.attributes.url,[t],'p0.data["Media"]["data"]["attributes"]["url"]')}},3,"Sf_5"),1,null)],1,null),1,"Sf_6"),ig=m(x(rg,"s_4av0zjglZmk")),og=t=>n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"min-h-[200px] w-full bg-gradient-to-br from-primary-light-blue to-[#23477f] !text-white"},o(Nt,{get data(){return t.data},backgroundColor:"primary-blue",color:"white",[s]:{backgroundColor:s,color:s,data:u(e=>e.data,[t],"p0.data")}},3,"tV_0"),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"tV_1"),ug=m(x(og,"s_cJop3g0b1vg")),cg=t=>n("div",null,{class:"flex w-full items-center justify-center"},n("div",null,{class:"flex max-w-[1200px] flex-wrap items-start justify-evenly gap-6 p-8"},t.data.map((e,a)=>n("div",null,{class:"flex w-[280px] flex-col items-center gap-2"},[o(Ee,{get url(){return e.Media.data.attributes.url},color:a%2===0?"bg-[#2E5899]":"bg-secondary-red",height:"a",width:"250px",get alt(){return e.Media.data.attributes.alternativeText},get title(){return e.Media.data.attributes.caption},[s]:{alt:f(e.Media.data.attributes,"alternativeText"),height:s,title:f(e.Media.data.attributes,"caption"),url:f(e.Media.data.attributes,"url"),width:s}},3,"lG_0"),o(I,{get text(){return e.Title},classN:"font-[600] text-center text-[18px] tracking-[-1px]",[s]:{classN:s,text:f(e,"Title")}},3,"lG_1"),o(I,{get text(){return e.Paragraph},classN:"text-center text-[16px]",[s]:{classN:s,text:f(e,"Paragraph")}},3,"lG_2")],1,a)),1,null),1,"lG_3"),dg=m(x(cg,"s_gpmIUuGz0sE")),pg=t=>{const e=t.data.pageDeals.data.attributes.Deals,a=t.data.pageDeals.data.attributes.RefInfo,l=t.data.pageDeals.data.attributes.Discounts,r=t.data.pageDeals.data.attributes.Disclaimer;return n("div",null,null,[o(ig,{data:e},3,"e6_0"),o(ug,{data:a},3,"e6_1"),o(dg,{data:l},3,"e6_2"),n("div",null,{class:"flex w-full items-center  justify-center p-8 text-center text-[14px] italic text-primary-dark-blue"},r,1,null)],1,"e6_3")},gg=m(x(pg,"s_xtY1ub2ohjs")),fg=t=>`
  query QueryDeals{
    pageDeals(locale:"${t}"){
      data{
        attributes{
          Deals {
            isVisible
            Title
            Description
            Deal
            Deals_description
            Media {
              ${v}
            }
            Services {
              Title
              Icon {
                ${v}
              }
            }
            Button {
              Text
              Link
            }
          }
  
          RefInfo{
            Title
            Paragraph
            Media{
              ${v}
            }
            Buttons{
              Text
              Link
            }
          }
          RefBackground{
            ${v}
          }
          
          Discounts{
            Title
            Paragraph
            Media{
             ${v}
            }
          }
          Disclaimer
          
          ${R}
        }
      }
    }
  }
    `,xg=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(fg,e)},Ql=A(x(xg,"s_2jiG1A0ymzM")),mg=()=>{const t=Ql();return o(N,{get data(){return t.value.layoutData},children:o(gg,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"B3_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"B3_1")},$g=m(x(mg,"s_OVAjdqBqgec")),hg=({resolveValue:t})=>{const a=t(Ql).pageData.data.pageDeals.data.attributes.SEO;return H(a)},bg=Object.freeze(Object.defineProperty({__proto__:null,default:$g,head:hg,usePageData:Ql},Symbol.toStringTag,{value:"Module"})),vg=t=>n("div",null,{class:"my-8"},[n("h1",null,{class:"text-center text-xl font-semibold text-primary-blue"},u(e=>e.data.Introduction.Titles[0].Text,[t],'p0.data["Introduction"]["Titles"][0]["Text"]'),3,null),n("h2",null,{class:"text-center text-primary-blue"},u(e=>e.data.Introduction.TextContent,[t],'p0.data["Introduction"]["TextContent"]'),3,null),n("div",null,{class:"px-4 md:px-10"},t.data.FAQList.map((e,a)=>Z(o(ge,{get title(){return e.Title},children:[n("p",null,{class:"text-primary-blue"},y(e,"Paragraph"),1,null),e.Disclaimer!==null?n("div",null,{class:"flex flex-row items-center justify-center"},[o(rd,{class:"text-secondary-red",[s]:{class:s}},3,"NP_0"),n("p",null,{class:"text-s text-primary-dark-blue"},y(e.Disclaimer,"Text"),1,null)],1,"NP_1"):null,e.Table!==null?n("div",null,{class:"flex flex-col item-center justify-center"},n("table",null,{class:"border-collapse border rounded-2xl border-gray-200 w-full"},n("tbody",null,null,e.Table.map((l,r)=>n("tr",{class:`${r===0?"bg-primary-blue text-white":r%2===1?"bg-blue-100 text-primary-blue":"bg-blue-200 text-primary-blue"}`},null,[n("td",null,null,y(l,"ColumnOne"),1,null),n("td",null,null,y(l,"ColumnTwo"),1,null),n("td",null,null,y(l,"ColumnThree"),1,null)],1,r)),1,null),1,null),1,"NP_2"):null],classChild:" text-sm md:text-base border-primary-blue",classContainer:"text-center bg-white text-primary-blue text-base md:text-lg shadow-xl",[s]:{classChild:s,classContainer:s,title:f(e,"Title")}},1,a))),1,null)],1,"NP_3"),yg=m(x(vg,"s_x7ihZ2PZWys")),wg=t=>`query QueryFAQ {
        pageFaq(locale:"${t}") {
          data{
            attributes{    
              Introduction{
                Titles{
                  Text
                }
                TextContent
              }
      
              FAQList{
                Title
                Paragraph
                Disclaimer{
                Icon{
                    ${v}
                }
                Title
                Text
                Caption
                }

                Table{
                ColumnOne
                ColumnTwo
                ColumnThree
                }
              }
              
              ${R}
            }
          }
        }
      }`,_g=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(wg,e)},Fl=A(x(_g,"s_SBnhqZ85K9A")),Tg=()=>{const t=Fl(),e=t.value.pageData.data.pageFaq.data.attributes;return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:o(yg,{data:e},3,"k1_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"k1_1")},1,"k1_2")},Sg=m(x(Tg,"s_jDEouB0mRKg")),Dg=({resolveValue:t})=>{const a=t(Fl).pageData.data.pageFaq.data.attributes.SEO;return H(a)},Pg=Object.freeze(Object.defineProperty({__proto__:null,default:Sg,head:Dg,usePageData:Fl},Symbol.toStringTag,{value:"Module"})),kg=t=>n("div",null,{class:"relative text-center items-center justify-center }"},n("img",{src:G(t.update.Picture.data.attributes.url)},{alt:u(e=>e.update.Picture.data.attributes.alternativeText,[t],'p0.update["Picture"]["data"]["attributes"]["alternativeText"]'),height:500,title:u(e=>e.update.Picture.data.attributes.caption,[t],'p0.update["Picture"]["data"]["attributes"]["caption"]'),width:350},null,3,null),1,"2q_0"),Lg=t=>{const e=m(x(kg,"s_SjfOqPww0ks")),a=t.carouselData.map((l,r)=>o(e,{update:l},3,r));return n("div",null,{class:"flex flex-row max-w-[1200px] items-center justify-center max-[800px]:flex-col h-full"},[n("div",null,null,n("h2",null,{class:"text-center text-4xl font-bold text-primary-blue max-[800px]:w-[40%]"},u(l=>l.title,[t],"p0.title"),3,null),3,null),n("div",null,{class:"h-[600px] w-[60%] flex items-center justify-center "},o(Bt,{hasPagination:!1,id:"updatesSlider",slides:a,[s]:{hasPagination:s,id:s}},3,"2q_1"),1,null)],1,"2q_2")},Mg=m(x(Lg,"s_kpGwS0aQJPs")),Cg=t=>n("div",null,null,[o(Nt,{get data(){return t.data.Introduction},alt:!0,hasPricing:!1,reverse:!0,[s]:{alt:s,data:u(e=>e.data.Introduction,[t],'p0.data["Introduction"]'),hasPricing:s,reverse:s}},3,"NM_0"),o(Mg,{get title(){return t.data.UpdatesTitle},get carouselData(){return t.data.UpdatesCarousel},[s]:{carouselData:u(e=>e.data.UpdatesCarousel,[t],'p0.data["UpdatesCarousel"]'),title:u(e=>e.data.UpdatesTitle,[t],'p0.data["UpdatesTitle"]')}},3,"NM_1")],1,"NM_2"),jg=m(x(Cg,"s_bPCxBsh3t6w")),Ig=t=>`query queryGfsn{
        pageGfSports(locale:"${t}"){
          data{
            attributes{
              
              Introduction{
                Title
                Subtitle
                Paragraph
                Media{
                 ${v}
                }
               
              }
              
              UpdatesTitle
              
              UpdatesCarousel{
                Picture{
                  ${v}
                }
                Link
                Title
                Subtitle
              }
              
              FeatInterview{
                Title
                Subtitle
                Paragraph
                
                Buttons{
                  Text
                  Link
                  Icon{
                    ${v}
                  }
                }
              }
              
              
              FeatVideo
              
              Interviews{
                Picture{
                  ${v}
                }
                Link
                Title
              }
              ${R}
            }
          }
        }
      }`,Eg=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(Ig,e)},Hl=A(x(Eg,"s_BZfivgZf0o0")),Og=()=>{const t=Hl();return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageGfSports.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfSports.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfSports"]["data"]["attributes"]["SEO"]')}},3,"7u_0"),o(jg,{get data(){return t.value.pageData.data.pageGfSports.data.attributes},[s]:{data:u(e=>e.value.pageData.data.pageGfSports.data.attributes,[t],'p0.value["pageData"]["data"]["pageGfSports"]["data"]["attributes"]')}},3,"7u_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"7u_2")},1,"7u_3")},Bg=m(x(Og,"s_KZzsv9nZPuQ")),Ag=({resolveValue:t})=>{const a=t(Hl).pageData.data.pageGfSports.data.attributes.SEO;return H(a)},qg=Object.freeze(Object.defineProperty({__proto__:null,default:Bg,head:Ag,usePageData:Hl},Symbol.toStringTag,{value:"Module"})),Ng=t=>{const e=t.data.pageGfCloud.data.attributes,a=t.data.sectionNetwork.data.attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[o(z,{get url(){return e.GNetworkLogo.data.attributes.url},get alt(){return e.GNetworkLogo.data.attributes.alternativeText},get title(){return e.GNetworkLogo.data.attributes.caption},height:95,width:500,[s]:{alt:f(e.GNetworkLogo.data.attributes,"alternativeText"),height:s,title:f(e.GNetworkLogo.data.attributes,"caption"),url:f(e.GNetworkLogo.data.attributes,"url"),width:s}},3,"JJ_0"),n("div",null,{class:"flex flex-wrap-reverse px-8 py-6 items-center justify-center"},[n("div",null,{class:"h-[450px] w-full md:w-1/2"},o(z,{get url(){return a.Map.MapPicture.data.attributes.url},get alt(){return a.Map.MapPicture.data.attributes.alternativeText},get title(){return a.Map.MapPicture.data.attributes.caption},height:95,width:500,[s]:{alt:f(a.Map.MapPicture.data.attributes,"alternativeText"),height:s,title:f(a.Map.MapPicture.data.attributes,"caption"),url:f(a.Map.MapPicture.data.attributes,"url"),width:s}},3,"JJ_1"),1,null),n("div",null,{class:"flex flex-col w-full md:w-1/2 items-center justify-center"},[o(I,{get text(){return a.Description.Paragraph},classN:"text-primary-blue",[s]:{classN:s,text:f(a.Description,"Paragraph")}},3,"JJ_2"),o(ge,{get title(){return a.Map.ServersTitle},children:n("div",null,{class:"flex flex-col py-4 text-primary-blue bg-white rounded-b-2xl"},a.Map.Servers.map((l,r)=>n("a",{href:y(l,"Link")},{class:"hover:text-secondary-red text-primary-blue"},y(l,"Text"),1,r)),1,null),classContainer:"rounded-full bg-white text-primary-blue shadow-xl",[s]:{classContainer:s,title:f(a.Map,"ServersTitle")}},1,"JJ_3")],1,null)],1,null),o(At,{get title(){return e.GFCloud.Title},get text(){return e.GFCloud.Paragraph},get image(){return e.GFCloud.Media.data.attributes},get logo(){return e.GFCloud.Logo.data.attributes},get buttons(){return e.GFCloud.Buttons},[s]:{buttons:f(e.GFCloud,"Buttons"),image:f(e.GFCloud.Media.data,"attributes"),logo:f(e.GFCloud.Logo.data,"attributes"),text:f(e.GFCloud,"Paragraph"),title:f(e.GFCloud,"Title")}},3,"JJ_4")],1,"JJ_5")},zg=m(x(Ng,"s_ee4CXUkPYJQ")),Rg=t=>`query QueryGFCloud {
        pageGfCloud (locale:"${t}"){    
          data{
            attributes{
              GNetworkLogo{
                ${v}
              }
            GFCloud{
              Title
              Logo{
                ${v}
              }
              Paragraph
              Media{
                ${v}
              }
              Buttons{
                Text
                Link
              }
            }
              
            ${R}
            }
          }
        }
        sectionNetwork (locale:"${t}"){
          data {
            attributes {
              Map {
                MapPicture {
                  ${v}
                }
                ServersTitle
                Servers {
                  Text
                  Link
                  Icon{
                    data{
                      attributes{
                        url
                      }
                    }
                  }
                }
              }
              Description{
                Title
                Paragraph
              }
            }
          }
        }
      }`,Gg=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(Rg,e)},Wl=A(x(Gg,"s_imQl8eEcDG0")),Qg=()=>{const t=Wl(),e=t.value.pageData.data;return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageGfCloud.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageGfCloud.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfCloud"]["data"]["attributes"]["SEO"]')}},3,"Fb_0"),o(zg,{data:e},3,"Fb_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Fb_2")},1,"Fb_3")},Fg=m(x(Qg,"s_8q0wwtngnhI")),Hg=({resolveValue:t})=>{const a=t(Wl).pageData.data.pageGfCloud.data.attributes.SEO;return H(a)},Wg=Object.freeze(Object.defineProperty({__proto__:null,default:Fg,head:Hg,usePageData:Wl},Symbol.toStringTag,{value:"Module"})),Ug=t=>n("div",null,{class:"flex w-full flex-col items-center justify-center gap-3 rounded-xl bg-white p-8 shadow-xl"},[n("div",null,{class:"w-fit rounded-full bg-secondary-red p-2"},o(z,{get url(){return t.tip.Icon.data.attributes.url},get alt(){return t.tip.Icon.data.attributes.alternativeText},get title(){return t.tip.Icon.data.attributes.caption},height:17,toWhite:!0,width:17,[s]:{alt:u(e=>e.tip.Icon.data.attributes.alternativeText,[t],'p0.tip["Icon"]["data"]["attributes"]["alternativeText"]'),height:s,title:u(e=>e.tip.Icon.data.attributes.caption,[t],'p0.tip["Icon"]["data"]["attributes"]["caption"]'),toWhite:s,url:u(e=>e.tip.Icon.data.attributes.url,[t],'p0.tip["Icon"]["data"]["attributes"]["url"]'),width:s}},3,"Ie_0"),1,null),n("h4",null,{class:"text-center font-[700] text-primary-blue"},u(e=>e.tip.Title,[t],'p0.tip["Title"]'),3,null),o(I,{classN:"text-[14px] font-[500]",get text(){return t.tip.Text},[s]:{classN:s,text:u(e=>e.tip.Text,[t],'p0.tip["Text"]')}},3,"Ie_1")],1,t.tip.Title),Vg=t=>{const e=m(x(Ug,"s_YpuX8PZv7fg"));return n("div",null,{class:"mt-6 flex w-full max-w-[1200px] flex-col items-center justify-center gap-4 p-8"},[n("h2",null,{class:"text-center text-[40px] font-[500] text-primary-blue"},u(a=>a.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"grid w-full grid-cols-3 gap-4  max-[800px]:grid-cols-1"},t.data.Bullets.slice(0,3).map((a,l)=>o(e,{tip:a},3,l)),1,null),n("div",null,{class:"grid w-full grid-cols-2 gap-4 max-[800px]:grid-cols-1"},t.data.Bullets.slice(3,5).map((a,l)=>o(e,{tip:a},3,l)),1,null)],1,"Ie_2")},Yg=m(x(Vg,"s_0W2ahleMHpc")),Zg=t=>o(Q,{children:t.data.map((e,a)=>o(Nt,{data:e,reverse:a%2===1,textPercentage:60,[s]:{textPercentage:s}},3,a))},1,"mL_0"),Jg=m(x(Zg,"s_GQ2BMpdgaAM")),Xg=t=>{const e=t.data.pageGfIS.data.attributes;let a="";return e.WiFiListing.Bullets.forEach(l=>{a+="- "+l.Text+`
`}),n("div",null,{class:"flex w-full flex-col items-center justify-center",onClick$:F("s_wLQQzX3cS04")},[n("h1",null,{class:"max-w-[800px] px-8 text-center text-[42px] font-[600] text-primary-blue max-[600px]:text-[32px]"},y(e.Introduction,"Paragraph"),1,null),o(Yg,{get data(){return e.Tips},[s]:{data:f(e,"Tips")}},3,"5A_0"),o(Jg,{get data(){return e.InternetInfo},[s]:{data:f(e,"InternetInfo")}},3,"5A_1"),n("div",null,{class:"flex max-w-[1200px] items-start justify-center gap-4 p-8 max-[800px]:flex-col"},[n("p",null,{class:"w-[60%] text-[15px] text-primary-blue max-[800px]:w-full"},y(e.InternetExample[0],"Text"),1,null),n("p",null,{class:"w-[40%] text-[15px] font-[600] text-primary-blue max-[800px]:w-full"},y(e.InternetExample[1],"Text"),1,null)],1,null),o(At,{get title(){return e.WiFiListing.Title},text:a,get image(){return e.WiFiPicture.data.attributes},reverse:!0,textPercentage:50,[s]:{image:f(e.WiFiPicture.data,"attributes"),reverse:s,textPercentage:s,title:f(e.WiFiListing,"Title")}},3,"5A_2"),o(Nt,{get data(){return e.TestPar},textPercentage:60,[s]:{data:f(e,"TestPar"),textPercentage:s}},3,"5A_3"),o(Ie,{steps:e.TestStepss.map(l=>"**"+l.Title+`**

`+l.Text)},3,"5A_4"),o(At,{get text(){return e.TestGlossary.Paragraph},get image(){return e.TestGlossary.Media.data.attributes},textPercentage:60,[s]:{image:f(e.TestGlossary.Media.data,"attributes"),text:f(e.TestGlossary,"Paragraph"),textPercentage:s}},3,"5A_5"),n("h3",null,{class:"text-[40px] font-[600] text-primary-blue"},y(e.TroubleSteps,"Title"),1,null),n("p",null,{class:"my-4 text-primary-blue"},y(e,"TroubleDescription"),1,null),n("div",null,{class:"max-w-[1200px]  px-8"},o(Ie,{steps:e.TroubleSteps.Bullets.map(l=>l.Title?"**"+l.Title+`**
`+l.Text.replaceAll(`

`,`
`):"**"+l.Text.replaceAll(`

`,`
`)+"**")},3,"5A_6"),1,null)],1,"5A_7")},Kg=m(x(Xg,"s_DlDfET88Hb4")),tf=t=>`query {
    pageGfIS(locale:"${t}") {
      data {
        attributes {
          Introduction {
            Paragraph
            Media {
              ${v}
            }
          }
          Tips {
            Title
            Bullets {
              Title
              Text
              Icon {
               ${v}
              }
            }
          }
          InternetInfo {
            Title
            Paragraph
            Media {
              ${v}
            }
          }
          InternetExample {
            Text
          }
          WiFiPicture {
           ${v}
          }
          WiFiListing {
            Title
            Bullets {
              Title
              Text
            }
          }
          TestPar{
            Title
            Paragraph
            Media{
              ${v}
            }
          }
          TestStepss{
            Title
            Text
          }
          TestGlossary {
            Paragraph
            Media {
              ${v}
            }
          }
          TroubleSteps {
            Title
            Bullets {
              Title
              Text
            }
          }
          TroubleDescription
          ${R}
  
        }
      }
    }
  }`,ef=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(tf,e)},Ul=A(x(ef,"s_YTLZ80iXjpk")),af=()=>{const t=Ul();return o(N,{get data(){return t.value.layoutData},children:o(Kg,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"0g_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"0g_1")},lf=m(x(af,"s_sPmm4Hp5SbY")),nf=({resolveValue:t})=>{const a=t(Ul).pageData.data.pageGfIS.data.attributes.SEO;return H(a)},sf=Object.freeze(Object.defineProperty({__proto__:null,default:lf,head:nf,usePageData:Ul},Symbol.toStringTag,{value:"Module"})),rf=t=>n("div",null,{class:"flex h-full w-fit max-w-[300px] flex-col items-center justify-between rounded-[35px] bg-white px-5"},[n("div",null,{class:"mt-8 flex w-fit max-w-full flex-col items-center self-center"},[t.isFullLogo??!1?n("div",null,{class:"flex flex-col justify-center items-center self-center gap-2 "},[n("img",{src:G(t.logo.url)},{alt:u(e=>e.logo.alternativeText,[t],'p0.logo["alternativeText"]'),class:" w-full  overflow-hidden object-center",height:100,loading:"lazy",title:u(e=>e.logo.caption,[t],'p0.logo["caption"]'),width:300},null,3,null),n("div",null,{class:" text-2xl font-bold leading-6 text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null)],1,"0s_0"):n("div",null,{class:"flex w-full items-start gap-5 self-center"},[n("img",{src:G(t.logo.url)},{alt:u(e=>e.logo.alternativeText,[t],'p0.logo["alternativeText"]'),class:"aspect-square w-[70px] max-w-full items-center justify-center self-stretch overflow-hidden object-contain object-center",height:100,loading:"lazy",title:u(e=>e.logo.caption,[t],'p0.logo["caption"]'),width:100},null,3,null),n("div",null,{class:"my-auto flex flex-col self-center"},n("div",null,{class:"self-start whitespace-nowrap text-2xl font-bold leading-6 text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),3,null)],1,null),n("div",null,{class:"mt-2 text-center text-base leading-4 tracking-tighter text-primary-blue"},[n("span",null,{class:"text-2xl font-light text-secondary-red"},"$",3,null),n("span",null,{class:"text-2xl font-light text-primary-blue"},u(e=>e.price,[t],"p0.price"),3,null),n("span",null,{class:" text-2xl text-primary-blue"},u(e=>e.priceTime,[t],"p0.priceTime"),3,null)],3,null),n("div",null,{class:"mt-5 text-center text-base text-primary-blue text-sm"},o(I,{get text(){return t.description},[s]:{text:u(e=>e.description,[t],"p0.description")}},3,"0s_1"),1,null),n("div",null,{class:"border-gary-500 my-4 h-[1px] w-full border-t-2"},null,3,null),n("div",null,{class:"mt-5 text-base text-primary-blue"},t.features.map((e,a)=>n("span",null,{class:"my-1 flex flex-row items-center justify-start"},[n("div",null,null,o(br,{class:"mx-2 h-[20px] w-[20px] fill-primary-blue text-primary-blue",[s]:{class:s}},3,"0s_2"),1,null),n("h3",null,{class:"text-sm font-light"},y(e,"Text"),1,a)],1,a)),1,null)],1,null),n("div",null,{class:"my-4 flex h-[80px] w-full flex-col items-center justify-center"},[n("div",null,{class:"border-gary-500 my-4 h-[1px] w-full border-t-2"},null,3,null),o(X,{get text(){return t.btnText},get link(){return t.btnLink},[s]:{link:u(e=>e.btnLink,[t],"p0.btnLink"),text:u(e=>e.btnText,[t],"p0.btnText")}},3,"0s_3")],1,null)],1,"0s_4"),Vl=m(x(rf,"s_Ttt0gCfGtkU")),of=t=>n("div",null,{class:"flex flex-col items-center justify-around"},[n("div",null,{class:"mx-4 my-8 max-w-[500px]"},o(z,{get url(){return t.data.Logo.data.attributes.url},get alt(){return t.data.Logo.data.attributes.alternativeText},get title(){return t.data.Logo.data.attributes.caption},height:229,width:1230,[s]:{alt:u(e=>e.data.Logo.data.attributes.alternativeText,[t],'p0.data["Logo"]["data"]["attributes"]["alternativeText"]'),height:s,title:u(e=>e.data.Logo.data.attributes.caption,[t],'p0.data["Logo"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.Logo.data.attributes.url,[t],'p0.data["Logo"]["data"]["attributes"]["url"]'),width:s}},3,"6h_0"),1,null),n("div",null,{class:"mx-10 my-4 flex max-w-[800px] flex-col items-center justify-center gap-2 text-primary-blue"},[n("span",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(e=>e.data.Introduction.Title,[t],'p0.data["Introduction"]["Title"]'),3,null),o(I,{classN:"text-center",get text(){return t.data.Introduction.Paragraph},[s]:{classN:s,text:u(e=>e.data.Introduction.Paragraph,[t],'p0.data["Introduction"]["Paragraph"]')}},3,"6h_1"),o(X,{get text(){return t.data.Introduction.Buttons[0].Text},get link(){return t.data.Introduction.Buttons[0].Link},[s]:{link:u(e=>e.data.Introduction.Buttons[0].Link,[t],'p0.data["Introduction"]["Buttons"][0]["Link"]'),text:u(e=>e.data.Introduction.Buttons[0].Text,[t],'p0.data["Introduction"]["Buttons"][0]["Text"]')}},3,"6h_2")],1,null),n("div",null,{class:"flex flex-wrap gap-10 justify-center mx-4 my-8 items-center"},t.data.PackTables.map((e,a)=>o(Vl,{get title(){return e.Title},get logo(){return e.Logo.data.attributes},get description(){return e.Description},get features(){return e.Features},get price(){return e.Price},get priceTime(){return e.Pricetime},get btnLink(){return e.Button.Link},get btnText(){return e.Button.Text},[s]:{btnLink:f(e.Button,"Link"),btnText:f(e.Button,"Text"),description:f(e,"Description"),features:f(e,"Features"),logo:f(e.Logo.data,"attributes"),price:f(e,"Price"),priceTime:f(e,"Pricetime"),title:f(e,"Title")}},3,a)),1,null),o(I,{classN:"text-primary-blue text-center mx-4 my-8",get text(){return t.data.Disclaimer},[s]:{classN:s,text:u(e=>e.data.Disclaimer,[t],'p0.data["Disclaimer"]')}},3,"6h_3"),o(At,{get text(){return t.data.GFInternetSupport.Paragraph},get title(){return t.data.GFInternetSupport.Title},get logo(){return t.data.GFInternetSupport.Logo.data.attributes},get buttons(){return t.data.GFInternetSupport.Buttons},get image(){return t.data.GFInternetSupport.Media.data.attributes},[s]:{buttons:u(e=>e.data.GFInternetSupport.Buttons,[t],'p0.data["GFInternetSupport"]["Buttons"]'),image:u(e=>e.data.GFInternetSupport.Media.data.attributes,[t],'p0.data["GFInternetSupport"]["Media"]["data"]["attributes"]'),logo:u(e=>e.data.GFInternetSupport.Logo.data.attributes,[t],'p0.data["GFInternetSupport"]["Logo"]["data"]["attributes"]'),text:u(e=>e.data.GFInternetSupport.Paragraph,[t],'p0.data["GFInternetSupport"]["Paragraph"]'),title:u(e=>e.data.GFInternetSupport.Title,[t],'p0.data["GFInternetSupport"]["Title"]')}},3,"6h_4")],1,"6h_5"),uf=m(x(of,"s_30f4iq1HkIo")),cf=t=>`query QueryGFInternet {
        pageGfInternet(locale:"${t}"){
          data {
            attributes {
              Logo {
                ${v}
              }
              Introduction {
                Paragraph
                Buttons {
                  Text
                  Link
                }
              }
              PackTables {
                Logo {
                  ${v}
                }
                Title
                Subtitle
                Price
                Pricetime
                Description
                Features {
                  Text
                  Title
                }
                Button {
                  Link
                  Text
                }
              }
              Disclaimer
              GFInternetSupport {
                Title
                Subtitle
                Paragraph
                Logo {
                  ${v}
                }
                Media {
                  ${v}
                }
                Buttons {
                  Text
                  Link
                }
              }
              ${R}
            }
          }
        }
      }
      `,df=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(cf,e)},Yl=A(x(df,"s_PG6JGbvGdSU")),pf=()=>{const t=Yl(),e=t.value.pageData.data.pageGfInternet.data.attributes;return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageGfInternet.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageGfInternet.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfInternet"]["data"]["attributes"]["SEO"]')}},3,"TH_0"),o(uf,{data:e},3,"TH_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"TH_2")},1,"TH_3")},gf=m(x(pf,"s_cj0XMKyWnnQ")),ff=({resolveValue:t})=>{const a=t(Yl).pageData.data.pageGfInternet.data.attributes.SEO;return H(a)},xf=Object.freeze(Object.defineProperty({__proto__:null,default:gf,head:ff,usePageData:Yl},Symbol.toStringTag,{value:"Module"})),mf=t=>{const e=t.data.pageGfIoT.data.attributes.Services,a=t.data.pageGfIoT.data.attributes.Introduction,l=t.data.pageGfIoT.data.attributes.Logo.data.attributes,r=t.data.pageGfIoT.data.attributes.WeatherAnounce;return n("div",null,{class:"flex flex-col items-center justify-center "},[n("div",null,{class:"m-4 flex items-center justify-center gap-4 rounded-full bg-[#edf6ff] px-8 py-5 shadow-xl max-sm:flex-col"},[n("span",null,{class:"text-center text-[18px] font-[600] text-primary-blue max-md:text-[14px]"},y(r,"Paragraph"),1,null),o(X,{get text(){return r.Buttons[0].Text},get link(){return r.Buttons[0].Link},[s]:{link:f(r.Buttons[0],"Link"),text:f(r.Buttons[0],"Text")}},3,"Ws_0")],1,null),n("div",null,{class:"mx-4 my-8 max-w-[500px]"},o(z,{get url(){return l.url},get alt(){return l.alternativeText},get title(){return l.caption},height:229,width:1230,[s]:{alt:f(l,"alternativeText"),height:s,title:f(l,"caption"),url:f(l,"url"),width:s}},3,"Ws_1"),1,null),n("div",null,{class:"mx-10 my-4 flex max-w-[800px] flex-col items-center justify-center gap-2 text-primary-blue"},[n("span",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},y(a,"Title"),1,null),o(I,{classN:"text-justify",get text(){return a.Paragraph},[s]:{classN:s,text:f(a,"Paragraph")}},3,"Ws_2")],1,null),o(Xt,{data:e},3,"Ws_3")],1,"Ws_4")},$f=m(x(mf,"s_1kXwT2q88rA")),hf=t=>`
  query QueryGFIoT {
    pageGfIoT(locale:"${t}"){
      data{
        attributes{
          Logo{
            ${v}
          }
          
          Introduction{
            Title
            Paragraph
          }
          
          WeatherAnounce{
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
          
          Services{
            Logo{
             ${v}
            }
            Title
            Paragraph
            Media{
             ${v}
            }
            Buttons{
              Text
              Link
            }
          }
          ${R}
        }
      }
    }
  }
    `,bf=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(hf,e)},Zl=A(x(bf,"s_2v03ITQBdcI")),vf=()=>{const t=Zl();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageGfIoT.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfIoT.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfIoT"]["data"]["attributes"]["SEO"]')}},3,"Mz_0"),o($f,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Mz_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Mz_2")},yf=m(x(vf,"s_teV3ya9bjBI")),wf=({resolveValue:t})=>{const a=t(Zl).pageData.data.pageGfIoT.data.attributes.SEO;return H(a)},_f=Object.freeze(Object.defineProperty({__proto__:null,default:yf,head:wf,usePageData:Zl},Symbol.toStringTag,{value:"Module"})),Tf=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),o(I,{get text(){return t.data.TextContent},classN:"markdownTitle markdownh3 markdownHyper tracking-wider text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"Wt_0")],1,"Wt_1"),Sf=m(x(Tf,"s_wAqfRFn86VY")),Df=t=>`query QuerygftvPrivacyP {
        pageGfTvPp(locale:"${t}"){    
          ${Ue}
          ${R}
            }
          }
        }
      }`,Pf=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(Df,e)},Jl=A(x(Pf,"s_o03PAaBI278")),kf=()=>{const t=Jl(),e=t.value.pageData.data.pageGfTvPp.data.attributes.Content;return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:o(Sf,{data:e},3,"zG_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"zG_1")},1,"zG_2")},Lf=m(x(kf,"s_0UMSXuOQgCA")),Mf=({resolveValue:t})=>{const a=t(Jl).pageData.data.pageGfTvPp.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},Cf=Object.freeze(Object.defineProperty({__proto__:null,default:Lf,head:Mf,usePageData:Jl},Symbol.toStringTag,{value:"Module"})),jf=async(t,e)=>{const a=G(t);try{const l=await fetch(a);if(!l.ok)throw new Error(`Error al descargar el archivo desde ${a}. Estado: ${l.status}`);const r=await l.arrayBuffer(),i=new Blob([r],{type:"application/pdf"}),c=window.URL.createObjectURL(i),d=document.createElement("a");d.href=c,d.download=e,d.click(),window.URL.revokeObjectURL(c)}catch(l){console.error(l)}},kr=x(jf,"s_Vd02rPSFNlY"),If=()=>{const[t]=et();kr(t.urlDoc,t.nameDoc)},Ef=t=>{const e=x(If,"s_L0UgBFqZ3XI",[t]);return n("div",null,{class:"flex flex-col h-[250px] w-[300px] bg-white shadow-2xl rounded-3xl justify-evenly items-center p-4"},[n("h3",null,{class:"text-2xl flex text-center font-bold text-[#2E5899]"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex w-fit items-center font-semibold justify-center gap-2 rounded-full border-2 border-teal-500 bg-white p-1 px-7 text-btn-green opacity-80 shadow-md transition-all hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:e},n("div",null,{class:"flex flex-row gap-2 items-center font-semibold text-center justify-center"},[u(a=>a.btnText,[t],"p0.btnText"),n("div",null,{class:"h-[25px] w-[25px] flex items-center justify-center font-bold text-white bg-teal-500 hover:text-teal-500 hover:bg-white rounded-full"},o(vr,{class:"stroke-current",[s]:{class:s}},3,"h5_0"),1,null)],1,null),1,null)],1,"h5_1")},Lr=m(x(Ef,"s_tF7T0UXX4O0")),Of=()=>{const[t]=et();kr(t.urlDoc,t.nameDoc)},Bf=t=>{const e=x(Of,"s_8SKPRTg50C4",[t]);return n("div",null,{class:"h-[370px] w-[400px] py-8 px-4 bg-white rounded-2xl pb-2 flex flex-col items-center justify-between shadow-2xl"},[n("div",null,{class:"relative flex w-full h-1/2 overflow-hidden"},n("img",{src:G(t.image.url)},{alt:u(a=>a.image.alternativeText,[t],'p0.image["alternativeText"]'),class:"object-fill w-full h-full rounded-t-2xl",height:"1500",title:u(a=>a.image.caption,[t],'p0.image["caption"]'),width:"2076"},null,3,null),1,null),n("h2",null,{class:"text-2xl flex text-center font-bold text-[#2E5899]"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex w-fit items-center font-semibold justify-center gap-2 rounded-full border-2 border-teal-500 bg-white p-1 text-btn-green opacity-80 shadow-md transition-all hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:e},n("div",null,{class:"flex flex-row gap-2 items-center font-semibold text-center justify-center"},[u(a=>a.btnText,[t],"p0.btnText"),n("div",null,{class:"h-[25px] w-[25px] flex items-center justify-center font-bold text-white bg-teal-500 hover:text-teal-500 hover:bg-white rounded-full"},o(vr,{class:"stroke-current",[s]:{class:s}},3,"d0_0"),1,null)],1,null),1,null)],1,"d0_1")},Mr=m(x(Bf,"s_OdYDJRaDcFY")),Af=t=>{const e=t.data.pageGfTvS.data.attributes,a=t.data.sectionChGuide.data.attributes;return n("div",null,{class:"flex flex-col justify-center items-center"},[n("div",null,{class:"flex flex-col md:flex-row px-8 items-center justify-center gap-5"},[n("h1",null,{class:"text-2xl text-center font-semibold text-primary-blue"},y(e,"IntroText"),1,null),n("div",null,{class:"h-[150px] relative w-[350px] flex mb-14"},[n("video",{src:G(e.IntroMedia.data[1].attributes.url)},{autoPlay:!0,class:"absolute pt-2",loop:!0,muted:!0},null,3,null),n("img",{alt:y(e.IntroMedia.data[0].attributes,"alternativeText"),src:G(e.IntroMedia.data[0].attributes.url),title:y(e.IntroMedia.data[0].attributes,"caption")},{class:"absolute z-0",height:"786",width:"1082"},null,3,null)],1,null)],1,null),n("div",null,{class:"flex my-20 w-full py-10 bg-primary-blue bg-opacity-40"},n("div",null,{class:"flex w-full py-10 bg-primary-blue bg-opacity-60"},n("div",null,{class:"flex w-full flex-col py-10 px-8 items-center justify-between bg-primary-blue bg-opacity-80"},[n("h2",null,{class:"font-bold text-3xl md:text-4xl my-5 text-white"},y(e,"DevicesTitle"),1,null),n("div",null,{class:"flex flex-wrap gap-5 items-center justify-center"},e.Devices.map((l,r)=>n("div",null,{class:"h-[300px] w-[300px] p-5 rounded-full bg-white bg-opacity-40"},n("div",null,{class:"h-full w-full p-5 rounded-full bg-white bg-opacity-60"},n("div",null,{class:"h-full w-full object-cover flex flex-col p-8 justify-center items-center rounded-full bg-white"},[n("h2",null,{class:"text-center font-semibold text-2xl text-primary-blue"},y(l,"Title"),1,null),o(I,{classN:"text-s text-primary-dark-blue",get text(){return l.Paragraph},[s]:{classN:s,text:f(l,"Paragraph")}},3,"yQ_0")],1,null),1,null),1,r)),1,null),n("p",null,{class:"text-center justify-end my-5 text-white"},y(e,"DevicesNote"),1,null)],1,null),1,null),1,null),n("div",null,{class:"flex flex-col justify-center px-8 items-center"},[n("div",null,{class:"w-full md:w-2/3 flex flex-col items-center"},[n("h2",null,{class:"text-3xl md:text-4xl text-center font-bold text-primary-blue"},y(e.GuidePar,"Title"),1,null),o(I,{classN:"text-center",get text(){return e.GuidePar.Paragraph},[s]:{classN:s,text:f(e.GuidePar,"Paragraph")}},3,"yQ_1")],1,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-10 my-5"},e.Guides.map((l,r)=>o(Lr,{get urlDoc(){return l.Guide.data.attributes.url},get title(){return l.Title},get btnText(){return l.BtnText},get nameDoc(){return l.Guide.data.attributes.name},[s]:{btnText:f(l,"BtnText"),nameDoc:f(l.Guide.data.attributes,"name"),title:f(l,"Title"),urlDoc:f(l.Guide.data.attributes,"url")}},3,r)),1,null)],1,null),n("div",null,{class:"flex w-full flex-col items-center justify-center"},n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex min-[800px]:w-[70%] flex-col items-center justify-center gap-4 px-10"},[n("div",null,{class:"max-w-[470px]"},n("img",{alt:y(a.Logo.data.attributes,"alternativeText"),src:G(a.Logo.data.attributes.url),title:y(a.Logo.data.attributes,"caption")},{height:"230",width:"1230"},null,3,null),1,null),n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},y(a,"Title"),1,null),1,null),o(I,{get text(){return a.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{classN:s,text:f(a,"Paragraph")}},3,"yQ_2")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},o(Mr,{get nameDoc(){return a.GuideBox.Guide.data.attributes.name},get urlDoc(){return a.GuideBox.Guide.data.attributes.url},get image(){return a.Picture.data.attributes},get title(){return a.GuideBox.Title},get btnText(){return a.GuideBox.BtnText},[s]:{btnText:f(a.GuideBox,"BtnText"),image:f(a.Picture.data,"attributes"),nameDoc:f(a.GuideBox.Guide.data.attributes,"name"),title:f(a.GuideBox,"Title"),urlDoc:f(a.GuideBox.Guide.data.attributes,"url")}},3,"yQ_3"),1,null)],1,null),1,null)],1,"yQ_4")},qf=m(x(Af,"s_L3FZbhALRyo")),Nf=t=>`query gfTvSupport {
        pageGfTvS (locale:"${t}") {
          data {
            attributes {
              IntroText
              IntroMedia {
                ${v}
              }
              DevicesTitle
              Devices {
                Title
                Paragraph
                Buttons {
                  Text
                  Link
                }
              }
              DevicesNote
              GuidePar {
                Title
                Paragraph
              }
              Guides {
                Title
                BtnText
                Guide {
                  data {
                    attributes {
                      url
                      name
                    }
                  }
                }
              }
              ${R}
            }
          }
        }
        sectionChGuide{
          data{
            attributes{
              Logo{
                ${v}
              }
              Picture{
                ${v}
              }
              Title
              Paragraph
              GuideBox{
                Title
                BtnText
                Guide{
                  data{
                    attributes{
                      url
                      name
                    }
                  }
                }
              }
            }
          }
        }
      }
      `,zf=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(Nf,e)},Xl=A(x(zf,"s_Y5JMYQJnIpI")),Rf=()=>{const t=Xl(),e=t.value.pageData.data;return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:o(qf,{data:e},3,"GS_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"GS_1")},1,"GS_2")},Gf=m(x(Rf,"s_sZYBtsmoVg8")),Qf=({resolveValue:t})=>{const a=t(Xl).pageData.data.pageGfTvS.data.attributes.SEO;return H(a)},Ff=Object.freeze(Object.defineProperty({__proto__:null,default:Gf,head:Qf,usePageData:Xl},Symbol.toStringTag,{value:"Module"})),Hf=t=>n("div",null,{class:"gap-10 w-ful flex flex-col"},t.data.map((e,a)=>Z(a%2==0?n("div",null,{class:"bg-primary-blue bg-opacity-40 py-10"},n("div",null,{class:"bg-primary-blue bg-opacity-60 py-10"},n("div",null,{class:"bg-primary-blue"},o(At,{color:"white",reverse:!0,get text(){return e.Paragraph},get image(){return e.Media.data.attributes},backgroundColor:"primary-blue",title:e.Title!=null?e.Title:"",[s]:{backgroundColor:s,color:s,image:f(e.Media.data,"attributes"),reverse:s,text:f(e,"Paragraph")}},3,a),1,null),1,null),1,a):o(At,{reverse:!1,get text(){return e.Paragraph},get image(){return e.Media.data.attributes},title:e.Title!=null?e.Title:"",[s]:{image:f(e.Media.data,"attributes"),reverse:s,text:f(e,"Paragraph")}},3,a))),1,"1n_0"),Wf=m(x(Hf,"s_3YkhEsBDjTI")),Uf=t=>n("div",null,{class:"justify-between min-h-[670px] w-[300px] items-center shadow-lg bg-white flex flex-col px-5 rounded-[35px]"},[n("div",null,{class:"items-center self-center flex w-[310px] max-w-full flex-col mt-8"},[n("div",null,{class:"items-start self-center flex w-full gap-5"},[n("img",{alt:G(t.logo.alternativeText),src:G(t.logo.url),title:G(t.logo.caption)},{class:"aspect-square object-contain object-center w-[70px] justify-center items-center overflow-hidden self-stretch max-w-full",height:80,loading:"lazy",width:80},null,3,null),n("div",null,{class:"self-center flex flex-col my-auto"},[n("div",null,{class:"text-blue-800 text-2xl font-bold leading-6 self-start whitespace-nowrap"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"justify-center text-rose-700 text-xl mt-2"},u(e=>e.subtitle,[t],"p0.subtitle"),3,null)],3,null)],1,null),n("div",null,{class:"text-blue-800 flex flex-row mt-5"},[n("span",null,{class:"font-light text-3xl text-rose-700"},"$",3,null),n("span",null,{class:"font-light text-3xl text-blue-800"},u(e=>e.price,[t],"p0.price"),3,null),n("span",null,{class:" text-blue-800"},["/",u(e=>e.priceTime,[t],"p0.priceTime")],3,null)],3,null),n("div",null,{class:"items-start self-stretch flex flex-col mt-5"},[n("div",null,{class:"justify-between items-start self-stretch flex w-full gap-5"},[n("div",null,{class:"text-blue-800 text-center text-base"},u(e=>e.description,[t],"p0.description"),3,null),o($a,{get link(){return t.btnSeeMoreLink},get dataChannels(){return t.dataChannels},get planId(){return t.title},get channels(){return t.subtitle},get text(){return t.btnSeeMoreText},[s]:{channels:u(e=>e.subtitle,[t],"p0.subtitle"),dataChannels:u(e=>e.dataChannels,[t],"p0.dataChannels"),link:u(e=>e.btnSeeMoreLink,[t],"p0.btnSeeMoreLink"),planId:u(e=>e.title,[t],"p0.title"),text:u(e=>e.btnSeeMoreText,[t],"p0.btnSeeMoreText")}},3,"Tv_0")],1,null),n("div",null,{class:"justify-center items-start self-stretch flex gap-2.5 mt-2.5"},t.channels.map((e,a)=>n("img",{alt:G(e.attributes.alternativeText),src:G(e.attributes.url),title:G(e.attributes.caption)},{class:"aspect-square object-contain object-center w-full overflow-hidden flex-1",height:50,loading:"lazy",width:50},null,3,a)),1,null)],1,null),n("div",null,{class:"border-gary-500 h-[1px] w-full border-t-2"},null,3,null),n("div",null,{class:"self-stretch w-full h-px mt-5 max-md:mx-0.5"},null,3,null),n("div",null,{class:"text-blue-800 text-base mt-5"},t.features.map((e,a)=>n("span",null,{class:"my-1 flex flex-row items-center justify-start"},[n("div",null,null,o(br,{class:"mx-2 h-[20px] w-[20px] fill-primary-blue text-primary-blue",[s]:{class:s}},3,"Tv_1"),1,null),n("h3",null,{class:"text-sm font-light"},y(e,"Text"),1,a)],1,a)),1,null)],1,null),o($a,{get link(){return t.btnLink},get text(){return t.btnText},[s]:{link:u(e=>e.btnLink,[t],"p0.btnLink"),text:u(e=>e.btnText,[t],"p0.btnText")}},3,"Tv_2")],1,"Tv_3"),Vf=m(x(Uf,"s_0v0O47RLS1E")),Yf=t=>n("div",null,{class:"flex flex-col items-center justify-center my-8 mx-4"},[n("h2",null,{class:"text-3xl text-center md:text-5xl font-semibold text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-4 my-6"},t.data.map((e,a)=>o(Vf,{get logo(){return e.Logo.data.attributes},get title(){return e.Title},get subtitle(){return e.Subtitle},get price(){return e.Price},get priceTime(){return e.Pricetime},get description(){return e.Description},get channels(){return e.Channels.data},get btnSeeMoreLink(){return e.LineupButton.Link},get btnSeeMoreText(){return e.LineupButton.Text},get features(){return e.Features},get btnLink(){return e.Button.Link},get btnText(){return e.Button.Text},get dataChannels(){return t.dataChannels},[s]:{btnLink:f(e.Button,"Link"),btnSeeMoreLink:f(e.LineupButton,"Link"),btnSeeMoreText:f(e.LineupButton,"Text"),btnText:f(e.Button,"Text"),channels:f(e.Channels,"data"),dataChannels:u(l=>l.dataChannels,[t],"p0.dataChannels"),description:f(e,"Description"),features:f(e,"Features"),logo:f(e.Logo.data,"attributes"),price:f(e,"Price"),priceTime:f(e,"Pricetime"),subtitle:f(e,"Subtitle"),title:f(e,"Title")}},3,a)),1,null)],1,"q0_0"),Zf=m(x(Yf,"s_m0jKnAHnXds")),Jf=t=>n("div",null,{class:"flex flex-col items-center justify-center px-6"},[n("h2",null,{class:"text-3xl md:text-5xl my-3 font-semibold text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap gap-8 items-start justify-center my-4"},t.data.map((e,a)=>n("div",null,{class:"flex flex-col w-full md:w-2/5 my-3 md:my-5 p-6 text-center items-center justify-center rounded-2xl bg-white shadow-xl"},[n("h3",null,{class:"text-primary-dark-blue my-4 font-semibold text-xl"},y(e,"Title"),1,null),o(I,{get text(){return e.Paragraph},[s]:{text:f(e,"Paragraph")}},3,"ys_0")],1,a)),1,null),o(I,{classN:"markdownli text-s",get text(){return t.disclaimers},[s]:{classN:s,text:u(e=>e.disclaimers,[t],"p0.disclaimers")}},3,"ys_1")],1,"ys_2"),Xf=m(x(Jf,"s_Sqd58asrM5U")),Kf=t=>{let e=[];return n("div",null,{class:"flex flex-col items-center justify-center"},[n("h2",null,{class:"text-3xl text-center md:text-5xl my-3 font-semibold text-primary-blue"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap items-start justify-center my-6 gap-5"},t.data.map((a,l)=>n("div",null,{class:"w-[290px] min-h-[300px] py-6 px-2 flex-col items-center justify-center flex rounded-3xl bg-primary-blue"},[n("h2",null,{class:"text-3xl font-semibold text-white"},y(a,"Title"),1,null),n("div",null,{class:"flex flex-row"},[n("h2",null,{class:"text-white text-2xl"},["$ ",y(a,"Price")],1,null),n("p",null,{class:"text-white"},[" ",y(a,"Pricetime")],1,null)],1,null),n("div",null,{class:"flex flex-col bg-white w-full rounded-2xl mt-4 p-4"},a.Features.map((r,i)=>{if(Z(),i<3)return e=[],n("div",null,{class:"flex flex-row gap-2 p-1 border-b-2"},[o(Hn,{class:"text-secondary-red",[s]:{class:s}},3,"yk_0"),n("p",null,{class:"text-primary-blue"},y(r,"Title"),1,null)],1,i);if(i>=3&&(e.push(n("div",null,{class:"flex flex-row gap-2 p-1 border-b-2"},[o(Hn,{class:"text-secondary-red",[s]:{class:s}},3,"yk_1"),n("p",null,{class:"text-primary-blue"},y(r,"Title"),1,null)],1,i)),i==3))return o(ge,{children:e,title:"Show all channels",[s]:{title:s}},1,"yk_2")}),1,null)],1,l)),1,null)],1,"yk_3")},tx=m(x(Kf,"s_5iYsl7ZjuZc")),ex=t=>{const e=t.data.data.pageGfTv.data.attributes,a=t.data.data.sectionChGuide.data.attributes,l=t.data.data.channelLineups.data;return n("div",null,{class:"flex flex-col justify-around"},[n("div",null,{class:"flex flex-col my-6 items-center justify-center gap-4"},[n("img",{alt:y(e.Logo.data.attributes,"alternativeText"),src:G(e.Logo.data.attributes.url),title:y(e.Logo.data.attributes,"caption")},{height:200,width:500},null,3,null),n("h2",null,{class:"text-[40px] font-semibold text-center text-primary-blue"},y(e.Titles[0],"Text"),1,null),n("h2",null,{class:"text-[40px] font-semibold text-center text-secondary-red"},y(e.Titles[1],"Text"),1,null)],1,null),o(Wf,{get data(){return e.Features},[s]:{data:f(e,"Features")}},3,"5L_0"),n("div",null,{class:"flex flex-col text-center p-4 items-center justify-center my-8"},[n("h2",null,{class:"text-3xl md:text-5xl font-semibold text-primary-blue"},y(e.Feature,"Title"),1,null),o(I,{get text(){return e.Feature.Paragraph},[s]:{text:f(e.Feature,"Paragraph")}},3,"5L_1")],1,null),o(Zf,{dataChannels:l,get data(){return e.ChPackTables},get title(){return e.ChPackTitle},[s]:{data:f(e,"ChPackTables"),title:f(e,"ChPackTitle")}},3,"5L_2"),o(tx,{get data(){return e.PremiumTables},get title(){return e.PremiumTitle},[s]:{data:f(e,"PremiumTables"),title:f(e,"PremiumTitle")}},3,"5L_3"),n("div",null,{class:"flex w-full flex-col items-center justify-center"},[n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex min-[800px]:w-[70%] flex-col items-center justify-center gap-4 px-10"},[n("div",null,{class:"max-w-[470px]"},n("img",{alt:y(a.Logo.data.attributes,"alternativeText"),src:G(a.Logo.data.attributes.url),title:y(a.Logo.data.attributes,"caption")},{height:"230",width:"1230"},null,3,null),1,null),n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},y(a,"Title"),1,null),1,null),o(I,{get text(){return a.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{classN:s,text:f(a,"Paragraph")}},3,"5L_4")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},o(Mr,{get nameDoc(){return a.GuideBox.Guide.data.attributes.name},get urlDoc(){return a.GuideBox.Guide.data.attributes.url},get image(){return a.Picture.data.attributes},get title(){return a.GuideBox.Title},get btnText(){return a.GuideBox.BtnText},[s]:{btnText:f(a.GuideBox,"BtnText"),image:f(a.Picture.data,"attributes"),nameDoc:f(a.GuideBox.Guide.data.attributes,"name"),title:f(a.GuideBox,"Title"),urlDoc:f(a.GuideBox.Guide.data.attributes,"url")}},3,"5L_5"),1,null)],1,null),o(Xf,{get data(){return e.Additionals},get disclaimers(){return e.Disclaimers},get title(){return e.AdditionalsTitle},[s]:{data:f(e,"Additionals"),disclaimers:f(e,"Disclaimers"),title:f(e,"AdditionalsTitle")}},3,"5L_6")],1,null)],1,"5L_7")},ax=m(x(ex,"s_dsszBuF1I7U")),lx=t=>`sectionChGuide(locale:"${t}"){
        data{
          attributes{
            Logo{
              ${v}
            }
            Title
            Paragraph
            
            GuideBox{
              BtnText
              Guide{
                data{
                  attributes{
                    name
                    url
                  }
                }
              }
            }
            
            Picture{
             ${v}
            }
          }
        }
      }`,nx=t=>`query {
        pageGfTv(locale:"${t}"){
          data {
            attributes {
              Logo {
               ${v}
              }
              Titles {
                Text
              }
              Features {
                Title
                Subtitle
                Paragraph
                Media {
                  ${v}
                }
              }
              Feature {
                Title
                Subtitle
                Paragraph
              }
              ChPackTitle
              ChPackTables {
                Logo {
                  ${v}
                }
                Title
                Subtitle
                Price
                Pricetime
                Description
                Channels {
                  ${v}
                }
                LineupButton{
                  Text
                  Link
                }
                Features {
                  Title
                  Text
                }
                Button {
                  Text
                  Link
                }
              }
              PremiumTitle
              PremiumTables {
                Title
                Price
                Pricetime
                Features {
                  Title
                }
              }
      
              
              
              AdditionalsTitle
              Additionals {
                Title
                Paragraph
              }
              Disclaimers
              
              ${R}
            }
          }
        }
        
        ${lx(t)}

        channelLineups (pagination:{limit:250}){
          data{
            attributes{
              Channel_name
              Image{
                ${v}
              }
              Category
              package_tvs{
                data{
                  attributes{
                    package
                  }
                }
              }
            }
        }
        }
      }`,sx=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(nx,e)},Kl=A(x(sx,"s_dLnU84H8AgM")),rx=()=>{const t=Kl();return console.log(t.value.pageData),o(Q,{children:o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageGfTv.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfTv.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfTv"]["data"]["attributes"]["SEO"]')}},3,"ad_0"),o(ax,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"ad_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"ad_2")},1,"ad_3")},ix=m(x(rx,"s_yF5Z09ey0P4")),ox=({resolveValue:t})=>{const a=t(Kl).pageData.data.pageGfTv.data.attributes.SEO;return H(a)},ux=Object.freeze(Object.defineProperty({__proto__:null,default:ix,head:ox,usePageData:Kl},Symbol.toStringTag,{value:"Module"})),cx=t=>{const e=t.data.pageGfVS.data.attributes,a=t.data.sectionPortGfv.data.attributes.Portability;return n("div",null,{class:"flex flex-col items-center"},[n("div",null,{class:"relative w-full md:w-2/3 h-[210px] md:h-[150px] bg-blue-200 flex flex-row justify-end items-center rounded-full"},[n("div",null,{class:"h-full absolute rounded-full w-3/4 bg-blue-300"},null,3,null),n("div",null,{class:"h-full absolute rounded-full w-2/4 bg-blue-400"},null,3,null),n("div",null,{class:"h-full absolute rounded-full w-1/4 bg-blue-600"},null,3,null),n("div",null,{class:"absolute w-full h-full flex flex-row p-5 justify-between items-center"},[n("h1",null,{class:"text-primary-blue lg:text-3xl md:text-2xl font-bold text-center text-xl"},y(e.Introduction,"Paragraph"),1,null),n("img",{alt:y(e.Introduction.Media.data.attributes,"alternativeText"),src:G(e.Introduction.Media.data.attributes.url),title:y(e.Introduction.Media.data.attributes,"caption")},{height:150,width:200},null,3,null)],1,null)],1,null),n("div",null,{class:"flex flex-col mt-10 justify-center px-8 items-center"},[n("div",null,{class:"w-full md:w-2/3 flex flex-col items-center"},[n("h2",null,{class:"text-3xl md:text-4xl text-center font-bold text-primary-blue"},y(e.GuidesPar,"Title"),1,null),o(I,{classN:"text-center",get text(){return e.GuidesPar.Paragraph},[s]:{classN:s,text:f(e.GuidesPar,"Paragraph")}},3,"T3_0")],1,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-10 my-5"},e.Guides.map((l,r)=>o(Lr,{get urlDoc(){return l.Guide.data.attributes.url},get title(){return l.Title},get btnText(){return l.BtnText},get nameDoc(){return l.Guide.data.attributes.name},[s]:{btnText:f(l,"BtnText"),nameDoc:f(l.Guide.data.attributes,"name"),title:f(l,"Title"),urlDoc:f(l.Guide.data.attributes,"url")}},3,r)),1,null)],1,null),n("div",null,null,o(At,{get title(){return a.Title},get text(){return a.Paragraph},get logo(){return a.Logo.data.attributes},get image(){return a.Media.data.attributes},get buttons(){return a.Buttons},[s]:{buttons:f(a,"Buttons"),image:f(a.Media.data,"attributes"),logo:f(a.Logo.data,"attributes"),text:f(a,"Paragraph"),title:f(a,"Title")}},3,"T3_1"),1,null)],1,"T3_2")},dx=m(x(cx,"s_BWUEQjQaK9s")),px=t=>`query queryGFTvSupport{
        pageGfVS(locale:"${t}"){
          data{
            attributes{
              Introduction{
                Paragraph
                Media{
                  ${v}
                }
              }
              GuidesPar{
                Title
                Paragraph
              }
              Guides{
                Title
                BtnText
                Guide{
                  data{
                    attributes{
                      url
                      name
                    }
                  }
                }
              }
              ${R}
            }
          }
        }
        sectionPortGfv(locale:"${t}"){
          data{
            attributes{
              Portability{
                Title
                Logo{
                 ${v}
                }
                Paragraph
                Media{
                 ${v}
                }
                Buttons{
                  Text
                  Link
                }
              }
            }
          }
        }
      }`,gx=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(px,e)},tn=A(x(gx,"s_MmL0KO3X80U")),fx=()=>{const t=tn();return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:o(dx,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Wc_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Wc_1")},1,"Wc_2")},xx=m(x(fx,"s_MnhzpLl96M8")),mx=({resolveValue:t})=>{const a=t(tn).pageData.data.pageGfVS.data.attributes.SEO;return H(a)},$x=Object.freeze(Object.defineProperty({__proto__:null,default:xx,head:mx,usePageData:tn},Symbol.toStringTag,{value:"Module"})),hx=t=>n("div",null,{class:"flex w-full justify-center text-primary-blue"},n("div",null,{class:"mx-8 my-8 flex flex-col items-center gap-6 text-center text-[18px]"},[o(z,{get url(){return t.data.Logo.data.attributes.url},get alt(){return t.data.Logo.data.attributes.alternativeText},get title(){return t.data.Logo.data.attributes.caption},clasN:"mb-6",width:"450",[s]:{alt:u(e=>e.data.Logo.data.attributes.alternativeText,[t],'p0.data["Logo"]["data"]["attributes"]["alternativeText"]'),clasN:s,title:u(e=>e.data.Logo.data.attributes.caption,[t],'p0.data["Logo"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.Logo.data.attributes.url,[t],'p0.data["Logo"]["data"]["attributes"]["url"]'),width:s}},3,"0F_0"),o(I,{get text(){return t.data.Paragraph},[s]:{text:u(e=>e.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"0F_1"),o(X,{get text(){return t.data.Buttons[0].Text},get link(){return t.data.Buttons[0].Link},[s]:{link:u(e=>e.data.Buttons[0].Link,[t],'p0.data["Buttons"][0]["Link"]'),text:u(e=>e.data.Buttons[0].Text,[t],'p0.data["Buttons"][0]["Text"]')}},3,"0F_2")],1,null),1,"0F_3"),bx=m(x(hx,"s_Ue8VWX4F1hY")),vx=t=>n("div",null,{class:"max-w-1200 mx-8 flex flex-wrap justify-evenly gap-6"},t.data.map((e,a)=>o(Vl,{get title(){return e.Title},get btnText(){return e.Button.Text},get btnLink(){return e.Button.Link},get description(){return e.Description},price:e.Price.toString(),get features(){return e.Features},get logo(){return e.Logo.data.attributes},get priceTime(){return e.Pricetime},[s]:{btnLink:f(e.Button,"Link"),btnText:f(e.Button,"Text"),description:f(e,"Description"),features:f(e,"Features"),logo:f(e.Logo.data,"attributes"),priceTime:f(e,"Pricetime"),title:f(e,"Title")}},3,a)),1,"mV_0"),yx=m(x(vx,"s_2f78m38d8Zo")),wx=t=>{const e={...t.data.pageGfV.data.attributes.Introduction,Logo:t.data.pageGfV.data.attributes.Logo},a=t.data.pageGfV.data.attributes.PackTables,l=t.data.sectionPortGfv.data.attributes.Portability;return n("div",null,null,[o(bx,{data:e},3,"Pl_0"),n("div",null,{class:"mt-6"},o(yx,{data:a},3,"Pl_1"),1,null),n("div",null,{class:"mt-6"},o(Nt,{backgroundColor:"transparent",color:"primary-blue",data:l,[s]:{backgroundColor:s,color:s}},3,"Pl_2"),1,null)],1,"Pl_3")},_x=m(x(wx,"s_S2NF7hg0ZA8")),Tx=t=>`
  query {
    pageGfV(locale:"${t}") {
      data {
        attributes {
          Logo {
            ${v}
          }
          Introduction {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          PackTables {
            Logo {
              ${v}
            }
            Title
            Subtitle
            Price
            Pricetime
            Description
            Features {
              Title
              Text
            }
            Button {
              Text
              Link
              Icon {
                data {
                  attributes {
                    name
                    url
                  }
                }
              }
            }
          }
          ${R}
        
        }
      }
    }
    sectionPortGfv(locale:"${t}"){
        data{
          attributes{
            Portability{
              Title
              Logo{
               ${v}
              }
              Paragraph
              Media{
               ${v}
              }
              Buttons{
                Text
                Link
              }
            }
          }
        }
      }
  }
    `,Sx=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(Tx,e)},en=A(x(Sx,"s_ThxJp560MGY")),Dx=()=>{const t=en();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageGfV.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfV.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfV"]["data"]["attributes"]["SEO"]')}},3,"0t_0"),o(_x,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"0t_1")],showHeader:!1,[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"0t_2")},Px=m(x(Dx,"s_1bc90Wt0fJ4")),kx=({resolveValue:t})=>{const a=t(en).pageData.data.pageGfV.data.attributes.SEO;return H(a)},Lx=Object.freeze(Object.defineProperty({__proto__:null,default:Px,head:kx,usePageData:en},Symbol.toStringTag,{value:"Module"})),Mx=t=>{const e=t.data.pageGivingBack.data.attributes.Helping;return n("div",null,{onClick$:F("s_IrVC6P6zSuQ")},o(Xt,{data:e},3,"eb_0"),1,"eb_1")},Cx=m(x(Mx,"s_g0kQhWSZ3HE")),jx=t=>`
    query QueryGivingBack {
        pageGivingBack(locale:"${t}"){    
          data{
            attributes{
                 Title
              Helping{
                Logo{
                 ${v}
                }
                Media{
                  ${v}
                }
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              ${R}
            }
          }
        }
      }
    `,Ix=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(jx,e)},an=A(x(Ix,"s_HxhGEMn0sRc")),Ex=()=>{const t=an();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageGivingBack.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGivingBack.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGivingBack"]["data"]["attributes"]["SEO"]')}},3,"4m_0"),o(Cx,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"4m_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"4m_2")},Ox=m(x(Ex,"s_NbmekxDi7Vw")),Bx=({resolveValue:t})=>{const a=t(an).pageData.data.pageGivingBack.data.attributes.SEO;return H(a)},Ax=Object.freeze(Object.defineProperty({__proto__:null,default:Ox,head:Bx,usePageData:an},Symbol.toStringTag,{value:"Module"})),qx=t=>`query QueryLeadershipTeam{
        pageLeadershipT(locale:"${t}"){
          data{
            attributes{
              ${$r}
              ${R}
              }
            }
          }
        }`,Nx=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(qx,e)},ln=A(x(Nx,"s_ZvTItzMmB40")),zx=()=>{const t=ln(),e=t.value.pageData.data.pageLeadershipT.data.attributes;return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageLeadershipT.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageLeadershipT.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageLeadershipT"]["data"]["attributes"]["SEO"]')}},3,"cW_0"),o(Pr,{data:e},3,"cW_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"cW_2")},1,"cW_3")},Rx=m(x(zx,"s_VJGz1Q1nMWA")),Gx=({resolveValue:t})=>{const a=t(ln).pageData.data.pageLeadershipT.data.attributes.SEO;return H(a)},Qx=Object.freeze(Object.defineProperty({__proto__:null,default:Rx,head:Gx,usePageData:ln},Symbol.toStringTag,{value:"Module"})),Fx=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),n("h2",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[1].Text,[t],'p0.data["Titles"][1]["Text"]'),3,null),o(I,{get text(){return t.data.TextContent},classN:" tracking-wider text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"tP_0")],1,"tP_1"),Hx=m(x(Fx,"s_l6pybhQ4d3A")),Wx=t=>`query QueryLegal {
        pageLegal(locale:"${t}"){    
          ${Ue}
          ${R}
            }
          }
        }
      }`,Ux=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(Wx,e)},nn=A(x(Ux,"s_p9UoBCtfUPo")),Vx=()=>{const t=nn(),e=t.value.pageData.data.pageLegal.data.attributes.Content;return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:o(Hx,{data:e},3,"W8_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"W8_1")},1,"W8_2")},Yx=m(x(Vx,"s_DAHSW75A6dQ")),Zx=({resolveValue:t})=>{const a=t(nn).pageData.data.pageLegal.data.attributes.SEO;return H(a)},Jx=Object.freeze(Object.defineProperty({__proto__:null,default:Yx,head:Zx,usePageData:nn},Symbol.toStringTag,{value:"Module"})),Xx=t=>{const e=t.data.pageLocWeather.data.attributes,a=l=>`https://raw.githubusercontent.com/visualcrossing/WeatherIcons/main/PNG/1st%20Set%20-%20Color/${l}.png`;return n("div",null,{class:"flex flex-wrap items-center justify-center gap-8 px-8 py-8 text-white",onClick$:F("s_VJdTV7fBj8k")},t.data.weatherData.data.map((l,r)=>n("div",null,{class:"relative h-[350px] w-[600px] max-[1200px]:h-[280px] max-[1200px]:w-[500px]"},[n("div",null,{class:"relative flex h-full w-[50%] flex-col justify-between overflow-hidden rounded-[30px] px-4 py-8 "},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-[6] h-full w-full"},o(z,{clasN:"h-[400px]",height:"3086",width:"2622",get url(){return e.LocTables.find(i=>i.Location===l.city).LocationPic.data.attributes.url},get alt(){return e.LocTables.find(i=>i.Location===l.city).LocationPic.data.attributes.alternativeText},get title(){return e.LocTables.find(i=>i.Location===l.city).LocationPic.data.attributes.caption},[s]:{alt:f(e.LocTables.find(i=>i.Location===l.city).LocationPic.data.attributes,"alternativeText"),clasN:s,height:s,title:f(e.LocTables.find(i=>i.Location===l.city).LocationPic.data.attributes,"caption"),url:f(e.LocTables.find(i=>i.Location===l.city).LocationPic.data.attributes,"url"),width:s}},3,"tT_0"),1,null),n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-[5] h-full w-full bg-black opacity-30"},null,3,null),n("div",null,{class:"flex flex-col"},[n("span",{onClick$:F("s_K3eGiPS50Ks",[l])},{class:"text-[20px] font-[700]"},Xe(l.data.days[0].datetime).split(", ")[0],0,null),n("span",null,{class:"text-[12px]"},Xe(l.data.days[0].datetime,!1),1,null),n("div",null,{class:"mt-2 flex items-center gap-3"},[o(Cl,{class:"text-[15px] text-white",[s]:{class:s}},3,"tT_1"),n("span",null,{class:"text-[17px] font-[600] max-[1200px]:text-[15px]"},y(l,"city"),1,null)],1,null)],1,null),n("div",null,null,[n("span",null,{class:"text-[18px] font-[700]"},y(l.data.days[0],"conditions"),1,null),n("img",{alt:`icon-${l.data.days[0].icon}`,src:a(l.data.days[0].icon),title:`icon-${l.data.days[0].icon}`},{height:"50",width:"50"},null,3,null)],1,null),n("div",null,{class:"flex w-full justify-evenly"},[n("div",null,{class:"flex flex-col items-center"},[n("span",null,{class:"text-[14px]"},"Min",3,null),n("span",null,{class:"text-[28px] font-[700] max-[1200px]:text-[20px]"},[y(l.data.days[0],"tempmin"),"°F"],1,null)],1,null),n("div",null,{class:"flex flex-col items-center"},[n("span",null,{class:"text-[14px]"},"Max",3,null),n("span",null,{class:"text-[28px] font-[700] max-[1200px]:text-[20px]"},[y(l.data.days[0],"tempmin"),"°F"],1,null)],1,null)],1,null)],1,null),n("div",null,{class:"absolute bottom-3 right-0 top-3 -z-[7] flex w-[56%] flex-col gap-1 rounded-[30px] bg-[#172c4b] py-8 pl-14 pr-6 text-[17px] max-[1200px]:text-[13px]"},[n("div",null,{class:"flex justify-between font-[700] "},[n("span",null,null,"PRECIPITATION",3,null),n("span",null,{class:"font-[300]"},[y(l.data.days[0],"precipprob"),"%"],1,null)],1,null),n("div",null,{class:"flex justify-between font-[700]"},[n("span",null,null,"HUMIDITY",3,null),n("span",null,{class:"font-[300]"},[y(l.data.days[0],"humidity"),"%"],1,null)],1,null),n("div",null,{class:"flex justify-between font-[700]"},[n("span",null,null,"WIND",3,null),n("span",null,{class:"font-[300]"},[y(l.data.days[0],"windspeed")," mph"],1,null)],1,null),n("div",null,{class:"mt-6 grid grid-cols-3 justify-center gap-1"},[1,2,3].map(i=>n("div",null,{class:"flex flex-col items-center gap-1 text-[12px] max-[1200px]:text-[9px]"},[n("img",{alt:`icon-${l.data.days[i].icon}`,src:a(l.data.days[i].icon),title:`icon-${l.data.days[i].icon}`},{height:"30",width:"30"},null,3,null),n("span",null,{class:""},Xe(l.data.days[i].datetime).split(", ")[0],1,null),n("span",null,{class:"font-[600]"},[y(l.data.days[i],"tempmax"),"°F"],1,null),n("span",null,{class:"font-[600]"},[y(l.data.days[i],"tempmin"),"°F"],1,null)],1,i)),1,null)],1,null)],1,r)),1,"tT_2")},Kx=m(x(Xx,"s_Eyqu8EYnqHs")),tm=t=>`query locWeather{
        pageLocWeather(locale:"${t}"){
          data{
            attributes{
              LocTables{
                Location
                LocationPic{
                  ${v}
                }
              }
              ${R}
            }
          }
        }
      }`,em=async t=>{const e=t.params.lang==""?"en":"es-419",a=await q(tm,e),l={status:"error",data:[]};for(const r of a.pageData.data.pageLocWeather.data.attributes.LocTables){const i=r.Location,c=await fetch(`https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${i}/next7days?unitGroup=us&include=days%2Ccurrent&key=J8MMBMZC9DTQTVGHBPNEWPPGS&contentType=json`);if(c.ok){const d=await c.json();l.data.push({city:i,data:d})}}return{...a,weatherData:l}},sn=A(x(em,"s_gwWti8fe82E")),am=()=>{const t=sn();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageLocWeather.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageLocWeather.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageLocWeather"]["data"]["attributes"]["SEO"]')}},3,"rD_0"),o(Kx,{get data(){return{pageLocWeather:t.value.pageData.data.pageLocWeather,weatherData:t.value.weatherData}},[s]:{data:u(e=>({pageLocWeather:e.value.pageData.data.pageLocWeather,weatherData:e.value.weatherData}),[t],'{pageLocWeather:p0.value["pageData"]["data"]["pageLocWeather"],weatherData:p0.value["weatherData"]}')}},3,"rD_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"rD_2")},lm=m(x(am,"s_VS5ugbSZKZs")),nm=({resolveValue:t})=>{const a=t(sn).pageData.data.pageLocWeather.data.attributes.SEO;return H(a)},sm=Object.freeze(Object.defineProperty({__proto__:null,default:lm,head:nm,usePageData:sn},Symbol.toStringTag,{value:"Module"})),rm=t=>{const e=t.data.pageNews.data.attributes,a=e.Posts.data[0].attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[o(Sr,{post:a},3,"MY_0"),n("div",null,{class:"my-4"},null,3,null),o(Dr,{get posts(){return e.Posts.data},loadSize:3,type:"News",[s]:{loadSize:s,posts:f(e.Posts,"data"),type:s}},3,"MY_1")],1,"MY_2")},im=m(x(rm,"s_d8TgHnXz650")),om=t=>` query QueryNews {
        pageNews(locale:"${t}"){    
          data{
          attributes{
            Posts(sort: "Date:desc", pagination: { limit: 100 }){
                data{
                  attributes{
                    Title
                    Date
                    Cover{
                      ${v}
                    }
                    Description
                    VideoLink
                    Gallery{
                      ${v}
                    }
                    Slug
                  }
                }
              }
            SugPages{
              Title
              Pages{
              Title
              Link
              Picture{
                ${v}
              }
              }
            }
            ${R}
          }
        }
        }
      }`,um=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(om,e)},rn=A(x(um,"s_HdPbxCOsb5s")),cm=()=>{const t=rn();return o(N,{get data(){return t.value.layoutData},children:o(im,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"7N_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"7N_1")},dm=m(x(cm,"s_Afg1iFacoB8")),pm=({resolveValue:t})=>{const a=t(rn).pageData.data.pageNews.data.attributes.SEO;return H(a)},gm=Object.freeze(Object.defineProperty({__proto__:null,default:dm,head:pm,usePageData:rn},Symbol.toStringTag,{value:"Module"})),fm=t=>n("div",null,{class:"flex flex-col items-center text-primary-blue"},[n("h2",null,{class:"px-4 md:px-8 text-center font-semibold text-secondary-red text-2xl md:text-3xl"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),n("h3",null,{class:"px-4 md:px-8 text-center text-xl md:text-2xl"},u(e=>e.data.Titles[1].Text,[t],'p0.data["Titles"][1]["Text"]'),3,null),n("div",null,{class:"flex px-4 md:px-8 mt-5 flex-wrap items-center justify-center"},[n("div",null,{class:"flex flex-col w-full lg:w-3/5 mx-5"},[n("h3",null,{class:"font-bold my-4 text-2xl md:text-4xl text-center"},u(e=>e.data.CommitmentPar.Title,[t],'p0.data["CommitmentPar"]["Title"]'),3,null),o(I,{get text(){return t.data.CommitmentPar.Paragraph},classN:"text-justify",[s]:{classN:s,text:u(e=>e.data.CommitmentPar.Paragraph,[t],'p0.data["CommitmentPar"]["Paragraph"]')}},3,"aa_0")],1,null),o(Ee,{height:"h-[350px]",width:"w-[350px]",get alt(){return t.data.CommitmentPar.Media.data.attributes.alternativeText},get url(){return t.data.CommitmentPar.Media.data.attributes.url},get title(){return t.data.CommitmentPar.Media.data.attributes.caption},[s]:{alt:u(e=>e.data.CommitmentPar.Media.data.attributes.alternativeText,[t],'p0.data["CommitmentPar"]["Media"]["data"]["attributes"]["alternativeText"]'),height:s,title:u(e=>e.data.CommitmentPar.Media.data.attributes.caption,[t],'p0.data["CommitmentPar"]["Media"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.CommitmentPar.Media.data.attributes.url,[t],'p0.data["CommitmentPar"]["Media"]["data"]["attributes"]["url"]'),width:s}},3,"aa_1")],1,null),n("div",null,{class:"flex px-8 mt-8 flex-col md:flex-row justify-center md:justify-around items-center md:items-start"},t.data.ColumnsPar.map((e,a)=>n("div",null,{class:"flex flex-col my-5 w-full md:w-1/2 justify-center items-center"},[n("h2",null,{class:"font-bold  text-2xl md:text-4xl text-center"},y(e,"Title"),1,null),o(I,{get text(){return e.Paragraph},[s]:{text:f(e,"Paragraph")}},3,"aa_2")],1,a)),1,null),n("h3",null,{class:"font-bold text-2xl md:text-4xl mt-8 text-center"},u(e=>e.data.SponsorshipsTitle,[t],'p0.data["SponsorshipsTitle"]'),3,null),n("div",null,{class:"flex items-center justify-center w-full my-4"},[n("div",null,{class:"w-full flex bg-primary-blue bg-opacity-30 my-4 h-[350px] py-10"},n("div",null,{class:"w-full bg-primary-blue py-10 bg-opacity-60"},n("div",null,{class:"w-full h-full bg-primary-blue"},null,3,null),3,null),3,null),t.data.Sponsorships.map((e,a)=>n("div",null,{class:"h-[350px] px-6 absolute flex flex-col justify-around items-center w-[250px] bg-white rounded-3xl shadow-xl"},[o(Ee,{height:"h-[200px]",width:"w-[200px]",get alt(){return e.Media.data.attributes.alternativeText},get url(){return t.data.Sponsorships[0].Media.data.attributes.url},get title(){return t.data.Sponsorships[0].Media.data.attributes.caption},[s]:{alt:f(e.Media.data.attributes,"alternativeText"),height:s,title:u(l=>l.data.Sponsorships[0].Media.data.attributes.caption,[t],'p0.data["Sponsorships"][0]["Media"]["data"]["attributes"]["caption"]'),url:u(l=>l.data.Sponsorships[0].Media.data.attributes.url,[t],'p0.data["Sponsorships"][0]["Media"]["data"]["attributes"]["url"]'),width:s}},3,"aa_3"),n("div",null,{class:"flex flex-col items-center"},[n("h3",null,{class:"text-secondary-red text-xl font-semibold"},y(e,"Title"),1,null),n("h3",null,{class:"text-secondary-red text-xl font-semibold"},y(e,"Subtitle"),1,null)],1,null),o(X,{get text(){return e.Buttons[0].Text},get link(){return e.Buttons[0].Link},[s]:{link:f(e.Buttons[0],"Link"),text:f(e.Buttons[0],"Text")}},3,"aa_4")],1,a))],1,null)],1,"aa_5"),xm=m(x(fm,"s_RH3prNj9z7A")),mm=t=>`query QueryOurStory{
        pageOurStory(locale:"${t}"){
          data{
            attributes{
              Titles{
                Text
              }
              CommitmentPar{
                Title
                Paragraph
                Media{
                ${v}
                }
              }
              
              ColumnsPar{
                Title
                Paragraph
              }
              
              SponsorshipsTitle
              Sponsorships{
                Title
                Subtitle
                Paragraph
                Media{
                ${v}
                }
                Buttons{
                  Text
                  Link
                }
              }
              ${R}
             
            }
          }
        }
      }`,$m=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(mm,e)},on=A(x($m,"s_I9YCjFVOHNE")),hm=()=>{const t=on(),e=t.value.pageData.data.pageOurStory.data.attributes;return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return e.SEO},[s]:{SEOdata:f(e,"SEO")}},3,"CH_0"),o(xm,{data:e},3,"CH_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"CH_2")},1,"CH_3")},bm=m(x(hm,"s_ONSPkGdkwcs")),vm=({resolveValue:t})=>{const a=t(on).pageData.data.pageOurStory.data.attributes.SEO;return H(a)},ym=Object.freeze(Object.defineProperty({__proto__:null,default:bm,head:vm,usePageData:on},Symbol.toStringTag,{value:"Module"})),wm=t=>{const e=t.data.Logo.data.attributes,a=t.data.Media.data.attributes;return n("div",null,{class:"flex max-w-[1200px] items-center justify-center self-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-4 px-10 min-[800px]:w-[70%]"},[n("div",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(l=>l.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"max-w-[470px]"},o(z,{get url(){return e.url},get alt(){return e.alternativeText},get title(){return e.caption},height:230,width:1230,[s]:{alt:f(e,"alternativeText"),height:s,title:f(e,"caption"),url:f(e,"url"),width:s}},3,"Y3_0"),1,null),n("div",null,null,o(I,{classN:"max-sm:text-[15px] text-[18px] text-[#2E5899]",get text(){return t.data.Paragraph},[s]:{classN:s,text:u(l=>l.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"Y3_1"),1,null)],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},o(z,{get url(){return a.url},get alt(){return a.alternativeText},get title(){return a.caption},height:1e3,width:1e3,[s]:{alt:f(a,"alternativeText"),height:s,title:f(a,"caption"),url:f(a,"url"),width:s}},3,"Y3_2"),1,null)],1,"Y3_3")},_m=m(x(wm,"s_G8eOcGEKYk4")),Tm=t=>{const e=t.data.pagePortability.data.attributes.PortabilityActs,a=t.data.pagePortability.data.attributes.Introduction;return n("div",null,{class:"flex flex-col items-center justify-center"},[o(_m,{data:a},3,"C7_0"),o(Xt,{data:e},3,"C7_1")],1,"C7_2")},Sm=m(x(Tm,"s_OvPpWmexBMU")),Dm=t=>`
    query QueryPortability{
        pagePortability(locale:"${t}"){    
          data{
            attributes{
              Introduction{
                Title
                Subtitle
                Logo{
                ${v}
                }
                Paragraph
                Media{
                ${v}
                }
              }
              
              IntroductionBG{
                ${v}
              }
      
              PortabilityActs{
                Title
                Subtitle
                Buttons{
                  Text
                  Link
                }
                Logo{
                ${v}
                }
                Paragraph
                Media{
                ${v}
                }
              }
              ${R}
            }
          }
        }
      }
    `,Pm=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(Dm,e)},un=A(x(Pm,"s_DV97RmVctT4")),km=()=>{const t=un();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pagePortability.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pagePortability.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pagePortability"]["data"]["attributes"]["SEO"]')}},3,"eB_0"),o(Sm,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"eB_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"eB_2")},Lm=m(x(km,"s_LbhuqOuteuA")),Mm=({resolveValue:t})=>{const a=t(un).pageData.data.pagePortability.data.attributes.SEO;return H(a)},Cm=Object.freeze(Object.defineProperty({__proto__:null,default:Lm,head:Mm,usePageData:un},Symbol.toStringTag,{value:"Module"})),Cr=new Date,jm=Cr.toISOString().substring(0,10),Im=Cr.toISOString().substring(11,19),jr=t=>`
    query QueryHome{
  pageHome(locale:"${t}"){
    data{
      attributes{
        
        VideoBGDesktop{
          ${v}
        }
        VideoBGMobile{
          ${v}
        }
        HeroCarSlideZS{
          Video{
            ${v}
          }
          Description
          Logo{
            ${v}
          }
          RaceDate
        }

        HeroCarSlides{
          Title
          Subtitle
          Logo{
          ${v}
          }
          Paragraph
          Media{
          ${v}
          }
          Buttons{
            Text
            Link
          }
        }
        HeroForm{
          Title
          ActionButton{
            Text
            Link
          }
        }
        ProsPar{
          Title
          Paragraph
        }

        ProsPicture{
          ${v}
        }
        ProsBackground{
          ${v}
        }
        ParACP{
          Title
          Subtitle
          Paragraph
          Logo{
          ${v}
          }
          Media{
          ${v}
          }
          Buttons{
            Text
            Link
          }
        }
        ParGFIPlans{
          Title
          Paragraph
          Disclaimer{
            Title
            Text
            Caption
            Icon{
          ${v}
            }
          }
          Table{
            ColumnOne
            ColumnTwo
            ColumnThree
          }

        }
        ParGFServices{
          Title
          Subtitle
          Logo{
          ${v}
          }
          Paragraph
          Media{
          ${v}
          }
          Buttons{
            Text
            Link
          }
        }
        SugsPages{
          Title
          Paragraph
          Media{
          ${v}
          }
          Buttons{
            Text
            Link
          }
        }
        SugsPagesBG{
          ${v}
        }
        ${R}
      }
    }
  }
  zaneRaces (
    filters: {RaceDay: {gte: "${jm}"}, RaceTime: {gte: "${Im}"}}, 
    locale:"en", 
    sort: "RaceDate"
    pagination: {limit: 1}) {
    data {
      attributes {
        Video {
          data {
            attributes {
              url
              alternativeText
              caption
            }
          }
        }
        Logo {
          data {
            attributes {
              url
              alternativeText
              caption
            }
          }
        }
        Description
        RaceDay
        RaceTime
      }
    }
  }
  sectionProsRta {
    data {
      attributes {
        Pros {
          Icon {
            data {
            attributes {
              url
              alternativeText
              caption
            }
          }
          }
          Title
          Text
          Caption
        }
      }
    }
  }
  sectionNetwork {
    data {
      attributes {
        Map {
          MapPicture {
            data {
              attributes {
                url
              }
            }
          }
        }
      }
    }
  }
}
`,Em=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang;return await q(jr,e)},Om=A(x(Em,"s_MfWlD1sVVR8")),Bm=()=>n("div",null,null,"a",3,"yK_0"),Am=m(x(Bm,"s_S2euYekMMCk")),qm=Object.freeze(Object.defineProperty({__proto__:null,default:Am,usePageData:Om},Symbol.toStringTag,{value:"Module"})),Nm=t=>n("div",null,{class:"p-6"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),o(I,{get text(){return t.data.TextContent},classN:"markdownTitle markdownHyper tracking-wider text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"Vp_0")],1,"Vp_1"),zm=m(x(Nm,"s_m0xHvviU9eM")),Rm=t=>`
query QueryPrivacyP {
  pagePrivacyP(locale:"${t}"){    
    ${Ue}
    ${R}
      }
    }
  }
}
`,Gm=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(Rm,e)},cn=A(x(Gm,"s_010w2sLh1OQ")),Qm=()=>{const t=cn(),e=t.value.pageData.data.pagePrivacyP.data.attributes.Content;return o(N,{get data(){return t.value.layoutData},children:o(zm,{data:e},3,"bX_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"bX_1")},Fm=m(x(Qm,"s_vRJXLmWn290")),Hm=({resolveValue:t})=>{const a=t(cn).pageData.data.pagePrivacyP.data.attributes.SEO;return H(a)},Wm=Object.freeze(Object.defineProperty({__proto__:null,default:Fm,head:Hm,usePageData:cn},Symbol.toStringTag,{value:"Module"})),Um=t=>n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"min-h-[200px] w-full bg-gradient-to-br from-primary-light-blue to-[#23477f] !text-white"},o(Nt,{get data(){return t.data},backgroundColor:"primary-blue",color:"white",hasPricing:!1,reverse:!0,[s]:{backgroundColor:s,color:s,data:u(e=>e.data,[t],"p0.data"),hasPricing:s,reverse:s}},3,"7j_0"),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"7j_1"),Vm=m(x(Um,"s_05kJ0dE4eLY")),Ym=t=>{const e=t.data.pageReferralP.data.attributes,a=e.Steps.Bullets.map(l=>l.Text);return n("div",null,null,[o(Vm,{get data(){return e.RefInfo},[s]:{data:f(e,"RefInfo")}},3,"Kl_0"),n("div",null,{class:"flex items-center justify-center px-8 py-8"},n("div",null,{class:" max-w-[1400px] "},[n("h4",null,{class:"mb-6 text-center text-[20px] font-[500] leading-6 text-primary-blue"},y(e,"StepsIntro"),1,null),n("h3",null,{class:"mb-6 text-center text-[42px] font-[700] leading-10 text-secondary-red"},y(e.Steps,"Title"),1,null),n("div",null,{class:"max-[799px]:hidden"},o(Ie,{align:"center",direction:"vertical",steps:a,[s]:{align:s,direction:s}},3,"Kl_1"),1,null),n("div",null,{class:"min-[800px]:hidden"},o(Ie,{align:"start",direction:"vertical",steps:a,[s]:{align:s,direction:s}},3,"Kl_2"),1,null)],1,null),1,null)],1,"Kl_3")},Zm=m(x(Ym,"s_lTuY9A29ePc")),Jm=t=>`
  query QueryReferralProgram{
    pageReferralP(locale:"${t}"){
      data{
        attributes{
            RefInfo{
          Title
          Subtitle
          Paragraph
          Media{
            ${v}
          }
        }
          StepsIntro
          Steps{
            Title
            Bullets{
              Text
              Caption
            }
          }
          ${R}
        }
      }
    }
  }
    `,Xm=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(Jm,e)},dn=A(x(Xm,"s_xJNMjIe9Xxc")),Km=()=>{const t=dn();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageReferralP.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageReferralP.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageReferralP"]["data"]["attributes"]["SEO"]')}},3,"Mu_0"),o(Zm,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Mu_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Mu_2")},t$=m(x(Km,"s_jMvbzO8YesI")),e$=({resolveValue:t})=>{const a=t(dn).pageData.data.pageReferralP.data.attributes.SEO;return H(a)},a$=Object.freeze(Object.defineProperty({__proto__:null,default:t$,head:e$,usePageData:dn},Symbol.toStringTag,{value:"Module"})),l$=t=>{const e=t.data.pageResidential.data.attributes.Services;return n("div",null,null,o(Xt,{data:e},3,"jS_0"),1,"jS_1")},n$=m(x(l$,"s_2a10udsh6KM")),s$=t=>`
  query QueryResidential {
    pageResidential(locale:"${t}"){    
      data{
        attributes{
          Services{
            Logo{
            ${v}
            }
            Media{
            ${v}
            }
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
          ${R}
        }
      }
    }
  }
    `,r$=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(s$,e)},pn=A(x(r$,"s_LcXJ0iBV25I")),i$=()=>{const t=pn();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageResidential.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageResidential.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageResidential"]["data"]["attributes"]["SEO"]')}},3,"O0_0"),o(n$,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"O0_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"O0_2")},o$=m(x(i$,"s_2tXslNmi0k4")),u$=({resolveValue:t})=>{const a=t(pn).pageData.data.pageResidential.data.attributes.SEO;return H(a)},c$=Object.freeze(Object.defineProperty({__proto__:null,default:o$,head:u$,usePageData:pn},Symbol.toStringTag,{value:"Module"})),d$=t=>{const e=t.data.data.pageSupport.data.attributes,a=t.data.data.sectionContactBoxes.data;return n("div",null,{class:"flex flex-col px-8 justify-center items-center"},[n("div",null,{class:"h-[100px] p-6 flex flex-row justify-evenly items-center shadow-2xl rounded-full w-[350px] mb-5 bg-blue-100"},[n("h2",null,{class:"text-primary-blue font-semibold text-xl"},y(e,"WTTTitle"),1,null),o(X,{get text(){return e.WTTButton.Text},get link(){return e.WTTButton.Link},[s]:{link:f(e.WTTButton,"Link"),text:f(e.WTTButton,"Text")}},3,"t0_0")],1,null),n("div",null,{class:"text-center"},[n("h1",null,{class:"text-3xl md:text-[40px] my-4 font-bold text-primary-blue"},y(e.Introduction,"Title"),1,null),n("h2",null,{class:"text-secondary-red my-4 text-2xl font-semibold"},y(e.Introduction,"Subtitle"),1,null),o(I,{get text(){return e.Introduction.Paragraph},[s]:{text:f(e.Introduction,"Paragraph")}},3,"t0_1")],1,null),n("div",null,{class:"flex flex-col md:flex-row my-4 w-full"},a.map((l,r)=>n("div",null,{class:"flex flex-col w-full md:w-1/2 items-center px-4 justify-start"},[l.attributes.Title.map((i,c)=>n("div",null,null,n("h2",null,{class:"text-center text-2xl text-primary-blue font-semibold"},y(i,"Text"),1,null),1,c)),l.attributes.BoxContent.map((i,c)=>n("div",null,{class:"h-[250px] my-4 w-full flex flex-col gap-5 justify-start items-center rounded-2xl shadow-xl"},[n("div",{class:`w-full flex justify-center py-2 items-center rounded-t-2xl ${r%2==0?"bg-primary-blue":"bg-secondary-red"}`},null,n("h2",null,{class:"text-center text-2xl text-white font-semibold"},y(i,"Title"),1,null),1,null),o(I,{classN:"text-center px-4",get text(){return i.Paragraph},[s]:{classN:s,text:f(i,"Paragraph")}},3,"t0_2"),n("div",null,{class:"flex flex-wrap items-center justify-center gap-2"},i.Buttons.map((d,p)=>{var g;return o(X,{get text(){return d.Text},get link(){return d.Link},type:(g=d.Link)!=null&&g.includes("tel:")?"action":"link",[s]:{link:f(d,"Link"),text:f(d,"Text")}},3,p)}),1,null)],1,c))],1,r)),1,null),n("div",null,{class:"flex flex-col my-4 md:flex-row gap-5"},e.SelfSupport.map((l,r)=>n("div",null,{class:"h-[290px] w-full md:w-[305px] rounded-3xl shadow-2xl flex p-6 flex-col items-center justify-between"},[n("img",{alt:y(l.Media.data.attributes,"alternativeText"),src:G(l.Media.data.attributes.url),title:y(l.Media.data.attributes,"caption")},{height:150,width:310},null,3,null),n("h2",null,{class:"text-2xl md:text-3xl text-center font-semibold text-primary-blue"},y(l,"Title"),1,null),o(I,{classN:"text-center",get text(){return l.Paragraph},[s]:{classN:s,text:f(l,"Paragraph")}},3,"t0_3"),o(X,{get text(){return l.Buttons[0].Text},get link(){return l.Buttons[0].Link},[s]:{link:f(l.Buttons[0],"Link"),text:f(l.Buttons[0],"Text")}},3,"t0_4")],1,r)),1,null)],1,"t0_5")},p$=m(x(d$,"s_Vkf3Ha9y0kU")),g$=t=>`
        sectionContactBoxes(locale:"${t}"){
          data{
            attributes{
              Title{
                Text
              }
              BoxContent{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
            }
          }
      }`,f$=t=>`query QuerySupport{
        pageSupport(locale:"${t}"){
          data{
            attributes{
              Marquee
              
              WTTTitle
              WTTButton{
                Text
                Link
              }
              
              Introduction{
                Title
                Subtitle
                Paragraph
              }
              
              SelfSupport{
                Media{
                ${v}
                }
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              ${R}
            }
          }
        }
        ${g$(t)}
      }`,x$=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(f$,e)},gn=A(x(x$,"s_PaoFf3TWb00")),m$=()=>{const t=gn();return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageSupport.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageSupport.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageSupport"]["data"]["attributes"]["SEO"]')}},3,"Ez_0"),o(p$,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"Ez_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Ez_2")},1,"Ez_3")},$$=m(x(m$,"s_BS8ceDijUKA")),h$=({resolveValue:t})=>{const a=t(gn).pageData.data.pageSupport.data.attributes.SEO;return H(a)},b$=Object.freeze(Object.defineProperty({__proto__:null,default:$$,head:h$,usePageData:gn},Symbol.toStringTag,{value:"Module"})),v$=t=>n("div",null,{class:"flex h-[190px]  max-w-[350px] flex-col items-center justify-center rounded-[20px] bg-white p-6 m-2 text-primary-blue"},[o(Xc,{class:"text-[28px] text-secondary-red",[s]:{class:s}},3,"Gr_0"),n("span",null,{class:"text-[17px] font-[600]"},u(e=>e.testimonial.Title,[t],'p0.testimonial["Title"]'),3,null),o(I,{classN:"text-[12px] text-center",get text(){return t.testimonial.Text},[s]:{classN:s,text:u(e=>e.testimonial.Text,[t],'p0.testimonial["Text"]')}},3,"Gr_1")],1,"Gr_2"),y$=t=>{const e=t.data.pageTestimon.data.attributes,a=m(x(v$,"s_ikLHAV9ZIuk")),l=e.Testimonials.map((r,i)=>o(a,{testimonial:r},3,i));return n("div",null,{class:"flex w-full items-center justify-center px-8",onClick$:F("s_KMXVxiVFs3M")},n("div",null,{class:"my-16 flex max-w-[1400px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex w-[60%] flex-col items-center justify-center gap-2 max-[800px]:w-full"},[n("h2",null,{class:"text-[36px] max-[800px]:text-[20px] font-[600] text-primary-dark-blue"},y(e,"VideoTitle"),1,null),n("video",{src:G(e.Video.data.attributes.url)},{class:"rounded-[30px] max-[800px]:max-w-[400px]",controls:!0,controlsList:"nodownload"},null,3,null)],1,null),n("div",null,{class:"items-center w-[40%] flex-col px-1 justify-center max-[800px]:w-full max-h-[500px]  "},o(Bt,{hasArrows:!1,hasPagination:!0,id:"carTestimonials",slides:l,slidesQty:1,[s]:{hasArrows:s,hasPagination:s,id:s,slidesQty:s}},3,"Gr_3"),1,null)],1,null),1,"Gr_4")},w$=m(x(y$,"s_HE2Hm2x9r68")),_$=t=>`query queryTestimonials{
    pageTestimon(locale:"${t}"){
      data{
        attributes{
          Testimonials{
            Title
            Text
          }
          VideoTitle
          TestimBG{
           ${v}
          }
          Video{
            ${v}
          }
          ${R}
        }
      }
    }
  }`,T$=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(_$,e)},fn=A(x(T$,"s_R6fQva4FAkw")),S$=()=>{const t=fn();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageTestimon.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageTestimon.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageTestimon"]["data"]["attributes"]["SEO"]')}},3,"cR_0"),o(w$,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"cR_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"cR_2")},D$=m(x(S$,"s_jKMCOKr9uSw")),P$=({resolveValue:t})=>{const a=t(fn).pageData.data.pageTestimon.data.attributes.SEO;return H(a)},k$=Object.freeze(Object.defineProperty({__proto__:null,default:D$,head:P$,usePageData:fn},Symbol.toStringTag,{value:"Module"})),L$=t=>{const e=t.data.data.pageWholesale.data.attributes,a=t.data.data.sectionNetwork.data.attributes,l=e.NetworkDIA.Features,r=U(0);return Re(F("s_jeOJGnobZvM",[l,r])),n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"w-full md:w-1/2 flex flex-col items-center px-4 my-8 justify-center"},[o(I,{classN:"text-center my-4",get text(){return e.Introduction.Paragraph},[s]:{classN:s,text:f(e.Introduction,"Paragraph")}},3,"Xs_0"),o(X,{get text(){return e.Introduction.Buttons[0].Text},get link(){return e.Introduction.Buttons[0].Link},type:"action",[s]:{link:f(e.Introduction.Buttons[0],"Link"),text:f(e.Introduction.Buttons[0],"Text"),type:s}},3,"Xs_1")],1,null),n("img",{alt:y(e.NetworkLogo.data.attributes,"alternativeText"),src:G(e.NetworkLogo.data.attributes.url)},{height:180,width:400},null,3,null),n("div",null,{class:"flex w-full flex-col items-center justify-center"},n("div",null,{class:"my-4 flex max-w-[1200px] items-center flex-row-reverse justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex min-[800px]:w-[70%] flex-col items-center justify-center gap-4 px-10"},[n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},y(e.NetworkDIA,"Title"),1,null),1,null),o(I,{get text(){return e.NetworkDIA.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{classN:s,text:f(e.NetworkDIA,"Paragraph")}},3,"Xs_2"),n("div",null,{class:"flex flex-col text-center items-center justify-end"},[n("h2",null,{class:"text-primary-blue font-semibold"},y(e.NetworkDIA,"Subtitle"),1,null),n("p",null,{class:"text-primary-blue font-bold text-2xl"},y(e.NetworkDIA,"FeaturesTitle"),1,null)],1,null),n("div",null,{class:"text-secondary-red text-center text-xl font-semibold"},n("h2",null,{class:"animated-fadein-down animated-fadeout-down"},y(l[r.value],"Text"),1,null),1,null)],1,null),n("div",null,{class:`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${30 .toString()}%]`},n("img",{src:G(e.NetworkDIA.Media.data.attributes.url)},{alt:"paragraph-image",height:"300",width:"597"},null,3,null),1,null)],1,null),1,null),o(At,{get text(){return e.NetworkCircuits.Paragraph},backgroundColor:"transparent",get title(){return e.NetworkCircuits.Title},get image(){return e.NetworkCircuits.Media.data.attributes},[s]:{backgroundColor:s,image:f(e.NetworkCircuits.Media.data,"attributes"),text:f(e.NetworkCircuits,"Paragraph"),title:f(e.NetworkCircuits,"Title")}},3,"Xs_3"),n("div",null,{class:"flex flex-wrap-reverse px-8 py-6 my-4 items-center justify-center"},[n("div",null,{class:"h-[450px] w-full md:w-1/2"},null,3,null),n("div",null,{class:"flex flex-col w-full md:w-1/2 items-center justify-center"},[o(I,{get text(){return a.Description.Paragraph},classN:"text-primary-blue",[s]:{classN:s,text:f(a.Description,"Paragraph")}},3,"Xs_4"),o(ge,{get title(){return a.Map.ServersTitle},children:n("div",null,{class:"flex flex-col py-4 text-primary-blue bg-white rounded-b-2xl"},a.Map.Servers.map((i,c)=>n("a",{href:y(i,"Link")},{class:"hover:text-secondary-red text-primary-blue"},y(i,"Text"),1,c)),1,null),classContainer:"rounded-full bg-white text-primary-blue shadow-xl",[s]:{classContainer:s,title:f(a.Map,"ServersTitle")}},1,"Xs_5")],1,null)],1,null),o(Xt,{get data(){return e.GFServices},[s]:{data:f(e,"GFServices")}},3,"Xs_6")],1,"Xs_7")},M$=m(x(L$,"s_SvASKT7lKMw")),C$=t=>`query QueryWholesale {
        pageWholesale(locale:"${t}"){    
          data{
            attributes{
            Introduction{
              Title
              Paragraph
              Buttons{
                Text
                Link
              }
            }
              
            NetworkLogo{
                ${v}
            }
            NetworkDIA{
              Title
              Paragraph
              Subtitle
              FeaturesTitle
              Features{
                Text
              }
              Media{
                ${v}
              }
            }
            NetworkCircuits{
              Title
              Subtitle
              Paragraph
              Media{
                 ${v}
              }
            }
           
              
            GFServices{
              Title
              Logo{
                ${v}
              }
              Paragraph
              Media{
                ${v}
              }
              Buttons{
                Text
                Link
              }
            }
              ${R}
            }
          }
        }
        ${Gc(t)}
      }`,j$=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(C$,e)},xn=A(x(j$,"s_odgwpNJ8jW8")),I$=()=>{const t=xn();return o(Q,{children:o(N,{get data(){return t.value.layoutData},children:o(M$,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"3I_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"3I_1")},1,"3I_2")},E$=m(x(I$,"s_W611gmEC5Rk")),O$=({resolveValue:t})=>{const a=t(xn).pageData.data.pageWholesale.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},B$=Object.freeze(Object.defineProperty({__proto__:null,default:E$,head:O$,usePageData:xn},Symbol.toStringTag,{value:"Module"})),A$=t=>n("div",{style:{backgroundImage:`url(${G(t.slide.attributes.url)})`}},{class:"h-[350px] my-5 w-[280px] overflow-hidden rounded-[10px] bg-contain bg-no-repeat bg-center"},null,3,"0D_0"),q$=t=>{const e=t.data.pageWinnersC.data.attributes,a=e.Winners.data.reverse(),l=m(x(A$,"s_Kis0UnPgGnE")),r=a.map((i,c)=>o(l,{slide:i},3,c));return n("div",null,{class:"relative flex flex-col items-center justify-center",onClick$:F("s_na2GxJ32Wno")},[n("div",null,{class:"relative flex w-full items-center justify-center overflow-hidden"},[o(z,{clasN:"max-w-[1000px] w-fit z-10 object-cover",height:"603",width:"1024",get url(){return e.WinnersBG.data.attributes.url},get alt(){return e.WinnersBG.data.attributes.alternativeText},get title(){return e.WinnersBG.data.attributes.caption},[s]:{alt:f(e.WinnersBG.data.attributes,"alternativeText"),clasN:s,height:s,title:f(e.WinnersBG.data.attributes,"caption"),url:f(e.WinnersBG.data.attributes,"url"),width:s}},3,"0D_1"),n("div",null,{class:"absolute z-20 mb-[160px]  w-[290px] overflow-hidden  rounded-[10px] border border-gray-500 bg-[#171f2a] p-2"},o(Bt,{addSpace:!1,hasArrows:!1,id:"carouselWinners",slides:r,slidesQty:1,[s]:{addSpace:s,hasArrows:s,id:s,slidesQty:s}},3,"0D_2"),1,null),n("div",null,{class:"absolute bottom-0 left-0 right-0 h-[30%] bg-black"},null,3,null)],1,null),n("div",null,{class:"flex w-full overflow-hidden bg-cover pt-16 bg-black justify-center"},n("div",null,{class:"flex max-w-[1200px] gap-4  max-[1000px]:flex-col  justify-center items-center"},[n("div",null,{class:"flex w-[30%] flex-col "},[n("h2",null,{class:"text-center text-[36px] font-[600] leading-[36px] text-secondary-red"},y(e,"GiveawayCarTitle"),1,null),n("br",null,null,null,3,null),n("div",null,{class:"mb-6 flex items-center justify-center rounded-xl bg-white p-2"},o(Bt,{addSpace:!1,duration:5e3,hasArrows:!0,hasPagination:!1,id:"giveAnswers",slides:e.GiveawayAnswers.reverse().map((i,c)=>n("div",null,{class:"flex flex-col items-center justify-center gap-1.5 max-w-[180px]"},[n("p",null,{class:"text-center text-[15px] text-primary-blue"},["This question was answered on"," ",n("br",null,null,null,3,null),Xe(i.AnswerDate,!1)],1,null),n("iframe",{src:`https://www.youtube.com/embed/${i.QuestionVideos.split("v=")[1]}`},{allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",allowFullScreen:!0,class:"rounded-[20px] shadow-xl",frameBorder:"0",height:270,width:160},null,3,null),n("span",null,{class:"text-secondary-red"},"Answer:",3,null),n("span",null,{class:"text-primary-blue"},y(i,"Answer"),1,null)],1,c)),slidesQty:1,[s]:{addSpace:s,duration:s,hasArrows:s,hasPagination:s,id:s,slidesQty:s}},3,"0D_3"),1,null)],1,null),n("div",null,{class:"flex md:w-[60%] w-[30%] h-full flex-col justify-center  overflow-hidden"},[n("h3",null,{class:"text-center text-[28px] font-[500] leading-[30px] text-primary-blue"},y(e,"TwitterFeedTitle"),1,null),n("br",null,null,null,3,null),n("iframe",{srcDoc:y(e,"TwitterFeedLink")},{class:"h-full",height:"100%",width:"100%"},null,3,null)],1,null)],1,null),1,null)],1,"0D_4")},N$=m(x(q$,"s_QYIFsZOPjHw")),z$=t=>`query queryWinnerCircle{
    pageWinnersC(locale:"${t}"){
      data{
        attributes{
          WinnersTitle
  
          WinnersBG{
            ${v}
          }
          
          WinnersCarBG{
           ${v}
          }
          Winners{
            ${v}
          }
         
          GiveawayCarTitle
          
          GiveawayAnswers{
            Description
            AnswerDate
            QuestionVideos
            Answer
          }
          TwitterFeedLink
          TwitterFeedTitle
  
          ${R}
        }
      }
    }
  }`,R$=async t=>{const e=t.params.lang==""?"en":"es-419";return await q(z$,e)},mn=A(x(R$,"s_6WeV0M8I1Do")),G$=()=>{const t=mn();return o(N,{get data(){return t.value.layoutData},children:[o(K,{get SEOdata(){return t.value.pageData.data.pageWinnersC.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageWinnersC.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageWinnersC"]["data"]["attributes"]["SEO"]')}},3,"00_0"),o(N$,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"00_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"00_2")},Q$=m(x(G$,"s_0m9hLjn9QnA")),F$=({resolveValue:t})=>{const a=t(mn).pageData.data.pageWinnersC.data.attributes.SEO;return H(a)},H$=Object.freeze(Object.defineProperty({__proto__:null,default:Q$,head:F$,usePageData:mn},Symbol.toStringTag,{value:"Module"})),W$=t=>{const e=t.data.Slug.substring(t.data.Slug.length-3,t.data.Slug.length)==="-es";return n("div",null,{class:"flex max-w-[1200px] gap-3 px-8 py-20 text-primary-blue max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-1 text-center min-[800px]:w-[50%]"},[n("h1",null,{class:"text-[38px] font-[700] leading-10"},`gigFAST INTERNET ${e?"e":"i"}n ${t.data.Name}`,1,null),n("span",null,{class:"text-[24px]"},[u(a=>a.data.ZipCode,[t],'p0.data["ZipCode"]'),", TX"],3,null),n("span",null,{class:"text-[28px] font-[600]"},e?"Llamar ahora:":"Call now:",1,null),o(X,{text:"512 360 4273",[s]:{text:s}},3,"pw_0")],1,null),n("div",null,{class:"text-justify text-[16px] max-[800px]:text-[13px] min-[800px]:w-[50%]"},o(I,{get text(){return t.data.Description},[s]:{text:u(a=>a.data.Description,[t],'p0.data["Description"]')}},3,"pw_1"),1,null)],1,"pw_2")},U$=m(x(W$,"s_8eJAul3VU0U")),V$=t=>{const e=t.data.lpPtGroup.data.attributes.PricingTables;return n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"flex min-h-[200px]  w-full items-center justify-center bg-gradient-to-br from-primary-light-blue to-[#23477f] p-8"},n("div",null,{class:"flex w-full max-w-[1200px] flex-col items-center justify-center"},[n("span",null,{class:"text-center text-[38px] font-[600] leading-10 text-white max-[800px]:text-[28px]"},"Find available offers in your area",3,null),n("div",null,{class:"mt-8 flex w-full gap-8 max-[1200px]:flex-col"},[n("div",null,{class:"flex min-h-[360px] items-center justify-center overflow-hidden rounded-2xl min-[1200px]:w-[36%]"},n("iframe",null,{class:"h-full w-full rounded-2xl",loading:"lazy",src:u(a=>a.data.locations.data[0].attributes.office.data.attributes.Address,[t],'p0.data["locations"]["data"][0]["attributes"]["office"]["data"]["attributes"]["Address"]')},null,3,null),3,null),n("div",null,{class:"flex justify-evenly gap-4 max-[1200px]:flex-wrap min-[1200px]:w-[64%]"},e.map((a,l)=>o(Vl,{get btnText(){return a.Button.Text},get btnLink(){return a.Button.Link},get description(){return a.Description},get logo(){return a.Logo.data.attributes},get features(){return a.Features},price:a.Price.toString(),get priceTime(){return a.Pricetime},get title(){return a.Title},isFullLogo:!0,[s]:{btnLink:f(a.Button,"Link"),btnText:f(a.Button,"Text"),description:f(a,"Description"),features:f(a,"Features"),isFullLogo:s,logo:f(a.Logo.data,"attributes"),priceTime:f(a,"Pricetime"),title:f(a,"Title")}},3,l)),1,null)],1,null)],1,null),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"88_0")},Y$=m(x(V$,"s_JRh1Z7hA4Tg")),Z$=t=>n("div",null,{class:"flex flex-col items-center justify-center"},[o(U$,{get data(){return t.data.locations.data[0].attributes},[s]:{data:u(e=>e.data.locations.data[0].attributes,[t],'p0.data["locations"]["data"][0]["attributes"]')}},3,"LA_0"),o(Y$,{get data(){return t.data},[s]:{data:u(e=>e.data,[t],"p0.data")}},3,"LA_1")],1,"LA_2"),J$=m(x(Z$,"s_xdmchVEPK4Q")),X$=(t,e)=>`
  query QueryLocalPage {
    locations(
      filters: { Slug: { eq: "${e}${t==="en"?"":"-es"}" } }
      locale: "${t}"
    ) {
      data {
        attributes {
            office {
                data {
                  attributes {
                    Address
                    Schema
                  }
                }
              }
          Name
          ZipCode
          Description
          Slug
          SEO {
            MetaTitle
            MetaDescription
            preventIndexing
            Keywords
          }
        }
      }
    }
    lpPtGroup(locale:"${t}"){
        data{
          attributes{
            PricingTables{
              Logo{
                ${v}
              }
              Title
              Subtitle
              Price
              Pricetime
              Description
              Features{
                Text
              }
              Button{
                Text
                Link
              }
            }
          }
        }
      } 
  }  
    `,K$=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang,a=t.params.slug;return await Ea(X$(fa(e),a),e)},$n=A(x(K$,"s_1P6SxAujDI0")),th=()=>{Z();const t=$n(),a=t.value.pageData.data.locations.data.length>0?o(J$,{get data(){return t.value.pageData.data},[s]:{data:u(l=>l.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"jm_1"):n("div",null,null,"Not Found",3,"jm_0");return o(N,{get data(){return t.value.layoutData},children:a,showHeader:!1,[s]:{data:u(l=>l.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"jm_2")},eh=m(x(th,"s_7yVzYV6frbA")),ah=({resolveValue:t})=>{const e=t($n);if(e.pageData.data.locations.data.length==0)return H({MetaTitle:"Not Found",MetaDescription:"Error 404, location not found"});const a=e.pageData.data.locations.data[0].attributes.SEO;return a.schema=e.pageData.data.locations.data[0].attributes.office.data.attributes.Schema,H(a)},lh=Object.freeze(Object.defineProperty({__proto__:null,default:eh,head:ah,usePageData:$n},Symbol.toStringTag,{value:"Module"})),nh=()=>{const[t,e,a,l,r]=et();e.value=!e.value,e.value&&(t.value=a.data.HeroForm.ActionButton.Link.replace("=pConf=","").replace("streetInput",l.value.value).replace("zipInput",r.value.value))},sh=t=>n("div",null,{class:"flex items-center justify-between gap-1"},[n("div",null,{class:"flex flex-col gap-1 max-[1000px]:gap-2"},[o(z,{clasN:"w-[160px]",width:"1667",get url(){return t.slide.Logo.data.attributes.url},get alt(){return t.slide.Logo.data.attributes.alternativeText},get title(){return t.slide.Logo.data.attributes.caption},[s]:{alt:u(e=>e.slide.Logo.data.attributes.alternativeText,[t],'p0.slide["Logo"]["data"]["attributes"]["alternativeText"]'),clasN:s,title:u(e=>e.slide.Logo.data.attributes.caption,[t],'p0.slide["Logo"]["data"]["attributes"]["caption"]'),url:u(e=>e.slide.Logo.data.attributes.url,[t],'p0.slide["Logo"]["data"]["attributes"]["url"]'),width:s}},3,"2R_1"),n("div",null,{class:"mx-3 max-[1000px]:hidden"},o(I,{classN:"text-[13px]",get text(){return t.slide.Paragraph},[s]:{classN:s,text:u(e=>e.slide.Paragraph,[t],'p0.slide["Paragraph"]')}},3,"2R_2"),1,null),o(X,{get text(){return t.slide.Buttons[0].Text},get link(){return t.slide.Buttons[0].Link},[s]:{link:u(e=>e.slide.Buttons[0].Link,[t],'p0.slide["Buttons"][0]["Link"]'),text:u(e=>e.slide.Buttons[0].Text,[t],'p0.slide["Buttons"][0]["Text"]')}},3,"2R_3")],1,null),o(Za,{clasN:"rounded-full w-[150px] mr-[30px] max-[1000px]:w-[40%]",get url(){return t.slide.Media.data.attributes.url},get alt(){return t.slide.Media.data.attributes.alternativeText},get title(){return t.slide.Media.data.attributes.caption},autoplay:!0,loop:!0,muted:!0,[s]:{alt:u(e=>e.slide.Media.data.attributes.alternativeText,[t],'p0.slide["Media"]["data"]["attributes"]["alternativeText"]'),autoplay:s,clasN:s,loop:s,muted:s,title:u(e=>e.slide.Media.data.attributes.caption,[t],'p0.slide["Media"]["data"]["attributes"]["caption"]'),url:u(e=>e.slide.Media.data.attributes.url,[t],'p0.slide["Media"]["data"]["attributes"]["url"]')}},3,"2R_4")],1,"2R_5"),rh=t=>{const[e]=et();return n("div",{class:`flex h-[230px] items-center  justify-center overflow-hidden bg-white   ${t.isMobile??!1?"w-full max-w-[420px] rounded-full min-[1000px]:hidden":"w-[420px] rounded-br-full rounded-tr-full bg-opacity-60 max-[1000px]:hidden"}`},null,o(Bt,{hasArrows:!1,slides:e,slidesQty:1,get id(){return`header_car_${t.isMobile??!1?"mobile":"desk"}`},[s]:{hasArrows:s,id:u(a=>`header_car_${a.isMobile??!1?"mobile":"desk"}`,[t],'`header_car_${p0.isMobile??false?"mobile":"desk"}`'),slidesQty:s}},3,"2R_6"),1,"2R_7")},ih=()=>{const[t,e,a,l]=et();clearTimeout(l.value),l.value=setTimeout(()=>{t.value.value.length>2&&fetch(`/api/get-streets?q=${encodeURIComponent(t.value.value)}`).then(r=>r.json()).then(r=>{const i=r.data;i.length===0?e.value="notfound":e.value="success",a.value=i})},1e3)},oh=t=>{const e=U(n("input",null,null,null,3,"2R_0")),a=U(n("input",null,null,null,3,null)),l=U(""),r=U(!1),i=U(),c=U([]),d=U("none"),p=x(nh,"s_fq93imJ971Y",[l,r,t,e,a]),g=m(x(sh,"s_bR2jjpv9PC0")),$=t.data.HeroCarSlides.map((T,D)=>o(g,{slide:T},3,D)),h=m(x(rh,"s_mBlTNPrtMiQ",[$])),w=x(ih,"s_r2MqT6I0l2Y",[e,d,c,i]);return o(Q,{children:[n("div",null,{class:"relative flex h-[80vh] max-h-[750px] w-full items-center"},[n("div",null,{class:u(T=>`fixed bottom-0 left-0 right-0 bg-white top-${T.value?"0 z-[200]":"[100vh] -z-[200]"}  transition-all duration-1000 ease-in-out`,[r],'`fixed bottom-0 left-0 right-0 bg-white top-${p0.value?"0 z-[200]":"[100vh] -z-[200]"}  transition-all duration-1000 ease-in-out`')},[o(hr,{class:"text-md absolute right-2 top-2 flex h-5 w-5 items-center justify-center rounded-full bg-secondary-red text-white hover:cursor-pointer",onClick$:p,[s]:{class:s,onClick$:s}},3,"2R_8"),n("iframe",null,{class:"h-full w-full",frameBorder:"0",src:u(T=>T.value,[l],"p0.value")},null,3,null)],1,null),n("video",{src:G(t.data.VideoBGDesktop.data.attributes.url)},{autoPlay:!0,class:"absolute left-0 top-0 -z-10 h-full w-full object-cover",loop:!0,muted:!0},null,3,null),n("div",null,{class:"flex h-full w-full items-center justify-between max-[1000px]:flex-col-reverse max-[1000px]:px-4"},n("div",null,{class:"relative flex w-[420px] flex-col items-center justify-center gap-5 rounded-bl-full rounded-tl-full bg-white bg-opacity-60 max-[1000px]:mb-8 max-[1000px]:w-full max-[1000px]:max-w-[420px] max-[1000px]:rounded-full max-[1000px]:py-8 min-[1000px]:h-[230px]"},[n("div",{class:`absolute left-10 right-10 top-[90%] z-20 flex max-h-[200px] flex-col gap-3 overflow-y-auto rounded-xl bg-white p-6 text-primary-blue shadow-lg ${d.value==="none"||d.value==="selected"?"hidden":""}`},null,[u(T=>T.value.length===0?"Not found":"",[c],'p0.value.length===0?"Not found":""'),c.value.map((T,D)=>n("div",{onClick$:F("s_0WdAGCARSDU",[e,T,d,a])},{class:"grid items-center gap-4 hover:cursor-pointer",style:{gridTemplateColumns:"20px 1fr"}},[o(Kc,{class:"w-6 text-secondary-red",[s]:{class:s}},3,"2R_9"),n("span",null,{class:"text-[14px]"},y(T,"address"),1,null)],0,D))],1,null),n("div",null,{class:"px-8 text-center text-[22px] font-[600] text-primary-blue max-[1000px]:px-12"},u(T=>T.data.HeroForm.Title,[t],'p0.data["HeroForm"]["Title"]'),3,null),n("div",null,{class:"flex w-full items-center gap-4 px-6 max-[1000px]:flex-col "},[n("input",{ref:e},{class:"w-[50%] rounded-full px-3 py-2 placeholder-primary-blue",onKeyUp$:w,placeholder:"Address Search",type:"text"},null,3,null),n("input",{ref:a},{class:"w-[50%] rounded-full px-3 py-2 placeholder-primary-blue",placeholder:"Zip Code",type:"text"},null,3,null)],1,null),o(X,{get text(){return t.data.HeroForm.ActionButton.Text},onClick:p,[s]:{onClick:s,text:u(T=>T.data.HeroForm.ActionButton.Text,[t],'p0.data["HeroForm"]["ActionButton"]["Text"]')}},3,"2R_10")],1,null),1,null)],1,null),n("div",null,{class:"flex justify-center bg-gradient-to-r from-[#3d76c1] to-[#3568ae] px-4 pt-4"},o(h,{isMobile:!0,[s]:{isMobile:s}},3,"2R_11"),1,null)]},1,"2R_12")},uh=m(x(oh,"s_S18xoZmdQUw")),ch=t=>n("div",null,{class:"z-20 flex w-full justify-center bg-gradient-to-br from-[#3d76c2] to-[#2e599a] px-10 py-6 text-white"},n("div",null,{class:"flex max-w-[1100px] items-center justify-center gap-8 max-[1000px]:flex-col"},[n("div",null,{class:"flex w-[50%] flex-col text-justify max-[1000px]:w-[100%]"},[n("div",null,{class:"text-[38px] font-bold max-sm:text-[28px]"},u(e=>e.data.prosPar.Title,[t],'p0.data.prosPar["Title"]'),3,null),n("div",null,{class:"text-[18px] max-sm:text-[15px]"},u(e=>e.data.prosPar.Paragraph,[t],'p0.data.prosPar["Paragraph"]'),3,null),n("div",null,{class:"mt-6 flex flex-col gap-4"},t.data.prosData.map((e,a)=>n("div",null,{class:"flex-row "},[n("div",null,{class:" bg-secondary-red h-fit w-fit rounded-full p-2"},o(z,{height:20,toWhite:!0,width:20,get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},[s]:{alt:f(e.Icon.data.attributes,"alternativeText"),height:s,title:f(e.Icon.data.attributes,"caption"),toWhite:s,url:f(e.Icon.data.attributes,"url"),width:s}},3,"l8_0"),1,null),n("div",null,{class:"flex flex-col"},[n("span",null,{class:"text-[28px] font-bold"},o(I,{get text(){return e.Title},classN:"text-white",[s]:{classN:s,text:f(e,"Title")}},3,"l8_1"),1,null),n("span",null,{class:"text-[18px] "},o(I,{get text(){return e.Text},classN:"text-white",[s]:{classN:s,text:f(e,"Text")}},3,"l8_2"),1,null)],1,null)],1,a)),1,null)],1,null),o(z,{height:"800",width:"800",get url(){return t.data.prosMap.url},get alt(){return t.data.prosMap.alternativeText},get title(){return t.data.prosMap.caption},clasN:"px-8  min-w-[250px]",[s]:{alt:u(e=>e.data.prosMap.alternativeText,[t],'p0.data.prosMap["alternativeText"]'),clasN:s,height:s,title:u(e=>e.data.prosMap.caption,[t],'p0.data.prosMap["caption"]'),url:u(e=>e.data.prosMap.url,[t],'p0.data.prosMap["url"]'),width:s}},3,"l8_3")],1,null),1,"l8_4"),dh=m(x(ch,"s_F6ekLiR69OY")),ph=t=>{const e=t.data.Logo.data.attributes.url,a=t.data.Logo.data.attributes.alternativeText,l=t.data.Media.data.attributes.url,r=t.data.Media.data.attributes.alternativeText;return n("div",null,{class:"mb-4 flex flex-row-reverse max-w-[1200px] items-center justify-center gap-4 self-center px-8 max-[800px]:flex-col-reverse"},[n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[40%]"},o(z,{alt:r,height:800,url:l,width:800,[s]:{height:s,width:s}},3,"a2_0"),1,null),n("div",null,{class:"flex flex-col items-center justify-center gap-4 min-[800px]:w-[60%]"},[n("div",null,{class:"max-w-[470px]"},o(z,{alt:a,height:230,url:e,width:1230,[s]:{height:s,width:s}},3,"a2_1"),1,null),n("div",null,{class:"flex items-start gap-2"},[n("div",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(i=>i.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"text-center text-[28px] font-bold text-secondary-red max-sm:text-[18px]"},u(i=>i.data.Subtitle,[t],'p0.data["Subtitle"]'),3,null)],3,null),n("div",null,{class:"text-primary-blue"},[o(I,{classN:"text-justify max-sm:text-[15px] text-[18px] text-[#2E5899]",get text(){return t.data.Paragraph},[s]:{classN:s,text:u(i=>i.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"a2_2"),t.parGFIPlans.map((i,c)=>n("div",null,{class:"text-[22px]"},o(ge,{get title(){return i.Title},children:o(I,{classN:"text-[16px] text-justify",get text(){return i.Paragraph},[s]:{classN:s,text:f(i,"Paragraph")}},3,"a2_3"),classContainer:"bg-white shadow-xl",[s]:{classContainer:s,title:f(i,"Title")}},1,"a2_4"),1,c))],1,null),n("div",null,{class:"flex gap-4"},t.data.Buttons.map((i,c)=>o(X,{get text(){return i.Text},get link(){return i.Link},[s]:{link:f(i,"Link"),text:f(i,"Text")}},3,c)),1,null)],1,null)],1,"a2_5")},gh=m(x(ph,"s_M9NFBwXMc48")),fh=t=>n("div",null,{class:"flex items-center justify-evenly gap-4 px-8 py-6 max-[1200px]:flex-col"},t.data.map((e,a)=>n("div",null,{class:" flex max-w-[400px] flex-col items-center gap-2 text-center text-primary-blue"},[o(Ee,{get url(){return e.Media.data.attributes.url},get alt(){return e.Media.data.attributes.alternativeText},get title(){return e.Media.data.attributes.caption},color:"bg-primary-blue",width:"w-[360px]",[s]:{alt:f(e.Media.data.attributes,"alternativeText"),color:s,title:f(e.Media.data.attributes,"caption"),url:f(e.Media.data.attributes,"url"),width:s}},3,"pO_0"),n("h5",null,{class:"text-[24px] font-[700]"},y(e,"Title"),1,null),n("p",null,{class:"text-[17px] font-[400]"},y(e,"Paragraph"),1,null),o(X,{get text(){return e.Buttons[0].Text},get link(){return e.Buttons[0].Link},[s]:{link:f(e.Buttons[0],"Link"),text:f(e.Buttons[0],"Text")}},3,"pO_1")],1,a)),1,"pO_2"),xh=m(x(fh,"s_PyTSx8biYlE")),mh=t=>{const e=t.data.pageHome.data.attributes,a=t.data.sectionProsRta.data.attributes.Pros,l=e.ProsPicture.data.attributes;return n("div",null,{class:"relative ",onClick$:F("s_TkQ204PTgK8")},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-[100vh] -z-10 bg-white"},null,3,null),o(uh,{data:e},3,"Ee_0"),o(dh,{data:{prosPar:e.ProsPar,prosData:a,prosMap:l}},3,"Ee_1"),o(Nt,{get data(){return e.ParACP},reverse:!0,textPercentage:60,[s]:{data:f(e,"ParACP"),reverse:s,textPercentage:s}},3,"Ee_2"),n("div",null,{class:"flex w-full justify-center bg-[#ebf4fc]"},o(gh,{data:e.ParGFServices[0],get parGFIPlans(){return e.ParGFIPlans},[s]:{parGFIPlans:f(e,"ParGFIPlans")}},3,"Ee_3"),1,null),o(Xt,{data:e.ParGFServices.slice(1,e.ParGFServices.length)},3,"Ee_4"),n("div",null,{class:"bg-[#ebf4fc]"},o(xh,{get data(){return e.SugsPages},[s]:{data:f(e,"SugsPages")}},3,"Ee_5"),1,null)],1,"Ee_6")},$h=m(x(mh,"s_G08oK4nfxwg")),hh=t=>n("div",null,{class:"flex  w-full flex-col items-center justify-center px-8 text-primary-blue"},[n("div",null,{class:"flex max-w-[1400px] items-center justify-evenly gap-4 py-16 max-[800px]:flex-col"},[n("h1",null,{class:"w-[40%] text-center text-[42px] font-[600]  max-sm:text-[28px] leading-10 max-[800px]:w-full"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),o(z,{clasN:" rounded-2xl shadow-xl w-[40%] max-[800px]:w-full",height:"539",width:"833",get url(){return t.data.Cover.data.attributes.url},get alt(){return t.data.Cover.data.attributes.alternativeText},get title(){return t.data.Cover.data.attributes.caption},[s]:{alt:u(e=>e.data.Cover.data.attributes.alternativeText,[t],'p0.data["Cover"]["data"]["attributes"]["alternativeText"]'),clasN:s,height:s,title:u(e=>e.data.Cover.data.attributes.caption,[t],'p0.data["Cover"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.Cover.data.attributes.url,[t],'p0.data["Cover"]["data"]["attributes"]["url"]'),width:s}},3,"cD_0")],1,null),n("div",null,{class:"mb-8 max-w-[1400px]"},o(I,{get text(){return t.data.Description},classN:"text-justify",[s]:{classN:s,text:u(e=>e.data.Description,[t],'p0.data["Description"]')}},3,"cD_1"),1,null)],1,"cD_2"),bh=m(x(hh,"s_QI52uAygONM")),vh=(t,e)=>{const a=e==="es-419";return console.log(`query QueryPostPage {
    posts (filters: {Slug: {eq: "${t}${a?"-es":""}"}} pagination:{limit:1} locale:"${e}") {
      data {
        attributes {
          Title
          Date
          Description
          Slug
          Cover {
            data {
              attributes {
                url
                caption
                alternativeText
              }
            }
          }
          SEO {
            MetaTitle
            MetaDescription
            Keywords
            preventIndexing
          }
          
        }
      }
    }
  }`),`query QueryPostPage {
        posts (filters: {Slug: {eq: "${t}${a?"-es":""}"}} pagination:{limit:1} locale:"${e}") {
          data {
            attributes {
              Title
              Date
              Description
              Slug
              Cover {
                data {
                  attributes {
                    url
                    caption
                    alternativeText
                  }
                }
              }
              SEO {
                MetaTitle
                MetaDescription
                Keywords
                preventIndexing
              }
              
            }
          }
        }
      }`},yh=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang;let a={};if(e=="en"||e=="es-419")return a=await q(jr,e),{...a,type:"home"};const l=e.includes("es/")?"es-419":"en",r=e.includes("es/")?e.split("es/")[1]:e;return a=await Ea(vh(r,l),l),{...a,type:a.pageData.data.posts.data.length>0?"post":"404"}},hn=A(x(yh,"s_Up0e7VSBoHc")),wh=()=>{Z();const t=hn();return o(N,{get data(){return t.value.layoutData},children:[n("h1",null,{class:"absolute opacity-0"},"Rural Telecommunications of America Inc.",3,null),t.value.type=="home"?o($h,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"2d_0"):t.value.type=="post"?o(bh,{get data(){return t.value.pageData.data.posts.data[0].attributes},[s]:{data:u(e=>e.value.pageData.data.posts.data[0].attributes,[t],'p0.value["pageData"]["data"]["posts"]["data"][0]["attributes"]')}},3,"2d_1"):n("div",null,null,"Nor Found",3,null)],showHeader:!1,[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"2d_2")},_h=m(x(wh,"s_jpH0I2vriFs")),Th=({resolveValue:t})=>{const e=t(hn),a=e.type;let l;return a=="home"?l=e.pageData.data.pageHome.data.attributes.SEO:a=="post"?(l=e.pageData.data.posts.data[0].attributes.SEO,l||(l={MetaTitle:e.pageData.data.posts.data[0].attributes.Title,MetaDescription:e.pageData.data.posts.data[0].attributes.Description,preventIndexing:!0,Keywords:e.pageData.data.posts.data[0].attributes.Title})):l={MetaTitle:"Not found"},H(l)},Sh=Object.freeze(Object.defineProperty({__proto__:null,default:_h,head:Th,usePageData:hn},Symbol.toStringTag,{value:"Module"})),Dh=[Wu],O=()=>Mc,Ph=[["forms/",[O,()=>Oc],"/forms/",["q-509cc7c8.js","q-dd6e9dfc.js"]],["[...lang]/api/emailjs/",[O,()=>Ac],"/[...lang]/api/emailjs/",["q-509cc7c8.js"]],["[...lang]/api/get-streets/",[O,()=>zc],"/[...lang]/api/get-streets/",["q-509cc7c8.js"]],["[...lang]/acp/",[O,()=>dp],"/[...lang]/acp/",["q-509cc7c8.js","q-4071d0e3.js"]],["[...lang]/appreciation-giveaway/",[O,()=>bp],"/[...lang]/appreciation-giveaway/",["q-509cc7c8.js","q-6475363a.js"]],["[...lang]/appreciation-lead/",[O,()=>Pp],"/[...lang]/appreciation-lead/",["q-509cc7c8.js","q-06449a6a.js"]],["[...lang]/awards/",[O,()=>Bp],"/[...lang]/awards/",["q-509cc7c8.js","q-cd817f58.js"]],["[...lang]/blog/",[O,()=>Jp],"/[...lang]/blog/",["q-509cc7c8.js","q-a77e2240.js"]],["[...lang]/board-members/",[O,()=>s0],"/[...lang]/board-members/",["q-509cc7c8.js","q-f4e17ee5.js"]],["[...lang]/business/",[O,()=>g0],"/[...lang]/business/",["q-509cc7c8.js","q-284a9275.js"]],["[...lang]/careers/",[O,()=>E0],"/[...lang]/careers/",["q-509cc7c8.js","q-25e73f07.js"]],["[...lang]/client-services-agreement-general-terms-and-conditions/",[O,()=>G0],"/[...lang]/client-services-agreement-general-terms-and-conditions/",["q-509cc7c8.js","q-5377567e.js"]],["[...lang]/contact-us/",[O,()=>Z0],"/[...lang]/contact-us/",["q-509cc7c8.js","q-d458a9a1.js"]],["[...lang]/cookies/",[O,()=>ng],"/[...lang]/cookies/",["q-509cc7c8.js","q-f485ef79.js"]],["[...lang]/deals/",[O,()=>bg],"/[...lang]/deals/",["q-509cc7c8.js","q-bcc316d6.js"]],["[...lang]/faq/",[O,()=>Pg],"/[...lang]/faq/",["q-509cc7c8.js","q-0bd45b61.js"]],["[...lang]/gfsn/",[O,()=>qg],"/[...lang]/gfsn/",["q-509cc7c8.js","q-47c66922.js"]],["[...lang]/gigfast-cloud/",[O,()=>Wg],"/[...lang]/gigfast-cloud/",["q-509cc7c8.js","q-19f6997b.js"]],["[...lang]/gigfast-internet-support/",[O,()=>sf],"/[...lang]/gigfast-internet-support/",["q-509cc7c8.js","q-6e83904e.js"]],["[...lang]/gigfast-internet/",[O,()=>xf],"/[...lang]/gigfast-internet/",["q-509cc7c8.js","q-8a3da294.js"]],["[...lang]/gigfast-iot/",[O,()=>_f],"/[...lang]/gigfast-iot/",["q-509cc7c8.js","q-7258af0b.js"]],["[...lang]/gigfast-tv-privacy-policy/",[O,()=>Cf],"/[...lang]/gigfast-tv-privacy-policy/",["q-509cc7c8.js","q-10dafc26.js"]],["[...lang]/gigfast-tv-support/",[O,()=>Ff],"/[...lang]/gigfast-tv-support/",["q-509cc7c8.js","q-aa77e86e.js"]],["[...lang]/gigfast-tv/",[O,()=>ux],"/[...lang]/gigfast-tv/",["q-509cc7c8.js","q-cbe3a7f1.js"]],["[...lang]/gigfast-voice-support/",[O,()=>$x],"/[...lang]/gigfast-voice-support/",["q-509cc7c8.js","q-fdac7927.js"]],["[...lang]/gigfast-voice/",[O,()=>Lx],"/[...lang]/gigfast-voice/",["q-509cc7c8.js","q-786606b1.js"]],["[...lang]/giving-back/",[O,()=>Ax],"/[...lang]/giving-back/",["q-509cc7c8.js","q-267ad351.js"]],["[...lang]/leadership-team/",[O,()=>Qx],"/[...lang]/leadership-team/",["q-509cc7c8.js","q-427c1e49.js"]],["[...lang]/legal/",[O,()=>Jx],"/[...lang]/legal/",["q-509cc7c8.js","q-b272b25a.js"]],["[...lang]/local-weather-stations/",[O,()=>sm],"/[...lang]/local-weather-stations/",["q-509cc7c8.js","q-0eb35fe7.js"]],["[...lang]/news/",[O,()=>gm],"/[...lang]/news/",["q-509cc7c8.js","q-92cf9e30.js"]],["[...lang]/our-story/",[O,()=>ym],"/[...lang]/our-story/",["q-509cc7c8.js","q-92951987.js"]],["[...lang]/portability/",[O,()=>Cm],"/[...lang]/portability/",["q-509cc7c8.js","q-474c5250.js"]],["[...lang]/post_slug/",[O,()=>qm],"/[...lang]/post_slug/",["q-509cc7c8.js","q-db6e696c.js"]],["[...lang]/privacy-policy/",[O,()=>Wm],"/[...lang]/privacy-policy/",["q-509cc7c8.js","q-c01437d9.js"]],["[...lang]/referral-program/",[O,()=>a$],"/[...lang]/referral-program/",["q-509cc7c8.js","q-61651da7.js"]],["[...lang]/residential/",[O,()=>c$],"/[...lang]/residential/",["q-509cc7c8.js","q-e21c80b1.js"]],["[...lang]/support/",[O,()=>b$],"/[...lang]/support/",["q-509cc7c8.js","q-9dbd18a2.js"]],["[...lang]/testimonials/",[O,()=>k$],"/[...lang]/testimonials/",["q-509cc7c8.js","q-ba674f3e.js"]],["[...lang]/wholesale/",[O,()=>B$],"/[...lang]/wholesale/",["q-509cc7c8.js","q-695947fd.js"]],["[...lang]/winners-circle/",[O,()=>H$],"/[...lang]/winners-circle/",["q-509cc7c8.js","q-b453227c.js"]],["[...lang]/texas/[slug]/",[O,()=>lh],"/[...lang]/texas/[slug]/",["q-509cc7c8.js","q-0cf4fefb.js"]],["[...lang]",[O,()=>Sh],"/[...lang]",["q-509cc7c8.js","q-a711e8ec.js"]]],kh=[],Lh=!0,Ir="/",Mh=!0,Fh={routes:Ph,serverPlugins:Dh,menus:kh,trailingSlash:Lh,basePathname:Ir,cacheModules:Mh};export{s as A,Dh as B,Ph as C,kh as D,Lh as E,Q as F,Ir as G,Mh as H,Rh as Q,Nh as R,st as S,Ih as _,Bh as a,Eh as b,Fo as c,m as d,We as e,o as f,n as g,u as h,x as i,Oh as j,J as k,y as l,qt as m,kl as n,zt as o,hs as p,Fh as q,et as r,jh as s,ja as t,zh as u,qh as v,Qh as w,Ah as x,Gh as y,Rn as z};
