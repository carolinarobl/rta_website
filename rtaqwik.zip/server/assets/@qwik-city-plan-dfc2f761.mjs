import{parse as Vn}from"marked";const Nr=!0,qr=!1;/**
 * @license
 * @builder.io/qwik 1.2.19
 * Copyright Builder.io, Inc. All Rights Reserved.
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/BuilderIO/qwik/blob/main/LICENSE
 */const Gt=t=>t&&typeof t.nodeType=="number",Yn=t=>t.nodeType===9,Qt=t=>t.nodeType===1,Zt=t=>{const e=t.nodeType;return e===1||e===111},Rr=t=>{const e=t.nodeType;return e===1||e===111||e===3},Mt=t=>t.nodeType===111,tl=t=>t.nodeType===3,Ae=t=>t.nodeType===8,Te=(t,...e)=>al(!0,t,...e),zr=(t,...e)=>{throw al(!1,t,...e)},el=(t,...e)=>al(!0,t,...e),De=()=>{},Fr=t=>t,al=(t,e,...a)=>{const l=e instanceof Error?e:new Error(e);return console.error("%cQWIK ERROR","",l.stack||l.message,...Fr(a)),t&&setTimeout(()=>{throw l},0),l},lt=(t,...e)=>{const a=ba(t);return el(a,...e)},ba=t=>`Code(${t})`,Gr=()=>({isServer:Nr,importSymbol(t,e,a){var o;{const c=lr(a),d=(o=globalThis.__qwik_reg_symbols)==null?void 0:o.get(c);if(d)return d}if(!e)throw lt(31,a);if(!t)throw lt(30,e,a);const l=Qr(t.ownerDocument,t,e).toString(),r=new URL(l);return r.hash="",r.search="",import(r.href).then(c=>c[a])},raf:t=>new Promise(e=>{requestAnimationFrame(()=>{e(t())})}),nextTick:t=>new Promise(e=>{setTimeout(()=>{e(t())})}),chunkForSymbol:(t,e)=>[t,e??"_"]}),Qr=(t,e,a)=>{const l=t.baseURI,r=new URL(e.getAttribute("q:base")??l,l);return new URL(a,r)};let ll=Gr();const pb=t=>ll=t,va=()=>ll,Et=()=>ll.isServer;const Ne=t=>{const e=Object.getPrototypeOf(t);return e===Object.prototype||e===null},Ct=t=>t&&typeof t=="object",tt=t=>Array.isArray(t),Kt=t=>typeof t=="string",mt=t=>typeof t=="function",rt=t=>t&&typeof t.then=="function",ya=(t,e,a)=>{try{const l=t();return rt(l)?l.then(e,a):e(l)}catch(l){return a(l)}},K=(t,e)=>rt(t)?t.then(e):e(t),nl=t=>t.some(rt)?Promise.all(t):t,Je=t=>t.length>0?Promise.all(t):t,Zn=t=>t!=null,Hr=t=>new Promise(e=>{setTimeout(e,t)}),Pt=[],ct={},qe=t=>typeof document<"u"?document:t.nodeType===9?t:t.ownerDocument,ht="q:slot",wa="q:style",qa=Symbol("proxy target"),le=Symbol("proxy flags"),kt=Symbol("proxy manager"),s=Symbol("IMMUTABLE"),_a="_qc_",xt=(t,e,a)=>t.setAttribute(e,a),Tt=(t,e)=>t.getAttribute(e),sl=t=>t.replace(/([A-Z])/g,"-$1").toLowerCase(),Wr=t=>t.replace(/-./g,e=>e[1].toUpperCase()),Ur=/^(on|window:|document:)/,Ra="preventdefault:",ta=t=>t.endsWith("$")&&Ur.test(t),rl=t=>{if(t.length===0)return Pt;if(t.length===1){const a=t[0];return[[a[0],[a[1]]]]}const e=[];for(let a=0;a<t.length;a++){const l=t[a][0];e.includes(l)||e.push(l)}return e.map(a=>[a,t.filter(l=>l[0]===a).map(l=>l[1])])},ea=(t,e,a,l)=>{if(e.endsWith("$"),e=za(e.slice(0,-1)),a)if(tt(a)){const r=a.flat(1/0).filter(o=>o!=null).map(o=>[e,_n(o,l)]);t.push(...r)}else t.push([e,_n(a,l)]);return e},wn=["on","window:on","document:on"],Vr=["on","on-window","on-document"],za=t=>{let e="on";for(let a=0;a<wn.length;a++){const l=wn[a];if(t.startsWith(l)){e=Vr[a],t=t.slice(l.length);break}}return e+":"+(t=t.startsWith("-")?sl(t.slice(1)):t.toLowerCase())},_n=(t,e)=>(t.$setContainer$(e),t),Yr=(t,e)=>{const a=t.$element$.attributes,l=[];for(let r=0;r<a.length;r++){const{name:o,value:c}=a.item(r);if(o.startsWith("on:")||o.startsWith("on-window:")||o.startsWith("on-document:")){const d=c.split(`
`);for(const p of d){const g=Ma(p,e);g.$capture$&&Ys(g,t),l.push([o,g])}}}return l},Sn=Symbol("ContainerState"),pe=t=>{let e=t[Sn];return e||(t[Sn]=e=Kn(t,Tt(t,"q:base")??"/")),e},Kn=(t,e)=>{const a={$containerEl$:t,$elementIndex$:0,$styleMoved$:!1,$proxyMap$:new WeakMap,$opsNext$:new Set,$taskNext$:new Set,$taskStaging$:new Set,$hostsNext$:new Set,$hostsStaging$:new Set,$styleIds$:new Set,$events$:new Set,$serverData$:{},$base$:e,$renderPromise$:void 0,$hostsRendering$:void 0,$pauseCtx$:void 0,$subsManager$:null};return a.$subsManager$=Ru(a),a},il=(t,e)=>{if(mt(t))return t(e);if(Ct(t)&&"value"in t)return t.value=e;throw lt(32,t)},Zr=t=>Qt(t)&&t.hasAttribute("q:container"),zt=t=>t.toString(36),Dt=t=>parseInt(t,36),Xn=t=>{const e=t.indexOf(":");return t&&Wr(t.slice(e+1))},Kr=(t,e)=>{ul(ol(t,void 0),e)},Tn=(t,e)=>{ul(ol(t,"document"),e)},Xr=(t,e)=>{ul(ol(t,"window"),e)},ol=(t,e)=>{const a=e!==void 0?e+":":"";return Array.isArray(t)?t.map(l=>`${a}on-${l}`):`${a}on-${t}`},ul=(t,e)=>{if(e){const a=ws(),l=vt(a.$hostElement$,a.$renderCtx$.$static$.$containerState$);typeof t=="string"?l.li.push([za(t),e]):l.li.push(...t.map(r=>[za(r),e])),l.$flags$|=Ft}},Jr=(t,e,a,l)=>{typeof CustomEvent=="function"&&t&&t.dispatchEvent(new CustomEvent(e,{detail:a,bubbles:l,composed:l}))},u=(t,e,a)=>new Fa(t,e,a),ti=t=>{const e=t.$funcStr$;let a="";for(let l=0;l<t.$args$.length;l++)a+=`p${l},`;return`(${a})=>(${e})`};var Jn;const ei=(t,e,a,l)=>{const r=e.$subsManager$.$createManager$(l);return new ke(t,r,a)},Pe=Symbol("proxy manager"),ts=Symbol("unassigned signal");class Re{}class ke extends Re{constructor(e,a,l){super(),this[Jn]=0,this.untrackedValue=e,this[kt]=a,this[Pe]=l}valueOf(){}toString(){return`[Signal ${String(this.value)}]`}toJSON(){return{value:this.value}}get value(){var a;if(2&this[Pe])throw ts;const e=(a=wt())==null?void 0:a.$subscriber$;return e&&this[kt].$addSub$(e),this.untrackedValue}set value(e){const a=this[kt];a&&this.untrackedValue!==e&&(this.untrackedValue=e,a.$notifySubs$())}}Jn=Pe;class Fa extends Re{constructor(e,a,l){super(),this.$func$=e,this.$args$=a,this.$funcStr$=l}get value(){return this.$func$.apply(void 0,this.$args$)}}class Ga extends Re{constructor(e,a){super(),this.ref=e,this.prop=a}get[kt](){return dt(this.ref)}get value(){return this.ref[this.prop]}set value(e){this.ref[this.prop]=e}}const $t=t=>t instanceof Re,x=(t,e)=>{var r,o;if(!Ct(t))return t[e];if(t instanceof Re)return t;const a=te(t);if(a){const c=a["$$"+e];if(c)return c;if(((r=a[s])==null?void 0:r[e])!==!0)return new Ga(t,e)}const l=(o=t[s])==null?void 0:o[e];return $t(l)?l:s},w=(t,e)=>{const a=x(t,e);return a===s?t[e]:a},cl=(t,e,a=0)=>e.$proxyMap$.get(t)||(a!==0&&Ta(t,a),ze(t,e,void 0)),ze=(t,e,a)=>{We(t),e.$proxyMap$.has(t);const l=e.$subsManager$.$createManager$(a),r=new Proxy(t,new es(e,l));return e.$proxyMap$.set(t,r),r},Sa=()=>{const t={};return Ta(t,2),t},Ta=(t,e)=>{Object.defineProperty(t,le,{value:e,enumerable:!1})},ai=(t,e)=>{const a={};for(const l in t)e.includes(l)||(a[l]=t[l]);return a};class es{constructor(e,a){this.$containerState$=e,this.$manager$=a}deleteProperty(e,a){if(2&e[le])throw lt(17);return typeof a=="string"&&delete e[a]&&(this.$manager$.$notifySubs$(tt(e)?void 0:a),!0)}get(e,a){var g;if(typeof a=="symbol")return a===qa?e:a===kt?this.$manager$:e[a];const l=e[le]??0,r=wt(),o=(1&l)!=0,c=e["$$"+a];let d,p;if(r&&(d=r.$subscriber$),!(2&l)||a in e&&!li((g=e[s])==null?void 0:g[a])||(d=null),c?(p=c.value,d=null):p=e[a],d){const h=tt(e);this.$manager$.$addSub$(d,h?void 0:a)}return o?ni(p,this.$containerState$):p}set(e,a,l){if(typeof a=="symbol")return e[a]=l,!0;const r=e[le]??0;if(2&r)throw lt(17);const o=1&r?We(l):l;if(tt(e))return e[a]=o,this.$manager$.$notifySubs$(),!0;const c=e[a];return e[a]=o,c!==o&&this.$manager$.$notifySubs$(a),!0}has(e,a){if(a===qa)return!0;const l=Object.prototype.hasOwnProperty;return!!l.call(e,a)||!(typeof a!="string"||!l.call(e,"$$"+a))}ownKeys(e){if(!(2&(e[le]??0))){let l=null;const r=wt();r&&(l=r.$subscriber$),l&&this.$manager$.$addSub$(l)}return tt(e)?Reflect.ownKeys(e):Reflect.ownKeys(e).map(l=>typeof l=="string"&&l.startsWith("$$")?l.slice(2):l)}getOwnPropertyDescriptor(e,a){return tt(e)||typeof a=="symbol"?Object.getOwnPropertyDescriptor(e,a):{enumerable:!0,configurable:!0}}}const li=t=>t===s||$t(t),ni=(t,e)=>{if(Ct(t)){if(Object.isFrozen(t))return t;const a=We(t);if(a!==t||Js(a))return t;if(Ne(a)||tt(a))return e.$proxyMap$.get(a)||cl(a,e,1)}return t},dl=Symbol("skip render"),as=()=>null,ls=()=>null,Xt=()=>{const t=ws(),e=vt(t.$hostElement$,t.$renderCtx$.$static$.$containerState$),a=e.$seq$||(e.$seq$=[]),l=t.$i$++;return{val:a[l],set:r=>a[l]=r,i:l,iCtx:t,elCtx:e}},Nt=t=>Object.freeze({id:sl(t)}),Rt=(t,e)=>{const{val:a,set:l,elCtx:r}=Xt();if(a!==void 0)return;(r.$contexts$||(r.$contexts$=new Map)).set(t.id,e),l(!0)},ge=(t,e)=>{const{val:a,set:l,iCtx:r,elCtx:o}=Xt();if(a!==void 0)return a;const c=ns(t,o,r.$renderCtx$.$static$.$containerState$);if(typeof e=="function")return l(pt(void 0,e,c));if(c!==void 0)return l(c);if(e!==void 0)return l(e);throw lt(13,t.id)},si=(t,e)=>{var r;let a=t,l=1;for(;a&&!((r=a.hasAttribute)!=null&&r.call(a,"q:container"));){for(;a=a.previousSibling;)if(Ae(a)){const o=a.__virtual;if(o){const c=o[_a];if(a===o.open)return c??vt(o,e);if(c!=null&&c.$parentCtx$)return c.$parentCtx$;a=o;continue}if(a.data==="/qv")l++;else if(a.data.startsWith("qv ")&&(l--,l===0))return vt(He(a),e)}a=t.parentElement,t=a}return null},ri=(t,e)=>(t.$parentCtx$===void 0&&(t.$parentCtx$=si(t.$element$,e)),t.$parentCtx$),ns=(t,e,a)=>{var o;const l=t.id;if(!e)return;let r=e;for(;r;){const c=(o=r.$contexts$)==null?void 0:o.get(l);if(c)return c;r=ri(r,a)}},ii=Nt("qk-error"),pl=(t,e,a)=>{const l=bt(e);if(Et())throw t;{const r=ns(ii,l,a.$static$.$containerState$);if(r===void 0)throw t;r.error=t}},oi=new Set(["animationIterationCount","aspectRatio","borderImageOutset","borderImageSlice","borderImageWidth","boxFlex","boxFlexGroup","boxOrdinalGroup","columnCount","columns","flex","flexGrow","flexShrink","gridArea","gridRow","gridRowEnd","gridRowStart","gridColumn","gridColumnEnd","gridColumnStart","fontWeight","lineClamp","lineHeight","opacity","order","orphans","scale","tabSize","widows","zIndex","zoom","MozAnimationIterationCount","MozBoxFlex","msFlex","msFlexPositive","WebkitAnimationIterationCount","WebkitBoxFlex","WebkitBoxOrdinalGroup","WebkitColumnCount","WebkitColumns","WebkitFlex","WebkitFlexGrow","WebkitFlexShrink","WebkitLineClamp"]),ui=t=>oi.has(t),aa=(t,e)=>{e.$flags$&=~ue,e.$flags$|=bl,e.$slots$=[],e.li.length=0;const a=e.$element$,l=e.$componentQrl$,r=e.$props$,o=_t(t.$static$.$locale$,a,void 0,"qRender"),c=o.$waitOn$=[],d=Fe(t);d.$cmpCtx$=e,d.$slotCtx$=null,o.$subscriber$=[0,a],o.$renderCtx$=t,l.$setContainer$(t.$static$.$containerState$.$containerEl$);const p=l.getFn(o);return ya(()=>p(r),g=>K(Je(c),()=>e.$flags$&ue?aa(t,e):{node:g,rCtx:d}),g=>g===ts?K(Je(c),()=>aa(t,e)):(pl(g,a,t),{node:dl,rCtx:d}))},ss=(t,e)=>({$static$:{$doc$:t,$locale$:e.$serverData$.locale,$containerState$:e,$hostElements$:new Set,$operations$:[],$postOperations$:[],$roots$:[],$addSlots$:[],$rmSlots$:[],$visited$:[]},$cmpCtx$:null,$slotCtx$:null}),Fe=t=>({$static$:t.$static$,$cmpCtx$:t.$cmpCtx$,$slotCtx$:t.$slotCtx$}),gl=(t,e)=>e&&e.$scopeIds$?e.$scopeIds$.join(" ")+" "+la(t):la(t),la=t=>{if(!t)return"";if(Kt(t))return t.trim();const e=[];if(tt(t))for(const a of t){const l=la(a);l&&e.push(l)}else for(const[a,l]of Object.entries(t))l&&e.push(a.trim());return e.join(" ")},Da=t=>{if(t==null)return"";if(typeof t=="object"){if(tt(t))throw lt(0,t,"style");{const e=[];for(const a in t)if(Object.prototype.hasOwnProperty.call(t,a)){const l=t[a];l!=null&&(a.startsWith("--")?e.push(a+":"+l):e.push(sl(a)+":"+ci(a,l)))}return e.join(";")}}return String(t)},ci=(t,e)=>typeof e!="number"||e===0||ui(t)?e:e+"px",Le=t=>zt(t.$static$.$containerState$.$elementIndex$++),rs=(t,e)=>{const a=Le(t);e.$id$=a},oe=t=>$t(t)?oe(t.value):t==null||typeof t=="boolean"?"":String(t);function is(t){return t.startsWith("aria-")}const os=(t,e)=>!!e.key&&(!fe(t)||!mt(t.type)&&t.key!=e.key),ot="dangerouslySetInnerHTML",fl=(t,e,a)=>{const l=!(e.$flags$&bl),r=e.$element$,o=t.$static$.$containerState$;return o.$hostsStaging$.delete(e),o.$subsManager$.$clearSub$(r),K(aa(t,e),c=>{const d=t.$static$,p=c.rCtx,g=_t(t.$static$.$locale$,r);if(d.$hostElements$.add(r),g.$subscriber$=[0,r],g.$renderCtx$=p,l&&e.$appendStyles$)for(const v of e.$appendStyles$)Lo(d,v);const h=Me(c.node,g);return K(h,v=>{const $=di(r,v),S=xl(e);return K(ua(p,S,$,a),()=>{e.$vdom$=$})})})},xl=t=>(t.$vdom$||(t.$vdom$=ca(t.$element$)),t.$vdom$);class It{constructor(e,a,l,r,o,c){this.$type$=e,this.$props$=a,this.$immutableProps$=l,this.$children$=r,this.$flags$=o,this.$key$=c,this.$elm$=null,this.$text$="",this.$signal$=null,this.$id$=e+(c?":"+c:"")}}const us=(t,e)=>{const{key:a,type:l,props:r,children:o,flags:c,immutableProps:d}=t;let p="";if(Kt(l))p=l;else{if(l!==Vt){if(mt(l)){const h=pt(e,l,r,a,c,t.dev);return os(h,t)?us(i(Vt,{children:h},0,a),e):Me(h,e)}throw lt(25,l)}p=ce}let g=Pt;return o!=null?K(Me(o,e),h=>(h!==void 0&&(g=tt(h)?h:[h]),new It(p,r,d,g,c,a))):new It(p,r,d,g,c,a)},di=(t,e)=>{const a=e===void 0?Pt:tt(e)?e:[e],l=new It(":virtual",{},null,a,0,null);return l.$elm$=t,l},Me=(t,e)=>{if(t!=null&&typeof t!="boolean"){if(cs(t)){const a=new It("#text",ct,null,Pt,0,null);return a.$text$=String(t),a}if(fe(t))return us(t,e);if($t(t)){const a=new It("#text",ct,null,Pt,0,null);return a.$signal$=t,a}if(tt(t)){const a=nl(t.flatMap(l=>Me(l,e)));return K(a,l=>l.flat(100).filter(Zn))}return rt(t)?t.then(a=>Me(a,e)):t===dl?new It(ra,ct,null,Pt,0,null):void De()}},cs=t=>Kt(t)||typeof t=="number",ds=t=>{Tt(t,"q:container")==="paused"&&(gi(t),$i(t))},pi=t=>{const e=qe(t),a=gs(t===e.documentElement?e.body:t,"type");if(a)return JSON.parse(xi(a.firstChild.data)||"{}")},gb=(t,e)=>{const a=JSON.parse(t);if(typeof a!="object")return null;const{_objs:l,_entry:r}=a;if(l===void 0||r===void 0)return null;let o={},c={};if(Gt(e)&&Zt(e)){const g=vl(e);g&&(c=pe(g),o=g.ownerDocument)}const d=Ks(c,o);for(let g=0;g<l.length;g++){const h=l[g];Kt(h)&&(l[g]=h===Ca?void 0:d.prepare(h))}const p=g=>l[Dt(g)];for(const g of l)ps(g,p,d);return p(r)},gi=t=>{if(!Zr(t))return void De();const e=t._qwikjson_??pi(t);if(t._qwikjson_=null,!e)return void De();const a=qe(t),l=t===a.documentElement?a.body:t,r=mi(l),o=pe(t),c=new Map,d=new Map;let p=null,g=0;const h=a.createTreeWalker(t,128);for(;p=h.nextNode();){const y=p.data;if(g===0){if(y.startsWith("qv ")){const I=bi(y);I>=0&&c.set(I,p)}else if(y.startsWith("t=")){const I=y.slice(2),P=Dt(I),_=hi(p);c.set(P,_),d.set(P,_.data)}}y==="cq"?g++:y==="/cq"&&g--}const v=t.getElementsByClassName("qc📦").length!==0;t.querySelectorAll("[q\\:id]").forEach(y=>{if(v&&y.closest("[q\\:container]")!==t)return;const I=Tt(y,"q:id"),P=Dt(I);c.set(P,y)});const $=Ks(o,a),S=new Map,D=new Set,L=y=>(typeof y=="string"&&y.length>0,S.has(y)?S.get(y):T(y)),T=y=>{if(y.startsWith("#")){const O=y.slice(1),k=Dt(O);c.has(k);const M=c.get(k);if(Ae(M)){if(!M.isConnected)return void S.set(y,void 0);const q=He(M);return S.set(y,q),vt(q,o),q}return Qt(M)?(S.set(y,M),vt(M,o),M):(S.set(y,M),M)}if(y.startsWith("@")){const O=y.slice(1),k=Dt(O);return r[k]}if(y.startsWith("*")){const O=y.slice(1),k=Dt(O);c.has(k);const M=d.get(k);return S.set(y,M),M}const I=Dt(y),P=e.objs;P.length>I;let _=P[I];Kt(_)&&(_=_===Ca?void 0:$.prepare(_));let j=_;for(let O=y.length-1;O>=0;O--){const k=Iu[y[O]];if(!k)break;j=k(j,o)}return S.set(y,j),cs(_)||D.has(I)||(D.add(I),fi(_,I,e.subs,L,o,$),ps(_,L,$)),j};o.$elementIndex$=1e5,o.$pauseCtx$={getObject:L,meta:e.ctx,refs:e.refs},xt(t,"q:container","resumed"),Jr(t,"qresume",void 0,!0)},fi=(t,e,a,l,r,o)=>{const c=a[e];if(c){const d=[];let p=0;for(const g of c)if(g.startsWith("_"))p=parseInt(g.slice(1),10);else{const h=qu(g,l);h&&d.push(h)}if(p>0&&Ta(t,p),!o.subs(t,d)){const g=r.$proxyMap$.get(t);g?dt(g).$addSubs$(d):ze(t,r,d)}}},ps=(t,e,a)=>{if(!a.fill(t,e)&&t&&typeof t=="object"){if(tt(t))for(let l=0;l<t.length;l++)t[l]=e(t[l]);else if(Ne(t))for(const l in t)t[l]=e(t[l])}},xi=t=>t.replace(/\\x3C(\/?script)/g,"<$1"),mi=t=>{const e=gs(t,"q:func");return(e==null?void 0:e.qFuncs)??Pt},gs=(t,e)=>{let a=t.lastElementChild;for(;a;){if(a.tagName==="SCRIPT"&&Tt(a,e)==="qwik/json")return a;a=a.previousElementSibling}},hi=t=>{const e=t.nextSibling;if(tl(e))return e;{const a=t.ownerDocument.createTextNode("");return t.parentElement.insertBefore(a,t),a}},$i=t=>{t.qwik={pause:()=>Ho(t),state:pe(t)}},bi=t=>{const e=t.indexOf("q:id=");return e>0?Dt(t.slice(e+5)):-1},et=()=>{const t=Ri();let e=t.$qrl$;if(e)e.$captureRef$;else{const a=t.$element$,l=vl(a);e=Ma(decodeURIComponent(String(t.$url$)),l),ds(l);const r=vt(a,pe(l));Ys(e,r)}return e.$captureRef$},vi=(t,e)=>{try{const a=e[0];switch(a){case 1:case 2:{let l,r;a===1?(l=e[1],r=e[3]):(l=e[3],r=e[1]);const o=bt(l);if(o==null)return;const c=e[4],d=l.namespaceURI===Qe;t.$containerState$.$subsManager$.$clearSignal$(e);let p=Ot(e[2],e.slice(0,-1));c==="class"?p=gl(p,bt(r)):c==="style"&&(p=Da(p));const g=xl(o);return c in g.$props$&&g.$props$[c]===p?void 0:(g.$props$[c]=p,Sl(t,l,c,p,d))}case 3:case 4:{const l=e[3];if(!t.$visited$.includes(l)){t.$containerState$.$subsManager$.$clearSignal$(e);const r=Ot(e[2],e.slice(0,-1));return Bt(t,l,"data",oe(r))}}}}catch{}},yi=(t,e)=>{if(t[0]===0){const a=t[1];$l(a)?ml(a,e):wi(a,e)}else _i(t,e)},wi=(t,e)=>{const a=Et();a||ds(e.$containerEl$);const l=vt(t,e);if(l.$componentQrl$,!(l.$flags$&ue))if(l.$flags$|=ue,e.$hostsRendering$!==void 0)e.$hostsStaging$.add(l);else{if(a)return void De();e.$hostsNext$.add(l),hl(e)}},_i=(t,e)=>{const a=e.$hostsRendering$!==void 0;e.$opsNext$.add(t),a||hl(e)},ml=(t,e)=>{t.$flags$&Ut||(t.$flags$|=Ut,e.$hostsRendering$!==void 0?e.$taskStaging$.add(t):(e.$taskNext$.add(t),hl(e)))},hl=t=>(t.$renderPromise$===void 0&&(t.$renderPromise$=va().nextTick(()=>fs(t))),t.$renderPromise$),Si=()=>{const[t]=et();ml(t,pe(vl(t.$el$)))},fs=async t=>{const e=t.$containerEl$,a=qe(e);try{const l=ss(a,t),r=l.$static$,o=t.$hostsRendering$=new Set(t.$hostsNext$);t.$hostsNext$.clear(),await Di(t,l),t.$hostsStaging$.forEach(p=>{o.add(p)}),t.$hostsStaging$.clear();const c=Array.from(t.$opsNext$);t.$opsNext$.clear();const d=Array.from(o);ki(d),!t.$styleMoved$&&d.length>0&&(t.$styleMoved$=!0,(e===a.documentElement?a.body:e).querySelectorAll("style[q\\:style]").forEach(p=>{t.$styleIds$.add(Tt(p,wa)),zs(r,a.head,p)}));for(const p of d){const g=p.$element$;if(!r.$hostElements$.has(g)&&p.$componentQrl$){g.isConnected,r.$roots$.push(p);try{await fl(l,p,Ti(g.parentElement))}catch(h){Te(h)}}}return c.forEach(p=>{vi(r,p)}),r.$operations$.push(...r.$postOperations$),r.$operations$.length===0?(On(r),void await Dn(t,l)):(await wo(r),On(r),Dn(t,l))}catch(l){Te(l)}},Ti=t=>{let e=0;return t&&(t.namespaceURI===Qe&&(e|=ft),t.tagName==="HEAD"&&(e|=ia)),e},Dn=async(t,e)=>{const a=e.$static$.$hostElements$;await Pi(t,e,(l,r)=>(l.$flags$&xs)!=0&&(!r||a.has(l.$el$))),t.$hostsStaging$.forEach(l=>{t.$hostsNext$.add(l)}),t.$hostsStaging$.clear(),t.$hostsRendering$=void 0,t.$renderPromise$=void 0,t.$hostsNext$.size+t.$taskNext$.size+t.$opsNext$.size>0&&(t.$renderPromise$=fs(t))},Di=async(t,e)=>{const a=t.$containerEl$,l=[],r=[],o=d=>(d.$flags$&ms)!=0,c=d=>(d.$flags$&hs)!=0;t.$taskNext$.forEach(d=>{o(d)&&(r.push(K(d.$qrl$.$resolveLazy$(a),()=>d)),t.$taskNext$.delete(d)),c(d)&&(l.push(K(d.$qrl$.$resolveLazy$(a),()=>d)),t.$taskNext$.delete(d))});do if(t.$taskStaging$.forEach(d=>{o(d)?r.push(K(d.$qrl$.$resolveLazy$(a),()=>d)):c(d)?l.push(K(d.$qrl$.$resolveLazy$(a),()=>d)):t.$taskNext$.add(d)}),t.$taskStaging$.clear(),r.length>0){const d=await Promise.all(r);Qa(d),await Promise.all(d.map(p=>Ha(p,t,e))),r.length=0}while(t.$taskStaging$.size>0);if(l.length>0){const d=await Promise.all(l);Qa(d),d.forEach(p=>Ha(p,t,e))}},Pi=async(t,e,a)=>{const l=[],r=t.$containerEl$;t.$taskNext$.forEach(o=>{a(o,!1)&&(o.$el$.isConnected&&l.push(K(o.$qrl$.$resolveLazy$(r),()=>o)),t.$taskNext$.delete(o))});do if(t.$taskStaging$.forEach(o=>{o.$el$.isConnected&&(a(o,!0)?l.push(K(o.$qrl$.$resolveLazy$(r),()=>o)):t.$taskNext$.add(o))}),t.$taskStaging$.clear(),l.length>0){const o=await Promise.all(l);Qa(o);for(const c of o)Ha(c,t,e);l.length=0}while(t.$taskStaging$.size>0)},ki=t=>{t.sort((e,a)=>2&e.$element$.compareDocumentPosition(pa(a.$element$))?1:-1)},Qa=t=>{t.sort((e,a)=>e.$el$===a.$el$?e.$index$<a.$index$?-1:1:2&e.$el$.compareDocumentPosition(pa(a.$el$))?1:-1)},xs=1,ms=2,hs=4,Ut=16,$s=(t,e)=>{const{val:a,set:l,iCtx:r,i:o,elCtx:c}=Xt();if(a)return;const d=r.$renderCtx$.$static$.$containerState$,p=new Pa(Ut|ms,o,c.$element$,t,void 0);l(!0),t.$resolveLazy$(d.$containerEl$),c.$tasks$||(c.$tasks$=[]),c.$tasks$.push(p),zi(r,()=>vs(p,d,r.$renderCtx$)),Et()&&Wa(p,e==null?void 0:e.eagerness)},Jt=(t,e)=>{const{val:a,set:l,i:r,iCtx:o,elCtx:c}=Xt(),d=(e==null?void 0:e.strategy)??"intersection-observer";if(a)return void(Et()&&Wa(a,d));const p=new Pa(xs,r,c.$element$,t,void 0),g=o.$renderCtx$.$static$.$containerState$;c.$tasks$||(c.$tasks$=[]),c.$tasks$.push(p),l(p),Wa(p,d),Et()||(t.$resolveLazy$(g.$containerEl$),ml(p,g))},bs=t=>(t.$flags$&hs)!=0,Li=t=>(8&t.$flags$)!=0,Ha=async(t,e,a)=>(t.$flags$&Ut,bs(t)?Mi(t,e,a):Li(t)?Ci(t,e,a):vs(t,e,a)),Mi=(t,e,a,l)=>{t.$flags$&=~Ut,Ce(t);const r=_t(a.$static$.$locale$,t.$el$,void 0,"TaskEvent"),{$subsManager$:o}=e;r.$renderCtx$=a;const c=t.$qrl$.getFn(r,()=>{o.$clearSub$(t)}),d=[],p=t.$state$,g=We(p),h={track:(y,I)=>{if(mt(y)){const _=_t();return _.$renderCtx$=a,_.$subscriber$=[0,t],pt(_,y)}const P=dt(y);return P?P.$addSub$([0,t],I):el(ba(26),y),I?y[I]:$t(y)?y.value:y},cleanup(y){d.push(y)},cache(y){let I=0;I=y==="immutable"?1/0:y,p._cache=I},previous:g._resolved};let v,$,S=!1;const D=(y,I)=>!S&&(S=!0,y?(S=!0,p.loading=!1,p._state="resolved",p._resolved=I,p._error=void 0,v(I)):(S=!0,p.loading=!1,p._state="rejected",p._error=I,$(I)),!0);pt(r,()=>{p._state="pending",p.loading=!Et(),p.value=new Promise((y,I)=>{v=y,$=I})}),t.$destroy$=Ia(()=>{S=!0,d.forEach(y=>y())});const L=ya(()=>K(l,()=>c(h)),y=>{D(!0,y)},y=>{D(!1,y)}),T=g._timeout;return T>0?Promise.race([L,Hr(T).then(()=>{D(!1,new Error("timeout"))&&Ce(t)})]):L},vs=(t,e,a)=>{t.$flags$&=~Ut,Ce(t);const l=t.$el$,r=_t(a.$static$.$locale$,l,void 0,"TaskEvent");r.$renderCtx$=a;const{$subsManager$:o}=e,c=t.$qrl$.getFn(r,()=>{o.$clearSub$(t)}),d=[];t.$destroy$=Ia(()=>{d.forEach(g=>g())});const p={track:(g,h)=>{if(mt(g)){const $=_t();return $.$subscriber$=[0,t],pt($,g)}const v=dt(g);return v?v.$addSub$([0,t],h):el(ba(26),g),h?g[h]:g},cleanup(g){d.push(g)}};return ya(()=>c(p),g=>{mt(g)&&d.push(g)},g=>{pl(g,l,a)})},Ci=(t,e,a)=>{t.$state$,t.$flags$&=~Ut,Ce(t);const l=t.$el$,r=_t(a.$static$.$locale$,l,void 0,"ComputedEvent");r.$subscriber$=[0,t],r.$renderCtx$=a;const{$subsManager$:o}=e,c=t.$qrl$.getFn(r,()=>{o.$clearSub$(t)});return ya(c,d=>na(()=>{const p=t.$state$;p[Pe]&=-3,p.untrackedValue=d,p[kt].$notifySubs$()}),d=>{pl(d,l,a)})},Ce=t=>{const e=t.$destroy$;if(e){t.$destroy$=void 0;try{e()}catch(a){Te(a)}}},ys=t=>{32&t.$flags$?(t.$flags$&=-33,(0,t.$qrl$)()):Ce(t)},Wa=(t,e)=>{e==="visible"||e==="intersection-observer"?Kr("qvisible",Ba(t)):e==="load"||e==="document-ready"?Tn("qinit",Ba(t)):e!=="idle"&&e!=="document-idle"||Tn("qidle",Ba(t))},Ba=t=>{const e=t.$qrl$;return Ea(e.$chunk$,"_hW",Si,null,null,[t],e.$symbol$)},$l=t=>Ct(t)&&t instanceof Pa,ji=(t,e)=>{let a=`${zt(t.$flags$)} ${zt(t.$index$)} ${e(t.$qrl$)} ${e(t.$el$)}`;return t.$state$&&(a+=` ${e(t.$state$)}`),a},Ii=t=>{const[e,a,l,r,o]=t.split(" ");return new Pa(Dt(e),Dt(a),r,l,o)};class Pa{constructor(e,a,l,r,o){this.$flags$=e,this.$index$=a,this.$el$=l,this.$qrl$=r,this.$state$=o}}function Ei(t){return Oi(t)&&t.nodeType===1}function Oi(t){return t&&typeof t.nodeType=="number"}const ue=1,Ft=2,bl=4,bt=t=>t[_a],vt=(t,e)=>{const a=bt(t);if(a)return a;const l=ka(t),r=Tt(t,"q:id");if(r){const o=e.$pauseCtx$;if(l.$id$=r,o){const{getObject:c,meta:d,refs:p}=o;if(Ei(t)){const g=p[r];g&&(l.$refMap$=g.split(" ").map(c),l.li=Yr(l,e.$containerEl$))}else{const g=t.getAttribute("q:sstyle");l.$scopeIds$=g?g.split("|"):null;const h=d[r];if(h){const v=h.s,$=h.h,S=h.c,D=h.w;if(v&&(l.$seq$=v.split(" ").map(c)),D&&(l.$tasks$=D.split(" ").map(c)),S){l.$contexts$=new Map;for(const L of S.split(" ")){const[T,y]=L.split("=");l.$contexts$.set(T,c(y))}}if($){const[L,T]=$.split(" ");if(l.$flags$=bl,L&&(l.$componentQrl$=c(L)),T){const y=c(T);l.$props$=y,Ta(y,2),y[s]=Bi(y)}else l.$props$=ze(Sa(),e)}}}}}return l},Bi=t=>{const e={},a=te(t);for(const l in a)l.startsWith("$$")&&(e[l.slice(2)]=a[l]);return e},ka=t=>{const e={$flags$:0,$id$:"",$element$:t,$refMap$:[],li:[],$tasks$:null,$seq$:null,$slots$:null,$scopeIds$:null,$appendStyles$:null,$props$:null,$vdom$:null,$componentQrl$:null,$contexts$:null,$dynamicSlots$:null,$parentCtx$:void 0};return t[_a]=e,e},Ai=(t,e)=>{var a;(a=t.$tasks$)==null||a.forEach(l=>{e.$clearSub$(l),ys(l)}),t.$componentQrl$=null,t.$seq$=null,t.$tasks$=null};let se;function Ni(t){if(se===void 0){const e=wt();if(e&&e.$locale$)return e.$locale$;if(t!==void 0)return t;throw new Error("Reading `locale` outside of context.")}return se}function Pn(t,e){const a=se;try{return se=t,e()}finally{se=a}}function qi(t){se=t}let ye;const wt=()=>{if(!ye){const t=typeof document<"u"&&document&&document.__q_context__;return t?tt(t)?document.__q_context__=_s(t):t:void 0}return ye},Ri=()=>{const t=wt();if(!t)throw lt(14);return t},ws=()=>{const t=wt();if(!t||t.$event$!=="qRender")throw lt(20);return t.$hostElement$,t.$waitOn$,t.$renderCtx$,t.$subscriber$,t};function pt(t,e,...a){const l=ye;let r;try{ye=t,r=e.apply(this,a)}finally{ye=l}return r}const zi=(t,e)=>{const a=t.$waitOn$;if(a.length===0){const l=e();rt(l)&&a.push(l)}else a.push(Promise.all(a).then(e))},_s=t=>{const e=t[0],a=e.closest("[q\\:container]"),l=(a==null?void 0:a.getAttribute("q:locale"))||void 0;return l&&qi(l),_t(l,void 0,e,t[1],t[2])},_t=(t,e,a,l,r)=>({$url$:r,$i$:0,$hostElement$:e,$element$:a,$event$:l,$qrl$:void 0,$waitOn$:void 0,$subscriber$:void 0,$renderCtx$:void 0,$locale$:t}),vl=t=>t.closest("[q\\:container]"),na=t=>pt(void 0,t),kn=_t(void 0,void 0,void 0,"qRender"),Ot=(t,e)=>(kn.$subscriber$=e,pt(kn,()=>t.value)),Fi=()=>{var e;const t=wt();if(t)return t.$element$??t.$hostElement$??((e=t.$qrl$)==null?void 0:e.$setContainer$(void 0))},Gi=()=>{const t=wt();if(t)return t.$event$},Z=t=>{const e=wt();return e&&e.$hostElement$&&e.$renderCtx$&&(vt(e.$hostElement$,e.$renderCtx$.$static$.$containerState$).$flags$|=8),t},Qi=(t,e=0)=>{for(let a=0;a<t.length;a++)e=(e<<5)-e+t.charCodeAt(a),e|=0;return Number(Math.abs(e)).toString(36)},Hi=(t,e)=>`${Qi(t.$hash$)}-${e}`,Wi=t=>"⭐️"+t,Ss=t=>{const e=t.join("|");if(e.length>0)return e};var Ts;const Ze="<!--qkssr-f-->";class Ds{constructor(e){this.nodeType=e,this[Ts]=null}}Ts=_a;const Ui=()=>new Ds(9),fb=async(t,e)=>{var $,S,D;const a=e.containerTagName,l=sa(1).$element$,r=Kn(l,e.base??"/");r.$serverData$.locale=($=e.serverData)==null?void 0:$.locale;const o=Ui(),c=ss(o,r),d=e.beforeContent??[],p={$static$:{$contexts$:[],$headNodes$:a==="html"?d:[],$locale$:(S=e.serverData)==null?void 0:S.locale,$textNodes$:new Map},$projectedChildren$:void 0,$projectedCtxs$:void 0,$invocationContext$:void 0};let g="ssr";e.containerAttributes["q:render"]&&(g=`${e.containerAttributes["q:render"]}-${g}`);const h={...e.containerAttributes,"q:container":"paused","q:version":"1.2.19","q:render":g,"q:base":e.base,"q:locale":(D=e.serverData)==null?void 0:D.locale,"q:manifest-hash":e.manifestHash},v=a==="html"?[t]:[d,t];a!=="html"&&(h.class="qc📦"+(h.class?" "+h.class:"")),e.serverData&&(r.$serverData$=e.serverData),t=n(a,null,h,v,ue|Ft,null),r.$hostsRendering$=new Set,await Promise.resolve().then(()=>Vi(t,c,p,e.stream,r,e))},Vi=async(t,e,a,l,r,o)=>{const c=o.beforeClose;return await wl(t,e,a,l,0,c?d=>{const p=c(a.$static$.$contexts$,r,!1,a.$static$.$textNodes$);return Lt(p,e,a,d,0,void 0)}:void 0),e},Yi=async(t,e,a,l,r)=>{l.write(Ze);const o=t.props.children;let c;if(mt(o)){const d=o({write(p){l.write(p),l.write(Ze)}});if(rt(d))return d;c=d}else c=o;for await(const d of c)await Lt(d,e,a,l,r,void 0),l.write(Ze)},Ps=(t,e,a,l,r,o,c,d)=>{var L;const p=t.props,g=p["q:renderFn"];if(g)return e.$componentQrl$=g,Xi(l,r,o,e,t,c,d);let h="<!--qv"+Ki(p);const v="q:s"in p,$=t.key!=null?String(t.key):null;v&&((L=l.$cmpCtx$)==null||L.$id$,h+=" q:sref="+l.$cmpCtx$.$id$),$!=null&&(h+=" q:key="+$),h+="-->",o.write(h);const S=t.props[ot];if(S)return o.write(S),void o.write(Aa);if(a)for(const T of a)yl(T.type,T.props,o);const D=ks(t.children,l,r,o,c);return K(D,()=>{var y;if(!v&&!d)return void o.write(Aa);let T;if(v){const I=(y=r.$projectedChildren$)==null?void 0:y[$];if(I){const[P,_]=r.$projectedCtxs$,j=Fe(P);j.$slotCtx$=e,r.$projectedChildren$[$]=void 0,T=Lt(I,j,_,o,c)}}return d&&(T=K(T,()=>d(o))),K(T,()=>{o.write(Aa)})})},Aa="<!--/qv-->",Zi=t=>{let e="";for(const a in t){if(a===ot)continue;const l=t[a];l!=null&&(e+=" "+(l===""?a:a+'="'+l+'"'))}return e},Ki=t=>{let e="";for(const a in t){if(a==="children"||a===ot)continue;const l=t[a];l!=null&&(e+=" "+(l===""?a:a+"="+l))}return e},yl=(t,e,a)=>{if(a.write("<"+t+Zi(e)+">"),Cs[t])return;const l=e[ot];l!=null&&a.write(l),a.write(`</${t}>`)},Xi=(t,e,a,l,r,o,c)=>(to(t,l,r.props.props),K(aa(t,l),d=>{const p=l.$element$,g=d.rCtx,h=_t(e.$static$.$locale$,p,void 0);h.$subscriber$=[0,p],h.$renderCtx$=g;const v={$static$:e.$static$,$projectedChildren$:Ji(r.children,e),$projectedCtxs$:[t,e],$invocationContext$:h},$=[];if(l.$appendStyles$){const T=4&o?e.$static$.$headNodes$:$;for(const y of l.$appendStyles$)T.push(n("style",{[wa]:y.styleId,[ot]:y.content,hidden:""},null,null,0,null))}const S=Le(t),D=l.$scopeIds$?Ss(l.$scopeIds$):void 0,L=i(r.type,{"q:sstyle":D,"q:id":S,children:d.node},0,r.key);return l.$id$=S,e.$static$.$contexts$.push(l),Ps(L,l,$,g,v,a,o,T=>{if(l.$flags$&Ft){const P=sa(1),_=P.li;_.push(...l.li),l.$flags$&=~Ft,P.$id$=Le(t);const j={type:"placeholder",hidden:"","q:id":P.$id$};e.$static$.$contexts$.push(P);const O=rl(_);for(const k of O){const M=js(k[0]);j[M]=Ll(k[1],P),Ke(M,t.$static$.$containerState$)}yl("script",j,T)}const y=v.$projectedChildren$;let I;if(y){const P=Object.keys(y).map(k=>{const M=y[k];if(M)return n("q:template",{[ht]:k,hidden:"","aria-hidden":"true"},null,M,0,null)}),[_,j]=v.$projectedCtxs$,O=Fe(_);O.$slotCtx$=l,I=Lt(P,O,j,T,0,void 0)}return c?K(I,()=>c(T)):I})})),Ji=(t,e)=>{const a=Ls(t,e);if(a===null)return;const l={};for(const r of a){let o="";fe(r)&&(o=r.props[ht]??""),(l[o]||(l[o]=[])).push(r)}return l},sa=t=>{const e=new Ds(t);return ka(e)},wl=(t,e,a,l,r,o)=>{var g;const c=t.type,d=e.$cmpCtx$;if(typeof c=="string"){const h=t.key,v=t.props,$=t.immutableProps,S=sa(1),D=S.$element$,L=c==="head";let T="<"+c,y=!1,I=!1,P="",_=null;if($)for(const k in $){let M=$[k];if(ta(k)){ea(S.li,k,M,void 0);continue}const q=Ln(k);if($t(M)&&(M=Ot(M,[1,D,M,d.$element$,q]),y=!0),k===ot){_=M;continue}k.startsWith(Ra)&&Ke(k.slice(15),e.$static$.$containerState$);const U=Mn(q,M);U!=null&&(q==="class"?P=U:q==="value"&&c==="textarea"?_=we(U):Cn(q)||(T+=" "+(M===""?q:q+'="'+Ve(U)+'"')))}for(const k in v){let M=v[k];if(k==="ref"){M!==void 0&&(il(M,D),I=!0);continue}if(ta(k)){ea(S.li,k,M,void 0);continue}const q=Ln(k);if($t(M)&&(M=Ot(M,[2,d.$element$,M,D,q]),y=!0),k===ot){_=M;continue}k.startsWith(Ra)&&Ke(k.slice(15),e.$static$.$containerState$);const U=Mn(q,M);U!=null&&(q==="class"?P=U:q==="value"&&c==="textarea"?_=we(U):Cn(q)||(T+=" "+(M===""?q:q+'="'+Ve(U)+'"')))}const j=S.li;if(d){if((g=d.$scopeIds$)!=null&&g.length){const k=d.$scopeIds$.join(" ");P=P?`${k} ${P}`:k}d.$flags$&Ft&&(j.push(...d.li),d.$flags$&=~Ft)}if(L&&(r|=1),c in eo&&(r|=16),c in ao&&(r|=8),P&&(T+=' class="'+Ve(P)+'"'),j.length>0){const k=rl(j),M=(16&r)!=0;for(const q of k){const U=M?js(q[0]):q[0];T+=" "+U+'="'+Ll(q[1],S)+'"',Ke(U,e.$static$.$containerState$)}}if(h!=null&&(T+=' q:key="'+Ve(h)+'"'),I||y||j.length>0){if(I||y||ro(j)){const k=Le(e);T+=' q:id="'+k+'"',S.$id$=k}a.$static$.$contexts$.push(S)}if(1&r&&(T+=" q:head"),T+=">",l.write(T),c in Cs)return;if(_!=null)return l.write(String(_)),void l.write(`</${c}>`);c==="html"?r|=4:r&=-5,2&t.flags&&(r|=1024);const O=Lt(t.children,e,a,l,r);return K(O,()=>{if(L){for(const k of a.$static$.$headNodes$)yl(k.type,k.props,l);a.$static$.$headNodes$.length=0}if(o)return K(o(l),()=>{l.write(`</${c}>`)});l.write(`</${c}>`)})}if(c===Vt){const h=sa(111);return h.$parentCtx$=e.$slotCtx$||e.$cmpCtx$,d&&8&d.$flags$&&io(d,h),Ps(t,h,void 0,e,a,l,r,o)}if(c===as)return void l.write(t.props.data);if(c===ls)return Yi(t,e,a,l,r);const p=pt(a.$invocationContext$,c,t.props,t.key,t.flags,t.dev);return os(p,t)?wl(i(Vt,{children:p},0,t.key),e,a,l,r,o):Lt(p,e,a,l,r,o)},Lt=(t,e,a,l,r,o)=>{var c;if(t!=null&&typeof t!="boolean"){if(!Kt(t)&&typeof t!="number"){if(fe(t))return wl(t,e,a,l,r,o);if(tt(t))return ks(t,e,a,l,r);if($t(t)){const d=8&r,p=(c=e.$cmpCtx$)==null?void 0:c.$element$;let g;if(p){if(!d){const h=Le(e);g=Ot(t,1024&r?[3,"#"+h,t,"#"+h]:[4,p,t,"#"+h]);const v=oe(g);return a.$static$.$textNodes$.set(v,h),void l.write(`<!--t=${h}-->${we(v)}<!---->`)}g=pt(a.$invocationContext$,()=>t.value)}return void l.write(we(oe(g)))}return rt(t)?(l.write(Ze),t.then(d=>Lt(d,e,a,l,r,o))):void De()}l.write(we(String(t)))}},ks=(t,e,a,l,r)=>{if(t==null)return;if(!tt(t))return Lt(t,e,a,l,r);const o=t.length;if(o===1)return Lt(t[0],e,a,l,r);if(o===0)return;let c=0;const d=[];return t.reduce((p,g,h)=>{const v=[];d.push(v);const $=Lt(g,e,a,p?{write(D){c===h?l.write(D):v.push(D)}}:l,r),S=()=>{c++,d.length>c&&d[c].forEach(D=>l.write(D))};return rt($)&&p?Promise.all([$,p]).then(S):rt($)?$.then(S):p?p.then(S):void c++},void 0)},Ls=(t,e)=>{if(t==null)return null;const a=Ms(t,e),l=tt(a)?a:[a];return l.length===0?null:l},Ms=(t,e)=>{if(t==null)return null;if(tt(t))return t.flatMap(a=>Ms(a,e));if(fe(t)&&mt(t.type)&&t.type!==as&&t.type!==ls&&t.type!==Vt){const a=pt(e.$invocationContext$,t.type,t.props,t.key,t.flags);return Ls(a,e)}return t},to=(t,e,a)=>{const l=Object.keys(a),r=Sa();if(e.$props$=ze(r,t.$static$.$containerState$),l.length===0)return;const o=r[s]=a[s]??ct;for(const c of l)c!=="children"&&c!==ht&&($t(o[c])?r["$$"+c]=o[c]:r[c]=a[c])},Ln=t=>t==="htmlFor"?"for":t,Mn=(t,e)=>t==="class"?la(e):t==="style"?Da(e):is(t)||t==="draggable"||t==="spellcheck"?e!=null?String(e):e:e===!1||e==null?null:e===!0?"":String(e),eo={head:!0,style:!0,script:!0,link:!0,meta:!0},ao={title:!0,style:!0,script:!0,noframes:!0,textarea:!0},Cs={area:!0,base:!0,basefont:!0,bgsound:!0,br:!0,col:!0,embed:!0,frame:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0},lo=/[&<>]/g,no=/[&"]/g,Ke=(t,e)=>{e.$events$.add(Xn(t))},we=t=>t.replace(lo,e=>{switch(e){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";default:return""}}),Ve=t=>t.replace(no,e=>{switch(e){case"&":return"&amp;";case'"':return"&quot;";default:return""}}),so=/[>/="'\u0009\u000a\u000c\u0020]/,Cn=t=>so.test(t),ro=t=>t.some(e=>e[1].$captureRef$&&e[1].$captureRef$.length>0),io=(t,e)=>{const a=t.$dynamicSlots$||(t.$dynamicSlots$=[]);a.includes(e)||a.push(e)},js=t=>t==="on:qvisible"?"on-document:qinit":t,n=(t,e,a,l,r,o)=>{const c=o==null?null:String(o);return new Ge(t,e??ct,a,l,r,c)},Y=(t,e,a,l,r,o)=>{let c=null;return e&&"children"in e&&(c=e.children,delete e.children),n(t,e,a,c,l,r)},i=(t,e,a,l,r)=>{const o=l==null?null:String(l),c=e??ct;if(typeof t=="string"&&s in c){const p={};for(const[g,h]of Object.entries(c[s]))p[g]=h===s?c[g]:h;return n(t,null,p,c.children,a,l)}const d=new Ge(t,c,null,c.children,a,o);return typeof t=="string"&&e&&delete e.children,d},xb=(t,e,a)=>{const l=a==null?null:String(a),r=na(()=>{const c=e.children;return typeof t=="string"&&delete e.children,c});return Kt(t)&&"className"in e&&(e.class=e.className,delete e.className),new Ge(t,e,null,r,0,l)},ra=":skipRender";class Ge{constructor(e,a,l,r,o,c=null){this.type=e,this.props=a,this.immutableProps=l,this.children=r,this.flags=o,this.key=c}}const Vt=t=>t.children,fe=t=>t instanceof Ge,H=t=>t.children,Qe="http://www.w3.org/2000/svg",ft=1,ia=2,oa=[],ua=(t,e,a,l)=>{e.$elm$;const r=a.$children$;if(r.length===1&&r[0].$type$===ra)return void(a.$children$=e.$children$);const o=e.$elm$;let c=da;e.$children$===oa&&o.nodeName==="HEAD"&&(c=po,l|=ia);const d=oo(e,c);return d.length>0&&r.length>0?uo(t,o,d,r,l):d.length>0&&r.length===0?_l(t.$static$,d,0,d.length-1):r.length>0?Os(t,o,null,r,0,r.length-1,l):void 0},oo=(t,e)=>{const a=t.$children$;return a===oa?t.$children$=Is(t.$elm$,e):a},uo=(t,e,a,l,r)=>{let o=0,c=0,d=a.length-1,p=a[0],g=a[d],h=l.length-1,v=l[0],$=l[h],S,D,L;const T=[],y=t.$static$;for(;o<=d&&c<=h;)if(p==null)p=a[++o];else if(g==null)g=a[--d];else if(v==null)v=l[++c];else if($==null)$=l[--h];else if(p.$id$===v.$id$)T.push(he(t,p,v,r)),p=a[++o],v=l[++c];else if(g.$id$===$.$id$)T.push(he(t,g,$,r)),g=a[--d],$=l[--h];else if(p.$key$&&p.$id$===$.$id$)p.$elm$,g.$elm$,T.push(he(t,p,$,r)),ko(y,e,p.$elm$,g.$elm$),p=a[++o],$=l[--h];else if(g.$key$&&g.$id$===v.$id$)p.$elm$,g.$elm$,T.push(he(t,g,v,r)),be(y,e,g.$elm$,p.$elm$),g=a[--d],v=l[++c];else{if(S===void 0&&(S=To(a,o,d)),D=S[v.$key$],D===void 0){const P=je(t,v,r,T);be(y,e,P,p==null?void 0:p.$elm$)}else if(L=a[D],L.$type$!==v.$type$){const P=je(t,v,r,T);K(P,_=>{be(y,e,_,p==null?void 0:p.$elm$)})}else T.push(he(t,L,v,r)),a[D]=void 0,L.$elm$,be(y,e,L.$elm$,p.$elm$);v=l[++c]}c<=h&&T.push(Os(t,e,l[h+1]==null?null:l[h+1].$elm$,l,c,h,r));let I=nl(T);return o<=d&&(I=K(I,()=>{_l(y,a,o,d)})),I},ne=(t,e)=>{const a=Mt(t)?t.close:null,l=[];let r=t.firstChild;for(;(r=Dl(r))&&(e(r)&&l.push(r),r=r.nextSibling,r!==a););return l},Is=(t,e)=>ne(t,e).map(co),co=t=>{var e;return Qt(t)?((e=bt(t))==null?void 0:e.$vdom$)??ca(t):ca(t)},ca=t=>{if(Zt(t)){const e=new It(t.localName,{},null,oa,0,Va(t));return e.$elm$=t,e}if(tl(t)){const e=new It(t.nodeName,ct,null,oa,0,null);return e.$text$=t.data,e.$elm$=t,e}},po=t=>{const e=t.nodeType;return e===1?t.hasAttribute("q:head"):e===111},Ua=t=>t.nodeName==="Q:TEMPLATE",da=t=>{const e=t.nodeType;if(e===3||e===111)return!0;if(e!==1)return!1;const a=t.nodeName;return a!=="Q:TEMPLATE"&&(a==="HEAD"?t.hasAttribute("q:head"):a!=="STYLE"||!t.hasAttribute(wa))},Es=t=>{const e={};for(const a of t){const l=go(a);(e[l]??(e[l]=new It(ce,{"q:s":""},null,[],0,l))).$children$.push(a)}return e},he=(t,e,a,l)=>{e.$type$,a.$type$,e.$key$,a.$key$,e.$id$,a.$id$;const r=e.$elm$,o=a.$type$,c=t.$static$,d=c.$containerState$,p=t.$cmpCtx$;if(a.$elm$=r,o==="#text"){c.$visited$.push(r);const $=a.$signal$;return $&&(a.$text$=oe(Ot($,[4,p.$element$,$,r]))),void Bt(c,r,"data",a.$text$)}const g=a.$props$,h=a.$flags$,v=vt(r,d);if(o!==ce){let $=(l&ft)!=0;if($||o!=="svg"||(l|=ft,$=!0),g!==ct){!(1&h)&&(v.li.length=0);const S=e.$props$;a.$props$=S;for(const D in g){let L=g[D];if(D!=="ref")if(ta(D)){const T=ea(v.li,D,L,d.$containerEl$);Ns(c,r,T)}else $t(L)&&(L=Ot(L,[1,p.$element$,L,r,D])),D==="class"?L=gl(L,p):D==="style"&&(L=Da(L)),S[D]!==L&&(S[D]=L,Sl(c,r,D,L,$));else L!==void 0&&il(L,r)}}return 2&h||($&&o==="foreignObject"&&(l&=~ft),g[ot]!==void 0)||o==="textarea"?void 0:ua(t,e,a,l)}if("q:renderFn"in g){const $=g.props;yo(d,v,$);let S=!!(v.$flags$&ue);return S||v.$componentQrl$||v.$element$.hasAttribute("q:id")||(rs(t,v),v.$componentQrl$=$["q:renderFn"],v.$componentQrl$,S=!0),S?K(fl(t,v,l),()=>jn(t,v,a,l)):jn(t,v,a,l)}if("q:s"in g)return p.$slots$,void p.$slots$.push(a);if(ot in g)Bt(c,r,"innerHTML",g[ot]);else if(!(2&h))return ua(t,e,a,l)},jn=(t,e,a,l)=>{if(2&a.$flags$)return;const r=t.$static$,o=Es(a.$children$),c=As(e);for(const d in c.slots)if(!o[d]){const p=c.slots[d],g=Is(p,da);if(g.length>0){const h=bt(p);h&&h.$vdom$&&(h.$vdom$.$children$=[]),_l(r,g,0,g.length-1)}}for(const d in c.templates){const p=c.templates[d];p&&!o[d]&&(c.templates[d]=void 0,Fs(r,p))}return nl(Object.keys(o).map(d=>{const p=o[d],g=Bs(r,c,e,d,t.$static$.$containerState$),h=xl(g),v=Fe(t),$=g.$element$;v.$slotCtx$=g,g.$vdom$=p,p.$elm$=$;let S=l&~ft;$.isSvg&&(S|=ft);const D=r.$addSlots$.findIndex(L=>L[0]===$);return D>=0&&r.$addSlots$.splice(D,1),ua(v,h,p,S)}))},Os=(t,e,a,l,r,o,c)=>{const d=[];for(;r<=o;++r){const p=l[r],g=je(t,p,c,d);be(t.$static$,e,g,a)}return Je(d)},_l=(t,e,a,l)=>{for(;a<=l;++a){const r=e[a];r&&(r.$elm$,Fs(t,r.$elm$))}},Bs=(t,e,a,l,r)=>{const o=e.slots[l];if(o)return vt(o,r);const c=e.templates[l];if(c)return vt(c,r);const d=Gs(t.$doc$,l),p=ka(d);return p.$parentCtx$=a,Co(t,a.$element$,d),e.templates[l]=d,p},go=t=>t.$props$[ht]??"",je=(t,e,a,l)=>{const r=e.$type$,o=t.$static$.$doc$,c=t.$cmpCtx$;if(r==="#text"){const T=e.$signal$,y=o.createTextNode(e.$text$);return T&&(y.data=e.$text$=oe(Ot(T,4&a?[3,y,T,y]:[4,c.$element$,T,y]))),e.$elm$=y}let d,p=!!(a&ft);p||r!=="svg"||(a|=ft,p=!0);const g=r===ce,h=e.$props$,v=t.$static$,$=v.$containerState$;g?d=Ao(o,p):r==="head"?(d=o.head,a|=ia):(d=Tl(o,r,p),a&=~ia),2&e.$flags$&&(a|=4),e.$elm$=d;const S=ka(d);if(S.$parentCtx$=t.$slotCtx$??t.$cmpCtx$,g){if("q:renderFn"in h){const T=h["q:renderFn"],y=Sa(),I=$.$subsManager$.$createManager$(),P=new Proxy(y,new es($,I)),_=h.props;if($.$proxyMap$.set(y,P),S.$props$=P,_!==ct){const O=y[s]=_[s]??ct;for(const k in _)if(k!=="children"&&k!==ht){const M=O[k];$t(M)?y["$$"+k]=M:y[k]=_[k]}}rs(t,S),S.$componentQrl$=T;const j=K(fl(t,S,a),()=>{let O=e.$children$;if(O.length===0)return;O.length===1&&O[0].$type$===ra&&(O=O[0].$children$);const k=As(S),M=[],q=Es(O);for(const U in q){const ut=q[U],it=Bs(v,k,S,U,v.$containerState$),jt=Fe(t),ae=it.$element$;jt.$slotCtx$=it,it.$vdom$=ut,ut.$elm$=ae;let gt=a&~ft;ae.isSvg&&(gt|=ft);for(const nt of ut.$children$){const me=je(jt,nt,gt,M);nt.$elm$,nt.$elm$,zs(v,ae,me)}}return Je(M)});return rt(j)&&l.push(j),d}if("q:s"in h)c.$slots$,Oo(d,e.$key$),xt(d,"q:sref",c.$id$),xt(d,"q:s",""),c.$slots$.push(e),v.$addSlots$.push([d,c.$element$]);else if(ot in h)return Bt(v,d,"innerHTML",h[ot]),d}else{if(e.$immutableProps$&&En(v,S,c,e.$immutableProps$,p,!0),h!==ct&&(S.$vdom$=e,e.$props$=En(v,S,c,h,p,!1)),p&&r==="foreignObject"&&(p=!1,a&=~ft),c){const T=c.$scopeIds$;T&&T.forEach(y=>{d.classList.add(y)}),c.$flags$&Ft&&(S.li.push(...c.li),c.$flags$&=~Ft)}for(const T of S.li)Ns(v,d,T[0]);if(h[ot]!==void 0)return d;p&&r==="foreignObject"&&(p=!1,a&=~ft)}let D=e.$children$;if(D.length===0)return d;D.length===1&&D[0].$type$===ra&&(D=D[0].$children$);const L=D.map(T=>je(t,T,a,l));for(const T of L)Ie(d,T);return d},fo=t=>{const e=t.$slots$;return e||(t.$element$.parentElement,t.$slots$=xo(t))},As=t=>{const e=fo(t),a={},l={},r=Array.from(t.$element$.childNodes).filter(Ua);for(const o of e)o.$elm$,a[o.$key$??""]=o.$elm$;for(const o of r)l[Tt(o,ht)??""]=o;return{slots:a,templates:l}},xo=t=>{const e=t.$element$.parentElement;return zo(e,"q:sref",t.$id$).map(ca)},mo=(t,e,a)=>(Bt(t,e.style,"cssText",a),!0),ho=(t,e,a)=>(e.namespaceURI===Qe?Ee(t,e,"class",a):Bt(t,e,"className",a),!0),In=(t,e,a,l)=>(l in e&&e[l]!==a&&(e.tagName==="SELECT"?Po(t,e,l,a):Bt(t,e,l,a)),!0),$e=(t,e,a,l)=>(Ee(t,e,l.toLowerCase(),a),!0),$o=(t,e,a)=>(Bt(t,e,"innerHTML",a),!0),bo=()=>!0,vo={style:mo,class:ho,value:In,checked:In,href:$e,list:$e,form:$e,tabIndex:$e,download:$e,innerHTML:bo,[ot]:$o},Sl=(t,e,a,l,r)=>{if(is(a))return void Ee(t,e,a,l!=null?String(l):l);const o=vo[a];o&&o(t,e,l,a)||(r||!(a in e)?(a.startsWith(Ra)&&qs(a.slice(15)),Ee(t,e,a,l)):Bt(t,e,a,l))},En=(t,e,a,l,r,o)=>{const c={},d=e.$element$;for(const p in l){let g=l[p];if(p!=="ref")if(ta(p))ea(e.li,p,g,t.$containerState$.$containerEl$);else{if($t(g)&&(g=Ot(g,o?[1,d,g,a.$element$,p]:[2,a.$element$,g,d,p])),p==="class"){if(g=gl(g,a),!g)continue}else p==="style"&&(g=Da(g));c[p]=g,Sl(t,d,p,g,r)}else g!==void 0&&il(g,d)}return c},yo=(t,e,a)=>{let l=e.$props$;if(l||(e.$props$=l=ze(Sa(),t)),a===ct)return;const r=dt(l),o=te(l),c=o[s]=a[s]??ct;for(const d in a)if(d!=="children"&&d!==ht&&!c[d]){const p=a[d];o[d]!==p&&(o[d]=p,r.$notifySubs$(d))}},_e=(t,e,a,l)=>{if(a.$clearSub$(t),Zt(t)){if(l&&t.hasAttribute("q:s"))return void e.$rmSlots$.push(t);const r=bt(t);r&&Ai(r,a);const o=Mt(t)?t.close:null;let c=t.firstChild;for(;(c=Dl(c))&&(_e(c,e,a,!0),c=c.nextSibling,c!==o););}},wo=async t=>{Eo(t)},Ie=(t,e)=>{Mt(e)?e.appendTo(t):t.appendChild(e)},_o=(t,e)=>{Mt(e)?e.remove():t.removeChild(e)},So=(t,e,a)=>{Mt(e)?e.insertBeforeTo(t,(a==null?void 0:a.nextSibling)??null):t.insertBefore(e,(a==null?void 0:a.nextSibling)??null)},La=(t,e,a)=>{Mt(e)?e.insertBeforeTo(t,pa(a)):t.insertBefore(e,pa(a))},To=(t,e,a)=>{const l={};for(let r=e;r<=a;++r){const o=t[r].$key$;o!=null&&(l[o]=r)}return l},Ns=(t,e,a)=>{a.startsWith("on:")||Ee(t,e,a,""),qs(a)},qs=t=>{var e;{const a=Xn(t);try{((e=globalThis).qwikevents||(e.qwikevents=[])).push(a)}catch{}}},Ee=(t,e,a,l)=>{t.$operations$.push({$operation$:Do,$args$:[e,a,l]})},Do=(t,e,a)=>{if(a==null||a===!1)t.removeAttribute(e);else{const l=a===!0?"":String(a);xt(t,e,l)}},Bt=(t,e,a,l)=>{t.$operations$.push({$operation$:Rs,$args$:[e,a,l]})},Po=(t,e,a,l)=>{t.$postOperations$.push({$operation$:Rs,$args$:[e,a,l]})},Rs=(t,e,a)=>{try{t[e]=a??"",a==null&&Gt(t)&&Qt(t)&&t.removeAttribute(e)}catch(l){Te(ba(6),{node:t,key:e,value:a},l)}},Tl=(t,e,a)=>a?t.createElementNS(Qe,e):t.createElement(e),be=(t,e,a,l)=>(t.$operations$.push({$operation$:La,$args$:[e,a,l||null]}),a),ko=(t,e,a,l)=>(t.$operations$.push({$operation$:So,$args$:[e,a,l||null]}),a),zs=(t,e,a)=>(t.$operations$.push({$operation$:Ie,$args$:[e,a]}),a),Lo=(t,e)=>{t.$containerState$.$styleIds$.add(e.styleId),t.$postOperations$.push({$operation$:Mo,$args$:[t.$containerState$,e]})},Mo=(t,e)=>{const a=t.$containerEl$,l=qe(a),r=l.documentElement===a,o=l.head,c=l.createElement("style");xt(c,wa,e.styleId),xt(c,"hidden",""),c.textContent=e.content,r&&o?Ie(o,c):La(a,c,a.firstChild)},Co=(t,e,a)=>{t.$operations$.push({$operation$:jo,$args$:[e,a]})},jo=(t,e)=>{La(t,e,t.firstChild)},Fs=(t,e)=>{Zt(e)&&_e(e,t,t.$containerState$.$subsManager$,!0),t.$operations$.push({$operation$:Io,$args$:[e,t]})},Io=t=>{const e=t.parentElement;e&&_o(e,t)},Gs=(t,e)=>{const a=Tl(t,"q:template",!1);return xt(a,ht,e),xt(a,"hidden",""),xt(a,"aria-hidden","true"),a},Eo=t=>{for(const e of t.$operations$)e.$operation$.apply(void 0,e.$args$);Bo(t)},Va=t=>Tt(t,"q:key"),Oo=(t,e)=>{e!==null&&xt(t,"q:key",e)},Bo=t=>{const e=t.$containerState$.$subsManager$;for(const a of t.$rmSlots$){const l=Va(a),r=ne(a,da);if(r.length>0){const o=a.getAttribute("q:sref"),c=t.$roots$.find(d=>d.$id$===o);if(c){const d=c.$element$;if(d.isConnected)if(ne(d,Ua).some(p=>Tt(p,ht)===l))_e(a,t,e,!1);else{const p=Gs(t.$doc$,l);for(const g of r)Ie(p,g);La(d,p,d.firstChild)}else _e(a,t,e,!1)}else _e(a,t,e,!1)}}for(const[a,l]of t.$addSlots$){const r=Va(a),o=ne(l,Ua).find(c=>c.getAttribute(ht)===r);o&&(ne(o,da).forEach(c=>{Ie(a,c)}),o.remove())}},On=()=>{},Ao=(t,e)=>{const a=t.createComment("qv "),l=t.createComment("/qv");return new Qs(a,l,e)},No=t=>{if(!t)return{};const e=t.split(" ");return Object.fromEntries(e.map(a=>{const l=a.indexOf("=");return l>=0?[a.slice(0,l),Go(a.slice(l+1))]:[a,""]}))},qo=t=>{const e=[];return Object.entries(t).forEach(([a,l])=>{e.push(l?`${a}=${Fo(l)}`:`${a}`)}),e.join(" ")},Ro=(t,e,a)=>t.ownerDocument.createTreeWalker(t,128,{acceptNode(l){const r=He(l);return r&&Tt(r,e)===a?1:2}}),zo=(t,e,a)=>{const l=Ro(t,e,a),r=[];let o=null;for(;o=l.nextNode();)r.push(He(o));return r},Fo=t=>t.replace(/ /g,"+"),Go=t=>t.replace(/\+/g," "),ce=":virtual";class Qs{constructor(e,a,l){this.open=e,this.close=a,this.isSvg=l,this._qc_=null,this.nodeType=111,this.localName=ce,this.nodeName=ce;const r=this.ownerDocument=e.ownerDocument;this.$template$=Tl(r,"template",!1),this.$attributes$=No(e.data.slice(3)),e.data.startsWith("qv "),e.__virtual=this,a.__virtual=this}insertBefore(e,a){const l=this.parentElement;return l?l.insertBefore(e,a||this.close):this.$template$.insertBefore(e,a),e}remove(){const e=this.parentElement;if(e){const a=this.childNodes;this.$template$.childElementCount,e.removeChild(this.open);for(let l=0;l<a.length;l++)this.$template$.appendChild(a[l]);e.removeChild(this.close)}}appendChild(e){return this.insertBefore(e,null)}insertBeforeTo(e,a){const l=this.childNodes;e.insertBefore(this.open,a);for(const r of l)e.insertBefore(r,a);e.insertBefore(this.close,a),this.$template$.childElementCount}appendTo(e){this.insertBeforeTo(e,null)}get namespaceURI(){var e;return((e=this.parentElement)==null?void 0:e.namespaceURI)??""}removeChild(e){this.parentElement?this.parentElement.removeChild(e):this.$template$.removeChild(e)}getAttribute(e){return this.$attributes$[e]??null}hasAttribute(e){return e in this.$attributes$}setAttribute(e,a){this.$attributes$[e]=a,this.open.data=Bn(this.$attributes$)}removeAttribute(e){delete this.$attributes$[e],this.open.data=Bn(this.$attributes$)}matches(e){return!1}compareDocumentPosition(e){return this.open.compareDocumentPosition(e)}closest(e){const a=this.parentElement;return a?a.closest(e):null}querySelectorAll(e){const a=[];return ne(this,Rr).forEach(l=>{Zt(l)&&(l.matches(e)&&a.push(l),a.concat(Array.from(l.querySelectorAll(e))))}),a}querySelector(e){for(const a of this.childNodes)if(Qt(a)){if(a.matches(e))return a;const l=a.querySelector(e);if(l!==null)return l}return null}get innerHTML(){return""}set innerHTML(e){const a=this.parentElement;a?(this.childNodes.forEach(l=>this.removeChild(l)),this.$template$.innerHTML=e,a.insertBefore(this.$template$.content,this.close)):this.$template$.innerHTML=e}get firstChild(){if(this.parentElement){const e=this.open.nextSibling;return e===this.close?null:e}return this.$template$.firstChild}get nextSibling(){return this.close.nextSibling}get previousSibling(){return this.open.previousSibling}get childNodes(){if(!this.parentElement)return Array.from(this.$template$.childNodes);const e=[];let a=this.open;for(;(a=a.nextSibling)&&a!==this.close;)e.push(a);return e}get isConnected(){return this.open.isConnected}get parentElement(){return this.open.parentElement}}const Bn=t=>`qv ${qo(t)}`,Dl=t=>{if(t==null)return null;if(Ae(t)){const e=He(t);if(e)return e}return t},Qo=t=>{let e=t,a=1;for(;e=e.nextSibling;)if(Ae(e)){const l=e.__virtual;if(l)e=l;else if(e.data.startsWith("qv "))a++;else if(e.data==="/qv"&&(a--,a===0))return e}},He=t=>{var a;const e=t.__virtual;if(e)return e;if(t.data.startsWith("qv ")){const l=Qo(t);return new Qs(t,l,((a=t.parentElement)==null?void 0:a.namespaceURI)===Qe)}return null},pa=t=>t==null?null:Mt(t)?t.open:t,mb=async t=>{const e={},a=Hs(e);let l;for(V(t,a,!1);(l=a.$promises$).length>0;)a.$promises$=[],await Promise.all(l);const r=Array.from(a.$objSet$.keys());let o=0;const c=new Map;for(const g of r)c.set(g,zt(o)),o++;if(a.$noSerialize$.length>0){const g=c.get(void 0);for(const h of a.$noSerialize$)c.set(h,g)}const d=g=>{let h="";if(rt(g)){const $=Ws(g);if(!$)throw lt(27,g);g=$.value,h+=$.resolved?"~":"_"}if(Ct(g)){const $=te(g);$&&(h+="!",g=$)}const v=c.get(g);if(v===void 0)throw lt(27,g);return v+h},p=Vs(r,d,null,a,e);return JSON.stringify({_entry:d(t),_objs:p})},Ho=async(t,e)=>{const a=qe(t),l=a.documentElement,r=Yn(t)?l:t;if(Tt(r,"q:container")==="paused")throw lt(21);const o=e??(r===a.documentElement?a.body:r),c=pe(r),d=Uo(r,tu);xt(r,"q:container","paused");for(const $ of d){const S=$.$element$,D=$.li;if($.$scopeIds$){const L=Ss($.$scopeIds$);L&&S.setAttribute("q:sstyle",L)}if($.$id$&&S.setAttribute("q:id",$.$id$),Qt(S)&&D.length>0){const L=rl(D);for(const T of L)S.setAttribute(T[0],Ll(T[1],$))}}const p=await Wo(d,c,$=>Gt($)&&tl($)?lu($,c):null),g=a.createElement("script");xt(g,"type","qwik/json"),g.textContent=Ko(JSON.stringify(p.state,void 0,void 0)),o.appendChild(g);const h=Array.from(c.$events$,$=>JSON.stringify($)),v=a.createElement("script");return v.textContent=`window.qwikevents||=[];window.qwikevents.push(${h.join(", ")})`,o.appendChild(v),p},Wo=async(t,e,a,l)=>{var P;const r=Hs(e);l==null||l.forEach((_,j)=>{r.$seen$.add(j)});let o=!1;for(const _ of t)if(_.$tasks$)for(const j of _.$tasks$)bs(j)&&r.$resources$.push(j.$state$),ys(j);for(const _ of t){const j=_.$element$,O=_.li;for(const k of O)if(Qt(j)){const M=k[1],q=M.$captureRef$;if(q)for(const U of q)V(U,r,!0);r.$qrls$.push(M),o=!0}}if(!o)return{state:{refs:{},ctx:{},objs:[],subs:[]},objs:[],funcs:[],qrls:[],resources:r.$resources$,mode:"static"};let c;for(;(c=r.$promises$).length>0;)r.$promises$=[],await Promise.all(c);const d=r.$elements$.length>0;if(d){for(const _ of r.$deferElements$)Pl(_,r,_.$element$);for(const _ of t)Vo(_,r)}for(;(c=r.$promises$).length>0;)r.$promises$=[],await Promise.all(c);const p=new Map,g=Array.from(r.$objSet$.keys()),h=new Map,v=_=>{let j="";if(rt(_)){const M=Ws(_);if(!M)return null;_=M.value,j+=M.resolved?"~":"_"}if(Ct(_)){const M=te(_);if(M)j+="!",_=M;else if(Zt(_)){const q=(U=>{let ut=p.get(U);return ut===void 0&&(ut=au(U),ut||console.warn("Missing ID",U),p.set(U,ut)),ut})(_);return q?"#"+q+j:null}}const O=h.get(_);if(O)return O+j;const k=l==null?void 0:l.get(_);return k?"*"+k:a?a(_):null},$=_=>{const j=v(_);if(j===null){if(ar(_)){const O=zt(h.size);return h.set(_,O),O}throw lt(27,_)}return j},S=new Map;for(const _ of g){const j=(P=eu(_,e))==null?void 0:P.$subs$;if(!j)continue;const O=er(_)??0,k=[];1&O&&k.push(O);for(const M of j){const q=M[1];M[0]===0&&Gt(q)&&Mt(q)&&!r.$elements$.includes(bt(q))||k.push(M)}k.length>0&&S.set(_,k)}g.sort((_,j)=>(S.has(_)?0:1)-(S.has(j)?0:1));let D=0;for(const _ of g)h.set(_,zt(D)),D++;if(r.$noSerialize$.length>0){const _=h.get(void 0);for(const j of r.$noSerialize$)h.set(j,_)}const L=[];for(const _ of g){const j=S.get(_);if(j==null)break;L.push(j.map(O=>typeof O=="number"?`_${O}`:Nu(O,v)).filter(Zn))}L.length,S.size;const T=Vs(g,$,v,r,e),y={},I={};for(const _ of t){const j=_.$element$,O=_.$id$,k=_.$refMap$,M=_.$props$,q=_.$contexts$,U=_.$tasks$,ut=_.$componentQrl$,it=_.$seq$,jt={},ae=Mt(j)&&r.$elements$.includes(_);if(k.length>0){const gt=Wt(k,$," ");gt&&(I[O]=gt)}else if(d){let gt=!1;if(ae){const nt=v(M);jt.h=$(ut)+(nt?" "+nt:""),gt=!0}else{const nt=v(M);nt&&(jt.h=" "+nt,gt=!0)}if(U&&U.length>0){const nt=Wt(U,v," ");nt&&(jt.w=nt,gt=!0)}if(ae&&it&&it.length>0){const nt=Wt(it,$," ");jt.s=nt,gt=!0}if(q){const nt=[];q.forEach((Br,Ar)=>{const yn=v(Br);yn&&nt.push(`${Ar}=${yn}`)});const me=nt.join(" ");me&&(jt.c=me,gt=!0)}gt&&(y[O]=jt)}}return{state:{refs:I,ctx:y,objs:T,subs:L},objs:g,funcs:r.$inlinedFunctions$,resources:r.$resources$,qrls:r.$qrls$,mode:d?"render":"listeners"}},Wt=(t,e,a)=>{let l="";for(const r of t){const o=e(r);o!==null&&(l!==""&&(l+=a),l+=o)}return l},Uo=(t,e)=>{const a=[],l=e(t);l!==void 0&&a.push(l);const r=t.ownerDocument.createTreeWalker(t,129,{acceptNode(o){if(Jo(o))return 2;const c=e(o);return c!==void 0&&a.push(c),3}});for(;r.nextNode(););return a},Vo=(t,e)=>{var r;const a=t.$parentCtx$,l=t.$props$;if(a&&l&&!Us(l)&&e.$elements$.includes(a)){const o=(r=dt(l))==null?void 0:r.$subs$,c=t.$element$;if(o)for(const[d,p]of o)d===0?(p!==c&&de(dt(l),e,!1),Gt(p)?Zo(p,e):V(p,e,!0)):(V(l,e,!1),de(dt(l),e,!1))}},Hs=t=>({$containerState$:t,$seen$:new Set,$objSet$:new Set,$prefetch$:0,$noSerialize$:[],$inlinedFunctions$:[],$resources$:[],$elements$:[],$qrls$:[],$deferElements$:[],$promises$:[]}),Yo=(t,e)=>{const a=bt(t);e.$elements$.includes(a)||(e.$elements$.push(a),e.$prefetch$++,8&a.$flags$?Pl(a,e,!0):e.$deferElements$.push(a),e.$prefetch$--)},Zo=(t,e)=>{const a=bt(t);if(a){if(e.$elements$.includes(a))return;e.$elements$.push(a),Pl(a,e,t)}},Pl=(t,e,a)=>{if(t.$props$&&!Us(t.$props$)&&(V(t.$props$,e,a),de(dt(t.$props$),e,a)),t.$componentQrl$&&V(t.$componentQrl$,e,a),t.$seq$)for(const l of t.$seq$)V(l,e,a);if(t.$tasks$){const l=e.$containerState$.$subsManager$.$groupToManagers$;for(const r of t.$tasks$)l.has(r)&&V(r,e,a)}if(a===!0&&(An(t,e),t.$dynamicSlots$))for(const l of t.$dynamicSlots$)An(l,e)},An=(t,e)=>{for(;t;){if(t.$contexts$)for(const a of t.$contexts$.values())V(a,e,!0);t=t.$parentCtx$}},Ko=t=>t.replace(/<(\/?script)/g,"\\x3C$1"),de=(t,e,a)=>{if(e.$seen$.has(t))return;e.$seen$.add(t);const l=t.$subs$;for(const r of l){const o=r[0];if(o>0&&V(r[2],e,a),a===!0){const c=r[1];Gt(c)&&Mt(c)?o===0&&Yo(c,e):V(c,e,!0)}}},Ya=Symbol(),Xo=t=>t.then(e=>(t[Ya]={resolved:!0,value:e},e),e=>(t[Ya]={resolved:!1,value:e},e)),Ws=t=>t[Ya],V=(t,e,a)=>{if(t!==null){const l=typeof t;switch(l){case"function":case"object":{const r=e.$seen$;if(r.has(t))return;if(r.add(t),Js(t))return e.$objSet$.add(void 0),void e.$noSerialize$.push(t);const o=t,c=te(t);if(c){const d=(2&er(t=c))==0;if(a&&d&&de(dt(o),e,a),tr(o))return void e.$objSet$.add(t)}if(Cu(t,e,a))return void e.$objSet$.add(t);if(rt(t))return void e.$promises$.push(Xo(t).then(d=>{V(d,e,a)}));if(l==="object"){if(Gt(t))return;if(tt(t))for(let d=0;d<t.length;d++)V(o[d],e,a);else if(Ne(t))for(const d in t)V(o[d],e,a)}break}case"string":if(e.$seen$.has(t))return}}e.$objSet$.add(t)},Jo=t=>Qt(t)&&t.hasAttribute("q:container"),tu=t=>{const e=Dl(t);if(Zt(e)){const a=bt(e);if(a&&a.$id$)return a}},eu=(t,e)=>{if(!Ct(t))return;if(t instanceof ke)return dt(t);const a=e.$proxyMap$.get(t);return a?dt(a):void 0},au=t=>{const e=bt(t);return e?e.$id$:null},lu=(t,e)=>{const a=t.previousSibling;if(a&&Ae(a)&&a.data.startsWith("t="))return"#"+a.data.slice(2);const l=t.ownerDocument,r=zt(e.$elementIndex$++),o=l.createComment(`t=${r}`),c=l.createComment(""),d=t.parentElement;return d.insertBefore(o,t),d.insertBefore(c,t.nextSibling),"#"+r},Us=t=>Object.keys(t).length===0;function Vs(t,e,a,l,r){return t.map(o=>{if(o===null)return null;const c=typeof o;switch(c){case"undefined":return Ca;case"number":if(!Number.isFinite(o))break;return o;case"string":if(o.charCodeAt(0)<32)break;return o;case"boolean":return o}const d=ju(o,e,l,r);if(d!==void 0)return d;if(c==="object"){if(tt(o))return o.map(e);if(Ne(o)){const p={};for(const g in o)if(a){const h=a(o[g]);h!==null&&(p[g]=h)}else p[g]=e(o[g]);return p}}throw lt(3,o)})}const f=(t,e,a=Pt)=>Ea(null,e,t,null,null,a,null),B=(t,e=Pt)=>Ea(null,t,null,null,null,e,null),kl=(t,e={})=>{let a=t.$symbol$,l=t.$chunk$;const r=t.$refSymbol$??a,o=va();if(o){const g=o.chunkForSymbol(r,l);g&&(l=g[1],t.$refSymbol$||(a=g[0]))}if(!l)throw lt(31,t.$symbol$);l.startsWith("./")&&(l=l.slice(2));let c=`${l}#${a}`;const d=t.$capture$,p=t.$captureRef$;return p&&p.length?e.$getObjId$?c+=`[${Wt(p,e.$getObjId$," ")}]`:e.$addRefMap$&&(c+=`[${Wt(p,e.$addRefMap$," ")}]`):d&&d.length>0&&(c+=`[${d.join(" ")}]`),c},Ll=(t,e)=>{e.$element$;const a={$addRefMap$:l=>nu(e.$refMap$,l)};return Wt(t,l=>kl(l,a),`
`)},Ma=(t,e)=>{const a=t.length,l=Nn(t,0,"#"),r=Nn(t,l,"["),o=Math.min(l,r),c=t.substring(0,o),d=l==a?l:l+1,p=d==r?"default":t.substring(d,r),g=r===a?Pt:t.substring(r+1,a-1).split(" "),h=Ea(c,p,null,null,g,null,null);return e&&h.$setContainer$(e),h},Nn=(t,e,a)=>{const l=t.length,r=t.indexOf(a,e==l?0:e);return r==-1?l:r},nu=(t,e)=>{const a=t.indexOf(e);return a===-1?(t.push(e),String(t.length-1)):String(a)},Ys=(t,e)=>(t.$capture$,t.$captureRef$=t.$capture$.map(a=>{const l=parseInt(a,10),r=e.$refMap$[l];return e.$refMap$.length>l,r})),hb=(t,e)=>(globalThis.__qwik_reg_symbols===void 0&&(globalThis.__qwik_reg_symbols=new Map),globalThis.__qwik_reg_symbols.set(e,t),t),su=t=>({__brand:"resource",value:void 0,loading:!Et(),_resolved:void 0,_error:void 0,_state:"pending",_timeout:(t==null?void 0:t.timeout)??-1,_cache:0}),ru=t=>Ct(t)&&t.__brand==="resource",iu=(t,e)=>{const a=t._state;return a==="resolved"?`0 ${e(t._resolved)}`:a==="pending"?"1":`2 ${e(t._error)}`},ou=t=>{const[e,a]=t.split(" "),l=su(void 0);return l.value=Promise.resolve(),e==="0"?(l._state="resolved",l._resolved=a,l.loading=!1):e==="1"?(l._state="pending",l.value=new Promise(()=>{}),l.loading=!0):e==="2"&&(l._state="rejected",l._error=a,l.loading=!1),l},st=t=>i(Vt,{"q:s":""},0,t.name??""),Ca="";function at(t){return{$prefixCode$:t.$prefix$.charCodeAt(0),$prefixChar$:t.$prefix$,$test$:t.$test$,$serialize$:t.$serialize$,$prepare$:t.$prepare$,$fill$:t.$fill$,$collect$:t.$collect$,$subs$:t.$subs$}}const uu=at({$prefix$:"",$test$:t=>ar(t),$collect$:(t,e,a)=>{if(t.$captureRef$)for(const l of t.$captureRef$)V(l,e,a);e.$prefetch$===0&&e.$qrls$.push(t)},$serialize$:(t,e)=>kl(t,{$getObjId$:e}),$prepare$:(t,e)=>Ma(t,e.$containerEl$),$fill$:(t,e)=>{t.$capture$&&t.$capture$.length>0&&(t.$captureRef$=t.$capture$.map(e),t.$capture$=null)}}),cu=at({$prefix$:"",$test$:t=>$l(t),$collect$:(t,e,a)=>{V(t.$qrl$,e,a),t.$state$&&(V(t.$state$,e,a),a===!0&&t.$state$ instanceof ke&&de(t.$state$[kt],e,!0))},$serialize$:(t,e)=>ji(t,e),$prepare$:t=>Ii(t),$fill$:(t,e)=>{t.$el$=e(t.$el$),t.$qrl$=e(t.$qrl$),t.$state$&&(t.$state$=e(t.$state$))}}),du=at({$prefix$:"",$test$:t=>ru(t),$collect$:(t,e,a)=>{V(t.value,e,a),V(t._resolved,e,a)},$serialize$:(t,e)=>iu(t,e),$prepare$:t=>ou(t),$fill$:(t,e)=>{if(t._state==="resolved")t._resolved=e(t._resolved),t.value=Promise.resolve(t._resolved);else if(t._state==="rejected"){const a=Promise.reject(t._error);a.catch(()=>null),t._error=e(t._error),t.value=a}}}),pu=at({$prefix$:"",$test$:t=>t instanceof URL,$serialize$:t=>t.href,$prepare$:t=>new URL(t),$fill$:void 0}),gu=at({$prefix$:"",$test$:t=>t instanceof Date,$serialize$:t=>t.toISOString(),$prepare$:t=>new Date(t),$fill$:void 0}),fu=at({$prefix$:"\x07",$test$:t=>t instanceof RegExp,$serialize$:t=>`${t.flags} ${t.source}`,$prepare$:t=>{const e=t.indexOf(" "),a=t.slice(e+1),l=t.slice(0,e);return new RegExp(a,l)},$fill$:void 0}),xu=at({$prefix$:"",$test$:t=>t instanceof Error,$serialize$:t=>t.message,$prepare$:t=>{const e=new Error(t);return e.stack=void 0,e},$fill$:void 0}),mu=at({$prefix$:"",$test$:t=>Yn(t),$serialize$:void 0,$prepare$:(t,e,a)=>a,$fill$:void 0}),ga=Symbol("serializable-data"),hu=at({$prefix$:"",$test$:t=>nr(t),$serialize$:(t,e)=>{const[a]=t[ga];return kl(a,{$getObjId$:e})},$prepare$:(t,e)=>{const a=Ma(t,e.$containerEl$);return m(a)},$fill$:(t,e)=>{const[a]=t[ga];a.$capture$&&a.$capture$.length>0&&(a.$captureRef$=a.$capture$.map(e),a.$capture$=null)}}),$u=at({$prefix$:"",$test$:t=>t instanceof Fa,$collect$:(t,e,a)=>{if(t.$args$)for(const l of t.$args$)V(l,e,a)},$serialize$:(t,e,a)=>{const l=ti(t);let r=a.$inlinedFunctions$.indexOf(l);return r<0&&(a.$inlinedFunctions$.push(l),r=a.$inlinedFunctions$.length-1),Wt(t.$args$,e," ")+" @"+zt(r)},$prepare$:t=>{const e=t.split(" "),a=e.slice(0,-1),l=e[e.length-1];return new Fa(l,a,l)},$fill$:(t,e)=>{t.$func$,t.$func$=e(t.$func$),t.$args$=t.$args$.map(e)}}),bu=at({$prefix$:"",$test$:t=>t instanceof ke,$collect$:(t,e,a)=>(V(t.untrackedValue,e,a),a===!0&&!(1&t[Pe])&&de(t[kt],e,!0),t),$serialize$:(t,e)=>e(t.untrackedValue),$prepare$:(t,e)=>{var a;return new ke(t,(a=e==null?void 0:e.$subsManager$)==null?void 0:a.$createManager$(),0)},$subs$:(t,e)=>{t[kt].$addSubs$(e)},$fill$:(t,e)=>{t.untrackedValue=e(t.untrackedValue)}}),vu=at({$prefix$:"",$test$:t=>t instanceof Ga,$collect$(t,e,a){if(V(t.ref,e,a),tr(t.ref)){const l=dt(t.ref);Eu(e.$containerState$.$subsManager$,l,a)&&V(t.ref[t.prop],e,a)}return t},$serialize$:(t,e)=>`${e(t.ref)} ${t.prop}`,$prepare$:t=>{const[e,a]=t.split(" ");return new Ga(e,a)},$fill$:(t,e)=>{t.ref=e(t.ref)}}),yu=at({$prefix$:"",$test$:t=>typeof t=="number",$serialize$:t=>String(t),$prepare$:t=>Number(t),$fill$:void 0}),wu=at({$prefix$:"",$test$:t=>t instanceof URLSearchParams,$serialize$:t=>t.toString(),$prepare$:t=>new URLSearchParams(t),$fill$:void 0}),_u=at({$prefix$:"",$test$:t=>typeof FormData<"u"&&t instanceof globalThis.FormData,$serialize$:t=>{const e=[];return t.forEach((a,l)=>{e.push(typeof a=="string"?[l,a]:[l,a.name])}),JSON.stringify(e)},$prepare$:t=>{const e=JSON.parse(t),a=new FormData;for(const[l,r]of e)a.append(l,r);return a},$fill$:void 0}),Su=at({$prefix$:"",$test$:t=>fe(t),$collect$:(t,e,a)=>{V(t.children,e,a),V(t.props,e,a),V(t.immutableProps,e,a);let l=t.type;l===st?l=":slot":l===H&&(l=":fragment"),V(l,e,a)},$serialize$:(t,e)=>{let a=t.type;return a===st?a=":slot":a===H&&(a=":fragment"),`${e(a)} ${e(t.props)} ${e(t.immutableProps)} ${e(t.children)} ${t.flags}`},$prepare$:t=>{const[e,a,l,r,o]=t.split(" ");return new Ge(e,a,l,r,parseInt(o,10))},$fill$:(t,e)=>{t.type=Ou(e(t.type)),t.props=e(t.props),t.immutableProps=e(t.immutableProps),t.children=e(t.children)}}),Tu=at({$prefix$:"",$test$:t=>typeof t=="bigint",$serialize$:t=>t.toString(),$prepare$:t=>BigInt(t),$fill$:void 0}),re=Symbol(),Du=at({$prefix$:"",$test$:t=>t instanceof Set,$collect$:(t,e,a)=>{t.forEach(l=>V(l,e,a))},$serialize$:(t,e)=>Array.from(t).map(e).join(" "),$prepare$:t=>{const e=new Set;return e[re]=t,e},$fill$:(t,e)=>{const a=t[re];t[re]=void 0;const l=a.length===0?[]:a.split(" ");for(const r of l)t.add(e(r))}}),Pu=at({$prefix$:"",$test$:t=>t instanceof Map,$collect$:(t,e,a)=>{t.forEach((l,r)=>{V(l,e,a),V(r,e,a)})},$serialize$:(t,e)=>{const a=[];return t.forEach((l,r)=>{a.push(e(r)+" "+e(l))}),a.join(" ")},$prepare$:t=>{const e=new Map;return e[re]=t,e},$fill$:(t,e)=>{const a=t[re];t[re]=void 0;const l=a.length===0?[]:a.split(" ");l.length%2;for(let r=0;r<l.length;r+=2)t.set(e(l[r]),e(l[r+1]))}}),ku=at({$prefix$:"\x1B",$test$:t=>!!Zs(t)||t===Ca,$serialize$:t=>t,$prepare$:t=>t,$fill$:void 0}),ja=[uu,cu,du,pu,gu,fu,xu,mu,hu,$u,bu,vu,yu,wu,_u,Su,Tu,Du,Pu,ku],qn=(()=>{const t=[];return ja.forEach(e=>{const a=e.$prefixCode$;for(;t.length<a;)t.push(void 0);t.push(e)}),t})();function Zs(t){if(typeof t=="string"){const e=t.charCodeAt(0);if(e<qn.length)return qn[e]}}const Lu=ja.filter(t=>t.$collect$),Mu=t=>{for(const e of ja)if(e.$test$(t))return!0;return!1},Cu=(t,e,a)=>{for(const l of Lu)if(l.$test$(t))return l.$collect$(t,e,a),!0;return!1},ju=(t,e,a,l)=>{for(const r of ja)if(r.$test$(t)){let o=r.$prefixChar$;return r.$serialize$&&(o+=r.$serialize$(t,e,a,l)),o}if(typeof t=="string")return t},Ks=(t,e)=>{const a=new Map,l=new Map;return{prepare(r){const o=Zs(r);if(o){const c=o.$prepare$(r.slice(1),t,e);return o.$fill$&&a.set(c,o),o.$subs$&&l.set(c,o),c}return r},subs(r,o){const c=l.get(r);return!!c&&(c.$subs$(r,o,t),!0)},fill(r,o){const c=a.get(r);return!!c&&(c.$fill$(r,o,t),!0)}}},Iu={"!":(t,e)=>e.$proxyMap$.get(t)??cl(t,e),"~":t=>Promise.resolve(t),_:t=>Promise.reject(t)},Eu=(t,e,a)=>{if(typeof a=="boolean")return a;const l=t.$groupToManagers$.get(a);return!!(l&&l.length>0)&&(l.length!==1||l[0]!==e)},Ou=t=>t===":slot"?st:t===":fragment"?H:t,$b=(t,e)=>Za(t,new Set,"_",e),Za=(t,e,a,l)=>{const r=We(t);if(r==null)return t;if(Bu(r)){if(e.has(r)||(e.add(r),Mu(r)))return t;const o=typeof r;switch(o){case"object":if(rt(r)||Gt(r))return t;if(tt(r)){let d=0;return r.forEach((p,g)=>{if(g!==d)throw lt(3,r);Za(p,e,a+"["+g+"]"),d=g+1}),t}if(Ne(r)){for(const[d,p]of Object.entries(r))Za(p,e,a+"."+d);return t}break;case"boolean":case"string":case"number":return t}let c="";if(c=l||"Value cannot be serialized",a!=="_"&&(c+=` in ${a},`),o==="object")c+=` because it's an instance of "${t==null?void 0:t.constructor.name}". You might need to use 'noSerialize()' or use an object literal instead. Check out https://qwik.builder.io/docs/advanced/dollar/`;else if(o==="function"){const d=t.name;c+=` because it's a function named "${d}". You might need to convert it to a QRL using $(fn):

const ${d} = $(${String(t)});

Please check out https://qwik.builder.io/docs/advanced/qrl/ for more information.`}console.error("Trying to serialize",t),zr(c)}return t},Ml=new WeakSet,Xs=new WeakSet,Bu=t=>!Ct(t)&&!mt(t)||!Ml.has(t),Js=t=>Ml.has(t),tr=t=>Xs.has(t),Ia=t=>(t!=null&&Ml.add(t),t),Au=t=>(Xs.add(t),t),We=t=>Ct(t)?te(t)??t:t,te=t=>t[qa],dt=t=>t[kt],er=t=>t[le],Nu=(t,e)=>{const a=t[0],l=typeof t[1]=="string"?t[1]:e(t[1]);if(!l)return;let r=a+" "+l,o;if(a===0)o=t[2];else{const c=e(t[2]);if(!c)return;a<=2?(o=t[5],r+=` ${c} ${Rn(e(t[3]))} ${t[4]}`):a<=4&&(o=t[4],r+=` ${c} ${typeof t[3]=="string"?t[3]:Rn(e(t[3]))}`)}return o&&(r+=` ${encodeURI(o)}`),r},qu=(t,e)=>{const a=t.split(" "),l=parseInt(a[0],10);a.length>=2;const r=e(a[1]);if(!r||$l(r)&&!r.$el$)return;const o=[l,r];return l===0?(a.length<=3,o.push(Na(a[2]))):l<=2?(a.length===5||a.length,o.push(e(a[2]),e(a[3]),a[4],Na(a[5]))):l<=4&&(a.length===4||a.length,o.push(e(a[2]),e(a[3]),Na(a[4]))),o},Na=t=>{if(t!==void 0)return decodeURI(t)},Ru=t=>{const e=new Map;return{$groupToManagers$:e,$createManager$:l=>new zu(e,t,l),$clearSub$:l=>{const r=e.get(l);if(r){for(const o of r)o.$unsubGroup$(l);e.delete(l),r.length=0}},$clearSignal$:l=>{const r=e.get(l[1]);if(r)for(const o of r)o.$unsubEntry$(l)}}};class zu{constructor(e,a,l){this.$groupToManagers$=e,this.$containerState$=a,this.$subs$=[],l&&this.$addSubs$(l)}$addSubs$(e){this.$subs$.push(...e);for(const a of this.$subs$)this.$addToGroup$(a[1],this)}$addToGroup$(e,a){let l=this.$groupToManagers$.get(e);l||this.$groupToManagers$.set(e,l=[]),l.includes(a)||l.push(a)}$unsubGroup$(e){const a=this.$subs$;for(let l=0;l<a.length;l++)a[l][1]===e&&(a.splice(l,1),l--)}$unsubEntry$(e){const[a,l,r,o]=e,c=this.$subs$;if(a===1||a===2){const d=e[4];for(let p=0;p<c.length;p++){const g=c[p];g[0]===a&&g[1]===l&&g[2]===r&&g[3]===o&&g[4]===d&&(c.splice(p,1),p--)}}else if(a===3||a===4)for(let d=0;d<c.length;d++){const p=c[d];p[0]===a&&p[1]===l&&p[2]===r&&p[3]===o&&(c.splice(d,1),d--)}}$addSub$(e,a){const l=this.$subs$,r=e[1];e[0]===0&&l.some(([o,c,d])=>o===0&&c===r&&d===a)||(l.push([...e,a]),this.$addToGroup$(r,this))}$notifySubs$(e){const a=this.$subs$;for(const l of a){const r=l[l.length-1];e&&r&&r!==e||yi(l,this.$containerState$)}}}const Rn=t=>{if(t==null)throw Te("must be non null",t);return t},ar=t=>typeof t=="function"&&typeof t.getSymbol=="function",Ea=(t,e,a,l,r,o,c)=>{let d;const p=async function(...T){return await $.call(this,wt())(...T)},g=T=>(d||(d=T),d),h=async T=>{if(T&&g(T),a!==null)return a;if(l!==null)return a=l().then(y=>p.resolved=a=y[e]);{const y=va().importSymbol(d,t,e);return a=K(y,I=>p.resolved=a=I)}},v=T=>a!==null?a:h(T);function $(T,y){return(...I)=>{const P=Qu(),_=v();return K(_,j=>{if(mt(j)){if(y&&y()===!1)return;const O={...S(T),$qrl$:p};return O.$event$===void 0&&(O.$event$=this),Fu(e,O.$element$,P),pt.call(this,O,j,...I)}throw lt(10)})}}const S=T=>T==null?_t():tt(T)?_s(T):T,D=c??e,L=lr(D);return Object.assign(p,{getSymbol:()=>D,getHash:()=>L,getCaptured:()=>o,resolve:h,$resolveLazy$:v,$setContainer$:g,$chunk$:t,$symbol$:e,$refSymbol$:c,$hash$:L,getFn:$,$capture$:r,$captureRef$:o,dev:null,resolved:void 0}),p},lr=t=>{const e=t.lastIndexOf("_");return e>-1?t.slice(e+1):t};const zn=new Set,Fu=(t,e,a)=>{zn.has(t)||(zn.add(t),Gu("qsymbol",{symbol:t,element:e,reqTime:a}))},Gu=(t,e)=>{Et()||typeof document!="object"||document.dispatchEvent(new CustomEvent(t,{bubbles:!1,detail:e}))},Qu=()=>Et()?0:typeof performance=="object"?performance.now():0,Fn=t=>t,m=t=>{function e(a,l,r){const o=t.$hash$.slice(0,4);return i(Vt,{"q:renderFn":t,[ht]:a[ht],[s]:a[s],children:a.children,props:a},r,o+":"+(l||""))}return e[ga]=[t],e},nr=t=>typeof t=="function"&&t[ga]!==void 0,ve=(t,e)=>{const{val:a,set:l,iCtx:r}=Xt();if(a!=null)return a;const o=mt(t)?pt(void 0,t):t;if((e==null?void 0:e.reactive)===!1)return l(o),o;{const c=cl(o,r.$renderCtx$.$static$.$containerState$,(e==null?void 0:e.deep)??!0?1:0);return l(c),c}};function Cl(t,e){var l;const a=wt();return((l=a==null?void 0:a.$renderCtx$)==null?void 0:l.$static$.$containerState$.$serverData$[t])??e}const Hu=t=>{Wu(t,e=>e,!1)},Wu=(t,e,a)=>{const{val:l,set:r,iCtx:o,i:c,elCtx:d}=Xt();if(l)return l;const p=Hi(t,c),g=o.$renderCtx$.$static$.$containerState$;if(r(p),d.$appendStyles$||(d.$appendStyles$=[]),d.$scopeIds$||(d.$scopeIds$=[]),a&&d.$scopeIds$.push(Wi(p)),g.$styleIds$.has(p))return p;g.$styleIds$.add(p);const h=t.$resolveLazy$(g.$containerEl$),v=$=>{d.$appendStyles$,d.$appendStyles$.push({styleId:p,content:e($,p)})};return rt(h)?o.$waitOn$.push(h.then(v)):v(h),p},W=t=>{const{val:e,set:a,iCtx:l}=Xt();if(e!=null)return e;const r=l.$renderCtx$.$static$.$containerState$,o=mt(t)&&!nr(t)?pt(void 0,t):t;return a(ei(o,r,0,void 0))},Gn={defaultLocale:{lang:"en",currency:"USD",timeZone:"America/Los_Angeles"},supportedLocales:[{lang:"en",currency:"USD",timeZone:"America/Los_Angeles"},{lang:"es",currency:"USD",timeZone:"America/Los_Angeles"}],assets:["app"]},Uu=({params:t,locale:e})=>{const a=Gn.supportedLocales.find(r=>r.lang===t.lang);console.log(t);const l=a?a.lang:!t.lang&&Gn.defaultLocale.lang;l&&e(l)},Vu=Object.freeze(Object.defineProperty({__proto__:null,onRequest:Uu},Symbol.toStringTag,{value:"Module"})),Yu='((i,a,r,s)=>{r=e=>{const t=document.querySelector("[q\\\\:base]");t&&a.active&&a.active.postMessage({type:"qprefetch",base:t.getAttribute("q:base"),...e})},document.addEventListener("qprefetch",e=>{const t=e.detail;a?r(t):i.push(t)}),navigator.serviceWorker.register("/service-worker.js").then(e=>{s=()=>{a=e,i.forEach(r),r({bundles:i})},e.installing?e.installing.addEventListener("statechange",t=>{t.target.state=="activated"&&s()}):e.active&&s()}).catch(e=>console.error(e))})([])',sr=Nt("qc-s"),Zu=Nt("qc-c"),rr=Nt("qc-ic"),ir=Nt("qc-h"),or=Nt("qc-l"),ur=Nt("qc-n"),cr=Nt("qc-a"),Ku=Nt("qc-ir"),Xu=t=>{const e=window,a=location.pathname+location.search,l="_qCitySPA",r="_qCityHistoryPatch",o="_qCityBootstrap",c="_qCityInitPopstate",d="_qCityInitAnchors",p="_qCityInitVisibility",g="_qCityInitScroll",h="_qCityScrollEnabled",v="_qCityScrollDebounce",$="_qCityScroll",S=T=>{T&&e.scrollTo(T.x,T.y)},D=()=>{const T=document.documentElement;return{x:T.scrollLeft,y:T.scrollTop,w:Math.max(T.scrollWidth,T.clientWidth),h:Math.max(T.scrollHeight,T.clientHeight)}},L=T=>{const y=history.state||{};y[$]=T||D(),history.replaceState(y,"")};if(!e[l]&&!e[c]&&!e[d]&&!e[p]&&!e[g]){if(L(),e[c]=()=>{var T;if(!e[l]){if(e[h]=!1,clearTimeout(e[v]),a!==location.pathname+location.search){const I=t.closest("[q\\:container]").querySelector('a[q\\:key="AD_1"]');if(I){const P=I.closest("[q\\:container]"),_=I.cloneNode();_.setAttribute("q:nbs",""),_.style.display="none",P.appendChild(_),e[o]=_,_.click()}else location.reload()}else if(history.scrollRestoration==="manual"){const y=(T=history.state)==null?void 0:T[$];S(y),e[h]=!0}}},!e[r]){e[r]=!0;const T=history.pushState,y=history.replaceState,I=P=>(P===null||typeof P>"u"?P={}:(P==null?void 0:P.constructor)!==Object&&(P={_data:P}),P._qCityScroll=P._qCityScroll||D(),P);history.pushState=(P,_,j)=>(P=I(P),T.call(history,P,_,j)),history.replaceState=(P,_,j)=>(P=I(P),y.call(history,P,_,j))}e[d]=T=>{if(e[l]||T.defaultPrevented)return;const y=T.target.closest("a[href]");if(y&&!y.hasAttribute("preventdefault:click")){const I=y.getAttribute("href"),P=new URL(location.href),_=new URL(I,P),j=_.origin===P.origin,O=_.pathname+_.search===P.pathname+P.search;if(j&&O)if(T.preventDefault(),_.href!==P.href&&history.pushState(null,"",_),!_.hash)_.href.endsWith("#")?window.scrollTo(0,0):(e[h]=!1,clearTimeout(e[v]),L({...D(),x:0,y:0}),location.reload());else{const k=_.hash.slice(1),M=document.getElementById(k);M&&M.scrollIntoView()}}},e[p]=()=>{!e[l]&&e[h]&&document.visibilityState==="hidden"&&L()},e[g]=()=>{e[l]||!e[h]||(clearTimeout(e[v]),e[v]=setTimeout(()=>{L(),e[v]=void 0},200))},e[h]=!0,setTimeout(()=>{addEventListener("popstate",e[c]),addEventListener("scroll",e[g],{passive:!0}),document.body.addEventListener("click",e[d]),e.navigation||document.addEventListener("visibilitychange",e[p],{passive:!0})},0)}},Ju=f(Xu,"s_DyVc0YBIqQU"),tc=()=>{{const[t,e]=va().chunkForSymbol(Ju.getSymbol(),null),a=Or+"build/"+e;return`(${ec.toString()})('${a}','${t}');`}},ec=async(t,e)=>{var a;if(!window._qcs&&history.scrollRestoration==="manual"){window._qcs=!0;const l=(a=history.state)==null?void 0:a._qCityScroll;l&&window.scrollTo(l.x,l.y);const r=document.currentScript;(await import(t))[e](r)}},ac=()=>{const t=tc();Z();const e=Cl("nonce"),a=ge(rr);if(a.value&&a.value.length>0){const l=a.value.length;let r=null;for(let o=l-1;o>=0;o--)a.value[o].default&&(r=i(a.value[o].default,{children:r},1,"zl_0"));return i(H,{children:[r,n("script",{dangerouslySetInnerHTML:t},{nonce:e},null,3,null)]},1,"zl_1")}return dl},bb=m(f(ac,"s_e0ssiDXoeAM")),lc="qaction",Qn=t=>t.pathname+t.search+t.hash,ie=(t,e)=>new URL(t,e.href),dr=(t,e)=>t.origin===e.origin,nc=(t,e)=>t.pathname+t.search===e.pathname+e.search,sc=(t,e)=>t.pathname===e.pathname,rc=(t,e)=>t.search===e.search,ic=(t,e)=>{const a=t.href;if(typeof a=="string"&&typeof t.target!="string"&&!t.reload)try{const l=ie(a.trim(),e.url),r=ie("",e.url);if(dr(l,r))return Qn(l)}catch(l){console.error(l)}else if(t.reload)return Qn(ie("",e.url));return null},oc=(t,e,a)=>{if(t.prefetch===!0&&e){const l=ie(e,a.url),r=ie("",a.url);if(!sc(l,r)||!rc(l,r))return""}return null},uc=t=>t&&typeof t.then=="function",cc=(t,e,a,l)=>{const r=pr(),c={head:r,withLocale:d=>Pn(l,d),resolveValue:d=>{const p=d.__id;if(d.__brand==="server_loader"&&!(p in t.loaders))throw new Error("You can not get the returned data of a loader that has not been executed for this request.");const g=t.loaders[p];if(uc(g))throw new Error("Loaders returning a function can not be referred to in the head function.");return g},...e};for(let d=a.length-1;d>=0;d--){const p=a[d]&&a[d].head;p&&(typeof p=="function"?Hn(r,Pn(l,()=>p(c))):typeof p=="object"&&Hn(r,p))}return c.head},Hn=(t,e)=>{typeof e.title=="string"&&(t.title=e.title),Ye(t.meta,e.meta),Ye(t.links,e.links),Ye(t.styles,e.styles),Ye(t.scripts,e.scripts),Object.assign(t.frontmatter,e.frontmatter)},Ye=(t,e)=>{if(Array.isArray(e))for(const a of e){if(typeof a.key=="string"){const l=t.findIndex(r=>r.key===a.key);if(l>-1){t[l]=a;continue}}t.push(a)}},pr=()=>({title:"",meta:[],links:[],styles:[],scripts:[],frontmatter:{}});let Wn;(function(t){t[t.EOL=0]="EOL",t[t.OPEN_BRACKET=91]="OPEN_BRACKET",t[t.CLOSE_BRACKET=93]="CLOSE_BRACKET",t[t.DOT=46]="DOT",t[t.SLASH=47]="SLASH"})(Wn||(Wn={}));const vb=()=>ge(ir),Ht=()=>ge(or),gr=()=>ge(ur),dc=()=>ge(cr),fr=()=>Ia(Cl("qwikcity")),pc=":root{view-transition-name:none}",gc=async(t,e)=>{const[a,l,r,o]=et(),{type:c="link",forceReload:d=t===void 0,replaceState:p=!1,scroll:g=!0}=typeof e=="object"?e:{forceReload:e},h=r.value.dest,v=t===void 0?h:ie(t,o.url);if(dr(v,h)&&!(!d&&nc(v,h)))return r.value={type:c,dest:v,forceReload:d,replaceState:p,scroll:g},a.value=void 0,o.isNavigating=!0,new Promise($=>{l.r=$})},fc=({track:t})=>{const[e,a,l,r,o,c,d,p,g,h,v]=et();async function $(){const[D,L]=t(()=>[h.value,e.value]),T=Ni(""),y=v.url,I=L?"form":D.type;D.replaceState;let P,_,j=null;if(P=new URL(D.dest,v.url),j=o.loadedRoute,_=o.response,j){const[O,k,M,q]=j,U=M,ut=U[U.length-1];v.prevUrl=y,v.url=P,v.params={...k},h.untrackedValue={type:I,dest:P};const it=cc(_,v,U,T);a.headings=ut.headings,a.menu=q,l.value=Ia(U),r.links=it.links,r.meta=it.meta,r.styles=it.styles,r.scripts=it.scripts,r.title=it.title,r.frontmatter=it.frontmatter}}return $()},xc=t=>{Hu(f(pc,"s_RPDJAz33WLA"));const e=fr();if(!(e!=null&&e.params))throw new Error("Missing Qwik City Env Data");const a=Cl("url");if(!a)throw new Error("Missing Qwik URL Env Data");const l=new URL(a),r=ve({url:l,params:e.params,isNavigating:!1,prevUrl:void 0},{deep:!1}),o={},c=Au(ve(e.response.loaders,{deep:!1})),d=W({type:"initial",dest:l,forceReload:!1,replaceState:!1,scroll:!0}),p=ve(pr),g=ve({headings:void 0,menu:void 0}),h=W(),v=e.response.action,$=v?e.response.loaders[v]:void 0,S=W($?{id:v,data:e.response.formData,output:{result:$,status:e.response.status}}:void 0),D=f(gc,"s_fX0bDjeJa0E",[S,o,d,r]);return Rt(Zu,g),Rt(rr,h),Rt(ir,p),Rt(or,r),Rt(ur,D),Rt(sr,c),Rt(cr,S),Rt(Ku,d),$s(f(fc,"s_02wMImzEAbk",[S,g,h,p,e,D,c,o,t,d,r])),i(st,null,3,"qY_0")},yb=m(f(xc,"s_TxCFOy819ag")),mc=t=>{const e=gr(),a=Ht(),{onClick$:l,reload:r,replaceState:o,scroll:c,...d}=(()=>t)(),p=na(()=>ic({...d,reload:r},a)),g=na(()=>oc(t,p,a));d["preventdefault:click"]=!!p,d.href=p||t.href;const h=g!=null?Fn(B("s_eBQ0vFsFKsk")):void 0,v=Fn(B("s_i1Cv0pYJNR0",[e,r,o,c]));return Y("a",{...d,children:i(st,null,3,"AD_0"),"data-prefetch":g,onClick$:[l,v],onFocus$:h,onMouseOver$:h,onQVisible$:h},null,0,"AD_1")},Se=m(f(mc,"s_8gdLBszqbaM")),wb=t=>n("script",{nonce:w(t,"nonce")},{dangerouslySetInnerHTML:Yu},null,3,"1Z_0"),hc=(t={})=>{throw et(),new Error(`Actions can not be invoked within the server during SSR.
Action.run() can only be called on the browser, for example when a user clicks a button, or submits a form.`)},$c=(t,...e)=>{const{id:a,validators:l}=mr(e,t);function r(){const o=Ht(),c=dc(),d={actionPath:`?${lc}=${a}`,isRunning:!1,status:void 0,value:void 0,formData:void 0},p=ve(()=>{const h=c.value;if(h&&(h==null?void 0:h.id)===a){const v=h.data;if(v instanceof FormData&&(d.formData=v),h.output){const{status:$,result:S}=h.output;d.status=$,d.value=S}}return d}),g=f(hc,"s_A5bZC7WO00A",[c,a,o,p]);return d.submit=g,p}return r.__brand="server_action",r.__validators=l,r.__qrl=t,r.__id=a,Object.freeze(r),r},xr=(t,...e)=>{const a=$c(t,...e);return typeof globalThis._qwikActionsMap>"u"&&(globalThis._qwikActionsMap=new Map),globalThis._qwikActionsMap.set(a.__id,a),a},N=(t,...e)=>{const{id:a,validators:l}=mr(e,t);function r(){return ge(sr,o=>{if(!(a in o))throw new Error(`routeLoader$ "${t.getSymbol()}" was invoked in a route where it was not declared.
    This is because the routeLoader$ was not exported in a 'layout.tsx' or 'index.tsx' file of the existing route.
    For more information check: https://qwik.builder.io/qwikcity/route-loader/`);return w(o,a)})}return r.__brand="server_loader",r.__qrl=t,r.__validators=l,r.__id=a,Object.freeze(r),r},bc=async function(...t){var a;const[e]=et();t.length>0&&t[0]instanceof AbortSignal&&t.shift();{const l=[(a=fr())==null?void 0:a.ev,this,Gi()].find(r=>r&&Object.prototype.hasOwnProperty.call(r,"sharedMap")&&Object.prototype.hasOwnProperty.call(r,"cookie"));return e.apply(l,t)}},_b=t=>{{const a=t.getCaptured();if(a&&a.length>0&&!Fi())throw new Error("For security reasons, we cannot serialize QRLs that capture lexical scope.")}function e(){return f(bc,"s_wOIPfiQ04l4",[t])}return e()},mr=(t,e)=>{let a;const l=[];if(t.length===1){const r=t[0];r&&typeof r=="object"&&("validate"in r?l.push(r):(a=r.id,r.validation&&l.push(...r.validation)))}else t.length>1&&l.push(...t.filter(r=>!!r));return typeof a=="string"?a=`id_${a}`:a=e.getHash(),{validators:l.reverse(),id:a}},vc=({action:t,spaReset:e,reloadDocument:a,onSubmit$:l,...r},o)=>(Z(),t?Y("form",{...r,action:w(t,"actionPath"),"preventdefault:submit":!a,"data-spa-reset":e?"true":void 0,onSubmit$:[a?void 0:t.submit,l]},{method:"post"},0,o):i(_c,{onSubmit$:l,reloadDocument:a,spaReset:e,...r},0,o)),yc=async(t,e)=>{const[a]=et(),l=new FormData(e),r=new URLSearchParams;l.forEach((o,c)=>{typeof o=="string"&&r.append(c,o)}),a("?"+r.toString(),{type:"form",forceReload:!0}).then(()=>{e.getAttribute("data-spa-reset")==="true"&&e.reset(),e.dispatchEvent(new CustomEvent("submitcompleted",{bubbles:!1,cancelable:!1,composed:!1,detail:{status:200}}))})},wc=t=>{const e=ai(t,["action","spaReset","reloadDocument","onSubmit$"]),a=gr();return Y("form",{...e,children:i(st,null,3,"BC_0"),onSubmit$:f(yc,"s_p9MSze0ojs4",[a])},{action:"get","data-spa-reset":u(l=>l.spaReset?"true":void 0,[t],'p0.spaReset?"true":undefined'),"preventdefault:submit":u(l=>!l.reloadDocument,[t],"!p0.reloadDocument")},0,"BC_1")},_c=m(f(wc,"s_Nk9PlpjQm9Y")),Sc=t=>n("div",null,{class:"w-fit h-fit flex items-center justify-center",role:"status"},n("svg",null,{"aria-hidden":"true",class:u(e=>`w-[${e.size}] h-[${e.size}] text-gray-200 animate-spin dark:text-blue-300 fill-primary-blue`,[t],"`w-[${p0.size}] h-[${p0.size}] text-gray-200 animate-spin dark:text-blue-300 fill-primary-blue`"),fill:"none",viewBox:"0 0 100 101",xmlns:"http://www.w3.org/2000/svg"},[n("path",null,{d:"M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",fill:"currentColor"},null,3,null),n("path",null,{d:"M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",fill:"currentFill"},null,3,null)],3,null),3,"73_0"),Yt=m(f(Sc,"s_kpSoQCQrots")),Tc=()=>n("div",null,{class:"flex absolute flex-col items-center justify-center m-auto gap-2 h-full w-full bg-gradient-radial from-white via-slate-200 to-slate-300"},[n("img",null,{alt:"RTA image loading",height:200,src:"https://strapi.rtatel.com/uploads/RTA_db22afd96e.webp",width:250},null,3,null),i(Yt,{size:"150px",[s]:{size:s}},3,"yL_0")],1,"yL_1"),Dc=m(f(Tc,"s_BeMhGs9mjvk")),Pc=async({cacheControl:t})=>{t({staleWhileRevalidate:604800,maxAge:5})},kc=()=>({date:new Date().toISOString()}),Lc=N(f(kc,"s_GQamrjryd1Y")),Mc=()=>{const[t]=et();t.value=!0},Cc=()=>{Z();const t=W(!0);return $s(f(Mc,"s_lROQwus8zWc",[t])),Jt(B("s_Ku7AU0gi0Go",[t])),i(H,{children:t.value?n("div",null,{class:"h-full w-full flex",id:"splash"},i(Dc,null,3,"XF_0"),1,"XF_1"):i(st,null,3,"XF_2")},1,"XF_3")},jc=m(f(Cc,"s_VkLNXphUh5s")),Ic=Object.freeze(Object.defineProperty({__proto__:null,default:jc,onGet:Pc,useServerTimeLoader:Lc},Symbol.toStringTag,{value:"Module"})),Ec=()=>{const t=["https://images.unsplash.com/photo-1693825948507-acd866203fae?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8MXx8fGVufDB8fHx8fA%3D%3D","https://images.unsplash.com/photo-1694476053120-d729a3f6a7ed?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8fA%3D%3D","https://images.unsplash.com/photo-1695256294687-5df561945542?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8MTB8fHxlbnwwfHx8fHw%3D"],e=W(0);return Jt(B("s_aXdoh0xz8cQ",[t,e])),n("div",null,null,n("img",{src:t[e.value]},{alt:"Slider",class:"transition-opacity duration-2000 ease-in-out opacity-100",height:150,width:150},null,3,null),1,"Sz_0")},Oc=m(f(Ec,"s_X6NIVA8H4IM")),Bc=()=>i(H,{children:i(Oc,null,3,"Ch_0")},1,"Ch_1"),Ac=m(f(Bc,"s_nUdxvD3SCSo")),Nc=Object.freeze(Object.defineProperty({__proto__:null,default:Ac},Symbol.toStringTag,{value:"Module"})),qc=async t=>{const e=await t.parseBody(),a="https://api.emailjs.com/api/v1.0/email/send/";console.log(e);const r={...{service_id:"service_3c06k96",user_id:"IYZz-W8oLRewKg_p0",accessToken:"6I-rPRtBvWRubnBm_GLdd"},template_id:e.template_id,template_params:e},o=await fetch(a,{method:"POST",body:JSON.stringify(r),headers:{"Content-Type":"application/json"}});t.json(200,{resp:await o.text()})},Rc=Object.freeze(Object.defineProperty({__proto__:null,onPost:qc},Symbol.toStringTag,{value:"Module"})),zc=async(t,e,a)=>{const r=await fetch(`https://autosuggest.search.hereapi.com/v1/autosuggest?apiKey=-plDP_dR7XAGxBSiHgTFyxkxNdjFFHqjQK9ge8b92CE&q=${t}&at=${e},${a}&in=countryCode:USA&types=street`);return r.status!==200?[]:(await r.json()).items.map(d=>({address:d.title,zip:d.title.split(", ")[2].split(" ")[1]}))},Fc=async({json:t,query:e})=>{const a=e.get("q");if(!a)t(400,{message:"Bad request (need ?q param)"});else{const l=await zc(a,29.62540053919014,-95.39478748016545);t(200,{data:l})}},Gc=Object.freeze(Object.defineProperty({__proto__:null,onGet:Fc},Symbol.toStringTag,{value:"Module"})),hr="https://strapi.rtatel.com",Qc="http://10.5.24.41:1337",Hc=`${Qc}/graphql`,G=t=>`${hr}${t}`,fa=t=>t==="es"?"es-419":t,b=`
data {
    attributes {
        url
        alternativeText
        caption
    }
}
`,Q=t=>{let e=[];return t.schema&&(e=t.schema.split('<script type="application/ld+json">').flatMap(a=>a.split("<script type='application/ld+json'>")).flatMap(a=>a.replace("<\/script>",""))),{title:t.MetaTitle,scripts:[...e.map(a=>({props:{type:"application/ld+json"},script:a}))],meta:[{name:"description",content:t.MetaDescription},{name:"robots",content:t.preventIndexing?"noindex":"index"},{name:"keywords",content:t.Keywords}]}},F=`
SEO {
    MetaTitle
    MetaDescription
    Keywords
    preventIndexing
    schema
}
`,Ue=`
data{
      attributes{
       	Content{
          Titles{
            Text
          }
          TextContent
        }
`,$r=`
MembersGrid{
           Picture{
         ${b}
        }
        FirstName
        LastName
        Position
        SocialMedia{
          Icon{
            ${b}
          }
          Link
        }
      }
`,Wc=t=>`
sectionNetwork (locale:"${t}"){
  data {
    attributes {
      Map {
        MapPicture {
          data {
            attributes {
              url
            }
          }
        }
        ServersTitle
        Servers {
          Text
          Link
          Icon{
            data{
              attributes{
                url
              }
            }
          }
        }
      }
      Description{
        Title
        Paragraph
      }
    }
  }
}
`,Uc=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],Vc=["January","February","March","April","May","June","July","August","September","October","November","December"];function Xe(t,e=!0){const a=new Date(t),l=Uc[a.getDay()],r=a.getDate(),o=Vc[a.getMonth()],c=a.getFullYear();return`${e?l+", ":""}${e?o:o.slice(0,3)} ${r}, ${c}`}const Yc=t=>n("img",{src:`${hr}${t.url}`},{alt:u(e=>e.alt??"",[t],'p0.alt??""'),class:u(e=>(e.toWhite??!1?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(e.clasN??""),[t],'(p0.toWhite??false?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(p0.clasN??"")'),height:u(e=>e.height??300,[t],"p0.height??300"),title:u(e=>e.title??"",[t],'p0.title??""'),width:u(e=>e.width??300,[t],"p0.width??300")},null,3,"cI_0"),E=m(f(Yc,"s_LQFPgtOeNdI")),Zc=t=>Y("svg",{...t,children:n("path",null,{d:"M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"xG_0"),Kc=t=>Y("svg",{...t,children:n("path",null,{d:"M201.4 342.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 274.7 86.6 137.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"xH_0"),Xc=t=>Y("svg",{...t,children:n("path",null,{d:"M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"GB_0"),Jc=t=>Y("svg",{...t,children:n("path",null,{d:"M96 32V64H48C21.5 64 0 85.5 0 112v48H448V112c0-26.5-21.5-48-48-48H352V32c0-17.7-14.3-32-32-32s-32 14.3-32 32V64H160V32c0-17.7-14.3-32-32-32S96 14.3 96 32zM448 192H0V464c0 26.5 21.5 48 48 48H400c26.5 0 48-21.5 48-48V192z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"nO_0"),td=t=>Y("svg",{...t,children:n("path",null,{d:"M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"p8_0"),ed=t=>Y("svg",{...t,children:n("path",null,{d:"M0 256a256 256 0 1 0 512 0A256 256 0 1 0 0 256zM281 385c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l71-71L136 280c-13.3 0-24-10.7-24-24s10.7-24 24-24l182.1 0-71-71c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0L393 239c9.4 9.4 9.4 24.6 0 33.9L281 385z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 512 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"tx_0"),ad=t=>Y("svg",{...t,children:n("path",null,{d:"M256 448c141.4 0 256-93.1 256-208S397.4 32 256 32S0 125.1 0 240c0 45.1 17.7 86.8 47.7 120.9c-1.9 24.5-11.4 46.3-21.4 62.9c-5.5 9.2-11.1 16.6-15.2 21.6c-2.1 2.5-3.7 4.4-4.9 5.7c-.6 .6-1 1.1-1.3 1.4l-.3 .3 0 0 0 0 0 0 0 0c-4.6 4.6-5.9 11.4-3.4 17.4c2.5 6 8.3 9.9 14.8 9.9c28.7 0 57.6-8.9 81.6-19.3c22.9-10 42.4-21.9 54.3-30.6c31.8 11.5 67 17.9 104.1 17.9zM128 208a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 0a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm96 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 512 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Bu_0"),jl=t=>Y("svg",{...t,children:n("path",null,{d:"M429.6 92.1c4.9-11.9 2.1-25.6-7-34.7s-22.8-11.9-34.7-7l-352 144c-14.2 5.8-22.2 20.8-19.3 35.8s16.1 25.8 31.4 25.8H224V432c0 15.3 10.8 28.4 25.8 31.4s30-5.1 35.8-19.3l144-352z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"ak_0"),ld=t=>Y("svg",{...t,children:n("path",null,{d:"M384 192c0 87.4-117 243-168.3 307.2c-12.3 15.3-35.1 15.3-47.4 0C117 435 0 279.4 0 192C0 86 86 0 192 0S384 86 384 192z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 384 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"6Z_0"),nd=t=>Y("svg",{...t,children:n("path",null,{d:"M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 384 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"4m_0"),sd=t=>{const e=W(!1);return n("div",null,{class:"relative w-fit"},[n("span",null,{class:u(a=>`${a.containerClass??""} flex cursor-pointer items-center gap-2`,[t],'`${p0.containerClass??""} flex cursor-pointer items-center gap-2`'),onClick$:B("s_F3aQ057DSxY",[e]),onFocusout$:B("s_eygkshVHA6I",[e])},[n("span",null,null,u(a=>a.title,[t],"p0.title"),3,null),i(Kc,null,3,"bO_0")],1,null),n("div",null,{class:u(a=>`absolute bottom-0 left-0 right-0 top-full z-10 min-w-[140px]  rounded-md bg-white shadow-lg transition-all duration-300 ${a.value?"":"hidden"}`,[e],'`absolute bottom-0 left-0 right-0 top-full z-10 min-w-[140px]  rounded-md bg-white shadow-lg transition-all duration-300 ${p0.value?"":"hidden"}`')},i(st,null,3,"bO_1"),1,null)],1,"bO_2")},xa=m(f(sd,"s_f0Yr0C5H5Es")),rd=()=>{const[t]=et();let e="";t?e="/"+window.location.pathname.split("/es/")[1]:e="/es"+window.location.pathname,window.location.pathname=e},id=t=>{var r;const a=(r=Ht().prevUrl)==null?void 0:r.pathname.includes("/es/");return n("div",null,{class:"relative flex cursor-pointer items-center justify-center self-center rounded-full bg-gray-100 shadow-sm",onClick$:f(rd,"s_W5KXXUmo6j8",[a])},[i(E,{get url(){return t.data[0].Icon.data.attributes.url},clasN:`h-[36px] w-[36px] m-1 rounded-full ${a?"opacity-30":"border-2 border-primary-blue border-opacity-50"}`,[s]:{url:u(o=>o.data[0].Icon.data.attributes.url,[t],'p0.data[0]["Icon"]["data"]["attributes"]["url"]')}},3,"tf_0"),i(E,{get url(){return t.data[1].Icon.data.attributes.url},clasN:`h-[36px] w-[36px] m-1 rounded-full ${a?"border-2 border-primary-blue border-opacity-50":"opacity-30"}  `,[s]:{url:u(o=>o.data[1].Icon.data.attributes.url,[t],'p0.data[1]["Icon"]["data"]["attributes"]["url"]')}},3,"tf_1")],1,"tf_2")},od=m(f(id,"s_mIn2RUIc9QU")),ud=t=>{Z();const e=W(!0);return n("div",null,{class:"bg-blue-900 h-[550px] w-full sm:w-4/5 flex flex-col justify-between items-center p-6 rounded-2xl"},[n("h2",null,{class:"text-white font-bold text-xl md:text-4xl mb-2"},"Get in contact with us",3,null),e.value?i(Yt,{size:"250px",[s]:{size:s}},3,"iV_0"):null,n("iframe",null,{class:"w-full h-full overflow-x-visible overflow-y-visible",id:"portability-request",onLoad$:B("s_fXnkVThI4oM",[e]),src:u(a=>a.link,[t],"p0.link")},null,3,null)],1,"iV_1")},cd=m(f(ud,"s_fvFnDV0yuRY")),dd=t=>Y("svg",{...t,children:n("path",null,{d:"M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z","fill-rule":"evenodd"},null,3,null)},{class:"bi bi-arrow-right-short","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Gz_0"),pd=t=>Y("svg",{...t,children:n("path",null,{d:"M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.5a1 1 0 0 0-.8.4l-1.9 2.533a1 1 0 0 1-1.6 0L5.3 12.4a1 1 0 0 0-.8-.4H2a2 2 0 0 1-2-2V2zm3.5 1a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm0 2.5a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm0 2.5a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5z"},null,3,null)},{class:"bi bi-chat-square-text-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"yq_0"),br=t=>Y("svg",{...t,children:n("path",null,{d:"M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"},null,3,null)},{class:"bi bi-check-circle-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Dp_0"),Un=t=>Y("svg",{...t,children:n("path",null,{d:"M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"},null,3,null)},{class:"bi bi-check","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"0U_0"),vr=t=>Y("svg",{...t,children:[n("path",null,{d:"M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"},null,3,null),n("path",null,{d:"M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"},null,3,null)]},{class:"bi bi-download","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"ME_0"),gd=t=>Y("svg",{...t,children:[n("path",null,{d:"M2 2A2 2 0 0 0 .05 3.555L8 8.414l7.95-4.859A2 2 0 0 0 14 2H2Zm-2 9.8V4.698l5.803 3.546L0 11.801Zm6.761-2.97-6.57 4.026A2 2 0 0 0 2 14h6.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.606-3.446l-.367-.225L8 9.586l-1.239-.757ZM16 9.671V4.697l-5.803 3.546.338.208A4.482 4.482 0 0 1 12.5 8c1.414 0 2.675.652 3.5 1.671Z"},null,3,null),n("path",null,{d:"M15.834 12.244c0 1.168-.577 2.025-1.587 2.025-.503 0-1.002-.228-1.12-.648h-.043c-.118.416-.543.643-1.015.643-.77 0-1.259-.542-1.259-1.434v-.529c0-.844.481-1.4 1.26-1.4.585 0 .87.333.953.63h.03v-.568h.905v2.19c0 .272.18.42.411.42.315 0 .639-.415.639-1.39v-.118c0-1.277-.95-2.326-2.484-2.326h-.04c-1.582 0-2.64 1.067-2.64 2.724v.157c0 1.867 1.237 2.654 2.57 2.654h.045c.507 0 .935-.07 1.18-.18v.731c-.219.1-.643.175-1.237.175h-.044C10.438 16 9 14.82 9 12.646v-.214C9 10.36 10.421 9 12.485 9h.035c2.12 0 3.314 1.43 3.314 3.034v.21Zm-4.04.21v.227c0 .586.227.8.581.8.31 0 .564-.17.564-.743v-.367c0-.516-.275-.708-.572-.708-.346 0-.573.245-.573.791Z"},null,3,null)]},{class:"bi bi-envelope-at-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"9e_0"),yr=t=>Y("svg",{...t,children:n("path",null,{d:"M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"},null,3,null)},{class:"bi bi-geo-alt-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"62_0"),wr=t=>Y("svg",{...t,children:[n("path",null,{d:"M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"},null,3,null),n("path",null,{d:"m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6Z"},null,3,null)]},{class:"bi bi-house-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"fX_0"),fd=t=>Y("svg",{...t,children:n("path",null,{d:"M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"},null,3,null)},{class:"bi bi-info-circle-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"SU_0"),xd=t=>Y("svg",{...t,children:n("path",null,{d:"M2 6a6 6 0 1 1 10.174 4.31c-.203.196-.359.4-.453.619l-.762 1.769A.5.5 0 0 1 10.5 13h-5a.5.5 0 0 1-.46-.302l-.761-1.77a1.964 1.964 0 0 0-.453-.618A5.984 5.984 0 0 1 2 6zm3 8.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1l-.224.447a1 1 0 0 1-.894.553H6.618a1 1 0 0 1-.894-.553L5.5 15a.5.5 0 0 1-.5-.5z"},null,3,null)},{class:"bi bi-lightbulb-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"IC_0"),md=t=>Y("svg",{...t,children:n("path",null,{d:"M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"},null,3,null)},{class:"bi bi-person-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"iB_0"),hd=t=>Y("svg",{...t,children:n("path",null,{d:"M0 12V4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm6.79-6.907A.5.5 0 0 0 6 5.5v5a.5.5 0 0 0 .79.407l3.5-2.5a.5.5 0 0 0 0-.814l-3.5-2.5z"},null,3,null)},{class:"bi bi-play-btn-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"YD_0"),$d=t=>Y("svg",{...t,children:n("path",null,{d:"M2 1a1 1 0 0 0-1 1v4.586a1 1 0 0 0 .293.707l7 7a1 1 0 0 0 1.414 0l4.586-4.586a1 1 0 0 0 0-1.414l-7-7A1 1 0 0 0 6.586 1H2zm4 3.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"},null,3,null)},{class:"bi bi-tag-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"vL_0"),_r=t=>Y("svg",{...t,children:n("path",null,{d:"M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z","fill-rule":"evenodd"},null,3,null)},{class:"bi bi-telephone-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"nW_0"),bd=t=>Y("svg",{...t,children:[n("path",null,{d:"M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"},null,3,null),n("path",null,{d:"M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"},null,3,null)]},{class:"bi bi-upload","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"pX_0"),vd=t=>Y("svg",{...t,children:n("path",null,{d:"M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"},null,3,null)},{class:"bi bi-x-lg","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"fv_0"),yd=t=>{Z();const e=W("NONE");return n("div",null,{class:"mx-auto flex max-w-lg flex-col rounded-3xl bg-white p-6"},n("form",null,{class:"mt-2",id:"s_form",onSubmit$:B("s_mKzn6gnXAQk",[e,t]),"preventdefault:submit":!0},[n("div",null,{class:"flex flex-wrap"},[n("div",null,{class:"mb-4 w-full sm:w-2/3"},[n("label",null,{class:"block font-medium text-base text-[#2e5899]",for:"name"},["Name ",n("span",null,{class:"text-red-600"},"*",3,null)," "],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(md,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"T4_0"),1,null),n("input",null,{class:"w-full border border-[#2e5899] rounded-full border-opacity-40 p-2 focus:border-blue-500 focus:outline-none",name:"from_name",required:!0,type:"text"},null,3,null)],1,null)],1,null),n("div",null,{class:"mb-4 w-2/3 sm:w-1/3"},[n("label",null,{class:"block font-medium text-base text-[#2e5899]",for:"zip_code"},["Zip Code ",n("span",null,{class:"text-red-600"},"*",3,null)," "],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(yr,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"T4_1"),1,null),n("input",null,{class:"w-full rounded-full border-opacity-40 border border-[#2e5899] p-2 focus:border-blue-500 focus:outline-none",maxLength:5,minLength:5,name:"zip_code",required:!0,type:"number"},null,3,null)],1,null)],1,null)],1,null),n("div",null,{class:"flex flex-wrap items-center md:flex-row"},[n("div",null,{class:"mb-4 w-full sm:w-1/2"},[n("label",null,{class:"block font-medium text-base text-[#2e5899]",for:"email"},["Email ",n("span",null,{class:"text-red-600"},"*",3,null)],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(gd,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"T4_2"),1,null),n("input",null,{class:"w-full rounded-full border-opacity-40 border border-[#2e5899] p-2 focus:border-blue-500 focus:outline-none",name:"from_email",required:!0,type:"email"},null,3,null)],1,null)],1,null),n("div",null,{class:"mb-4 w-full md:w-1/2"},[n("label",null,{class:"block font-medium text-base text-[#2e5899]",for:"tel"},"Phone",3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(_r,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"T4_3"),1,null),n("input",null,{class:"w-full rounded-full border-opacity-40 border border-[#2e5899] p-2 focus:border-blue-500 focus:outline-none",maxLength:14,name:"tel",type:"tel"},null,3,null)],1,null)],1,null)],1,null),n("div",null,{class:"mb-4"},[n("label",null,{class:"block text-base font-medium text-[#2e5899]",for:"message"},["Message",n("span",null,{class:"text-red-600"},"*",3,null)],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(pd,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"T4_4"),1,null),n("textarea",null,{class:"w-full rounded-3xl border-opacity-40 border border-[#2e5899] p-2 focus:border-blue-500 focus:outline-none",name:"message",required:!0,rows:4},null,3,null)],1,null)],1,null),n("button",{class:`flex w-full items-center text-base justify-center rounded-full bg-secondary-red px-4 py-2 font-semibold text-white hover:bg-opacity-95 ${e.value==="LOADING"?"cursor-wait bg-primary-blue":e.value==="SUCCESS"?"bg-teal-500":""} focus:outline-none`},{disabled:u(a=>a.value==="LOADING"||a.value==="SUCCESS",[e],'p0.value==="LOADING"||p0.value==="SUCCESS"'),type:"submit"},e.value==="NONE"?"Submit":e.value==="LOADING"?i(Yt,{size:"28px",[s]:{size:s}},3,"T4_5"):e.value==="ERROR"?"Error":"Email Sent!",1,null)],1,null),1,"T4_6")},wd=m(f(yd,"s_UlMR3Hqos6E")),_d=()=>{const[t,e]=et();e.value=t},Sd=t=>{var v;const e=new Set(t.data.map($=>$.attributes.Category)),a=t.data.filter($=>$.attributes.Category==="Sports"),l=t.data.filter($=>$.attributes.Category==="Movies"),r=t.data.filter($=>$.attributes.Category==="News"),o=t.data.filter($=>$.attributes.Category==="Music"),c=t.data.filter($=>$.attributes.Category==="Kids"),d=(v=t.planId)==null?void 0:v.slice(0,2),p=W(0),g=$=>$.map((S,D)=>{const L=S.attributes.package_tvs.data.some(y=>y.attributes.package.includes(d)),T=S.attributes.package_tvs.data.some(y=>y.attributes.package.includes("comingSoon"));return n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",{class:`h-[40px] w-[40px] md:h-[60px] md:w-[60px] ${L?"":"opacity-20"} flex flex-col rounded-full border-2 p-1`},null,n("img",{alt:w(S.attributes.Image.data.attributes,"alterbativeText"),src:G(S.attributes.Image.data.attributes.url)},{height:50,width:50},null,3,null),1,null),T?n("div",null,{class:"rounded-full bg-primary-blue p-0.5 text-center text-xs text-white"},"Coming Soon",3,"wr_0"):null,n("p",null,{class:"text-center text-xs text-primary-blue"},w(S.attributes,"Channel_name"),1,null)],1,D)}),h=Array.from(e).map(($,S)=>n("div",null,{class:"grid w-full grid-cols-3 gap-4 py-4 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8"},$==="General"?g(t.data):$==="Sports"?g(a):$==="News"?g(r):$==="Music"?g(o):$==="Movies"?g(l):$==="Kids"?g(c):null,1,S));return n("div",null,{class:"h-[800px] w-full rounded-3xl bg-blue-700 p-5 md:h-[500px] md:w-[800px] md:p-10"},[n("div",null,{class:"flex flex-col content-start items-center justify-start md:flex-row md:justify-between"},[n("h1",null,{class:"text-2xl font-semibold text-white md:text-4xl"},u($=>$.planId,[t],"p0.planId"),3,null),n("p",null,{class:"text-xl font-light text-white md:text-2xl"},u($=>$.channels,[t],"p0.channels"),3,null)],3,null),n("div",null,{class:"my-1 flex h-fit flex-row items-start justify-start gap-4 overflow-x-auto rounded-t-2xl bg-white px-2 py-2 font-bold text-primary-blue md:items-center md:justify-between md:overflow-clip"},Array.from(e).map(($,S)=>n("button",{class:`${p.value==S?"bg-gray-200":""} rounded-xl p-2`,onClick$:f(_d,"s_jPiPOXcEB6E",[S,p])},null,$,0,S)),1,null),n("div",null,{class:"flex h-3/4 w-full items-center justify-center rounded-b-3xl bg-white p-6"},Array.from(e).map(($,S)=>p.value==S?n("div",null,{class:"flex h-full w-full overflow-y-auto overflow-x-hidden rounded-2xl border-2 border-primary-blue bg-white py-4"},h[S],1,S):null),1,null)],1,"wr_1")},Td=m(f(Sd,"s_bUc7uFb70ZI")),Dd=t=>`query {
        offices (filters:{locations:{ZipCode:{eq:${t}}}}) {
          data {
            attributes {
              InstanceLink
            }
          }
        }
      }`,Sr=t=>`
query QueryLayout {
    generalMenu(locale: "${t}") {
      data {
        attributes {
          TopOptions {
            Icon {
              ${b}
            }
            Text
            Link
          }
  
          localizations {
            data {
              attributes {
                MainOptions {
                  Text
                  Link
                  SubOption {
                    Text
                    Link
                  }
                }
              }
            }
          }
  
          MainMenu {
            Logo {
              ${b}
            }
            Switcher {
              Text
              Link
              Icon {
                ${b}
              }
            }
          }
          MainOptions {
            Text
            Link
            SubOption {
              Text
              Link
              MenuOption {
                data {
                  attributes {
                    SubOption {
                      Text
                      Link
                    }
                  }
                }
              }
            }
          }
          ClientOptions {
            Text
            Link
          }
          gigfastOptions {
            Text
            Link
            Icon {
              ${b}
            }
          }
        }
      }
    }
    generalFooter(locale: "${t}") {
      data {
        attributes {
          SupportSection {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          CorpInfo {
            Media {
              ${b}
            }
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          Menus {
            Text
            SubOption {
              Text
              Link
            }
          }
          SocialMedia {
            Text
            SubOption {
              Icon {
                ${b}
              }
              Link
            }
          }
        }
      }
    }
    generalHeader {
      data {
        attributes {
          Slide {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
        }
      }
    }
  } 
`;async function ma(t){return await(await fetch(Hc,{method:"POST",cache:"no-cache",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:t})})).json()}async function R(t,e="en",a=!0){let l={};a&&(l=await ma(Sr(fa(e))));const r=await ma(t(fa(e)));return{layoutData:l,pageData:r}}async function Oa(t,e="en",a=!0){let l={};a&&(l=await ma(Sr(fa(e))));const r=await ma(t);return{layoutData:l,pageData:r}}const Pd=t=>`query {
        offices(filters: { locations: { ZipCode: { eq: ${t} } } }) {
          data {
            attributes {
              Location
              Phone {
                Link
                Text
              }
            }
          }
        }
      }`,kd=async t=>{let e=null;const a=await Oa(Dd(t["zip-code"].toString()));return a.pageData.data.offices.data.length>0&&(e=await a.pageData.data.offices.data[0].attributes.InstanceLink),e},Ld=xr(f(kd,"s_Aa7HFHe6DLE")),Md=async t=>{let e=null;const a=await Oa(Pd(t["zip-code"].toString()));return a.pageData.data.offices.data.length>0&&(e=await a.pageData.data.offices.data[0].attributes),e};xr(f(Md,"s_txZGYKoQ0E8"));const Cd=()=>{},jd=t=>{var o;Z();const e=Ld(),a=W(!1),r=(o=Ht().prevUrl)==null?void 0:o.pathname.includes("/es/");return n("div",null,{class:" z-[800] flex h-fit w-[600px] flex-col items-center justify-center gap-4 rounded-full bg-blue-100 p-8"},[n("h1",null,{class:"text-center text-4xl font-bold text-primary-blue"},u(c=>c.title,[t],"p0.title"),3,null),n("p",null,{class:"font-light"},u(c=>c.description,[t],"p0.description"),3,null),i(vc,{action:e,children:n("div",null,{class:"flex flex-row items-center justify-center gap-4 px-4"},[n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(yr,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"PA_0"),1,null),n("input",null,{class:"rounded-full border border-gray-300 p-2 placeholder:text-primary-blue focus:border-blue-500 focus:outline-none",maxLength:5,name:"zip-code",placeholder:"Zip-code",required:!0,type:"text"},null,3,null)],1,null),n("button",null,{class:"w-1/4 rounded-full border-2 border-teal-500 bg-white px-4 py-2 font-bold text-teal-500 hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:B("s_odOkENLwWr0",[a,e]),type:"submit"},u(c=>c.btnText,[t],"p0.btnText"),3,null)],1,null),class:"w-full",onSubmit$:f(Cd,"s_SuMdNt0qey8"),[s]:{action:s,class:s,onSubmit$:s}},1,"PA_1"),t.popup==="login"&&e.isRunning&&i(Yt,{size:"50px",[s]:{size:s}},3,"PA_2"),t.popup==="login"&&!e.isRunning&&e.value!=null&&n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,null,"Portal found",3,null),n("a",null,{href:u(c=>c.value.toString(),[e],"p0.value.toString()")},n("button",null,{class:"w-full rounded-full border-2 border-teal-500 bg-white px-4 py-2 font-bold text-teal-500 hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"},r?"Ir al portal":"Go to portal",1,null),1,null)],1,"PA_3"),t.popup==="login"&&!e.isRunning&&e.value==null&&a.value&&n("p",null,{class:"text-2xl text-secondary-red"},r?"Portal no encontrado":"Portal not found",1,"PA_4"),t.popup!=="login"&&e.isRunning&&i(Yt,{size:"50px",[s]:{size:s}},3,"PA_5"),t.popup!=="login"&&!e.isRunning&&e.value!=null&&n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,null,e.value.Location.toString(),1,null),n("a",null,{href:u(c=>c.value.Phone.Link.toString(),[e],'p0.value["Phone"]["Link"].toString()')},n("button",null,{class:"w-full rounded-full border-2 border-teal-500 bg-white px-4 py-2 font-bold text-teal-500 hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"},u(c=>c.value.Phone.Text,[e],'p0.value["Phone"]["Text"]'),3,null),3,null)],1,"PA_6"),t.popup!=="login"&&!e.isRunning&&e.value==null&&a.value&&n("p",null,{class:"text-xs text-primary-blue"},u(c=>c.notFountText,[t],"p0.notFountText"),3,"PA_7")],1,"PA_8")},Ka=m(f(jd,"s_7GiaINstLc4")),Id=t=>n("div",null,{class:"fixed bottom-0 left-0 right-0 bg-white top-0 z-[200]  transition-all duration-1000 ease-in-out"},n("iframe",null,{class:"h-full w-full",frameBorder:"0",src:u(e=>e.route,[t],"p0.route")},null,3,null),3,"V0_0"),Ed=m(f(Id,"s_R079dt5Nweo")),Od=t=>{var o,c;Z();const a=(o=Ht().prevUrl)==null?void 0:o.pathname.includes("/es/");let l=null;if(t.link.includes("=pConf=")){const d=t.link.replace("=pConf=","");l=i(Ed,{route:d},3,"Y1_0")}else if(t.link.includes("=pIFrame=")){const d=t.link.replaceAll("=pIFrame=","");l=i(cd,{link:d},3,"Y1_1")}else t.link.includes("=pContactEmail=")?l=i(wd,{get templateID(){return t.link.split("=")[2]},[s]:{templateID:u(d=>d.link.split("=")[2],[t],'p0.link.split("=")[2]')}},3,"Y1_2"):t.link.includes("=pChannelLineup=")?l=i(Td,{get channels(){return t.channels},get planId(){return t.planId},get data(){return t.dataChannels},[s]:{channels:u(d=>d.channels,[t],"p0.channels"),data:u(d=>d.dataChannels,[t],"p0.dataChannels"),planId:u(d=>d.planId,[t],"p0.planId")}},3,"Y1_3"):t.link.includes("=pLogin")?l=i(Ka,{btnText:a?"Ir ahora":"Go Now",description:a?"Simplemente ingrese su código postal.":"Just enter your Zip code.",popup:"login",title:a?"Inicia sesión en el portal de tu zona":"Log into the portal of your area",[s]:{popup:s}},3,"Y1_4"):t.link.includes("=pOfficeCall")&&(l=i(Ka,{btnText:a?"Comprobar ahora":"Check Now",description:a?"Descubra exactamente qué servicios ofrece RTA en su ciudad natal. Ingrese su código postal para el número de teléfono de su oficina local.":"Find out exactly what services RTA has to offer in your hometown. Input your zip code for your local office phone number.",notFountText:a?"Desafortunadamente, RTA no está disponible actualmente en su área. Sin embargo, RTA continúa expandiéndose en todo Estados Unidos. Si está interesado en los servicios de RTA en su área, envíenos un correo electrónico o llame a nuestra oficina principal.":"Find out exactly what services RTA has to offer in your hometown. Input your zip code for your local office phone number.",popup:"location",title:a?"Llame a su oficina local":"Call your local office",[s]:{popup:s}},3,"Y1_5"));const r=W(!1);return n("div",null,{class:"relative flex"},[t.link.includes("=pConf=")&&(!((c=t.text)!=null&&c.includes("Check"))||!t.text.includes("Buscar"))?n("div",null,{class:"flex w-fit items-center justify-center rounded-full border-2 border-teal-500 border-opacity-70 bg-white p-0.5 px-1 text-btn-green opacity-90 shadow-md transition-all delay-150 ease-in-out hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:B("s_gRyPmBMRMEM",[r])},[n("p",null,{class:"min-sm:text-[13px] mx-2 text-[15px] font-[600] tracking-wide max-md:text-[14px] "},u(d=>d.text,[t],"p0.text"),3,null),n("div",null,{class:"flex h-[25px] w-[25px] items-center justify-center rounded-full bg-teal-500 p-0 opacity-70 "},i($d,{class:"fill-white font-bold",[s]:{class:s}},3,"Y1_6"),1,null)],1,"Y1_7"):t.hasStyle??!0?n("button",{class:`flex w-fit items-center justify-center gap-2 ${t.link.includes("=pChannelLineup=")?"":"rounded-full border-2 border-teal-500 p-1 px-7 shadow-md transition-all  hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"}  bg-white  text-[15px] font-[600]  text-btn-green opacity-80 max-md:text-[14px] max-sm:text-[13px] `},{onClick$:B("s_LMY0q14Gz9I",[r])},u(d=>d.text,[t],"p0.text"),3,null):n("div",null,{onClick$:B("s_CtCqQvywDJo",[r])},[i(st,null,3,"Y1_8")," "],1,"Y1_9"),r.value&&n("div",null,{class:"fixed inset-0 z-50 flex flex-col items-center justify-center bg-black bg-opacity-40"},n("div",null,{class:u(d=>` ${d.link.includes("=pConf=")?"w-full h-full flex-row-reverse ":"flex-col-reverse md:flex-row w-fit"} animate-zoomIn flex `,[t],'` ${p0.link.includes("=pConf=")?"w-full h-full flex-row-reverse ":"flex-col-reverse md:flex-row w-fit"} animate-zoomIn flex `')},[n("div",null,{class:"flex p-4 flex-wrap overflow-hidden items-center justify-center "},l,1,null),n("button",{class:`${t.link.includes("=pConf=")?"mt-2 mx-0":"w-[30px] p-4"} bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] focus:outline-none z-[600]`},{"aria-label":"Close popup",onClick$:B("s_Hg5lk0TunCg",[r])},t.link.includes("=pConf=")?n("div",null,{class:"px-3 flex flex-row items-center text-xs gap-2"},["Back to site ",i(wr,null,3,"Y1_10")],1,"Y1_11"):n("div",null,null,i(vd,null,3,"Y1_12"),1,null),1,null)],1,null),1,"Y1_13")],1,"Y1_14")},ha=m(f(Od,"s_G7PwpIAJKRA")),Bd=t=>{var r;Z();const a=(r=Ht().prevUrl)==null?void 0:r.pathname.includes("/es/"),l=t.link.startsWith("/");return t.link.startsWith("/")||t.link.startsWith("http")||t.link.startsWith("tel:")?i(Se,{get class(){return t.classN??""},href:(a&&l?"/es":"")+t.link,prefetch:!0,get target(){return t.link.startsWith("http")?"_blank":"_self"},children:i(st,null,3,"8s_0"),[s]:{class:u(o=>o.classN??"",[t],'p0.classN??""'),prefetch:s,target:u(o=>o.link.startsWith("http")?"_blank":"_self",[t],'p0.link.startsWith("http")?"_blank":"_self"')}},1,"8s_1"):t.link.startsWith("=")&&t.link?i(ha,{get link(){return t.link},get text(){return t.text??""},get hasStyle(){return t.hasStyle??!0},children:[" ",n("div",null,{class:u(o=>`${o.classN??""} cursor-pointer`,[t],'`${p0.classN??""} cursor-pointer`')},i(st,null,3,"8s_2"),1,null)],[s]:{hasStyle:u(o=>o.hasStyle??!0,[t],"p0.hasStyle??true"),link:u(o=>o.link,[t],"p0.link"),text:u(o=>o.text??"",[t],'p0.text??""')}},1,"8s_3"):n("div",null,{class:u(o=>o.classN??"",[t],'p0.classN??""')},i(st,null,3,"8s_4"),1,"8s_5")},yt=m(f(Bd,"s_nqL2AObZq60")),Ad=()=>{const[t]=et();t.mobMenuOpen.value=!t.mobMenuOpen.value;const e=document.getElementsByTagName("body")[0];t.mobMenuOpen.value?e.classList.add("overflow-y-hidden"):e.classList.remove("overflow-y-hidden")},Nd=t=>n("div",null,{class:"relative z-30 shadow-[0_5px_40px_-25px_rgba(0,0,0,0.2)]"},[n("div",null,{class:" fixed top-0 w-full shadow-[0_5px_40px_-25px_rgba(0,0,0,0.2)]"},[n("div",null,{class:"flex h-[28px] flex-row items-center justify-end gap-4 bg-primary-blue px-5 py-[4px] text-[12px] font-bold text-white max-sm:justify-evenly max-sm:text-[10px] max-sm:font-normal max-[400px]:text-[9px]"},t.data.TopOptions.map((e,a)=>i(yt,{get link(){return e.Link},hasStyle:!1,get text(){return e.Text},children:n("div",null,{class:"flex flex-row items-center gap-2"},[n("div",null,{class:"w-[12px]"},i(E,{get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},height:"16",toWhite:!0,width:"16",[s]:{alt:x(e.Icon.data.attributes,"alternativeText"),height:s,title:x(e.Icon.data.attributes,"caption"),toWhite:s,url:x(e.Icon.data.attributes,"url"),width:s}},3,"Qt_0"),1,null),w(e,"Text")],1,null),[s]:{hasStyle:s,link:x(e,"Link"),text:x(e,"Text")}},1,a)),1,null),n("div",null,{class:"grid grid-cols-3 items-center justify-evenly bg-white py-1 min-[1200px]:flex"},[n("div",null,{class:"flex items-center justify-center min-[1200px]:hidden"},i(Xc,{class:"w-[30px] min-[1200px]:hidden",onClick$:f(Ad,"s_4kdCNCRjFuk",[t]),[s]:{class:s,onClick$:s}},3,"Qt_1"),1,null),n("div",null,{class:"flex items-center justify-center"},n("div",null,{class:"w-[125px] py-1"},i(yt,{children:i(E,{get url(){return t.data.MainMenu.Logo.data.attributes.url},get alt(){return t.data.MainMenu.Logo.data.attributes.alternativeText},get title(){return t.data.MainMenu.Logo.data.attributes.caption},height:80,width:150,[s]:{alt:u(e=>e.data.MainMenu.Logo.data.attributes.alternativeText,[t],'p0.data["MainMenu"]["Logo"]["data"]["attributes"]["alternativeText"]'),height:s,title:u(e=>e.data.MainMenu.Logo.data.attributes.caption,[t],'p0.data["MainMenu"]["Logo"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.MainMenu.Logo.data.attributes.url,[t],'p0.data["MainMenu"]["Logo"]["data"]["attributes"]["url"]'),width:s}},3,"Qt_2"),link:"/",[s]:{link:s}},1,"Qt_3"),1,null),1,null),n("div",null,{class:"flex items-center justify-center gap-4 max-[1200px]:hidden"},t.data.MainOptions.map(function(e,a){Z();const l=e.SubOption.length>0;return n("div",null,{class:"text-[15px] font-bold text-primary-blue "},l?i(xa,{get title(){return e.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},e.SubOption.map((r,o)=>{Z();const c=r.MenuOption.data;return c?i(xa,{get title(){return r.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},c.attributes.SubOption.map((d,p)=>i(yt,{get link(){return d.Link},children:w(d,"Text"),[s]:{link:x(d,"Link")}},1,p)),1,null),[s]:{title:x(r,"Text")}},1,"Qt_5"):i(yt,{classN:"text-primary-blue",get link(){return r.Link},children:w(r,"Text"),hasStyle:!1,[s]:{classN:s,hasStyle:s,link:x(r,"Link")}},1,o)}),1,null),[s]:{title:x(e,"Text")}},1,"Qt_6"):i(yt,{classN:"text-primary-blue",get link(){return e.Link},children:w(e,"Text"),hasStyle:!1,[s]:{classN:s,hasStyle:s,link:x(e,"Link")}},1,"Qt_4"),1,a)}),1,null),n("div",null,{class:"flex items-center justify-center"},i(od,{get data(){return t.data.MainMenu.Switcher},[s]:{data:u(e=>e.data.MainMenu.Switcher,[t],'p0.data["MainMenu"]["Switcher"]')}},3,"Qt_7"),1,null)],1,null)],1,null),n("div",null,{class:"mt-[89px] flex h-[32px] flex-row items-center justify-center gap-6 bg-secondary-red py-[2px] text-[14px] font-semibold tracking-[1px] text-white max-sm:text-[11px]"},t.data.ClientOptions.map((e,a)=>i(yt,{get link(){return e.Link},children:w(e,"Text"),[s]:{link:x(e,"Link")}},1,a)),1,null),n("div",null,{class:"flex flex-row items-center justify-evenly bg-white py-1 max-[1200px]:hidden"},t.data.gigfastOptions.map((e,a)=>i(yt,{get link(){return e.Link},children:n("div",null,{class:"w-[130px] rounded-md p-1 hover:bg-slate-50"},i(E,{get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},height:"60",width:"311",[s]:{alt:x(e.Icon.data.attributes,"alternativeText"),height:s,title:x(e.Icon.data.attributes,"caption"),url:x(e.Icon.data.attributes,"url"),width:s}},3,"Qt_8"),1,null),[s]:{link:x(e,"Link")}},1,a)),1,null)],1,"Qt_9"),qd=m(f(Nd,"s_qJ0s4sH5iHo")),Rd=t=>{Z();const e=W(!1);return n("div",null,{class:"my-8 mb-2 w-full"},[n("div",{class:`flex cursor-pointer flex-row items-center transition ${t.inFooter??!1?"":e.value?"rounded-b-none rounded-t-2xl":"rounded-full"} justify-between ${t.classContainer} p-2 `},{onClick$:B("s_n7LVHyx9gZ0",[e])},[n("span",null,{class:"flex w-full items-center justify-center font-bold"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:u(a=>`flex h-[20px] w-[20px] items-center justify-center ${a.inFooter??!1?"":"rounded-full bg-secondary-red text-white"}`,[t],'`flex h-[20px] w-[20px] items-center justify-center ${p0.inFooter??false?"":"rounded-full bg-secondary-red text-white"}`')},n("span",null,{class:"w-1/8 flex items-center justify-end text-xs"},u(a=>a.value?"▲":"▼",[e],'p0.value?"▲":"▼"'),3,null),3,null)],3,null),e.value&&n("div",null,{class:u(a=>`${a.classChild} ${a.inFooter??!1?"":"rounded-b-2xl rounded-t-none border-t-2 bg-white"} p-2 text-center transition-all duration-500 ease-in-out`,[t],'`${p0.classChild} ${p0.inFooter??false?"":"rounded-b-2xl rounded-t-none border-t-2 bg-white"} p-2 text-center transition-all duration-500 ease-in-out`')},i(st,null,3,"vV_0"),1,"vV_1")],1,"vV_2")},xe=m(f(Rd,"s_znBlgckysPY")),zd=()=>{const[t]=et();if(t.link){if(t.link.includes("http"))return window.open(t.link,"_blank");window.location.href=t.link}(t.onClick??(()=>{}))()},Fd=t=>{var a;Z();const e=f(zd,"s_5VUQoQPBpDA",[t]);return(t.type??"link")==="link"?(a=t.link)!=null&&a.startsWith("=")&&t.link?i(ha,{get link(){return t.link},get text(){return t.text},[s]:{link:u(l=>l.link,[t],"p0.link"),text:u(l=>l.text,[t],"p0.text")}},3,"ky_0"):n("div",null,{class:"flex w-fit items-center justify-center rounded-full border-2 border-teal-500 border-opacity-70 bg-white p-0.5 px-1 text-btn-green opacity-90 shadow-md transition transition-all delay-150 ease-in-out hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:B("s_v30BEZ050tM",[e])},[n("p",null,{class:"min-sm:text-[13px] mx-2 text-[15px] font-[600] tracking-wide max-md:text-[14px] "},u(l=>l.text,[t],"p0.text"),3,null),n("div",null,{class:"flex h-[25px] w-[25px] items-center justify-center rounded-full bg-teal-500 p-0 opacity-70 "},i(dd,{class:"fill-white font-bold",[s]:{class:s}},3,"ky_1"),1,null)],1,"ky_2"):n("div",null,{class:"text-btn-white flex w-fit items-center justify-center  rounded-full bg-teal-500 p-1 px-1 opacity-90 shadow-md transition transition-all  delay-150  ease-in-out hover:cursor-pointer hover:bg-teal-600",onClick$:B("s_eSPP9CLbtZw",[e])},[n("p",null,{class:"min-sm:text-[13px] mx-2 text-[15px] font-[600] tracking-wide  text-white max-md:text-[14px] "},u(l=>l.text,[t],"p0.text"),3,null),n("div",null,{class:"flex h-[25px] w-[25px] items-center justify-center rounded-full bg-white p-0 opacity-60 opacity-70 "},i(_r,{class:"w-[12px] fill-teal-500",[s]:{class:s}},3,"ky_3"),1,null)],1,"ky_4")},X=m(f(Fd,"s_FRLwbQyPTTI")),Gd=t=>n("div",null,{class:"",id:"footer"},[n("div",null,{class:"flex flex-col items-center bg-primary-blue px-4 py-3 text-white"},[n("h3",null,{class:"text-[22px] font-semibold"},u(e=>e.data.SupportSection.Title,[t],'p0.data["SupportSection"]["Title"]'),3,null),n("p",null,{class:"text-s lm:w-1/2 text-center sm:w-3/4"},u(e=>e.data.SupportSection.Paragraph,[t],'p0.data["SupportSection"]["Paragraph"]'),3,null)],3,null),n("div",null,{class:"flex flex-col flex-wrap justify-around bg-primary-dark-blue px-3 py-3 text-white lg:flex-row"},[n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"mb-4 w-[180px]"},i(E,{height:359,width:970,get url(){return t.data.CorpInfo.Media.data.attributes.url},get alt(){return t.data.CorpInfo.Media.data.attributes.alternativeText},get title(){return t.data.CorpInfo.Media.data.attributes.caption},[s]:{alt:u(e=>e.data.CorpInfo.Media.data.attributes.alternativeText,[t],'p0.data["CorpInfo"]["Media"]["data"]["attributes"]["alternativeText"]'),height:s,title:u(e=>e.data.CorpInfo.Media.data.attributes.caption,[t],'p0.data["CorpInfo"]["Media"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.CorpInfo.Media.data.attributes.url,[t],'p0.data["CorpInfo"]["Media"]["data"]["attributes"]["url"]'),width:s}},3,"Zn_0"),1,null),n("p",null,{class:"mb-4 max-w-sm text-center"},u(e=>e.data.CorpInfo.Paragraph,[t],'p0.data["CorpInfo"]["Paragraph"]'),3,null),i(X,{type:"action",get link(){return t.data.CorpInfo.Buttons[0].Link},get text(){return t.data.CorpInfo.Buttons[0].Text},[s]:{link:u(e=>e.data.CorpInfo.Buttons[0].Link,[t],'p0.data["CorpInfo"]["Buttons"][0]["Link"]'),text:u(e=>e.data.CorpInfo.Buttons[0].Text,[t],'p0.data["CorpInfo"]["Buttons"][0]["Text"]'),type:s}},3,"Zn_1")],1,null),n("div",null,{class:"container sm:hidden"},t.data.Menus.map((e,a)=>i(xe,{inFooter:!0,get title(){return e.Text},children:e.SubOption.map((l,r)=>i(Se,{get href(){return l.Link},children:n("h3",null,null,w(l,"Text"),1,null),class:"mb-4 hover:text-blue-600",[s]:{class:s,href:x(l,"Link")}},1,r)),classContainer:"text-xl text-primary-light-blue font-semibold border-b-2 border-t-2 border-primary-light-blue",[s]:{classContainer:s,inFooter:s,title:x(e,"Text")}},1,a)),1,null),n("div",null,{class:"flex justify-around"},t.data.Menus.map((e,a)=>n("div",null,{class:"hidden w-1/4 sm:block"},[n("h2",null,{class:"text-2xl text-primary-light-blue font-semibold"},w(e,"Text"),1,null),e.SubOption.map((l,r)=>i(Se,{get href(){return l.Link},children:n("h3",null,null,w(l,"Text"),1,null),class:"hover:text-blue-600",[s]:{class:s,href:x(l,"Link")}},1,r))],1,a)),1,null)],1,null),n("div",null,{class:"flex flex-col items-center gap-2 bg-primary-dark-blue px-4 py-4 text-white"},[n("p",null,{class:"text-[14px]"},u(e=>e.data.SocialMedia.Text,[t],'p0.data["SocialMedia"]["Text"]'),3,null),n("div",null,{class:"flex flex-row gap-4"},t.data.SocialMedia.SubOption.map((e,a)=>Z(i(Se,{get href(){return e.Link},children:[e.Link.includes("facebook")&&n("div",null,{class:"flex h-7 w-7 items-center justify-center rounded-full bg-primary-blue p-2"},i(E,{height:20,width:20,get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},toWhite:!0,[s]:{alt:x(e.Icon.data.attributes,"alternativeText"),height:s,title:x(e.Icon.data.attributes,"caption"),toWhite:s,url:x(e.Icon.data.attributes,"url"),width:s}},3,"Zn_2"),1,"Zn_3"),!e.Link.includes("facebook")&&n("div",null,{class:"flex h-7 w-7 items-center justify-center rounded-full bg-primary-blue p-1"},i(E,{height:20,width:20,get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},toWhite:!0,[s]:{alt:x(e.Icon.data.attributes,"alternativeText"),height:s,title:x(e.Icon.data.attributes,"caption"),toWhite:s,url:x(e.Icon.data.attributes,"url"),width:s}},3,"Zn_4"),1,"Zn_5")],[s]:{href:x(e,"Link")}},1,a))),1,null)],1,null)],1,"Zn_6"),Qd=m(f(Gd,"s_ecsQS6so2H0")),Hd=t=>n("div",{class:`flex list-outside flex-col gap-3 text-primary-blue [&>*>a]:text-secondary-red [&>h1]:text-[36px] [&>h1]:font-[600] [&>h2]:text-[32px] [&>h3]:text-[26px] [&>ul]:flex [&>ul]:flex-col [&>ul]:gap-3  ${t.classN??""}`,dangerouslySetInnerHTML:Vn(t.text)},null,null,3,"Cb_0"),C=m(f(Hd,"s_RjmVkFh5HBg")),Tr=({qty:t})=>{if(t!==void 0)return t;if(typeof window<"u"){const e=window.innerWidth;return e>1200?3:e>800?2:1}else return 1},Wd=()=>{const[t,e]=et();t.value=Tr({qty:e})},Ud=()=>{const[t]=et();t()},Vd=({slidesQty:t})=>{const e=W(Tr({qty:t})),a=f(Wd,"s_zVG057gY2pI",[e,t]);return Jt(B("s_hQsoJzDpgeo",[a])),Xr("resize",f(Ud,"s_WB2t7tmOijA",[a])),e};const Yd=t=>{const e=Vd({slidesQty:t.slidesQty});return Jt(B("s_xmo13ab0hsk",[e,t])),i(H,{children:n("section",null,{"aria-label":"Componente Carousel",class:"splide max-w-screen overflow-hidden",id:u(a=>`${a.id?a.id:""}`,[t],'`${p0.id?p0.id:""}`')},n("div",null,{class:u(a=>` splide__track  ${a.addSpace??!0?"p-8":""}`,[t],'` splide__track  ${p0.addSpace??true?"p-8":""}`')},n("div",null,{class:"splide__list justify-between "},t.slides.map((a,l)=>n("div",null,{class:"splide__slide w-full items-center"},n("div",null,{class:u(r=>`${r.fillSlide??!1?"w-full h-full object-cover":"object-center"} flex items-center  ${r.addSpace??!0?"mx-10":""}  justify-center`,[t],'`${p0.fillSlide??false?"w-full h-full object-cover":"object-center"} flex items-center  ${p0.addSpace??true?"mx-10":""}  justify-center`')},a,1,null),1,l)),1,null),1,null),1,null)},1,"cE_0")},St=m(f(Yd,"s_UuwASfcxtbw")),Zd=t=>n("div",null,{class:"flex flex-col items-center justify-between"},[n("div",null,{class:"z-20 mb-1 flex flex-col justify-center"},[n("span",null,{class:"text-center text-[20px] font-semibold"},u(e=>e.slide.Title,[t],'p0.slide["Title"]'),3,null),n("span",null,{class:"text-[14px] font-light"},i(C,{classN:"text-white",get text(){return t.slide.Paragraph},[s]:{classN:s,text:u(e=>e.slide.Paragraph,[t],'p0.slide["Paragraph"]')}},3,"DG_0"),1,null)],1,null),i(X,{get link(){return t.slide.Buttons[0].Link},get text(){return t.slide.Buttons[0].Text},[s]:{link:u(e=>e.slide.Buttons[0].Link,[t],'p0.slide["Buttons"][0]["Link"]'),text:u(e=>e.slide.Buttons[0].Text,[t],'p0.slide["Buttons"][0]["Text"]')}},3,"DG_1")],1,"DG_2"),Kd=t=>{const e=m(f(Zd,"s_3lZ1awB53As")),a=t.data.Slide.map((l,r)=>i(e,{slide:l},3,r));return n("div",null,{class:"mb-4 flex w-[40%] min-w-[350px] max-w-[500px] flex-col items-center justify-center overflow-hidden rounded-full rounded-t-none bg-[#0E4FB0] px-8 py-1 text-white max-[400px]:w-[98%] max-[400px]:min-w-[200px] max-[400px]:pb-10 "},i(St,{addSpace:!1,duration:4e3,hasPagination:!1,id:"headerCarousel",slides:a,slidesQty:1,[s]:{addSpace:s,duration:s,hasPagination:s,id:s,slidesQty:s}},3,"DG_3"),1,"DG_4")},Xd=m(f(Kd,"s_BIrsaZMr3LY")),Jd=()=>{const[t]=et();t.showSignal.value=!1},tp=t=>n("div",{class:`fixed left-0 right-0 top-0 z-[500] flex h-screen items-center justify-center bg-primary-dark-blue bg-opacity-30 transition-all duration-300 ${t.showSignal.value?"":"hidden"}`},{id:"modalback",onClick$:B("s_0718nqiE4KE",[t])},[i(nd,{class:"absolute right-2 top-2 rounded-full bg-secondary-red p-1 text-[30px] font-[200] text-white hover:cursor-pointer",onClick$:f(Jd,"s_AR3wQHs8a3I",[t]),[s]:{class:s,onClick$:s}},3,"kj_0"),i(st,null,3,"kj_1")],1,"kj_2"),Xa=m(f(tp,"s_oHrF0mun03M")),ep=t=>{var r;const a=(r=Ht().prevUrl)==null?void 0:r.pathname.includes("/es/"),l=W(!1);return n("div",null,{class:"flex flex-col gap-4 px-4 py-6 text-[15px] tracking-tight text-white"},[n("div",null,{class:"text-primary-blue"},i(Xa,{children:i(Ka,{btnText:a?"Ir ahora":"Go Now",description:a?"Ingrese su código postal.":"Just enter your Zip code.",popup:"login",title:a?"Inicia sesión en el portal de tu zona":"Log into the portal of your area",[s]:{popup:s}},3,"Ux_0"),showSignal:l,[s]:{showSignal:s}},1,"Ux_1"),1,null),t.data.MainOptions.map(function(o,c){Z();const d=o.SubOption.length>0;return n("div",null,{class:""},d?i(xa,{get title(){return o.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},o.SubOption.map((p,g)=>{Z();const h=p.MenuOption.data;return h?i(xa,{get title(){return p.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},h.attributes.SubOption.map((v,$)=>i(yt,{get link(){return v.Link},children:w(v,"Text"),hasStyle:!1,[s]:{hasStyle:s,link:x(v,"Link")}},1,$)),1,null),[s]:{title:x(p,"Text")}},1,"Ux_4"):p.Link.includes("Login")?n("div",null,{class:"hover:cursor-pointer",onClick$:B("s_SnfOjeOrlzY",[l])},w(p,"Text"),1,"Ux_3"):i(yt,{get link(){return p.Link},children:w(p,"Text"),hasStyle:!1,[s]:{hasStyle:s,link:x(p,"Link")}},1,g)}),1,null),[s]:{title:x(o,"Text")}},1,"Ux_5"):i(yt,{get link(){return o.Link},children:w(o,"Text"),[s]:{link:x(o,"Link")}},1,"Ux_2"),1,c)}),n("div",null,{class:"w-full border border-white border-opacity-40"},null,3,null),n("div",null,{class:"flex w-fit flex-col gap-5"},t.data.gigfastOptions.map((o,c)=>i(yt,{get link(){return o.Link},children:n("div",null,{class:"w-[130px] rounded-md p-1"},i(E,{get url(){return o.Icon.data.attributes.url},height:"60",width:"311",[s]:{height:s,url:x(o.Icon.data.attributes,"url"),width:s}},3,"Ux_6"),1,null),classN:"rounded-full bg-white px-4 py-1 shadow-lg",[s]:{classN:s,link:x(o,"Link")}},1,c)),1,null)],1,"Ux_7")},ap=m(f(ep,"s_jSaadUqLWqI")),lp=t=>{Z();const e=W(!1);return n("div",null,{class:u(a=>`relative overflow-hidden transition-all duration-500 ${a.value?"overflow-y-hidden":"z-50"}`,[e],'`relative overflow-hidden transition-all duration-500 ${p0.value?"overflow-y-hidden":"z-50"}`'),style:u(a=>a.value?{perspective:"9000px"}:{},[e],'p0.value?{perspective:"9000px"}:{}')},[n("div",null,{class:u(a=>`absolute inset-0 ${a.value?"bg-gradient-to-l from-[#2e599a] to-[#182d4d] ":"bg-white !important"}   ${a.value?"overflow-y-hidden":"z-50"}`,[e],'`absolute inset-0 ${p0.value?"bg-gradient-to-l from-[#2e599a] to-[#182d4d] ":"bg-white !important"}   ${p0.value?"overflow-y-hidden":"z-50"}`')},i(ap,{get data(){return t.data.data.generalMenu.data.attributes},[s]:{data:u(a=>a.data.data.generalMenu.data.attributes,[t],'p0.data["data"]["generalMenu"]["data"]["attributes"]')}},3,"m8_0"),1,null),n("div",null,{class:u(a=>`relative transition-all duration-500 ${a.value?"overflow-y-hidden":"z-50"}`,[e],'`relative transition-all duration-500 ${p0.value?"overflow-y-hidden":"z-50"}`'),style:u(a=>a.value?{transform:"rotateY(-30deg) translateX(250px) translateY(200px)",transformStyle:"preserve-3d"}:{},[e],'p0.value?{transform:"rotateY(-30deg) translateX(250px) translateY(200px)",transformStyle:"preserve-3d"}:{}')},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-10 bg-gradient-to-l from-[#FFFFFF] to-[#C8D8ED]"},null,3,null),i(qd,{get data(){return t.data.data.generalMenu.data.attributes},mobMenuOpen:e,[s]:{data:u(a=>a.data.data.generalMenu.data.attributes,[t],'p0.data["data"]["generalMenu"]["data"]["attributes"]'),mobMenuOpen:s}},3,"m8_1"),n("div",null,{class:u(a=>`${a.value?"overflow-y-hidden":""}`,[e],'`${p0.value?"overflow-y-hidden":""}`')},[(t.showHeader??!0)&&n("div",null,{class:"flex w-full items-center justify-center"},i(Xd,{get data(){return t.data.data.generalHeader.data.attributes},[s]:{data:u(a=>a.data.data.generalHeader.data.attributes,[t],'p0.data["data"]["generalHeader"]["data"]["attributes"]')}},3,"m8_2"),1,"m8_3"),n("div",null,{class:"relative"},i(st,null,3,"m8_4"),1,null),i(Qd,{get data(){return t.data.data.generalFooter.data.attributes},[s]:{data:u(a=>a.data.data.generalFooter.data.attributes,[t],'p0.data["data"]["generalFooter"]["data"]["attributes"]')}},3,"m8_5")],1,null)],1,null)],1,"m8_6")},z=m(f(lp,"s_vumpf0PbXbo")),np=t=>{const e=t.customText?t.customText:t.SEOdata.MetaTitle.split(" |")[0];return!t.SEOdata&&!t.customText?n("h1",null,{class:"absolute opacity-0"},"RTA",3,"Yj_0"):n("h1",null,{class:"absolute opacity-0"},e,1,"Yj_1")},J=m(f(np,"s_SOxRNst40is")),sp=t=>n("div",{class:`flex w-full flex-col items-center justify-center ${t.alt??!1?"bg-white":"bg-[#e2eefa]"}
        ${t.backgroundColor&&`bg-${t.backgroundColor}`}`},null,[(t.alt??!1)&&i(H,{children:[n("div",null,{class:"h-8 w-full bg-[#ebf4fc]"},null,3,null),n("div",null,{class:"h-8 w-full bg-[#f7fafe]"},null,3,null)]},3,"9K_0"),n("div",null,{class:u(e=>`my-4 flex ${e.reverse??!1?"flex-row-reverse":""} max-w-[1200px] items-center justify-center max-[800px]:flex-col`,[t],'`my-4 flex ${p0.reverse??false?"flex-row-reverse":""} max-w-[1200px] items-center justify-center max-[800px]:flex-col`')},[n("div",null,{class:u(e=>`flex ${e.image&&`min-[800px]:w-[${(e.textPercentage??70).toString()}%]`}  flex-col items-center justify-center gap-4 px-10`,[t],"`flex ${p0.image&&`min-[800px]:w-[${(p0.textPercentage??70).toString()}%]`}  flex-col items-center justify-center gap-4 px-10`")},[t.logo&&n("div",null,{class:"max-w-[470px]"},n("img",{src:G(t.logo.url)},{alt:u(e=>e.logo.alternativeText,[t],'p0.logo["alternativeText"]'),height:"230",title:u(e=>e.logo.caption,[t],'p0.logo["caption"]'),width:"1230"},null,3,null),1,"9K_1"),n("div",null,{class:u(e=>`flex ${!(e.hasPricing??!0)&&"flex-col"} justify-center gap-2 text-${e.color??"primary-blue"}`,[t],'`flex ${!(p0.hasPricing??true)&&"flex-col"} justify-center gap-2 text-${p0.color??"primary-blue"}`')},[t.title&&n("h2",null,{class:"text-center text-[38px]  font-bold max-sm:text-[28px]"},u(e=>e.title,[t],"p0.title"),3,"9K_2"),t.subtitle&&n("h3",{class:`text-[28px] font-bold
                  ${t.backgroundColor&&t.backgroundColor.trim()!==""?"text-white":"text-secondary-red"}
                  ${t.hasPricing??!0?"":"text-center "} max-sm:text-[20px]`},null,u(e=>e.subtitle,[t],"p0.subtitle"),3,"9K_3")],1,null),i(C,{get text(){return t.text},get classN(){return`text-[18px] max-sm:text-[15px] text-${t.color??"primary-blue"}`},[s]:{classN:u(e=>`text-[18px] max-sm:text-[15px] text-${e.color??"primary-blue"}`,[t],'`text-[18px] max-sm:text-[15px] text-${p0.color??"primary-blue"}`'),text:u(e=>e.text,[t],"p0.text")}},3,"9K_4"),n("div",null,{class:"flex gap-4"},t.buttons&&t.buttons.map((e,a)=>i(X,{get text(){return e.Text},get link(){return e.Link},children:i(ed,{class:"text-[21px] opacity-60",color:"#13B295",[s]:{class:s,color:s}},3,"9K_5"),[s]:{link:x(e,"Link"),text:x(e,"Text")}},1,a)),1,null)],1,null),t.image&&n("div",{class:`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${(100-(t.textPercentage??70)).toString()}%] ${t.imageLink&&"cursor-pointer"}`},{onClick$:B("s_0a2swupHwgA",[t])},n("img",{src:G(t.image.url)},{alt:u(e=>e.image.alternativeText,[t],'p0.image["alternativeText"]'),height:"300",title:u(e=>e.image.caption,[t],'p0.image["caption"]'),width:"597"},null,3,null),1,"9K_6"),t.customComponent&&n("div",null,{class:u(e=>`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${(100-(e.textPercentage??70)).toString()}%]`,[t],"`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${(100-(p0.textPercentage??70)).toString()}%]`")},u(e=>e.customComponent,[t],"p0.customComponent"),3,"9K_7")],1,null),(t.alt??!1)&&i(H,{children:[n("div",null,{class:"h-8 w-full bg-[#f7fafe]"},null,3,null),n("div",null,{class:"h-8 w-full bg-[#ebf4fc]"},null,3,null)]},3,"9K_8")],1,"9K_9"),At=m(f(sp,"s_QAc0HW5bNAE")),rp=t=>i(At,{get logo(){return t.data.Logo&&t.data.Logo.data&&t.data.Logo.data.attributes},get image(){return t.data.Media&&t.data.Media.data&&t.data.Media.data.attributes},get title(){return t.data.Title},get subtitle(){return t.data.Subtitle},get text(){return t.data.Paragraph},get buttons(){return t.data.Buttons},get reverse(){return t.reverse??!1},get color(){return t.color??"primary-blue"},get alt(){return t.alt??!1},get hasPricing(){return t.hasPricing??!0},get textPercentage(){return t.textPercentage??70},get customComponent(){return t.customComponent},get backgroundColor(){return t.backgroundColor},imageLink:t.data.Media&&t.data.Media.data&&t.data.Media.data.attributes.caption.includes("http")?t.data.Media.data.attributes.caption:t.imageLink,[s]:{alt:u(e=>e.alt??!1,[t],"p0.alt??false"),backgroundColor:u(e=>e.backgroundColor,[t],"p0.backgroundColor"),buttons:u(e=>e.data.Buttons,[t],'p0.data["Buttons"]'),color:u(e=>e.color??"primary-blue",[t],'p0.color??"primary-blue"'),customComponent:u(e=>e.customComponent,[t],"p0.customComponent"),hasPricing:u(e=>e.hasPricing??!0,[t],"p0.hasPricing??true"),image:u(e=>e.data.Media&&e.data.Media.data&&e.data.Media.data.attributes,[t],'p0.data["Media"]&&p0.data["Media"]["data"]&&p0.data["Media"]["data"]["attributes"]'),logo:u(e=>e.data.Logo&&e.data.Logo.data&&e.data.Logo.data.attributes,[t],'p0.data["Logo"]&&p0.data["Logo"]["data"]&&p0.data["Logo"]["data"]["attributes"]'),reverse:u(e=>e.reverse??!1,[t],"p0.reverse??false"),subtitle:u(e=>e.data.Subtitle,[t],'p0.data["Subtitle"]'),text:u(e=>e.data.Paragraph,[t],'p0.data["Paragraph"]'),textPercentage:u(e=>e.textPercentage??70,[t],"p0.textPercentage??70"),title:u(e=>e.data.Title,[t],'p0.data["Title"]')}},3,"9K_10"),qt=m(f(rp,"s_Itm0b43i6oU")),ip=t=>i(H,{children:t.data.map((e,a)=>i(qt,{alt:a%2===0,data:e,reverse:a%2===0,get color(){return t.color??"primary-blue"},[s]:{color:u(l=>l.color??"primary-blue",[t],'p0.color??"primary-blue"')}},3,a))},1,"9K_11"),ee=m(f(ip,"s_0DQ5Kmfc4bA")),op=t=>n("div",null,{class:"flex max-w-[1200px] items-center justify-center self-center max-[800px]:flex-col"},[n("div",null,{class:"flex w-[300px] flex-col items-center justify-center self-center p-4 min-[800px]:w-[40%]"},[n("iframe",null,{allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",allowFullScreen:!0,class:"mb-5 rounded-[30px] shadow-md",frameBorder:"0",height:"250px",src:u(e=>`https://www.youtube.com/embed/${e.video.Link.split("v=")[1]}`,[t],'`https://www.youtube.com/embed/${p0.video["Link"].split("v=")[1]}`'),width:"100%"},null,3,null),i(C,{get text(){return t.video.Paragraph},classN:"px-3 max-sm:text-[14px] text-[16px] text-primary-blue text-justify",[s]:{classN:s,text:u(e=>e.video.Paragraph,[t],'p0.video["Paragraph"]')}},3,"tX_0")],1,null),n("div",null,{class:"flex flex-col items-center justify-center gap-4 px-10 min-[800px]:w-[60%]"},[n("h3",null,{class:"text-center text-[38px] font-bold text-primary-blue max-sm:text-[28px]"},u(e=>e.info.Title,[t],'p0.info["Title"]'),3,null),n("h4",null,{class:"text-center text-[38px] font-bold text-secondary-red max-sm:text-[28px]"},u(e=>e.info.Subtitle,[t],'p0.info["Subtitle"]'),3,null),n("div",null,null,i(C,{classN:"max-sm:text-[15px] text-[18px] text-primary-blue",get text(){return t.info.Paragraph},[s]:{classN:s,text:u(e=>e.info.Paragraph,[t],'p0.info["Paragraph"]')}},3,"tX_1"),1,null)],1,null)],1,"tX_2"),up=m(f(op,"s_ndQUOpucQqo")),cp=t=>n("div",null,{class:"relative flex h-full w-full items-center justify-center overflow-hidden"},[!(t.isFirst??!1)&&n("div",null,{class:"absolute bottom-[calc(50%+20px)] top-0 border-l-2 border-secondary-red"},null,3,"9r_0"),!(t.isLast??!1)&&n("div",null,{class:"absolute bottom-0 top-[calc(50%+20px)] border-l-2 border-secondary-red"},null,3,"9r_1"),n("div",null,{class:"flex h-[36px] w-[36px] items-center justify-center self-center rounded-full border border-secondary-red bg-transparent"},n("div",null,{class:"flex h-[30px] w-[30px] items-center justify-center rounded-full bg-secondary-red text-white"},u(e=>e.caption,[t],"p0.caption"),3,null),3,null)],1,"9r_2"),dp=t=>{const e=m(f(cp,"s_2AZJZ0GqJyo"));return(t.direction??"vertical")==="vertical"?n("div",null,{class:"grid w-fit items-center justify-around",style:u(a=>({gridTemplateColumns:(a.align??"start")==="center"?"1fr 60px 1fr":(a.align??"start")==="end"?"1fr 60px":"60px 1fr"}),[t],'{gridTemplateColumns:(p0.align??"start")==="center"?"1fr 60px 1fr":(p0.align??"start")==="end"?"1fr 60px":"60px 1fr"}')},t.steps.map((a,l)=>Z(i(H,{children:[(t.align??"start")!=="center"&&i(H,{children:[(t.align??"start")==="start"&&i(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_3"),n("div",null,{class:u(r=>`my-[20px] ${(r.align??"start")==="end"&&"ml-auto"} flex w-full flex-row items-center justify-center rounded-[50px] bg-white p-6 shadow-xl`,[t],'`my-[20px] ${(p0.align??"start")==="end"&&"ml-auto"} flex w-full flex-row items-center justify-center rounded-[50px] bg-white p-6 shadow-xl`')},i(C,{classN:"text-center",text:a,[s]:{classN:s}},3,"9r_4"),1,l),(t.align??"start")==="end"&&i(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_5")]},1,"9r_6"),(t.align??"start")==="center"&&i(H,{children:[n("div",null,{class:"flex w-fit flex-row items-center rounded-[50px] bg-white px-6 py-10 shadow-lg"},i(C,{classN:"text-center",text:a,[s]:{classN:s}},3,"9r_7"),1,l),l%2===0?i(H,{children:[i(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_8"),n("div",null,null,null,3,null),n("div",null,null,null,3,null),l+1<t.steps.length&&i(e,{caption:(l+2).toString(),isLast:l===t.steps.length},3,"9r_9")]},1,"9r_10"):i(H,null,3,"9r_11")]},1,"9r_12")]},1,"9r_13"))),1,"9r_14"):n("div",null,{class:"flex flex-row justify-between"},t.steps.map((a,l)=>n("div",null,{class:"flex flex-col items-center"},[n("div",null,{class:"h-2 w-2 rounded-full bg-primary-blue"},null,3,null),n("div",null,{class:"text-primary-blue"},a,1,null)],1,l)),1,null)},Oe=m(f(dp,"s_Zd6X64AupUo")),pp=t=>{const e=t.data.pageAcp.data.attributes,a=e.Steps.Bullets.map(l=>l.Text);return n("div",null,{onClick$:B("s_ey5yETkFTzM")},[i(qt,{get data(){return e.SummaryPar},alt:!0,hasPricing:!1,textPercentage:50,[s]:{alt:s,data:x(e,"SummaryPar"),hasPricing:s,textPercentage:s}},3,"ai_0"),n("div",null,{class:"flex w-full items-center justify-center"},i(up,{get info(){return e.InfoHowItWorks},get video(){return e.ACPVideo},[s]:{info:x(e,"InfoHowItWorks"),video:x(e,"ACPVideo")}},3,"ai_1"),1,null),n("div",null,{class:"mt-5 flex flex-col items-center justify-center bg-[#f2f6fb] pb-8"},[n("div",null,{class:"h-[32px] w-full bg-white opacity-70"},null,3,null),n("div",null,{class:"h-[32px] w-full bg-white opacity-40"},null,3,null),n("h2",null,{class:"px-6 pt-8 text-center text-[36px] font-[500] leading-9 text-primary-blue"},w(e.Steps,"Title"),1,null),n("div",null,{class:"px-6"},i(Oe,{steps:a},3,"ai_2"),1,null)],1,null)],1,"ai_3")},gp=m(f(pp,"s_00vzGmbsaMs")),fp=t=>`
  query QueryACP {
    pageAcp(locale:"${t}"){    
      data{
        attributes{
        
          SummaryPar{
            Title
            Subtitle
            Paragraph
            Media{
              ${b}
            }
          }
          
          ACPVideo{
            Link
            Paragraph
          }
          
          InfoHowItWorks{
            Title
            Subtitle
            Paragraph
          
          }
          
          Steps{
            Title
            Bullets{
              Title
              Text
            }
          }
          
          ${F}
        }
      }
    }
  }
    `,xp=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(fp,e)},Il=N(f(xp,"s_R1neS1rgBX0")),mp=()=>{const t=Il();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageAcp.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAcp.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAcp"]["data"]["attributes"]["SEO"]')}},3,"lm_0"),i(gp,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"lm_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"lm_2")},hp=m(f(mp,"s_clXmi6bmYdI")),$p=({resolveValue:t})=>{const a=t(Il).pageData.data.pageAcp.data.attributes.SEO;return Q(a)},bp=Object.freeze(Object.defineProperty({__proto__:null,default:hp,head:$p,usePageData:Il},Symbol.toStringTag,{value:"Module"})),vp=t=>{Z();const e=W(!0);return n("div",null,{class:"h-[550px] w-full  flex flex-col items-center justify-center"},[e.value?i(Yt,{size:"250px",[s]:{size:s}},3,"a3_0"):null,n("iframe",null,{class:"w-3/4 my-4 h-full rounded-3xl",id:"iframe-appre-giveaway",loading:"lazy",onLoad$:B("s_b0xkTBodv54",[e]),src:u(a=>a.data.iFrame_link,[t],'p0.data["iFrame_link"]')},null,3,null)],1,"a3_1")},yp=m(f(vp,"s_VzseIswtUxM")),wp=t=>`query QueryAprGive {
        pageAprGive(locale:"${t}"){
          data{
            attributes{
              iFrame_link
              ${F}
            }
          }
        }
        }`,_p=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(wp,e)},El=N(f(_p,"s_xcQxq8lbgb0")),Sp=()=>{const t=El();return i(H,{children:i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageAprGive.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAprGive.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAprGive"]["data"]["attributes"]["SEO"]')}},3,"kA_0"),i(yp,{get data(){return t.value.pageData.data.pageAprGive.data.attributes},[s]:{data:u(e=>e.value.pageData.data.pageAprGive.data.attributes,[t],'p0.value["pageData"]["data"]["pageAprGive"]["data"]["attributes"]')}},3,"kA_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"kA_2")},1,"kA_3")},Tp=m(f(Sp,"s_Py5O2s07X3c")),Dp=({resolveValue:t})=>{const a=t(El).pageData.data.pageAprGive.data.attributes.SEO;return Q(a)},Pp=Object.freeze(Object.defineProperty({__proto__:null,default:Tp,head:Dp,usePageData:El},Symbol.toStringTag,{value:"Module"})),kp=t=>{Z();const e=t.data.data.pageAprLead.data.attributes,a=W(!0);return n("div",null,{class:"flex flex-wrap px-8 items-center justify-center"},[n("div",null,{class:"flex flex-col items-center justify-center w-full md:w-1/2"},[n("div",null,{class:"relative h-[600px] w-[80%] flex flex-col items-center justify-center"},[n("img",{alt:w(e.zane_lead.bg_pic.data.attributes,"alternativeText"),src:G(e.zane_lead.bg_pic.data.attributes.url),title:w(e.zane_lead.bg_pic.data.attributes,"caption")},{class:"",height:"650",width:"650"},null,3,null),n("img",{alt:w(e.zane_lead.zane_pic.data.attributes,"alternativeText"),src:G(e.zane_lead.zane_pic.data.attributes.url)},{class:"absolute flex rounded-full h-3/4 w-auto",height:250,width:250},null,3,null),n("img",{src:G(e.zane_lead.tv_pic.data.attributes.url)},{alt:"",class:"absolute h-[10%] w-auto top-20 right-10",height:"50",width:"50"},null,3,null),n("img",{src:G(e.zane_lead.wifi_pic.data.attributes.url)},{alt:"",class:"absolute bottom-10 h-[10%] w-auto left-5",height:"50",width:"50"},null,3,null),n("img",{src:G(e.zane_lead.phone_pic.data.attributes.url)},{alt:"",class:"absolute top-10 left-10 h-[10%] w-auto",height:"50",width:"50"},null,3,null),n("div",null,{class:"absolute left-1/2 top-5 flex flex-row text-primary-blue bg-white items-center justify-center p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},i(E,{height:20,toWhite:!0,width:20,get url(){return e.zane_lead.give_pic.data.attributes.url},get alt(){return e.zane_lead.give_pic.data.attributes.alternativeText},[s]:{alt:x(e.zane_lead.give_pic.data.attributes,"alternativeText"),height:s,toWhite:s,url:x(e.zane_lead.give_pic.data.attributes,"url"),width:s}},3,"q7_0"),1,null),"Price"],1,null),n("div",null,{class:"absolute w-fit h-fit bottom-0 left-1/2 flex flex-row text-primary-blue bg-white items-center justify-evenly p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},i(E,{height:20,toWhite:!0,width:20,get url(){return e.zane_lead.auto_pic.data.attributes.url},get alt(){return e.zane_lead.auto_pic.data.attributes.alternativeText},[s]:{alt:x(e.zane_lead.auto_pic.data.attributes,"alternativeText"),height:s,toWhite:s,url:x(e.zane_lead.auto_pic.data.attributes,"url"),width:s}},3,"q7_1"),1,null),"Live Events"],1,null),n("div",null,{class:"absolute w-fit h-fit flex flex-row left-3/4 bottom-1/4 text-primary-blue bg-white items-center justify-evenly p-2 rounded-full"},[n("div",null,{class:"h-[25px] w-[25px] rounded-full  bg-secondary-red p-1"},i(E,{height:20,toWhite:!0,width:20,get url(){return e.zane_lead.cota_pic.data.attributes.url},get alt(){return e.zane_lead.cota_pic.data.attributes.alternativeText},[s]:{alt:x(e.zane_lead.cota_pic.data.attributes,"alternativeText"),height:s,toWhite:s,url:x(e.zane_lead.cota_pic.data.attributes,"url"),width:s}},3,"q7_2"),1,null),"Discounts"],1,null),n("div",null,{class:"absolute w-fit h-fit flex flex-row justify-evenly left-0  text-primary-blue bg-white items-center p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},i(E,{height:20,toWhite:!0,width:20,get url(){return e.zane_lead.auto_pic.data.attributes.url},get alt(){return e.zane_lead.auto_pic.data.attributes.alternativeText},[s]:{alt:x(e.zane_lead.auto_pic.data.attributes,"alternativeText"),height:s,toWhite:s,url:x(e.zane_lead.auto_pic.data.attributes,"url"),width:s}},3,"q7_3"),1,null),"Live Events"],1,null)],1,null),n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,{class:"text-xl text-center font-medium text-primary-blue"},w(e,"zane_description"),1,null),n("img",{src:G(e.zane_banner.banner_pic.data.attributes.url)},{alt:"",height:"78",width:"400"},null,3,null),n("div",null,{class:"flex flex-row items-center gap-5 justify-evenly my-5"},[n("div",null,{class:"bg-primary-blue text-white flex flex-col rounded-full items-center justify-center w-fit px-10 py-2"},[n("h2",null,{class:"text-sm text-center font-bold"},w(e.date_race,"Text"),1,null),n("p",null,{class:"text-sm text-center"},w(e.date_race,"Link"),1,null)],1,null),i(X,{get text(){return e.button_promo.text},get link(){return e.button_promo.link},[s]:{link:x(e.button_promo,"link"),text:x(e.button_promo,"text")}},3,"q7_4")],1,null)],1,null)],1,null),n("div",null,{class:"w-full md:w-2/6 shadow-2xl rounded-2xl h-[500px]"},[a.value?i(Yt,{size:"250px",[s]:{size:s}},3,"q7_5"):null,n("iframe",{src:w(e,"iFrame_link")},{class:"w-full  rounded-2xl h-full",id:"iframe-appre-lead",loading:"lazy",onLoad$:B("s_M94pZoIEeB0",[a])},null,3,null)],1,null)],1,"q7_6")},Lp=m(f(kp,"s_0jvpiBD6mW4")),Mp=t=>`query QueryPageAprLead {
        pageAprLead(locale:"${t}"){
          data {
            attributes {
              zane_lead {
                zane_pic {
                    ${b}
                }
                give_pic {
                    ${b}
                }
                cota_pic {
                    ${b}
                }
                auto_pic {
                    ${b}
                }
                live_pic {
                    ${b}
                }
                phone_pic {
                    ${b}
                }
                tv_pic {
                    ${b}
                }
                wifi_pic {
                    ${b}
                }
                bg_pic {
                    ${b}
                }
              }
              zane_banner {
                banner_pic {
                    ${b}
                }
              }
              zane_description
              iFrame_link
              date_race {
                Text
                Link
                Icon {
                  ${b}
                }
              }
              button_promo {
                text
                icon {
                  ${b}
                }
                link
              }
              pricing_box {
                Title
                Subtitle
                Pricing
                Period
                bg {
                  ${b}
                }
                Icon {
                  ${b}
                }
              }
              car {
                car_pic {
                  ${b}
                }
              }
              ${F}
              
            }
          }
        }
      }`,Cp=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Mp,e)},Ol=N(f(Cp,"s_05Sy9vG0VbY")),jp=()=>{const t=Ol();return i(H,{children:i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageAprLead.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAprLead.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAprLead"]["data"]["attributes"]["SEO"]')}},3,"LY_0"),i(Lp,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"LY_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"LY_2")},1,"LY_3")},Ip=m(f(jp,"s_32Qq7YbePEg")),Ep=({resolveValue:t})=>{const a=t(Ol).pageData.data.pageAprLead.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},Op=Object.freeze(Object.defineProperty({__proto__:null,default:Ip,head:Ep,usePageData:Ol},Symbol.toStringTag,{value:"Module"})),Bp=t=>n("div",null,{class:"text-center"},[n("div",null,{class:"bg-primary-blue bg-opacity-40 p-6 h-[310px] w-[310px] inline-block items-center justify-center rounded-full"},n("div",null,{class:"bg-primary-blue flex h-full w-full items-center justify-center  rounded-full bg-opacity-60 px-6 py-6 shadow-md"},n("div",null,{class:"bg-primary-blue flex flex-col h-full w-full items-center justify-around rounded-full shadow-md"},[n("div",null,{class:"flex flex-col items-center"},[n("img",{src:G(t.award.Icon.data.attributes.url)},{alt:u(e=>e.award.Icon.data.attributes.alternativeText,[t],'p0.award["Icon"]["data"]["attributes"]["alternativeText"]'),height:40,title:u(e=>e.award.Icon.data.attributes.caption,[t],'p0.award["Icon"]["data"]["attributes"]["caption"]'),width:40},null,3,null),n("h2",null,{class:"text-l text-white font-semibold text-center"},u(e=>e.award.Title,[t],'p0.award["Title"]'),3,null),n("p",null,{class:"text-center text-sm font-light text-white leading-8"},u(e=>e.award.Award,[t],'p0.award["Award"]'),3,null)],1,null),n("a",null,{class:"text-white font-semibold",href:u(e=>e.award.Button.Link,[t],'p0.award["Button"]["Link"]'),target:"_blank"},u(e=>e.award.Button.Text,[t],'p0.award["Button"]["Text"]'),3,null)],1,null),1,null),1,null),n("h2",null,{class:"text-3xl font-semibold text-primary-blue"},u(e=>e.award.Year,[t],'p0.award["Year"]'),3,null)],1,"5M_0"),Ap=t=>{const e=t.data.data.pageAward.data.attributes,a=m(f(Bp,"s_fwfHmjnV3nY")),l=e.Awards.map((r,o)=>i(a,{award:r},3,o));return n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"w-3/4"},[n("h1",null,{class:"text-center text-4xl font-bold text-primary-blue"},w(e,"Title"),1,null),i(C,{classN:"text-center",get text(){return e.Description},[s]:{classN:s,text:x(e,"Description")}},3,"5M_1")],1,null),n("div",null,{class:"w-full h-[500px] relative items-center justify-center overflow-hidden"},[n("div",null,{class:"h-full w-full absolute bg-opacity-50"},n("img",{alt:w(e.Background.data.attributes,"alternativeText"),src:G(e.Background.data.attributes.url)},{class:"object-fill opacity-50",height:500,width:1200},null,3,null),1,null),n("div",null,{class:"h-full w-full flex items-center justify-center absolute"},i(St,{duration:3e3,hasPagination:!0,id:"awardsSlider",slides:l,[s]:{duration:s,hasPagination:s,id:s}},3,"5M_2"),1,null)],1,null)],1,"5M_3")},Np=m(f(Ap,"s_DHWUiZRKjUc")),qp=t=>`query {
        pageAward(locale:"${t}"){
          data {
            attributes {
              Title
              Description
              
              Background {
                ${b}
              }
              
              Awards {
                Title
                Award
                Year
                Background {
                  ${b}
                }
                Icon {
                  ${b}
                }
                Button{
                  Text
                  Link
                }
              }
      
              ${F}
            }
          }
        }
      }`,Rp=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(qp,e)},Bl=N(f(Rp,"s_sqeXWQdLNKw")),zp=()=>{const t=Bl();return i(z,{get data(){return t.value.layoutData},children:i(Np,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"Q2_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Q2_1")},Fp=m(f(zp,"s_YOAlBnNiDxQ")),Gp=({resolveValue:t})=>{const a=t(Bl).pageData.data.pageAward.data.attributes.SEO;return Q(a)},Qp=Object.freeze(Object.defineProperty({__proto__:null,default:Fp,head:Gp,usePageData:Bl},Symbol.toStringTag,{value:"Module"})),Hp=t=>{const e=(a,l)=>a.slice(0,l)+"...";return n("div",null,{class:"flex max-w-[1200px] flex-row-reverse items-center justify-center self-center px-8 py-4 max-[800px]:flex-col-reverse"},[n("div",null,{class:"flex  flex-col items-center justify-start  gap-4 px-10 min-[800px]:w-[60%]"},[n("div",null,{class:""},[n("div",null,{class:"text-[32px] font-[600] leading-10 text-[#2E5899] max-sm:text-[24px] max-sm:leading-7"},u(a=>a.post.Title,[t],'p0.post["Title"]'),3,null),n("div",null,null,i(C,{classN:"max-sm:text-[13px] text-[16px] text-[#2E5899] text-justify ",text:e(t.post.Description,500),[s]:{classN:s}},3,"su_0"),1,null)],1,null),i(X,{text:"Read More",get link(){return`/${t.post.Slug}/`},[s]:{link:u(a=>`/${a.post.Slug}/`,[t],'`/${p0.post["Slug"]}/`'),text:s}},3,"su_1")],1,null),n("div",null,{class:"flex w-full items-center justify-center self-center p-4 min-[800px]:w-[40%]"},i(E,{get url(){return t.post.Cover.data.attributes.url},get alt(){return t.post.Cover.data.attributes.alternativeText},get title(){return t.post.Cover.data.attributes.caption},clasN:"rounded-[50px] shadow-2xl",height:"894",width:"1184",[s]:{alt:u(a=>a.post.Cover.data.attributes.alternativeText,[t],'p0.post["Cover"]["data"]["attributes"]["alternativeText"]'),clasN:s,height:s,title:u(a=>a.post.Cover.data.attributes.caption,[t],'p0.post["Cover"]["data"]["attributes"]["caption"]'),url:u(a=>a.post.Cover.data.attributes.url,[t],'p0.post["Cover"]["data"]["attributes"]["url"]'),width:s}},3,"su_2"),1,null)],1,"su_3")},Dr=m(f(Hp,"s_KKagOAzP0DM")),Wp=t=>{const e=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],a=["January","February","March","April","May","June","July","August","September","October","November","December"];function l(o){const c=e[o.getDay()],d=o.getDate(),p=a[o.getMonth()],g=o.getFullYear();return`${c}, ${p} ${d}, ${g}`}const r=(o,c)=>o.slice(0,c)+"...";return n("div",null,{class:"mb-8 flex max-w-[300px] flex-col",id:u(o=>o.id,[t],"p0.id")},[i(E,{clasN:"rounded-2xl self-center object-cover h-[200px] w-[300px]",height:"894",width:"1184",get url(){return t.post.attributes.Cover.data.attributes.url},get alt(){return t.post.attributes.Cover.data.attributes.alternativeText},get title(){return t.post.attributes.Cover.data.attributes.caption},[s]:{alt:u(o=>o.post.attributes.Cover.data.attributes.alternativeText,[t],'p0.post["attributes"]["Cover"]["data"]["attributes"]["alternativeText"]'),clasN:s,height:s,title:u(o=>o.post.attributes.Cover.data.attributes.caption,[t],'p0.post["attributes"]["Cover"]["data"]["attributes"]["caption"]'),url:u(o=>o.post.attributes.Cover.data.attributes.url,[t],'p0.post["attributes"]["Cover"]["data"]["attributes"]["url"]'),width:s}},3,"j0_0"),n("span",null,{class:"px-3 py-1 font-[600] text-primary-blue opacity-70"},l(new Date(t.post.attributes.Date)),1,null),n("span",null,{class:"px-3 text-primary-blue"},n("div",{dangerouslySetInnerHTML:Vn(r(t.post.attributes.Description,120))},{class:"flex list-inside flex-col gap-3 text-justify text-sm"},null,3,null),1,null),n("div",null,{class:"mt-2 self-center"},i(X,{text:"Read More",get link(){return`/${[t.post.attributes.Slug]}`},[s]:{link:u(o=>`/${[o.post.attributes.Slug]}`,[t],'`/${[p0.post["attributes"]["Slug"]]}`'),text:s}},3,"j0_1"),1,null)],1,"j0_2")},Up=m(f(Wp,"s_KUqCzJ00kfw")),Vp=t=>{var c;const a=(c=Ht().prevUrl)!=null&&c.pathname.includes("/es/")?"es-419":"en",l=W(t.posts.slice(1,(t.loadSize??6)+1)),r=W(!1),o=W(1);return n("div",{"document:onscroll$":B("s_t0DoAQDJl4Y",[a,r,o,t,l])},{class:"grid w-full max-w-[1200px] grid-cols-3 justify-evenly gap-4 max-[800px]:grid-cols-1 [&>*]:justify-self-center",id:"postLoader"},l.value.map((d,p)=>i(Up,{id:`post-${p.toString()}`,post:d},3,p)),0,"4a_0")},Pr=m(f(Vp,"s_HS0GyQ0UHYM")),Yp=t=>n("div",null,{class:"flex flex-col items-center justify-center w-fit "},n("div",null,{class:"  px-2 mb-8  md:max-h-[150px]  overflow-y-scroll"},i(C,{classN:"text-[12.5px]",get text(){return t.slide.attributes.Content},[s]:{classN:s,text:u(e=>e.slide.attributes.Content,[t],'p0.slide["attributes"]["Content"]')}},3,"9l_0"),1,null),1,"9l_1"),Zp=t=>{const e=t.data.TechTips.data,a=m(f(Yp,"s_0D1CtJAueP4")),l=e.map((r,o)=>i(a,{slide:r},3,o));return n("div",null,{class:" gap-2 flex flex-row bg-white p-3 md:rounded-full rounded-3xl md:w-[750px] w-[90%] shadow-lg items-center"},[n("div",null,null,n("div",null,{class:"bg-[#2e5899] p-5 rounded-full shadow-lg md:min-h-[130px] md:max-w-[130px] md:max-h-[130px] max-w-[80px] flex justify-center items-center max-[768px]:hidden	"},n("div",null,{class:"bg-white md:p-5 p-2 w-fit h-fit items-center rounded-full shadow-lg shadow-inner"},i(xd,{class:" md:w-[45px] md:h-[45px] w-[20px] h-[20px] fill-[#2e5899]",[s]:{class:s}},3,"9l_2"),1,null),1,null),1,null),n("div",null,{class:" justify-center items-center  md:w-[650px] max-w-[100%]"},[n("div",null,{class:"text-[18px] tracking-wide font-[600] leading-10 text-[#2E5899]"},u(r=>r.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"h-fit relative flex md:w-[650px] max-w-[90%]  items-center justify-center overflow-hidden   "},i(St,{addSpace:!1,hasArrows:!1,id:"techTipsCarousel",slides:l,slidesQty:1,[s]:{addSpace:s,hasArrows:s,id:s,slidesQty:s}},3,"9l_3"),1,null)],1,null)],1,"9l_4")},Kp=m(f(Zp,"s_600c5npFpQo")),Xp=t=>{const e=t.data.pageBlog.data.attributes,a=e.Posts.data[0].attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(Kp,{get data(){return e.Tips},[s]:{data:x(e,"Tips")}},3,"LH_0"),i(Dr,{post:a},3,"LH_1"),n("div",null,{class:"my-4"},null,3,null),i(Pr,{get posts(){return e.Posts.data},loadSize:3,type:"Blog",[s]:{loadSize:s,posts:x(e.Posts,"data"),type:s}},3,"LH_2")],1,"LH_3")},Jp=m(f(Xp,"s_lTYqJJcPHc4")),t0=t=>` query QueryBlog {
        pageBlog(locale:"${t}"){    
          data{
          attributes{
            Tips{
              Title
              TechTips(sort: "Date:desc", pagination: { limit: 10 }){
                data{
                  attributes{
                    Content
                  }
                }
              }
            }
            Posts(sort: "Date:desc", pagination: { limit: 100 }){
                data{
                  attributes{
                    Title
                    Date
                    Cover{
                      ${b}
                    }
                    Description
                    VideoLink
                    Gallery{
                      ${b}
                    }
                    Slug
                  }
                }
              }
          
            ${F}
          }
        }
        }
      }`,e0=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(t0,e)},Al=N(f(e0,"s_PlB05JNPqRo")),a0=()=>{const t=Al();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageBlog.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageBlog.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBlog"]["data"]["attributes"]["SEO"]')}},3,"Yn_0"),i(Jp,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Yn_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Yn_2")},l0=m(f(a0,"s_WiOXv30Ec4Y")),n0=({resolveValue:t})=>{const a=t(Al).pageData.data.pageBlog.data.attributes.SEO;return Q(a)},s0=Object.freeze(Object.defineProperty({__proto__:null,default:l0,head:n0,usePageData:Al},Symbol.toStringTag,{value:"Module"})),r0=t=>n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} bg-opacity-40 p-6 ${e.height??""} ${e.width??""} inline-block items-center justify-center rounded-full`,[t],'`${p0.color??"bg-[#2E5899]"} bg-opacity-40 p-6 ${p0.height??""} ${p0.width??""} inline-block items-center justify-center rounded-full`')},n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md`,[t],'`${p0.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md`')},n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md`,[t],'`${p0.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md`')},n("img",{src:G(t.url)},{alt:u(e=>e.alt??"",[t],'p0.alt??""'),class:"h-full w-full rounded-full object-cover",height:250,title:u(e=>e.title??"",[t],'p0.title??""'),width:250},null,3,null),1,null),1,null),1,"03_0"),Be=m(f(r0,"s_CA0rJqJDom0")),i0=t=>n("div",null,{class:"flex w-fit flex-wrap gap-12 md:gap-20 m-5 items-center justify-center"},t.data.MembersGrid.map((e,a)=>Z(n("div",null,{class:"w-[300px] h-[300px] items-center justify-around flex flex-col"},[i(Be,{height:"h-[200px]",width:"w-[200px]",get url(){return e.Picture.data.attributes.url},get alt(){return e.Picture.data.attributes.alternativeText},get title(){return e.Picture.data.attributes.caption},[s]:{alt:x(e.Picture.data.attributes,"alternativeText"),height:s,title:x(e.Picture.data.attributes,"caption"),url:x(e.Picture.data.attributes,"url"),width:s}},3,"Q1_0"),n("h2",null,{class:"font-bold text-primary-blue text-xl"},[w(e,"FirstName")," ",w(e,"LastName")],1,null),n("p",null,{class:"text-sm text-primary-blue"},w(e,"Position"),1,null),e.SocialMedia.length>0&&n("a",{href:w(e.SocialMedia[0],"Link")},null,n("div",null,{class:"h-[30px] w-[30px] flex items-center justify-center bg-white shadow rounded-full p-1.5"},i(Zc,{class:"fill-primary-blue",[s]:{class:s}},3,"Q1_1"),1,null),1,"Q1_2")],1,a))),1,"Q1_3"),kr=m(f(i0,"s_fHxbC9gELko")),o0=t=>`query QueryBoardOfDirectors{
        pageBDirectors(locale:"${t}"){
          data{
            attributes{
              ${$r}
              ${F}
              }
            }
          }
        }`,u0=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(o0,e)},Nl=N(f(u0,"s_zIMYdRdJ00w")),c0=()=>{const t=Nl(),e=t.value.pageData.data.pageBDirectors.data.attributes;return i(H,{children:i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageBDirectors.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageBDirectors.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBDirectors"]["data"]["attributes"]["SEO"]')}},3,"ts_0"),i(kr,{data:e},3,"ts_1")],showHeader:!0,[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"ts_2")},1,"ts_3")},d0=m(f(c0,"s_IBN44L8LT0g")),p0=({resolveValue:t})=>{const a=t(Nl).pageData.data.pageBDirectors.data.attributes.SEO;return Q(a)},g0=Object.freeze(Object.defineProperty({__proto__:null,default:d0,head:p0,usePageData:Nl},Symbol.toStringTag,{value:"Module"})),f0=t=>{const e=t.data.pageBusiness.data.attributes.Services;return n("div",null,null,i(ee,{data:e},3,"zl_0"),1,"zl_1")},x0=m(f(f0,"s_u188pr8UG0M")),m0=t=>`query QueryBusiness {
    pageBusiness(locale:"${t}"){    
      data{
        attributes{
          Services{
            Logo{
              ${b}
            }
            Media{
              ${b}
            }
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
             ${F}
  
        }
      }
    }
  }`,h0=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(m0,e)},ql=N(f(h0,"s_oQUmv8Ne7NI")),$0=()=>{const t=ql();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageBusiness.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageBusiness.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBusiness"]["data"]["attributes"]["SEO"]')}},3,"Uj_0"),i(x0,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Uj_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Uj_2")},b0=m(f($0,"s_JufSC5OrOV4")),v0=({resolveValue:t})=>{const a=t(ql).pageData.data.pageBusiness.data.attributes.SEO;return Q(a)},y0=Object.freeze(Object.defineProperty({__proto__:null,default:b0,head:v0,usePageData:ql},Symbol.toStringTag,{value:"Module"})),w0=t=>n("div",null,{class:"relative flex w-full items-center justify-center"},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 z-10 grid",style:{gridTemplateRows:"35px 35px 1fr 35px 35px",gridTemplateColumns:"100%"}},[n("div",null,{class:"bg-white opacity-50"},null,3,null),n("div",null,{class:"bg-white opacity-80"},null,3,null),n("div",null,{class:"bg-white "},null,3,null),n("div",null,{class:"bg-white opacity-80"},null,3,null),n("div",null,{class:"bg-white opacity-50"},null,3,null)],3,null),n("div",null,{class:"z-10 flex flex-wrap items-center justify-center px-8 text-center text-[30px] font-[700] text-primary-blue"},[i(E,{clasN:"w-[300px] max-[1000px]:hidden",get url(){return t.data.HeaderPictures.data[0].attributes.url},get alt(){return t.data.HeaderPictures.data[0].attributes.alternativeText},get title(){return t.data.HeaderPictures.data[0].attributes.caption},[s]:{alt:u(e=>e.data.HeaderPictures.data[0].attributes.alternativeText,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]["alternativeText"]'),clasN:s,title:u(e=>e.data.HeaderPictures.data[0].attributes.caption,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]["caption"]'),url:u(e=>e.data.HeaderPictures.data[0].attributes.url,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]["url"]')}},3,"bE_0"),n("div",null,{class:"flex flex-col"},[n("span",null,null,"Join the",3,null),i(E,{clasN:"w-[200px]",get url(){return t.data.HeaderLogo.data.attributes.url},get alt(){return t.data.HeaderLogo.data.attributes.alternativeText},get title(){return t.data.HeaderLogo.data.attributes.caption},[s]:{alt:u(e=>e.data.HeaderLogo.data.attributes.alternativeText,[t],'p0.data["HeaderLogo"]["data"]["attributes"]["alternativeText"]'),clasN:s,title:u(e=>e.data.HeaderLogo.data.attributes.caption,[t],'p0.data["HeaderLogo"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.HeaderLogo.data.attributes.url,[t],'p0.data["HeaderLogo"]["data"]["attributes"]["url"]')}},3,"bE_1"),n("span",null,null,"Family",3,null)],1,null),i(E,{clasN:"w-[300px]",get url(){return t.data.HeaderPictures.data[1].attributes.url},get alt(){return t.data.HeaderPictures.data[1].attributes.alternativeText},get title(){return t.data.HeaderPictures.data[1].attributes.caption},[s]:{alt:u(e=>e.data.HeaderPictures.data[1].attributes.alternativeText,[t],'p0.data["HeaderPictures"]["data"][1]["attributes"]["alternativeText"]'),clasN:s,title:u(e=>e.data.HeaderPictures.data[1].attributes.caption,[t],'p0.data["HeaderPictures"]["data"][1]["attributes"]["caption"]'),url:u(e=>e.data.HeaderPictures.data[1].attributes.url,[t],'p0.data["HeaderPictures"]["data"][1]["attributes"]["url"]')}},3,"bE_2")],1,null)],1,"bE_3"),_0=m(f(w0,"s_YWCAmY4twe0")),S0=t=>n("div",null,{class:"flex h-[250px] w-[170px] flex-col items-center justify-start gap-3 rounded-[16px] bg-white p-3 text-center shadow-lg"},[i(E,{clasN:"h-[80px] w-[100%] object-cover rounded-[16px] bg-primary-blue bg-opacity-10",get url(){return t.offer.Media.data.attributes.url},get alt(){return t.offer.Media.data.attributes.alternativeText},get title(){return t.offer.Media.data.attributes.caption},height:"120",width:"240",[s]:{alt:u(e=>e.offer.Media.data.attributes.alternativeText,[t],'p0.offer["Media"]["data"]["attributes"]["alternativeText"]'),clasN:s,height:s,title:u(e=>e.offer.Media.data.attributes.caption,[t],'p0.offer["Media"]["data"]["attributes"]["caption"]'),url:u(e=>e.offer.Media.data.attributes.url,[t],'p0.offer["Media"]["data"]["attributes"]["url"]'),width:s}},3,"IA_0"),n("h3",null,{class:"text-[18px] font-[600]"},u(e=>e.offer.Title,[t],'p0.offer["Title"]'),3,null),n("p",null,{class:"text-[14px] font-[400]"},u(e=>e.offer.Paragraph,[t],'p0.offer["Paragraph"]'),3,null)],1,"IA_1"),T0=t=>{const e=m(f(S0,"s_7vgX9wWJy0Y"));return n("div",null,{class:"flex w-full justify-center px-8"},n("div",null,{class:"mt-10 flex max-w-[1400px] items-center justify-center gap-8 px-8 text-center text-primary-blue max-[1000px]:flex-col"},[n("div",null,{class:"flex w-[50%] flex-col max-[1000px]:w-[100%]"},[n("h3",null,{class:"mt-3 text-[40px] font-[700]"},u(a=>a.data.BeliefsTitle,[t],'p0.data["BeliefsTitle"]'),3,null),n("span",null,{class:"text-[28px] font-[600]"},u(a=>a.data.BeliefsSubtitle,[t],'p0.data["BeliefsSubtitle"]'),3,null),n("span",null,{class:"text-[26px] font-[600] text-secondary-red"},u(a=>a.data.Beliefs[0].Text,[t],'p0.data["Beliefs"][0]["Text"]'),3,null),n("p",null,{class:"mt-3 text-[20px]"},u(a=>a.data.BeliefsDescription,[t],'p0.data["BeliefsDescription"]'),3,null)],3,null),n("div",null,{class:"flex w-[50%] flex-col items-center justify-center max-[1000px]:w-[100%]"},[n("h4",null,{class:"text-[40px] font-[700]"},u(a=>a.data.OfferingTitle,[t],'p0.data["OfferingTitle"]'),3,null),n("div",null,{class:"mt-4 flex flex-wrap justify-center gap-6"},t.data.Offerings.map((a,l)=>i(e,{offer:a},3,l)),1,null)],1,null)],1,null),1,"IA_2")},D0=m(f(T0,"s_rLVOk7WyC5I")),P0=t=>{const e=W("duties");return n("div",null,{class:"flex w-[60%] min-w-[310px] max-w-[550px] flex-col items-center rounded-[50px] bg-white p-8 text-primary-blue"},[n("div",null,{class:"mb-2 flex items-center gap-1"},[i(jl,{class:"text-secondary-red",[s]:{class:s}},3,"H3_0"),n("span",null,{class:"text-[14px] opacity-60"},u(a=>a.data.Location,[t],'p0.data["Location"]'),3,null)],1,null),n("h4",null,{class:"mb-4 text-center text-[20px] font-[600] leading-7 text-primary-dark-blue"},u(a=>a.data.Name,[t],'p0.data["Name"]'),3,null),n("div",null,{class:"relative my-4 flex w-[300px] justify-between gap-2 overflow-hidden rounded-[30px] border border-primary-blue border-opacity-60 px-6 py-2"},[n("div",{class:`absolute bottom-0 transition-all ${e.value==="duties"?"left-0 right-[55%]":"left-[45%] right-0"} top-0 z-[1] rounded-[30px] bg-primary-blue shadow-sm`},null,null,3,null),n("div",null,{class:"z-[2] flex w-[45%] cursor-pointer items-center gap-1 px-2",onClick$:B("s_m2mi5sfy3GQ",[e])},[n("div",null,{class:"flex h-6 w-6 items-center justify-center rounded-full bg-white p-1"},i(Jc,{class:"text-secondary-red",[s]:{class:s}},3,"H3_1"),1,null),n("span",null,{class:u(a=>`font-[400] text-${a.value==="duties"?"white":"primary-blue"}`,[e],'`font-[400] text-${p0.value==="duties"?"white":"primary-blue"}`')},"Duties",3,null)],1,null),n("div",null,{class:"z-[2] flex w-[55%] cursor-pointer items-center gap-1 px-2",onClick$:B("s_ynhdzdQwHCA",[e])},[n("div",null,{class:"flex h-6 w-6 items-center justify-center rounded-full bg-white p-1"},i(td,{class:"text-secondary-red",[s]:{class:s}},3,"H3_2"),1,null),n("span",null,{class:u(a=>`font-[400] text-${a.value==="qualifications"?"white":"primary-blue"}`,[e],'`font-[400] text-${p0.value==="qualifications"?"white":"primary-blue"}`')},"Qualifications",3,null)],1,null)],1,null),n("div",null,{class:"relative flex h-[200px] w-full overflow-x-hidden text-[13px] leading-4 transition-all "},[n("div",null,{class:u(a=>`absolute h-[200px] w-full p-4 transition-all ${a.value!=="duties"?"right-full":" right-0"}`,[e],'`absolute h-[200px] w-full p-4 transition-all ${p0.value!=="duties"?"right-full":" right-0"}`')},i(C,{get text(){return t.data.Duties},[s]:{text:u(a=>a.data.Duties,[t],'p0.data["Duties"]')}},3,"H3_3"),1,null),n("div",null,{class:u(a=>`absolute h-[200px] w-full p-4 transition-all ${a.value!=="qualifications"?"left-full":"left-0"}`,[e],'`absolute h-[200px] w-full p-4 transition-all ${p0.value!=="qualifications"?"left-full":"left-0"}`')},i(C,{get text(){return t.data.Qualifications},[s]:{text:u(a=>a.data.Qualifications,[t],'p0.data["Qualifications"]')}},3,"H3_4"),1,null)],1,null)],1,"H3_5")},k0=m(f(P0,"s_kNPEZsb0EOk")),L0=()=>{const t=W("NONE");return n("div",null,{class:"flex flex-col w-full md:w-1/2 h-[560px] bg-blue-100 rounded-2xl p-4"},[n("p",null,{class:"text-center font-medium text-color-Primary"},"Fill out the form below and attach your resume to contact us today",3,null),n("form",null,{class:"mt-2 overflow-y-auto",id:"form_careers",onSubmit$:B("s_i05DmpZA0BU",[t])},[n("div",null,{class:"flex-col sm:flex-row flex justify-between"},[n("div",null,{class:"mb-4 gap-2 w-full flex flex-col mr-0 md:mr-4"},[n("label",null,{class:"block font-medium text-color-Primary",for:"from_name"},"Name",3,null),n("input",null,{class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",id:"from_name",name:"from_name",type:"text"},null,3,null)],3,null),n("div",null,{class:"mb-4 gap-2 w-full flex flex-col"},[n("label",null,{class:"block font-medium text-color-Primary",for:"tel"},"Phone",3,null),n("input",null,{class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",id:"tel",maxLength:10,name:"tel",type:"tel"},null,3,null)],3,null)],3,null),n("div",null,{class:"mb-4 gap-2 flex flex-col"},[n("label",null,{class:"block font-medium text-color-Primary",for:"from_email"},"Email",3,null),n("input",null,{class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",id:"from_email",name:"from_email",required:!0,type:"email"},null,3,null)],3,null),n("div",null,{class:"mb-4 gap-2 flex flex-col"},[n("label",null,{class:"block  font-medium text-color-Primary",for:"message"},"Message",3,null),n("textarea",null,{class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",id:"message",name:"message",required:!0,rows:4},null,3,null)],3,null),n("label",null,{class:"flex w-[200px] text-color-Primary p-2 justify-evenly rounded-md font-medium",for:"resume"},["Upload resume",i(bd,{class:"text-center font-bold",[s]:{class:s}},3,"ty_0")],1,null),n("input",null,{accept:".pdf",class:"w-full",id:"resume",name:"resume",required:!0,type:"file"},null,3,null),n("button",null,{class:"mt-4 bg-secondary-red text-white w-full font-semibold px-4 py-2 rounded-xl hover:bg-blue-600 focus:outline-none",type:"submit"},"Submit",3,null)],1,null)],1,"ty_1")},M0=m(f(L0,"s_34gK8gnZN08")),C0=()=>{const[t]=et();t.value=!0},j0=t=>{const[e,a,l]=et();return n("div",null,{class:"flex h-[380px] w-[460px] flex-col justify-between rounded-[30px] bg-white p-6 text-center shadow-lg max-[800px]:h-[280px] "},[n("div",null,{class:"flex-col items-center"},[n("div",null,{class:"flex items-center justify-center gap-2"},[i(jl,null,3,"At_0"),n("span",null,{class:"font-[500] opacity-60"},u(r=>r.position.Location,[t],'p0.position["Location"]'),3,null)],1,null),n("h4",null,{class:"mt-2 text-[19px] font-[700] text-primary-dark-blue"},u(r=>r.position.Name,[t],'p0.position["Name"]'),3,null),i(C,{classN:"text-[15px] max-[800px]:text-[13px]",get text(){return t.position.Summary},[s]:{classN:s,text:u(r=>r.position.Summary,[t],'p0.position["Summary"]')}},3,"At_1")],1,null),n("div",null,{class:"flex flex-col items-center gap-2"},[n("div",null,{class:"flex gap-1 text-[15px]"},[n("span",null,{class:"text-btn-green hover:cursor-pointer",onClick$:B("s_d5LXfHtAyog",[a,t,l])},"Learn more",3,null)," ",n("span",null,{class:"text-black"},"or",3,null)],3,null),i(X,{onClick:e,text:"Submit Resume",[s]:{onClick:s,text:s}},3,"At_2")],1,null)],1,"At_3")},I0=t=>{const e=W(!1),a=W(!1),l=W(t.data.Positions[0].attributes),o=m(f(j0,"s_MLxpYci0h0Y",[f(C0,"s_DxkiX1SABig",[e]),a,l])),c=t.data.Positions.map((d,p)=>i(o,{get position(){return d.attributes},[s]:{position:x(d,"attributes")}},3,p));return n("div",null,{class:"my-8 flex justify-center text-primary-blue"},[i(Xa,{children:i(M0,null,3,"At_4"),showSignal:e,[s]:{showSignal:s}},1,"At_5"),i(Xa,{children:i(k0,{get data(){return l.value},[s]:{data:u(d=>d.value,[l],"p0.value")}},3,"At_6"),showSignal:a,[s]:{showSignal:s}},1,"At_7"),n("div",null,{class:"flex flex-col "},[n("h3",null,{class:"text-center text-[44px] font-[600]"},u(d=>d.data.PositionsTitle,[t],'p0.data["PositionsTitle"]'),3,null),n("div",null,{class:"flex-column flex w-[1200px] "},i(St,{hasArrows:!0,id:"carPositions",slides:c,[s]:{hasArrows:s,id:s}},3,"At_8"),1,null)],1,null)],1,"At_9")},E0=m(f(I0,"s_Su5lXmtHgW0")),O0=t=>{const e=t.data.pageCareers.data.attributes;return n("div",null,{onClick$:B("s_yJsNttxIAPY")},[i(_0,{data:{HeaderLogo:t.data.pageCareers.data.attributes.HeaderLogo,HeaderTitle:t.data.pageCareers.data.attributes.HeaderTitle,HeaderPictures:t.data.pageCareers.data.attributes.HeaderPictures}},3,"a0_0"),i(D0,{data:{Beliefs:t.data.pageCareers.data.attributes.Beliefs,BeliefsDescription:t.data.pageCareers.data.attributes.BeliefsDescription,BeliefsSubtitle:t.data.pageCareers.data.attributes.BeliefsSubtitle,BeliefsTitle:t.data.pageCareers.data.attributes.BeliefsTitle,Offerings:t.data.pageCareers.data.attributes.Offerings,OfferingTitle:t.data.pageCareers.data.attributes.OfferingTitle}},3,"a0_1"),n("div",null,{class:"flex w-full justify-center px-8"},n("div",null,{class:"max-w-[1200px] text-center text-primary-blue"},[n("h3",null,{class:"mb-4 mt-16 text-[38px] font-[800]"},w(e.FormParagraph,"Title"),1,null),i(C,{get text(){return e.FormParagraph.Paragraph},classN:"text-[18px] font-[400]",[s]:{classN:s,text:x(e.FormParagraph,"Paragraph")}},3,"a0_2")],1,null),1,null),i(E0,{data:{Positions:e.Positions.data,PositionsTitle:e.PositionsTitle}},3,"a0_3")],1,"a0_4")},B0=m(f(O0,"s_CHSZKaaPR2c")),A0=t=>`query QueryCareers {
    pageCareers(locale:"${t}"){    
      data{
        attributes{
                  HeaderLogo{
                    ${b}
                  }
          HeaderPictures{
            ${b}
          }
          HeaderBackground{
           ${b}
          }
          HeaderTitle{
            Text
          }
          
          
          BeliefsTitle
          BeliefsSubtitle
          Beliefs{
            Text
          }
          BeliefsDescription
          
          
          OfferingTitle
          Offerings{
            Title
            Paragraph
            Media{
              ${b}
            }
          }
          
          PositionsTitle
          Positions(sort: "Name:Asc"){
            data{
              attributes{
                Location
                Name
                Summary
                Duties
                Qualifications
              }
            }
          }
          
          FormParagraph{
            Title
            Paragraph
          }
          FormCareers{
            Title
            Fields{
              Label
              Icon{
                ${b}
              }
            }
            ActionButton{
              Text
              Link
            }
          }
        ${F}
        }
      }
    }
  }`,N0=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(A0,e)},Rl=N(f(N0,"s_bBcTtiHl1Tw")),q0=()=>{const t=Rl();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageCareers.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageCareers.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageCareers"]["data"]["attributes"]["SEO"]')}},3,"sa_0"),i(B0,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"sa_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"sa_2")},R0=m(f(q0,"s_KylSGhTDLNs")),z0=({resolveValue:t})=>{const a=t(Rl).pageData.data.pageCareers.data.attributes.SEO;return Q(a)},F0=Object.freeze(Object.defineProperty({__proto__:null,default:R0,head:z0,usePageData:Rl},Symbol.toStringTag,{value:"Module"})),G0=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(C,{get text(){return t.data.TextContent},classN:"markdownTitle markdownh3 markdownHyper text-justify flex text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"27_0")],1,"27_1"),Q0=m(f(G0,"s_qLAYw5vO9og")),H0=t=>`query QuerySupplement {
        pageSuppleTerms(locale:"${t}"){    
          ${Ue}
          ${F}
            }
          }
        }
      }`,W0=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(H0,e)},zl=N(f(W0,"s_LHhYaz4wQcQ")),U0=()=>{const t=zl(),e=t.value.pageData.data.pageSuppleTerms.data.attributes.Content;return i(H,{children:i(z,{get data(){return t.value.layoutData},children:i(Q0,{data:e},3,"NP_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"NP_1")},1,"NP_2")},V0=m(f(U0,"s_2WfoIGYZZ0E")),Y0=({resolveValue:t})=>{const a=t(zl).pageData.data.pageSuppleTerms.data.attributes.SEO;return Q(a)},Z0=Object.freeze(Object.defineProperty({__proto__:null,default:V0,head:Y0,usePageData:zl},Symbol.toStringTag,{value:"Module"})),K0=t=>n("div",null,{class:"flex flex-col py-10 items-center justify-center"},[n("h1",null,{class:"text-2xl sm:text-4xl font-bold text-primary-blue"},u(e=>e.data.Introduction.Title,[t],'p0.data["Introduction"]["Title"]'),3,null),n("p",null,{class:"text-primary-blue text-center text-[16px] md:text-[18px] m-5"},u(e=>e.data.Introduction.Paragraph,[t],'p0.data["Introduction"]["Paragraph"]'),3,null),i(X,{get text(){return t.data.Introduction.Buttons[0].Text},get link(){return t.data.Introduction.Buttons[0].Link},[s]:{link:u(e=>e.data.Introduction.Buttons[0].Link,[t],'p0.data["Introduction"]["Buttons"][0]["Link"]'),text:u(e=>e.data.Introduction.Buttons[0].Text,[t],'p0.data["Introduction"]["Buttons"][0]["Text"]')}},3,"wL_0"),n("div",null,{class:"flex flex-col items-center gap-2 px-4 py-4 my-10"},[n("p",null,{class:"text-xl sm:text-2xl font-bold text-primary-blue"},u(e=>e.data.SocialMedia.Text,[t],'p0.data["SocialMedia"]["Text"]'),3,null),n("div",null,{class:"flex flex-row gap-4"},t.data.SocialMedia.SubOption.map((e,a)=>Z(i(Se,{get href(){return e.Link},children:[e.Link.includes("facebook")&&n("div",null,{class:"flex w-[50px] h-[50px] items-center justify-center rounded-full bg-primary-blue p-4"},i(E,{get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},toWhite:!0,[s]:{alt:x(e.Icon.data.attributes,"alternativeText"),title:x(e.Icon.data.attributes,"caption"),toWhite:s,url:x(e.Icon.data.attributes,"url")}},3,"wL_1"),1,"wL_2"),!e.Link.includes("facebook")&&n("div",null,{class:"flex w-[50px] h-[50px] items-center justify-center rounded-full bg-primary-blue p-3"},i(E,{get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},toWhite:!0,[s]:{alt:x(e.Icon.data.attributes,"alternativeText"),title:x(e.Icon.data.attributes,"caption"),toWhite:s,url:x(e.Icon.data.attributes,"url")}},3,"wL_3"),1,"wL_4")],[s]:{href:x(e,"Link")}},1,a))),1,null)],1,null),n("div",null,{class:"flex flex-col items-center justify-center"},[n("h2",null,{class:"text-xl sm:text-2xl font-bold text-primary-blue"},u(e=>e.data.OfficesTitle,[t],'p0.data["OfficesTitle"]'),3,null),n("div",null,{class:"flex flex-wrap gap-8 mt-5 justify-center items-start"},t.data.OfficesLocation.map((e,a)=>n("div",null,{class:"flex flex-col w-[200px]"},[n("a",{href:w(e.Buttons[0],"Link")},{class:"font-bold text-secondary-red"},w(e.Buttons[0],"Text"),1,null),n("a",{href:w(e.Buttons[1],"Link")},{class:"font-bold text-primary-blue"},w(e.Buttons[1],"Text"),1,null),n("p",null,{class:"tracking-wide font-normal text-sm text-primary-blue"},w(e,"Paragraph"),1,null)],1,a)),1,null)],1,null)],1,"wL_5"),X0=m(f(K0,"s_5L0HuXf9QnQ")),J0=t=>`query QueryContactUs{
        pageContact(locale:"${t}"){
          data{
            attributes{
              Introduction{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              SocialMedia{
                Text
                SubOption{
                  Text
                  Link
                  Icon{
                    ${b}
                  }
                }
              }
              
              OfficesTitle
              OfficesLocation{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              ${F}
            }
          }
        }
      }`,tg=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(J0,e)},Fl=N(f(tg,"s_QdheZerij2w")),eg=()=>{const t=Fl(),e=t.value.pageData.data.pageContact.data.attributes;return i(H,{children:i(z,{get data(){return t.value.layoutData},children:i(X0,{data:e},3,"yX_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"yX_1")},1,"yX_2")},ag=m(f(eg,"s_FZeWA02p0TI")),lg=({resolveValue:t})=>{const a=t(Fl).pageData.data.pageContact.data.attributes.SEO;return Q(a)},ng=Object.freeze(Object.defineProperty({__proto__:null,default:ag,head:lg,usePageData:Fl},Symbol.toStringTag,{value:"Module"})),sg=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(C,{get text(){return t.data.TextContent},classN:"markdownTitle markdownHyper text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"NS_0")],1,"NS_1"),rg=m(f(sg,"s_gvsFRD0Vfkk")),ig=t=>`
query QueryCookies {
  pageCookies(locale:"${t}"){    
    ${Ue}
    ${F}
      }
    }
  }
}`,og=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(ig,e)},Gl=N(f(og,"s_IqhWiqyXb00")),ug=()=>{const t=Gl(),e=t.value.pageData.data.pageCookies.data.attributes.Content;return i(H,{children:i(z,{get data(){return t.value.layoutData},children:i(rg,{data:e},3,"wB_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"wB_1")},1,"wB_2")},cg=m(f(ug,"s_OmN9OIo5qbs")),dg=({resolveValue:t})=>{const a=t(Gl).pageData.data.pageCookies.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},pg=Object.freeze(Object.defineProperty({__proto__:null,default:cg,head:dg,usePageData:Gl},Symbol.toStringTag,{value:"Module"})),gg=t=>(Z(),t.url.includes(".mp4")?n("video",{src:G(t.url)},{autoPlay:u(e=>e.autoplay??!1,[t],"p0.autoplay??false"),class:u(e=>(e.toWhite??!1?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(e.clasN??""),[t],'(p0.toWhite??false?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(p0.clasN??"")'),controls:u(e=>e.controls??!1,[t],"p0.controls??false"),height:u(e=>e.height,[t],"p0.height"),loop:u(e=>e.loop??!0,[t],"p0.loop??true"),muted:u(e=>e.muted??!0,[t],"p0.muted??true"),width:u(e=>e.width,[t],"p0.width")},null,3,"kf_0"):i(E,{get url(){return t.url},get width(){return t.width},get height(){return t.height},get alt(){return t.alt??""},get title(){return t.title??""},get toWhite(){return t.toWhite??!1},get clasN(){return t.clasN??""},[s]:{alt:u(e=>e.alt??"",[t],'p0.alt??""'),clasN:u(e=>e.clasN??"",[t],'p0.clasN??""'),height:u(e=>e.height,[t],"p0.height"),title:u(e=>e.title??"",[t],'p0.title??""'),toWhite:u(e=>e.toWhite??!1,[t],"p0.toWhite??false"),url:u(e=>e.url,[t],"p0.url"),width:u(e=>e.width,[t],"p0.width")}},3,"kf_1")),Ja=m(f(gg,"s_GG0oZTUUfNc")),fg=t=>n("div",null,{class:"flex w-full flex-col items-center justify-center text-primary-blue"},n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center px-10 min-[800px]:w-[70%]"},[n("span",null,{class:"text-center text-[38px] font-[800] text-secondary-red max-[800px]:text-[30px]"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),i(C,{classN:"mb-3 w-full bg-primary-blue p-2 font-[600] text-[26px] max-[800px]:text-[20px] text-white text-center mx-4 rounded-full",get text(){return t.data.Description},[s]:{classN:s,text:u(e=>e.data.Description,[t],'p0.data["Description"]')}},3,"Sf_0"),i(C,{classN:"text-center text-[26px]",get text(){return t.data.Deal},[s]:{classN:s,text:u(e=>e.data.Deal,[t],'p0.data["Deal"]')}},3,"Sf_1"),i(C,{classN:"text-center text-[18px] mb-3",get text(){return t.data.Deals_description},[s]:{classN:s,text:u(e=>e.data.Deals_description,[t],'p0.data["Deals_description"]')}},3,"Sf_2"),n("div",null,{class:"mb-3 flex items-start justify-evenly gap-4 max-[600px]:flex-col"},t.data.Services.map((e,a)=>n("div",null,{class:"flex items-center justify-center gap-1"},[i(Ja,{get url(){return e.Icon.data.attributes.url},clasN:"w-[100px] max-[1000px]:w-[80px] ",muted:!0,[s]:{clasN:s,muted:s,url:x(e.Icon.data.attributes,"url")}},3,"Sf_3"),n("span",null,{class:"font-[600]"},w(e,"Title"),1,null)],1,a)),1,null),i(X,{get text(){return t.data.Button.Text},get link(){return t.data.Button.Link},[s]:{link:u(e=>e.data.Button.Link,[t],'p0.data["Button"]["Link"]'),text:u(e=>e.data.Button.Text,[t],'p0.data["Button"]["Text"]')}},3,"Sf_4")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 max-[600px]:hidden min-[800px]:w-[30%]"},i(Ja,{get url(){return t.data.Media.data.attributes.url},autoplay:!0,clasN:"rounded-full  mr-[30px]",loop:!0,muted:!0,[s]:{autoplay:s,clasN:s,loop:s,muted:s,url:u(e=>e.data.Media.data.attributes.url,[t],'p0.data["Media"]["data"]["attributes"]["url"]')}},3,"Sf_5"),1,null)],1,null),1,"Sf_6"),xg=m(f(fg,"s_4av0zjglZmk")),mg=t=>n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"min-h-[200px] w-full bg-gradient-to-br from-primary-light-blue to-[#23477f] !text-white"},i(qt,{get data(){return t.data},backgroundColor:"primary-blue",color:"white",[s]:{backgroundColor:s,color:s,data:u(e=>e.data,[t],"p0.data")}},3,"tV_0"),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"tV_1"),hg=m(f(mg,"s_cJop3g0b1vg")),$g=t=>n("div",null,{class:"flex w-full items-center justify-center"},n("div",null,{class:"flex max-w-[1200px] flex-wrap items-start justify-evenly gap-6 p-8"},t.data.map((e,a)=>n("div",null,{class:"flex w-[280px] flex-col items-center gap-2"},[i(Be,{get url(){return e.Media.data.attributes.url},color:a%2===0?"bg-[#2E5899]":"bg-secondary-red",height:"a",width:"250px",get alt(){return e.Media.data.attributes.alternativeText},get title(){return e.Media.data.attributes.caption},[s]:{alt:x(e.Media.data.attributes,"alternativeText"),height:s,title:x(e.Media.data.attributes,"caption"),url:x(e.Media.data.attributes,"url"),width:s}},3,"lG_0"),i(C,{get text(){return e.Title},classN:"font-[600] text-center text-[18px] tracking-[-1px]",[s]:{classN:s,text:x(e,"Title")}},3,"lG_1"),i(C,{get text(){return e.Paragraph},classN:"text-center text-[16px]",[s]:{classN:s,text:x(e,"Paragraph")}},3,"lG_2")],1,a)),1,null),1,"lG_3"),bg=m(f($g,"s_gpmIUuGz0sE")),vg=t=>{const e=t.data.pageDeals.data.attributes.Deals,a=t.data.pageDeals.data.attributes.RefInfo,l=t.data.pageDeals.data.attributes.Discounts,r=t.data.pageDeals.data.attributes.Disclaimer;return n("div",null,null,[i(xg,{data:e},3,"e6_0"),i(hg,{data:a},3,"e6_1"),i(bg,{data:l},3,"e6_2"),n("div",null,{class:"flex w-full items-center  justify-center p-8 text-center text-[14px] italic text-primary-dark-blue"},r,1,null)],1,"e6_3")},yg=m(f(vg,"s_xtY1ub2ohjs")),wg=t=>`
  query QueryDeals{
    pageDeals(locale:"${t}"){
      data{
        attributes{
          Deals {
            isVisible
            Title
            Description
            Deal
            Deals_description
            Media {
              ${b}
            }
            Services {
              Title
              Icon {
                ${b}
              }
            }
            Button {
              Text
              Link
            }
          }
  
          RefInfo{
            Title
            Paragraph
            Media{
              ${b}
            }
            Buttons{
              Text
              Link
            }
          }
          RefBackground{
            ${b}
          }
          
          Discounts{
            Title
            Paragraph
            Media{
             ${b}
            }
          }
          Disclaimer
          
          ${F}
        }
      }
    }
  }
    `,_g=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(wg,e)},Ql=N(f(_g,"s_2jiG1A0ymzM")),Sg=()=>{const t=Ql();return i(z,{get data(){return t.value.layoutData},children:i(yg,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"B3_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"B3_1")},Tg=m(f(Sg,"s_OVAjdqBqgec")),Dg=({resolveValue:t})=>{const a=t(Ql).pageData.data.pageDeals.data.attributes.SEO;return Q(a)},Pg=Object.freeze(Object.defineProperty({__proto__:null,default:Tg,head:Dg,usePageData:Ql},Symbol.toStringTag,{value:"Module"})),kg=t=>n("div",null,{class:"my-8"},[n("h1",null,{class:"text-center text-xl font-semibold text-primary-blue"},u(e=>e.data.Introduction.Titles[0].Text,[t],'p0.data["Introduction"]["Titles"][0]["Text"]'),3,null),n("h2",null,{class:"text-center text-primary-blue"},u(e=>e.data.Introduction.TextContent,[t],'p0.data["Introduction"]["TextContent"]'),3,null),n("div",null,{class:"px-4 md:px-10"},t.data.FAQList.map((e,a)=>Z(i(xe,{get title(){return e.Title},children:[n("p",null,{class:"text-primary-blue"},w(e,"Paragraph"),1,null),e.Disclaimer!==null?n("div",null,{class:"flex flex-row items-center justify-center"},[i(fd,{class:"text-secondary-red",[s]:{class:s}},3,"NP_0"),n("p",null,{class:"text-s text-primary-dark-blue"},w(e.Disclaimer,"Text"),1,null)],1,"NP_1"):null,e.Table!==null?n("div",null,{class:"flex flex-col item-center justify-center"},n("table",null,{class:"border-collapse border rounded-2xl border-gray-200 w-full"},n("tbody",null,null,e.Table.map((l,r)=>n("tr",{class:`${r===0?"bg-primary-blue text-white":r%2===1?"bg-blue-100 text-primary-blue":"bg-blue-200 text-primary-blue"}`},null,[n("td",null,null,w(l,"ColumnOne"),1,null),n("td",null,null,w(l,"ColumnTwo"),1,null),n("td",null,null,w(l,"ColumnThree"),1,null)],1,r)),1,null),1,null),1,"NP_2"):null],classChild:" text-sm md:text-base border-primary-blue",classContainer:"text-center bg-white text-primary-blue text-base md:text-lg shadow-xl",[s]:{classChild:s,classContainer:s,title:x(e,"Title")}},1,a))),1,null)],1,"NP_3"),Lg=m(f(kg,"s_x7ihZ2PZWys")),Mg=t=>`query QueryFAQ {
        pageFaq(locale:"${t}") {
          data{
            attributes{    
              Introduction{
                Titles{
                  Text
                }
                TextContent
              }
      
              FAQList{
                Title
                Paragraph
                Disclaimer{
                Icon{
                    ${b}
                }
                Title
                Text
                Caption
                }

                Table{
                ColumnOne
                ColumnTwo
                ColumnThree
                }
              }
              
              ${F}
            }
          }
        }
      }`,Cg=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Mg,e)},Hl=N(f(Cg,"s_SBnhqZ85K9A")),jg=()=>{const t=Hl(),e=t.value.pageData.data.pageFaq.data.attributes;return i(H,{children:i(z,{get data(){return t.value.layoutData},children:i(Lg,{data:e},3,"k1_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"k1_1")},1,"k1_2")},Ig=m(f(jg,"s_jDEouB0mRKg")),Eg=({resolveValue:t})=>{const a=t(Hl).pageData.data.pageFaq.data.attributes.SEO;return Q(a)},Og=Object.freeze(Object.defineProperty({__proto__:null,default:Ig,head:Eg,usePageData:Hl},Symbol.toStringTag,{value:"Module"})),Bg=t=>n("div",null,{class:"relative z-0 h-3/4 w-[250px] text-center items-center justify-center }"},[n("img",{src:G(t.update.Picture.data.attributes.url)},{alt:u(e=>e.update.Picture.data.attributes.alternativeText,[t],'p0.update["Picture"]["data"]["attributes"]["alternativeText"]'),class:"object-fill h-full w-full",height:500,title:u(e=>e.update.Picture.data.attributes.caption,[t],'p0.update["Picture"]["data"]["attributes"]["caption"]'),width:250},null,3,null),n("a",null,{href:u(e=>e.update.Link,[t],'p0.update["Link"]')},n("div",null,{class:"absolute flex items-center justify-center flex-col inset-0 w-full h-full bg-black bg-opacity-30 text-white"},[n("h2",null,{class:"text-2xl font-semibold"},u(e=>e.update.Title,[t],'p0.update["Title"]'),3,null),n("p",null,{class:"text-xl"},u(e=>e.update.Subtitle,[t],'p0.update["Subtitle"]'),3,null)],3,null),3,null)],1,"2q_0"),Ag=t=>{const e=m(f(Bg,"s_SjfOqPww0ks")),a=t.carouselData.map((l,r)=>i(e,{update:l},3,r));return n("div",null,{class:"flex w-full items-center justify-center"},n("div",null,{class:"flex flex-row max-w-[1200px] items-center justify-center max-[800px]:flex-col h-full"},[n("h2",null,{class:"text-center p-5 text-4xl font-bold text-primary-blue max-[800px]:w-[40%]"},u(l=>l.title,[t],"p0.title"),3,null),n("div",null,{class:"h-fit w-[60%] flex items-center justify-center "},i(St,{addSpace:!1,fillSlide:!0,hasPagination:!1,id:"updatesSlider",slides:a,[s]:{addSpace:s,fillSlide:s,hasPagination:s,id:s}},3,"2q_1"),1,null)],1,null),1,"2q_2")},Ng=m(f(Ag,"s_kpGwS0aQJPs")),qg=t=>n("iframe",null,{allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",allowFullScreen:!0,class:u(e=>`h-full w-full ${e.classN}`,[t],"`h-full w-full ${p0.classN}`"),frameBorder:"0",src:u(e=>`https://www.youtube.com/embed/${e.ytURL.split("v=")[1]}`,[t],'`https://www.youtube.com/embed/${p0.ytURL.split("v=")[1]}`')},null,3,"Fj_0"),$a=m(f(qg,"s_jekwDGWyuec")),Rg=t=>n("div",null,{class:"flex flex-col lg:flex-row w-full px-10 items-center justify-center my-8"},[n("div",null,{class:"flex flex-col w-full lg:w-1/3 h-full text-center lg:text-end justify-evenly mr-4 my-4"},[n("h2",null,{class:"text-2xl font-semibold text-secondary-red"},u(e=>e.data.FeatInterview.Title,[t],'p0.data["FeatInterview"]["Title"]'),3,null),n("h3",null,{class:"text-2xl font-[350] text-primary-blue"},u(e=>e.data.FeatInterview.Subtitle,[t],'p0.data["FeatInterview"]["Subtitle"]'),3,null),i(C,{classN:"my-8 ml-4",get text(){return t.data.FeatInterview.Paragraph},[s]:{classN:s,text:u(e=>e.data.FeatInterview.Paragraph,[t],'p0.data["FeatInterview"]["Paragraph"]')}},3,"RS_0"),n("div",null,{class:"flex justify-center lg:justify-end"},n("a",null,{class:"text-end",href:u(e=>e.data.FeatInterview.Buttons[0].Link,[t],'p0.data["FeatInterview"]["Buttons"][0]["Link"]')},n("div",null,{class:"flex px-4 w-fit py-2 justify-evenly items-center rounded-2xl border-2 border-primary-blue"},[i(hd,{class:"fill-secondary-red mr-4 h-full",[s]:{class:s}},3,"RS_1"),n("p",null,null,u(e=>e.data.FeatInterview.Buttons[0].Text,[t],'p0.data["FeatInterview"]["Buttons"][0]["Text"]'),3,null)],1,null),1,null),1,null)],1,null),n("div",null,null,i($a,{get ytURL(){return t.data.FeatVideo},classN:"rounded-2xl w-[460px] md:w-[530px] md:h-[350px] m-8",[s]:{classN:s,ytURL:u(e=>e.data.FeatVideo,[t],'p0.data["FeatVideo"]')}},3,"RS_2"),1,null)],1,"RS_3"),zg=m(f(Rg,"s_liBh70ErorA")),Fg=t=>{const e=t.data.map((a,l)=>n("div",null,{class:"relative z-0 w-350 h-150 rounded-2xl"},[n("img",{alt:w(a.Picture.data.attributes,"alternativeText"),src:G(a.Picture.data.attributes.url)},{class:"rounded-2xl",height:150,width:350},null,3,null),n("a",{href:w(a,"Link")},{class:"absolute inset-0 h-full w-full flex items-center justify-center"},i(E,{height:50,toWhite:!0,url:"/uploads/youtube_67497ef97d.svg",width:50,[s]:{height:s,toWhite:s,url:s,width:s}},3,"zz_0"),1,null)],1,l));return n("div",null,{class:"w-full flex items-center justify-center"},i(St,{duration:5e3,hasPagination:!1,id:"InterviewCarousel",slides:e,[s]:{duration:s,hasPagination:s,id:s}},3,"zz_1"),1,"zz_2")},Gg=m(f(Fg,"s_w6lTa7I5NZ4")),Qg=t=>n("div",null,null,[i(qt,{get data(){return t.data.Introduction},alt:!0,hasPricing:!1,reverse:!0,[s]:{alt:s,data:u(e=>e.data.Introduction,[t],'p0.data["Introduction"]'),hasPricing:s,reverse:s}},3,"NM_0"),i(Ng,{get title(){return t.data.UpdatesTitle},get carouselData(){return t.data.UpdatesCarousel},[s]:{carouselData:u(e=>e.data.UpdatesCarousel,[t],'p0.data["UpdatesCarousel"]'),title:u(e=>e.data.UpdatesTitle,[t],'p0.data["UpdatesTitle"]')}},3,"NM_1"),i(zg,{get data(){return t.data},[s]:{data:u(e=>e.data,[t],"p0.data")}},3,"NM_2"),i(Gg,{get data(){return t.data.Interviews},[s]:{data:u(e=>e.data.Interviews,[t],'p0.data["Interviews"]')}},3,"NM_3")],1,"NM_4"),Hg=m(f(Qg,"s_bPCxBsh3t6w")),Wg=t=>`query queryGfsn{
        pageGfSports(locale:"${t}"){
          data{
            attributes{
              
              Introduction{
                Title
                Subtitle
                Paragraph
                Media{
                 ${b}
                }
               
              }
              
              UpdatesTitle
              
              UpdatesCarousel{
                Picture{
                  ${b}
                }
                Link
                Title
                Subtitle
              }
              
              FeatInterview{
                Title
                Subtitle
                Paragraph
                
                Buttons{
                  Text
                  Link
                  Icon{
                    ${b}
                  }
                }
              }
              
              
              FeatVideo
              
              Interviews{
                Picture{
                  ${b}
                }
                Link
                Title
              }
              ${F}
            }
          }
        }
      }`,Ug=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Wg,e)},Wl=N(f(Ug,"s_BZfivgZf0o0")),Vg=()=>{const t=Wl();return i(H,{children:i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageGfSports.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfSports.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfSports"]["data"]["attributes"]["SEO"]')}},3,"7u_0"),i(Hg,{get data(){return t.value.pageData.data.pageGfSports.data.attributes},[s]:{data:u(e=>e.value.pageData.data.pageGfSports.data.attributes,[t],'p0.value["pageData"]["data"]["pageGfSports"]["data"]["attributes"]')}},3,"7u_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"7u_2")},1,"7u_3")},Yg=m(f(Vg,"s_KZzsv9nZPuQ")),Zg=({resolveValue:t})=>{const a=t(Wl).pageData.data.pageGfSports.data.attributes.SEO;return Q(a)},Kg=Object.freeze(Object.defineProperty({__proto__:null,default:Yg,head:Zg,usePageData:Wl},Symbol.toStringTag,{value:"Module"})),Xg=t=>{const e=t.data.pageGfCloud.data.attributes,a=t.data.sectionNetwork.data.attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(E,{get url(){return e.GNetworkLogo.data.attributes.url},get alt(){return e.GNetworkLogo.data.attributes.alternativeText},get title(){return e.GNetworkLogo.data.attributes.caption},height:95,width:500,[s]:{alt:x(e.GNetworkLogo.data.attributes,"alternativeText"),height:s,title:x(e.GNetworkLogo.data.attributes,"caption"),url:x(e.GNetworkLogo.data.attributes,"url"),width:s}},3,"JJ_0"),n("div",null,{class:"flex flex-wrap-reverse px-8 py-6 items-center justify-center"},[n("div",null,{class:"h-[450px] w-full md:w-1/2"},i(E,{get url(){return a.Map.MapPicture.data.attributes.url},get alt(){return a.Map.MapPicture.data.attributes.alternativeText},get title(){return a.Map.MapPicture.data.attributes.caption},height:95,width:500,[s]:{alt:x(a.Map.MapPicture.data.attributes,"alternativeText"),height:s,title:x(a.Map.MapPicture.data.attributes,"caption"),url:x(a.Map.MapPicture.data.attributes,"url"),width:s}},3,"JJ_1"),1,null),n("div",null,{class:"flex flex-col w-full md:w-1/2 items-center justify-center"},[i(C,{get text(){return a.Description.Paragraph},classN:"text-primary-blue",[s]:{classN:s,text:x(a.Description,"Paragraph")}},3,"JJ_2"),i(xe,{get title(){return a.Map.ServersTitle},children:n("div",null,{class:"flex flex-col py-4 text-primary-blue bg-white rounded-b-2xl"},a.Map.Servers.map((l,r)=>n("a",{href:w(l,"Link")},{class:"hover:text-secondary-red text-primary-blue"},w(l,"Text"),1,r)),1,null),classContainer:"rounded-full bg-white text-primary-blue shadow-xl",[s]:{classContainer:s,title:x(a.Map,"ServersTitle")}},1,"JJ_3")],1,null)],1,null),i(At,{get title(){return e.GFCloud.Title},get text(){return e.GFCloud.Paragraph},get image(){return e.GFCloud.Media.data.attributes},get logo(){return e.GFCloud.Logo.data.attributes},get buttons(){return e.GFCloud.Buttons},[s]:{buttons:x(e.GFCloud,"Buttons"),image:x(e.GFCloud.Media.data,"attributes"),logo:x(e.GFCloud.Logo.data,"attributes"),text:x(e.GFCloud,"Paragraph"),title:x(e.GFCloud,"Title")}},3,"JJ_4")],1,"JJ_5")},Jg=m(f(Xg,"s_ee4CXUkPYJQ")),tf=t=>`query QueryGFCloud {
        pageGfCloud (locale:"${t}"){    
          data{
            attributes{
              GNetworkLogo{
                ${b}
              }
            GFCloud{
              Title
              Logo{
                ${b}
              }
              Paragraph
              Media{
                ${b}
              }
              Buttons{
                Text
                Link
              }
            }
              
            ${F}
            }
          }
        }
        sectionNetwork (locale:"${t}"){
          data {
            attributes {
              Map {
                MapPicture {
                  ${b}
                }
                ServersTitle
                Servers {
                  Text
                  Link
                  Icon{
                    data{
                      attributes{
                        url
                      }
                    }
                  }
                }
              }
              Description{
                Title
                Paragraph
              }
            }
          }
        }
      }`,ef=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(tf,e)},Ul=N(f(ef,"s_imQl8eEcDG0")),af=()=>{const t=Ul(),e=t.value.pageData.data;return i(H,{children:i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageGfCloud.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageGfCloud.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfCloud"]["data"]["attributes"]["SEO"]')}},3,"Fb_0"),i(Jg,{data:e},3,"Fb_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Fb_2")},1,"Fb_3")},lf=m(f(af,"s_8q0wwtngnhI")),nf=({resolveValue:t})=>{const a=t(Ul).pageData.data.pageGfCloud.data.attributes.SEO;return Q(a)},sf=Object.freeze(Object.defineProperty({__proto__:null,default:lf,head:nf,usePageData:Ul},Symbol.toStringTag,{value:"Module"})),rf=t=>n("div",null,{class:"flex w-full flex-col items-center justify-center gap-3 rounded-xl bg-white p-8 shadow-xl"},[n("div",null,{class:"w-fit rounded-full bg-secondary-red p-2"},i(E,{get url(){return t.tip.Icon.data.attributes.url},get alt(){return t.tip.Icon.data.attributes.alternativeText},get title(){return t.tip.Icon.data.attributes.caption},height:17,toWhite:!0,width:17,[s]:{alt:u(e=>e.tip.Icon.data.attributes.alternativeText,[t],'p0.tip["Icon"]["data"]["attributes"]["alternativeText"]'),height:s,title:u(e=>e.tip.Icon.data.attributes.caption,[t],'p0.tip["Icon"]["data"]["attributes"]["caption"]'),toWhite:s,url:u(e=>e.tip.Icon.data.attributes.url,[t],'p0.tip["Icon"]["data"]["attributes"]["url"]'),width:s}},3,"Ie_0"),1,null),n("h4",null,{class:"text-center font-[700] text-primary-blue"},u(e=>e.tip.Title,[t],'p0.tip["Title"]'),3,null),i(C,{classN:"text-[14px] font-[500]",get text(){return t.tip.Text},[s]:{classN:s,text:u(e=>e.tip.Text,[t],'p0.tip["Text"]')}},3,"Ie_1")],1,t.tip.Title),of=t=>{const e=m(f(rf,"s_YpuX8PZv7fg"));return n("div",null,{class:"mt-6 flex w-full max-w-[1200px] flex-col items-center justify-center gap-4 p-8"},[n("h2",null,{class:"text-center text-[40px] font-[500] text-primary-blue"},u(a=>a.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"grid w-full grid-cols-3 gap-4  max-[800px]:grid-cols-1"},t.data.Bullets.slice(0,3).map((a,l)=>i(e,{tip:a},3,l)),1,null),n("div",null,{class:"grid w-full grid-cols-2 gap-4 max-[800px]:grid-cols-1"},t.data.Bullets.slice(3,5).map((a,l)=>i(e,{tip:a},3,l)),1,null)],1,"Ie_2")},uf=m(f(of,"s_0W2ahleMHpc")),cf=t=>i(H,{children:t.data.map((e,a)=>i(qt,{data:e,reverse:a%2===1,textPercentage:60,[s]:{textPercentage:s}},3,a))},1,"mL_0"),df=m(f(cf,"s_GQ2BMpdgaAM")),pf=t=>{const e=t.data.pageGfIS.data.attributes;let a="";return e.WiFiListing.Bullets.forEach(l=>{a+="- "+l.Text+`
`}),n("div",null,{class:"flex w-full flex-col items-center justify-center",onClick$:B("s_wLQQzX3cS04")},[n("h1",null,{class:"max-w-[800px] px-8 text-center text-[42px] font-[600] text-primary-blue max-[600px]:text-[32px]"},w(e.Introduction,"Paragraph"),1,null),i(uf,{get data(){return e.Tips},[s]:{data:x(e,"Tips")}},3,"5A_0"),i(df,{get data(){return e.InternetInfo},[s]:{data:x(e,"InternetInfo")}},3,"5A_1"),n("div",null,{class:"flex max-w-[1200px] items-start justify-center gap-4 p-8 max-[800px]:flex-col"},[n("p",null,{class:"w-[60%] text-[15px] text-primary-blue max-[800px]:w-full"},w(e.InternetExample[0],"Text"),1,null),n("p",null,{class:"w-[40%] text-[15px] font-[600] text-primary-blue max-[800px]:w-full"},w(e.InternetExample[1],"Text"),1,null)],1,null),i(At,{get title(){return e.WiFiListing.Title},text:a,get image(){return e.WiFiPicture.data.attributes},reverse:!0,textPercentage:50,[s]:{image:x(e.WiFiPicture.data,"attributes"),reverse:s,textPercentage:s,title:x(e.WiFiListing,"Title")}},3,"5A_2"),i(qt,{get data(){return e.TestPar},textPercentage:60,[s]:{data:x(e,"TestPar"),textPercentage:s}},3,"5A_3"),i(Oe,{steps:e.TestStepss.map(l=>"**"+l.Title+`**

`+l.Text)},3,"5A_4"),i(At,{get text(){return e.TestGlossary.Paragraph},get image(){return e.TestGlossary.Media.data.attributes},textPercentage:60,[s]:{image:x(e.TestGlossary.Media.data,"attributes"),text:x(e.TestGlossary,"Paragraph"),textPercentage:s}},3,"5A_5"),n("h3",null,{class:"text-[40px] font-[600] text-primary-blue"},w(e.TroubleSteps,"Title"),1,null),n("p",null,{class:"my-4 text-primary-blue"},w(e,"TroubleDescription"),1,null),n("div",null,{class:"max-w-[1200px]  px-8"},i(Oe,{steps:e.TroubleSteps.Bullets.map(l=>l.Title?"**"+l.Title+`**
`+l.Text.replaceAll(`

`,`
`):"**"+l.Text.replaceAll(`

`,`
`)+"**")},3,"5A_6"),1,null)],1,"5A_7")},gf=m(f(pf,"s_DlDfET88Hb4")),ff=t=>`query {
    pageGfIS(locale:"${t}") {
      data {
        attributes {
          Introduction {
            Paragraph
            Media {
              ${b}
            }
          }
          Tips {
            Title
            Bullets {
              Title
              Text
              Icon {
               ${b}
              }
            }
          }
          InternetInfo {
            Title
            Paragraph
            Media {
              ${b}
            }
          }
          InternetExample {
            Text
          }
          WiFiPicture {
           ${b}
          }
          WiFiListing {
            Title
            Bullets {
              Title
              Text
            }
          }
          TestPar{
            Title
            Paragraph
            Media{
              ${b}
            }
          }
          TestStepss{
            Title
            Text
          }
          TestGlossary {
            Paragraph
            Media {
              ${b}
            }
          }
          TroubleSteps {
            Title
            Bullets {
              Title
              Text
            }
          }
          TroubleDescription
          ${F}
  
        }
      }
    }
  }`,xf=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(ff,e)},Vl=N(f(xf,"s_YTLZ80iXjpk")),mf=()=>{const t=Vl();return i(z,{get data(){return t.value.layoutData},children:i(gf,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"0g_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"0g_1")},hf=m(f(mf,"s_sPmm4Hp5SbY")),$f=({resolveValue:t})=>{const a=t(Vl).pageData.data.pageGfIS.data.attributes.SEO;return Q(a)},bf=Object.freeze(Object.defineProperty({__proto__:null,default:hf,head:$f,usePageData:Vl},Symbol.toStringTag,{value:"Module"})),vf=t=>n("div",null,{class:"flex min-h-[600px] w-fit max-w-[300px] flex-col items-center justify-between rounded-[35px] bg-white px-5"},[n("div",null,{class:"mt-8 flex w-fit max-w-full flex-col items-center self-center"},[t.isFullLogo??!1?n("div",null,{class:"flex flex-col justify-center items-center self-center gap-2 "},[n("img",{src:G(t.logo.url)},{alt:u(e=>e.logo.alternativeText,[t],'p0.logo["alternativeText"]'),class:" w-full  overflow-hidden object-center",height:100,loading:"lazy",title:u(e=>e.logo.caption,[t],'p0.logo["caption"]'),width:300},null,3,null),n("div",null,{class:" text-2xl font-bold leading-6 text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null)],1,"0s_0"):n("div",null,{class:"flex w-full items-start gap-5 self-center"},[n("img",{src:G(t.logo.url)},{alt:u(e=>e.logo.alternativeText,[t],'p0.logo["alternativeText"]'),class:"aspect-square w-[70px] max-w-full items-center justify-center self-stretch overflow-hidden object-contain object-center",height:100,loading:"lazy",title:u(e=>e.logo.caption,[t],'p0.logo["caption"]'),width:100},null,3,null),n("div",null,{class:"my-auto flex flex-col self-center"},n("div",null,{class:"self-start whitespace-nowrap text-2xl font-bold leading-6 text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),3,null)],1,null),n("div",null,{class:"mt-2 text-center text-base leading-4 tracking-tighter text-primary-blue"},[n("span",null,{class:"text-2xl font-light text-secondary-red"},"$",3,null),n("span",null,{class:"text-2xl font-light text-primary-blue"},u(e=>e.price,[t],"p0.price"),3,null),n("span",null,{class:" text-2xl text-primary-blue"},u(e=>e.priceTime,[t],"p0.priceTime"),3,null)],3,null),n("div",null,{class:"mt-5 text-center text-base text-primary-blue"},i(C,{get text(){return t.description},[s]:{text:u(e=>e.description,[t],"p0.description")}},3,"0s_1"),1,null),n("div",null,{class:"border-gary-500 my-4 h-[1px] w-full border-t-2"},null,3,null),n("div",null,{class:"mt-5 text-base text-primary-blue"},t.features.map((e,a)=>n("span",null,{class:"my-1 flex flex-row items-center justify-start"},[n("div",null,null,i(br,{class:"mx-2 h-[20px] w-[20px] fill-primary-blue text-primary-blue",[s]:{class:s}},3,"0s_2"),1,null),n("h3",null,{class:"text-sm font-light"},w(e,"Text"),1,a)],1,a)),1,null)],1,null),n("div",null,{class:"my-4 flex h-[80px] w-full flex-col items-center justify-center"},[n("div",null,{class:"border-gary-500 my-4 h-[1px] w-full border-t-2"},null,3,null),i(X,{get text(){return t.btnText},get link(){return t.btnLink},[s]:{link:u(e=>e.btnLink,[t],"p0.btnLink"),text:u(e=>e.btnText,[t],"p0.btnText")}},3,"0s_3")],1,null)],1,"0s_4"),Yl=m(f(vf,"s_Ttt0gCfGtkU")),yf=t=>n("div",null,{class:"flex flex-col items-center justify-around"},[n("div",null,{class:"mx-4 my-8 max-w-[500px]"},i(E,{get url(){return t.data.Logo.data.attributes.url},get alt(){return t.data.Logo.data.attributes.alternativeText},get title(){return t.data.Logo.data.attributes.caption},height:229,width:1230,[s]:{alt:u(e=>e.data.Logo.data.attributes.alternativeText,[t],'p0.data["Logo"]["data"]["attributes"]["alternativeText"]'),height:s,title:u(e=>e.data.Logo.data.attributes.caption,[t],'p0.data["Logo"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.Logo.data.attributes.url,[t],'p0.data["Logo"]["data"]["attributes"]["url"]'),width:s}},3,"6h_0"),1,null),n("div",null,{class:"mx-10 my-4 flex max-w-[800px] flex-col items-center justify-center gap-2 text-primary-blue"},[n("span",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(e=>e.data.Introduction.Title,[t],'p0.data["Introduction"]["Title"]'),3,null),i(C,{classN:"text-center",get text(){return t.data.Introduction.Paragraph},[s]:{classN:s,text:u(e=>e.data.Introduction.Paragraph,[t],'p0.data["Introduction"]["Paragraph"]')}},3,"6h_1"),i(X,{get text(){return t.data.Introduction.Buttons[0].Text},get link(){return t.data.Introduction.Buttons[0].Link},[s]:{link:u(e=>e.data.Introduction.Buttons[0].Link,[t],'p0.data["Introduction"]["Buttons"][0]["Link"]'),text:u(e=>e.data.Introduction.Buttons[0].Text,[t],'p0.data["Introduction"]["Buttons"][0]["Text"]')}},3,"6h_2")],1,null),n("div",null,{class:"flex flex-wrap gap-10 justify-center mx-4 my-8 items-start"},t.data.PackTables.map((e,a)=>i(Yl,{get title(){return e.Title},get logo(){return e.Logo.data.attributes},get description(){return e.Description},get features(){return e.Features},get price(){return e.Price},get priceTime(){return e.Pricetime},get btnLink(){return e.Button.Link},get btnText(){return e.Button.Text},[s]:{btnLink:x(e.Button,"Link"),btnText:x(e.Button,"Text"),description:x(e,"Description"),features:x(e,"Features"),logo:x(e.Logo.data,"attributes"),price:x(e,"Price"),priceTime:x(e,"Pricetime"),title:x(e,"Title")}},3,a)),1,null),i(C,{classN:"text-primary-blue text-center mx-4 my-8",get text(){return t.data.Disclaimer},[s]:{classN:s,text:u(e=>e.data.Disclaimer,[t],'p0.data["Disclaimer"]')}},3,"6h_3"),i(At,{get text(){return t.data.GFInternetSupport.Paragraph},get title(){return t.data.GFInternetSupport.Title},get logo(){return t.data.GFInternetSupport.Logo.data.attributes},get buttons(){return t.data.GFInternetSupport.Buttons},get image(){return t.data.GFInternetSupport.Media.data.attributes},[s]:{buttons:u(e=>e.data.GFInternetSupport.Buttons,[t],'p0.data["GFInternetSupport"]["Buttons"]'),image:u(e=>e.data.GFInternetSupport.Media.data.attributes,[t],'p0.data["GFInternetSupport"]["Media"]["data"]["attributes"]'),logo:u(e=>e.data.GFInternetSupport.Logo.data.attributes,[t],'p0.data["GFInternetSupport"]["Logo"]["data"]["attributes"]'),text:u(e=>e.data.GFInternetSupport.Paragraph,[t],'p0.data["GFInternetSupport"]["Paragraph"]'),title:u(e=>e.data.GFInternetSupport.Title,[t],'p0.data["GFInternetSupport"]["Title"]')}},3,"6h_4")],1,"6h_5"),wf=m(f(yf,"s_30f4iq1HkIo")),_f=t=>`query QueryGFInternet {
        pageGfInternet(locale:"${t}"){
          data {
            attributes {
              Logo {
                ${b}
              }
              Introduction {
                Paragraph
                Buttons {
                  Text
                  Link
                }
              }
              PackTables {
                Logo {
                  ${b}
                }
                Title
                Subtitle
                Price
                Pricetime
                Description
                Features {
                  Text
                  Title
                }
                Button {
                  Link
                  Text
                }
              }
              Disclaimer
              GFInternetSupport {
                Title
                Subtitle
                Paragraph
                Logo {
                  ${b}
                }
                Media {
                  ${b}
                }
                Buttons {
                  Text
                  Link
                }
              }
              ${F}
            }
          }
        }
      }
      `,Sf=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(_f,e)},Zl=N(f(Sf,"s_PG6JGbvGdSU")),Tf=()=>{const t=Zl(),e=t.value.pageData.data.pageGfInternet.data.attributes;return i(H,{children:i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageGfInternet.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageGfInternet.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfInternet"]["data"]["attributes"]["SEO"]')}},3,"TH_0"),i(wf,{data:e},3,"TH_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"TH_2")},1,"TH_3")},Df=m(f(Tf,"s_cj0XMKyWnnQ")),Pf=({resolveValue:t})=>{const a=t(Zl).pageData.data.pageGfInternet.data.attributes.SEO;return Q(a)},kf=Object.freeze(Object.defineProperty({__proto__:null,default:Df,head:Pf,usePageData:Zl},Symbol.toStringTag,{value:"Module"})),Lf=t=>{const e=t.data.pageGfIoT.data.attributes.Services,a=t.data.pageGfIoT.data.attributes.Introduction,l=t.data.pageGfIoT.data.attributes.Logo.data.attributes,r=t.data.pageGfIoT.data.attributes.WeatherAnounce;return n("div",null,{class:"flex flex-col items-center justify-center "},[n("div",null,{class:"m-4 flex items-center justify-center gap-4 rounded-full bg-[#edf6ff] px-8 py-5 shadow-xl max-sm:flex-col"},[n("span",null,{class:"text-center text-[18px] font-[600] text-primary-blue max-md:text-[14px]"},w(r,"Paragraph"),1,null),i(X,{get text(){return r.Buttons[0].Text},get link(){return r.Buttons[0].Link},[s]:{link:x(r.Buttons[0],"Link"),text:x(r.Buttons[0],"Text")}},3,"Ws_0")],1,null),n("div",null,{class:"mx-4 my-8 max-w-[500px]"},i(E,{get url(){return l.url},get alt(){return l.alternativeText},get title(){return l.caption},height:229,width:1230,[s]:{alt:x(l,"alternativeText"),height:s,title:x(l,"caption"),url:x(l,"url"),width:s}},3,"Ws_1"),1,null),n("div",null,{class:"mx-10 my-4 flex max-w-[800px] flex-col items-center justify-center gap-2 text-primary-blue"},[n("span",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},w(a,"Title"),1,null),i(C,{classN:"text-justify",get text(){return a.Paragraph},[s]:{classN:s,text:x(a,"Paragraph")}},3,"Ws_2")],1,null),i(ee,{data:e},3,"Ws_3")],1,"Ws_4")},Mf=m(f(Lf,"s_1kXwT2q88rA")),Cf=t=>`
  query QueryGFIoT {
    pageGfIoT(locale:"${t}"){
      data{
        attributes{
          Logo{
            ${b}
          }
          
          Introduction{
            Title
            Paragraph
          }
          
          WeatherAnounce{
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
          
          Services{
            Logo{
             ${b}
            }
            Title
            Paragraph
            Media{
             ${b}
            }
            Buttons{
              Text
              Link
            }
          }
          ${F}
        }
      }
    }
  }
    `,jf=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Cf,e)},Kl=N(f(jf,"s_2v03ITQBdcI")),If=()=>{const t=Kl();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageGfIoT.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfIoT.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfIoT"]["data"]["attributes"]["SEO"]')}},3,"Mz_0"),i(Mf,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Mz_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Mz_2")},Ef=m(f(If,"s_teV3ya9bjBI")),Of=({resolveValue:t})=>{const a=t(Kl).pageData.data.pageGfIoT.data.attributes.SEO;return Q(a)},Bf=Object.freeze(Object.defineProperty({__proto__:null,default:Ef,head:Of,usePageData:Kl},Symbol.toStringTag,{value:"Module"})),Af=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(C,{get text(){return t.data.TextContent},classN:"markdownTitle markdownh3 markdownHyper text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"Wt_0")],1,"Wt_1"),Nf=m(f(Af,"s_wAqfRFn86VY")),qf=t=>`query QuerygftvPrivacyP {
        pageGfTvPp(locale:"${t}"){    
          ${Ue}
          ${F}
            }
          }
        }
      }`,Rf=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(qf,e)},Xl=N(f(Rf,"s_o03PAaBI278")),zf=()=>{const t=Xl(),e=t.value.pageData.data.pageGfTvPp.data.attributes.Content;return i(H,{children:i(z,{get data(){return t.value.layoutData},children:i(Nf,{data:e},3,"zG_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"zG_1")},1,"zG_2")},Ff=m(f(zf,"s_0UMSXuOQgCA")),Gf=({resolveValue:t})=>{const a=t(Xl).pageData.data.pageGfTvPp.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},Qf=Object.freeze(Object.defineProperty({__proto__:null,default:Ff,head:Gf,usePageData:Xl},Symbol.toStringTag,{value:"Module"})),Hf=async(t,e)=>{const a=G(t);try{const l=await fetch(a);if(!l.ok)throw new Error(`Error al descargar el archivo desde ${a}. Estado: ${l.status}`);const r=await l.arrayBuffer(),o=new Blob([r],{type:"application/pdf"}),c=window.URL.createObjectURL(o),d=document.createElement("a");d.href=c,d.download=e,d.click(),window.URL.revokeObjectURL(c)}catch(l){console.error(l)}},Lr=f(Hf,"s_Vd02rPSFNlY"),Wf=()=>{const[t]=et();Lr(t.urlDoc,t.nameDoc)},Uf=t=>{const e=f(Wf,"s_L0UgBFqZ3XI",[t]);return n("div",null,{class:"flex flex-col h-[250px] w-[300px] bg-white shadow-2xl rounded-3xl justify-evenly items-center p-4"},[n("h3",null,{class:"text-2xl flex text-center font-bold text-[#2E5899]"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex w-fit items-center font-semibold justify-center gap-2 rounded-full border-2 border-teal-500 bg-white p-1 px-7 text-btn-green opacity-80 shadow-md transition-all hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:e},n("div",null,{class:"flex flex-row gap-2 items-center font-semibold text-center justify-center"},[u(a=>a.btnText,[t],"p0.btnText"),n("div",null,{class:"h-[25px] w-[25px] flex items-center justify-center font-bold text-white bg-teal-500 hover:text-teal-500 hover:bg-white rounded-full"},i(vr,{class:"stroke-current",[s]:{class:s}},3,"h5_0"),1,null)],1,null),1,null)],1,"h5_1")},Mr=m(f(Uf,"s_tF7T0UXX4O0")),Vf=()=>{const[t]=et();Lr(t.urlDoc,t.nameDoc)},Yf=t=>{const e=f(Vf,"s_8SKPRTg50C4",[t]);return n("div",null,{class:"h-[370px] w-[400px] py-8 px-4 bg-white rounded-2xl pb-2 flex flex-col items-center justify-between shadow-2xl"},[n("div",null,{class:"relative flex w-full h-1/2 overflow-hidden"},n("img",{src:G(t.image.url)},{alt:u(a=>a.image.alternativeText,[t],'p0.image["alternativeText"]'),class:"object-fill w-full h-full rounded-t-2xl",height:"1500",title:u(a=>a.image.caption,[t],'p0.image["caption"]'),width:"2076"},null,3,null),1,null),n("h2",null,{class:"text-2xl flex text-center font-bold text-[#2E5899]"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex w-fit items-center font-semibold justify-center gap-2 rounded-full border-2 border-teal-500 bg-white p-1 text-btn-green opacity-80 shadow-md transition-all hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:e},n("div",null,{class:"flex flex-row gap-2 items-center font-semibold text-center justify-center"},[u(a=>a.btnText,[t],"p0.btnText"),n("div",null,{class:"h-[25px] w-[25px] flex items-center justify-center font-bold text-white bg-teal-500 hover:text-teal-500 hover:bg-white rounded-full"},i(vr,{class:"stroke-current",[s]:{class:s}},3,"d0_0"),1,null)],1,null),1,null)],1,"d0_1")},Cr=m(f(Yf,"s_OdYDJRaDcFY")),Zf=t=>{const e=t.data.pageGfTvS.data.attributes,a=t.data.sectionChGuide.data.attributes;return n("div",null,{class:"flex flex-col justify-center items-center"},[n("div",null,{class:"flex flex-col md:flex-row px-8 items-center justify-center gap-5"},[n("h1",null,{class:"text-2xl text-center font-semibold text-primary-blue"},w(e,"IntroText"),1,null),n("div",null,{class:"h-[150px] relative w-[350px] flex mb-14"},[n("video",{src:G(e.IntroMedia.data[1].attributes.url)},{autoPlay:!0,class:"absolute pt-2",loop:!0,muted:!0},null,3,null),n("img",{alt:w(e.IntroMedia.data[0].attributes,"alternativeText"),src:G(e.IntroMedia.data[0].attributes.url),title:w(e.IntroMedia.data[0].attributes,"caption")},{class:"absolute z-0",height:"786",width:"1082"},null,3,null)],1,null)],1,null),n("div",null,{class:"flex my-20 w-full py-10 bg-primary-blue bg-opacity-40"},n("div",null,{class:"flex w-full py-10 bg-primary-blue bg-opacity-60"},n("div",null,{class:"flex w-full flex-col py-10 px-8 items-center justify-between bg-primary-blue bg-opacity-80"},[n("h2",null,{class:"font-bold text-3xl md:text-4xl my-5 text-white"},w(e,"DevicesTitle"),1,null),n("div",null,{class:"flex flex-wrap gap-5 items-center justify-center"},e.Devices.map((l,r)=>n("div",null,{class:"h-[300px] w-[300px] p-5 rounded-full bg-white bg-opacity-40"},n("div",null,{class:"h-full w-full p-5 rounded-full bg-white bg-opacity-60"},n("div",null,{class:"h-full w-full object-cover flex flex-col p-8 justify-center items-center rounded-full bg-white"},[n("h2",null,{class:"text-center font-semibold text-2xl text-primary-blue"},w(l,"Title"),1,null),i(C,{classN:"text-s text-primary-dark-blue",get text(){return l.Paragraph},[s]:{classN:s,text:x(l,"Paragraph")}},3,"yQ_0")],1,null),1,null),1,r)),1,null),n("p",null,{class:"text-center justify-end my-5 text-white"},w(e,"DevicesNote"),1,null)],1,null),1,null),1,null),n("div",null,{class:"flex flex-col justify-center px-8 items-center"},[n("div",null,{class:"w-full md:w-2/3 flex flex-col items-center"},[n("h2",null,{class:"text-3xl md:text-4xl text-center font-bold text-primary-blue"},w(e.GuidePar,"Title"),1,null),i(C,{classN:"text-center",get text(){return e.GuidePar.Paragraph},[s]:{classN:s,text:x(e.GuidePar,"Paragraph")}},3,"yQ_1")],1,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-10 my-5"},e.Guides.map((l,r)=>i(Mr,{get urlDoc(){return l.Guide.data.attributes.url},get title(){return l.Title},get btnText(){return l.BtnText},get nameDoc(){return l.Guide.data.attributes.name},[s]:{btnText:x(l,"BtnText"),nameDoc:x(l.Guide.data.attributes,"name"),title:x(l,"Title"),urlDoc:x(l.Guide.data.attributes,"url")}},3,r)),1,null)],1,null),n("div",null,{class:"flex w-full flex-col items-center justify-center"},n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex min-[800px]:w-[70%] flex-col items-center justify-center gap-4 px-10"},[n("div",null,{class:"max-w-[470px]"},n("img",{alt:w(a.Logo.data.attributes,"alternativeText"),src:G(a.Logo.data.attributes.url),title:w(a.Logo.data.attributes,"caption")},{height:"230",width:"1230"},null,3,null),1,null),n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},w(a,"Title"),1,null),1,null),i(C,{get text(){return a.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{classN:s,text:x(a,"Paragraph")}},3,"yQ_2")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(Cr,{get nameDoc(){return a.GuideBox.Guide.data.attributes.name},get urlDoc(){return a.GuideBox.Guide.data.attributes.url},get image(){return a.Picture.data.attributes},get title(){return a.GuideBox.Title},get btnText(){return a.GuideBox.BtnText},[s]:{btnText:x(a.GuideBox,"BtnText"),image:x(a.Picture.data,"attributes"),nameDoc:x(a.GuideBox.Guide.data.attributes,"name"),title:x(a.GuideBox,"Title"),urlDoc:x(a.GuideBox.Guide.data.attributes,"url")}},3,"yQ_3"),1,null)],1,null),1,null)],1,"yQ_4")},Kf=m(f(Zf,"s_L3FZbhALRyo")),Xf=t=>`query gfTvSupport {
        pageGfTvS (locale:"${t}") {
          data {
            attributes {
              IntroText
              IntroMedia {
                ${b}
              }
              DevicesTitle
              Devices {
                Title
                Paragraph
                Buttons {
                  Text
                  Link
                }
              }
              DevicesNote
              GuidePar {
                Title
                Paragraph
              }
              Guides {
                Title
                BtnText
                Guide {
                  data {
                    attributes {
                      url
                      name
                    }
                  }
                }
              }
              ${F}
            }
          }
        }
        sectionChGuide{
          data{
            attributes{
              Logo{
                ${b}
              }
              Picture{
                ${b}
              }
              Title
              Paragraph
              GuideBox{
                Title
                BtnText
                Guide{
                  data{
                    attributes{
                      url
                      name
                    }
                  }
                }
              }
            }
          }
        }
      }
      `,Jf=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Xf,e)},Jl=N(f(Jf,"s_Y5JMYQJnIpI")),tx=()=>{const t=Jl(),e=t.value.pageData.data;return i(H,{children:i(z,{get data(){return t.value.layoutData},children:i(Kf,{data:e},3,"GS_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"GS_1")},1,"GS_2")},ex=m(f(tx,"s_sZYBtsmoVg8")),ax=({resolveValue:t})=>{const a=t(Jl).pageData.data.pageGfTvS.data.attributes.SEO;return Q(a)},lx=Object.freeze(Object.defineProperty({__proto__:null,default:ex,head:ax,usePageData:Jl},Symbol.toStringTag,{value:"Module"})),nx=t=>n("div",null,{class:"gap-10 w-ful flex flex-col"},t.data.map((e,a)=>Z(a%2==0?n("div",null,{class:"bg-primary-blue bg-opacity-40 py-10"},n("div",null,{class:"bg-primary-blue bg-opacity-60 py-10"},n("div",null,{class:"bg-primary-blue"},i(At,{color:"white",reverse:!0,get text(){return e.Paragraph},get image(){return e.Media.data.attributes},backgroundColor:"primary-blue",textPercentage:50,title:e.Title!=null?e.Title:"",[s]:{backgroundColor:s,color:s,image:x(e.Media.data,"attributes"),reverse:s,text:x(e,"Paragraph"),textPercentage:s}},3,a),1,null),1,null),1,a):i(At,{reverse:!1,get text(){return e.Paragraph},get image(){return e.Media.data.attributes},textPercentage:50,title:e.Title!=null?e.Title:"",[s]:{image:x(e.Media.data,"attributes"),reverse:s,text:x(e,"Paragraph"),textPercentage:s}},3,a))),1,"1n_0"),sx=m(f(nx,"s_3YkhEsBDjTI")),rx=t=>n("div",null,{class:"justify-between min-h-[670px] w-[300px] items-center shadow-lg bg-white flex flex-col px-5 pb-4 rounded-[35px]"},[n("div",null,{class:"items-center self-center flex w-[310px] max-w-full flex-col mt-8"},[n("div",null,{class:"items-start self-center flex w-full gap-5"},[n("img",{alt:G(t.logo.alternativeText),src:G(t.logo.url),title:G(t.logo.caption)},{class:"aspect-square object-contain object-center w-[70px] justify-center items-center overflow-hidden self-stretch max-w-full",height:80,loading:"lazy",width:80},null,3,null),n("div",null,{class:"self-center flex flex-col my-auto"},[n("div",null,{class:"text-blue-800 text-2xl font-bold leading-6 self-start whitespace-nowrap"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"justify-center text-rose-700 text-xl mt-2"},u(e=>e.subtitle,[t],"p0.subtitle"),3,null)],3,null)],1,null),n("div",null,{class:"text-blue-800 flex flex-row mt-5"},[n("span",null,{class:"font-light text-3xl text-rose-700"},"$",3,null),n("span",null,{class:"font-light text-3xl text-blue-800"},u(e=>e.price,[t],"p0.price"),3,null),n("span",null,{class:" text-blue-800"},["/",u(e=>e.priceTime,[t],"p0.priceTime")],3,null)],3,null),n("div",null,{class:"items-start self-stretch flex flex-col mt-5"},[n("div",null,{class:"justify-between items-start self-stretch flex w-full gap-5"},[n("div",null,{class:"text-blue-800 text-center text-base"},u(e=>e.description,[t],"p0.description"),3,null),i(ha,{get link(){return t.btnSeeMoreLink},get dataChannels(){return t.dataChannels},get planId(){return t.title},get channels(){return t.subtitle},get text(){return t.btnSeeMoreText},[s]:{channels:u(e=>e.subtitle,[t],"p0.subtitle"),dataChannels:u(e=>e.dataChannels,[t],"p0.dataChannels"),link:u(e=>e.btnSeeMoreLink,[t],"p0.btnSeeMoreLink"),planId:u(e=>e.title,[t],"p0.title"),text:u(e=>e.btnSeeMoreText,[t],"p0.btnSeeMoreText")}},3,"Tv_0")],1,null),n("div",null,{class:"justify-center items-start self-stretch flex gap-2.5 mt-2.5"},t.channels.map((e,a)=>n("img",{alt:G(e.attributes.alternativeText),src:G(e.attributes.url),title:G(e.attributes.caption)},{class:"aspect-square object-contain object-center w-full overflow-hidden flex-1",height:50,loading:"lazy",width:50},null,3,a)),1,null)],1,null),n("div",null,{class:"border-gary-500 h-[1px] w-full border-t-2"},null,3,null),n("div",null,{class:"self-stretch w-full h-px mt-5 max-md:mx-0.5"},null,3,null),n("div",null,{class:"text-blue-800 text-base mt-5"},t.features.map((e,a)=>n("span",null,{class:"my-1 flex flex-row items-center justify-start"},[n("div",null,null,i(br,{class:"mx-2 h-[20px] w-[20px] fill-primary-blue text-primary-blue",[s]:{class:s}},3,"Tv_1"),1,null),n("h3",null,{class:"text-sm font-light"},w(e,"Text"),1,a)],1,a)),1,null)],1,null),i(ha,{get link(){return t.btnLink},get text(){return t.btnText},[s]:{link:u(e=>e.btnLink,[t],"p0.btnLink"),text:u(e=>e.btnText,[t],"p0.btnText")}},3,"Tv_2")],1,"Tv_3"),ix=m(f(rx,"s_0v0O47RLS1E")),ox=t=>n("div",null,{class:"flex flex-col items-center justify-center my-8 mx-4"},[n("h2",null,{class:"text-3xl text-center md:text-5xl font-semibold text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-5 lg:gap-10 my-6"},t.data.map((e,a)=>i(ix,{get logo(){return e.Logo.data.attributes},get title(){return e.Title},get subtitle(){return e.Subtitle},get price(){return e.Price},get priceTime(){return e.Pricetime},get description(){return e.Description},get channels(){return e.Channels.data},get btnSeeMoreLink(){return e.LineupButton.Link},get btnSeeMoreText(){return e.LineupButton.Text},get features(){return e.Features},get btnLink(){return e.Button.Link},get btnText(){return e.Button.Text},get dataChannels(){return t.dataChannels},[s]:{btnLink:x(e.Button,"Link"),btnSeeMoreLink:x(e.LineupButton,"Link"),btnSeeMoreText:x(e.LineupButton,"Text"),btnText:x(e.Button,"Text"),channels:x(e.Channels,"data"),dataChannels:u(l=>l.dataChannels,[t],"p0.dataChannels"),description:x(e,"Description"),features:x(e,"Features"),logo:x(e.Logo.data,"attributes"),price:x(e,"Price"),priceTime:x(e,"Pricetime"),subtitle:x(e,"Subtitle"),title:x(e,"Title")}},3,a)),1,null)],1,"q0_0"),ux=m(f(ox,"s_m0jKnAHnXds")),cx=t=>n("div",null,{class:"flex flex-col items-center justify-center px-6"},[n("h2",null,{class:"text-3xl md:text-5xl my-3 font-semibold text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap gap-8 items-start justify-center my-4"},t.data.map((e,a)=>n("div",null,{class:"flex flex-col w-full md:w-2/5 my-3 md:my-5 p-6 text-center items-center justify-center rounded-2xl bg-white shadow-xl"},[n("h3",null,{class:"text-primary-dark-blue my-4 font-semibold text-xl"},w(e,"Title"),1,null),i(C,{get text(){return e.Paragraph},[s]:{text:x(e,"Paragraph")}},3,"ys_0")],1,a)),1,null),i(C,{classN:"markdownli text-s",get text(){return t.disclaimers},[s]:{classN:s,text:u(e=>e.disclaimers,[t],"p0.disclaimers")}},3,"ys_1")],1,"ys_2"),dx=m(f(cx,"s_Sqd58asrM5U")),px=t=>{let e=[];return n("div",null,{class:"flex flex-col items-center justify-center"},[n("h2",null,{class:"text-3xl text-center md:text-5xl my-3 font-semibold text-primary-blue"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap items-start justify-center my-6 gap-5"},t.data.map((a,l)=>n("div",null,{class:"w-[290px] min-h-[300px] py-6 px-2 flex-col items-center justify-center flex rounded-3xl bg-primary-blue"},[n("h2",null,{class:"text-3xl font-semibold text-white"},w(a,"Title"),1,null),n("div",null,{class:"flex flex-row"},[n("h2",null,{class:"text-white text-2xl"},["$ ",w(a,"Price")],1,null),n("p",null,{class:"text-white"},[" ",w(a,"Pricetime")],1,null)],1,null),n("div",null,{class:"flex flex-col bg-white w-full rounded-2xl mt-4 p-4"},a.Features.map((r,o)=>{if(Z(),o<3)return e=[],n("div",null,{class:"flex flex-row gap-2 p-1 border-b-2"},[i(Un,{class:"text-secondary-red",[s]:{class:s}},3,"yk_0"),n("p",null,{class:"text-primary-blue"},w(r,"Title"),1,null)],1,o);if(o>=3&&(e.push(n("div",null,{class:"flex flex-row gap-2 p-1 border-b-2"},[i(Un,{class:"text-secondary-red",[s]:{class:s}},3,"yk_1"),n("p",null,{class:"text-primary-blue"},w(r,"Title"),1,null)],1,o)),o==3))return i(xe,{children:e,title:"Show all channels",[s]:{title:s}},1,"yk_2")}),1,null)],1,l)),1,null)],1,"yk_3")},gx=m(f(px,"s_5iYsl7ZjuZc")),fx=t=>{const e=t.data.data.pageGfTv.data.attributes,a=t.data.data.sectionChGuide.data.attributes,l=t.data.data.channelLineups.data;return n("div",null,{class:"flex flex-col justify-around"},[n("div",null,{class:"flex flex-col my-6 items-center justify-center gap-4"},[n("img",{alt:w(e.Logo.data.attributes,"alternativeText"),src:G(e.Logo.data.attributes.url),title:w(e.Logo.data.attributes,"caption")},{height:200,width:500},null,3,null),n("h2",null,{class:"text-[50px] font-bold text-center text-primary-blue"},w(e.Titles[0],"Text"),1,null),n("h2",null,{class:"text-[50px] font-bold text-center text-secondary-red"},w(e.Titles[1],"Text"),1,null)],1,null),i(sx,{get data(){return e.Features},[s]:{data:x(e,"Features")}},3,"5L_0"),n("div",null,{class:"flex flex-col text-center p-4 items-center justify-center my-8"},[n("h2",null,{class:"text-3xl md:text-5xl font-semibold text-primary-blue my-6"},w(e.Feature,"Title"),1,null),i(C,{get text(){return e.Feature.Paragraph},[s]:{text:x(e.Feature,"Paragraph")}},3,"5L_1")],1,null),i(ux,{dataChannels:l,get data(){return e.ChPackTables},get title(){return e.ChPackTitle},[s]:{data:x(e,"ChPackTables"),title:x(e,"ChPackTitle")}},3,"5L_2"),i(gx,{get data(){return e.PremiumTables},get title(){return e.PremiumTitle},[s]:{data:x(e,"PremiumTables"),title:x(e,"PremiumTitle")}},3,"5L_3"),n("div",null,{class:"flex w-full flex-col items-center justify-center"},[n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex min-[800px]:w-[70%] flex-col items-center justify-center gap-4 px-10"},[n("div",null,{class:"max-w-[470px]"},n("img",{alt:w(a.Logo.data.attributes,"alternativeText"),src:G(a.Logo.data.attributes.url),title:w(a.Logo.data.attributes,"caption")},{height:"230",width:"1230"},null,3,null),1,null),n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},w(a,"Title"),1,null),1,null),i(C,{get text(){return a.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{classN:s,text:x(a,"Paragraph")}},3,"5L_4")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(Cr,{get nameDoc(){return a.GuideBox.Guide.data.attributes.name},get urlDoc(){return a.GuideBox.Guide.data.attributes.url},get image(){return a.Picture.data.attributes},get title(){return a.GuideBox.Title},get btnText(){return a.GuideBox.BtnText},[s]:{btnText:x(a.GuideBox,"BtnText"),image:x(a.Picture.data,"attributes"),nameDoc:x(a.GuideBox.Guide.data.attributes,"name"),title:x(a.GuideBox,"Title"),urlDoc:x(a.GuideBox.Guide.data.attributes,"url")}},3,"5L_5"),1,null)],1,null),i(dx,{get data(){return e.Additionals},get disclaimers(){return e.Disclaimers},get title(){return e.AdditionalsTitle},[s]:{data:x(e,"Additionals"),disclaimers:x(e,"Disclaimers"),title:x(e,"AdditionalsTitle")}},3,"5L_6")],1,null)],1,"5L_7")},xx=m(f(fx,"s_dsszBuF1I7U")),mx=t=>`sectionChGuide(locale:"${t}"){
        data{
          attributes{
            Logo{
              ${b}
            }
            Title
            Paragraph
            
            GuideBox{
              BtnText
              Guide{
                data{
                  attributes{
                    name
                    url
                  }
                }
              }
            }
            
            Picture{
             ${b}
            }
          }
        }
      }`,hx=t=>`query {
        pageGfTv(locale:"${t}"){
          data {
            attributes {
              Logo {
               ${b}
              }
              Titles {
                Text
              }
              Features {
                Title
                Subtitle
                Paragraph
                Media {
                  ${b}
                }
              }
              Feature {
                Title
                Subtitle
                Paragraph
              }
              ChPackTitle
              ChPackTables {
                Logo {
                  ${b}
                }
                Title
                Subtitle
                Price
                Pricetime
                Description
                Channels {
                  ${b}
                }
                LineupButton{
                  Text
                  Link
                }
                Features {
                  Title
                  Text
                }
                Button {
                  Text
                  Link
                }
              }
              PremiumTitle
              PremiumTables {
                Title
                Price
                Pricetime
                Features {
                  Title
                }
              }
      
              
              
              AdditionalsTitle
              Additionals {
                Title
                Paragraph
              }
              Disclaimers
              
              ${F}
            }
          }
        }
        
        ${mx(t)}

        channelLineups (pagination:{limit:250}){
          data{
            attributes{
              Channel_name
              Image{
                ${b}
              }
              Category
              package_tvs{
                data{
                  attributes{
                    package
                  }
                }
              }
            }
        }
        }
      }`,$x=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(hx,e)},tn=N(f($x,"s_dLnU84H8AgM")),bx=()=>{const t=tn();return console.log(t.value.pageData),i(H,{children:i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageGfTv.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfTv.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfTv"]["data"]["attributes"]["SEO"]')}},3,"ad_0"),i(xx,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"ad_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"ad_2")},1,"ad_3")},vx=m(f(bx,"s_yF5Z09ey0P4")),yx=({resolveValue:t})=>{const a=t(tn).pageData.data.pageGfTv.data.attributes.SEO;return Q(a)},wx=Object.freeze(Object.defineProperty({__proto__:null,default:vx,head:yx,usePageData:tn},Symbol.toStringTag,{value:"Module"})),_x=t=>{const e=t.data.pageGfVS.data.attributes,a=t.data.sectionPortGfv.data.attributes.Portability;return n("div",null,{class:"flex flex-col items-center"},[n("div",null,{class:"relative w-full md:w-2/3 h-[210px] md:h-[150px] bg-blue-200 flex flex-row justify-end items-center rounded-full"},[n("div",null,{class:"h-full absolute rounded-full w-3/4 bg-blue-300"},null,3,null),n("div",null,{class:"h-full absolute rounded-full w-2/4 bg-blue-400"},null,3,null),n("div",null,{class:"h-full absolute rounded-full w-1/4 bg-blue-600"},null,3,null),n("div",null,{class:"absolute w-full h-full flex flex-row p-5 justify-between items-center"},[n("h1",null,{class:"text-primary-blue lg:text-3xl md:text-2xl font-bold text-center text-xl"},w(e.Introduction,"Paragraph"),1,null),n("img",{alt:w(e.Introduction.Media.data.attributes,"alternativeText"),src:G(e.Introduction.Media.data.attributes.url),title:w(e.Introduction.Media.data.attributes,"caption")},{height:150,width:200},null,3,null)],1,null)],1,null),n("div",null,{class:"flex flex-col mt-10 justify-center px-8 items-center"},[n("div",null,{class:"w-full md:w-2/3 flex flex-col items-center"},[n("h2",null,{class:"text-3xl md:text-4xl text-center font-bold text-primary-blue"},w(e.GuidesPar,"Title"),1,null),i(C,{classN:"text-center",get text(){return e.GuidesPar.Paragraph},[s]:{classN:s,text:x(e.GuidesPar,"Paragraph")}},3,"T3_0")],1,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-10 my-5"},e.Guides.map((l,r)=>i(Mr,{get urlDoc(){return l.Guide.data.attributes.url},get title(){return l.Title},get btnText(){return l.BtnText},get nameDoc(){return l.Guide.data.attributes.name},[s]:{btnText:x(l,"BtnText"),nameDoc:x(l.Guide.data.attributes,"name"),title:x(l,"Title"),urlDoc:x(l.Guide.data.attributes,"url")}},3,r)),1,null)],1,null),n("div",null,null,i(At,{get title(){return a.Title},get text(){return a.Paragraph},get logo(){return a.Logo.data.attributes},get image(){return a.Media.data.attributes},backgroundColor:"transparent",get buttons(){return a.Buttons},[s]:{backgroundColor:s,buttons:x(a,"Buttons"),image:x(a.Media.data,"attributes"),logo:x(a.Logo.data,"attributes"),text:x(a,"Paragraph"),title:x(a,"Title")}},3,"T3_1"),1,null)],1,"T3_2")},Sx=m(f(_x,"s_BWUEQjQaK9s")),Tx=t=>`query queryGFTvSupport{
        pageGfVS(locale:"${t}"){
          data{
            attributes{
              Introduction{
                Paragraph
                Media{
                  ${b}
                }
              }
              GuidesPar{
                Title
                Paragraph
              }
              Guides{
                Title
                BtnText
                Guide{
                  data{
                    attributes{
                      url
                      name
                    }
                  }
                }
              }
              ${F}
            }
          }
        }
        sectionPortGfv(locale:"${t}"){
          data{
            attributes{
              Portability{
                Title
                Logo{
                 ${b}
                }
                Paragraph
                Media{
                 ${b}
                }
                Buttons{
                  Text
                  Link
                }
              }
            }
          }
        }
      }`,Dx=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Tx,e)},en=N(f(Dx,"s_MmL0KO3X80U")),Px=()=>{const t=en();return i(H,{children:i(z,{get data(){return t.value.layoutData},children:i(Sx,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Wc_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Wc_1")},1,"Wc_2")},kx=m(f(Px,"s_MnhzpLl96M8")),Lx=({resolveValue:t})=>{const a=t(en).pageData.data.pageGfVS.data.attributes.SEO;return Q(a)},Mx=Object.freeze(Object.defineProperty({__proto__:null,default:kx,head:Lx,usePageData:en},Symbol.toStringTag,{value:"Module"})),Cx=t=>n("div",null,{class:"flex w-full justify-center text-primary-blue"},n("div",null,{class:"mx-8 my-8 flex flex-col items-center gap-6 text-center text-[18px]"},[i(E,{get url(){return t.data.Logo.data.attributes.url},get alt(){return t.data.Logo.data.attributes.alternativeText},get title(){return t.data.Logo.data.attributes.caption},clasN:"mb-6",width:"450",[s]:{alt:u(e=>e.data.Logo.data.attributes.alternativeText,[t],'p0.data["Logo"]["data"]["attributes"]["alternativeText"]'),clasN:s,title:u(e=>e.data.Logo.data.attributes.caption,[t],'p0.data["Logo"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.Logo.data.attributes.url,[t],'p0.data["Logo"]["data"]["attributes"]["url"]'),width:s}},3,"0F_0"),i(C,{get text(){return t.data.Paragraph},[s]:{text:u(e=>e.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"0F_1"),i(X,{get text(){return t.data.Buttons[0].Text},get link(){return t.data.Buttons[0].Link},[s]:{link:u(e=>e.data.Buttons[0].Link,[t],'p0.data["Buttons"][0]["Link"]'),text:u(e=>e.data.Buttons[0].Text,[t],'p0.data["Buttons"][0]["Text"]')}},3,"0F_2")],1,null),1,"0F_3"),jx=m(f(Cx,"s_Ue8VWX4F1hY")),Ix=t=>n("div",null,{class:"max-w-1200 mx-8 flex flex-wrap justify-evenly gap-6"},t.data.map((e,a)=>i(Yl,{get title(){return e.Title},get btnText(){return e.Button.Text},get btnLink(){return e.Button.Link},get description(){return e.Description},price:e.Price.toString(),get features(){return e.Features},get logo(){return e.Logo.data.attributes},get priceTime(){return e.Pricetime},[s]:{btnLink:x(e.Button,"Link"),btnText:x(e.Button,"Text"),description:x(e,"Description"),features:x(e,"Features"),logo:x(e.Logo.data,"attributes"),priceTime:x(e,"Pricetime"),title:x(e,"Title")}},3,a)),1,"mV_0"),Ex=m(f(Ix,"s_2f78m38d8Zo")),Ox=t=>{const e={...t.data.pageGfV.data.attributes.Introduction,Logo:t.data.pageGfV.data.attributes.Logo},a=t.data.pageGfV.data.attributes.PackTables,l=t.data.sectionPortGfv.data.attributes.Portability;return n("div",null,null,[i(jx,{data:e},3,"Pl_0"),n("div",null,{class:"mt-6"},i(Ex,{data:a},3,"Pl_1"),1,null),n("div",null,{class:"mt-6"},i(qt,{backgroundColor:"transparent",color:"primary-blue",data:l,[s]:{backgroundColor:s,color:s}},3,"Pl_2"),1,null)],1,"Pl_3")},Bx=m(f(Ox,"s_S2NF7hg0ZA8")),Ax=t=>`
  query {
    pageGfV(locale:"${t}") {
      data {
        attributes {
          Logo {
            ${b}
          }
          Introduction {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          PackTables {
            Logo {
              ${b}
            }
            Title
            Subtitle
            Price
            Pricetime
            Description
            Features {
              Title
              Text
            }
            Button {
              Text
              Link
              Icon {
                data {
                  attributes {
                    name
                    url
                  }
                }
              }
            }
          }
          ${F}
        
        }
      }
    }
    sectionPortGfv(locale:"${t}"){
        data{
          attributes{
            Portability{
              Title
              Logo{
               ${b}
              }
              Paragraph
              Media{
               ${b}
              }
              Buttons{
                Text
                Link
              }
            }
          }
        }
      }
  }
    `,Nx=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Ax,e)},an=N(f(Nx,"s_ThxJp560MGY")),qx=()=>{const t=an();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageGfV.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfV.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfV"]["data"]["attributes"]["SEO"]')}},3,"0t_0"),i(Bx,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"0t_1")],showHeader:!1,[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"0t_2")},Rx=m(f(qx,"s_1bc90Wt0fJ4")),zx=({resolveValue:t})=>{const a=t(an).pageData.data.pageGfV.data.attributes.SEO;return Q(a)},Fx=Object.freeze(Object.defineProperty({__proto__:null,default:Rx,head:zx,usePageData:an},Symbol.toStringTag,{value:"Module"})),Gx=t=>{const e=t.data.pageGivingBack.data.attributes.Helping;return n("div",null,{onClick$:B("s_IrVC6P6zSuQ")},i(ee,{data:e},3,"eb_0"),1,"eb_1")},Qx=m(f(Gx,"s_g0kQhWSZ3HE")),Hx=t=>`
    query QueryGivingBack {
        pageGivingBack(locale:"${t}"){    
          data{
            attributes{
                 Title
              Helping{
                Logo{
                 ${b}
                }
                Media{
                  ${b}
                }
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              ${F}
            }
          }
        }
      }
    `,Wx=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Hx,e)},ln=N(f(Wx,"s_HxhGEMn0sRc")),Ux=()=>{const t=ln();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageGivingBack.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGivingBack.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGivingBack"]["data"]["attributes"]["SEO"]')}},3,"4m_0"),i(Qx,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"4m_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"4m_2")},Vx=m(f(Ux,"s_NbmekxDi7Vw")),Yx=({resolveValue:t})=>{const a=t(ln).pageData.data.pageGivingBack.data.attributes.SEO;return Q(a)},Zx=Object.freeze(Object.defineProperty({__proto__:null,default:Vx,head:Yx,usePageData:ln},Symbol.toStringTag,{value:"Module"})),Kx=t=>`query QueryLeadershipTeam{
        pageLeadershipT(locale:"${t}"){
          data{
            attributes{
              ${$r}
              ${F}
              }
            }
          }
        }`,Xx=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Kx,e)},nn=N(f(Xx,"s_ZvTItzMmB40")),Jx=()=>{const t=nn(),e=t.value.pageData.data.pageLeadershipT.data.attributes;return i(H,{children:i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageLeadershipT.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageLeadershipT.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageLeadershipT"]["data"]["attributes"]["SEO"]')}},3,"cW_0"),i(kr,{data:e},3,"cW_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"cW_2")},1,"cW_3")},tm=m(f(Jx,"s_VJGz1Q1nMWA")),em=({resolveValue:t})=>{const a=t(nn).pageData.data.pageLeadershipT.data.attributes.SEO;return Q(a)},am=Object.freeze(Object.defineProperty({__proto__:null,default:tm,head:em,usePageData:nn},Symbol.toStringTag,{value:"Module"})),lm=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),n("h2",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[1].Text,[t],'p0.data["Titles"][1]["Text"]'),3,null),i(C,{get text(){return t.data.TextContent},classN:" text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"tP_0")],1,"tP_1"),nm=m(f(lm,"s_l6pybhQ4d3A")),sm=t=>`query QueryLegal {
        pageLegal(locale:"${t}"){    
          ${Ue}
          ${F}
            }
          }
        }
      }`,rm=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(sm,e)},sn=N(f(rm,"s_p9UoBCtfUPo")),im=()=>{const t=sn(),e=t.value.pageData.data.pageLegal.data.attributes.Content;return i(H,{children:i(z,{get data(){return t.value.layoutData},children:i(nm,{data:e},3,"W8_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"W8_1")},1,"W8_2")},om=m(f(im,"s_DAHSW75A6dQ")),um=({resolveValue:t})=>{const a=t(sn).pageData.data.pageLegal.data.attributes.SEO;return Q(a)},cm=Object.freeze(Object.defineProperty({__proto__:null,default:om,head:um,usePageData:sn},Symbol.toStringTag,{value:"Module"})),dm=t=>{const e=t.data.pageLocWeather.data.attributes,a=l=>`https://raw.githubusercontent.com/visualcrossing/WeatherIcons/main/PNG/1st%20Set%20-%20Color/${l}.png`;return n("div",null,{class:"flex flex-wrap items-center justify-center gap-8 px-8 py-8 text-white",onClick$:B("s_VJdTV7fBj8k")},t.data.weatherData.data.map((l,r)=>n("div",null,{class:"relative h-[350px] w-[600px] max-[1200px]:h-[280px] max-[1200px]:w-[500px]"},[n("div",null,{class:"relative flex h-full w-[50%] flex-col justify-between overflow-hidden rounded-[30px] px-4 py-8 "},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-[6] h-full w-full"},i(E,{clasN:"h-[400px]",height:"3086",width:"2622",get url(){return e.LocTables.find(o=>o.Location===l.city).LocationPic.data.attributes.url},get alt(){return e.LocTables.find(o=>o.Location===l.city).LocationPic.data.attributes.alternativeText},get title(){return e.LocTables.find(o=>o.Location===l.city).LocationPic.data.attributes.caption},[s]:{alt:x(e.LocTables.find(o=>o.Location===l.city).LocationPic.data.attributes,"alternativeText"),clasN:s,height:s,title:x(e.LocTables.find(o=>o.Location===l.city).LocationPic.data.attributes,"caption"),url:x(e.LocTables.find(o=>o.Location===l.city).LocationPic.data.attributes,"url"),width:s}},3,"tT_0"),1,null),n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-[5] h-full w-full bg-black opacity-30"},null,3,null),n("div",null,{class:"flex flex-col"},[n("span",{onClick$:B("s_K3eGiPS50Ks",[l])},{class:"text-[20px] font-[700]"},Xe(l.data.days[0].datetime).split(", ")[0],0,null),n("span",null,{class:"text-[12px]"},Xe(l.data.days[0].datetime,!1),1,null),n("div",null,{class:"mt-2 flex items-center gap-3"},[i(jl,{class:"text-[15px] text-white",[s]:{class:s}},3,"tT_1"),n("span",null,{class:"text-[17px] font-[600] max-[1200px]:text-[15px]"},w(l,"city"),1,null)],1,null)],1,null),n("div",null,null,[n("span",null,{class:"text-[18px] font-[700]"},w(l.data.days[0],"conditions"),1,null),n("img",{alt:`icon-${l.data.days[0].icon}`,src:a(l.data.days[0].icon),title:`icon-${l.data.days[0].icon}`},{height:"50",width:"50"},null,3,null)],1,null),n("div",null,{class:"flex w-full justify-evenly"},[n("div",null,{class:"flex flex-col items-center"},[n("span",null,{class:"text-[14px]"},"Min",3,null),n("span",null,{class:"text-[28px] font-[700] max-[1200px]:text-[20px]"},[w(l.data.days[0],"tempmin"),"°F"],1,null)],1,null),n("div",null,{class:"flex flex-col items-center"},[n("span",null,{class:"text-[14px]"},"Max",3,null),n("span",null,{class:"text-[28px] font-[700] max-[1200px]:text-[20px]"},[w(l.data.days[0],"tempmin"),"°F"],1,null)],1,null)],1,null)],1,null),n("div",null,{class:"absolute bottom-3 right-0 top-3 -z-[7] flex w-[56%] flex-col gap-1 rounded-[30px] bg-[#172c4b] py-8 pl-14 pr-6 text-[17px] max-[1200px]:text-[13px]"},[n("div",null,{class:"flex justify-between font-[700] "},[n("span",null,null,"PRECIPITATION",3,null),n("span",null,{class:"font-[300]"},[w(l.data.days[0],"precipprob"),"%"],1,null)],1,null),n("div",null,{class:"flex justify-between font-[700]"},[n("span",null,null,"HUMIDITY",3,null),n("span",null,{class:"font-[300]"},[w(l.data.days[0],"humidity"),"%"],1,null)],1,null),n("div",null,{class:"flex justify-between font-[700]"},[n("span",null,null,"WIND",3,null),n("span",null,{class:"font-[300]"},[w(l.data.days[0],"windspeed")," mph"],1,null)],1,null),n("div",null,{class:"mt-6 grid grid-cols-3 justify-center gap-1"},[1,2,3].map(o=>n("div",null,{class:"flex flex-col items-center gap-1 text-[12px] max-[1200px]:text-[9px]"},[n("img",{alt:`icon-${l.data.days[o].icon}`,src:a(l.data.days[o].icon),title:`icon-${l.data.days[o].icon}`},{height:"30",width:"30"},null,3,null),n("span",null,{class:""},Xe(l.data.days[o].datetime).split(", ")[0],1,null),n("span",null,{class:"font-[600]"},[w(l.data.days[o],"tempmax"),"°F"],1,null),n("span",null,{class:"font-[600]"},[w(l.data.days[o],"tempmin"),"°F"],1,null)],1,o)),1,null)],1,null)],1,r)),1,"tT_2")},pm=m(f(dm,"s_Eyqu8EYnqHs")),gm=t=>`query locWeather{
        pageLocWeather(locale:"${t}"){
          data{
            attributes{
              LocTables{
                Location
                LocationPic{
                  ${b}
                }
              }
              ${F}
            }
          }
        }
      }`,fm=async t=>{const e=t.params.lang==""?"en":"es-419",a=await R(gm,e),l={status:"error",data:[]};for(const r of a.pageData.data.pageLocWeather.data.attributes.LocTables){const o=r.Location,c=await fetch(`https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${o}/next7days?unitGroup=us&include=days%2Ccurrent&key=J8MMBMZC9DTQTVGHBPNEWPPGS&contentType=json`);if(c.ok){const d=await c.json();l.data.push({city:o,data:d})}}return{...a,weatherData:l}},rn=N(f(fm,"s_gwWti8fe82E")),xm=()=>{const t=rn();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageLocWeather.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageLocWeather.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageLocWeather"]["data"]["attributes"]["SEO"]')}},3,"rD_0"),i(pm,{get data(){return{pageLocWeather:t.value.pageData.data.pageLocWeather,weatherData:t.value.weatherData}},[s]:{data:u(e=>({pageLocWeather:e.value.pageData.data.pageLocWeather,weatherData:e.value.weatherData}),[t],'{pageLocWeather:p0.value["pageData"]["data"]["pageLocWeather"],weatherData:p0.value["weatherData"]}')}},3,"rD_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"rD_2")},mm=m(f(xm,"s_VS5ugbSZKZs")),hm=({resolveValue:t})=>{const a=t(rn).pageData.data.pageLocWeather.data.attributes.SEO;return Q(a)},$m=Object.freeze(Object.defineProperty({__proto__:null,default:mm,head:hm,usePageData:rn},Symbol.toStringTag,{value:"Module"})),bm=t=>{const e=t.data.pageNews.data.attributes,a=e.Posts.data[0].attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(Dr,{post:a},3,"MY_0"),n("div",null,{class:"my-4"},null,3,null),i(Pr,{get posts(){return e.Posts.data},loadSize:3,type:"News",[s]:{loadSize:s,posts:x(e.Posts,"data"),type:s}},3,"MY_1")],1,"MY_2")},vm=m(f(bm,"s_d8TgHnXz650")),ym=t=>` query QueryNews {
        pageNews(locale:"${t}"){    
          data{
          attributes{
            Posts(sort: "Date:desc", pagination: { limit: 100 }){
                data{
                  attributes{
                    Title
                    Date
                    Cover{
                      ${b}
                    }
                    Description
                    VideoLink
                    Gallery{
                      ${b}
                    }
                    Slug
                  }
                }
              }
            SugPages{
              Title
              Pages{
              Title
              Link
              Picture{
                ${b}
              }
              }
            }
            ${F}
          }
        }
        }
      }`,wm=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(ym,e)},on=N(f(wm,"s_HdPbxCOsb5s")),_m=()=>{const t=on();return i(z,{get data(){return t.value.layoutData},children:i(vm,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"7N_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"7N_1")},Sm=m(f(_m,"s_Afg1iFacoB8")),Tm=({resolveValue:t})=>{const a=t(on).pageData.data.pageNews.data.attributes.SEO;return Q(a)},Dm=Object.freeze(Object.defineProperty({__proto__:null,default:Sm,head:Tm,usePageData:on},Symbol.toStringTag,{value:"Module"})),Pm=t=>n("div",null,{class:"flex flex-col items-center text-primary-blue"},[n("h2",null,{class:"px-4 md:px-8 text-center font-semibold text-secondary-red text-2xl md:text-3xl"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),n("h3",null,{class:"px-4 md:px-8 text-center text-xl md:text-2xl"},u(e=>e.data.Titles[1].Text,[t],'p0.data["Titles"][1]["Text"]'),3,null),n("div",null,{class:"flex px-4 md:px-8 mt-5 flex-wrap items-center justify-center"},[n("div",null,{class:"flex flex-col w-full lg:w-3/5 mx-5"},[n("h3",null,{class:"font-bold my-4 text-2xl md:text-4xl text-center"},u(e=>e.data.CommitmentPar.Title,[t],'p0.data["CommitmentPar"]["Title"]'),3,null),i(C,{get text(){return t.data.CommitmentPar.Paragraph},classN:"text-justify",[s]:{classN:s,text:u(e=>e.data.CommitmentPar.Paragraph,[t],'p0.data["CommitmentPar"]["Paragraph"]')}},3,"aa_0")],1,null),i(Be,{height:"h-[350px]",width:"w-[350px]",get alt(){return t.data.CommitmentPar.Media.data.attributes.alternativeText},get url(){return t.data.CommitmentPar.Media.data.attributes.url},get title(){return t.data.CommitmentPar.Media.data.attributes.caption},[s]:{alt:u(e=>e.data.CommitmentPar.Media.data.attributes.alternativeText,[t],'p0.data["CommitmentPar"]["Media"]["data"]["attributes"]["alternativeText"]'),height:s,title:u(e=>e.data.CommitmentPar.Media.data.attributes.caption,[t],'p0.data["CommitmentPar"]["Media"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.CommitmentPar.Media.data.attributes.url,[t],'p0.data["CommitmentPar"]["Media"]["data"]["attributes"]["url"]'),width:s}},3,"aa_1")],1,null),n("div",null,{class:"flex px-8 mt-8 flex-col md:flex-row justify-center md:justify-around items-center md:items-start"},t.data.ColumnsPar.map((e,a)=>n("div",null,{class:"flex flex-col my-5 w-full md:w-1/2 justify-center items-center"},[n("h2",null,{class:"font-bold  text-2xl md:text-4xl text-center"},w(e,"Title"),1,null),i(C,{get text(){return e.Paragraph},[s]:{text:x(e,"Paragraph")}},3,"aa_2")],1,a)),1,null),n("h3",null,{class:"font-bold text-2xl md:text-4xl mt-8 text-center"},u(e=>e.data.SponsorshipsTitle,[t],'p0.data["SponsorshipsTitle"]'),3,null),n("div",null,{class:"flex items-center justify-center w-full my-4"},[n("div",null,{class:"w-full flex bg-primary-blue bg-opacity-30 my-4 h-[350px] py-10"},n("div",null,{class:"w-full bg-primary-blue py-10 bg-opacity-60"},n("div",null,{class:"w-full h-full bg-primary-blue"},null,3,null),3,null),3,null),t.data.Sponsorships.map((e,a)=>n("div",null,{class:"h-[350px] px-6 absolute flex flex-col justify-around items-center w-[250px] bg-white rounded-3xl shadow-xl"},[i(Be,{height:"h-[200px]",width:"w-[200px]",get alt(){return e.Media.data.attributes.alternativeText},get url(){return t.data.Sponsorships[0].Media.data.attributes.url},get title(){return t.data.Sponsorships[0].Media.data.attributes.caption},[s]:{alt:x(e.Media.data.attributes,"alternativeText"),height:s,title:u(l=>l.data.Sponsorships[0].Media.data.attributes.caption,[t],'p0.data["Sponsorships"][0]["Media"]["data"]["attributes"]["caption"]'),url:u(l=>l.data.Sponsorships[0].Media.data.attributes.url,[t],'p0.data["Sponsorships"][0]["Media"]["data"]["attributes"]["url"]'),width:s}},3,"aa_3"),n("div",null,{class:"flex flex-col items-center"},[n("h3",null,{class:"text-secondary-red text-xl font-semibold"},w(e,"Title"),1,null),n("h3",null,{class:"text-secondary-red text-xl font-semibold"},w(e,"Subtitle"),1,null)],1,null),i(X,{get text(){return e.Buttons[0].Text},get link(){return e.Buttons[0].Link},[s]:{link:x(e.Buttons[0],"Link"),text:x(e.Buttons[0],"Text")}},3,"aa_4")],1,a))],1,null)],1,"aa_5"),km=m(f(Pm,"s_RH3prNj9z7A")),Lm=t=>`query QueryOurStory{
        pageOurStory(locale:"${t}"){
          data{
            attributes{
              Titles{
                Text
              }
              CommitmentPar{
                Title
                Paragraph
                Media{
                ${b}
                }
              }
              
              ColumnsPar{
                Title
                Paragraph
              }
              
              SponsorshipsTitle
              Sponsorships{
                Title
                Subtitle
                Paragraph
                Media{
                ${b}
                }
                Buttons{
                  Text
                  Link
                }
              }
              ${F}
             
            }
          }
        }
      }`,Mm=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Lm,e)},un=N(f(Mm,"s_I9YCjFVOHNE")),Cm=()=>{const t=un(),e=t.value.pageData.data.pageOurStory.data.attributes;return i(H,{children:i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return e.SEO},[s]:{SEOdata:x(e,"SEO")}},3,"CH_0"),i(km,{data:e},3,"CH_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"CH_2")},1,"CH_3")},jm=m(f(Cm,"s_ONSPkGdkwcs")),Im=({resolveValue:t})=>{const a=t(un).pageData.data.pageOurStory.data.attributes.SEO;return Q(a)},Em=Object.freeze(Object.defineProperty({__proto__:null,default:jm,head:Im,usePageData:un},Symbol.toStringTag,{value:"Module"})),Om=t=>{const e=t.data.Logo.data.attributes,a=t.data.Media.data.attributes;return n("div",null,{class:"flex max-w-[1200px] items-center justify-center self-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-4 px-10 min-[800px]:w-[70%]"},[n("div",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(l=>l.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"max-w-[470px]"},i(E,{get url(){return e.url},get alt(){return e.alternativeText},get title(){return e.caption},height:230,width:1230,[s]:{alt:x(e,"alternativeText"),height:s,title:x(e,"caption"),url:x(e,"url"),width:s}},3,"Y3_0"),1,null),n("div",null,null,i(C,{classN:"max-sm:text-[15px] text-[18px] text-[#2E5899]",get text(){return t.data.Paragraph},[s]:{classN:s,text:u(l=>l.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"Y3_1"),1,null)],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(E,{get url(){return a.url},get alt(){return a.alternativeText},get title(){return a.caption},height:1e3,width:1e3,[s]:{alt:x(a,"alternativeText"),height:s,title:x(a,"caption"),url:x(a,"url"),width:s}},3,"Y3_2"),1,null)],1,"Y3_3")},Bm=m(f(Om,"s_G8eOcGEKYk4")),Am=t=>{const e=t.data.pagePortability.data.attributes.PortabilityActs,a=t.data.pagePortability.data.attributes.Introduction;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(Bm,{data:a},3,"C7_0"),i(ee,{data:e},3,"C7_1")],1,"C7_2")},Nm=m(f(Am,"s_OvPpWmexBMU")),qm=t=>`
    query QueryPortability{
        pagePortability(locale:"${t}"){    
          data{
            attributes{
              Introduction{
                Title
                Subtitle
                Logo{
                ${b}
                }
                Paragraph
                Media{
                ${b}
                }
              }
              
              IntroductionBG{
                ${b}
              }
      
              PortabilityActs{
                Title
                Subtitle
                Buttons{
                  Text
                  Link
                }
                Logo{
                ${b}
                }
                Paragraph
                Media{
                ${b}
                }
              }
              ${F}
            }
          }
        }
      }
    `,Rm=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(qm,e)},cn=N(f(Rm,"s_DV97RmVctT4")),zm=()=>{const t=cn();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pagePortability.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pagePortability.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pagePortability"]["data"]["attributes"]["SEO"]')}},3,"eB_0"),i(Nm,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"eB_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"eB_2")},Fm=m(f(zm,"s_LbhuqOuteuA")),Gm=({resolveValue:t})=>{const a=t(cn).pageData.data.pagePortability.data.attributes.SEO;return Q(a)},Qm=Object.freeze(Object.defineProperty({__proto__:null,default:Fm,head:Gm,usePageData:cn},Symbol.toStringTag,{value:"Module"})),jr=new Date,Hm=jr.toISOString().substring(0,10),Wm=jr.toISOString().substring(11,19),Ir=t=>`
    query QueryHome{
  pageHome(locale:"${t}"){
    data{
      attributes{
        
        VideoBGDesktop{
          ${b}
        }
        VideoBGMobile{
          ${b}
        }
        HeroCarSlideZS{
          Video{
            ${b}
          }
          Description
          Logo{
            ${b}
          }
          RaceDate
        }

        HeroCarSlides{
          Title
          Subtitle
          Logo{
          ${b}
          }
          Paragraph
          Media{
          ${b}
          }
          Buttons{
            Text
            Link
          }
        }
        HeroForm{
          Title
          ActionButton{
            Text
            Link
          }
        }
        ProsPar{
          Title
          Paragraph
        }

        ProsPicture{
          ${b}
        }
        ProsBackground{
          ${b}
        }
        ParACP{
          Title
          Subtitle
          Paragraph
          Logo{
          ${b}
          }
          Media{
          ${b}
          }
          Buttons{
            Text
            Link
          }
        }
        ParGFIPlans{
          Title
          Paragraph
          Disclaimer{
            Title
            Text
            Caption
            Icon{
          ${b}
            }
          }
          Table{
            ColumnOne
            ColumnTwo
            ColumnThree
          }

        }
        ParGFServices{
          Title
          Subtitle
          Logo{
          ${b}
          }
          Paragraph
          Media{
          ${b}
          }
          Buttons{
            Text
            Link
          }
        }
        SugsPages{
          Title
          Paragraph
          Media{
          ${b}
          }
          Buttons{
            Text
            Link
          }
        }
        SugsPagesBG{
          ${b}
        }
        ${F}
      }
    }
  }
  zaneRaces (
    filters: {RaceDay: {gte: "${Hm}"}, RaceTime: {gte: "${Wm}"}}, 
    locale:"en", 
    sort: "RaceDate"
    pagination: {limit: 1}) {
    data {
      attributes {
        Video {
          data {
            attributes {
              url
              alternativeText
              caption
            }
          }
        }
        Logo {
          data {
            attributes {
              url
              alternativeText
              caption
            }
          }
        }
        Description
        RaceDay
        RaceTime
      }
    }
  }
  sectionProsRta {
    data {
      attributes {
        Pros {
          Icon {
            data {
            attributes {
              url
              alternativeText
              caption
            }
          }
          }
          Title
          Text
          Caption
        }
      }
    }
  }
  sectionNetwork {
    data {
      attributes {
        Map {
          MapPicture {
            data {
              attributes {
                url
              }
            }
          }
        }
      }
    }
  }
}
`,Um=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang;return await R(Ir,e)},Vm=N(f(Um,"s_MfWlD1sVVR8")),Ym=()=>n("div",null,null,"a",3,"yK_0"),Zm=m(f(Ym,"s_S2euYekMMCk")),Km=Object.freeze(Object.defineProperty({__proto__:null,default:Zm,usePageData:Vm},Symbol.toStringTag,{value:"Module"})),Xm=t=>n("div",null,{class:"p-6"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(C,{get text(){return t.data.TextContent},classN:"markdownTitle markdownHyper text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"Vp_0")],1,"Vp_1"),Jm=m(f(Xm,"s_m0xHvviU9eM")),th=t=>`
query QueryPrivacyP {
  pagePrivacyP(locale:"${t}"){    
    ${Ue}
    ${F}
      }
    }
  }
}
`,eh=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(th,e)},dn=N(f(eh,"s_010w2sLh1OQ")),ah=()=>{const t=dn(),e=t.value.pageData.data.pagePrivacyP.data.attributes.Content;return i(z,{get data(){return t.value.layoutData},children:i(Jm,{data:e},3,"bX_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"bX_1")},lh=m(f(ah,"s_vRJXLmWn290")),nh=({resolveValue:t})=>{const a=t(dn).pageData.data.pagePrivacyP.data.attributes.SEO;return Q(a)},sh=Object.freeze(Object.defineProperty({__proto__:null,default:lh,head:nh,usePageData:dn},Symbol.toStringTag,{value:"Module"})),rh=t=>n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"min-h-[200px] w-full bg-gradient-to-br from-primary-light-blue to-[#23477f] !text-white"},i(qt,{get data(){return t.data},backgroundColor:"primary-blue",color:"white",hasPricing:!1,reverse:!0,[s]:{backgroundColor:s,color:s,data:u(e=>e.data,[t],"p0.data"),hasPricing:s,reverse:s}},3,"7j_0"),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"7j_1"),ih=m(f(rh,"s_05kJ0dE4eLY")),oh=t=>{const e=t.data.pageReferralP.data.attributes,a=e.Steps.Bullets.map(l=>l.Text);return n("div",null,null,[i(ih,{get data(){return e.RefInfo},[s]:{data:x(e,"RefInfo")}},3,"Kl_0"),n("div",null,{class:"flex items-center justify-center px-8 py-8"},n("div",null,{class:" max-w-[1400px] "},[n("h4",null,{class:"mb-6 text-center text-[20px] font-[500] leading-6 text-primary-blue"},w(e,"StepsIntro"),1,null),n("h3",null,{class:"mb-6 text-center text-[42px] font-[700] leading-10 text-secondary-red"},w(e.Steps,"Title"),1,null),n("div",null,{class:"max-[799px]:hidden"},i(Oe,{align:"center",direction:"vertical",steps:a,[s]:{align:s,direction:s}},3,"Kl_1"),1,null),n("div",null,{class:"min-[800px]:hidden"},i(Oe,{align:"start",direction:"vertical",steps:a,[s]:{align:s,direction:s}},3,"Kl_2"),1,null)],1,null),1,null)],1,"Kl_3")},uh=m(f(oh,"s_lTuY9A29ePc")),ch=t=>`
  query QueryReferralProgram{
    pageReferralP(locale:"${t}"){
      data{
        attributes{
            RefInfo{
          Title
          Subtitle
          Paragraph
          Media{
            ${b}
          }
        }
          StepsIntro
          Steps{
            Title
            Bullets{
              Text
              Caption
            }
          }
          ${F}
        }
      }
    }
  }
    `,dh=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(ch,e)},pn=N(f(dh,"s_xJNMjIe9Xxc")),ph=()=>{const t=pn();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageReferralP.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageReferralP.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageReferralP"]["data"]["attributes"]["SEO"]')}},3,"Mu_0"),i(uh,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Mu_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Mu_2")},gh=m(f(ph,"s_jMvbzO8YesI")),fh=({resolveValue:t})=>{const a=t(pn).pageData.data.pageReferralP.data.attributes.SEO;return Q(a)},xh=Object.freeze(Object.defineProperty({__proto__:null,default:gh,head:fh,usePageData:pn},Symbol.toStringTag,{value:"Module"})),mh=t=>{const e=t.data.pageResidential.data.attributes.Services;return n("div",null,null,i(ee,{data:e},3,"jS_0"),1,"jS_1")},hh=m(f(mh,"s_2a10udsh6KM")),$h=t=>`
  query QueryResidential {
    pageResidential(locale:"${t}"){    
      data{
        attributes{
          Services{
            Logo{
            ${b}
            }
            Media{
            ${b}
            }
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
          ${F}
        }
      }
    }
  }
    `,bh=async t=>{const e=t.params.lang==""?"en":"es-419";return await R($h,e)},gn=N(f(bh,"s_LcXJ0iBV25I")),vh=()=>{const t=gn();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageResidential.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageResidential.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageResidential"]["data"]["attributes"]["SEO"]')}},3,"O0_0"),i(hh,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"O0_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"O0_2")},yh=m(f(vh,"s_2tXslNmi0k4")),wh=({resolveValue:t})=>{const a=t(gn).pageData.data.pageResidential.data.attributes.SEO;return Q(a)},_h=Object.freeze(Object.defineProperty({__proto__:null,default:yh,head:wh,usePageData:gn},Symbol.toStringTag,{value:"Module"})),Sh=t=>{const e=t.data.data.pageSupport.data.attributes,a=t.data.data.sectionContactBoxes.data;return n("div",null,{class:"flex flex-col px-8 justify-center items-center"},[n("div",null,{class:"h-[100px] p-6 flex flex-row justify-evenly items-center shadow-2xl rounded-full w-[350px] mb-5 bg-blue-100"},[n("h2",null,{class:"text-primary-blue font-semibold text-xl"},w(e,"WTTTitle"),1,null),i(X,{get text(){return e.WTTButton.Text},get link(){return e.WTTButton.Link},[s]:{link:x(e.WTTButton,"Link"),text:x(e.WTTButton,"Text")}},3,"t0_0")],1,null),n("div",null,{class:"text-center"},[n("h1",null,{class:"text-3xl md:text-[40px] my-4 font-bold text-primary-blue"},w(e.Introduction,"Title"),1,null),n("h2",null,{class:"text-secondary-red my-4 text-2xl font-semibold"},w(e.Introduction,"Subtitle"),1,null),i(C,{get text(){return e.Introduction.Paragraph},[s]:{text:x(e.Introduction,"Paragraph")}},3,"t0_1")],1,null),n("div",null,{class:"flex flex-col md:flex-row my-4 w-full"},a.map((l,r)=>n("div",null,{class:"flex flex-col w-full md:w-1/2 items-center px-4 justify-start"},[l.attributes.Title.map((o,c)=>n("div",null,null,n("h2",null,{class:"text-center text-2xl text-primary-blue font-semibold"},w(o,"Text"),1,null),1,c)),l.attributes.BoxContent.map((o,c)=>n("div",null,{class:"min-h-[250px] my-4 w-full flex flex-col gap-5 justify-start items-center py-4 rounded-2xl shadow-xl"},[n("div",{class:`w-full flex justify-center py-2 items-center rounded-t-2xl ${r%2==0?"bg-primary-blue":"bg-secondary-red"}`},null,n("h2",null,{class:"text-center text-2xl text-white font-semibold"},w(o,"Title"),1,null),1,null),i(C,{classN:"text-center px-4",get text(){return o.Paragraph},[s]:{classN:s,text:x(o,"Paragraph")}},3,"t0_2"),n("div",null,{class:"flex flex-wrap items-center justify-center gap-2"},o.Buttons.map((d,p)=>{var g;return i(X,{get text(){return d.Text},get link(){return d.Link},type:(g=d.Link)!=null&&g.includes("tel:")?"action":"link",[s]:{link:x(d,"Link"),text:x(d,"Text")}},3,p)}),1,null)],1,c))],1,r)),1,null),n("div",null,{class:"flex flex-col my-4 md:flex-row gap-5"},e.SelfSupport.map((l,r)=>n("div",null,{class:"h-[290px] w-full md:w-[305px] rounded-3xl shadow-2xl flex p-6 flex-col items-center justify-between"},[n("img",{alt:w(l.Media.data.attributes,"alternativeText"),src:G(l.Media.data.attributes.url),title:w(l.Media.data.attributes,"caption")},{height:150,width:310},null,3,null),n("h2",null,{class:"text-2xl md:text-3xl text-center font-semibold text-primary-blue"},w(l,"Title"),1,null),i(C,{classN:"text-center",get text(){return l.Paragraph},[s]:{classN:s,text:x(l,"Paragraph")}},3,"t0_3"),i(X,{get text(){return l.Buttons[0].Text},get link(){return l.Buttons[0].Link},[s]:{link:x(l.Buttons[0],"Link"),text:x(l.Buttons[0],"Text")}},3,"t0_4")],1,r)),1,null)],1,"t0_5")},Th=m(f(Sh,"s_Vkf3Ha9y0kU")),Dh=t=>`
        sectionContactBoxes(locale:"${t}"){
          data{
            attributes{
              Title{
                Text
              }
              BoxContent{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
            }
          }
      }`,Ph=t=>`query QuerySupport{
        pageSupport(locale:"${t}"){
          data{
            attributes{
              Marquee
              
              WTTTitle
              WTTButton{
                Text
                Link
              }
              
              Introduction{
                Title
                Subtitle
                Paragraph
              }
              
              SelfSupport{
                Media{
                ${b}
                }
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              ${F}
            }
          }
        }
        ${Dh(t)}
      }`,kh=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Ph,e)},fn=N(f(kh,"s_PaoFf3TWb00")),Lh=()=>{const t=fn();return i(H,{children:i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageSupport.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageSupport.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageSupport"]["data"]["attributes"]["SEO"]')}},3,"Ez_0"),i(Th,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"Ez_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Ez_2")},1,"Ez_3")},Mh=m(f(Lh,"s_BS8ceDijUKA")),Ch=({resolveValue:t})=>{const a=t(fn).pageData.data.pageSupport.data.attributes.SEO;return Q(a)},jh=Object.freeze(Object.defineProperty({__proto__:null,default:Mh,head:Ch,usePageData:fn},Symbol.toStringTag,{value:"Module"})),Ih=t=>n("div",null,{class:"flex h-[190px]  max-w-[350px] flex-col items-center justify-center rounded-[20px] bg-white p-6 m-2 text-primary-blue"},[i(ad,{class:"text-[28px] text-secondary-red",[s]:{class:s}},3,"Gr_0"),n("span",null,{class:"text-[17px] font-[600]"},u(e=>e.testimonial.Title,[t],'p0.testimonial["Title"]'),3,null),i(C,{classN:"text-[12px] text-center",get text(){return t.testimonial.Text},[s]:{classN:s,text:u(e=>e.testimonial.Text,[t],'p0.testimonial["Text"]')}},3,"Gr_1")],1,"Gr_2"),Eh=t=>{const e=t.data.pageTestimon.data.attributes,a=m(f(Ih,"s_ikLHAV9ZIuk")),l=e.Testimonials.map((r,o)=>i(a,{testimonial:r},3,o));return n("div",null,{class:"flex w-full items-center justify-center px-8",onClick$:B("s_KMXVxiVFs3M")},n("div",null,{class:"my-16 flex max-w-[1400px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex w-[60%] flex-col items-center justify-center gap-2 max-[800px]:w-full"},[n("h2",null,{class:"text-[36px] max-[800px]:text-[20px] font-[600] text-primary-dark-blue"},w(e,"VideoTitle"),1,null),n("video",{src:G(e.Video.data.attributes.url)},{class:"rounded-[30px] max-[800px]:max-w-[400px]",controls:!0,controlsList:"nodownload"},null,3,null)],1,null),n("div",null,{class:"items-center w-[40%] flex-col px-1 justify-center max-[800px]:w-full max-h-[500px]  "},i(St,{hasArrows:!1,hasPagination:!0,id:"carTestimonials",slides:l,slidesQty:1,[s]:{hasArrows:s,hasPagination:s,id:s,slidesQty:s}},3,"Gr_3"),1,null)],1,null),1,"Gr_4")},Oh=m(f(Eh,"s_HE2Hm2x9r68")),Bh=t=>`query queryTestimonials{
    pageTestimon(locale:"${t}"){
      data{
        attributes{
          Testimonials{
            Title
            Text
          }
          VideoTitle
          TestimBG{
           ${b}
          }
          Video{
            ${b}
          }
          ${F}
        }
      }
    }
  }`,Ah=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Bh,e)},xn=N(f(Ah,"s_R6fQva4FAkw")),Nh=()=>{const t=xn();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageTestimon.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageTestimon.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageTestimon"]["data"]["attributes"]["SEO"]')}},3,"cR_0"),i(Oh,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"cR_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"cR_2")},qh=m(f(Nh,"s_jKMCOKr9uSw")),Rh=({resolveValue:t})=>{const a=t(xn).pageData.data.pageTestimon.data.attributes.SEO;return Q(a)},zh=Object.freeze(Object.defineProperty({__proto__:null,default:qh,head:Rh,usePageData:xn},Symbol.toStringTag,{value:"Module"})),Fh=t=>{const e=t.data.data.pageWholesale.data.attributes,a=t.data.data.sectionNetwork.data.attributes,l=e.NetworkDIA.Features,r=W(0);return Jt(B("s_jeOJGnobZvM",[l,r])),n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"my-8 flex w-full flex-col items-center justify-center px-4 md:w-1/2"},[i(C,{classN:"text-center my-4",get text(){return e.Introduction.Paragraph},[s]:{classN:s,text:x(e.Introduction,"Paragraph")}},3,"Xs_0"),i(X,{get text(){return e.Introduction.Buttons[0].Text},get link(){return e.Introduction.Buttons[0].Link},type:"action",[s]:{link:x(e.Introduction.Buttons[0],"Link"),text:x(e.Introduction.Buttons[0],"Text"),type:s}},3,"Xs_1")],1,null),n("img",{alt:w(e.NetworkLogo.data.attributes,"alternativeText"),src:G(e.NetworkLogo.data.attributes.url)},{height:180,width:400},null,3,null),n("div",null,{class:"flex w-full flex-col items-center justify-center"},n("div",null,{class:"my-4 flex max-w-[1200px] flex-row-reverse items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-4 px-10 min-[800px]:w-[70%]"},[n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},w(e.NetworkDIA,"Title"),1,null),1,null),i(C,{get text(){return e.NetworkDIA.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{classN:s,text:x(e.NetworkDIA,"Paragraph")}},3,"Xs_2"),n("div",null,{class:"flex flex-col items-center justify-end text-center"},[n("h2",null,{class:"font-semibold text-primary-blue"},w(e.NetworkDIA,"Subtitle"),1,null),n("p",null,{class:"text-2xl font-bold text-primary-blue"},w(e.NetworkDIA,"FeaturesTitle"),1,null)],1,null),n("div",null,{class:"text-center text-xl font-semibold text-secondary-red"},n("h2",null,{class:"animated-fadein-down animated-fadeout-down"},w(l[r.value],"Text"),1,null),1,null)],1,null),n("div",null,{class:`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${30 .toString()}%]`},n("img",{src:G(e.NetworkDIA.Media.data.attributes.url)},{alt:"paragraph-image",height:"300",width:"597"},null,3,null),1,null)],1,null),1,null),i(At,{get text(){return e.NetworkCircuits.Paragraph},backgroundColor:"transparent",get title(){return e.NetworkCircuits.Title},get image(){return e.NetworkCircuits.Media.data.attributes},[s]:{backgroundColor:s,image:x(e.NetworkCircuits.Media.data,"attributes"),text:x(e.NetworkCircuits,"Paragraph"),title:x(e.NetworkCircuits,"Title")}},3,"Xs_3"),n("div",null,{class:"my-4 flex flex-wrap-reverse items-center justify-center gap-8 px-8 py-6"},[n("div",{onClick$:B("s_VUkdu4BrA18",[e])},{class:"flex h-[400px] items-center justify-center"},i(E,{get url(){return e.NetworkMap.data.attributes.Map.MapPicture.data.attributes.url},[s]:{url:x(e.NetworkMap.data.attributes.Map.MapPicture.data.attributes,"url")}},3,"Xs_4"),0,null),n("div",null,{class:"flex w-full flex-col items-center justify-center md:w-1/2"},[i(C,{get text(){return a.Description.Paragraph},classN:"text-primary-blue",[s]:{classN:s,text:x(a.Description,"Paragraph")}},3,"Xs_5"),i(xe,{get title(){return a.Map.ServersTitle},children:n("div",null,{class:"flex flex-col rounded-b-2xl bg-white py-4 text-primary-blue"},a.Map.Servers.map((o,c)=>n("a",{href:w(o,"Link")},{class:"text-primary-blue hover:text-secondary-red"},w(o,"Text"),1,c)),1,null),classContainer:"rounded-full bg-white text-primary-blue shadow-xl",[s]:{classContainer:s,title:x(a.Map,"ServersTitle")}},1,"Xs_6")],1,null)],1,null),i(ee,{get data(){return e.GFServices},[s]:{data:x(e,"GFServices")}},3,"Xs_7")],1,"Xs_8")},Gh=m(f(Fh,"s_SvASKT7lKMw")),Qh=t=>`query QueryWholesale {
        pageWholesale(locale:"${t}"){    
          data{
            attributes{
            Introduction{
              Title
              Paragraph
              Buttons{
                Text
                Link
              }
            }
              
            NetworkLogo{
                ${b}
            }
            NetworkDIA{
              Title
              Paragraph
              Subtitle
              FeaturesTitle
              Features{
                Text
              }
              Media{
                ${b}
              }
            }
            NetworkCircuits{
              Title
              Subtitle
              Paragraph
              Media{
                 ${b}
              }
            }
           
              
            GFServices{
              Title
              Logo{
                ${b}
              }
              Paragraph
              Media{
                ${b}
              }
              Buttons{
                Text
                Link
              }
            }
              ${F}
              NetworkMap {
                data {
                  attributes {
                    Map {
                      MapPicture {
                        data {
                          attributes {
                            url
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        ${Wc(t)}
      }`,Hh=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Qh,e)},mn=N(f(Hh,"s_odgwpNJ8jW8")),Wh=()=>{const t=mn();return i(H,{children:i(z,{get data(){return t.value.layoutData},children:i(Gh,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"3I_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"3I_1")},1,"3I_2")},Uh=m(f(Wh,"s_W611gmEC5Rk")),Vh=({resolveValue:t})=>{const a=t(mn).pageData.data.pageWholesale.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},Yh=Object.freeze(Object.defineProperty({__proto__:null,default:Uh,head:Vh,usePageData:mn},Symbol.toStringTag,{value:"Module"})),Zh=t=>n("div",{style:{backgroundImage:`url(${G(t.slide.attributes.url)})`}},{class:"h-[350px] my-5 w-[280px] overflow-hidden rounded-[10px] bg-contain bg-no-repeat bg-center"},null,3,"0D_0"),Kh=t=>{const e=t.data.pageWinnersC.data.attributes,a=e.Winners.data.reverse(),l=m(f(Zh,"s_Kis0UnPgGnE")),r=a.map((o,c)=>i(l,{slide:o},3,c));return n("div",null,{class:"relative flex flex-col items-center justify-center",onClick$:B("s_na2GxJ32Wno")},[n("div",null,{class:"relative flex w-full items-center justify-center overflow-hidden"},[i(E,{clasN:"max-w-[1000px] w-fit z-10 object-cover",height:"603",width:"1024",get url(){return e.WinnersBG.data.attributes.url},get alt(){return e.WinnersBG.data.attributes.alternativeText},get title(){return e.WinnersBG.data.attributes.caption},[s]:{alt:x(e.WinnersBG.data.attributes,"alternativeText"),clasN:s,height:s,title:x(e.WinnersBG.data.attributes,"caption"),url:x(e.WinnersBG.data.attributes,"url"),width:s}},3,"0D_1"),n("div",null,{class:"absolute z-20 mb-[160px]  w-[290px] overflow-hidden  rounded-[10px] border border-gray-500 bg-[#171f2a] p-2"},i(St,{addSpace:!1,hasArrows:!1,id:"carouselWinners",slides:r,slidesQty:1,[s]:{addSpace:s,hasArrows:s,id:s,slidesQty:s}},3,"0D_2"),1,null),n("div",null,{class:"absolute bottom-0 left-0 right-0 h-[30%] bg-black"},null,3,null)],1,null),n("div",null,{class:"flex w-full overflow-hidden bg-cover pt-16 bg-black justify-center"},n("div",null,{class:"flex max-w-[1200px] gap-4  max-[1000px]:flex-col  justify-center items-center"},[n("div",null,{class:"flex w-[30%] flex-col "},[n("h2",null,{class:"text-center text-[36px] font-[600] leading-[36px] text-secondary-red"},w(e,"GiveawayCarTitle"),1,null),n("br",null,null,null,3,null),n("div",null,{class:"mb-6 flex items-center justify-center rounded-xl bg-white p-2"},i(St,{addSpace:!1,duration:5e3,hasArrows:!0,hasPagination:!1,id:"giveAnswers",slides:e.GiveawayAnswers.reverse().map((o,c)=>n("div",null,{class:"flex flex-col items-center justify-center gap-1.5 max-w-[180px]"},[n("p",null,{class:"text-center text-[15px] text-primary-blue"},["This question was answered on"," ",n("br",null,null,null,3,null),Xe(o.AnswerDate,!1)],1,null),n("iframe",{src:`https://www.youtube.com/embed/${o.QuestionVideos.split("v=")[1]}`},{allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",allowFullScreen:!0,class:"rounded-[20px] shadow-xl",frameBorder:"0",height:270,width:160},null,3,null),n("span",null,{class:"text-secondary-red"},"Answer:",3,null),n("span",null,{class:"text-primary-blue"},w(o,"Answer"),1,null)],1,c)),slidesQty:1,[s]:{addSpace:s,duration:s,hasArrows:s,hasPagination:s,id:s,slidesQty:s}},3,"0D_3"),1,null)],1,null),n("div",null,{class:"flex md:w-[60%] w-[30%] h-full flex-col justify-center  overflow-hidden"},[n("h3",null,{class:"text-center text-[28px] font-[500] leading-[30px] text-primary-blue"},w(e,"TwitterFeedTitle"),1,null),n("br",null,null,null,3,null),n("iframe",{srcDoc:w(e,"TwitterFeedLink")},{class:"h-full",height:"100%",width:"100%"},null,3,null)],1,null)],1,null),1,null)],1,"0D_4")},Xh=m(f(Kh,"s_QYIFsZOPjHw")),Jh=t=>`query queryWinnerCircle{
    pageWinnersC(locale:"${t}"){
      data{
        attributes{
          WinnersTitle
  
          WinnersBG{
            ${b}
          }
          
          WinnersCarBG{
           ${b}
          }
          Winners{
            ${b}
          }
         
          GiveawayCarTitle
          
          GiveawayAnswers{
            Description
            AnswerDate
            QuestionVideos
            Answer
          }
          TwitterFeedLink
          TwitterFeedTitle
  
          ${F}
        }
      }
    }
  }`,t$=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(Jh,e)},hn=N(f(t$,"s_6WeV0M8I1Do")),e$=()=>{const t=hn();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageWinnersC.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageWinnersC.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageWinnersC"]["data"]["attributes"]["SEO"]')}},3,"00_0"),i(Xh,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"00_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"00_2")},a$=m(f(e$,"s_0m9hLjn9QnA")),l$=({resolveValue:t})=>{const a=t(hn).pageData.data.pageWinnersC.data.attributes.SEO;return Q(a)},n$=Object.freeze(Object.defineProperty({__proto__:null,default:a$,head:l$,usePageData:hn},Symbol.toStringTag,{value:"Module"})),s$=t=>n("div",null,{class:"flex max-w-[400px] flex-col items-center max-[900px]:place-self-center"},[n("section",null,{class:"flex h-fit w-full flex-col rounded-[35px] bg-white text-center shadow-lg"},[n("div",null,{class:"flex w-full items-center justify-center rounded-t-[35px] bg-gradient-to-r from-[#4caafd] to-[#1a7ee4] px-6 py-3 text-center"},i(E,{get url(){return t.data.RaceRepLogo.data.attributes.url},clasN:"h-[16px] w-fit",[s]:{clasN:s,url:u(e=>e.data.RaceRepLogo.data.attributes.url,[t],'p0.data["RaceRepLogo"]["data"]["attributes"]["url"]')}},3,"QP_0"),1,null),n("div",null,{class:"flex flex-col items-center justify-center p-4"},[i($a,{get ytURL(){return t.data.RaceRepVids[0].Link},classN:"rounded-[30px] shadow-lg",[s]:{classN:s,ytURL:u(e=>e.data.RaceRepVids[0].Link,[t],'p0.data["RaceRepVids"][0]["Link"]')}},3,"QP_1"),i(C,{get text(){return t.data.RaceRepVids[0].Paragraph},classN:"text-[13px] p-1 mt-2",[s]:{classN:s,text:u(e=>e.data.RaceRepVids[0].Paragraph,[t],'p0.data["RaceRepVids"][0]["Paragraph"]')}},3,"QP_2"),n("div",null,{class:"h-[6px] w-full border-t border-gray-300"},null,3,null),n("div",null,{class:"h-[6px] w-full border-t border-gray-300"},null,3,null),n("div",null,{class:"mb-4 h-[6px] w-full border-t border-gray-300"},null,3,null),i($a,{get ytURL(){return t.data.RaceRepVids[1].Link},classN:"rounded-[30px] shadow-lg",[s]:{classN:s,ytURL:u(e=>e.data.RaceRepVids[1].Link,[t],'p0.data["RaceRepVids"][1]["Link"]')}},3,"QP_3"),i(C,{get text(){return t.data.RaceRepVids[1].Paragraph},classN:"text-[13px] p-1 mt-2",[s]:{classN:s,text:u(e=>e.data.RaceRepVids[1].Paragraph,[t],'p0.data["RaceRepVids"][1]["Paragraph"]')}},3,"QP_4")],1,null)],1,null),n("a",null,{class:"mt-8 w-full rounded-full border-[6px] border-[#e7758f] bg-secondary-red px-8 py-1 text-center text-[14px] font-[600] leading-[18px] text-white shadow-lg",href:u(e=>e.data.HeaderButtons[0].Link,[t],'p0.data["HeaderButtons"][0]["Link"]'),target:"_blank"},u(e=>e.data.HeaderButtons[0].Text,[t],'p0.data["HeaderButtons"][0]["Text"]'),3,null)],1,"QP_5"),r$=t=>n("div",null,{class:"flex h-fit max-w-[600px] flex-col items-center justify-center  text-center text-white"},[i(E,{get url(){return t.data.LogoCorp.data.attributes.url},clasN:"h-[80px] w-fit",[s]:{clasN:s,url:u(e=>e.data.LogoCorp.data.attributes.url,[t],'p0.data["LogoCorp"]["data"]["attributes"]["url"]')}},3,"QP_6"),n("span",null,{class:"mb-4 text-[46px] font-[700] leading-[50px]"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),i(E,{get url(){return t.data.LogoSponsor.data.attributes.url},[s]:{url:u(e=>e.data.LogoSponsor.data.attributes.url,[t],'p0.data["LogoSponsor"]["data"]["attributes"]["url"]')}},3,"QP_7"),n("span",null,{class:"my-4 rounded-full bg-white px-4 text-[15px] font-[400] tracking-widest text-primary-blue"},t.data.Subtitle.toUpperCase(),1,null),i(E,{get url(){return t.data.HeaderPictures.data[0].attributes.url},clasN:"w-full h-fit px-4 pt-4",[s]:{clasN:s,url:u(e=>e.data.HeaderPictures.data[0].attributes.url,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]["url"]')}},3,"QP_8")],1,"QP_9"),i$=t=>{Z();const e=W(1e3);Jt(B("s_0vxrMcOslm0",[e]));const a=m(f(s$,"s_S9x7nXVXxQ0")),l=m(f(r$,"s_YXp1rsg61DU"));return n("div",null,{class:"flex min-h-[500px] w-full items-center justify-center bg-[conic-gradient(at_top,_var(--tw-gradient-stops))] from-[#001536] via-[#0E67BB] to-[#001536]"},n("div",null,{class:"flex max-w-[1200px] flex-col items-center justify-center px-8 pt-12"},n("div",null,{class:"grid items-start justify-center gap-6 max-[900px]:items-center",style:u(r=>({gridTemplateColumns:r.value>900?"250px 1fr 250px":"1fr"}),[e],'{gridTemplateColumns:p0.value>900?"250px 1fr 250px":"1fr"}')},[e.value<=900&&i(l,{get data(){return t.data},[s]:{data:u(r=>r.data,[t],"p0.data")}},3,"QP_10"),i(a,{get data(){return t.data},[s]:{data:u(r=>r.data,[t],"p0.data")}},3,"QP_11"),e.value>900&&i(l,{get data(){return t.data},[s]:{data:u(r=>r.data,[t],"p0.data")}},3,"QP_12"),n("div",null,{class:"flex max-w-[400px] flex-col items-center max-[900px]:place-self-center"},[n("section",null,{class:"flex h-fit w-full flex-col items-center justify-center rounded-[35px] bg-white p-4 text-center shadow-lg"},[n("div",null,{class:"h-[420px]"},i($a,{get ytURL(){return t.data.GiveawayBox[0].Video.Link},classN:"rounded-[30px] shadow-lg",[s]:{classN:s,ytURL:u(r=>r.data.GiveawayBox[0].Video.Link,[t],'p0.data["GiveawayBox"][0]["Video"]["Link"]')}},3,"QP_13"),1,null),i(C,{get text(){return t.data.GiveawayBox[0].Video.Paragraph},classN:"text-[13px] p-1 mt-2",[s]:{classN:s,text:u(r=>r.data.GiveawayBox[0].Video.Paragraph,[t],'p0.data["GiveawayBox"][0]["Video"]["Paragraph"]')}},3,"QP_14"),i(X,{get text(){return t.data.GiveawayBox[0].Button.Text},get link(){return t.data.GiveawayBox[0].Button.Link},[s]:{link:u(r=>r.data.GiveawayBox[0].Button.Link,[t],'p0.data["GiveawayBox"][0]["Button"]["Link"]'),text:u(r=>r.data.GiveawayBox[0].Button.Text,[t],'p0.data["GiveawayBox"][0]["Button"]["Text"]')}},3,"QP_15")],1,null),n("a",null,{class:"my-8 w-full rounded-full border-[6px] border-[#e7758f] bg-secondary-red px-8 py-1 text-center text-[14px] font-[600] leading-[18px] text-white shadow-lg",href:u(r=>r.data.HeaderButtons[1].Link,[t],'p0.data["HeaderButtons"][1]["Link"]')},u(r=>r.data.HeaderButtons[1].Text,[t],'p0.data["HeaderButtons"][1]["Text"]'),3,null)],1,null)],1,null),1,null),1,"QP_16")},o$=m(f(i$,"s_v9v6ItSeef4")),u$=t=>n("div",null,{class:"flex flex-col items-center justify-center text-center text-white"},[n("span",null,{class:"text-[24px]"},i(C,{classN:"text-white",get text(){return t.data.QuoteText},[s]:{classN:s,text:u(e=>e.data.QuoteText,[t],'p0.data["QuoteText"]')}},3,"0q_0"),1,null),n("div",null,{class:"mt-4 flex flex-col"},[n("span",null,{class:"text-[19px] font-[600] text-[#7bc8ff]"},u(e=>e.data.QuoteAuthor,[t],'p0.data["QuoteAuthor"]'),3,null),n("span",null,{class:"max-w-[200px] text-[14px] tracking-[2px]"},u(e=>e.data.QuoteADesc,[t],'p0.data["QuoteADesc"]'),3,null)],3,null)],1,"0q_1"),c$=m(f(u$,"s_P6qdCyIENpU")),d$=t=>n("div",null,{class:"flex items-center justify-center gap-10 px-8 max-[800px]:flex-col"},[n("div",null,{class:"flex min-w-[300px] max-w-[400px] flex-col items-center justify-center rounded-[30px] bg-white p-8 text-primary-blue "},[i(E,{clasN:"h-fit w-[180px]",get url(){return t.data.AboutZane.Media.data.attributes.url},[s]:{clasN:s,url:u(e=>e.data.AboutZane.Media.data.attributes.url,[t],'p0.data["AboutZane"]["Media"]["data"]["attributes"]["url"]')}},3,"E0_0"),n("h2",null,{class:"mt-4 text-[30px] font-[500] text-secondary-red"},u(e=>e.data.AboutZane.Title,[t],'p0.data["AboutZane"]["Title"]'),3,null),i(C,{classN:"[&>h2]:text-[21px] [&>h2]:leading-10 [&>h2]:font-[600]",get text(){return t.data.AboutZane.Paragraph},[s]:{classN:s,text:u(e=>e.data.AboutZane.Paragraph,[t],'p0.data["AboutZane"]["Paragraph"]')}},3,"E0_1"),n("div",null,{class:"mb-4 flex w-full items-center justify-evenly gap-2 rounded-full bg-primary-blue p-2"},t.data.AboutZane.Buttons.filter(e=>!e.Text).map((e,a)=>n("div",{onClick$:B("s_aBdgclRoL4w",[e])},{class:"hover:cursor-pointer"},i(E,{clasN:"h-[20px]",toWhite:a!==0,get url(){return e.Icon.data.attributes.url},[s]:{clasN:s,url:x(e.Icon.data.attributes,"url")}},3,"E0_2"),0,a)),1,null),t.data.AboutZane.Buttons.filter(e=>e.Text).map((e,a)=>n("div",{onClick$:B("s_0qHArrAd29Q",[e])},{class:"flex gap-2 self-start hover:cursor-pointer"},[i(E,{clasN:"h-[24px] w-[24px]",get url(){return e.Icon.data.attributes.url},[s]:{clasN:s,url:x(e.Icon.data.attributes,"url")}},3,"E0_3"),n("span",null,{class:"text-[14px] font-[500]"},w(e,"Text"),1,null)],0,a))],1,null),n("div",null,{class:"flex flex-col text-white"},[n("span",null,{class:"mb-4 text-[40px] font-[600]"},u(e=>e.data.Highlights.Title,[t],'p0.data["Highlights"]["Title"]'),3,null),i(C,{classN:"text-white text-justify",get text(){return t.data.Highlights.Paragraph},[s]:{classN:s,text:u(e=>e.data.Highlights.Paragraph,[t],'p0.data["Highlights"]["Paragraph"]')}},3,"E0_4")],1,null)],1,"E0_5"),p$=m(f(d$,"s_CpEM5GsNAyg")),g$=t=>n("div",null,{class:"mt-[80px] flex flex-col items-center justify-center"},[n("div",null,{class:"mb-6 flex items-center justify-center gap-6"},[n("span",null,{class:"text-[40px] font-[600] text-white max-[800px]:hidden"},u(e=>e.data.AboutFRM.Title,[t],'p0.data["AboutFRM"]["Title"]'),3,null),i(E,{get url(){return t.data.AboutFRM.Logo.data.attributes.url},[s]:{url:u(e=>e.data.AboutFRM.Logo.data.attributes.url,[t],'p0.data["AboutFRM"]["Logo"]["data"]["attributes"]["url"]')}},3,"KU_0")],1,null),n("div",null,{class:"flex gap-8 max-[800px]:flex-col"},[n("div",null,{class:"flex w-[60%] flex-col items-center gap-4 max-[800px]:w-full"},[i(C,{classN:"text-white text-[18px] text-justify",get text(){return t.data.AboutFRM.Paragraph},[s]:{classN:s,text:u(e=>e.data.AboutFRM.Paragraph,[t],'p0.data["AboutFRM"]["Paragraph"]')}},3,"KU_1"),i(E,{clasN:"w-[80%] min-w-[300px] rounded-3xl",get url(){return t.data.FRMChamps.data.attributes.url},[s]:{clasN:s,url:u(e=>e.data.FRMChamps.data.attributes.url,[t],'p0.data["FRMChamps"]["data"]["attributes"]["url"]')}},3,"KU_2"),i(C,{classN:"text-white text-[12px]",get text(){return t.data.FRMChamps.data.attributes.caption},[s]:{classN:s,text:u(e=>e.data.FRMChamps.data.attributes.caption,[t],'p0.data["FRMChamps"]["data"]["attributes"]["caption"]')}},3,"KU_3"),i(C,{classN:"text-white text-[12px] text-justify",get text(){return t.data.AboutFRMPInfo},[s]:{classN:s,text:u(e=>e.data.AboutFRMPInfo,[t],'p0.data["AboutFRMPInfo"]')}},3,"KU_4")],1,null),n("div",null,{class:"flex w-[40%] flex-col items-center max-[800px]:w-full"},[i(C,{classN:"text-white text-[15px] font-[600]",get text(){return t.data.AboutFRM.Subtitle},[s]:{classN:s,text:u(e=>e.data.AboutFRM.Subtitle,[t],'p0.data["AboutFRM"]["Subtitle"]')}},3,"KU_5"),i(E,{clasN:"w-[80%] min-w-[180px] rounded-3xl my-2",get url(){return t.data.AboutFRM.Media.data.attributes.url},[s]:{clasN:s,url:u(e=>e.data.AboutFRM.Media.data.attributes.url,[t],'p0.data["AboutFRM"]["Media"]["data"]["attributes"]["url"]')}},3,"KU_6"),i(C,{classN:"text-white text-[13px]",get text(){return t.data.AboutFRM.Media.data.attributes.caption},[s]:{classN:s,text:u(e=>e.data.AboutFRM.Media.data.attributes.caption,[t],'p0.data["AboutFRM"]["Media"]["data"]["attributes"]["caption"]')}},3,"KU_7"),n("div",null,{class:"my-4 flex flex-col items-start justify-start gap-1 self-start"},t.data.AboutFRM.Buttons.map((e,a)=>n("div",{onClick$:B("s_TcbYAUHeCh4",[e])},{class:"flex items-center"},[i(E,{clasN:"h-[16px] w-[16px] mr-2",toWhite:!0,get url(){return e.Icon.data.attributes.url},[s]:{clasN:s,toWhite:s,url:x(e.Icon.data.attributes,"url")}},3,"KU_8"),n("span",null,{class:"text-white"},w(e,"Text"),1,null)],0,a)),1,null)],1,null)],1,null)],1,"KU_9"),f$=m(f(g$,"s_uxm1007Tl9Q")),x$=t=>n("div",null,{class:"my-[80px] flex flex-col items-center justify-center text-white"},[n("span",null,{class:"text-center text-[40px] font-[600]"},u(e=>e.data.CarouselTitle,[t],'p0.data["CarouselTitle"]'),3,null),n("div",null,{class:"max-w-[1300px] px-8"},i(St,{addSpace:!0,direction:"horizontal",hasArrows:!0,id:"zss_carousel",slides:t.data.CarouselContent.map((e,a)=>n("div",{onClick$:B("s_LReiaiAXvdI",[e])},{class:"relative overflow-hidden rounded-3xl hover:cursor-pointer"},[n("div",null,{class:"absolute inset-0 z-20 flex items-center justify-center bg-black bg-opacity-10 text-[60px] font-[900] text-white"},"▷",3,null),i(E,{get url(){return e.Cover.data.attributes.url},[s]:{url:x(e.Cover.data.attributes,"url")}},3,"YI_0")],0,a)),slidesQty:3,[s]:{addSpace:s,direction:s,hasArrows:s,id:s,slidesQty:s}},3,"YI_1"),1,null)],1,"YI_2"),m$=m(f(x$,"s_leW0062t5ac")),h$=t=>{const e=t.data.pageZaneSpon.data.attributes;return n("div",{onClick$:B("s_m03OOMoHREo",[e])},null,[i(o$,{data:e},3,"5E_0"),n("div",null,{class:"bg-gradient-to-b from-[#041630] to-[#153069] w-full object-center"},n("div",null,{class:"max-w-[1200px] px-8 pt-8 place-items-center"},[i(c$,{data:e},3,"5E_1"),i(m$,{data:e},3,"5E_2"),i(p$,{data:e},3,"5E_3"),i(f$,{data:e},3,"5E_4")],1,null),1,null)],0,"5E_5")},$$=m(f(h$,"s_kYGFw8H412s")),b$=t=>`query {
    pageZaneSpon(locale:"${t}") {
      data {
        attributes {
          Title
          Subtitle
          LogoCorp {
            ${b}
          }
          LogoSponsor {
            ${b}
          }
          HeaderPictures {
            ${b}
          }
          HeaderButtons {
            Text
            Link
          }
          NascarSchedule {
            ${b}
          }
          yt {
            ${b}
          }
          GiveawayBox {
            Video {
              Link
              Paragraph
            }
            Button {
              Text
              Link
            }
          }
          QuoteText
          QuoteAuthor
          QuoteADesc
          RaceRepLogo {
            ${b}
          }
          RaceRepVids {
            Link
            Paragraph
          }
          CarouselTitle
          CarouselContent {
            Link
            Paragraph
            Cover {
                ${b}
            }
          }
          AboutZane {
            Title
            Subtitle
            Paragraph
            Media {
                ${b}
            }
            Buttons {
              Text
              Link
              Icon {
                ${b}
              }
            }
          }
          Highlights {
            Title
            Paragraph
          }
          AboutFRM {
            Title
            Subtitle
            Paragraph
            Buttons {
              Text
              Link
              Icon {
                ${b}
              }
            }
            Logo {
                ${b}
            }
            Media {
                ${b}
            }
          }
  
          Sponsors{
            ${b}
          }
  
            FRMChamps{
                ${b}
            }
  
          AboutFRMPInfo
  
          
          ${F}
          
        }
      }
    }
  }`,v$=async t=>{const e=t.params.lang==""?"en":"es-419";return await R(b$,e)},$n=N(f(v$,"s_s1m2ueqRceg")),y$=()=>{const t=$n();return i(z,{get data(){return t.value.layoutData},children:[i(J,{get SEOdata(){return t.value.pageData.data.pageZaneSpon.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageZaneSpon.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageZaneSpon"]["data"]["attributes"]["SEO"]')}},3,"zi_0"),i($$,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"zi_1")],showHeader:!1,[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"zi_2")},w$=m(f(y$,"s_uWXfycW000o")),_$=({resolveValue:t})=>{const a=t($n).pageData.data.pageZaneSpon.data.attributes.SEO;return Q(a)},S$=Object.freeze(Object.defineProperty({__proto__:null,default:w$,head:_$,usePageData:$n},Symbol.toStringTag,{value:"Module"})),T$=t=>{const e=t.data.Slug.substring(t.data.Slug.length-3,t.data.Slug.length)==="-es";return n("div",null,{class:"flex max-w-[1200px] gap-3 px-8 py-20 text-primary-blue max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-1 text-center min-[800px]:w-[50%]"},[n("h1",null,{class:"text-[38px] font-[700] leading-10"},`gigFAST INTERNET ${e?"e":"i"}n ${t.data.Name}`,1,null),n("span",null,{class:"text-[24px]"},[u(a=>a.data.ZipCode,[t],'p0.data["ZipCode"]'),", TX"],3,null),n("span",null,{class:"text-[28px] font-[600]"},e?"Llamar ahora:":"Call now:",1,null),i(X,{text:"512 360 4273",[s]:{text:s}},3,"pw_0")],1,null),n("div",null,{class:"text-justify text-[16px] max-[800px]:text-[13px] min-[800px]:w-[50%]"},i(C,{get text(){return t.data.Description},[s]:{text:u(a=>a.data.Description,[t],'p0.data["Description"]')}},3,"pw_1"),1,null)],1,"pw_2")},D$=m(f(T$,"s_8eJAul3VU0U")),P$=t=>{const e=t.data.lpPtGroup.data.attributes.PricingTables;return n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"flex min-h-[200px]  w-full items-center justify-center bg-gradient-to-br from-primary-light-blue to-[#23477f] p-8"},n("div",null,{class:"flex w-full max-w-[1200px] flex-col items-center justify-center"},[n("span",null,{class:"text-center text-[38px] font-[600] leading-10 text-white max-[800px]:text-[28px]"},"Find available offers in your area",3,null),n("div",null,{class:"mt-8 flex w-full gap-8 max-[1200px]:flex-col"},[n("div",null,{class:"flex min-h-[360px] items-center justify-center overflow-hidden rounded-2xl min-[1200px]:w-[36%]"},n("iframe",null,{class:"h-full w-full rounded-2xl",loading:"lazy",src:u(a=>a.data.locations.data[0].attributes.office.data.attributes.Address,[t],'p0.data["locations"]["data"][0]["attributes"]["office"]["data"]["attributes"]["Address"]')},null,3,null),3,null),n("div",null,{class:"flex justify-evenly gap-4 max-[1200px]:flex-wrap min-[1200px]:w-[64%]"},e.map((a,l)=>i(Yl,{get btnText(){return a.Button.Text},get btnLink(){return a.Button.Link},get description(){return a.Description},get logo(){return a.Logo.data.attributes},get features(){return a.Features},price:a.Price.toString(),get priceTime(){return a.Pricetime},get title(){return a.Title},isFullLogo:!0,[s]:{btnLink:x(a.Button,"Link"),btnText:x(a.Button,"Text"),description:x(a,"Description"),features:x(a,"Features"),isFullLogo:s,logo:x(a.Logo.data,"attributes"),priceTime:x(a,"Pricetime"),title:x(a,"Title")}},3,l)),1,null)],1,null)],1,null),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"88_0")},k$=m(f(P$,"s_JRh1Z7hA4Tg")),L$=t=>n("div",null,{class:"flex flex-col items-center justify-center"},[i(D$,{get data(){return t.data.locations.data[0].attributes},[s]:{data:u(e=>e.data.locations.data[0].attributes,[t],'p0.data["locations"]["data"][0]["attributes"]')}},3,"LA_0"),i(k$,{get data(){return t.data},[s]:{data:u(e=>e.data,[t],"p0.data")}},3,"LA_1")],1,"LA_2"),M$=m(f(L$,"s_xdmchVEPK4Q")),C$=()=>n("div",null,{class:"flex w-full items-center justify-center px-8 py-12 text-center text-primary-dark-blue"},n("div",null,{class:"flex max-w-[1000px] flex-col items-center justify-center"},[n("span",null,{class:"text-[50px] font-[300]"},"Oops!",3,null),n("span",null,{class:"text-[18px] font-[400]"},"The page you are looking for does not exist.",3,null),n("h1",null,{class:"text-[150px] font-[700] max-[400px]:text-[100px]"},"404",3,null),n("span",null,{class:"text-[30px] font-[500] text-secondary-red"},"Something went wrong.",3,null)],3,null),3,"7k_0"),Er=m(f(C$,"s_6KpdMMBpLyc")),j$=(t,e)=>`
  query QueryLocalPage {
    locations(
      filters: { Slug: { eq: "${e}${t==="en"?"":"-es"}" } }
      locale: "${t}"
    ) {
      data {
        attributes {
            office {
                data {
                  attributes {
                    Address
                    Schema
                  }
                }
              }
          Name
          ZipCode
          Description
          Slug
          SEO {
            MetaTitle
            MetaDescription
            preventIndexing
            Keywords
          }
        }
      }
    }
    lpPtGroup(locale:"${t}"){
        data{
          attributes{
            PricingTables{
              Logo{
                ${b}
              }
              Title
              Subtitle
              Price
              Pricetime
              Description
              Features{
                Text
              }
              Button{
                Text
                Link
              }
            }
          }
        }
      } 
  }  
    `,I$=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang,a=t.params.slug;return await Oa(j$(fa(e),a),e)},bn=N(f(I$,"s_1P6SxAujDI0")),E$=()=>{Z();const t=bn(),a=t.value.pageData.data.locations.data.length>0?i(M$,{get data(){return t.value.pageData.data},[s]:{data:u(l=>l.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"jm_1"):i(Er,null,3,"jm_0");return i(z,{get data(){return t.value.layoutData},children:a,showHeader:!1,[s]:{data:u(l=>l.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"jm_2")},O$=m(f(E$,"s_7yVzYV6frbA")),B$=({resolveValue:t})=>{const e=t(bn);if(e.pageData.data.locations.data.length==0)return Q({MetaTitle:"Not Found",MetaDescription:"Error 404, location not found"});const a=e.pageData.data.locations.data[0].attributes.SEO;return a.schema=e.pageData.data.locations.data[0].attributes.office.data.attributes.Schema,Q(a)},A$=Object.freeze(Object.defineProperty({__proto__:null,default:O$,head:B$,usePageData:bn},Symbol.toStringTag,{value:"Module"})),N$=()=>{const[t,e,a,l,r]=et();e.value=!e.value,e.value&&(t.value=a.data.HeroForm.ActionButton.Link.replace("=pConf=","").replace("streetInput",l.value.value).replace("zipInput",r.value.value))},q$=t=>n("div",null,{class:"flex items-center justify-between gap-1"},[n("div",null,{class:"flex flex-col gap-1 max-[1000px]:gap-2"},[i(E,{clasN:"w-[160px]",width:"1667",get url(){return t.slide.Logo.data.attributes.url},get alt(){return t.slide.Logo.data.attributes.alternativeText},get title(){return t.slide.Logo.data.attributes.caption},[s]:{alt:u(e=>e.slide.Logo.data.attributes.alternativeText,[t],'p0.slide["Logo"]["data"]["attributes"]["alternativeText"]'),clasN:s,title:u(e=>e.slide.Logo.data.attributes.caption,[t],'p0.slide["Logo"]["data"]["attributes"]["caption"]'),url:u(e=>e.slide.Logo.data.attributes.url,[t],'p0.slide["Logo"]["data"]["attributes"]["url"]'),width:s}},3,"2R_1"),n("div",null,{class:"mx-3 max-[1000px]:hidden"},i(C,{classN:"text-[13px]",get text(){return t.slide.Paragraph},[s]:{classN:s,text:u(e=>e.slide.Paragraph,[t],'p0.slide["Paragraph"]')}},3,"2R_2"),1,null),i(X,{get text(){return t.slide.Buttons[0].Text},get link(){return t.slide.Buttons[0].Link},[s]:{link:u(e=>e.slide.Buttons[0].Link,[t],'p0.slide["Buttons"][0]["Link"]'),text:u(e=>e.slide.Buttons[0].Text,[t],'p0.slide["Buttons"][0]["Text"]')}},3,"2R_3")],1,null),i(Ja,{clasN:"rounded-full w-[150px] mr-[30px] max-[1000px]:w-[40%]",get url(){return t.slide.Media.data.attributes.url},get alt(){return t.slide.Media.data.attributes.alternativeText},get title(){return t.slide.Media.data.attributes.caption},autoplay:!0,loop:!0,muted:!0,[s]:{alt:u(e=>e.slide.Media.data.attributes.alternativeText,[t],'p0.slide["Media"]["data"]["attributes"]["alternativeText"]'),autoplay:s,clasN:s,loop:s,muted:s,title:u(e=>e.slide.Media.data.attributes.caption,[t],'p0.slide["Media"]["data"]["attributes"]["caption"]'),url:u(e=>e.slide.Media.data.attributes.url,[t],'p0.slide["Media"]["data"]["attributes"]["url"]')}},3,"2R_4")],1,"2R_5"),R$=t=>{const[e]=et();return n("div",{class:`flex h-[230px] items-center  justify-center overflow-hidden bg-white   ${t.isMobile??!1?"w-full max-w-[420px] rounded-full min-[1000px]:hidden":"w-[420px] rounded-br-full rounded-tr-full bg-opacity-60 max-[1000px]:hidden"}`},null,i(St,{hasArrows:!1,slides:e,slidesQty:1,get id(){return`header_car_${t.isMobile??!1?"mobile":"desk"}`},[s]:{hasArrows:s,id:u(a=>`header_car_${a.isMobile??!1?"mobile":"desk"}`,[t],'`header_car_${p0.isMobile??false?"mobile":"desk"}`'),slidesQty:s}},3,"2R_6"),1,"2R_7")},z$=()=>{const[t,e,a,l]=et();clearTimeout(l.value),l.value=setTimeout(()=>{t.value.value.length>2&&fetch(`/api/get-streets?q=${encodeURIComponent(t.value.value)}`).then(r=>r.json()).then(r=>{const o=r.data;o.length===0?e.value="notfound":e.value="success",a.value=o})},1e3)},F$=t=>{const e=W(n("input",null,null,null,3,"2R_0")),a=W(n("input",null,null,null,3,null)),l=W(""),r=W(!1),o=W(),c=W([]),d=W("none"),p=W(1e3);Jt(B("s_OSAER37KIRU",[p]));const g=f(N$,"s_fq93imJ971Y",[l,r,t,e,a]),h=m(f(q$,"s_bR2jjpv9PC0")),v=t.data.HeroCarSlides.map((D,L)=>i(h,{slide:D},3,L)),$=m(f(R$,"s_mBlTNPrtMiQ",[v])),S=f(z$,"s_r2MqT6I0l2Y",[e,d,c,o]);return i(H,{children:[n("div",null,{class:"relative flex h-[80vh] max-h-[750px] w-full items-center"},[n("div",null,{class:u(D=>`fixed bottom-0 left-0 right-0 bg-white top-${D.value?"0 z-[200]":"[100vh] -z-[200]"}  transition-all duration-1000 ease-in-out`,[r],'`fixed bottom-0 left-0 right-0 bg-white top-${p0.value?"0 z-[200]":"[100vh] -z-[200]"}  transition-all duration-1000 ease-in-out`')},[n("button",null,{"aria-label":"Close popup",class:'absolute right-2  mt-2 mx-0" bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] focus:outline-none z-[600]',onClick$:g},n("div",null,{class:"px-3 flex flex-row items-center text-xs gap-2"},["Back to site ",i(wr,null,3,"2R_8")],1,null),1,null),n("iframe",null,{class:"h-full w-full",frameBorder:"0",src:u(D=>D.value,[l],"p0.value")},null,3,null)],1,null),n("video",{poster:G(t.data.VideoBGDesktop.data.attributes.caption)},{autoPlay:!0,class:"absolute left-0 top-0 -z-10 h-full w-full object-cover",loop:!0,muted:!0,preload:"auto"},n("source",{src:G(t.data[`${p.value<=800?"VideoBGMobile":"VideoBGDesktop"}`].data.attributes.url)+"#t=0.1"},{type:"video/mp4"},null,3,null),1,null),n("div",null,{class:"flex h-full w-full items-center justify-between max-[1000px]:flex-col-reverse max-[1000px]:px-4"},[i($,null,3,"2R_9"),n("div",null,{class:"relative flex w-[420px] flex-col items-center justify-center gap-5 rounded-bl-full rounded-tl-full bg-white bg-opacity-60 max-[1000px]:mb-8 max-[1000px]:w-full max-[1000px]:max-w-[420px] max-[1000px]:rounded-full max-[1000px]:py-8 min-[1000px]:h-[230px]"},[n("div",{class:`absolute left-10 right-10 top-[90%] z-20 flex max-h-[200px] flex-col gap-3 overflow-y-auto rounded-xl bg-white p-6 text-primary-blue shadow-lg ${d.value==="none"||d.value==="selected"?"hidden":""}`},null,[u(D=>D.value.length===0?"Not found":"",[c],'p0.value.length===0?"Not found":""'),c.value.map((D,L)=>n("div",{onClick$:B("s_0WdAGCARSDU",[e,D,d,a])},{class:"grid items-center gap-4 hover:cursor-pointer",style:{gridTemplateColumns:"20px 1fr"}},[i(ld,{class:"w-6 text-secondary-red",[s]:{class:s}},3,"2R_10"),n("span",null,{class:"text-[14px]"},w(D,"address"),1,null)],0,L))],1,null),n("div",null,{class:"px-8 text-center text-[22px] font-[600] text-primary-blue max-[1000px]:px-12"},u(D=>D.data.HeroForm.Title,[t],'p0.data["HeroForm"]["Title"]'),3,null),n("div",null,{class:"flex w-full items-center gap-4 px-6 max-[1000px]:flex-col "},[n("input",{ref:e},{class:"w-[50%] rounded-full px-3 py-2 placeholder-primary-blue",onKeyUp$:S,placeholder:"Address Search",type:"text"},null,3,null),n("input",{ref:a},{class:"w-[50%] rounded-full px-3 py-2 placeholder-primary-blue",placeholder:"Zip Code",type:"text"},null,3,null)],1,null),i(X,{get text(){return t.data.HeroForm.ActionButton.Text},onClick:g,[s]:{onClick:s,text:u(D=>D.data.HeroForm.ActionButton.Text,[t],'p0.data["HeroForm"]["ActionButton"]["Text"]')}},3,"2R_11")],1,null)],1,null)],1,null),n("div",null,{class:"flex justify-center bg-gradient-to-r from-[#3d76c1] to-[#3568ae] px-4 pt-4"},i($,{isMobile:!0,[s]:{isMobile:s}},3,"2R_12"),1,null)]},1,"2R_13")},G$=m(f(F$,"s_S18xoZmdQUw")),Q$=t=>n("div",null,{class:"z-20 flex w-full justify-center bg-gradient-to-br from-[#3d76c2] to-[#2e599a] px-10 py-6 text-white"},n("div",null,{class:"flex max-w-[1100px] items-center justify-center gap-8 max-[1000px]:flex-col"},[n("div",null,{class:"flex w-[50%] flex-col text-justify max-[1000px]:w-[100%]"},[n("div",null,{class:"text-[38px] font-bold max-sm:text-[28px]"},u(e=>e.data.prosPar.Title,[t],'p0.data.prosPar["Title"]'),3,null),n("div",null,{class:"text-[18px] max-sm:text-[15px]"},u(e=>e.data.prosPar.Paragraph,[t],'p0.data.prosPar["Paragraph"]'),3,null),n("div",null,{class:"mt-6 flex flex-col gap-4"},t.data.prosData.map((e,a)=>n("div",null,{class:"flex-row "},[n("div",null,{class:" bg-secondary-red h-fit w-fit rounded-full p-2"},i(E,{height:20,toWhite:!0,width:20,get url(){return e.Icon.data.attributes.url},get alt(){return e.Icon.data.attributes.alternativeText},get title(){return e.Icon.data.attributes.caption},[s]:{alt:x(e.Icon.data.attributes,"alternativeText"),height:s,title:x(e.Icon.data.attributes,"caption"),toWhite:s,url:x(e.Icon.data.attributes,"url"),width:s}},3,"l8_0"),1,null),n("div",null,{class:"flex flex-col"},[n("span",null,{class:"text-[28px] font-bold"},i(C,{get text(){return e.Title},classN:"text-white",[s]:{classN:s,text:x(e,"Title")}},3,"l8_1"),1,null),n("span",null,{class:"text-[18px] "},i(C,{get text(){return e.Text},classN:"text-white",[s]:{classN:s,text:x(e,"Text")}},3,"l8_2"),1,null)],1,null)],1,a)),1,null)],1,null),i(E,{height:"800",width:"800",get url(){return t.data.prosMap.url},get alt(){return t.data.prosMap.alternativeText},get title(){return t.data.prosMap.caption},clasN:"px-8  min-w-[250px]",[s]:{alt:u(e=>e.data.prosMap.alternativeText,[t],'p0.data.prosMap["alternativeText"]'),clasN:s,height:s,title:u(e=>e.data.prosMap.caption,[t],'p0.data.prosMap["caption"]'),url:u(e=>e.data.prosMap.url,[t],'p0.data.prosMap["url"]'),width:s}},3,"l8_3")],1,null),1,"l8_4"),H$=m(f(Q$,"s_F6ekLiR69OY")),W$=t=>{const e=t.data.Logo.data.attributes.url,a=t.data.Logo.data.attributes.alternativeText,l=t.data.Media.data.attributes.url,r=t.data.Media.data.attributes.alternativeText;return n("div",null,{class:"mb-4 flex flex-row-reverse max-w-[1200px] items-center justify-center gap-4 self-center px-8 max-[800px]:flex-col-reverse"},[n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[40%]"},i(E,{alt:r,height:800,url:l,width:800,[s]:{height:s,width:s}},3,"a2_0"),1,null),n("div",null,{class:"flex flex-col items-center justify-center gap-4 min-[800px]:w-[60%]"},[n("div",null,{class:"max-w-[470px]"},i(E,{alt:a,height:230,url:e,width:1230,[s]:{height:s,width:s}},3,"a2_1"),1,null),n("div",null,{class:"flex items-start gap-2"},[n("div",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(o=>o.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"text-center text-[28px] font-bold text-secondary-red max-sm:text-[18px]"},u(o=>o.data.Subtitle,[t],'p0.data["Subtitle"]'),3,null)],3,null),n("div",null,{class:"text-primary-blue"},[i(C,{classN:"text-justify max-sm:text-[15px] text-[18px] text-[#2E5899]",get text(){return t.data.Paragraph},[s]:{classN:s,text:u(o=>o.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"a2_2"),t.parGFIPlans.map((o,c)=>n("div",null,{class:"text-[22px]"},i(xe,{get title(){return o.Title},children:i(C,{classN:"text-[16px] text-justify",get text(){return o.Paragraph},[s]:{classN:s,text:x(o,"Paragraph")}},3,"a2_3"),classContainer:"bg-white shadow-xl",[s]:{classContainer:s,title:x(o,"Title")}},1,"a2_4"),1,c))],1,null),n("div",null,{class:"flex gap-4"},t.data.Buttons.map((o,c)=>i(X,{get text(){return o.Text},get link(){return o.Link},[s]:{link:x(o,"Link"),text:x(o,"Text")}},3,c)),1,null)],1,null)],1,"a2_5")},U$=m(f(W$,"s_M9NFBwXMc48")),V$=t=>n("div",null,{class:"flex items-center justify-evenly gap-4 px-8 py-6 max-[1200px]:flex-col"},t.data.map((e,a)=>n("div",null,{class:" flex max-w-[400px] flex-col items-center gap-2 text-center text-primary-blue"},[i(Be,{get url(){return e.Media.data.attributes.url},get alt(){return e.Media.data.attributes.alternativeText},get title(){return e.Media.data.attributes.caption},color:"bg-primary-blue",width:"w-[360px]",[s]:{alt:x(e.Media.data.attributes,"alternativeText"),color:s,title:x(e.Media.data.attributes,"caption"),url:x(e.Media.data.attributes,"url"),width:s}},3,"pO_0"),n("h5",null,{class:"text-[24px] font-[700]"},w(e,"Title"),1,null),n("p",null,{class:"text-[17px] font-[400]"},w(e,"Paragraph"),1,null),i(X,{get text(){return e.Buttons[0].Text},get link(){return e.Buttons[0].Link},[s]:{link:x(e.Buttons[0],"Link"),text:x(e.Buttons[0],"Text")}},3,"pO_1")],1,a)),1,"pO_2"),Y$=m(f(V$,"s_PyTSx8biYlE")),Z$=t=>{const e=t.data.pageHome.data.attributes,a=t.data.sectionProsRta.data.attributes.Pros,l=e.ProsPicture.data.attributes;return n("div",null,{class:"relative ",onClick$:B("s_TkQ204PTgK8")},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-[100vh] -z-10 bg-white"},null,3,null),i(G$,{data:e},3,"Ee_0"),i(H$,{data:{prosPar:e.ProsPar,prosData:a,prosMap:l}},3,"Ee_1"),i(qt,{get data(){return e.ParACP},reverse:!0,textPercentage:60,[s]:{data:x(e,"ParACP"),reverse:s,textPercentage:s}},3,"Ee_2"),n("div",null,{class:"flex w-full justify-center bg-[#ebf4fc]"},i(U$,{data:e.ParGFServices[0],get parGFIPlans(){return e.ParGFIPlans},[s]:{parGFIPlans:x(e,"ParGFIPlans")}},3,"Ee_3"),1,null),i(ee,{data:e.ParGFServices.slice(1,e.ParGFServices.length)},3,"Ee_4"),n("div",null,{class:"bg-[#ebf4fc]"},i(Y$,{get data(){return e.SugsPages},[s]:{data:x(e,"SugsPages")}},3,"Ee_5"),1,null)],1,"Ee_6")},K$=m(f(Z$,"s_G08oK4nfxwg")),X$=t=>n("div",null,{class:"flex  w-full flex-col items-center justify-center px-8 text-primary-blue"},[n("div",null,{class:"flex max-w-[1400px] items-center justify-evenly gap-4 py-16 max-[800px]:flex-col"},[n("h1",null,{class:"w-[40%] text-center text-[42px] font-[600]  max-sm:text-[28px] leading-10 max-[800px]:w-full"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),i(E,{clasN:" rounded-2xl shadow-xl w-[40%] max-[800px]:w-full",height:"539",width:"833",get url(){return t.data.Cover.data.attributes.url},get alt(){return t.data.Cover.data.attributes.alternativeText},get title(){return t.data.Cover.data.attributes.caption},[s]:{alt:u(e=>e.data.Cover.data.attributes.alternativeText,[t],'p0.data["Cover"]["data"]["attributes"]["alternativeText"]'),clasN:s,height:s,title:u(e=>e.data.Cover.data.attributes.caption,[t],'p0.data["Cover"]["data"]["attributes"]["caption"]'),url:u(e=>e.data.Cover.data.attributes.url,[t],'p0.data["Cover"]["data"]["attributes"]["url"]'),width:s}},3,"cD_0")],1,null),n("div",null,{class:"mb-8 max-w-[1400px]"},i(C,{get text(){return t.data.Description},classN:"text-justify",[s]:{classN:s,text:u(e=>e.data.Description,[t],'p0.data["Description"]')}},3,"cD_1"),1,null)],1,"cD_2"),J$=m(f(X$,"s_QI52uAygONM")),tb=(t,e)=>{const a=e==="es-419";return console.log(`query QueryPostPage {
    posts (filters: {Slug: {eq: "${t}${a?"-es":""}"}} pagination:{limit:1} locale:"${e}") {
      data {
        attributes {
          Title
          Date
          Description
          Slug
          Cover {
            data {
              attributes {
                url
                caption
                alternativeText
              }
            }
          }
          SEO {
            MetaTitle
            MetaDescription
            Keywords
            preventIndexing
          }
          
        }
      }
    }
  }`),`query QueryPostPage {
        posts (filters: {Slug: {eq: "${t}${a?"-es":""}"}} pagination:{limit:1} locale:"${e}") {
          data {
            attributes {
              Title
              Date
              Description
              Slug
              Cover {
                data {
                  attributes {
                    url
                    caption
                    alternativeText
                  }
                }
              }
              SEO {
                MetaTitle
                MetaDescription
                Keywords
                preventIndexing
              }
              
            }
          }
        }
      }`},eb=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang;let a={};if(e=="en"||e=="es-419")return a=await R(Ir,e),{...a,type:"home"};const l=e.includes("es/")?"es-419":"en",r=e.includes("es/")?e.split("es/")[1]:e;return a=await Oa(tb(r,l),l),{...a,type:a.pageData.data.posts.data.length>0?"post":"404"}},vn=N(f(eb,"s_Up0e7VSBoHc")),ab=()=>{Z();const t=vn();return i(z,{get data(){return t.value.layoutData},children:[n("h1",null,{class:"absolute opacity-0"},"Rural Telecommunications of America Inc.",3,null),t.value.type=="home"?i(K$,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"2d_0"):t.value.type=="post"?i(J$,{get data(){return t.value.pageData.data.posts.data[0].attributes},[s]:{data:u(e=>e.value.pageData.data.posts.data[0].attributes,[t],'p0.value["pageData"]["data"]["posts"]["data"][0]["attributes"]')}},3,"2d_1"):i(Er,null,3,"2d_2")],showHeader:!1,[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"2d_3")},lb=m(f(ab,"s_jpH0I2vriFs")),nb=({resolveValue:t})=>{const e=t(vn),a=e.type;let l;return a=="home"?l=e.pageData.data.pageHome.data.attributes.SEO:a=="post"?(l=e.pageData.data.posts.data[0].attributes.SEO,l||(l={MetaTitle:e.pageData.data.posts.data[0].attributes.Title,MetaDescription:e.pageData.data.posts.data[0].attributes.Description,preventIndexing:!0,Keywords:e.pageData.data.posts.data[0].attributes.Title})):l={MetaTitle:"Not found"},Q(l)},sb=Object.freeze(Object.defineProperty({__proto__:null,default:lb,head:nb,usePageData:vn},Symbol.toStringTag,{value:"Module"})),rb=[Vu],A=()=>Ic,ib=[["forms/",[A,()=>Nc],"/forms/",["q-6eb6e525.js","q-315cacf3.js"]],["[...lang]/api/emailjs/",[A,()=>Rc],"/[...lang]/api/emailjs/",["q-6eb6e525.js"]],["[...lang]/api/get-streets/",[A,()=>Gc],"/[...lang]/api/get-streets/",["q-6eb6e525.js"]],["[...lang]/acp/",[A,()=>bp],"/[...lang]/acp/",["q-6eb6e525.js","q-196c5951.js"]],["[...lang]/appreciation-giveaway/",[A,()=>Pp],"/[...lang]/appreciation-giveaway/",["q-6eb6e525.js","q-a4b4bf93.js"]],["[...lang]/appreciation-lead/",[A,()=>Op],"/[...lang]/appreciation-lead/",["q-6eb6e525.js","q-d923d8e6.js"]],["[...lang]/awards/",[A,()=>Qp],"/[...lang]/awards/",["q-6eb6e525.js","q-f84ef7a2.js"]],["[...lang]/blog/",[A,()=>s0],"/[...lang]/blog/",["q-6eb6e525.js","q-a4fd2699.js"]],["[...lang]/board-members/",[A,()=>g0],"/[...lang]/board-members/",["q-6eb6e525.js","q-eb5e92e1.js"]],["[...lang]/business/",[A,()=>y0],"/[...lang]/business/",["q-6eb6e525.js","q-20839444.js"]],["[...lang]/careers/",[A,()=>F0],"/[...lang]/careers/",["q-6eb6e525.js","q-b942e7e1.js"]],["[...lang]/client-services-agreement-general-terms-and-conditions/",[A,()=>Z0],"/[...lang]/client-services-agreement-general-terms-and-conditions/",["q-6eb6e525.js","q-f54dc185.js"]],["[...lang]/contact-us/",[A,()=>ng],"/[...lang]/contact-us/",["q-6eb6e525.js","q-94991cfc.js"]],["[...lang]/cookies/",[A,()=>pg],"/[...lang]/cookies/",["q-6eb6e525.js","q-26c20c6d.js"]],["[...lang]/deals/",[A,()=>Pg],"/[...lang]/deals/",["q-6eb6e525.js","q-bb7b2fe3.js"]],["[...lang]/faq/",[A,()=>Og],"/[...lang]/faq/",["q-6eb6e525.js","q-3335e8d4.js"]],["[...lang]/gfsn/",[A,()=>Kg],"/[...lang]/gfsn/",["q-6eb6e525.js","q-0b169dfb.js"]],["[...lang]/gigfast-cloud/",[A,()=>sf],"/[...lang]/gigfast-cloud/",["q-6eb6e525.js","q-049dd479.js"]],["[...lang]/gigfast-internet-support/",[A,()=>bf],"/[...lang]/gigfast-internet-support/",["q-6eb6e525.js","q-d84aedea.js"]],["[...lang]/gigfast-internet/",[A,()=>kf],"/[...lang]/gigfast-internet/",["q-6eb6e525.js","q-f9ad946a.js"]],["[...lang]/gigfast-iot/",[A,()=>Bf],"/[...lang]/gigfast-iot/",["q-6eb6e525.js","q-15834c59.js"]],["[...lang]/gigfast-tv-privacy-policy/",[A,()=>Qf],"/[...lang]/gigfast-tv-privacy-policy/",["q-6eb6e525.js","q-16c8cd0e.js"]],["[...lang]/gigfast-tv-support/",[A,()=>lx],"/[...lang]/gigfast-tv-support/",["q-6eb6e525.js","q-353a46a1.js"]],["[...lang]/gigfast-tv/",[A,()=>wx],"/[...lang]/gigfast-tv/",["q-6eb6e525.js","q-a3d35132.js"]],["[...lang]/gigfast-voice-support/",[A,()=>Mx],"/[...lang]/gigfast-voice-support/",["q-6eb6e525.js","q-92e5a4d9.js"]],["[...lang]/gigfast-voice/",[A,()=>Fx],"/[...lang]/gigfast-voice/",["q-6eb6e525.js","q-15b77bfd.js"]],["[...lang]/giving-back/",[A,()=>Zx],"/[...lang]/giving-back/",["q-6eb6e525.js","q-6e5dfdb5.js"]],["[...lang]/leadership-team/",[A,()=>am],"/[...lang]/leadership-team/",["q-6eb6e525.js","q-d1310cb8.js"]],["[...lang]/legal/",[A,()=>cm],"/[...lang]/legal/",["q-6eb6e525.js","q-ce16f6db.js"]],["[...lang]/local-weather-stations/",[A,()=>$m],"/[...lang]/local-weather-stations/",["q-6eb6e525.js","q-08988d24.js"]],["[...lang]/news/",[A,()=>Dm],"/[...lang]/news/",["q-6eb6e525.js","q-a2cd9f4a.js"]],["[...lang]/our-story/",[A,()=>Em],"/[...lang]/our-story/",["q-6eb6e525.js","q-3b29ac90.js"]],["[...lang]/portability/",[A,()=>Qm],"/[...lang]/portability/",["q-6eb6e525.js","q-df661fc6.js"]],["[...lang]/post_slug/",[A,()=>Km],"/[...lang]/post_slug/",["q-6eb6e525.js","q-3f8d2930.js"]],["[...lang]/privacy-policy/",[A,()=>sh],"/[...lang]/privacy-policy/",["q-6eb6e525.js","q-aa1310e8.js"]],["[...lang]/referral-program/",[A,()=>xh],"/[...lang]/referral-program/",["q-6eb6e525.js","q-e0c559cb.js"]],["[...lang]/residential/",[A,()=>_h],"/[...lang]/residential/",["q-6eb6e525.js","q-d1f31976.js"]],["[...lang]/support/",[A,()=>jh],"/[...lang]/support/",["q-6eb6e525.js","q-f97ab65c.js"]],["[...lang]/testimonials/",[A,()=>zh],"/[...lang]/testimonials/",["q-6eb6e525.js","q-8c0a1951.js"]],["[...lang]/wholesale/",[A,()=>Yh],"/[...lang]/wholesale/",["q-6eb6e525.js","q-0c4604b3.js"]],["[...lang]/winners-circle/",[A,()=>n$],"/[...lang]/winners-circle/",["q-6eb6e525.js","q-73435272.js"]],["[...lang]/zane-smith-sponsorship/",[A,()=>S$],"/[...lang]/zane-smith-sponsorship/",["q-6eb6e525.js","q-c6134150.js"]],["[...lang]/texas/[slug]/",[A,()=>A$],"/[...lang]/texas/[slug]/",["q-6eb6e525.js","q-c9e586c9.js"]],["[...lang]",[A,()=>sb],"/[...lang]",["q-6eb6e525.js","q-d1a99bd3.js"]]],ob=[],ub=!0,Or="/",cb=!0,Sb={routes:ib,serverPlugins:rb,menus:ob,trailingSlash:ub,basePathname:Or,cacheModules:cb};export{s as A,rb as B,ib as C,ob as D,ub as E,H as F,Or as G,cb as H,yb as Q,bb as R,st as S,gb as _,mb as a,fb as b,Wo as c,m as d,Ht as e,i as f,n as g,u as h,f as i,xb as j,Y as k,w as l,Nt as m,Cl as n,Rt as o,$s as p,Sb as q,et as r,pb as s,Ia as t,vb as u,$b as v,_b as w,hb as x,wb as y,Gn as z};
