import{createClient as ui}from"@supabase/supabase-js";import{parse as fs}from"marked";const ci=!0,di=!1;/**
 * @license
 * @builder.io/qwik 1.4.0
 * Copyright Builder.io, Inc. All Rights Reserved.
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/BuilderIO/qwik/blob/main/LICENSE
 */const Zt=t=>t&&typeof t.nodeType=="number",gs=t=>t.nodeType===9,Xt=t=>t.nodeType===1,Kt=t=>{const e=t.nodeType;return e===1||e===111},pi=t=>{const e=t.nodeType;return e===1||e===111||e===3},Et=t=>t.nodeType===111,Ka=t=>t.nodeType===3,Fe=t=>t.nodeType===8,ae=(t,...e)=>tl(!0,t,...e),xs=(t,...e)=>{throw tl(!1,t,...e)},Ja=(t,...e)=>tl(!0,t,...e),Le=()=>{},fi=t=>t,tl=(t,e,...a)=>{const l=e instanceof Error?e:new Error(e);return console.error("%cQWIK ERROR","",l.stack||l.message,...fi(a)),t&&setTimeout(()=>{throw l},0),l};const nt=(t,...e)=>{const a=ha(t);return Ja(a,...e)},ha=t=>`Code(${t})`,gi=()=>({isServer:ci,importSymbol(t,e,a){var o;{const c=vr(a),d=(o=globalThis.__qwik_reg_symbols)==null?void 0:o.get(c);if(d)return d}if(!e)throw nt(31,a);if(!t)throw nt(30,e,a);const l=xi(t.ownerDocument,t,e).toString(),r=new URL(l);return r.hash="",r.search="",import(r.href).then(c=>c[a])},raf:t=>new Promise(e=>{requestAnimationFrame(()=>{e(t())})}),nextTick:t=>new Promise(e=>{setTimeout(()=>{e(t())})}),chunkForSymbol:(t,e)=>[t,e??"_"]}),xi=(t,e,a)=>{const l=t.baseURI,r=new URL(e.getAttribute("q:base")??l,l);return new URL(a,r)};let el=gi();const ty=t=>el=t,$a=()=>el,At=()=>el.isServer,ze=t=>{const e=Object.getPrototypeOf(t);return e===Object.prototype||e===null},Bt=t=>!!t&&typeof t=="object",at=t=>Array.isArray(t),Qt=t=>typeof t=="string",ht=t=>typeof t=="function",rt=t=>t&&typeof t.then=="function",ba=(t,e,a)=>{try{const l=t();return rt(l)?l.then(e,a):e(l)}catch(l){return a(l)}},V=(t,e)=>rt(t)?t.then(e):e(t),al=t=>t.some(rt)?Promise.all(t):t,la=t=>t.length>0?Promise.all(t):t,ms=t=>t!=null,mi=t=>new Promise(e=>{setTimeout(e,t)}),Mt=[],xt={},Ge=t=>typeof document<"u"?document:t.nodeType===9?t:t.ownerDocument,$t="q:slot",ya="q:style",Oa=Symbol("proxy target"),de=Symbol("proxy flags"),jt=Symbol("proxy manager"),s=Symbol("IMMUTABLE"),va="_qc_",mt=(t,e,a)=>t.setAttribute(e,a),Lt=(t,e)=>t.getAttribute(e),ll=t=>t.replace(/([A-Z])/g,"-$1").toLowerCase(),hi=t=>t.replace(/-./g,e=>e[1].toUpperCase()),qn=Symbol("ContainerState"),ye=t=>{let e=t[qn];return e||(t[qn]=e=nl(t,Lt(t,"q:base")??"/")),e},nl=(t,e)=>{const a={$containerEl$:t,$elementIndex$:0,$styleMoved$:!1,$proxyMap$:new WeakMap,$opsNext$:new Set,$taskNext$:new Set,$taskStaging$:new Set,$hostsNext$:new Set,$hostsStaging$:new Set,$styleIds$:new Set,$events$:new Set,$serverData$:{},$base$:e,$renderPromise$:void 0,$hostsRendering$:void 0,$pauseCtx$:void 0,$subsManager$:null,$inlineFns$:new Map};return a.$subsManager$=gc(a),a},sl=(t,e)=>{if(ht(t))return t(e);if(Bt(t)&&"value"in t)return t.value=e;throw nt(32,t)},$i=t=>Xt(t)&&t.hasAttribute("q:container"),Ht=t=>t.toString(36),Ct=t=>parseInt(t,36),hs=t=>{const e=t.indexOf(":");return t&&hi(t.slice(e+1))},bi=/^(on|window:|document:)/,$s="preventdefault:",rl=t=>t.endsWith("$")&&bi.test(t),il=t=>{if(t.length===0)return Mt;if(t.length===1){const a=t[0];return[[a[0],[a[1]]]]}const e=[];for(let a=0;a<t.length;a++){const l=t[a][0];e.includes(l)||e.push(l)}return e.map(a=>[a,t.filter(l=>l[0]===a).map(l=>l[1])])},ol=(t,e,a,l)=>{if(e.endsWith("$"),e=Aa(e.slice(0,-1)),a)if(at(a)){const r=a.flat(1/0).filter(o=>o!=null).map(o=>[e,zn(o,l)]);t.push(...r)}else t.push([e,zn(a,l)]);return e},Fn=["on","window:on","document:on"],yi=["on","on-window","on-document"],Aa=t=>{let e="on";for(let a=0;a<Fn.length;a++){const l=Fn[a];if(t.startsWith(l)){e=yi[a],t=t.slice(l.length);break}}return e+":"+(t=t.startsWith("-")?ll(t.slice(1)):t.toLowerCase())},zn=(t,e)=>(t.$setContainer$(e),t),vi=(t,e)=>{const a=t.$element$.attributes,l=[];for(let r=0;r<a.length;r++){const{name:o,value:c}=a.item(r);if(o.startsWith("on:")||o.startsWith("on-window:")||o.startsWith("on-document:")){const d=c.split(`
`);for(const p of d){const f=ka(p,e);f.$capture$&&fr(f,t),l.push([o,f])}}}return l},wi=(t,e)=>{cl(ul(t,void 0),e)},Gn=(t,e)=>{cl(ul(t,"document"),e)},_i=(t,e)=>{cl(ul(t,"window"),e)},ul=(t,e)=>{const a=e!==void 0?e+":":"";return Array.isArray(t)?t.map(l=>`${a}on-${l}`):`${a}on-${t}`},cl=(t,e)=>{if(e){const a=Hs(),l=dt(a.$hostElement$,a.$renderCtx$.$static$.$containerState$);typeof t=="string"?l.li.push([Aa(t),e]):l.li.push(...t.map(r=>[Aa(r),e])),l.$flags$|=Yt}},Si=(t,e,a,l)=>{typeof CustomEvent=="function"&&t&&t.dispatchEvent(new CustomEvent(e,{detail:a,bubbles:l,composed:l}))},u=(t,e,a)=>new Na(t,e,a),Ti=t=>{const e=t.$funcStr$;let a="";for(let l=0;l<t.$args$.length;l++)a+=`p${l},`;return`(${a})=>(${e})`};var bs;const Di=(t,e,a,l)=>{const r=e.$subsManager$.$createManager$(l);return new Me(t,r,a)},Ce=Symbol("proxy manager"),ys=Symbol("unassigned signal");class Qe{}class Me extends Qe{constructor(e,a,l){super(),this[bs]=0,this.untrackedValue=e,this[jt]=a,this[Ce]=l}valueOf(){}toString(){return`[Signal ${String(this.value)}]`}toJSON(){return{value:this.value}}get value(){var a;if(2&this[Ce])throw ys;const e=(a=Tt())==null?void 0:a.$subscriber$;return e&&this[jt].$addSub$(e),this.untrackedValue}set value(e){const a=this[jt];a&&this.untrackedValue!==e&&(this.untrackedValue=e,a.$notifySubs$())}}bs=Ce;class Na extends Qe{constructor(e,a,l){super(),this.$func$=e,this.$args$=a,this.$funcStr$=l}get value(){return this.$func$.apply(void 0,this.$args$)}}class Ra extends Qe{constructor(e,a){super(),this.ref=e,this.prop=a}get[jt](){return ut(this.ref)}get value(){return this.ref[this.prop]}set value(e){this.ref[this.prop]=e}}const ct=t=>t instanceof Qe,x=(t,e)=>{var r,o;if(!Bt(t))return t[e];if(t instanceof Qe)return t;const a=ie(t);if(a){const c=a["$$"+e];if(c)return c;if(((r=a[s])==null?void 0:r[e])!==!0)return new Ra(t,e)}const l=(o=t[s])==null?void 0:o[e];return ct(l)?l:s},_=(t,e)=>{const a=x(t,e);return a===s?t[e]:a},dl=(t,e,a=0)=>e.$proxyMap$.get(t)||(a!==0&&_a(t,a),He(t,e,void 0)),He=(t,e,a)=>{Ve(t),e.$proxyMap$.has(t);const l=e.$subsManager$.$createManager$(a),r=new Proxy(t,new vs(e,l));return e.$proxyMap$.set(t,r),r},wa=()=>{const t={};return _a(t,2),t},_a=(t,e)=>{Object.defineProperty(t,de,{value:e,enumerable:!1})},Pi=(t,e)=>{const a={};for(const l in t)e.includes(l)||(a[l]=t[l]);return a};class vs{constructor(e,a){this.$containerState$=e,this.$manager$=a}deleteProperty(e,a){if(2&e[de])throw nt(17);return typeof a=="string"&&delete e[a]&&(this.$manager$.$notifySubs$(at(e)?void 0:a),!0)}get(e,a){var f;if(typeof a=="symbol")return a===Oa?e:a===jt?this.$manager$:e[a];const l=e[de]??0,r=Tt(),o=(1&l)!=0,c=e["$$"+a];let d,p;if(r&&(d=r.$subscriber$),!(2&l)||a in e&&!ki((f=e[s])==null?void 0:f[a])||(d=null),c?(p=c.value,d=null):p=e[a],d){const h=at(e);this.$manager$.$addSub$(d,h?void 0:a)}return o?Li(p,this.$containerState$):p}set(e,a,l){if(typeof a=="symbol")return e[a]=l,!0;const r=e[de]??0;if(2&r)throw nt(17);const o=1&r?Ve(l):l;if(at(e))return e[a]=o,this.$manager$.$notifySubs$(),!0;const c=e[a];return e[a]=o,c!==o&&this.$manager$.$notifySubs$(a),!0}has(e,a){if(a===Oa)return!0;const l=Object.prototype.hasOwnProperty;return!!l.call(e,a)||!(typeof a!="string"||!l.call(e,"$$"+a))}ownKeys(e){if(!(2&(e[de]??0))){let l=null;const r=Tt();r&&(l=r.$subscriber$),l&&this.$manager$.$addSub$(l)}return at(e)?Reflect.ownKeys(e):Reflect.ownKeys(e).map(l=>typeof l=="string"&&l.startsWith("$$")?l.slice(2):l)}getOwnPropertyDescriptor(e,a){return at(e)||typeof a=="symbol"?Object.getOwnPropertyDescriptor(e,a):{enumerable:!0,configurable:!0}}}const ki=t=>t===s||ct(t),Li=(t,e)=>{if(Bt(t)){if(Object.isFrozen(t))return t;const a=Ve(t);if(a!==t||hr(a))return t;if(ze(a)||at(a))return e.$proxyMap$.get(a)||dl(a,e,1)}return t},Ci=(t,e=0)=>{for(let a=0;a<t.length;a++)e=(e<<5)-e+t.charCodeAt(a),e|=0;return Number(Math.abs(e)).toString(36)},Mi=(t,e)=>`${Ci(t.$hash$)}-${e}`,ws=t=>{const e=t.join("|");if(e.length>0)return e};var _s;const ea="<!--qkssr-f-->";class Ss{constructor(e){this.nodeType=e,this[_s]=null}}_s=va;const ji=()=>new Ss(9),ey=async(t,e)=>{var w,D,L;const a=e.containerTagName,l=na(1).$element$,r=nl(l,e.base??"/");r.$serverData$.locale=(w=e.serverData)==null?void 0:w.locale;const o=ji(),c=Us(o,r),d=e.beforeContent??[],p={$static$:{$contexts$:[],$headNodes$:a==="html"?d:[],$locale$:(D=e.serverData)==null?void 0:D.locale,$textNodes$:new Map},$projectedChildren$:void 0,$projectedCtxs$:void 0,$invocationContext$:void 0};let f="ssr";e.containerAttributes["q:render"]&&(f=`${e.containerAttributes["q:render"]}-${f}`);const h={...e.containerAttributes,"q:container":"paused","q:version":"1.4.0","q:render":f,"q:base":e.base,"q:locale":(L=e.serverData)==null?void 0:L.locale,"q:manifest-hash":e.manifestHash},y=a==="html"?[t]:[d,t];a!=="html"&&(h.class="qc📦"+(h.class?" "+h.class:"")),e.serverData&&(r.$serverData$=e.serverData);const b=n(a,null,h,y,me|Yt,null);r.$hostsRendering$=new Set,await Promise.resolve().then(()=>Ei(b,c,p,e.stream,r,e))},Ei=async(t,e,a,l,r,o)=>{const c=o.beforeClose;return await fl(t,e,a,l,0,c?d=>{const p=c(a.$static$.$contexts$,r,!1,a.$static$.$textNodes$);return _t(p,e,a,d,0,void 0)}:void 0),e},Bi=async(t,e,a,l,r)=>{l.write(ea);const o=t.props.children;let c;if(ht(o)){const d=o({write(p){l.write(p),l.write(ea)}});if(rt(d))return d;c=d}else c=o;for await(const d of c)await _t(d,e,a,l,r,void 0),l.write(ea)},Ts=(t,e,a,l,r,o,c,d)=>{var L;const p=t.props,f=p["q:renderFn"];if(f)return e.$componentQrl$=f,Ai(l,r,o,e,t,c,d);let h="<!--qv"+Oi(p);const y="q:s"in p,b=t.key!=null?String(t.key):null;y&&((L=l.$cmpCtx$)==null||L.$id$,h+=" q:sref="+l.$cmpCtx$.$id$),b!=null&&(h+=" q:key="+b),h+="-->",o.write(h);const w=t.props[ot];if(w)return o.write(w),void o.write(ja);if(a)for(const v of a)pl(v.type,v.props,o);const D=Ds(t.children,l,r,o,c);return V(D,()=>{var S;if(!y&&!d)return void o.write(ja);let v;if(y){const M=(S=r.$projectedChildren$)==null?void 0:S[b];if(M){const[k,T]=r.$projectedCtxs$,E=We(k);E.$slotCtx$=e,r.$projectedChildren$[b]=void 0,v=_t(M,E,T,o,c)}}return d&&(v=V(v,()=>d(o))),V(v,()=>{o.write(ja)})})},ja="<!--/qv-->",Ii=t=>{let e="";for(const a in t){if(a===ot)continue;const l=t[a];l!=null&&(e+=" "+(l===""?a:a+'="'+l+'"'))}return e},Oi=t=>{let e="";for(const a in t){if(a==="children"||a===ot)continue;const l=t[a];l!=null&&(e+=" "+(l===""?a:a+"="+l))}return e},pl=(t,e,a)=>{if(a.write("<"+t+Ii(e)+">"),Ls[t])return;const l=e[ot];l!=null&&a.write(l),a.write(`</${t}>`)},Ai=(t,e,a,l,r,o,c)=>(Ri(t,l,r.props.props),V(sa(t,l),d=>{const p=l.$element$,f=d.rCtx,h=Dt(e.$static$.$locale$,p,void 0);h.$subscriber$=[0,p],h.$renderCtx$=f;const y={$static$:e.$static$,$projectedChildren$:Ni(r.children,e),$projectedCtxs$:[t,e],$invocationContext$:h},b=[];if(l.$appendStyles$){const v=4&o?e.$static$.$headNodes$:b;for(const S of l.$appendStyles$)v.push(n("style",{[ya]:S.styleId,[ot]:S.content,hidden:""},null,null,0,null))}const w=Ee(t),D=l.$scopeIds$?ws(l.$scopeIds$):void 0,L=i(r.type,{"q:sstyle":D,"q:id":w,children:d.node},0,r.key);return l.$id$=w,e.$static$.$contexts$.push(l),Ts(L,l,b,f,y,a,o,v=>{if(l.$flags$&Yt){const k=na(1),T=k.li;T.push(...l.li),l.$flags$&=~Yt,k.$id$=Ee(t);const E={type:"placeholder",hidden:"","q:id":k.$id$};e.$static$.$contexts$.push(k);const B=il(T);for(const R of B){const j=Cs(R[0]);E[j]=El(R[1],t.$static$.$containerState$,k),qa(j,t.$static$.$containerState$)}pl("script",E,v)}const S=y.$projectedChildren$;let M;if(S){const k=Object.keys(S).map(R=>{const j=S[R];if(j)return n("q:template",{[$t]:R||!0,hidden:!0,"aria-hidden":"true"},null,j,0,null)}),[T,E]=y.$projectedCtxs$,B=We(T);B.$slotCtx$=l,M=_t(k,B,E,v,0,void 0)}return c?V(M,()=>c(v)):M})})),Ni=(t,e)=>{const a=Ps(t,e);if(a===null)return;const l={};for(const r of a){let o="";se(r)&&(o=r.props[$t]||""),(l[o]||(l[o]=[])).push(r)}return l},na=t=>{const e=new Ss(t);return Ta(e)},fl=(t,e,a,l,r,o)=>{var f;const c=t.type,d=e.$cmpCtx$;if(typeof c=="string"){const h=t.key,y=t.props,b=t.immutableProps,w=na(1),D=w.$element$,L=c==="head";let v="<"+c,S=!1,M=!1,k="",T=null;const E=(j,H,J)=>{if(j==="ref")return void(H!==void 0&&(sl(H,D),M=!0));if(rl(j))return void ol(w.li,j,H,void 0);if(ct(H)&&(H=Nt(H,J?[1,D,H,d.$element$,j]:[2,d.$element$,H,D,j]),S=!0),j===ot)return void(T=H);let tt;j.startsWith($s)&&qa(j.slice(15),e.$static$.$containerState$);const et=j==="htmlFor"?"for":j;et==="class"?k=ra(H):et==="style"?tt=Da(H):Vs(et)||et==="draggable"||et==="spellcheck"?(tt=H!=null?String(H):null,H=tt):tt=H===!1||H==null?null:String(H),tt!=null&&(et==="value"&&c==="textarea"?T=Fa(tt):Hi(et)||(v+=" "+(H===!0?et:et+'="'+Ea(tt)+'"')))};if(b)for(const j in b)E(j,b[j],!0);for(const j in y)E(j,y[j],!1);const B=w.li;if(d){if((f=d.$scopeIds$)!=null&&f.length){const j=d.$scopeIds$.join(" ");k=k?`${j} ${k}`:j}d.$flags$&Yt&&(B.push(...d.li),d.$flags$&=~Yt)}if(L&&(r|=1),c in qi&&(r|=16),c in Fi&&(r|=8),k&&(v+=' class="'+Ea(k)+'"'),B.length>0){const j=il(B),H=(16&r)!=0;for(const J of j){const tt=H?Cs(J[0]):J[0];v+=" "+tt+'="'+El(J[1],e.$static$.$containerState$,w)+'"',qa(tt,e.$static$.$containerState$)}}if(h!=null&&(v+=' q:key="'+Ea(h)+'"'),M||S||B.length>0){if(M||S||Wi(B)){const j=Ee(e);v+=' q:id="'+j+'"',w.$id$=j}a.$static$.$contexts$.push(w)}if(1&r&&(v+=" q:head"),v+=">",l.write(v),c in Ls)return;if(T!=null)return l.write(String(T)),void l.write(`</${c}>`);c==="html"?r|=4:r&=-5,t.flags&Ie&&(r|=1024);const R=_t(t.children,e,a,l,r);return V(R,()=>{if(L){for(const j of a.$static$.$headNodes$)pl(j.type,j.props,l);a.$static$.$headNodes$.length=0}if(o)return V(o(l),()=>{l.write(`</${c}>`)});l.write(`</${c}>`)})}if(c===Wt){const h=na(111);return e.$slotCtx$?(h.$parentCtx$=e.$slotCtx$,h.$realParentCtx$=e.$cmpCtx$):h.$parentCtx$=e.$cmpCtx$,d&&d.$flags$&_l&&Ui(d,h),Ts(t,h,void 0,e,a,l,r,o)}if(c===Ms)return void l.write(t.props.data);if(c===js)return Bi(t,e,a,l,r);const p=pt(a.$invocationContext$,c,t.props,t.key,t.flags,t.dev);return Zs(p,t)?fl(i(Wt,{children:p},0,t.key),e,a,l,r,o):_t(p,e,a,l,r,o)},_t=(t,e,a,l,r,o)=>{var c;if(t!=null&&typeof t!="boolean"){if(!Qt(t)&&typeof t!="number"){if(se(t))return fl(t,e,a,l,r,o);if(at(t))return Ds(t,e,a,l,r);if(ct(t)){const d=8&r,p=(c=e.$cmpCtx$)==null?void 0:c.$element$;let f;if(p){if(!d){const h=Ee(e);if(f=Nt(t,1024&r?[3,"#"+h,t,"#"+h]:[4,p,t,"#"+h]),Qt(f)){const y=Be(f);a.$static$.$textNodes$.set(y,h)}return l.write(`<!--t=${h}-->`),_t(f,e,a,l,r,o),void l.write("<!---->")}f=pt(a.$invocationContext$,()=>t.value)}return void l.write(Fa(Be(f)))}return rt(t)?(l.write(ea),t.then(d=>_t(d,e,a,l,r,o))):void Le()}l.write(Fa(String(t)))}},Ds=(t,e,a,l,r)=>{if(t==null)return;if(!at(t))return _t(t,e,a,l,r);const o=t.length;if(o===1)return _t(t[0],e,a,l,r);if(o===0)return;let c=0;const d=[];return t.reduce((p,f,h)=>{const y=[];d.push(y);const b=_t(f,e,a,p?{write(w){c===h?l.write(w):y.push(w)}}:l,r);if(p||rt(b)){const w=()=>{c++,d.length>c&&d[c].forEach(D=>l.write(D))};return rt(b)?p?Promise.all([b,p]).then(w):b.then(w):p.then(w)}c++},void 0)},Ps=(t,e)=>{if(t==null)return null;const a=ks(t,e),l=at(a)?a:[a];return l.length===0?null:l},ks=(t,e)=>{if(t==null)return null;if(at(t))return t.flatMap(a=>ks(a,e));if(se(t)&&ht(t.type)&&t.type!==Ms&&t.type!==js&&t.type!==Wt){const a=pt(e.$invocationContext$,t.type,t.props,t.key,t.flags);return Ps(a,e)}return t},Ri=(t,e,a)=>{const l=Object.keys(a),r=wa();if(e.$props$=He(r,t.$static$.$containerState$),l.length===0)return;const o=r[s]=a[s]??xt;for(const c of l)c!=="children"&&c!==$t&&(ct(o[c])?r["$$"+c]=o[c]:r[c]=a[c])},qi={head:!0,style:!0,script:!0,link:!0,meta:!0},Fi={title:!0,style:!0,script:!0,noframes:!0,textarea:!0},Ls={area:!0,base:!0,basefont:!0,bgsound:!0,br:!0,col:!0,embed:!0,frame:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0},zi=/[&<>]/g,Gi=/[&"]/g,qa=(t,e)=>{e.$events$.add(hs(t))},Fa=t=>t.replace(zi,e=>{switch(e){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";default:return""}}),Ea=t=>t.replace(Gi,e=>{switch(e){case"&":return"&amp;";case'"':return"&quot;";default:return""}}),Qi=/[>/="'\u0009\u000a\u000c\u0020]/,Hi=t=>Qi.test(t),Wi=t=>t.some(e=>e[1].$captureRef$&&e[1].$captureRef$.length>0),Ui=(t,e)=>{const a=t.$dynamicSlots$||(t.$dynamicSlots$=[]);a.includes(e)||a.push(e)},Cs=t=>t==="on:qvisible"?"on-document:qinit":t,n=(t,e,a,l,r,o)=>{const c=o==null?null:String(o);return new ve(t,e||xt,a,l,r,c)},Y=(t,e,a,l,r,o)=>{let c=null;return e&&"children"in e&&(c=e.children,delete e.children),n(t,e,a,c,l,r)},i=(t,e,a,l,r)=>{const o=l==null?null:String(l),c=e??{};if(typeof t=="string"&&s in c){const p=c[s];delete c[s];const f=c.children;delete c.children;for(const[h,y]of Object.entries(p))y!==s&&(delete c[h],c[h]=y);return n(t,null,c,f,a,l)}const d=new ve(t,c,null,c.children,a,o);return typeof t=="string"&&e&&delete e.children,d},ay=(t,e,a)=>{const r=Pe(()=>{const c=e.children;return typeof t=="string"&&delete e.children,c});return Qt(t)&&"className"in e&&(e.class=e.className,delete e.className),new ve(t,e,null,r,0,null)};class ve{constructor(e,a,l,r,o,c=null){this.type=e,this.props=a,this.immutableProps=l,this.children=r,this.flags=o,this.key=c}}const Wt=t=>t.children,se=t=>t instanceof ve,Q=t=>t.children,gl=Symbol("skip render"),Ms=()=>null,js=()=>null,xl=(t,e,a)=>{const l=!(e.$flags$&wl),r=e.$element$,o=t.$static$.$containerState$;return o.$hostsStaging$.delete(e),o.$subsManager$.$clearSub$(r),V(sa(t,e),c=>{const d=t.$static$,p=c.rCtx,f=Dt(t.$static$.$locale$,r);if(d.$hostElements$.add(r),f.$subscriber$=[0,r],f.$renderCtx$=p,l&&e.$appendStyles$)for(const y of e.$appendStyles$)lu(d,y);const h=Ut(c.node,f);return V(h,y=>{const b=Yi(r,y),w=ml(e);return V(ua(p,w,b,a),()=>{e.$vdom$=b})})})},ml=t=>(t.$vdom$||(t.$vdom$=ca(t.$element$)),t.$vdom$);class Ot{constructor(e,a,l,r,o,c){this.$type$=e,this.$props$=a,this.$immutableProps$=l,this.$children$=r,this.$flags$=o,this.$key$=c,this.$elm$=null,this.$text$="",this.$signal$=null,this.$id$=e+(c?":"+c:"")}}const Es=(t,e)=>{const{key:a,type:l,props:r,children:o,flags:c,immutableProps:d}=t;let p="";if(Qt(l))p=l;else{if(l!==Wt){if(ht(l)){const h=pt(e,l,r,a,c,t.dev);return Zs(h,t)?Es(i(Wt,{children:h},0,a),e):Ut(h,e)}throw nt(25,l)}p=he}let f=Mt;return o!=null?V(Ut(o,e),h=>(h!==void 0&&(f=at(h)?h:[h]),new Ot(p,r,d,f,c,a))):new Ot(p,r,d,f,c,a)},Yi=(t,e)=>{const a=e===void 0?Mt:at(e)?e:[e],l=new Ot(":virtual",{},null,a,0,null);return l.$elm$=t,l},Ut=(t,e)=>{if(t!=null&&typeof t!="boolean"){if(Bs(t)){const a=new Ot("#text",xt,null,Mt,0,null);return a.$text$=String(t),a}if(se(t))return Es(t,e);if(ct(t)){const a=new Ot("#signal",xt,null,Mt,0,null);return a.$signal$=t,a}if(at(t)){const a=al(t.flatMap(l=>Ut(l,e)));return V(a,l=>l.flat(100).filter(ms))}return rt(t)?t.then(a=>Ut(a,e)):t===gl?new Ot(":skipRender",xt,null,Mt,0,null):void Le()}},Bs=t=>Qt(t)||typeof t=="number",Is=t=>{Lt(t,"q:container")==="paused"&&(Xi(t),lo(t))},Vi=t=>{const e=Ge(t),a=eo(t===e.documentElement?e.body:t,"type");if(a)return JSON.parse(Ji(a.firstChild.data)||"{}")},Zi=(t,e)=>{const a=JSON.parse(t);if(typeof a!="object")return null;const{_objs:l,_entry:r}=a;if(l===void 0||r===void 0)return null;let o={},c={};if(Zt(e)&&Kt(e)){const f=Sl(e);f&&(c=ye(f),o=f.ownerDocument)}const d=xr(c,o);for(let f=0;f<l.length;f++){const h=l[f];Qt(h)&&(l[f]=h===La?void 0:d.prepare(h))}const p=f=>l[Ct(f)];for(const f of l)Os(f,p,d);return p(r)},Xi=t=>{if(!$i(t))return void Le();const e=t._qwikjson_??Vi(t);if(t._qwikjson_=null,!e)return void Le();const a=Ge(t),l=to(t),r=ye(t),o=new Map,c=new Map;let d=null,p=0;const f=a.createTreeWalker(t,128);for(;d=f.nextNode();){const v=d.data;if(p===0){if(v.startsWith("qv ")){const S=no(v);S>=0&&o.set(S,d)}else if(v.startsWith("t=")){const S=v.slice(2),M=Ct(S),k=ao(d);o.set(M,k),c.set(M,k.data)}}v==="cq"?p++:v==="/cq"&&p--}const h=t.getElementsByClassName("qc📦").length!==0;t.querySelectorAll("[q\\:id]").forEach(v=>{if(h&&v.closest("[q\\:container]")!==t)return;const S=Lt(v,"q:id"),M=Ct(S);o.set(M,v)});const y=xr(r,a),b=new Map,w=new Set,D=v=>(typeof v=="string"&&v.length>0,b.has(v)?b.get(v):L(v)),L=v=>{if(v.startsWith("#")){const E=v.slice(1),B=Ct(E);o.has(B);const R=o.get(B);if(Fe(R)){if(!R.isConnected)return void b.set(v,void 0);const j=Ye(R);return b.set(v,j),dt(j,r),j}return Xt(R)?(b.set(v,R),dt(R,r),R):(b.set(v,R),R)}if(v.startsWith("@")){const E=v.slice(1),B=Ct(E);return l[B]}if(v.startsWith("*")){const E=v.slice(1),B=Ct(E);o.has(B);const R=c.get(B);return b.set(v,R),R}const S=Ct(v),M=e.objs;M.length>S;let k=M[S];Qt(k)&&(k=k===La?void 0:y.prepare(k));let T=k;for(let E=v.length-1;E>=0;E--){const B=ic[v[E]];if(!B)break;T=B(T,r)}return b.set(v,T),Bs(k)||w.has(S)||(w.add(S),Ki(k,S,e.subs,D,r,y),Os(k,D,y)),T};r.$elementIndex$=1e5,r.$pauseCtx$={getObject:D,meta:e.ctx,refs:e.refs},mt(t,"q:container","resumed"),Si(t,"qresume",void 0,!0)},Ki=(t,e,a,l,r,o)=>{const c=a[e];if(c){const d=[];let p=0;for(const f of c)if(f.startsWith("_"))p=parseInt(f.slice(1),10);else{const h=fc(f,l);h&&d.push(h)}if(p>0&&_a(t,p),!o.subs(t,d)){const f=r.$proxyMap$.get(t);f?ut(f).$addSubs$(d):He(t,r,d)}}},Os=(t,e,a)=>{if(!a.fill(t,e)&&t&&typeof t=="object"){if(at(t))for(let l=0;l<t.length;l++)t[l]=e(t[l]);else if(ze(t))for(const l in t)t[l]=e(t[l])}},Ji=t=>t.replace(/\\x3C(\/?script)/gi,"<$1"),to=t=>t.qFuncs??Mt,eo=(t,e)=>{let a=t.lastElementChild;for(;a;){if(a.tagName==="SCRIPT"&&Lt(a,e)==="qwik/json")return a;a=a.previousElementSibling}},ao=t=>{const e=t.nextSibling;if(Ka(e))return e;{const a=t.ownerDocument.createTextNode("");return t.parentElement.insertBefore(a,t),a}},lo=t=>{t.qwik={pause:()=>bu(t),state:ye(t)}},no=t=>{const e=t.indexOf("q:id=");return e>0?Ct(t.slice(e+5)):-1},X=()=>{const t=Co();let e=t.$qrl$;if(e)e.$captureRef$;else{const a=t.$element$,l=Sl(a);e=ka(decodeURIComponent(String(t.$url$)),l),Is(l);const r=dt(a,ye(l));fr(e,r)}return e.$captureRef$},so=(t,e)=>{try{const a=e[0],l=t.$static$;switch(a){case 1:case 2:{let r,o;a===1?(r=e[1],o=e[3]):(r=e[3],o=e[1]);const c=bt(r);if(c==null)return;const d=e[4],p=r.namespaceURI===Ue;l.$containerState$.$subsManager$.$clearSignal$(e);let f=Nt(e[2],e.slice(0,-1));d==="class"?f=Tl(f,bt(o)):d==="style"&&(f=Da(f));const h=ml(c);return d in h.$props$&&h.$props$[d]===f?void 0:(h.$props$[d]=f,Pl(l,r,d,f,p))}case 3:case 4:{const r=e[3];if(!l.$visited$.includes(r)){l.$containerState$.$subsManager$.$clearSignal$(e);const o=void 0;let c=Nt(e[2],e.slice(0,-1));const d=mc();Array.isArray(c)&&(c=new ve(Wt,{},null,c,0,null));let p=Ut(c,o);if(rt(p))ae("Rendering promises in JSX signals is not supported");else{p===void 0&&(p=Ut("",o));const f=Ks(r),h=ro(e[1]);if(t.$cmpCtx$=dt(h,t.$static$.$containerState$),f.$type$==p.$type$&&f.$key$==p.$key$&&f.$id$==p.$id$)ce(t,f,p,0);else{const y=[],b=f.$elm$,w=te(t,p,0,y);y.length&&ae("Rendering promises in JSX signals is not supported"),d[3]=w,fe(t.$static$,r.parentElement,w,b),b&&Ll(l,b)}}}}}}catch{}};function ro(t){for(;t;){if(Kt(t))return t;t=t.parentElement}throw new Error("Not found")}const io=(t,e)=>{if(t[0]===0){const a=t[1];vl(a)?hl(a,e):oo(a,e)}else uo(t,e)},oo=(t,e)=>{const a=At();a||Is(e.$containerEl$);const l=dt(t,e);if(l.$componentQrl$,!(l.$flags$&me))if(l.$flags$|=me,e.$hostsRendering$!==void 0)e.$hostsStaging$.add(l);else{if(a)return void Le();e.$hostsNext$.add(l),$l(e)}},uo=(t,e)=>{const a=e.$hostsRendering$!==void 0;e.$opsNext$.add(t),a||$l(e)},hl=(t,e)=>{t.$flags$&le||(t.$flags$|=le,e.$hostsRendering$!==void 0?e.$taskStaging$.add(t):(e.$taskNext$.add(t),$l(e)))},$l=t=>(t.$renderPromise$===void 0&&(t.$renderPromise$=$a().nextTick(()=>As(t))),t.$renderPromise$),co=()=>{const[t]=X();hl(t,ye(Sl(t.$el$)))},As=async t=>{const e=t.$containerEl$,a=Ge(e);try{const l=Us(a,t),r=l.$static$,o=t.$hostsRendering$=new Set(t.$hostsNext$);t.$hostsNext$.clear(),await fo(t,l),t.$hostsStaging$.forEach(p=>{o.add(p)}),t.$hostsStaging$.clear();const c=Array.from(t.$opsNext$);t.$opsNext$.clear();const d=Array.from(o);xo(d),!t.$styleMoved$&&d.length>0&&(t.$styleMoved$=!0,(e===a.documentElement?a.body:e).querySelectorAll("style[q\\:style]").forEach(p=>{t.$styleIds$.add(Lt(p,ya)),rr(r,a.head,p)}));for(const p of d){const f=p.$element$;if(!r.$hostElements$.has(f)&&p.$componentQrl$){f.isConnected,r.$roots$.push(p);try{await xl(l,p,po(f.parentElement))}catch(h){ae(h)}}}return c.forEach(p=>{so(l,p)}),r.$operations$.push(...r.$postOperations$),r.$operations$.length===0?(Kn(r),void await Qn(t,l)):(await Zo(r),Kn(r),Qn(t,l))}catch(l){ae(l)}},po=t=>{let e=0;return t&&(t.namespaceURI===Ue&&(e|=gt),t.tagName==="HEAD"&&(e|=ia)),e},Qn=async(t,e)=>{const a=e.$static$.$hostElements$;await go(t,e,(l,r)=>(l.$flags$&Rs)!=0&&(!r||a.has(l.$el$))),t.$hostsStaging$.forEach(l=>{t.$hostsNext$.add(l)}),t.$hostsStaging$.clear(),t.$hostsRendering$=void 0,t.$renderPromise$=void 0,t.$hostsNext$.size+t.$taskNext$.size+t.$opsNext$.size>0&&(t.$renderPromise$=As(t))},Hn=t=>(t.$flags$&qs)!=0,Wn=t=>(t.$flags$&Fs)!=0,fo=async(t,e)=>{const a=t.$containerEl$,l=[],r=[];t.$taskNext$.forEach(o=>{Hn(o)&&(r.push(V(o.$qrl$.$resolveLazy$(a),()=>o)),t.$taskNext$.delete(o)),Wn(o)&&(l.push(V(o.$qrl$.$resolveLazy$(a),()=>o)),t.$taskNext$.delete(o))});do if(t.$taskStaging$.forEach(o=>{Hn(o)?r.push(V(o.$qrl$.$resolveLazy$(a),()=>o)):Wn(o)?l.push(V(o.$qrl$.$resolveLazy$(a),()=>o)):t.$taskNext$.add(o)}),t.$taskStaging$.clear(),r.length>0){const o=await Promise.all(r);za(o),await Promise.all(o.map(c=>Ga(c,t,e))),r.length=0}while(t.$taskStaging$.size>0);if(l.length>0){const o=await Promise.all(l);za(o);for(const c of o)Ga(c,t,e)}},go=async(t,e,a)=>{const l=[],r=t.$containerEl$;t.$taskNext$.forEach(o=>{a(o,!1)&&(o.$el$.isConnected&&l.push(V(o.$qrl$.$resolveLazy$(r),()=>o)),t.$taskNext$.delete(o))});do if(t.$taskStaging$.forEach(o=>{o.$el$.isConnected&&(a(o,!0)?l.push(V(o.$qrl$.$resolveLazy$(r),()=>o)):t.$taskNext$.add(o))}),t.$taskStaging$.clear(),l.length>0){const o=await Promise.all(l);za(o);for(const c of o)Ga(c,t,e);l.length=0}while(t.$taskStaging$.size>0)},xo=t=>{t.sort((e,a)=>2&e.$element$.compareDocumentPosition(pa(a.$element$))?1:-1)},za=t=>{t.sort((e,a)=>e.$el$===a.$el$?e.$index$<a.$index$?-1:1:2&e.$el$.compareDocumentPosition(pa(a.$el$))?1:-1)},re=()=>{const t=Hs(),e=dt(t.$hostElement$,t.$renderCtx$.$static$.$containerState$),a=e.$seq$||(e.$seq$=[]),l=t.$i$++;return{val:a[l],set:r=>a[l]=r,i:l,iCtx:t,elCtx:e}},Rt=t=>Object.freeze({id:ll(t)}),Ft=(t,e)=>{const{val:a,set:l,elCtx:r}=re();if(a!==void 0)return;(r.$contexts$||(r.$contexts$=new Map)).set(t.id,e),l(!0)},we=(t,e)=>{const{val:a,set:l,iCtx:r,elCtx:o}=re();if(a!==void 0)return a;const c=Ns(t,o,r.$renderCtx$.$static$.$containerState$);if(typeof e=="function")return l(pt(void 0,e,c));if(c!==void 0)return l(c);if(e!==void 0)return l(e);throw nt(13,t.id)},mo=(t,e)=>{var r;let a=t,l=1;for(;a&&!((r=a.hasAttribute)!=null&&r.call(a,"q:container"));){for(;a=a.previousSibling;)if(Fe(a)){const o=a.__virtual;if(o){const c=o[va];if(a===o.open)return c??dt(o,e);if(c!=null&&c.$parentCtx$)return c.$parentCtx$;a=o;continue}if(a.data==="/qv")l++;else if(a.data.startsWith("qv ")&&(l--,l===0))return dt(Ye(a),e)}a=t.parentElement,t=a}return null},ho=(t,e)=>(t.$parentCtx$===void 0&&(t.$parentCtx$=mo(t.$element$,e)),t.$parentCtx$),Ns=(t,e,a)=>{var o;const l=t.id;if(!e)return;let r=e;for(;r;){const c=(o=r.$contexts$)==null?void 0:o.get(l);if(c)return c;r=ho(r,a)}},$o=Rt("qk-error"),bl=(t,e,a)=>{const l=bt(e);if(At())throw t;{const r=Ns($o,l,a.$static$.$containerState$);if(r===void 0)throw t;r.error=t}},Rs=1,qs=2,Fs=4,le=16,yl=(t,e)=>{const{val:a,set:l,iCtx:r,i:o,elCtx:c}=re();if(a)return;const d=r.$renderCtx$.$static$.$containerState$,p=new Sa(le|qs,o,c.$element$,t,void 0);l(!0),t.$resolveLazy$(d.$containerEl$),c.$tasks$||(c.$tasks$=[]),c.$tasks$.push(p),jo(r,()=>Gs(p,d,r.$renderCtx$)),At()&&Qa(p,e==null?void 0:e.eagerness)},yt=(t,e)=>{const{val:a,set:l,i:r,iCtx:o,elCtx:c}=re(),d=(e==null?void 0:e.strategy)??"intersection-observer";if(a)return void(At()&&Qa(a,d));const p=new Sa(Rs,r,c.$element$,t,void 0),f=o.$renderCtx$.$static$.$containerState$;c.$tasks$||(c.$tasks$=[]),c.$tasks$.push(p),l(p),Qa(p,d),At()||(t.$resolveLazy$(f.$containerEl$),hl(p,f))},zs=t=>(t.$flags$&Fs)!=0,bo=t=>(8&t.$flags$)!=0,Ga=async(t,e,a)=>(t.$flags$&le,zs(t)?yo(t,e,a):bo(t)?vo(t,e,a):Gs(t,e,a)),yo=(t,e,a,l)=>{t.$flags$&=~le,je(t);const r=Dt(a.$static$.$locale$,t.$el$,void 0,"qTask"),{$subsManager$:o}=e;r.$renderCtx$=a;const c=t.$qrl$.getFn(r,()=>{o.$clearSub$(t)}),d=[],p=t.$state$,f=Ve(p),h={track:(S,M)=>{if(ht(S)){const T=Dt();return T.$renderCtx$=a,T.$subscriber$=[0,t],pt(T,S)}const k=ut(S);return k?k.$addSub$([0,t],M):Ja(ha(26),S),M?S[M]:ct(S)?S.value:S},cleanup(S){d.push(S)},cache(S){let M=0;M=S==="immutable"?1/0:S,p._cache=M},previous:f._resolved};let y,b,w=!1;const D=(S,M)=>!w&&(w=!0,S?(w=!0,p.loading=!1,p._state="resolved",p._resolved=M,p._error=void 0,y(M)):(w=!0,p.loading=!1,p._state="rejected",p._error=M,b(M)),!0);pt(r,()=>{p._state="pending",p.loading=!At(),p.value=new Promise((S,M)=>{y=S,b=M})}),t.$destroy$=Ma(()=>{w=!0,d.forEach(S=>S())});const L=ba(()=>V(l,()=>c(h)),S=>{D(!0,S)},S=>{D(!1,S)}),v=f._timeout;return v>0?Promise.race([L,mi(v).then(()=>{D(!1,new Error("timeout"))&&je(t)})]):L},Gs=(t,e,a)=>{t.$flags$&=~le,je(t);const l=t.$el$,r=Dt(a.$static$.$locale$,l,void 0,"qTask");r.$renderCtx$=a;const{$subsManager$:o}=e,c=t.$qrl$.getFn(r,()=>{o.$clearSub$(t)}),d=[];t.$destroy$=Ma(()=>{d.forEach(f=>f())});const p={track:(f,h)=>{if(ht(f)){const b=Dt();return b.$subscriber$=[0,t],pt(b,f)}const y=ut(f);return y?y.$addSub$([0,t],h):Ja(ha(26),f),h?f[h]:ct(f)?f.value:f},cleanup(f){d.push(f)}};return ba(()=>c(p),f=>{ht(f)&&d.push(f)},f=>{bl(f,l,a)})},vo=(t,e,a)=>{t.$state$,t.$flags$&=~le,je(t);const l=t.$el$,r=Dt(a.$static$.$locale$,l,void 0,"qComputed");r.$subscriber$=[0,t],r.$renderCtx$=a;const{$subsManager$:o}=e,c=t.$qrl$.getFn(r,()=>{o.$clearSub$(t)});return ba(c,d=>Pe(()=>{const p=t.$state$;p[Ce]&=-3,p.untrackedValue=d,p[jt].$notifySubs$()}),d=>{bl(d,l,a)})},je=t=>{const e=t.$destroy$;if(e){t.$destroy$=void 0;try{e()}catch(a){ae(a)}}},Qs=t=>{32&t.$flags$?(t.$flags$&=-33,(0,t.$qrl$)()):je(t)},Qa=(t,e)=>{e==="visible"||e==="intersection-observer"?wi("qvisible",Ba(t)):e==="load"||e==="document-ready"?Gn("qinit",Ba(t)):e!=="idle"&&e!=="document-idle"||Gn("qidle",Ba(t))},Ba=t=>{const e=t.$qrl$;return Ze(e.$chunk$,"_hW",co,null,null,[t],e.$symbol$)},vl=t=>Bt(t)&&t instanceof Sa,wo=(t,e)=>{let a=`${Ht(t.$flags$)} ${Ht(t.$index$)} ${e(t.$qrl$)} ${e(t.$el$)}`;return t.$state$&&(a+=` ${e(t.$state$)}`),a},_o=t=>{const[e,a,l,r,o]=t.split(" ");return new Sa(Ct(e),Ct(a),r,l,o)};class Sa{constructor(e,a,l,r,o){this.$flags$=e,this.$index$=a,this.$el$=l,this.$qrl$=r,this.$state$=o}}function So(t){return To(t)&&t.nodeType===1}function To(t){return t&&typeof t.nodeType=="number"}const me=1,Yt=2,wl=4,_l=8,bt=t=>t[va],dt=(t,e)=>{const a=bt(t);if(a)return a;const l=Ta(t),r=Lt(t,"q:id");if(r){const o=e.$pauseCtx$;if(l.$id$=r,o){const{getObject:c,meta:d,refs:p}=o;if(So(t)){const f=p[r];f&&(l.$refMap$=f.split(" ").map(c),l.li=vi(l,e.$containerEl$))}else{const f=t.getAttribute("q:sstyle");l.$scopeIds$=f?f.split("|"):null;const h=d[r];if(h){const y=h.s,b=h.h,w=h.c,D=h.w;if(y&&(l.$seq$=y.split(" ").map(c)),D&&(l.$tasks$=D.split(" ").map(c)),w){l.$contexts$=new Map;for(const L of w.split(" ")){const[v,S]=L.split("=");l.$contexts$.set(v,c(S))}}if(b){const[L,v]=b.split(" ");if(l.$flags$=wl,L&&(l.$componentQrl$=c(L)),v){const S=c(v);l.$props$=S,_a(S,2),S[s]=Do(S)}else l.$props$=He(wa(),e)}}}}}return l},Do=t=>{const e={},a=ie(t);for(const l in a)l.startsWith("$$")&&(e[l.slice(2)]=a[l]);return e},Ta=t=>{const e={$flags$:0,$id$:"",$element$:t,$refMap$:[],li:[],$tasks$:null,$seq$:null,$slots$:null,$scopeIds$:null,$appendStyles$:null,$props$:null,$vdom$:null,$componentQrl$:null,$contexts$:null,$dynamicSlots$:null,$parentCtx$:void 0,$realParentCtx$:void 0};return t[va]=e,e},Po=(t,e)=>{var a;(a=t.$tasks$)==null||a.forEach(l=>{e.$clearSub$(l),Qs(l)}),t.$componentQrl$=null,t.$seq$=null,t.$tasks$=null};let ge;function ko(t){if(ge===void 0){const e=Tt();return e&&e.$locale$?e.$locale$:t}return ge}function Un(t,e){const a=ge;try{return ge=t,e()}finally{ge=a}}function Lo(t){ge=t}let De;const Tt=()=>{if(!De){const t=typeof document<"u"&&document&&document.__q_context__;return t?at(t)?document.__q_context__=Ws(t):t:void 0}return De},Co=()=>{const t=Tt();if(!t)throw nt(14);return t},Hs=()=>{const t=Tt();if(!t||t.$event$!=="qRender")throw nt(20);return t.$hostElement$,t.$waitOn$,t.$renderCtx$,t.$subscriber$,t};function pt(t,e,...a){return Mo.call(this,t,e,a)}function Mo(t,e,a){const l=De;let r;try{De=t,r=e.apply(this,a)}finally{De=l}return r}const jo=(t,e)=>{const a=t.$waitOn$;if(a.length===0){const l=e();rt(l)&&a.push(l)}else a.push(Promise.all(a).then(e))},Ws=([t,e,a])=>{const l=t.closest("[q\\:container]"),r=(l==null?void 0:l.getAttribute("q:locale"))||void 0;return r&&Lo(r),Dt(r,void 0,t,e,a)},Dt=(t,e,a,l,r)=>({$url$:r,$i$:0,$hostElement$:e,$element$:a,$event$:l,$qrl$:void 0,$waitOn$:void 0,$subscriber$:void 0,$renderCtx$:void 0,$locale$:t}),Sl=t=>t.closest("[q\\:container]"),Pe=t=>pt(void 0,t),Yn=Dt(void 0,void 0,void 0,"qRender"),Nt=(t,e)=>(Yn.$subscriber$=e,pt(Yn,()=>t.value)),Eo=()=>{var e;const t=Tt();if(t)return t.$element$??t.$hostElement$??((e=t.$qrl$)==null?void 0:e.$setContainer$(void 0))},Bo=()=>{const t=Tt();if(t)return t.$event$},W=t=>{const e=Tt();return e&&e.$hostElement$&&e.$renderCtx$&&(dt(e.$hostElement$,e.$renderCtx$.$static$.$containerState$).$flags$|=_l),t},Io=new Set(["animationIterationCount","aspectRatio","borderImageOutset","borderImageSlice","borderImageWidth","boxFlex","boxFlexGroup","boxOrdinalGroup","columnCount","columns","flex","flexGrow","flexShrink","gridArea","gridRow","gridRowEnd","gridRowStart","gridColumn","gridColumnEnd","gridColumnStart","fontWeight","lineClamp","lineHeight","opacity","order","orphans","scale","tabSize","widows","zIndex","zoom","MozAnimationIterationCount","MozBoxFlex","msFlex","msFlexPositive","WebkitAnimationIterationCount","WebkitBoxFlex","WebkitBoxOrdinalGroup","WebkitColumnCount","WebkitColumns","WebkitFlex","WebkitFlexGrow","WebkitFlexShrink","WebkitLineClamp"]),Oo=t=>Io.has(t),sa=(t,e)=>{e.$flags$&=~me,e.$flags$|=wl,e.$slots$=[],e.li.length=0;const a=e.$element$,l=e.$componentQrl$,r=e.$props$,o=Dt(t.$static$.$locale$,a,void 0,"qRender"),c=o.$waitOn$=[],d=We(t);d.$cmpCtx$=e,d.$slotCtx$=void 0,o.$subscriber$=[0,a],o.$renderCtx$=t,l.$setContainer$(t.$static$.$containerState$.$containerEl$);const p=l.getFn(o);return ba(()=>p(r),f=>V(la(c),()=>e.$flags$&me?sa(t,e):{node:f,rCtx:d}),f=>f===ys?V(la(c),()=>sa(t,e)):(bl(f,a,t),{node:gl,rCtx:d}))},Us=(t,e)=>({$static$:{$doc$:t,$locale$:e.$serverData$.locale,$containerState$:e,$hostElements$:new Set,$operations$:[],$postOperations$:[],$roots$:[],$addSlots$:[],$rmSlots$:[],$visited$:[]},$cmpCtx$:null,$slotCtx$:void 0}),We=t=>({$static$:t.$static$,$cmpCtx$:t.$cmpCtx$,$slotCtx$:t.$slotCtx$}),Tl=(t,e)=>{var a;return(a=e==null?void 0:e.$scopeIds$)!=null&&a.length?e.$scopeIds$.join(" ")+" "+ra(t):ra(t)},ra=t=>{if(!t)return"";if(Qt(t))return t.trim();const e=[];if(at(t))for(const a of t){const l=ra(a);l&&e.push(l)}else for(const[a,l]of Object.entries(t))l&&e.push(a.trim());return e.join(" ")},Da=t=>{if(t==null)return"";if(typeof t=="object"){if(at(t))throw nt(0,t,"style");{const e=[];for(const a in t)if(Object.prototype.hasOwnProperty.call(t,a)){const l=t[a];l!=null&&(a.startsWith("--")?e.push(a+":"+l):e.push(ll(a)+":"+Ao(a,l)))}return e.join(";")}}return String(t)},Ao=(t,e)=>typeof e!="number"||e===0||Oo(t)?e:e+"px",Ee=t=>Ht(t.$static$.$containerState$.$elementIndex$++),Ys=(t,e)=>{const a=Ee(t);e.$id$=a},Be=t=>ct(t)?Be(t.value):t==null||typeof t=="boolean"?"":String(t);function Vs(t){return t.startsWith("aria-")}const Zs=(t,e)=>!!e.key&&(!se(t)||!ht(t.type)&&t.key!=e.key),Ie=2,ot="dangerouslySetInnerHTML",Ue="http://www.w3.org/2000/svg",gt=1,ia=2,oa=[],ua=(t,e,a,l)=>{e.$elm$;const r=a.$children$;if(r.length===1&&r[0].$type$===":skipRender")return void(a.$children$=e.$children$);const o=e.$elm$;let c=da;e.$children$===oa&&o.nodeName==="HEAD"&&(c=qo,l|=ia);const d=No(e,c);return d.length>0&&r.length>0?Ro(t,o,d,r,l):d.length>0&&r.length===0?Dl(t.$static$,d,0,d.length-1):r.length>0?tr(t,o,null,r,0,r.length-1,l):void 0},No=(t,e)=>{const a=t.$children$;return a===oa?t.$children$=Xs(t.$elm$,e):a},Ro=(t,e,a,l,r)=>{let o=0,c=0,d=a.length-1,p=a[0],f=a[d],h=l.length-1,y=l[0],b=l[h],w,D,L;const v=[],S=t.$static$;for(;o<=d&&c<=h;)if(p==null)p=a[++o];else if(f==null)f=a[--d];else if(y==null)y=l[++c];else if(b==null)b=l[--h];else if(p.$id$===y.$id$)v.push(ce(t,p,y,r)),p=a[++o],y=l[++c];else if(f.$id$===b.$id$)v.push(ce(t,f,b,r)),f=a[--d],b=l[--h];else if(p.$key$&&p.$id$===b.$id$)p.$elm$,f.$elm$,v.push(ce(t,p,b,r)),au(S,e,p.$elm$,f.$elm$),p=a[++o],b=l[--h];else if(f.$key$&&f.$id$===y.$id$)p.$elm$,f.$elm$,v.push(ce(t,f,y,r)),fe(S,e,f.$elm$,p.$elm$),f=a[--d],y=l[++c];else{if(w===void 0&&(w=Jo(a,o,d)),D=w[y.$key$],D===void 0){const k=te(t,y,r,v);fe(S,e,k,p==null?void 0:p.$elm$)}else if(L=a[D],L.$type$!==y.$type$){const k=te(t,y,r,v);V(k,T=>{fe(S,e,T,p==null?void 0:p.$elm$)})}else v.push(ce(t,L,y,r)),a[D]=void 0,L.$elm$,fe(S,e,L.$elm$,p.$elm$);y=l[++c]}c<=h&&v.push(tr(t,e,l[h+1]==null?null:l[h+1].$elm$,l,c,h,r));let M=al(v);return o<=d&&(M=V(M,()=>{Dl(S,a,o,d)})),M},pe=(t,e)=>{const a=Et(t)?t.close:null,l=[];let r=t.firstChild;for(;(r=Cl(r))&&(e(r)&&l.push(r),r=r.nextSibling,r!==a););return l},Xs=(t,e)=>pe(t,e).map(Ks),Ks=t=>{var e;return Xt(t)?((e=bt(t))==null?void 0:e.$vdom$)??ca(t):ca(t)},ca=t=>{if(Kt(t)){const e=new Ot(t.localName,{},null,oa,0,Wa(t));return e.$elm$=t,e}if(Ka(t)){const e=new Ot(t.nodeName,xt,null,oa,0,null);return e.$text$=t.data,e.$elm$=t,e}},qo=t=>{const e=t.nodeType;return e===1?t.hasAttribute("q:head"):e===111},Ha=t=>t.nodeName==="Q:TEMPLATE",da=t=>{const e=t.nodeType;if(e===3||e===111)return!0;if(e!==1)return!1;const a=t.nodeName;return a!=="Q:TEMPLATE"&&(a==="HEAD"?t.hasAttribute("q:head"):a!=="STYLE"||!t.hasAttribute(ya))},Js=t=>{const e={};for(const a of t){const l=Fo(a);(e[l]??(e[l]=new Ot(he,{"q:s":""},null,[],0,l))).$children$.push(a)}return e},ce=(t,e,a,l)=>{e.$type$,a.$type$,e.$key$,a.$key$,e.$id$,a.$id$;const r=e.$elm$,o=a.$type$,c=t.$static$,d=c.$containerState$,p=t.$cmpCtx$;if(a.$elm$=r,o==="#text"){c.$visited$.push(r);const b=a.$signal$;return b&&(a.$text$=Be(Nt(b,[4,p.$element$,b,r]))),void Vt(c,r,"data",a.$text$)}if(o==="#signal")return;const f=a.$props$,h=a.$flags$,y=dt(r,d);if(o!==he){let b=(l&gt)!=0;if(b||o!=="svg"||(l|=gt,b=!0),f!==xt){!(1&h)&&(y.li.length=0);const w=e.$props$;a.$props$=w;for(const D in f){let L=f[D];if(D!=="ref")if(rl(D)){const v=ol(y.li,D,L,d.$containerEl$);lr(c,r,v)}else ct(L)&&(L=Nt(L,[1,p.$element$,L,r,D])),D==="class"?L=Tl(L,p):D==="style"&&(L=Da(L)),w[D]!==L&&(w[D]=L,Pl(c,r,D,L,b));else L!==void 0&&sl(L,r)}}return h&Ie||(b&&o==="foreignObject"&&(l&=~gt),f[ot]!==void 0)||o==="textarea"?void 0:ua(t,e,a,l)}if("q:renderFn"in f){const b=f.props;Vo(d,y,b);let w=!!(y.$flags$&me);return w||y.$componentQrl$||y.$element$.hasAttribute("q:id")||(Ys(t,y),y.$componentQrl$=b["q:renderFn"],y.$componentQrl$,w=!0),w?V(xl(t,y,l),()=>Vn(t,y,a,l)):Vn(t,y,a,l)}if("q:s"in f)return p.$slots$,void p.$slots$.push(a);if(ot in f)Vt(c,r,"innerHTML",f[ot]);else if(!(h&Ie))return ua(t,e,a,l)},Vn=(t,e,a,l)=>{if(a.$flags$&Ie)return;const r=t.$static$,o=Js(a.$children$),c=ar(e);for(const d in c.slots)if(!o[d]){const p=c.slots[d],f=Xs(p,da);if(f.length>0){const h=bt(p);h&&h.$vdom$&&(h.$vdom$.$children$=[]),Dl(r,f,0,f.length-1)}}for(const d in c.templates){const p=c.templates[d];p&&!o[d]&&(c.templates[d]=void 0,Ll(r,p))}return al(Object.keys(o).map(d=>{const p=o[d],f=er(r,c,e,d,t.$static$.$containerState$),h=ml(f),y=We(t),b=f.$element$;y.$slotCtx$=f,f.$vdom$=p,p.$elm$=b;let w=l&~gt;b.isSvg&&(w|=gt);const D=r.$addSlots$.findIndex(L=>L[0]===b);return D>=0&&r.$addSlots$.splice(D,1),ua(y,h,p,w)}))},tr=(t,e,a,l,r,o,c)=>{const d=[];for(;r<=o;++r){const p=l[r],f=te(t,p,c,d);fe(t.$static$,e,f,a)}return la(d)},Dl=(t,e,a,l)=>{for(;a<=l;++a){const r=e[a];r&&(r.$elm$,Ll(t,r.$elm$))}},er=(t,e,a,l,r)=>{const o=e.slots[l];if(o)return dt(o,r);const c=e.templates[l];if(c)return dt(c,r);const d=ir(t.$doc$,l),p=Ta(d);return p.$parentCtx$=a,su(t,a.$element$,d),e.templates[l]=d,p},Fo=t=>t.$props$[$t]??"",te=(t,e,a,l)=>{const r=e.$type$,o=t.$static$.$doc$,c=t.$cmpCtx$;if(r==="#text")return e.$elm$=o.createTextNode(e.$text$);if(r==="#signal"){const v=e.$signal$,S=v.value;if(se(S)){const M=Ut(S);if(ct(M))throw new Error("NOT IMPLEMENTED: Promise");if(Array.isArray(M))throw new Error("NOT IMPLEMENTED: Array");{const k=te(t,M,a,l);return Nt(v,4&a?[3,k,v,k]:[4,c.$element$,v,k]),e.$elm$=k}}{const M=o.createTextNode(e.$text$);return M.data=e.$text$=Be(S),Nt(v,4&a?[3,M,v,M]:[4,c.$element$,v,M]),e.$elm$=M}}let d,p=!!(a&gt);p||r!=="svg"||(a|=gt,p=!0);const f=r===he,h=e.$props$,y=t.$static$,b=y.$containerState$;f?d=du(o,p):r==="head"?(d=o.head,a|=ia):(d=kl(o,r,p),a&=~ia),e.$flags$&Ie&&(a|=4),e.$elm$=d;const w=Ta(d);if(t.$slotCtx$?(w.$parentCtx$=t.$slotCtx$,w.$realParentCtx$=t.$cmpCtx$):w.$parentCtx$=t.$cmpCtx$,f){if("q:renderFn"in h){const v=h["q:renderFn"],S=wa(),M=b.$subsManager$.$createManager$(),k=new Proxy(S,new vs(b,M)),T=h.props;if(b.$proxyMap$.set(S,k),w.$props$=k,T!==xt){const B=S[s]=T[s]??xt;for(const R in T)if(R!=="children"&&R!==$t){const j=B[R];ct(j)?S["$$"+R]=j:S[R]=T[R]}}Ys(t,w),w.$componentQrl$=v;const E=V(xl(t,w,a),()=>{let B=e.$children$;if(B.length===0)return;B.length===1&&B[0].$type$===":skipRender"&&(B=B[0].$children$);const R=ar(w),j=[],H=Js(B);for(const J in H){const tt=H[J],et=er(y,R,w,J,y.$containerState$),It=We(t),ue=et.$element$;It.$slotCtx$=et,et.$vdom$=tt,tt.$elm$=ue;let ft=a&~gt;ue.isSvg&&(ft|=gt);for(const st of tt.$children$){const Se=te(It,st,ft,j);st.$elm$,st.$elm$,rr(y,ue,Se)}}return la(j)});return rt(E)&&l.push(E),d}if("q:s"in h)c.$slots$,uu(d,e.$key$),mt(d,"q:sref",c.$id$),mt(d,"q:s",""),c.$slots$.push(e),y.$addSlots$.push([d,c.$element$]);else if(ot in h)return Vt(y,d,"innerHTML",h[ot]),d}else{if(e.$immutableProps$&&Xn(y,w,c,e.$immutableProps$,p,!0),h!==xt&&(w.$vdom$=e,e.$props$=Xn(y,w,c,h,p,!1)),p&&r==="foreignObject"&&(p=!1,a&=~gt),c){const v=c.$scopeIds$;v&&v.forEach(S=>{d.classList.add(S)}),c.$flags$&Yt&&(w.li.push(...c.li),c.$flags$&=~Yt)}for(const v of w.li)lr(y,d,v[0]);if(h[ot]!==void 0)return d;p&&r==="foreignObject"&&(p=!1,a&=~gt)}let D=e.$children$;if(D.length===0)return d;D.length===1&&D[0].$type$===":skipRender"&&(D=D[0].$children$);const L=D.map(v=>te(t,v,a,l));for(const v of L)Oe(d,v);return d},zo=t=>{const e=t.$slots$;return e||(t.$element$.parentElement,t.$slots$=Go(t))},ar=t=>{const e=zo(t),a={},l={},r=Array.from(t.$element$.childNodes).filter(Ha);for(const o of e)o.$elm$,a[o.$key$??""]=o.$elm$;for(const o of r)l[Lt(o,$t)??""]=o;return{slots:a,templates:l}},Go=t=>{const e=t.$element$.parentElement;return xu(e,"q:sref",t.$id$).map(ca)},Qo=(t,e,a)=>(Vt(t,e.style,"cssText",a),!0),Ho=(t,e,a)=>(e.namespaceURI===Ue?Ae(t,e,"class",a):Vt(t,e,"className",a),!0),Zn=(t,e,a,l)=>l in e&&((e[l]!==a||l==="value"&&!e.hasAttribute(l))&&(e.tagName==="SELECT"?eu(t,e,l,a):Vt(t,e,l,a)),!0),Te=(t,e,a,l)=>(Ae(t,e,l.toLowerCase(),a),!0),Wo=(t,e,a)=>(Vt(t,e,"innerHTML",a),!0),Uo=()=>!0,Yo={style:Qo,class:Ho,value:Zn,checked:Zn,href:Te,list:Te,form:Te,tabIndex:Te,download:Te,innerHTML:Uo,[ot]:Wo},Pl=(t,e,a,l,r)=>{if(Vs(a))return void Ae(t,e,a,l!=null?String(l):l);const o=Yo[a];o&&o(t,e,l,a)||(r||!(a in e)?(a.startsWith($s)&&nr(a.slice(15)),Ae(t,e,a,l)):Vt(t,e,a,l))},Xn=(t,e,a,l,r,o)=>{const c={},d=e.$element$;for(const p in l){let f=l[p];if(p!=="ref")if(rl(p))ol(e.li,p,f,t.$containerState$.$containerEl$);else{if(ct(f)&&(f=Nt(f,o?[1,d,f,a.$element$,p]:[2,a.$element$,f,d,p])),p==="class"){if(f=Tl(f,a),!f)continue}else p==="style"&&(f=Da(f));c[p]=f,Pl(t,d,p,f,r)}else f!==void 0&&sl(f,d)}return c},Vo=(t,e,a)=>{let l=e.$props$;if(l||(e.$props$=l=He(wa(),t)),a===xt)return;const r=ut(l),o=ie(l),c=o[s]=a[s]??xt;for(const d in a)if(d!=="children"&&d!==$t&&!c[d]){const p=a[d];o[d]!==p&&(o[d]=p,r.$notifySubs$(d))}},ke=(t,e,a,l)=>{if(a.$clearSub$(t),Kt(t)){if(l&&t.hasAttribute("q:s"))return void e.$rmSlots$.push(t);const r=bt(t);r&&Po(r,a);const o=Et(t)?t.close:null;let c=t.firstChild;for(;(c=Cl(c))&&(ke(c,e,a,!0),c=c.nextSibling,c!==o););}},Zo=async t=>{ou(t)},Oe=(t,e)=>{Et(e)?e.appendTo(t):t.appendChild(e)},Xo=(t,e)=>{Et(e)?e.remove():t.removeChild(e)},Ko=(t,e,a)=>{Et(e)?e.insertBeforeTo(t,(a==null?void 0:a.nextSibling)??null):t.insertBefore(e,(a==null?void 0:a.nextSibling)??null)},Pa=(t,e,a)=>{Et(e)?e.insertBeforeTo(t,pa(a)):t.insertBefore(e,pa(a))},Jo=(t,e,a)=>{const l={};for(let r=e;r<=a;++r){const o=t[r].$key$;o!=null&&(l[o]=r)}return l},lr=(t,e,a)=>{a.startsWith("on:")||Ae(t,e,a,""),nr(a)},nr=t=>{var e;{const a=hs(t);try{((e=globalThis).qwikevents||(e.qwikevents=[])).push(a)}catch{}}},Ae=(t,e,a,l)=>{t.$operations$.push({$operation$:tu,$args$:[e,a,l]})},tu=(t,e,a)=>{if(a==null||a===!1)t.removeAttribute(e);else{const l=a===!0?"":String(a);mt(t,e,l)}},Vt=(t,e,a,l)=>{t.$operations$.push({$operation$:sr,$args$:[e,a,l]})},eu=(t,e,a,l)=>{t.$postOperations$.push({$operation$:sr,$args$:[e,a,l]})},sr=(t,e,a)=>{try{t[e]=a??"",a==null&&Zt(t)&&Xt(t)&&t.removeAttribute(e)}catch(l){ae(ha(6),{node:t,key:e,value:a},l)}},kl=(t,e,a)=>a?t.createElementNS(Ue,e):t.createElement(e),fe=(t,e,a,l)=>(t.$operations$.push({$operation$:Pa,$args$:[e,a,l||null]}),a),au=(t,e,a,l)=>(t.$operations$.push({$operation$:Ko,$args$:[e,a,l||null]}),a),rr=(t,e,a)=>(t.$operations$.push({$operation$:Oe,$args$:[e,a]}),a),lu=(t,e)=>{t.$containerState$.$styleIds$.add(e.styleId),t.$postOperations$.push({$operation$:nu,$args$:[t.$containerState$,e]})},nu=(t,e)=>{const a=t.$containerEl$,l=Ge(a),r=l.documentElement===a,o=l.head,c=l.createElement("style");mt(c,ya,e.styleId),mt(c,"hidden",""),c.textContent=e.content,r&&o?Oe(o,c):Pa(a,c,a.firstChild)},su=(t,e,a)=>{t.$operations$.push({$operation$:ru,$args$:[e,a]})},ru=(t,e)=>{Pa(t,e,t.firstChild)},Ll=(t,e)=>{Kt(e)&&ke(e,t,t.$containerState$.$subsManager$,!0),t.$operations$.push({$operation$:iu,$args$:[e,t]})},iu=t=>{const e=t.parentElement;e&&Xo(e,t)},ir=(t,e)=>{const a=kl(t,"q:template",!1);return mt(a,$t,e),mt(a,"hidden",""),mt(a,"aria-hidden","true"),a},ou=t=>{for(const e of t.$operations$)e.$operation$.apply(void 0,e.$args$);cu(t)},Wa=t=>Lt(t,"q:key"),uu=(t,e)=>{e!==null&&mt(t,"q:key",e)},cu=t=>{const e=t.$containerState$.$subsManager$;for(const a of t.$rmSlots$){const l=Wa(a),r=pe(a,da);if(r.length>0){const o=a.getAttribute("q:sref"),c=t.$roots$.find(d=>d.$id$===o);if(c){const d=c.$element$;if(d.isConnected)if(pe(d,Ha).some(p=>Lt(p,$t)===l))ke(a,t,e,!1);else{const p=ir(t.$doc$,l);for(const f of r)Oe(p,f);Pa(d,p,d.firstChild)}else ke(a,t,e,!1)}else ke(a,t,e,!1)}}for(const[a,l]of t.$addSlots$){const r=Wa(a),o=pe(l,Ha).find(c=>c.getAttribute($t)===r);o&&(pe(o,da).forEach(c=>{Oe(a,c)}),o.remove())}},Kn=()=>{},du=(t,e)=>{const a=t.createComment("qv "),l=t.createComment("/qv");return new or(a,l,e)},pu=t=>{if(!t)return{};const e=t.split(" ");return Object.fromEntries(e.map(a=>{const l=a.indexOf("=");return l>=0?[a.slice(0,l),hu(a.slice(l+1))]:[a,""]}))},fu=t=>{const e=[];return Object.entries(t).forEach(([a,l])=>{e.push(l?`${a}=${mu(l)}`:`${a}`)}),e.join(" ")},gu=(t,e,a)=>t.ownerDocument.createTreeWalker(t,128,{acceptNode(l){const r=Ye(l);return r&&Lt(r,e)===a?1:2}}),xu=(t,e,a)=>{const l=gu(t,e,a),r=[];let o=null;for(;o=l.nextNode();)r.push(Ye(o));return r},mu=t=>t.replace(/ /g,"+"),hu=t=>t.replace(/\+/g," "),he=":virtual";class or{constructor(e,a,l){this.open=e,this.close=a,this.isSvg=l,this._qc_=null,this.nodeType=111,this.localName=he,this.nodeName=he;const r=this.ownerDocument=e.ownerDocument;this.$template$=kl(r,"template",!1),this.$attributes$=pu(e.data.slice(3)),e.data.startsWith("qv "),e.__virtual=this,a.__virtual=this}insertBefore(e,a){const l=this.parentElement;return l?l.insertBefore(e,a||this.close):this.$template$.insertBefore(e,a),e}remove(){const e=this.parentElement;if(e){const a=this.childNodes;this.$template$.childElementCount,e.removeChild(this.open);for(let l=0;l<a.length;l++)this.$template$.appendChild(a[l]);e.removeChild(this.close)}}appendChild(e){return this.insertBefore(e,null)}insertBeforeTo(e,a){const l=this.childNodes;e.insertBefore(this.open,a);for(const r of l)e.insertBefore(r,a);e.insertBefore(this.close,a),this.$template$.childElementCount}appendTo(e){this.insertBeforeTo(e,null)}get namespaceURI(){var e;return((e=this.parentElement)==null?void 0:e.namespaceURI)??""}removeChild(e){this.parentElement?this.parentElement.removeChild(e):this.$template$.removeChild(e)}getAttribute(e){return this.$attributes$[e]??null}hasAttribute(e){return e in this.$attributes$}setAttribute(e,a){this.$attributes$[e]=a,this.open.data=Jn(this.$attributes$)}removeAttribute(e){delete this.$attributes$[e],this.open.data=Jn(this.$attributes$)}matches(e){return!1}compareDocumentPosition(e){return this.open.compareDocumentPosition(e)}closest(e){const a=this.parentElement;return a?a.closest(e):null}querySelectorAll(e){const a=[];return pe(this,pi).forEach(l=>{Kt(l)&&(l.matches(e)&&a.push(l),a.concat(Array.from(l.querySelectorAll(e))))}),a}querySelector(e){for(const a of this.childNodes)if(Xt(a)){if(a.matches(e))return a;const l=a.querySelector(e);if(l!==null)return l}return null}get innerHTML(){return""}set innerHTML(e){const a=this.parentElement;a?(this.childNodes.forEach(l=>this.removeChild(l)),this.$template$.innerHTML=e,a.insertBefore(this.$template$.content,this.close)):this.$template$.innerHTML=e}get firstChild(){if(this.parentElement){const e=this.open.nextSibling;return e===this.close?null:e}return this.$template$.firstChild}get nextSibling(){return this.close.nextSibling}get previousSibling(){return this.open.previousSibling}get childNodes(){if(!this.parentElement)return Array.from(this.$template$.childNodes);const e=[];let a=this.open;for(;(a=a.nextSibling)&&a!==this.close;)e.push(a);return e}get isConnected(){return this.open.isConnected}get parentElement(){return this.open.parentElement}}const Jn=t=>`qv ${fu(t)}`,Cl=t=>{if(t==null)return null;if(Fe(t)){const e=Ye(t);if(e)return e}return t},$u=t=>{let e=t,a=1;for(;e=e.nextSibling;)if(Fe(e)){const l=e.__virtual;if(l)e=l;else if(e.data.startsWith("qv "))a++;else if(e.data==="/qv"&&(a--,a===0))return e}},Ye=t=>{var a;const e=t.__virtual;if(e)return e;if(t.data.startsWith("qv ")){const l=$u(t);return new or(t,l,((a=t.parentElement)==null?void 0:a.namespaceURI)===Ue)}return null},pa=t=>t==null?null:Et(t)?t.open:t,ly=async t=>{const e=nl(null,null),a=ur(e);let l;for(U(t,a,!1);(l=a.$promises$).length>0;)a.$promises$=[],await Promise.all(l);const r=Array.from(a.$objSet$.keys());let o=0;const c=new Map;for(const f of r)c.set(f,Ht(o)),o++;if(a.$noSerialize$.length>0){const f=c.get(void 0);for(const h of a.$noSerialize$)c.set(h,f)}const d=f=>{let h="";if(rt(f)){const b=cr(f);if(!b)throw nt(27,f);f=b.value,h+=b.resolved?"~":"_"}if(Bt(f)){const b=ie(f);b&&(h+="!",f=b)}const y=c.get(f);if(y===void 0)throw nt(27,f);return y+h},p=pr(r,d,null,a,e);return JSON.stringify({_entry:d(t),_objs:p})},bu=async(t,e)=>{const a=Ge(t),l=a.documentElement,r=gs(t)?l:t;if(Lt(r,"q:container")==="paused")throw nt(21);const o=r===a.documentElement?a.body:r,c=ye(r),d=vu(r,ku);mt(r,"q:container","paused");for(const b of d){const w=b.$element$,D=b.li;if(b.$scopeIds$){const L=ws(b.$scopeIds$);L&&w.setAttribute("q:sstyle",L)}if(b.$id$&&w.setAttribute("q:id",b.$id$),Xt(w)&&D.length>0){const L=il(D);for(const v of L)w.setAttribute(v[0],El(v[1],c,b))}}const p=await yu(d,c,b=>Zt(b)&&Ka(b)?Mu(b,c):null),f=a.createElement("script");mt(f,"type","qwik/json"),f.textContent=Tu(JSON.stringify(p.state,void 0,void 0)),o.appendChild(f);const h=Array.from(c.$events$,b=>JSON.stringify(b)),y=a.createElement("script");return y.textContent=`window.qwikevents||=[];window.qwikevents.push(${h.join(", ")})`,o.appendChild(y),p},yu=async(t,e,a,l)=>{var k;const r=ur(e);l==null||l.forEach((T,E)=>{r.$seen$.add(E)});let o=!1;for(const T of t)if(T.$tasks$)for(const E of T.$tasks$)zs(E)&&r.$resources$.push(E.$state$),Qs(E);for(const T of t){const E=T.$element$,B=T.li;for(const R of B)if(Xt(E)){const j=R[1],H=j.$captureRef$;if(H)for(const J of H)U(J,r,!0);r.$qrls$.push(j),o=!0}}if(!o)return{state:{refs:{},ctx:{},objs:[],subs:[]},objs:[],funcs:[],qrls:[],resources:r.$resources$,mode:"static"};let c;for(;(c=r.$promises$).length>0;)r.$promises$=[],await Promise.all(c);const d=r.$elements$.length>0;if(d){for(const T of r.$deferElements$)Ml(T,r,T.$element$);for(const T of t)wu(T,r)}for(;(c=r.$promises$).length>0;)r.$promises$=[],await Promise.all(c);const p=new Map,f=Array.from(r.$objSet$.keys()),h=new Map,y=T=>{let E="";if(rt(T)){const j=cr(T);if(!j)return null;T=j.value,E+=j.resolved?"~":"_"}if(Bt(T)){const j=ie(T);if(j)E+="!",T=j;else if(Kt(T)){const H=(J=>{let tt=p.get(J);return tt===void 0&&(tt=Cu(J),tt||console.warn("Missing ID",J),p.set(J,tt)),tt})(T);return H?"#"+H+E:null}}const B=h.get(T);if(B)return B+E;const R=l==null?void 0:l.get(T);return R?"*"+R:a?a(T):null},b=T=>{const E=y(T);if(E===null){if(Ol(T)){const B=Ht(h.size);return h.set(T,B),B}throw nt(27,T)}return E},w=new Map;for(const T of f){const E=(k=Lu(T,e))==null?void 0:k.$subs$;if(!E)continue;const B=br(T)??0,R=[];1&B&&R.push(B);for(const j of E){const H=j[1];j[0]===0&&Zt(H)&&Et(H)&&!r.$elements$.includes(bt(H))||R.push(j)}R.length>0&&w.set(T,R)}f.sort((T,E)=>(w.has(T)?0:1)-(w.has(E)?0:1));let D=0;for(const T of f)h.set(T,Ht(D)),D++;if(r.$noSerialize$.length>0){const T=h.get(void 0);for(const E of r.$noSerialize$)h.set(E,T)}const L=[];for(const T of f){const E=w.get(T);if(E==null)break;L.push(E.map(B=>typeof B=="number"?`_${B}`:pc(B,y)).filter(ms))}L.length,w.size;const v=pr(f,b,y,r,e),S={},M={};for(const T of t){const E=T.$element$,B=T.$id$,R=T.$refMap$,j=T.$props$,H=T.$contexts$,J=T.$tasks$,tt=T.$componentQrl$,et=T.$seq$,It={},ue=Et(E)&&r.$elements$.includes(T);if(R.length>0){const ft=ee(R,b," ");ft&&(M[B]=ft)}else if(d){let ft=!1;if(ue){const st=y(j);It.h=b(tt)+(st?" "+st:""),ft=!0}else{const st=y(j);st&&(It.h=" "+st,ft=!0)}if(J&&J.length>0){const st=ee(J,y," ");st&&(It.w=st,ft=!0)}if(ue&&et&&et.length>0){const st=ee(et,b," ");It.s=st,ft=!0}if(H){const st=[];H.forEach((ii,oi)=>{const Rn=y(ii);Rn&&st.push(`${oi}=${Rn}`)});const Se=st.join(" ");Se&&(It.c=Se,ft=!0)}ft&&(S[B]=It)}}return{state:{refs:M,ctx:S,objs:v,subs:L},objs:f,funcs:r.$inlinedFunctions$,resources:r.$resources$,qrls:r.$qrls$,mode:d?"render":"listeners"}},ee=(t,e,a)=>{let l="";for(const r of t){const o=e(r);o!==null&&(l!==""&&(l+=a),l+=o)}return l},vu=(t,e)=>{const a=[],l=e(t);l!==void 0&&a.push(l);const r=t.ownerDocument.createTreeWalker(t,129,{acceptNode(o){if(Pu(o))return 2;const c=e(o);return c!==void 0&&a.push(c),3}});for(;r.nextNode(););return a},wu=(t,e)=>{var r;const a=t.$realParentCtx$||t.$parentCtx$,l=t.$props$;if(a&&l&&!dr(l)&&e.$elements$.includes(a)){const o=(r=ut(l))==null?void 0:r.$subs$,c=t.$element$;if(o)for(const[d,p]of o)d===0?(p!==c&&$e(ut(l),e,!1),Zt(p)?Su(p,e):U(p,e,!0)):(U(l,e,!1),$e(ut(l),e,!1))}},ur=t=>{const e=[];return t.$inlineFns$.forEach((a,l)=>{for(;e.length<=a;)e.push("");e[a]=l}),{$containerState$:t,$seen$:new Set,$objSet$:new Set,$prefetch$:0,$noSerialize$:[],$inlinedFunctions$:e,$resources$:[],$elements$:[],$qrls$:[],$deferElements$:[],$promises$:[]}},_u=(t,e)=>{const a=bt(t);e.$elements$.includes(a)||(e.$elements$.push(a),a.$flags$&_l?(e.$prefetch$++,Ml(a,e,!0),e.$prefetch$--):e.$deferElements$.push(a))},Su=(t,e)=>{const a=bt(t);if(a){if(e.$elements$.includes(a))return;e.$elements$.push(a),Ml(a,e,t)}},Ml=(t,e,a)=>{if(t.$props$&&!dr(t.$props$)&&(U(t.$props$,e,a),$e(ut(t.$props$),e,a)),t.$componentQrl$&&U(t.$componentQrl$,e,a),t.$seq$)for(const l of t.$seq$)U(l,e,a);if(t.$tasks$){const l=e.$containerState$.$subsManager$.$groupToManagers$;for(const r of t.$tasks$)l.has(r)&&U(r,e,a)}if(a===!0&&(ts(t,e),t.$dynamicSlots$))for(const l of t.$dynamicSlots$)ts(l,e)},ts=(t,e)=>{for(;t;){if(t.$contexts$)for(const a of t.$contexts$.values())U(a,e,!0);t=t.$parentCtx$}},Tu=t=>t.replace(/<(\/?script)/gi,"\\x3C$1"),$e=(t,e,a)=>{if(e.$seen$.has(t))return;e.$seen$.add(t);const l=t.$subs$;for(const r of l)if(r[0]>0&&U(r[2],e,a),a===!0){const o=r[1];Zt(o)&&Et(o)?r[0]===0&&_u(o,e):U(o,e,!0)}},Ua=Symbol(),Du=t=>t.then(e=>(t[Ua]={resolved:!0,value:e},e),e=>(t[Ua]={resolved:!1,value:e},e)),cr=t=>t[Ua],U=(t,e,a)=>{if(t!=null){const l=typeof t;switch(l){case"function":case"object":{if(e.$seen$.has(t))return;if(e.$seen$.add(t),hr(t))return e.$objSet$.add(void 0),void e.$noSerialize$.push(t);const r=t,o=ie(t);if(o){const c=(2&br(t=o))==0;if(a&&c&&$e(ut(r),e,a),$r(r))return void e.$objSet$.add(t)}if(sc(t,e,a))return void e.$objSet$.add(t);if(rt(t))return void e.$promises$.push(Du(t).then(c=>{U(c,e,a)}));if(l==="object"){if(Zt(t))return;if(at(t))for(let c=0;c<t.length;c++)U(r[c],e,a);else if(ze(t))for(const c in t)U(r[c],e,a)}break}}}e.$objSet$.add(t)},Pu=t=>Xt(t)&&t.hasAttribute("q:container"),ku=t=>{const e=Cl(t);if(Kt(e)){const a=bt(e);if(a&&a.$id$)return a}},Lu=(t,e)=>{if(!Bt(t))return;if(t instanceof Me)return ut(t);const a=e.$proxyMap$.get(t);return a?ut(a):void 0},Cu=t=>{const e=bt(t);return e?e.$id$:null},Mu=(t,e)=>{const a=t.previousSibling;if(a&&Fe(a)&&a.data.startsWith("t="))return"#"+a.data.slice(2);const l=t.ownerDocument,r=Ht(e.$elementIndex$++),o=l.createComment(`t=${r}`),c=l.createComment(""),d=t.parentElement;return d.insertBefore(o,t),d.insertBefore(c,t.nextSibling),"#"+r},dr=t=>Object.keys(t).length===0;function pr(t,e,a,l,r){return t.map(o=>{if(o===null)return null;const c=typeof o;switch(c){case"undefined":return La;case"number":if(!Number.isFinite(o))break;return o;case"string":if(o.charCodeAt(0)<32)break;return o;case"boolean":return o}const d=rc(o,e,l,r);if(d!==void 0)return d;if(c==="object"){if(at(o))return o.map(e);if(ze(o)){const p={};for(const f in o)if(a){const h=a(o[f]);h!==null&&(p[f]=h)}else p[f]=e(o[f]);return p}}throw nt(3,o)})}const g=(t,e,a=Mt)=>Ze(null,e,t,null,null,a,null),I=(t,e=Mt)=>Ze(null,t,null,null,null,e,null),jl=(t,e={})=>{let a=t.$symbol$,l=t.$chunk$;const r=t.$refSymbol$??a,o=$a();if(o){const f=o.chunkForSymbol(r,l);f&&(l=f[1],t.$refSymbol$||(a=f[0]))}if(l==null)throw nt(31,t.$symbol$);if(l.startsWith("./")&&(l=l.slice(2)),hc(t))if(e.$containerState$){const f=e.$containerState$,h=t.resolved.toString();let y=f.$inlineFns$.get(h);y===void 0&&(y=f.$inlineFns$.size,f.$inlineFns$.set(h,y)),a=String(y)}else xs("Sync QRL without containerState");let c=`${l}#${a}`;const d=t.$capture$,p=t.$captureRef$;return p&&p.length?e.$getObjId$?c+=`[${ee(p,e.$getObjId$," ")}]`:e.$addRefMap$&&(c+=`[${ee(p,e.$addRefMap$," ")}]`):d&&d.length>0&&(c+=`[${d.join(" ")}]`),c},El=(t,e,a)=>{a.$element$;const l={$containerState$:e,$addRefMap$:r=>ju(a.$refMap$,r)};return ee(t,r=>jl(r,l),`
`)},ka=(t,e)=>{const a=t.length,l=es(t,0,"#"),r=es(t,l,"["),o=Math.min(l,r),c=t.substring(0,o),d=l==a?l:l+1,p=d==r?"default":t.substring(d,r),f=r===a?Mt:t.substring(r+1,a-1).split(" "),h=Ze(c,p,null,null,f,null,null);return e&&h.$setContainer$(e),h},es=(t,e,a)=>{const l=t.length,r=t.indexOf(a,e==l?0:e);return r==-1?l:r},ju=(t,e)=>{const a=t.indexOf(e);return a===-1?(t.push(e),String(t.length-1)):String(a)},fr=(t,e)=>(t.$capture$,t.$captureRef$=t.$capture$.map(a=>{const l=parseInt(a,10),r=e.$refMap$[l];return e.$refMap$.length>l,r})),Bl=(t,e)=>(globalThis.__qwik_reg_symbols===void 0&&(globalThis.__qwik_reg_symbols=new Map),globalThis.__qwik_reg_symbols.set(e,t),t),Eu=t=>({__brand:"resource",value:void 0,loading:!At(),_resolved:void 0,_error:void 0,_state:"pending",_timeout:(t==null?void 0:t.timeout)??-1,_cache:0}),Bu=t=>Bt(t)&&t.__brand==="resource",Iu=(t,e)=>{const a=t._state;return a==="resolved"?`0 ${e(t._resolved)}`:a==="pending"?"1":`2 ${e(t._error)}`},Ou=t=>{const[e,a]=t.split(" "),l=Eu(void 0);return l.value=Promise.resolve(),e==="0"?(l._state="resolved",l._resolved=a,l.loading=!1):e==="1"?(l._state="pending",l.value=new Promise(()=>{}),l.loading=!0):e==="2"&&(l._state="rejected",l._error=a,l.loading=!1),l},it=t=>i(Wt,{"q:s":""},0,t.name??""),La="";function lt(t){return{$prefixCode$:t.$prefix$.charCodeAt(0),$prefixChar$:t.$prefix$,$test$:t.$test$,$serialize$:t.$serialize$,$prepare$:t.$prepare$,$fill$:t.$fill$,$collect$:t.$collect$,$subs$:t.$subs$}}const Au=lt({$prefix$:"",$test$:t=>Ol(t),$collect$:(t,e,a)=>{if(t.$captureRef$)for(const l of t.$captureRef$)U(l,e,a);e.$prefetch$===0&&e.$qrls$.push(t)},$serialize$:(t,e)=>jl(t,{$getObjId$:e}),$prepare$:(t,e)=>ka(t,e.$containerEl$),$fill$:(t,e)=>{t.$capture$&&t.$capture$.length>0&&(t.$captureRef$=t.$capture$.map(e),t.$capture$=null)}}),Nu=lt({$prefix$:"",$test$:t=>vl(t),$collect$:(t,e,a)=>{U(t.$qrl$,e,a),t.$state$&&(U(t.$state$,e,a),a===!0&&t.$state$ instanceof Me&&$e(t.$state$[jt],e,!0))},$serialize$:(t,e)=>wo(t,e),$prepare$:t=>_o(t),$fill$:(t,e)=>{t.$el$=e(t.$el$),t.$qrl$=e(t.$qrl$),t.$state$&&(t.$state$=e(t.$state$))}}),Ru=lt({$prefix$:"",$test$:t=>Bu(t),$collect$:(t,e,a)=>{U(t.value,e,a),U(t._resolved,e,a)},$serialize$:(t,e)=>Iu(t,e),$prepare$:t=>Ou(t),$fill$:(t,e)=>{if(t._state==="resolved")t._resolved=e(t._resolved),t.value=Promise.resolve(t._resolved);else if(t._state==="rejected"){const a=Promise.reject(t._error);a.catch(()=>null),t._error=e(t._error),t.value=a}}}),qu=lt({$prefix$:"",$test$:t=>t instanceof URL,$serialize$:t=>t.href,$prepare$:t=>new URL(t)}),Fu=lt({$prefix$:"",$test$:t=>t instanceof Date,$serialize$:t=>t.toISOString(),$prepare$:t=>new Date(t)}),zu=lt({$prefix$:"\x07",$test$:t=>t instanceof RegExp,$serialize$:t=>`${t.flags} ${t.source}`,$prepare$:t=>{const e=t.indexOf(" "),a=t.slice(e+1),l=t.slice(0,e);return new RegExp(a,l)}}),Gu=lt({$prefix$:"",$test$:t=>t instanceof Error,$serialize$:t=>t.message,$prepare$:t=>{const e=new Error(t);return e.stack=void 0,e}}),Qu=lt({$prefix$:"",$test$:t=>!!t&&typeof t=="object"&&gs(t),$prepare$:(t,e,a)=>a}),fa=Symbol("serializable-data"),Hu=lt({$prefix$:"",$test$:t=>wr(t),$serialize$:(t,e)=>{const[a]=t[fa];return jl(a,{$getObjId$:e})},$prepare$:(t,e)=>{const a=ka(t,e.$containerEl$);return m(a)},$fill$:(t,e)=>{var l;const[a]=t[fa];(l=a.$capture$)!=null&&l.length&&(a.$captureRef$=a.$capture$.map(e),a.$capture$=null)}}),Wu=lt({$prefix$:"",$test$:t=>t instanceof Na,$collect$:(t,e,a)=>{if(t.$args$)for(const l of t.$args$)U(l,e,a)},$serialize$:(t,e,a)=>{const l=Ti(t);let r=a.$inlinedFunctions$.indexOf(l);return r<0&&(r=a.$inlinedFunctions$.length,a.$inlinedFunctions$.push(l)),ee(t.$args$,e," ")+" @"+Ht(r)},$prepare$:t=>{const e=t.split(" "),a=e.slice(0,-1),l=e[e.length-1];return new Na(l,a,l)},$fill$:(t,e)=>{t.$func$,t.$func$=e(t.$func$),t.$args$=t.$args$.map(e)}}),Uu=lt({$prefix$:"",$test$:t=>t instanceof Me,$collect$:(t,e,a)=>(U(t.untrackedValue,e,a),a===!0&&!(1&t[Ce])&&$e(t[jt],e,!0),t),$serialize$:(t,e)=>e(t.untrackedValue),$prepare$:(t,e)=>{var a;return new Me(t,(a=e==null?void 0:e.$subsManager$)==null?void 0:a.$createManager$(),0)},$subs$:(t,e)=>{t[jt].$addSubs$(e)},$fill$:(t,e)=>{t.untrackedValue=e(t.untrackedValue)}}),Yu=lt({$prefix$:"",$test$:t=>t instanceof Ra,$collect$(t,e,a){if(U(t.ref,e,a),$r(t.ref)){const l=ut(t.ref);oc(e.$containerState$.$subsManager$,l,a)&&U(t.ref[t.prop],e,a)}return t},$serialize$:(t,e)=>`${e(t.ref)} ${t.prop}`,$prepare$:t=>{const[e,a]=t.split(" ");return new Ra(e,a)},$fill$:(t,e)=>{t.ref=e(t.ref)}}),Vu=lt({$prefix$:"",$test$:t=>typeof t=="number",$serialize$:t=>String(t),$prepare$:t=>Number(t)}),Zu=lt({$prefix$:"",$test$:t=>t instanceof URLSearchParams,$serialize$:t=>t.toString(),$prepare$:t=>new URLSearchParams(t)}),Xu=lt({$prefix$:"",$test$:t=>typeof FormData<"u"&&t instanceof globalThis.FormData,$serialize$:t=>{const e=[];return t.forEach((a,l)=>{e.push(typeof a=="string"?[l,a]:[l,a.name])}),JSON.stringify(e)},$prepare$:t=>{const e=JSON.parse(t),a=new FormData;for(const[l,r]of e)a.append(l,r);return a}}),Ku=lt({$prefix$:"",$test$:t=>se(t),$collect$:(t,e,a)=>{U(t.children,e,a),U(t.props,e,a),U(t.immutableProps,e,a),U(t.key,e,a);let l=t.type;l===it?l=":slot":l===Q&&(l=":fragment"),U(l,e,a)},$serialize$:(t,e)=>{let a=t.type;return a===it?a=":slot":a===Q&&(a=":fragment"),`${e(a)} ${e(t.props)} ${e(t.immutableProps)} ${e(t.key)} ${e(t.children)} ${t.flags}`},$prepare$:t=>{const[e,a,l,r,o,c]=t.split(" ");return new ve(e,a,l,o,parseInt(c,10),r)},$fill$:(t,e)=>{t.type=uc(e(t.type)),t.props=e(t.props),t.immutableProps=e(t.immutableProps),t.key=e(t.key),t.children=e(t.children)}}),Ju=lt({$prefix$:"",$test$:t=>typeof t=="bigint",$serialize$:t=>t.toString(),$prepare$:t=>BigInt(t)}),xe=Symbol(),tc=lt({$prefix$:"",$test$:t=>t instanceof Set,$collect$:(t,e,a)=>{t.forEach(l=>U(l,e,a))},$serialize$:(t,e)=>Array.from(t).map(e).join(" "),$prepare$:t=>{const e=new Set;return e[xe]=t,e},$fill$:(t,e)=>{const a=t[xe];t[xe]=void 0;const l=a.length===0?[]:a.split(" ");for(const r of l)t.add(e(r))}}),ec=lt({$prefix$:"",$test$:t=>t instanceof Map,$collect$:(t,e,a)=>{t.forEach((l,r)=>{U(l,e,a),U(r,e,a)})},$serialize$:(t,e)=>{const a=[];return t.forEach((l,r)=>{a.push(e(r)+" "+e(l))}),a.join(" ")},$prepare$:t=>{const e=new Map;return e[xe]=t,e},$fill$:(t,e)=>{const a=t[xe];t[xe]=void 0;const l=a.length===0?[]:a.split(" ");l.length%2;for(let r=0;r<l.length;r+=2)t.set(e(l[r]),e(l[r+1]))}}),ac=lt({$prefix$:"\x1B",$test$:t=>!!gr(t)||t===La,$serialize$:t=>t,$prepare$:t=>t}),Ca=[Au,Nu,Ru,qu,Fu,zu,Gu,Qu,Hu,Wu,Uu,Yu,Vu,Zu,Xu,Ku,Ju,tc,ec,ac],as=(()=>{const t=[];return Ca.forEach(e=>{const a=e.$prefixCode$;for(;t.length<a;)t.push(void 0);t.push(e)}),t})();function gr(t){if(typeof t=="string"){const e=t.charCodeAt(0);if(e<as.length)return as[e]}}const lc=Ca.filter(t=>t.$collect$),nc=t=>{for(const e of Ca)if(e.$test$(t))return!0;return!1},sc=(t,e,a)=>{for(const l of lc)if(l.$test$(t))return l.$collect$(t,e,a),!0;return!1},rc=(t,e,a,l)=>{for(const r of Ca)if(r.$test$(t)){let o=r.$prefixChar$;return r.$serialize$&&(o+=r.$serialize$(t,e,a,l)),o}if(typeof t=="string")return t},xr=(t,e)=>{const a=new Map,l=new Map;return{prepare(r){const o=gr(r);if(o){const c=o.$prepare$(r.slice(1),t,e);return o.$fill$&&a.set(c,o),o.$subs$&&l.set(c,o),c}return r},subs(r,o){const c=l.get(r);return!!c&&(c.$subs$(r,o,t),!0)},fill(r,o){const c=a.get(r);return!!c&&(c.$fill$(r,o,t),!0)}}},ic={"!":(t,e)=>e.$proxyMap$.get(t)??dl(t,e),"~":t=>Promise.resolve(t),_:t=>Promise.reject(t)},oc=(t,e,a)=>{if(typeof a=="boolean")return a;const l=t.$groupToManagers$.get(a);return!!(l&&l.length>0)&&(l.length!==1||l[0]!==e)},uc=t=>t===":slot"?it:t===":fragment"?Q:t,ny=(t,e)=>Ya(t,new Set,"_",e),Ya=(t,e,a,l)=>{const r=Ve(t);if(r==null)return t;if(cc(r)){if(e.has(r)||(e.add(r),nc(r)))return t;const o=typeof r;switch(o){case"object":if(rt(r)||Zt(r))return t;if(at(r)){let d=0;return r.forEach((p,f)=>{if(f!==d)throw nt(3,r);Ya(p,e,a+"["+f+"]"),d=f+1}),t}if(ze(r)){for(const[d,p]of Object.entries(r))Ya(p,e,a+"."+d);return t}break;case"boolean":case"string":case"number":return t}let c="";if(c=l||"Value cannot be serialized",a!=="_"&&(c+=` in ${a},`),o==="object")c+=` because it's an instance of "${t==null?void 0:t.constructor.name}". You might need to use 'noSerialize()' or use an object literal instead. Check out https://qwik.builder.io/docs/advanced/dollar/`;else if(o==="function"){const d=t.name;c+=` because it's a function named "${d}". You might need to convert it to a QRL using $(fn):

const ${d} = $(${String(t)});

Please check out https://qwik.builder.io/docs/advanced/qrl/ for more information.`}console.error("Trying to serialize",t),xs(c)}return t},Il=new WeakSet,mr=new WeakSet,cc=t=>!Bt(t)&&!ht(t)||!Il.has(t),hr=t=>Il.has(t),$r=t=>mr.has(t),Ma=t=>(t!=null&&Il.add(t),t),dc=t=>(mr.add(t),t),Ve=t=>Bt(t)?ie(t)??t:t,ie=t=>t[Oa],ut=t=>t[jt],br=t=>t[de],pc=(t,e)=>{const a=t[0],l=typeof t[1]=="string"?t[1]:e(t[1]);if(!l)return;let r=a+" "+l,o;if(a===0)o=t[2];else{const c=e(t[2]);if(!c)return;a<=2?(o=t[5],r+=` ${c} ${ls(e(t[3]))} ${t[4]}`):a<=4&&(o=t[4],r+=` ${c} ${typeof t[3]=="string"?t[3]:ls(e(t[3]))}`)}return o&&(r+=` ${encodeURI(o)}`),r},fc=(t,e)=>{const a=t.split(" "),l=parseInt(a[0],10);a.length>=2;const r=e(a[1]);if(!r||vl(r)&&!r.$el$)return;const o=[l,r];return l===0?(a.length<=3,o.push(Ia(a[2]))):l<=2?(a.length===5||a.length,o.push(e(a[2]),e(a[3]),a[4],Ia(a[5]))):l<=4&&(a.length===4||a.length,o.push(e(a[2]),e(a[3]),Ia(a[4]))),o},Ia=t=>{if(t!==void 0)return decodeURI(t)},gc=t=>{const e=new Map;return{$groupToManagers$:e,$createManager$:l=>new xc(e,t,l),$clearSub$:l=>{const r=e.get(l);if(r){for(const o of r)o.$unsubGroup$(l);e.delete(l),r.length=0}},$clearSignal$:l=>{const r=e.get(l[1]);if(r)for(const o of r)o.$unsubEntry$(l)}}};class xc{constructor(e,a,l){this.$groupToManagers$=e,this.$containerState$=a,this.$subs$=[],l&&this.$addSubs$(l)}$addSubs$(e){this.$subs$.push(...e);for(const a of this.$subs$)this.$addToGroup$(a[1],this)}$addToGroup$(e,a){let l=this.$groupToManagers$.get(e);l||this.$groupToManagers$.set(e,l=[]),l.includes(a)||l.push(a)}$unsubGroup$(e){const a=this.$subs$;for(let l=0;l<a.length;l++)a[l][1]===e&&(a.splice(l,1),l--)}$unsubEntry$(e){const[a,l,r,o]=e,c=this.$subs$;if(a===1||a===2){const d=e[4];for(let p=0;p<c.length;p++){const f=c[p];f[0]===a&&f[1]===l&&f[2]===r&&f[3]===o&&f[4]===d&&(c.splice(p,1),p--)}}else if(a===3||a===4)for(let d=0;d<c.length;d++){const p=c[d];p[0]===a&&p[1]===l&&p[2]===r&&p[3]===o&&(c.splice(d,1),d--)}}$addSub$(e,a){const l=this.$subs$,r=e[1];e[0]===0&&l.some(([o,c,d])=>o===0&&c===r&&d===a)||(l.push(yr=[...e,a]),this.$addToGroup$(r,this))}$notifySubs$(e){const a=this.$subs$;for(const l of a){const r=l[l.length-1];e&&r&&r!==e||io(l,this.$containerState$)}}}let yr;function mc(){return yr}const ls=t=>{if(t==null)throw ae("must be non null",t);return t},Ol=t=>typeof t=="function"&&typeof t.getSymbol=="function",hc=t=>Ol(t)&&t.$symbol$=="<sync>",Ze=(t,e,a,l,r,o,c)=>{let d;const p=async function(...v){return await b.call(this,Tt())(...v)},f=v=>(d||(d=v),d),h=async v=>{if(v&&f(v),t==""&&(a=(d.qFuncs||[])[Number(e)]),a!==null)return a;{const S=$a().importSymbol(d,t,e);return a=V(S,M=>p.resolved=a=M)}},y=v=>a!==null?a:h(v);function b(v,S){return(...M)=>{const k=yc(),T=y();return V(T,E=>{if(ht(E)){if(S&&S()===!1)return;const B={...w(v),$qrl$:p};return B.$event$===void 0&&(B.$event$=this),$c(e,B.$element$,k),pt.call(this,B,E,...M)}throw nt(10)})}}const w=v=>v==null?Dt():at(v)?Ws(v):v,D=c??e,L=vr(D);return Object.assign(p,{getSymbol:()=>D,getHash:()=>L,getCaptured:()=>o,resolve:h,$resolveLazy$:y,$setContainer$:f,$chunk$:t,$symbol$:e,$refSymbol$:c,$hash$:L,getFn:b,$capture$:r,$captureRef$:o,dev:null,resolved:e=="<sync>"?a:void 0}),p},vr=t=>{const e=t.lastIndexOf("_");return e>-1?t.slice(e+1):t};const ns=new Set,$c=(t,e,a)=>{ns.has(t)||(ns.add(t),bc("qsymbol",{symbol:t,element:e,reqTime:a}))},bc=(t,e)=>{At()||typeof document!="object"||document.dispatchEvent(new CustomEvent(t,{bubbles:!1,detail:e}))},yc=()=>At()?0:typeof performance=="object"?performance.now():0,vc=function(t,e){return Ze("","<sync>",t,null,null,null,null)},m=t=>{function e(a,l,r){const o=t.$hash$.slice(0,4);return i(Wt,{"q:renderFn":t,[$t]:a[$t],[s]:a[s],children:a.children,props:a},r,o+":"+(l||""))}return e[fa]=[t],e},wr=t=>typeof t=="function"&&t[fa]!==void 0,Jt=(t,e)=>{const{val:a,set:l,iCtx:r}=re();if(a!=null)return a;const o=ht(t)?pt(void 0,t):t;if((e==null?void 0:e.reactive)===!1)return l(o),o;{const c=dl(o,r.$renderCtx$.$static$.$containerState$,(e==null?void 0:e.deep)??!0?1:0);return l(c),c}};function Al(t,e){var l;const a=Tt();return((l=a==null?void 0:a.$renderCtx$)==null?void 0:l.$static$.$containerState$.$serverData$[t])??e}const wc=t=>{_c(t,e=>e)},_c=(t,e,a)=>{const{val:l,set:r,iCtx:o,i:c,elCtx:d}=re();if(l)return l;const p=Mi(t,c),f=o.$renderCtx$.$static$.$containerState$;if(r(p),d.$appendStyles$||(d.$appendStyles$=[]),d.$scopeIds$||(d.$scopeIds$=[]),f.$styleIds$.has(p))return p;f.$styleIds$.add(p);const h=t.$resolveLazy$(f.$containerEl$),y=b=>{d.$appendStyles$,d.$appendStyles$.push({styleId:p,content:e(b,p)})};return rt(h)?o.$waitOn$.push(h.then(y)):y(h),p},O=t=>{const{val:e,set:a,iCtx:l}=re();if(e!=null)return e;const r=l.$renderCtx$.$static$.$containerState$,o=ht(t)&&!wr(t)?pt(void 0,t):t;return a(Di(o,r,0,void 0))},ss={defaultLocale:{lang:"en",currency:"USD",timeZone:"America/Los_Angeles"},supportedLocales:[{lang:"en",currency:"USD",timeZone:"America/Los_Angeles"},{lang:"es",currency:"USD",timeZone:"America/Los_Angeles"}],assets:["app"]},Sc=({params:t,locale:e})=>{const a=ss.supportedLocales.find(r=>r.lang===t.lang);console.log(t);const l=a?a.lang:!t.lang&&ss.defaultLocale.lang;l&&e(l)},Tc=Object.freeze(Object.defineProperty({__proto__:null,onRequest:Sc},Symbol.toStringTag,{value:"Module"})),Dc='((i,a,r,s)=>{r=e=>{const t=document.querySelector("[q\\\\:base]");t&&a.active&&a.active.postMessage({type:"qprefetch",base:t.getAttribute("q:base"),...e})},document.addEventListener("qprefetch",e=>{const t=e.detail;a?r(t):i.push(t)}),navigator.serviceWorker.register("/service-worker.js").then(e=>{s=()=>{a=e,i.forEach(r),r({bundles:i})},e.installing?e.installing.addEventListener("statechange",t=>{t.target.state=="activated"&&s()}):e.active&&s()}).catch(e=>console.error(e))})([])',_r=Rt("qc-s"),Pc=Rt("qc-c"),Sr=Rt("qc-ic"),Tr=Rt("qc-h"),Dr=Rt("qc-l"),Pr=Rt("qc-n"),kr=Rt("qc-a"),kc=Rt("qc-ir"),Lc=t=>{const e=window,a=location.pathname+location.search,l="_qCitySPA",r="_qCityHistoryPatch",o="_qCityBootstrap",c="_qCityInitPopstate",d="_qCityInitAnchors",p="_qCityInitVisibility",f="_qCityInitScroll",h="_qCityScrollEnabled",y="_qCityScrollDebounce",b="_qCityScroll",w=v=>{v&&e.scrollTo(v.x,v.y)},D=()=>{const v=document.documentElement;return{x:v.scrollLeft,y:v.scrollTop,w:Math.max(v.scrollWidth,v.clientWidth),h:Math.max(v.scrollHeight,v.clientHeight)}},L=v=>{const S=history.state||{};S[b]=v||D(),history.replaceState(S,"")};if(!e[l]&&!e[c]&&!e[d]&&!e[p]&&!e[f]){if(L(),e[c]=()=>{var v;if(!e[l]){if(e[h]=!1,clearTimeout(e[y]),a!==location.pathname+location.search){const M=t.closest("[q\\:container]").querySelector('a[q\\:key="AD_1"]');if(M){const k=M.closest("[q\\:container]"),T=M.cloneNode();T.setAttribute("q:nbs",""),T.style.display="none",k.appendChild(T),e[o]=T,T.click()}else location.reload()}else if(history.scrollRestoration==="manual"){const S=(v=history.state)==null?void 0:v[b];w(S),e[h]=!0}}},!e[r]){e[r]=!0;const v=history.pushState,S=history.replaceState,M=k=>(k===null||typeof k>"u"?k={}:(k==null?void 0:k.constructor)!==Object&&(k={_data:k}),k._qCityScroll=k._qCityScroll||D(),k);history.pushState=(k,T,E)=>(k=M(k),v.call(history,k,T,E)),history.replaceState=(k,T,E)=>(k=M(k),S.call(history,k,T,E))}e[d]=v=>{if(e[l]||v.defaultPrevented)return;const S=v.target.closest("a[href]");if(S&&!S.hasAttribute("preventdefault:click")){const M=S.getAttribute("href"),k=new URL(location.href),T=new URL(M,k),E=T.origin===k.origin,B=T.pathname+T.search===k.pathname+k.search;if(E&&B)if(v.preventDefault(),T.href!==k.href&&history.pushState(null,"",T),!T.hash)T.href.endsWith("#")?window.scrollTo(0,0):(e[h]=!1,clearTimeout(e[y]),L({...D(),x:0,y:0}),location.reload());else{const R=T.hash.slice(1),j=document.getElementById(R);j&&j.scrollIntoView()}}},e[p]=()=>{!e[l]&&e[h]&&document.visibilityState==="hidden"&&L()},e[f]=()=>{e[l]||!e[h]||(clearTimeout(e[y]),e[y]=setTimeout(()=>{L(),e[y]=void 0},200))},e[h]=!0,setTimeout(()=>{addEventListener("popstate",e[c]),addEventListener("scroll",e[f],{passive:!0}),document.body.addEventListener("click",e[d]),e.navigation||document.addEventListener("visibilitychange",e[p],{passive:!0})},0)}},Cc=g(Lc,"s_DyVc0YBIqQU"),Mc=()=>{{const[t,e]=$a().chunkForSymbol(Cc.getSymbol(),null),a=ri+"build/"+e;return`(${jc.toString()})('${a}','${t}');`}},jc=async(t,e)=>{var a;if(!window._qcs&&history.scrollRestoration==="manual"){window._qcs=!0;const l=(a=history.state)==null?void 0:a._qCityScroll;l&&window.scrollTo(l.x,l.y);const r=document.currentScript;(await import(t))[e](r)}},Ec=()=>{const t=Mc();W();const e=Al("nonce"),a=we(Sr);if(a.value&&a.value.length>0){const l=a.value.length;let r=null;for(let o=l-1;o>=0;o--)a.value[o].default&&(r=i(a.value[o].default,{children:r},1,"zl_0"));return i(Q,{children:[r,n("script",{dangerouslySetInnerHTML:t},{nonce:e},null,3,null)]},1,"zl_1")}return gl},sy=m(g(Ec,"s_e0ssiDXoeAM")),Je=new Map,Lr="qaction",rs=t=>t.pathname+t.search+t.hash,zt=(t,e)=>new URL(t,e.href),Cr=(t,e)=>t.origin===e.origin,is=t=>t.endsWith("/")?t:t+"/",Mr=({pathname:t},{pathname:e})=>{const a=Math.abs(t.length-e.length);return a===0?t===e:a===1&&is(t)===is(e)},Bc=(t,e)=>t.search===e.search,jr=(t,e)=>Bc(t,e)&&Mr(t,e),Ic=(t,e,a)=>{let l=e??"";return a&&(l+=(l?"&":"?")+Lr+"="+encodeURIComponent(a.id)),t+(t.endsWith("/")?"":"/")+"q-data.json"+l},Oc=(t,e)=>{const a=t.href;if(typeof a=="string"&&typeof t.target!="string"&&!t.reload)try{const l=zt(a.trim(),e.url),r=zt("",e.url);if(Cr(l,r))return rs(l)}catch(l){console.error(l)}else if(t.reload)return rs(zt("",e.url));return null},Ac=(t,e)=>{if(t){const a=zt(t,e.url),l=zt("",e.url);return!jr(a,l)}return!1},Nc=(t,e)=>{if(t){const a=zt(t,e.url),l=zt("",e.url);return!Mr(a,l)}return!1},Rc=t=>t&&typeof t.then=="function",qc=(t,e,a,l)=>{const r=Er(),c={head:r,withLocale:d=>Un(l,d),resolveValue:d=>{const p=d.__id;if(d.__brand==="server_loader"&&!(p in t.loaders))throw new Error("You can not get the returned data of a loader that has not been executed for this request.");const f=t.loaders[p];if(Rc(f))throw new Error("Loaders returning a promise can not be resolved for the head function.");return f},...e};for(let d=a.length-1;d>=0;d--){const p=a[d]&&a[d].head;p&&(typeof p=="function"?os(r,Un(l,()=>p(c))):typeof p=="object"&&os(r,p))}return c.head},os=(t,e)=>{typeof e.title=="string"&&(t.title=e.title),ta(t.meta,e.meta),ta(t.links,e.links),ta(t.styles,e.styles),ta(t.scripts,e.scripts),Object.assign(t.frontmatter,e.frontmatter)},ta=(t,e)=>{if(Array.isArray(e))for(const a of e){if(typeof a.key=="string"){const l=t.findIndex(r=>r.key===a.key);if(l>-1){t[l]=a;continue}}t.push(a)}},Er=()=>({title:"",meta:[],links:[],styles:[],scripts:[],frontmatter:{}});let us;(function(t){t[t.EOL=0]="EOL",t[t.OPEN_BRACKET=91]="OPEN_BRACKET",t[t.CLOSE_BRACKET=93]="CLOSE_BRACKET",t[t.DOT=46]="DOT",t[t.SLASH=47]="SLASH"})(us||(us={}));const Fc=t=>{},zc=async(t,e,a)=>{const l=t.pathname,r=t.search,o=Ic(l,r,a==null?void 0:a.action);let c;a!=null&&a.action||(c=Je.get(o)),a==null||a.prefetchSymbols;let d;if(!c){const p=Gc(a==null?void 0:a.action);a!=null&&a.action&&(a.action.data=void 0),c=fetch(o,p).then(f=>{const h=new URL(f.url),y=h.pathname.endsWith("/q-data.json");if(h.origin!==location.origin||!y){location.href=h.href;return}if((f.headers.get("content-type")||"").includes("json"))return f.text().then(b=>{const w=Zi(b,e);if(!w){location.href=t.href;return}if(a!=null&&a.clearCache&&Je.delete(o),w.redirect)location.href=w.redirect;else if(a!=null&&a.action){const{action:D}=a,L=w.loaders[D.id];d=()=>{D.resolve({status:f.status,result:L})}}return w});location.href=t.href}),a!=null&&a.action||Je.set(o,c)}return c.then(p=>(p||Je.delete(o),d&&d(),p))},Gc=t=>{const e=t==null?void 0:t.data;if(e)return e instanceof FormData?{method:"POST",body:e}:{method:"POST",body:JSON.stringify(e),headers:{"Content-Type":"application/json, charset=UTF-8"}}},ry=()=>we(Tr),vt=()=>we(Dr),Br=()=>we(Pr),Qc=()=>we(kr),Ir=()=>Ma(Al("qwikcity")),Hc=":root{view-transition-name:none}",Wc=async(t,e)=>{const[a,l,r,o]=X(),{type:c="link",forceReload:d=t===void 0,replaceState:p=!1,scroll:f=!0}=typeof e=="object"?e:{forceReload:e},h=r.value.dest,y=t===void 0?h:zt(t,o.url);if(Cr(y,h)&&!(!d&&jr(y,h)))return r.value={type:c,dest:y,forceReload:d,replaceState:p,scroll:f},a.value=void 0,o.isNavigating=!0,new Promise(b=>{l.r=b})},Uc=({track:t})=>{const[e,a,l,r,o,c,d,p,f,h,y]=X();async function b(){const[D,L]=t(()=>[h.value,e.value]),v=ko(""),S=y.url,M=L?"form":D.type;D.replaceState;let k,T,E=null;if(k=new URL(D.dest,y.url),E=o.loadedRoute,T=o.response,E){const[B,R,j,H]=E,J=j,tt=J[J.length-1];y.prevUrl=S,y.url=k,y.params={...R},h.untrackedValue={type:M,dest:k};const et=qc(T,y,J,v);a.headings=tt.headings,a.menu=H,l.value=Ma(J),r.links=et.links,r.meta=et.meta,r.styles=et.styles,r.scripts=et.scripts,r.title=et.title,r.frontmatter=et.frontmatter}}return b()},Yc=t=>{wc(g(Hc,"s_RPDJAz33WLA"));const e=Ir();if(!(e!=null&&e.params))throw new Error("Missing Qwik City Env Data");const a=Al("url");if(!a)throw new Error("Missing Qwik URL Env Data");const l=new URL(a),r=Jt({url:l,params:e.params,isNavigating:!1,prevUrl:void 0},{deep:!1}),o={},c=dc(Jt(e.response.loaders,{deep:!1})),d=O({type:"initial",dest:l,forceReload:!1,replaceState:!1,scroll:!0}),p=Jt(Er),f=Jt({headings:void 0,menu:void 0}),h=O(),y=e.response.action,b=y?e.response.loaders[y]:void 0,w=O(b?{id:y,data:e.response.formData,output:{result:b,status:e.response.status}}:void 0),D=g(Wc,"s_fX0bDjeJa0E",[w,o,d,r]);return Ft(Pc,f),Ft(Sr,h),Ft(Tr,p),Ft(Dr,r),Ft(Pr,D),Ft(_r,c),Ft(kr,w),Ft(kc,d),yl(g(Uc,"s_02wMImzEAbk",[w,f,h,p,e,D,c,o,t,d,r])),i(it,null,3,"qY_0")},iy=m(g(Yc,"s_TxCFOy819ag")),Vc=(t,e)=>{var a;if(!((a=navigator.connection)!=null&&a.saveData)&&e&&e.href){const l=new URL(e.href);Fc(l.pathname),e.hasAttribute("data-prefetch")&&zc(l,e,{prefetchSymbols:!1})}},Zc=async(t,e)=>{const[a,l,r,o]=X();t.defaultPrevented&&(e.hasAttribute("q:nbs")?await a(location.href,{type:"popstate"}):e.href&&(e.setAttribute("aria-pressed","true"),await a(e.href,{forceReload:l,replaceState:r,scroll:o}),e.removeAttribute("aria-pressed")))},Xc=t=>{const e=Br(),a=vt(),{onClick$:l,prefetch:r,reload:o,replaceState:c,scroll:d,...p}=t,f=Pe(()=>Oc({...p,reload:o},a));p["link:app"]=!!f,p.href=f||t.href;const h=Pe(()=>!!f&&r!==!1&&r!=="js"&&Ac(f,a)||void 0),b=Pe(()=>h||!!f&&r!==!1&&Nc(f,a))?g(Vc,"s_Osdg8FnYTw4"):void 0,w=f?vc((L,v)=>{L.metaKey||L.ctrlKey||L.shiftKey||L.altKey||L.preventDefault()}):void 0;return Y("a",{...p,children:i(it,null,3,"AD_0"),"data-prefetch":h,onClick$:[w,l,f?g(Zc,"s_pIf0khHUxfY",[e,o,c,d]):void 0],onFocus$:[p.onFocus$,b],onMouseOver$:[p.onMouseOver$,b],onQVisible$:[p.onQVisible$,b]},null,0,"AD_1")},Gt=m(g(Xc,"s_8gdLBszqbaM")),oy=t=>n("script",{nonce:_(t,"nonce")},{dangerouslySetInnerHTML:Dc},null,3,"1Z_0"),Kc=(t={})=>{throw X(),new Error(`Actions can not be invoked within the server during SSR.
Action.run() can only be called on the browser, for example when a user clicks a button, or submits a form.`)},Jc=(t,...e)=>{const{id:a,validators:l}=Ar(e,t);function r(){const o=vt(),c=Qc(),d={actionPath:`?${Lr}=${a}`,isRunning:!1,status:void 0,value:void 0,formData:void 0},p=Jt(()=>{const h=c.value;if(h&&(h==null?void 0:h.id)===a){const y=h.data;if(y instanceof FormData&&(d.formData=y),h.output){const{status:b,result:w}=h.output;d.status=b,d.value=w}}return d}),f=g(Kc,"s_A5bZC7WO00A",[c,a,o,p]);return d.submit=f,p}return r.__brand="server_action",r.__validators=l,r.__qrl=t,r.__id=a,Object.freeze(r),r},Or=(t,...e)=>{const a=Jc(t,...e);return typeof globalThis._qwikActionsMap>"u"&&(globalThis._qwikActionsMap=new Map),globalThis._qwikActionsMap.set(a.__id,a),a},N=(t,...e)=>{const{id:a,validators:l}=Ar(e,t);function r(){return we(_r,o=>{if(!(a in o))throw new Error(`routeLoader$ "${t.getSymbol()}" was invoked in a route where it was not declared.
    This is because the routeLoader$ was not exported in a 'layout.tsx' or 'index.tsx' file of the existing route.
    For more information check: https://qwik.builder.io/qwikcity/route-loader/

    If your are managing reusable logic or a library it is essential that this function is re-exported from within 'layout.tsx' or 'index.tsx file of the existing route otherwise it will not run or throw exception.
    For more information check: https://qwik.builder.io/docs/cookbook/re-exporting-loaders/`);return _(o,a)})}return r.__brand="server_loader",r.__qrl=t,r.__validators=l,r.__id=a,Object.freeze(r),r},td=async function(...t){var a;const[e]=X();t.length>0&&t[0]instanceof AbortSignal&&t.shift();{const l=[(a=Ir())==null?void 0:a.ev,this,Bo()].find(r=>r&&Object.prototype.hasOwnProperty.call(r,"sharedMap")&&Object.prototype.hasOwnProperty.call(r,"cookie"));return e.apply(l,t)}},Nl=t=>{{const a=t.getCaptured();if(a&&a.length>0&&!Eo())throw new Error("For security reasons, we cannot serialize QRLs that capture lexical scope.")}function e(){return g(td,"s_wOIPfiQ04l4",[t])}return e()},Ar=(t,e)=>{let a;const l=[];if(t.length===1){const r=t[0];r&&typeof r=="object"&&("validate"in r?l.push(r):(a=r.id,r.validation&&l.push(...r.validation)))}else t.length>1&&l.push(...t.filter(r=>!!r));return typeof a=="string"?a=`id_${a}`:a=e.getHash(),{validators:l.reverse(),id:a}},ed=({action:t,spaReset:e,reloadDocument:a,onSubmit$:l,...r},o)=>(W(),t?Y("form",{...r,action:_(t,"actionPath"),"preventdefault:submit":!a,"data-spa-reset":e?"true":void 0,onSubmit$:[a?void 0:t.submit,l]},{method:"post"},0,o):i(nd,{onSubmit$:l,reloadDocument:a,spaReset:e,...r},0,o)),ad=async(t,e)=>{const[a]=X(),l=new FormData(e),r=new URLSearchParams;l.forEach((o,c)=>{typeof o=="string"&&r.append(c,o)}),a("?"+r.toString(),{type:"form",forceReload:!0}).then(()=>{e.getAttribute("data-spa-reset")==="true"&&e.reset(),e.dispatchEvent(new CustomEvent("submitcompleted",{bubbles:!1,cancelable:!1,composed:!1,detail:{status:200}}))})},ld=t=>{const e=Pi(t,["action","spaReset","reloadDocument","onSubmit$"]),a=Br();return Y("form",{...e,children:i(it,null,3,"BC_0"),onSubmit$:g(ad,"s_p9MSze0ojs4",[a])},{action:"get","data-spa-reset":u(l=>l.spaReset?"true":void 0,[t],'p0.spaReset?"true":undefined'),"preventdefault:submit":u(l=>!l.reloadDocument,[t],"!p0.reloadDocument")},0,"BC_1")},nd=m(g(ld,"s_Nk9PlpjQm9Y")),sd=t=>n("div",null,{class:"w-fit h-fit flex items-center justify-center",role:"status"},n("svg",null,{"aria-hidden":"true",class:u(e=>`w-[${e.size}] h-[${e.size}] text-gray-200 animate-spin dark:text-blue-300 fill-primary-blue`,[t],"`w-[${p0.size}] h-[${p0.size}] text-gray-200 animate-spin dark:text-blue-300 fill-primary-blue`"),fill:"none",viewBox:"0 0 100 101",xmlns:"http://www.w3.org/2000/svg"},[n("path",null,{d:"M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",fill:"currentColor"},null,3,null),n("path",null,{d:"M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",fill:"currentFill"},null,3,null)],3,null),3,"73_0"),ne=m(g(sd,"s_kpSoQCQrots")),Nr="https://strapi42.rtatel.com",rd=`${Nr}/graphql`,St=t=>`${Nr}${t}`,Ne=t=>t==="es"?"es-419":t,$=`
data {
    attributes {
        url
        alternativeText
        caption
        formats
    }
}
`,G=t=>{let e=[],a=!0;return t.schema&&(t.schema.includes('<script type="application/ld+json">')&&(a=!1),e=t.schema.split(a?"<script>":'<script type="application/ld+json">').flatMap(l=>l.split(a?"<script>":'<script type="application/ld+json">')).flatMap(l=>l.replace("<\/script>","")).reduce((l,r)=>r?[...l,r]:l,[])),e.flat(),{title:t.MetaTitle,scripts:[...e.map(l=>({props:a?{}:{type:"application/ld+json"},script:l}))],meta:[{name:"description",content:t.MetaDescription},{name:"keywords",content:t.Keywords}]}},q=`
SEO {
    MetaTitle
    MetaDescription
    Keywords
    preventIndexing
    schema
}
`,Xe=`
data{
      attributes{
       	Content{
          Titles{
            Text
          }
          TextContent
        }
`,Rr=`
MembersGrid{
           Picture{
         ${$}
        }
        FirstName
        LastName
        Position
        SocialMedia{
          Icon{
            ${$}
          }
          Link
        }
      }
`,id=t=>`
sectionNetwork (locale:"${t}"){
  data {
    attributes {
      Map {
        MapPicture {
          ${$}
        }
        ServersTitle
        Servers {
          Text
          Link
          Icon{
            ${$}
          }
        }
      }
      Description{
        Title
        Paragraph
      }
    }
  }
}
`,od=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],ud=["January","February","March","April","May","June","July","August","September","October","November","December"];function aa(t,e=!0){const a=new Date(t),l=od[a.getDay()],r=a.getDate(),o=ud[a.getMonth()],c=a.getFullYear();return`${e?l+", ":""}${e?o:o.slice(0,3)} ${r}, ${c}`}const cd=()=>n("div",null,{class:"flex absolute flex-col items-center justify-center m-auto gap-2 h-full w-full bg-gradient-radial from-white via-slate-200 to-slate-300"},[n("img",null,{alt:"RTA image loading",height:200,src:St("/uploads/RTA_db22afd96e.webp"),width:250},null,3,null),i(ne,{size:"150px",[s]:{size:s}},3,"yL_0")],1,"yL_1"),dd=m(g(cd,"s_BeMhGs9mjvk")),pd=async({cacheControl:t})=>{t({staleWhileRevalidate:604800,maxAge:5})},fd=()=>({date:new Date().toISOString()}),gd=N(g(fd,"s_GQamrjryd1Y")),xd=()=>{const[t]=X();t.value=!0},md=()=>{W();const t=O(!0);return yl(g(xd,"s_lROQwus8zWc",[t])),yt(I("s_Ku7AU0gi0Go",[t])),i(Q,{children:t.value?n("div",null,{class:"h-full w-full flex",id:"splash"},i(dd,null,3,"XF_0"),1,"XF_1"):i(it,null,3,"XF_2")},1,"XF_3")},hd=m(g(md,"s_VkLNXphUh5s")),$d=Object.freeze(Object.defineProperty({__proto__:null,default:hd,onGet:pd,useServerTimeLoader:gd},Symbol.toStringTag,{value:"Module"})),bd=()=>{const t=["https://images.unsplash.com/photo-1693825948507-acd866203fae?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8MXx8fGVufDB8fHx8fA%3D%3D","https://images.unsplash.com/photo-1694476053120-d729a3f6a7ed?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8fA%3D%3D","https://images.unsplash.com/photo-1695256294687-5df561945542?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8MTB8fHxlbnwwfHx8fHw%3D"],e=O(0);return yt(I("s_aXdoh0xz8cQ",[t,e])),n("div",null,null,n("img",{src:t[e.value]},{alt:"Slider",class:"transition-opacity duration-2000 ease-in-out opacity-100",height:150,width:150},null,3,null),1,"Sz_0")},yd=m(g(bd,"s_X6NIVA8H4IM")),vd=()=>i(Q,{children:i(yd,null,3,"Ch_0")},1,"Ch_1"),wd=m(g(vd,"s_nUdxvD3SCSo")),_d=Object.freeze(Object.defineProperty({__proto__:null,default:wd},Symbol.toStringTag,{value:"Module"})),Sd=async t=>{const e=await t.parseBody(),a="https://api.emailjs.com/api/v1.0/email/send/";console.log(e);const r={...{service_id:"service_3c06k96",user_id:"IYZz-W8oLRewKg_p0",accessToken:"6I-rPRtBvWRubnBm_GLdd"},template_id:e.template_id,template_params:e},o=await fetch(a,{method:"POST",body:JSON.stringify(r),headers:{"Content-Type":"application/json"}});t.json(200,{resp:await o.text()})},Td=Object.freeze(Object.defineProperty({__proto__:null,onPost:Sd},Symbol.toStringTag,{value:"Module"})),Dd=async(t,e,a)=>{const r=await fetch(`https://autosuggest.search.hereapi.com/v1/autosuggest?apiKey=-plDP_dR7XAGxBSiHgTFyxkxNdjFFHqjQK9ge8b92CE&q=${t}&at=${e},${a}&in=countryCode:USA&types=street`);return r.status!==200?[]:(await r.json()).items.map(d=>({address:d.title,zip:d.title.split(", ")[2].split(" ")[1]}))},Pd=async({json:t,query:e})=>{const a=e.get("q");if(!a)t(400,{message:"Bad request (need ?q param)"});else{const l=await Dd(a,29.62540053919014,-95.39478748016545);t(200,{data:l})}},kd=Object.freeze(Object.defineProperty({__proto__:null,onGet:Pd},Symbol.toStringTag,{value:"Module"})),qr=t=>`
query QueryLayout {
    generalMenu(locale: "${t}") {
      data {
        attributes {
          TopOptions {
            Icon {
              ${$}
            }
            Text
            Link
          }
  
          localizations {
            data {
              attributes {
                MainOptions {
                  Text
                  Link
                  SubOption {
                    Text
                    Link
                  }
                }
              }
            }
          }
  
          MainMenu {
            Logo {
              ${$}
            }
            Switcher {
              Text
              Link
              Icon {
                ${$}
              }
            }
          }
          MainOptions {
            Text
            Link
            SubOption {
              Text
              Link
              MenuOption {
                data {
                  attributes {
                    SubOption {
                      Text
                      Link
                    }
                  }
                }
              }
            }
          }
          ClientOptions {
            Text
            Link
          }
          gigfastOptions {
            Text
            Link
            Icon {
              ${$}
            }
          }
        }
      }
    }
    generalFooter(locale: "${t}") {
      data {
        attributes {
          SupportSection {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          CorpInfo {
            Media {
              ${$}
            }
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          Menus {
            Text
            SubOption {
              Text
              Link
            }
          }
          SocialMedia {
            Text
            SubOption {
              Icon {
                ${$}
              }
              Link
            }
          }
        }
      }
    }
    generalHeader {
      data {
        attributes {
          Slide {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
        }
      }
    }
  } 
`;async function Re(t){return await(await fetch(rd,{method:"POST",cache:"no-cache",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:t})})).json()}async function z(t,e="en",a=!0){let l={};a&&(l=await Re(qr(Ne(e))));const r=await Re(t(Ne(e)));return{layoutData:l,pageData:r}}async function Ke(t,e="en",a=!0){let l={};a&&(l=await Re(qr(Ne(e))));const r=await Re(t);return{layoutData:l,pageData:r}}const Ld=async t=>{const e=await t.parseBody(),a=await Re(e.query);t.json(200,a)},Cd=Object.freeze(Object.defineProperty({__proto__:null,onPost:Ld},Symbol.toStringTag,{value:"Module"})),Md=async({request:t,json:e})=>{const a=await t.json();e(200,{body:a})},jd=Object.freeze(Object.defineProperty({__proto__:null,onPost:Md},Symbol.toStringTag,{value:"Module"})),Ed=t=>n("img",{src:St(t.media.url),srcset:t.media.formats&&t.media.formats.small&&`${St(t.media.formats.small.url)} 40w, ${St(t.media.url)} 800w`},{alt:u(e=>e.media.alternativeText,[t],'p0.media["alternativeText"]'),class:u(e=>(e.toWhite??!1?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+(e.clasN??""),[t],'(p0.toWhite??false?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+""+(p0.clasN??"")'),height:u(e=>e.height??150,[t],"p0.height??150"),sizes:"(max-width: 600px) 40px, 800px",title:u(e=>e.media.caption,[t],'p0.media["caption"]'),width:u(e=>e.width??150,[t],"p0.width??150")},null,3,"cI_0"),P=m(g(Ed,"s_LQFPgtOeNdI")),Bd=t=>Y("svg",{...t,children:n("path",null,{d:"M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"xG_0"),Id=t=>Y("svg",{...t,children:n("path",null,{d:"M201.4 342.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 274.7 86.6 137.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"xH_0"),Od=t=>Y("svg",{...t,children:n("path",null,{d:"M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"GB_0"),Ad=t=>Y("svg",{...t,children:n("path",null,{d:"M96 32V64H48C21.5 64 0 85.5 0 112v48H448V112c0-26.5-21.5-48-48-48H352V32c0-17.7-14.3-32-32-32s-32 14.3-32 32V64H160V32c0-17.7-14.3-32-32-32S96 14.3 96 32zM448 192H0V464c0 26.5 21.5 48 48 48H400c26.5 0 48-21.5 48-48V192z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"nO_0"),Nd=t=>Y("svg",{...t,children:n("path",null,{d:"M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"p8_0"),Rd=t=>Y("svg",{...t,children:n("path",null,{d:"M0 256a256 256 0 1 0 512 0A256 256 0 1 0 0 256zM281 385c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l71-71L136 280c-13.3 0-24-10.7-24-24s10.7-24 24-24l182.1 0-71-71c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0L393 239c9.4 9.4 9.4 24.6 0 33.9L281 385z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 512 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"tx_0"),qd=t=>Y("svg",{...t,children:n("path",null,{d:"M256 448c141.4 0 256-93.1 256-208S397.4 32 256 32S0 125.1 0 240c0 45.1 17.7 86.8 47.7 120.9c-1.9 24.5-11.4 46.3-21.4 62.9c-5.5 9.2-11.1 16.6-15.2 21.6c-2.1 2.5-3.7 4.4-4.9 5.7c-.6 .6-1 1.1-1.3 1.4l-.3 .3 0 0 0 0 0 0 0 0c-4.6 4.6-5.9 11.4-3.4 17.4c2.5 6 8.3 9.9 14.8 9.9c28.7 0 57.6-8.9 81.6-19.3c22.9-10 42.4-21.9 54.3-30.6c31.8 11.5 67 17.9 104.1 17.9zM128 208a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 0a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm96 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 512 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Bu_0"),Rl=t=>Y("svg",{...t,children:n("path",null,{d:"M429.6 92.1c4.9-11.9 2.1-25.6-7-34.7s-22.8-11.9-34.7-7l-352 144c-14.2 5.8-22.2 20.8-19.3 35.8s16.1 25.8 31.4 25.8H224V432c0 15.3 10.8 28.4 25.8 31.4s30-5.1 35.8-19.3l144-352z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"ak_0"),Fd=t=>Y("svg",{...t,children:n("path",null,{d:"M384 192c0 87.4-117 243-168.3 307.2c-12.3 15.3-35.1 15.3-47.4 0C117 435 0 279.4 0 192C0 86 86 0 192 0S384 86 384 192z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 384 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"6Z_0"),zd=t=>Y("svg",{...t,children:n("path",null,{d:"M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 384 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"4m_0"),Gd=t=>{const e=O(!1);return n("div",null,{class:"relative w-fit"},[n("span",null,{class:u(a=>`${a.containerClass??""} flex cursor-pointer items-center gap-2`,[t],'`${p0.containerClass??""} flex cursor-pointer items-center gap-2`'),onClick$:I("s_F3aQ057DSxY",[e]),onFocusout$:I("s_eygkshVHA6I",[e])},[n("span",null,null,u(a=>a.title,[t],"p0.title"),3,null),i(Id,null,3,"bO_0")],1,null),n("div",null,{class:u(a=>`absolute bottom-0 left-0 right-0 top-full z-10 min-w-[140px]  rounded-md bg-white shadow-lg transition-all duration-300 ${a.value?"":"hidden"}`,[e],'`absolute bottom-0 left-0 right-0 top-full z-10 min-w-[140px]  rounded-md bg-white shadow-lg transition-all duration-300 ${p0.value?"":"hidden"}`')},i(it,null,3,"bO_1"),1,null)],1,"bO_2")},ga=m(g(Gd,"s_f0Yr0C5H5Es")),Qd=()=>{const[t]=X();let e="";t?e="/"+window.location.pathname.split("/es/")[1]:e="/es"+window.location.pathname,window.location.pathname=e},Hd=t=>{var r;const a=(r=vt().prevUrl)==null?void 0:r.pathname.includes("/es/");return n("div",null,{class:"relative flex cursor-pointer items-center justify-center self-center rounded-full bg-gray-100 shadow-sm",onClick$:g(Qd,"s_W5KXXUmo6j8",[a])},[i(P,{get media(){return t.data[0].Icon.data.attributes},clasN:`h-[36px] w-[36px] m-1 rounded-full ${a?"opacity-30":"border-2 border-primary-blue border-opacity-50"}`,[s]:{media:u(o=>o.data[0].Icon.data.attributes,[t],'p0.data[0]["Icon"]["data"]["attributes"]')}},3,"tf_0"),i(P,{get media(){return t.data[1].Icon.data.attributes},clasN:`h-[36px] w-[36px] m-1 rounded-full ${a?"border-2 border-primary-blue border-opacity-50":"opacity-30"}  `,[s]:{media:u(o=>o.data[1].Icon.data.attributes,[t],'p0.data[1]["Icon"]["data"]["attributes"]')}},3,"tf_1")],1,"tf_2")},Wd=m(g(Hd,"s_mIn2RUIc9QU")),Ud=t=>{W();const e=O(!0);return n("div",null,{class:"bg-blue-900 h-[550px] w-full sm:w-4/5 flex flex-col justify-between items-center p-6 rounded-2xl"},[n("h2",null,{class:"text-white font-bold text-xl md:text-4xl mb-2"},"Get in contact with us",3,null),e.value?i(ne,{size:"250px",[s]:{size:s}},3,"iV_0"):null,n("iframe",null,{class:"w-full h-full overflow-x-visible overflow-y-visible",id:"portability-request",onLoad$:I("s_fXnkVThI4oM",[e]),src:u(a=>a.link,[t],"p0.link")},null,3,null)],1,"iV_1")},Yd=m(g(Ud,"s_fvFnDV0yuRY")),Vd=t=>Y("svg",{...t,children:n("path",null,{d:"M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z","fill-rule":"evenodd"},null,3,null)},{class:"bi bi-arrow-right-short","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Gz_0"),Zd=t=>Y("svg",{...t,children:n("path",null,{d:"M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.5a1 1 0 0 0-.8.4l-1.9 2.533a1 1 0 0 1-1.6 0L5.3 12.4a1 1 0 0 0-.8-.4H2a2 2 0 0 1-2-2V2zm3.5 1a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm0 2.5a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm0 2.5a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5z"},null,3,null)},{class:"bi bi-chat-square-text-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"yq_0"),Fr=t=>Y("svg",{...t,children:n("path",null,{d:"M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"},null,3,null)},{class:"bi bi-check-circle-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Dp_0"),cs=t=>Y("svg",{...t,children:n("path",null,{d:"M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"},null,3,null)},{class:"bi bi-check","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"0U_0"),zr=t=>Y("svg",{...t,children:[n("path",null,{d:"M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"},null,3,null),n("path",null,{d:"M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"},null,3,null)]},{class:"bi bi-download","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"ME_0"),Xd=t=>Y("svg",{...t,children:[n("path",null,{d:"M2 2A2 2 0 0 0 .05 3.555L8 8.414l7.95-4.859A2 2 0 0 0 14 2H2Zm-2 9.8V4.698l5.803 3.546L0 11.801Zm6.761-2.97-6.57 4.026A2 2 0 0 0 2 14h6.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.606-3.446l-.367-.225L8 9.586l-1.239-.757ZM16 9.671V4.697l-5.803 3.546.338.208A4.482 4.482 0 0 1 12.5 8c1.414 0 2.675.652 3.5 1.671Z"},null,3,null),n("path",null,{d:"M15.834 12.244c0 1.168-.577 2.025-1.587 2.025-.503 0-1.002-.228-1.12-.648h-.043c-.118.416-.543.643-1.015.643-.77 0-1.259-.542-1.259-1.434v-.529c0-.844.481-1.4 1.26-1.4.585 0 .87.333.953.63h.03v-.568h.905v2.19c0 .272.18.42.411.42.315 0 .639-.415.639-1.39v-.118c0-1.277-.95-2.326-2.484-2.326h-.04c-1.582 0-2.64 1.067-2.64 2.724v.157c0 1.867 1.237 2.654 2.57 2.654h.045c.507 0 .935-.07 1.18-.18v.731c-.219.1-.643.175-1.237.175h-.044C10.438 16 9 14.82 9 12.646v-.214C9 10.36 10.421 9 12.485 9h.035c2.12 0 3.314 1.43 3.314 3.034v.21Zm-4.04.21v.227c0 .586.227.8.581.8.31 0 .564-.17.564-.743v-.367c0-.516-.275-.708-.572-.708-.346 0-.573.245-.573.791Z"},null,3,null)]},{class:"bi bi-envelope-at-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"9e_0"),Gr=t=>Y("svg",{...t,children:n("path",null,{d:"M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"},null,3,null)},{class:"bi bi-geo-alt-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"62_0"),ql=t=>Y("svg",{...t,children:[n("path",null,{d:"M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"},null,3,null),n("path",null,{d:"m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6Z"},null,3,null)]},{class:"bi bi-house-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"fX_0"),Kd=t=>Y("svg",{...t,children:n("path",null,{d:"M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"},null,3,null)},{class:"bi bi-info-circle-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"SU_0"),Jd=t=>Y("svg",{...t,children:n("path",null,{d:"M2 6a6 6 0 1 1 10.174 4.31c-.203.196-.359.4-.453.619l-.762 1.769A.5.5 0 0 1 10.5 13h-5a.5.5 0 0 1-.46-.302l-.761-1.77a1.964 1.964 0 0 0-.453-.618A5.984 5.984 0 0 1 2 6zm3 8.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1l-.224.447a1 1 0 0 1-.894.553H6.618a1 1 0 0 1-.894-.553L5.5 15a.5.5 0 0 1-.5-.5z"},null,3,null)},{class:"bi bi-lightbulb-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"IC_0"),tp=t=>Y("svg",{...t,children:n("path",null,{d:"M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"},null,3,null)},{class:"bi bi-person-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"iB_0"),ep=t=>Y("svg",{...t,children:n("path",null,{d:"M0 12V4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm6.79-6.907A.5.5 0 0 0 6 5.5v5a.5.5 0 0 0 .79.407l3.5-2.5a.5.5 0 0 0 0-.814l-3.5-2.5z"},null,3,null)},{class:"bi bi-play-btn-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"YD_0"),ap=t=>Y("svg",{...t,children:n("path",null,{d:"M2 1a1 1 0 0 0-1 1v4.586a1 1 0 0 0 .293.707l7 7a1 1 0 0 0 1.414 0l4.586-4.586a1 1 0 0 0 0-1.414l-7-7A1 1 0 0 0 6.586 1H2zm4 3.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"},null,3,null)},{class:"bi bi-tag-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"vL_0"),Qr=t=>Y("svg",{...t,children:n("path",null,{d:"M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z","fill-rule":"evenodd"},null,3,null)},{class:"bi bi-telephone-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"nW_0"),lp=t=>Y("svg",{...t,children:[n("path",null,{d:"M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"},null,3,null),n("path",null,{d:"M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"},null,3,null)]},{class:"bi bi-upload","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"pX_0"),np=t=>Y("svg",{...t,children:n("path",null,{d:"M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"},null,3,null)},{class:"bi bi-x-lg","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"fv_0"),sp=()=>{const[t,e]=X();t.value="LOADING";const a=new FormData(document.getElementById("s_form")),l=Object.fromEntries(a);l.template_id=e.templateID,console.log(l),fetch("/api/emailjs/",{method:"POST",body:JSON.stringify(l),headers:{"Content-Type":"application/json"}}).then(r=>r.json()).then(r=>{r.resp==="OK"?t.value="SUCCESS":t.value="ERROR"}).catch(r=>{console.error(r),t.value="ERROR"})},rp=t=>{W();const e=O("NONE"),a=O(!1),l=O(!1),r=O(!1),o=O(!1),d=yt(I("s_azU0komrCE4",[o,a,r,l,g(sp,"s_ZwppZMA0qq4",[e,t])]));return n("div",null,{class:"mx-auto flex max-w-lg flex-col rounded-3xl bg-white p-6"},n("form",null,{class:"mt-2",id:"s_form",onSubmit$:I("s_mKzn6gnXAQk",[d]),"preventdefault:submit":!0},[n("div",null,{class:"flex flex-wrap"},[n("div",null,{class:"mb-4 w-full sm:w-2/3"},[n("label",null,{class:"block text-base font-medium text-[#2e5899]",for:"name"},["Name ",n("span",null,{class:"text-red-600"},"*",3,null)," "],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(tp,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"T4_0"),1,null),n("input",null,{class:"w-full rounded-full border border-[#2e5899] border-opacity-40 p-2 focus:border-blue-500 focus:outline-none",name:"from_name",required:!0,type:"text"},null,3,null)],1,null)],1,null),n("div",null,{class:"mb-4 w-2/3 sm:w-1/3"},[n("label",null,{class:"block text-base font-medium text-[#2e5899]",for:"zip_code"},["Zip Code ",n("span",null,{class:"text-red-600"},"*",3,null)," "],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(Gr,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"T4_1"),1,null),n("input",null,{class:"w-full rounded-full border border-[#2e5899] border-opacity-40 p-2 focus:border-blue-500 focus:outline-none",maxLength:5,minLength:5,name:"zip_code",required:!0,type:"number"},null,3,null)],1,null)],1,null)],1,null),n("div",null,{class:"flex flex-wrap items-center md:flex-row"},[n("div",null,{class:"mb-4 w-full sm:w-1/2"},[n("label",null,{class:"block text-base font-medium text-[#2e5899]",for:"email"},["Email ",n("span",null,{class:"text-red-600"},"*",3,null)],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(Xd,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"T4_2"),1,null),n("input",null,{class:"w-full rounded-full border border-[#2e5899] border-opacity-40 p-2 focus:border-blue-500 focus:outline-none",id:"from_email",name:"from_email",required:!0,type:"email"},null,3,null)],1,null),n("label",null,{class:u((p,f)=>`text-xs text-red-600 ${p.value==!1&&f.value==!0?"flex":"hidden"} bg-transparent`,[o,r],'`text-xs text-red-600 ${p0.value==false&&p1.value==true?"flex":"hidden"} bg-transparent`')},"email is invalid",3,null)],1,null),n("div",null,{class:"mb-4 w-full md:w-1/2"},[n("label",null,{class:"block text-base font-medium text-[#2e5899]",for:"tel"},"Phone",3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(Qr,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"T4_3"),1,null),n("input",null,{class:"w-full rounded-full border border-[#2e5899] border-opacity-40 p-2 focus:border-blue-500 focus:outline-none",id:"tel",maxLength:10,name:"tel",type:"tel"},null,3,null)],1,null),n("label",null,{class:u((p,f)=>`text-xs text-red-600 ${p.value==!1&&f.value==!0?"flex":"hidden"} bg-transparent`,[a,l],'`text-xs text-red-600 ${p0.value==false&&p1.value==true?"flex":"hidden"} bg-transparent`')},"phone number is invalid",3,null)],1,null)],1,null),n("div",null,{class:"mb-4"},[n("label",null,{class:"block text-base font-medium text-[#2e5899]",for:"message"},["Message",n("span",null,{class:"text-red-600"},"*",3,null)],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(Zd,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"T4_4"),1,null),n("textarea",null,{class:"w-full rounded-3xl border border-[#2e5899] border-opacity-40 p-2 focus:border-blue-500 focus:outline-none",name:"message",required:!0,rows:4},null,3,null)],1,null)],1,null),n("button",{class:`flex w-full items-center justify-center rounded-full bg-secondary-red px-4 py-2 text-base font-semibold text-white hover:bg-opacity-95 ${e.value==="LOADING"?"cursor-wait bg-primary-blue":e.value==="SUCCESS"?"bg-teal-500":""} focus:outline-none`},{disabled:u(p=>p.value==="LOADING"||p.value==="SUCCESS",[e],'p0.value==="LOADING"||p0.value==="SUCCESS"'),type:"submit"},e.value==="NONE"?"Submit":e.value==="LOADING"?i(ne,{size:"28px",[s]:{size:s}},3,"T4_5"):e.value==="ERROR"?"Error":"Email Sent!",1,null)],1,null),1,"T4_6")},ip=m(g(rp,"s_UlMR3Hqos6E")),op=()=>{const[t,e]=X();e.value=t},up=t=>{var y;const e=new Set(t.data.map(b=>b.attributes.Category)),a=t.data.filter(b=>b.attributes.Category==="Sports"),l=t.data.filter(b=>b.attributes.Category==="Movies"),r=t.data.filter(b=>b.attributes.Category==="News"),o=t.data.filter(b=>b.attributes.Category==="Music"),c=t.data.filter(b=>b.attributes.Category==="Kids"),d=(y=t.planId)==null?void 0:y.slice(0,2),p=O(0),f=b=>b.map((w,D)=>{const L=w.attributes.package_tvs.data.some(S=>S.attributes.package.includes(d)),v=w.attributes.package_tvs.data.some(S=>S.attributes.package.includes("comingSoon"));return n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",{class:`h-[40px] w-[40px] md:h-[60px] md:w-[60px] ${L?"":"opacity-20"} flex flex-col rounded-full border-2 p-1`},null,i(P,{height:50,width:50,get media(){return w.attributes.Image.data.attributes},[s]:{height:s,media:x(w.attributes.Image.data,"attributes"),width:s}},3,"wr_0"),1,null),v?n("div",null,{class:"rounded-full bg-primary-blue p-0.5 text-center text-xs text-white"},"Coming Soon",3,"wr_1"):null,n("p",null,{class:"text-center text-xs text-primary-blue"},_(w.attributes,"Channel_name"),1,null)],1,D)}),h=Array.from(e).map((b,w)=>n("div",null,{class:"grid w-full grid-cols-3 gap-4 py-4 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8"},b==="General"?f(t.data):b==="Sports"?f(a):b==="News"?f(r):b==="Music"?f(o):b==="Movies"?f(l):b==="Kids"?f(c):null,1,w));return n("div",null,{class:"h-[800px] w-full rounded-3xl bg-blue-700 p-5 md:h-[500px] md:w-[800px] md:p-10"},[n("div",null,{class:"flex flex-col content-start items-center justify-start md:flex-row md:justify-between"},[n("h1",null,{class:"text-2xl font-semibold text-white md:text-4xl"},u(b=>b.planId,[t],"p0.planId"),3,null),n("p",null,{class:"text-xl font-light text-white md:text-2xl"},u(b=>b.channels,[t],"p0.channels"),3,null)],3,null),n("div",null,{class:"my-1 flex h-fit flex-row items-start justify-start gap-4 overflow-x-auto rounded-t-2xl bg-white px-2 py-2 font-bold text-primary-blue md:items-center md:justify-between md:overflow-clip"},Array.from(e).map((b,w)=>n("button",{class:`${p.value==w?"bg-gray-200":""} rounded-xl p-2`,onClick$:g(op,"s_jPiPOXcEB6E",[w,p])},null,b,0,w)),1,null),n("div",null,{class:"flex h-3/4 w-full items-center justify-center rounded-b-3xl bg-white p-6"},Array.from(e).map((b,w)=>p.value==w?n("div",null,{class:"flex h-full w-full overflow-y-auto overflow-x-hidden rounded-2xl border-2 border-primary-blue bg-white py-4"},h[w],1,w):null),1,null)],1,"wr_2")},cp=m(g(up,"s_bUc7uFb70ZI")),dp=t=>`query {
        offices (filters:{locations:{ZipCode:{eq:${t}}}}) {
          data {
            attributes {
              InstanceLink
            }
          }
        }
      }`,pp=t=>`query {
        offices(filters: { locations: { ZipCode: { eq: ${t} } } }) {
          data {
            attributes {
              Location
              Phone {
                Link
                Text
              }
            }
          }
        }
      }`,fp=async t=>{let e=null;const a=await Ke(dp(t["zip-code"].toString()));return a.pageData.data.offices.data.length>0&&(e=await a.pageData.data.offices.data[0].attributes.InstanceLink),e},gp=Or(g(fp,"s_Aa7HFHe6DLE")),xp=async t=>{let e=null;const a=await Ke(pp(t["zip-code"].toString()));return a.pageData.data.offices.data.length>0&&(e=await a.pageData.data.offices.data[0].attributes),e};Or(g(xp,"s_txZGYKoQ0E8"));const mp=()=>{},hp=t=>{var o;W();const e=gp(),a=O(!1),r=(o=vt().prevUrl)==null?void 0:o.pathname.includes("/es/");return n("div",null,{class:" z-[800] flex h-fit w-[600px] flex-col items-center justify-center gap-4 rounded-full bg-blue-100 p-8"},[n("p",null,{class:"text-center text-4xl font-bold text-primary-blue"},u(c=>c.title,[t],"p0.title"),3,null),n("p",null,{class:"font-light"},u(c=>c.description,[t],"p0.description"),3,null),i(ed,{action:e,children:n("div",null,{class:"flex flex-row items-center justify-center gap-4 px-4"},[n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(Gr,{get style(){return{color:"#2e5899"}},[s]:{style:s}},3,"PA_0"),1,null),n("input",null,{class:"rounded-full border border-gray-300 p-2 placeholder:text-primary-blue focus:border-blue-500 focus:outline-none",maxLength:5,name:"zip-code",placeholder:"Zip-code",required:!0,type:"text"},null,3,null)],1,null),n("button",null,{class:"w-1/4 rounded-full border-2 border-teal-500 bg-white px-4 py-2 font-bold text-teal-500 hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:I("s_odOkENLwWr0",[a,e]),type:"submit"},u(c=>c.btnText,[t],"p0.btnText"),3,null)],1,null),class:"w-full",onSubmit$:g(mp,"s_SuMdNt0qey8"),[s]:{action:s,class:s,onSubmit$:s}},1,"PA_1"),t.popup==="login"&&e.isRunning&&i(ne,{size:"50px",[s]:{size:s}},3,"PA_2"),t.popup==="login"&&!e.isRunning&&e.value!=null&&n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,null,"Portal found",3,null),n("a",null,{href:u(c=>c.value.toString(),[e],"p0.value.toString()")},n("button",null,{class:"w-full rounded-full border-2 border-teal-500 bg-white px-4 py-2 font-bold text-teal-500 hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"},r?"Ir al portal":"Go to portal",1,null),1,null)],1,"PA_3"),t.popup==="login"&&!e.isRunning&&e.value==null&&a.value&&n("p",null,{class:"text-2xl text-secondary-red"},r?"Portal no encontrado":"Portal not found",1,"PA_4"),t.popup!=="login"&&e.isRunning&&i(ne,{size:"50px",[s]:{size:s}},3,"PA_5"),t.popup!=="login"&&!e.isRunning&&e.value!=null&&n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,null,e.value.Location.toString(),1,null),n("a",null,{href:u(c=>c.value.Phone.Link.toString(),[e],'p0.value["Phone"]["Link"].toString()')},n("button",null,{class:"w-full rounded-full border-2 border-teal-500 bg-white px-4 py-2 font-bold text-teal-500 hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"},u(c=>c.value.Phone.Text,[e],'p0.value["Phone"]["Text"]'),3,null),3,null)],1,"PA_6"),t.popup!=="login"&&!e.isRunning&&e.value==null&&a.value&&n("p",null,{class:"text-xs text-primary-blue"},u(c=>c.notFountText,[t],"p0.notFountText"),3,"PA_7")],1,"PA_8")},Va=m(g(hp,"s_7GiaINstLc4")),$p=t=>n("div",null,{class:"fixed bottom-0 left-0 right-0 bg-white top-0 z-[200] transition-all duration-1000 ease-in-out"},n("iframe",null,{class:"h-full w-full",frameBorder:"0",src:u(e=>e.route,[t],"p0.route")},null,3,null),3,"V0_0"),Hr=m(g($p,"s_R079dt5Nweo")),bp=t=>{const e=O(!1);return yt(I("s_rTgprikOCoA",[e,t])),n("div",{class:`flex items-center justify-start hover:cursor-pointer ${e.value?"text-white bg-primary-blue":"text-primary-dark-blue bg-white"}  shadow-2xl px-4 rounded-2xl h-[50px] ${t.classN}`},null,[n("input",null,{class:"peer appearance-none border border-primary-dark-blue w-4 h-4 rounded-full mr-[20px] checked:bg-btn-green checked:border-white",id:u(a=>a.id,[t],"p0.id"),name:"answer",type:"radio",value:u(a=>a.text,[t],"p0.text")},null,3,null),n("label",null,{class:"w-full hover:cursor-pointer h-full flex items-center font-bold",for:u(a=>a.id,[t],"p0.id")},u(a=>a.text,[t],"p0.text"),3,null)],3,"ss_0")},yp=m(g(bp,"s_HFec7A1uToc")),vp=t=>{const e=O(!1),a=O(!0);return yt(I("s_nLcxs1o4e5w",[e,t,a])),n("div",null,{class:u(l=>`flex flex-col w-full  shadow-2xl px-4 rounded-2xl ${l.value?"bg-primary-blue text-white":"bg-white text-primary-dark-blue"}`,[e],'`flex flex-col w-full  shadow-2xl px-4 rounded-2xl ${p0.value?"bg-primary-blue text-white":"bg-white text-primary-dark-blue"}`')},[n("div",null,{class:u(l=>`flex items-center justify-start hover:cursor-pointer h-[50px] ${l.classN}`,[t],"`flex items-center justify-start hover:cursor-pointer h-[50px] ${p0.classN}`")},[n("input",null,{checked:u(l=>l.signal.value,[t],"p0.signal.value"),class:"peer appearance-none border border-primary-dark-blue w-4 h-4 rounded-full mr-[20px] checked:bg-btn-green checked:border-white",id:u(l=>l.id,[t],"p0.id"),name:"answer",type:"radio"},null,3,null),n("label",null,{class:u(l=>`${l.description??""?"w-fit":"w-full"} hover:cursor-pointer h-full flex items-center font-bold `,[t],'`${p0.description??""?"w-fit":"w-full"} hover:cursor-pointer h-full flex items-center font-bold `'),for:u(l=>l.id,[t],"p0.id")},u(l=>l.text,[t],"p0.text"),3,null),(t.description??"")!=""?n("label",null,{class:"hover:cursor-pointer w-full h-full flex items-center font-light",for:u(l=>l.id,[t],"p0.id")},u(l=>`(${l.description??""})`,[t],'`(${p0.description??""})`'),3,"CH_0"):null],1,null),n("textarea",null,{class:u((l,r)=>`appearance-none border ${l.value&&r.value?"border-secondary-red":"border-primary-dark-blue"}  
        rounded-2xl text-primary-dark-blue px-1`,[e,a],'`appearance-none border ${p0.value&&p1.value?"border-secondary-red":"border-primary-dark-blue"}  \n        rounded-2xl text-primary-dark-blue px-1`'),id:u(l=>`${l.id}-textarea`,[t],"`${p0.id}-textarea`"),name:u(l=>`${l.id}-textarea`,[t],"`${p0.id}-textarea`"),rows:3},null,3,null),n("div",null,{class:u((l,r)=>`w-full rounded-3xl bg-secondary-red bg-opacity-70 text-center mt-1 ${l.value&&r.value?"":"hidden"}`,[e,a],'`w-full rounded-3xl bg-secondary-red bg-opacity-70 text-center mt-1 ${p0.value&&p1.value?"":"hidden"}`')},"Specify the reason",3,null)],1,"CH_1")},wp=m(g(vp,"s_5IvA0RZVpzA")),_p="https://supa42.rtatel.com",Sp="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ewogICAgInJvbGUiOiAiYW5vbiIsCiAgICAiaXNzIjogInN1cGFiYXNlIiwKICAgICJpYXQiOiAxNjg0ODI1MjAwLAogICAgImV4cCI6IDE4NDI2NzgwMDAKfQ.Atj9wTNbdEEVPOjstsO14DtxbY2SEpnr50elVXBgAmM",Fl=ui(_p,Sp,{db:{schema:"rta_surveys"}}),Tp=Bl(async t=>{const{data:e,error:a}=await Fl.from("questions").select("*").eq("id",t?11:10);if(a)throw console.error("Error en getQuestions: "+a),a;return e},"wiMa5jDble0"),Wr=Nl(g(Tp,"s_wiMa5jDble0")),Dp=Bl(async()=>{const{data:t,error:e}=await Fl.from("survey_answers").insert([{survey_id:2,created_at:new Date().toISOString()}]).select("id");if(e)throw console.log("Error en insertSurveyAnswers: "+e),e;return t},"0gk9ERY7sDw"),ds=Nl(g(Dp,"s_0gk9ERY7sDw")),Pp=Bl(async(t,e,a)=>{const{data:l,error:r}=await Fl.from("answers").insert([{survey_answers_id:t,question_id:e,answer:a,created_at:new Date().toISOString()}]);if(r)throw console.log("Error en insertAnswers: "+r),r;return l},"s08qE8uMmw8"),ps=Nl(g(Pp,"s_s08qE8uMmw8")),kp=async()=>{const[t]=X();(await Wr(!1)).map(a=>{t.id=a.id,t.survey_id=a.survey_id,t.question=a.question,t.answers=[a.radio1,a.radio2,a.radio3,a.radio4]})},Lp=async()=>{const[t]=X();t.signalPopupLeaving.value=!1},Cp=async()=>{const[t,e,a,l,r,o]=X();t.value=!0;const c=document.getElementById("form-leaving"),d=new FormData(c);let p="";d.forEach((f,h)=>{h=="answer"&&(p=f)}),console.log(p);try{if(p=="on"&&e.value&&r.value!=""){o.value=!0;const h=(await Wr(!0))[0].id,y=await ds();await ps(y[0].id,h,r.value)}if(p!="on"){o.value=!0;const f=await ds();await ps(f[0].id,l.id,p)}o.value&&(a.signalPopupLeaving.value=!1,a.signalMainPopup.value=!1,window.localStorage.setItem("sendform_leaving","true"))}catch(f){throw console.log("Error: "+f),f}},Mp=t=>{const e=Jt({id:0,survey_id:0,question:"",answers:["","","",""]}),a=O(!1),l=O(!1),r=O(!1),o=O(""),c=document.querySelector("textarea");c==null||c.addEventListener("input",()=>{(c==null?void 0:c.value)!=null&&(c==null?void 0:c.value)!=""?(a.value=!0,o.value=c==null?void 0:c.value):a.value=!1}),yl(g(kp,"s_0QW8yCiluKc",[e]));const d=g(Lp,"s_iTiGFY1069I",[t]),p=g(Cp,"s_q00AFmMZ9Pg",[r,a,t,e,o,l]);return n("div",null,{class:"fixed flex items-center justify-center h-full w-full bottom-0 left-0 right-0 bg-blue-300 bg-opacity-50 top-0 z-[700]"},n("div",null,{class:"flex flex-col items-center justify-evenly sm:h-[80%] h-fit md:w-1/2 w-[80%] bg-[#DFEDFF] rounded-2xl px-5 pb-4 transition-all duration-1000 ease-in-out"},[n("div",null,{class:"ml-auto text-3xl font-bold text-[#8AA7D2] cursor-pointer",onClick$:I("s_CvHEL9M08RI",[d])},"×",3,null),n("div",null,{class:"w-full h-[20%] flex flex-col items-center justify-center bg-gradient-to-tr from-primary-blue to-primary-light-blue rounded-3xl text-white mb-6 p-4 text-center"},[n("h2",null,{class:"font-bold sm:text-[35px] text-[24px]"},"Leaving so soon?",3,null),n("p",null,null,u(f=>f.question,[e],"p0.question"),3,null)],3,null),n("div",null,{class:u((f,h)=>`w-full rounded-3xl bg-secondary-red bg-opacity-70 text-center mt-1 ${f.value&&h.value==!1?"":"hidden"}`,[r,l],'`w-full rounded-3xl bg-secondary-red bg-opacity-70 text-center mt-1 ${p0.value&&p1.value==false?"":"hidden"}`')},"Select an option",3,null),n("form",null,{class:"flex flex-col items-center justify-between h-[50%] w-full",id:"form-leaving"},e.answers.map((f,h)=>W(h==3?i(wp,{classN:"mt-1",description:"Please, specify the reason",id:h,signal:a,text:f,[s]:{classN:s,description:s,signal:s}},3,h):i(yp,{classN:"w-full my-1",id:`checkbox-1-${h}`,text:f,[s]:{classN:s}},3,h))),1,null),n("button",null,{class:"text-white bg-btn-green font-bold py-2 px-4 w-fit h-fit rounded-3xl mt-4",onClick$:I("s_N36GmA7Tgos",[p])},"Submit",3,null)],1,null),1,"O0_0")},Ur=m(g(Mp,"s_F0u0TUxd0sI")),jp=t=>{var c,d;W();const a=(c=vt().prevUrl)==null?void 0:c.pathname.includes("/es/");let l=null;if(t.link.includes("=pConf=")){const p=t.link.replace("=pConf=","");l=i(Hr,{route:p},3,"Y1_0")}else if(t.link.includes("=pIFrame=")){const p=t.link.replaceAll("=pIFrame=","");l=i(Yd,{link:p},3,"Y1_1")}else t.link.includes("=pContactEmail=")?l=i(ip,{get templateID(){return t.link.split("=")[2]},[s]:{templateID:u(p=>p.link.split("=")[2],[t],'p0.link.split("=")[2]')}},3,"Y1_2"):t.link.includes("=pChannelLineup=")?l=i(cp,{get channels(){return t.channels},get planId(){return t.planId},get data(){return t.dataChannels},[s]:{channels:u(p=>p.channels,[t],"p0.channels"),data:u(p=>p.dataChannels,[t],"p0.dataChannels"),planId:u(p=>p.planId,[t],"p0.planId")}},3,"Y1_3"):t.link.includes("=pLogin")?l=i(Va,{btnText:a?"Ir ahora":"Go Now",description:a?"Simplemente ingrese su código postal.":"Just enter your Zip code.",popup:"login",title:a?"Inicia sesión en el portal de tu zona":"Log into the portal of your area",[s]:{popup:s}},3,"Y1_4"):t.link.includes("=pOfficeCall")&&(l=i(Va,{btnText:a?"Comprobar ahora":"Check Now",description:a?"Descubra exactamente qué servicios ofrece RTA en su ciudad natal. Ingrese su código postal para el número de teléfono de su oficina local.":"Find out exactly what services RTA has to offer in your hometown. Input your zip code for your local office phone number.",notFountText:a?"Desafortunadamente, RTA no está disponible actualmente en su área. Sin embargo, RTA continúa expandiéndose en todo Estados Unidos. Si está interesado en los servicios de RTA en su área, envíenos un correo electrónico o llame a nuestra oficina principal.":"Find out exactly what services RTA has to offer in your hometown. Input your zip code for your local office phone number.",popup:"location",title:a?"Llame a su oficina local":"Call your local office",[s]:{popup:s}},3,"Y1_5"));const r=O(!1),o=O(!1);return n("div",null,{class:"relative flex"},[t.link.includes("=pConf=")&&(!((d=t.text)!=null&&d.includes("Check"))||!t.text.includes("Buscar"))?n("div",null,{class:"flex w-fit items-center justify-center rounded-full border-2 border-teal-500 border-opacity-70 bg-white p-0.5 px-1 text-btn-green opacity-90 shadow-md transition-all delay-150 ease-in-out hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:I("s_gRyPmBMRMEM",[r])},[n("p",null,{class:"min-sm:text-[13px] mx-2 text-[15px] font-[600] tracking-wide max-md:text-[14px] "},u(p=>p.text,[t],"p0.text"),3,null),n("div",null,{class:"flex h-[25px] w-[25px] items-center justify-center rounded-full bg-teal-500 p-0 opacity-70 "},i(ap,{class:"fill-white font-bold",[s]:{class:s}},3,"Y1_6"),1,null)],1,"Y1_7"):t.hasStyle??!0?n("button",{class:`flex w-fit items-center justify-center gap-2 ${t.link.includes("=pChannelLineup=")?"":"rounded-full border-2 border-teal-500 p-1 px-7 shadow-md transition-all  hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"}  bg-white  text-[15px] font-[600]  text-btn-green opacity-80 max-md:text-[14px] max-sm:text-[13px] `},{onClick$:I("s_LMY0q14Gz9I",[r])},u(p=>p.text,[t],"p0.text"),3,null):n("div",null,{onClick$:I("s_CtCqQvywDJo",[r])},[i(it,null,3,"Y1_8")," "],1,"Y1_9"),r.value&&n("div",null,{class:"fixed inset-0 z-[200] flex flex-col items-center justify-center bg-black bg-opacity-40"},n("div",null,{class:u(p=>` ${p.link.includes("=pConf=")?"w-full h-full flex-row-reverse ":"flex-col-reverse md:flex-row w-fit"} animate-zoomIn flex `,[t],'` ${p0.link.includes("=pConf=")?"w-full h-full flex-row-reverse ":"flex-col-reverse md:flex-row w-fit"} animate-zoomIn flex `')},[n("div",null,{class:"flex p-4 flex-wrap overflow-hidden items-center justify-center "},[l,t.link.includes("=pConf=")&&o.value&&window.localStorage.getItem("sendform_leaving")!="true"?i(Ur,{signalMainPopup:r,signalPopupLeaving:o,[s]:{signalMainPopup:s,signalPopupLeaving:s}},3,"Y1_10"):null],1,null),n("button",{class:`${t.link.includes("=pConf=")?"mt-2 mx-0":"w-[30px] p-4"} bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] focus:outline-none z-[600]`},{"aria-label":"Close popup",onClick$:I("s_Hg5lk0TunCg",[t,r,o])},t.link.includes("=pConf=")?n("div",null,{class:"px-3 flex flex-row items-center text-xs gap-2"},["Back to site ",i(ql,null,3,"Y1_11")],1,"Y1_12"):n("div",null,null,i(np,null,3,"Y1_13"),1,null),1,null)],1,null),1,"Y1_14")],1,"Y1_15")},xa=m(g(jp,"s_G7PwpIAJKRA")),Ep=t=>{var r;W();const a=(r=vt().prevUrl)==null?void 0:r.pathname.includes("/es/"),l=t.link.startsWith("/");return t.link.startsWith("/")||t.link.startsWith("http")||t.link.startsWith("tel:")?i(Gt,{get class(){return t.classN??""},href:(a&&l?"/es":"")+t.link,prefetch:!0,get target(){return t.link.startsWith("http")?"_blank":"_self"},children:i(it,null,3,"8s_0"),[s]:{class:u(o=>o.classN??"",[t],'p0.classN??""'),prefetch:s,target:u(o=>o.link.startsWith("http")?"_blank":"_self",[t],'p0.link.startsWith("http")?"_blank":"_self"')}},1,"8s_1"):t.link.startsWith("=")&&t.link?i(xa,{get link(){return t.link},get text(){return t.text??""},get hasStyle(){return t.hasStyle??!0},children:[" ",n("div",null,{class:u(o=>`${o.classN??""} cursor-pointer`,[t],'`${p0.classN??""} cursor-pointer`')},i(it,null,3,"8s_2"),1,null)],[s]:{hasStyle:u(o=>o.hasStyle??!0,[t],"p0.hasStyle??true"),link:u(o=>o.link,[t],"p0.link"),text:u(o=>o.text??"",[t],'p0.text??""')}},1,"8s_3"):n("div",null,{class:u(o=>o.classN??"",[t],'p0.classN??""')},i(it,null,3,"8s_4"),1,"8s_5")},wt=m(g(Ep,"s_nqL2AObZq60")),Bp=t=>n("div",null,{class:"relative z-30 shadow-[0_5px_40px_-25px_rgba(0,0,0,0.2)]"},[n("div",null,{class:" fixed top-0 w-full shadow-[0_5px_40px_-25px_rgba(0,0,0,0.2)]"},[n("div",null,{class:"flex h-[28px] flex-row items-center justify-end gap-4 bg-primary-blue px-5 py-[4px] text-[12px] font-bold text-white max-sm:justify-evenly max-sm:text-[10px] max-sm:font-normal max-[400px]:text-[9px]"},t.data.TopOptions.map((e,a)=>i(wt,{get link(){return e.Link},hasStyle:!1,get text(){return e.Text},children:n("div",null,{class:"flex flex-row items-center gap-2"},[n("div",null,{class:"w-[12px]"},i(P,{get media(){return e.Icon.data.attributes},height:"16",toWhite:!0,width:"16",[s]:{height:s,media:x(e.Icon.data,"attributes"),toWhite:s,width:s}},3,"Qt_0"),1,null),_(e,"Text")],1,null),[s]:{hasStyle:s,link:x(e,"Link"),text:x(e,"Text")}},1,a)),1,null),n("div",null,{class:"grid grid-cols-3 items-center justify-evenly bg-white px-3 py-1 min-[800px]:flex"},[n("button",null,{class:"mx-4 flex h-fit w-fit items-center justify-center rounded-3xl bg-primary-blue p-2 active:bg-primary-light-blue min-[800px]:hidden"},n("div",null,{onClick$:I("s_EXeZ7SCEUFc",[t])},i(Od,{class:"fill-white object-fill min-[800px]:hidden",[s]:{class:s}},3,"Qt_1"),1,null),1,null),n("div",null,{class:"flex items-center justify-center"},n("div",null,{class:"w-[125px] py-1"},i(wt,{children:i(P,{get media(){return t.data.MainMenu.Logo.data.attributes},height:80,width:150,[s]:{height:s,media:u(e=>e.data.MainMenu.Logo.data.attributes,[t],'p0.data["MainMenu"]["Logo"]["data"]["attributes"]'),width:s}},3,"Qt_2"),link:"/",[s]:{link:s}},1,"Qt_3"),1,null),1,null),n("div",null,{class:"flex items-center justify-center gap-4 px-3 text-[15px] max-[1200px]:text-[13px] max-[800px]:hidden"},t.data.MainOptions.map(function(e,a){W();const l=e.SubOption.length>0;return n("div",null,{class:" font-bold text-primary-blue "},l?i(ga,{get title(){return e.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},e.SubOption.map((r,o)=>{W();const c=r.MenuOption.data;return c?i(ga,{get title(){return r.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},c.attributes.SubOption.map((d,p)=>i(wt,{get link(){return d.Link},children:_(d,"Text"),[s]:{link:x(d,"Link")}},1,p)),1,null),[s]:{title:x(r,"Text")}},1,"Qt_5"):i(wt,{classN:"text-primary-blue",get link(){return r.Link},children:_(r,"Text"),hasStyle:!1,[s]:{classN:s,hasStyle:s,link:x(r,"Link")}},1,o)}),1,null),[s]:{title:x(e,"Text")}},1,"Qt_6"):i(wt,{classN:"text-primary-blue",get link(){return e.Link},children:_(e,"Text"),hasStyle:!1,[s]:{classN:s,hasStyle:s,link:x(e,"Link")}},1,"Qt_4"),1,a)}),1,null),n("div",null,{class:"flex items-center justify-center"},i(Wd,{get data(){return t.data.MainMenu.Switcher},[s]:{data:u(e=>e.data.MainMenu.Switcher,[t],'p0.data["MainMenu"]["Switcher"]')}},3,"Qt_7"),1,null)],1,null)],1,null),n("div",null,{class:"mt-[89px] flex h-[32px] flex-row items-center justify-center gap-6 bg-secondary-red py-[2px] text-[14px] font-semibold tracking-[1px] text-white max-sm:text-[11px]"},t.data.ClientOptions.map((e,a)=>i(wt,{get link(){return e.Link},children:_(e,"Text"),[s]:{link:x(e,"Link")}},1,a)),1,null),n("div",null,{class:"flex flex-row items-center justify-evenly bg-white py-1 max-[800px]:hidden"},t.data.gigfastOptions.map((e,a)=>i(wt,{get link(){return e.Link},children:n("div",null,{class:"w-[130px] rounded-md p-1 hover:bg-slate-50"},i(P,{get media(){return e.Icon.data.attributes},height:"60",width:"311",[s]:{height:s,media:x(e.Icon.data,"attributes"),width:s}},3,"Qt_8"),1,null),[s]:{link:x(e,"Link")}},1,a)),1,null)],1,"Qt_9"),Ip=m(g(Bp,"s_qJ0s4sH5iHo")),Op=t=>{W();const e=O(!1);return n("div",null,{class:"my-8 mb-2 w-full"},[n("div",{class:`flex cursor-pointer flex-row items-center transition ${t.inFooter??!1?"":e.value?"rounded-b-none rounded-t-2xl":"rounded-full"} justify-between ${t.classContainer} p-2 `},{onClick$:I("s_n7LVHyx9gZ0",[e])},[n("h3",null,{class:"flex w-full items-center justify-center font-bold"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:u(a=>`flex h-[20px] w-[20px] items-center justify-center ${a.inFooter??!1?"":"rounded-full bg-secondary-red text-white"}`,[t],'`flex h-[20px] w-[20px] items-center justify-center ${p0.inFooter??false?"":"rounded-full bg-secondary-red text-white"}`')},n("span",null,{class:"w-1/8 flex items-center justify-end text-xs"},u(a=>a.value?"▲":"▼",[e],'p0.value?"▲":"▼"'),3,null),3,null)],3,null),e.value&&n("div",null,{class:u(a=>`${a.classChild} ${a.inFooter??!1?"":"rounded-b-2xl rounded-t-none border-t-2 bg-white"} p-2 text-center transition-all duration-500 ease-in-out`,[t],'`${p0.classChild} ${p0.inFooter??false?"":"rounded-b-2xl rounded-t-none border-t-2 bg-white"} p-2 text-center transition-all duration-500 ease-in-out`')},i(it,null,3,"vV_0"),1,"vV_1")],1,"vV_2")},_e=m(g(Op,"s_znBlgckysPY")),Ap=()=>{const[t]=X();if(t.link){if(t.link.includes("http"))return window.open(t.link,"_blank");window.location.href=t.link}(t.onClick??(()=>{}))()},Np=t=>{var a;W();const e=g(Ap,"s_5VUQoQPBpDA",[t]);return(t.type??"link")==="link"?(a=t.link)!=null&&a.startsWith("=")&&t.link?i(xa,{get link(){return t.link},get text(){return t.text},[s]:{link:u(l=>l.link,[t],"p0.link"),text:u(l=>l.text,[t],"p0.text")}},3,"ky_0"):n("div",null,{class:"flex w-fit items-center justify-center rounded-full border-2 border-teal-500 border-opacity-70 bg-white p-0.5 px-1 text-btn-green opacity-90 shadow-md transition transition-all delay-150 ease-in-out hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:I("s_v30BEZ050tM",[e])},[n("p",null,{class:"min-sm:text-[13px] mx-2 text-[15px] font-[600] tracking-wide max-md:text-[14px] "},u(l=>l.text,[t],"p0.text"),3,null),n("div",null,{class:"flex h-[25px] w-[25px] items-center justify-center rounded-full bg-teal-500 p-0 opacity-70 "},i(Vd,{class:"fill-white font-bold",[s]:{class:s}},3,"ky_1"),1,null)],1,"ky_2"):n("div",null,{class:"text-btn-white flex w-fit items-center justify-center  rounded-full bg-teal-500 p-1 px-1 opacity-90 shadow-md transition transition-all  delay-150  ease-in-out hover:cursor-pointer hover:bg-teal-600",onClick$:I("s_eSPP9CLbtZw",[e])},[n("p",null,{class:"min-sm:text-[13px] mx-2 text-[15px] font-[600] tracking-wide  text-white max-md:text-[14px] "},u(l=>l.text,[t],"p0.text"),3,null),n("div",null,{class:"flex h-[25px] w-[25px] items-center justify-center rounded-full bg-white p-0 opacity-60 opacity-70 "},i(Qr,{class:"w-[12px] fill-teal-500",[s]:{class:s}},3,"ky_3"),1,null)],1,"ky_4")},Z=m(g(Np,"s_FRLwbQyPTTI")),Rp=t=>n("div",null,{class:"",id:"footer"},[n("div",null,{class:"flex flex-col items-center bg-primary-blue px-4 py-3 text-white"},[n("p",null,{class:"text-[22px] font-semibold"},u(e=>e.data.SupportSection.Title,[t],'p0.data["SupportSection"]["Title"]'),3,null),n("p",null,{class:"text-s lm:w-1/2 text-center sm:w-3/4"},u(e=>e.data.SupportSection.Paragraph,[t],'p0.data["SupportSection"]["Paragraph"]'),3,null)],3,null),n("div",null,{class:"flex flex-col flex-wrap justify-around bg-primary-dark-blue px-3 py-3 text-white lg:flex-row"},[n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"mb-4 w-[180px]"},i(P,{height:359,width:970,get media(){return t.data.CorpInfo.Media.data.attributes},[s]:{height:s,media:u(e=>e.data.CorpInfo.Media.data.attributes,[t],'p0.data["CorpInfo"]["Media"]["data"]["attributes"]'),width:s}},3,"Zn_0"),1,null),n("p",null,{class:"mb-4 max-w-sm text-center"},u(e=>e.data.CorpInfo.Paragraph,[t],'p0.data["CorpInfo"]["Paragraph"]'),3,null),i(Z,{type:"action",get link(){return t.data.CorpInfo.Buttons[0].Link},get text(){return t.data.CorpInfo.Buttons[0].Text},[s]:{link:u(e=>e.data.CorpInfo.Buttons[0].Link,[t],'p0.data["CorpInfo"]["Buttons"][0]["Link"]'),text:u(e=>e.data.CorpInfo.Buttons[0].Text,[t],'p0.data["CorpInfo"]["Buttons"][0]["Text"]'),type:s}},3,"Zn_1")],1,null),n("div",null,{class:"container sm:hidden"},t.data.Menus.map((e,a)=>i(_e,{inFooter:!0,get title(){return e.Text},children:e.SubOption.map((l,r)=>i(Gt,{get href(){return l.Link},children:n("p",null,null,_(l,"Text"),1,null),class:"mb-4 hover:text-blue-600",[s]:{class:s,href:x(l,"Link")}},1,r)),classContainer:"text-xl text-primary-light-blue font-semibold border-b-2 border-t-2 border-primary-light-blue",[s]:{classContainer:s,inFooter:s,title:x(e,"Text")}},1,a)),1,null),n("div",null,{class:"flex justify-around"},t.data.Menus.map((e,a)=>n("div",null,{class:"hidden w-1/4 sm:block"},[n("p",null,{class:"text-2xl text-primary-light-blue font-semibold"},_(e,"Text"),1,null),e.SubOption.map((l,r)=>i(Gt,{get href(){return l.Link},children:n("p",null,null,_(l,"Text"),1,null),class:"hover:text-blue-600",[s]:{class:s,href:x(l,"Link")}},1,r))],1,a)),1,null)],1,null),n("div",null,{class:"flex flex-col items-center gap-2 bg-primary-dark-blue px-4 py-4 text-white"},[n("p",null,{class:"text-[14px]"},u(e=>e.data.SocialMedia.Text,[t],'p0.data["SocialMedia"]["Text"]'),3,null),n("div",null,{class:"flex flex-row gap-4"},t.data.SocialMedia.SubOption.map((e,a)=>W(i(Gt,{get href(){return e.Link},children:[e.Link.includes("facebook")&&n("div",null,{class:"flex h-7 w-7 items-center justify-center rounded-full bg-primary-blue p-2"},i(P,{height:20,width:20,get media(){return e.Icon.data.attributes},toWhite:!0,[s]:{height:s,media:x(e.Icon.data,"attributes"),toWhite:s,width:s}},3,"Zn_2"),1,"Zn_3"),!e.Link.includes("facebook")&&n("div",null,{class:"flex h-7 w-7 items-center justify-center rounded-full bg-primary-blue p-1"},i(P,{height:20,width:20,get media(){return e.Icon.data.attributes},toWhite:!0,[s]:{height:s,media:x(e.Icon.data,"attributes"),toWhite:s,width:s}},3,"Zn_4"),1,"Zn_5")],[s]:{href:x(e,"Link")}},1,a))),1,null)],1,null)],1,"Zn_6"),qp=m(g(Rp,"s_ecsQS6so2H0")),Fp=t=>n("div",{class:`flex list-outside flex-col gap-3 text-primary-blue [&>*>a]:text-secondary-red min-[1000px]:[&>h1]:text-[45px] [&>h1]:text-[15px] [&>h1]:leading-tight [&>h1]:font-[400] [&>h2]:text-[26px] [&>h3]:text-[26px] [&>ul]:flex [&>ul]:flex-col [&>ul]:gap-3  ${t.classN??""}`,dangerouslySetInnerHTML:fs(t.text)},null,null,3,"Cb_0"),C=m(g(Fp,"s_RjmVkFh5HBg")),Yr=({qty:t})=>{if(t!==void 0)return t;if(typeof window<"u"){const e=window.innerWidth;return e>1200?3:e>800?2:1}else return 1},zp=()=>{const[t,e]=X();t.value=Yr({qty:e})},Gp=()=>{const[t]=X();t()},Qp=({slidesQty:t})=>{const e=O(Yr({qty:t})),a=g(zp,"s_zVG057gY2pI",[e,t]);return yt(I("s_hQsoJzDpgeo",[a])),_i("resize",g(Gp,"s_WB2t7tmOijA",[a])),e},Hp=t=>{const e=Qp({slidesQty:t.slidesQty});return yt(I("s_xmo13ab0hsk",[e,t])),i(Q,{children:n("section",null,{"aria-label":"Componente Carousel",class:"splide max-w-screen overflow-hidden",id:u(a=>`${a.id?a.id:""}`,[t],'`${p0.id?p0.id:""}`')},n("div",null,{class:u(a=>` splide__track  ${a.addSpace??!0?"p-8":""}`,[t],'` splide__track  ${p0.addSpace??true?"p-8":""}`')},n("div",null,{class:"splide__list justify-between "},t.slides.map((a,l)=>n("div",null,{class:"splide__slide w-full items-center"},n("div",null,{class:u(r=>`${r.fillSlide??!1?"w-full h-full object-cover":"object-center"} flex items-center  ${r.addSpace??!0?"mx-10":""}  justify-center`,[t],'`${p0.fillSlide??false?"w-full h-full object-cover":"object-center"} flex items-center  ${p0.addSpace??true?"mx-10":""}  justify-center`')},a,1,null),1,l)),1,null),1,null),1,null)},1,"cE_0")},Pt=m(g(Hp,"s_UuwASfcxtbw")),Wp=()=>{const[t]=X();t.value=!0},Up=t=>{const[e,a]=X();return W(),yt(I("s_4GZYBHap0Wg",[e,t])),n("div",null,{class:"flex flex-col items-center justify-between"},[n("div",null,{class:"z-20 mb-1 flex flex-col justify-center"},[n("span",null,{class:"text-center text-[20px] font-semibold"},u(l=>l.slide.Title,[t],'p0.slide["Title"]'),3,null),n("span",null,{class:"text-[14px] font-light"},i(C,{classN:"text-white",get text(){return t.slide.Paragraph},[s]:{classN:s,text:u(l=>l.slide.Paragraph,[t],'p0.slide["Paragraph"]')}},3,"DG_0"),1,null)],1,null),t.slide.Buttons[0].Link.includes("=pConf=")?i(Z,{get text(){return t.slide.Buttons[0].Text},onClick:a,[s]:{onClick:s,text:u(l=>l.slide.Buttons[0].Text,[t],'p0.slide["Buttons"][0]["Text"]')}},3,t.index):i(Z,{get link(){return t.slide.Buttons[0].Link},get text(){return t.slide.Buttons[0].Text},[s]:{link:u(l=>l.slide.Buttons[0].Link,[t],'p0.slide["Buttons"][0]["Link"]'),text:u(l=>l.slide.Buttons[0].Text,[t],'p0.slide["Buttons"][0]["Text"]')}},3,t.index)],1,"DG_1")},Yp=t=>{W();const e=O(!1),a=O(!1),l=g(Wp,"s_vj08LuDnaHY",[e]),r=Jt({url:""}),o=m(g(Up,"s_3lZ1awB53As",[r,l])),c=t.data.Slide.map((d,p)=>i(o,{index:p,slide:d},3,p));return n("div",null,{class:"mb-4 flex w-[40%] min-w-[350px] max-w-[500px] flex-col items-center justify-center overflow-hidden rounded-full rounded-t-none bg-[#0E4FB0] px-8 py-1 text-white max-[400px]:w-[98%] max-[400px]:min-w-[200px] max-[400px]:pb-10 "},[i(Pt,{addSpace:!1,duration:4e3,hasPagination:!1,id:"headerCarousel",slides:c,slidesQty:1,[s]:{addSpace:s,duration:s,hasPagination:s,id:s,slidesQty:s}},3,"DG_2"),e.value&&n("div",null,{class:"fixed inset-0 z-[200] flex flex-col items-center justify-center bg-black bg-opacity-40"},n("div",null,{class:"w-full h-full flex-row-reverse  animate-zoomIn flex "},[n("div",null,{class:"flex p-4 flex-wrap overflow-hidden items-center justify-center "},[i(Hr,{get route(){return r.url},[s]:{route:u(d=>d.url,[r],"p0.url")}},3,"DG_3"),a.value&&window.localStorage.getItem("sendform_leaving")!="true"?i(Ur,{signalMainPopup:e,signalPopupLeaving:a,[s]:{signalMainPopup:s,signalPopupLeaving:s}},3,"DG_4"):null],1,null),n("button",null,{"aria-label":"Close popup",class:"mt-2 mx-0 bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] focus:outline-none z-[600]",onClick$:I("s_uXChW58fn0g",[r,e,a])},n("div",null,{class:"px-3 flex flex-row items-center text-xs gap-2"},["Back to site ",i(ql,null,3,"DG_5")],1,null),1,null)],1,null),1,"DG_6")],1,"DG_7")},Vp=m(g(Yp,"s_BIrsaZMr3LY")),Zp=t=>n("div",{class:`fixed left-0 right-0 top-0 z-[500] flex h-screen items-center justify-center bg-primary-dark-blue bg-opacity-30 transition-all duration-300 ${t.showSignal.value?"":"hidden"}`},{id:"modalback",onClick$:I("s_0718nqiE4KE",[t])},[n("div",null,{onClick$:I("s_Wu4a00SV7hw",[t])},i(zd,{class:"absolute right-2 top-2 rounded-full bg-secondary-red p-1 text-[30px] font-[200] text-white hover:cursor-pointer",[s]:{class:s}},3,"kj_0"),1,null),i(it,null,3,"kj_1")],1,"kj_2"),Za=m(g(Zp,"s_oHrF0mun03M")),Xp=t=>{var r;const a=(r=vt().prevUrl)==null?void 0:r.pathname.includes("/es/"),l=O(!1);return n("div",null,{class:"flex flex-col gap-4 px-4 py-6 text-[15px] tracking-tight text-white"},[n("div",null,{class:"text-primary-blue"},i(Za,{children:i(Va,{btnText:a?"Ir ahora":"Go Now",description:a?"Ingrese su código postal.":"Just enter your Zip code.",popup:"login",title:a?"Inicia sesión en el portal de tu zona":"Log into the portal of your area",[s]:{popup:s}},3,"Ux_0"),showSignal:l,[s]:{showSignal:s}},1,"Ux_1"),1,null),t.data.MainOptions.map(function(o,c){W();const d=o.SubOption.length>0;return n("div",null,{class:""},d?i(ga,{get title(){return o.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},o.SubOption.map((p,f)=>{W();const h=p.MenuOption.data;return h?i(ga,{get title(){return p.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},h.attributes.SubOption.map((y,b)=>i(wt,{get link(){return y.Link},children:_(y,"Text"),hasStyle:!1,[s]:{hasStyle:s,link:x(y,"Link")}},1,b)),1,null),[s]:{title:x(p,"Text")}},1,"Ux_4"):p.Link.includes("Login")?n("div",null,{class:"hover:cursor-pointer",onClick$:I("s_SnfOjeOrlzY",[l])},_(p,"Text"),1,"Ux_3"):i(wt,{get link(){return p.Link},children:_(p,"Text"),hasStyle:!1,[s]:{hasStyle:s,link:x(p,"Link")}},1,f)}),1,null),[s]:{title:x(o,"Text")}},1,"Ux_5"):i(wt,{get link(){return o.Link},children:_(o,"Text"),[s]:{link:x(o,"Link")}},1,"Ux_2"),1,c)}),n("div",null,{class:"w-full border border-white border-opacity-40"},null,3,null),n("div",null,{class:"flex w-fit flex-col gap-5"},t.data.gigfastOptions.map((o,c)=>i(wt,{get link(){return o.Link},children:n("div",null,{class:"w-[130px] rounded-md p-1"},i(P,{get media(){return o.Icon.data.attributes},height:"60",width:"311",[s]:{height:s,media:x(o.Icon.data,"attributes"),width:s}},3,"Ux_6"),1,null),classN:"rounded-full bg-white px-4 py-1 shadow-lg",[s]:{classN:s,link:x(o,"Link")}},1,c)),1,null)],1,"Ux_7")},Kp=m(g(Xp,"s_jSaadUqLWqI")),Jp=t=>{W();const e=O(!1);return n("div",null,{class:u(a=>`relative overflow-hidden transition-all duration-500 ${a.value?"overflow-y-hidden":"z-50"}`,[e],'`relative overflow-hidden transition-all duration-500 ${p0.value?"overflow-y-hidden":"z-50"}`'),style:u(a=>a.value?{perspective:"9000px"}:{},[e],'p0.value?{perspective:"9000px"}:{}')},[n("div",null,{class:u(a=>`absolute inset-0 ${a.value?"bg-gradient-to-l from-[#2e599a] to-[#182d4d] ":"bg-white !important"}   ${a.value?"overflow-y-hidden":"z-50"}`,[e],'`absolute inset-0 ${p0.value?"bg-gradient-to-l from-[#2e599a] to-[#182d4d] ":"bg-white !important"}   ${p0.value?"overflow-y-hidden":"z-50"}`')},i(Kp,{get data(){return t.data.data.generalMenu.data.attributes},[s]:{data:u(a=>a.data.data.generalMenu.data.attributes,[t],'p0.data["data"]["generalMenu"]["data"]["attributes"]')}},3,"m8_0"),1,null),n("div",null,{class:u(a=>`relative transition-all duration-500 ${a.value?"overflow-y-hidden":"z-50"}`,[e],'`relative transition-all duration-500 ${p0.value?"overflow-y-hidden":"z-50"}`'),style:u(a=>a.value?{transform:"rotateY(-30deg) translateX(250px) translateY(200px)",transformStyle:"preserve-3d"}:{},[e],'p0.value?{transform:"rotateY(-30deg) translateX(250px) translateY(200px)",transformStyle:"preserve-3d"}:{}')},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-10 bg-gradient-to-l from-[#FFFFFF] to-[#C8D8ED]"},null,3,null),(t.showMenus??!0)&&i(Ip,{get data(){return t.data.data.generalMenu.data.attributes},mobMenuOpen:e,[s]:{data:u(a=>a.data.data.generalMenu.data.attributes,[t],'p0.data["data"]["generalMenu"]["data"]["attributes"]'),mobMenuOpen:s}},3,"m8_1"),n("div",null,{class:u(a=>`${a.value?"overflow-y-hidden":""}`,[e],'`${p0.value?"overflow-y-hidden":""}`')},[(t.showHeader??!0)&&n("div",null,{class:"flex w-full items-center justify-center"},i(Vp,{get data(){return t.data.data.generalHeader.data.attributes},[s]:{data:u(a=>a.data.data.generalHeader.data.attributes,[t],'p0.data["data"]["generalHeader"]["data"]["attributes"]')}},3,"m8_2"),1,"m8_3"),n("div",null,{class:"relative"},i(it,null,3,"m8_4"),1,null),(t.showMenus??!0)&&i(qp,{get data(){return t.data.data.generalFooter.data.attributes},[s]:{data:u(a=>a.data.data.generalFooter.data.attributes,[t],'p0.data["data"]["generalFooter"]["data"]["attributes"]')}},3,"m8_5")],1,null)],1,null)],1,"m8_6")},F=m(g(Jp,"s_vumpf0PbXbo")),t0=t=>{const e=t.customText?t.customText:t.SEOdata.MetaTitle.split(" |")[0];return!t.SEOdata&&!t.customText?n("h1",null,{class:"absolute opacity-0"},"RTA",3,"Yj_0"):n("h1",null,{class:"absolute opacity-0"},e,1,"Yj_1")},K=m(g(t0,"s_SOxRNst40is")),e0=t=>(W(),n("div",{class:`flex w-full flex-col items-center justify-center ${t.alt??!1?"bg-white":"bg-[#e2eefa]"}
        ${t.backgroundColor&&`bg-${t.backgroundColor}`}`},null,[(t.alt??!1)&&i(Q,{children:[n("div",null,{class:"h-8 w-full bg-[#ebf4fc]"},null,3,null),n("div",null,{class:"h-8 w-full bg-[#f7fafe]"},null,3,null)]},3,"9K_0"),n("div",null,{class:u(e=>`my-4 flex ${e.reverse??!1?"flex-row-reverse":""} max-w-[1200px] items-center justify-center max-[800px]:flex-col`,[t],'`my-4 flex ${p0.reverse??false?"flex-row-reverse":""} max-w-[1200px] items-center justify-center max-[800px]:flex-col`')},[n("div",null,{class:u(e=>`flex ${e.image&&`min-[800px]:w-[${(e.textPercentage??70).toString()}%]`}  flex-col items-center justify-center gap-4 px-10`,[t],"`flex ${p0.image&&`min-[800px]:w-[${(p0.textPercentage??70).toString()}%]`}  flex-col items-center justify-center gap-4 px-10`")},[t.logo&&n("div",null,{class:"max-w-[470px]"},i(P,{get media(){return t.logo},height:"230",width:"1230",[s]:{height:s,media:u(e=>e.logo,[t],"p0.logo"),width:s}},3,"9K_1"),1,"9K_2"),n("div",null,{class:u(e=>`flex ${!(e.hasPricing??!0)&&"flex-col"} justify-center gap-2 text-${e.color??"primary-blue"}`,[t],'`flex ${!(p0.hasPricing??true)&&"flex-col"} justify-center gap-2 text-${p0.color??"primary-blue"}`')},[t.title&&n("h2",null,{class:"text-center text-[38px]  font-bold max-sm:text-[28px]"},u(e=>e.title,[t],"p0.title"),3,"9K_3"),t.subtitle&&n("h3",{class:`text-[28px] font-bold
                  ${t.backgroundColor&&t.backgroundColor.trim()!=="transparent"?"text-white":"text-secondary-red"}
                  ${t.hasPricing??!0?"":"text-center "} max-sm:text-[20px]`},null,u(e=>e.subtitle,[t],"p0.subtitle"),3,"9K_4")],1,null),i(C,{get text(){return t.text},get classN(){return`text-[18px] max-sm:text-[15px] text-${t.color??"primary-blue"}`},[s]:{classN:u(e=>`text-[18px] max-sm:text-[15px] text-${e.color??"primary-blue"}`,[t],'`text-[18px] max-sm:text-[15px] text-${p0.color??"primary-blue"}`'),text:u(e=>e.text,[t],"p0.text")}},3,"9K_5"),n("div",null,{class:"flex gap-4"},t.buttons&&t.buttons.map((e,a)=>i(Z,{get text(){return e.Text},get link(){return e.Link},children:i(Rd,{class:"text-[21px] opacity-60",color:"#13B295",[s]:{class:s,color:s}},3,"9K_6"),type:e.Link.startsWith("tel:")?"action":"link",[s]:{link:x(e,"Link"),text:x(e,"Text")}},1,a)),1,null)],1,null),t.image&&n("div",null,{class:u(e=>`flex items-center justify-center self-center ${e.imageLink&&"cursor-pointer"}`,[t],'`flex items-center justify-center self-center ${p0.imageLink&&"cursor-pointer"}`'),onClick$:I("s_0a2swupHwgA",[t])},n("div",null,{class:"flex md:w-[400px] w-[350px] items-center justify-center self-center p-4"},i(P,{get media(){return t.image},height:"400",width:"400",[s]:{height:s,media:u(e=>e.image,[t],"p0.image"),width:s}},3,"9K_7"),1,null),1,"9K_8"),t.customComponent&&n("div",null,{class:u(e=>`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${(100-(e.textPercentage??70)).toString()}%]`,[t],"`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${(100-(p0.textPercentage??70)).toString()}%]`")},u(e=>e.customComponent,[t],"p0.customComponent"),3,"9K_9")],1,null),(t.alt??!1)&&i(Q,{children:[n("div",null,{class:"h-8 w-full bg-[#f7fafe]"},null,3,null),n("div",null,{class:"h-8 w-full bg-[#ebf4fc]"},null,3,null)]},3,"9K_10")],1,"9K_11")),kt=m(g(e0,"s_QAc0HW5bNAE")),a0=t=>i(kt,{get logo(){return t.data.Logo&&t.data.Logo.data&&t.data.Logo.data.attributes},get image(){return t.data.Media&&t.data.Media.data&&t.data.Media.data.attributes},get title(){return t.data.Title},get subtitle(){return t.data.Subtitle},get text(){return t.data.Paragraph},get buttons(){return t.data.Buttons},get reverse(){return t.reverse??!1},get color(){return t.color??"primary-blue"},get alt(){return t.alt??!1},get hasPricing(){return t.hasPricing??!0},get textPercentage(){return t.textPercentage??70},get customComponent(){return t.customComponent},get backgroundColor(){return t.backgroundColor},imageLink:t.data.Media&&t.data.Media.data&&t.data.Media.data.attributes.caption.includes("http")?t.data.Media.data.attributes.caption:t.imageLink,[s]:{alt:u(e=>e.alt??!1,[t],"p0.alt??false"),backgroundColor:u(e=>e.backgroundColor,[t],"p0.backgroundColor"),buttons:u(e=>e.data.Buttons,[t],'p0.data["Buttons"]'),color:u(e=>e.color??"primary-blue",[t],'p0.color??"primary-blue"'),customComponent:u(e=>e.customComponent,[t],"p0.customComponent"),hasPricing:u(e=>e.hasPricing??!0,[t],"p0.hasPricing??true"),image:u(e=>e.data.Media&&e.data.Media.data&&e.data.Media.data.attributes,[t],'p0.data["Media"]&&p0.data["Media"]["data"]&&p0.data["Media"]["data"]["attributes"]'),logo:u(e=>e.data.Logo&&e.data.Logo.data&&e.data.Logo.data.attributes,[t],'p0.data["Logo"]&&p0.data["Logo"]["data"]&&p0.data["Logo"]["data"]["attributes"]'),reverse:u(e=>e.reverse??!1,[t],"p0.reverse??false"),subtitle:u(e=>e.data.Subtitle,[t],'p0.data["Subtitle"]'),text:u(e=>e.data.Paragraph,[t],'p0.data["Paragraph"]'),textPercentage:u(e=>e.textPercentage??70,[t],"p0.textPercentage??70"),title:u(e=>e.data.Title,[t],'p0.data["Title"]')}},3,"9K_12"),qt=m(g(a0,"s_Itm0b43i6oU")),l0=t=>i(Q,{children:t.data.map((e,a)=>i(qt,{alt:a%2===0,data:e,reverse:a%2===0,get color(){return t.color??"primary-blue"},[s]:{color:u(l=>l.color??"primary-blue",[t],'p0.color??"primary-blue"')}},3,a))},1,"9K_13"),oe=m(g(l0,"s_0DQ5Kmfc4bA")),n0=t=>n("div",null,{class:"flex max-w-[1200px] items-center justify-center self-center max-[800px]:flex-col"},[n("div",null,{class:"flex w-[300px] flex-col items-center justify-center self-center p-4 min-[800px]:w-[40%]"},[n("iframe",null,{allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",allowFullscreen:!0,class:"mb-5 rounded-[30px] shadow-md",frameBorder:"0",height:"250px",src:u(e=>`https://www.youtube.com/embed/${e.video.Link.split("v=")[1]}`,[t],'`https://www.youtube.com/embed/${p0.video["Link"].split("v=")[1]}`'),width:"100%"},null,3,null),i(C,{get text(){return t.video.Paragraph},classN:"px-3 max-sm:text-[14px] text-[16px] text-primary-blue text-justify",[s]:{classN:s,text:u(e=>e.video.Paragraph,[t],'p0.video["Paragraph"]')}},3,"tX_0")],1,null),n("div",null,{class:"flex flex-col items-center justify-center gap-4 px-10 min-[800px]:w-[60%]"},[n("h3",null,{class:"text-center text-[38px] font-bold text-primary-blue max-sm:text-[28px]"},u(e=>e.info.Title,[t],'p0.info["Title"]'),3,null),n("h4",null,{class:"text-center text-[38px] font-bold text-secondary-red max-sm:text-[28px]"},u(e=>e.info.Subtitle,[t],'p0.info["Subtitle"]'),3,null),n("div",null,null,i(C,{classN:"max-sm:text-[15px] text-[18px] text-primary-blue",get text(){return t.info.Paragraph},[s]:{classN:s,text:u(e=>e.info.Paragraph,[t],'p0.info["Paragraph"]')}},3,"tX_1"),1,null)],1,null)],1,"tX_2"),s0=m(g(n0,"s_ndQUOpucQqo")),r0=t=>n("div",null,{class:"relative flex h-full w-full items-center justify-center overflow-hidden"},[!(t.isFirst??!1)&&n("div",null,{class:"absolute bottom-[calc(50%+20px)] top-0 border-l-2 border-secondary-red"},null,3,"9r_0"),!(t.isLast??!1)&&n("div",null,{class:"absolute bottom-0 top-[calc(50%+20px)] border-l-2 border-secondary-red"},null,3,"9r_1"),n("div",null,{class:"flex h-[36px] w-[36px] items-center justify-center self-center rounded-full border border-secondary-red bg-transparent"},n("div",null,{class:"flex h-[30px] w-[30px] items-center justify-center rounded-full bg-secondary-red text-white"},u(e=>e.caption,[t],"p0.caption"),3,null),3,null)],1,"9r_2"),i0=t=>{const e=m(g(r0,"s_2AZJZ0GqJyo"));return(t.direction??"vertical")==="vertical"?n("div",null,{class:"grid w-fit items-center justify-around",style:u(a=>({gridTemplateColumns:(a.align??"start")==="center"?"1fr 60px 1fr":(a.align??"start")==="end"?"1fr 60px":"60px 1fr"}),[t],'{gridTemplateColumns:(p0.align??"start")==="center"?"1fr 60px 1fr":(p0.align??"start")==="end"?"1fr 60px":"60px 1fr"}')},t.steps.map((a,l)=>W(i(Q,{children:[(t.align??"start")!=="center"&&i(Q,{children:[(t.align??"start")==="start"&&i(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_3"),n("div",null,{class:u(r=>`my-[20px] ${(r.align??"start")==="end"&&"ml-auto"} flex w-full flex-row items-center justify-center rounded-[50px] bg-white p-6 shadow-xl`,[t],'`my-[20px] ${(p0.align??"start")==="end"&&"ml-auto"} flex w-full flex-row items-center justify-center rounded-[50px] bg-white p-6 shadow-xl`')},i(C,{classN:"text-center",text:a,[s]:{classN:s}},3,"9r_4"),1,l),(t.align??"start")==="end"&&i(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_5")]},1,"9r_6"),(t.align??"start")==="center"&&i(Q,{children:[n("div",null,{class:"flex w-fit flex-row items-center rounded-[50px] bg-white px-6 py-10 shadow-lg"},i(C,{classN:"text-center",text:a,[s]:{classN:s}},3,"9r_7"),1,l),l%2===0?i(Q,{children:[i(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_8"),n("div",null,null,null,3,null),n("div",null,null,null,3,null),l+1<t.steps.length&&i(e,{caption:(l+2).toString(),isLast:l===t.steps.length},3,"9r_9")]},1,"9r_10"):i(Q,null,3,"9r_11")]},1,"9r_12")]},1,"9r_13"))),1,"9r_14"):n("div",null,{class:"flex flex-row justify-between"},t.steps.map((a,l)=>n("div",null,{class:"flex flex-col items-center"},[n("div",null,{class:"h-2 w-2 rounded-full bg-primary-blue"},null,3,null),n("div",null,{class:"text-primary-blue"},a,1,null)],1,l)),1,null)},qe=m(g(i0,"s_Zd6X64AupUo")),o0=t=>{const e=t.data.pageAcp.data.attributes,a=e.Steps.Bullets.map(l=>l.Text);return n("div",null,{onClick$:I("s_ey5yETkFTzM")},[i(qt,{get data(){return e.SummaryPar},alt:!0,hasPricing:!1,textPercentage:50,[s]:{alt:s,data:x(e,"SummaryPar"),hasPricing:s,textPercentage:s}},3,"ai_0"),n("div",null,{class:"flex w-full items-center justify-center"},i(s0,{get info(){return e.InfoHowItWorks},get video(){return e.ACPVideo},[s]:{info:x(e,"InfoHowItWorks"),video:x(e,"ACPVideo")}},3,"ai_1"),1,null),n("div",null,{class:"mt-5 flex flex-col items-center justify-center bg-[#f2f6fb] pb-8"},[n("div",null,{class:"h-[32px] w-full bg-white opacity-70"},null,3,null),n("div",null,{class:"h-[32px] w-full bg-white opacity-40"},null,3,null),n("h2",null,{class:"px-6 pt-8 text-center text-[36px] font-[500] leading-9 text-primary-blue"},_(e.Steps,"Title"),1,null),n("div",null,{class:"px-6"},i(qe,{steps:a},3,"ai_2"),1,null)],1,null)],1,"ai_3")},u0=m(g(o0,"s_00vzGmbsaMs")),c0=t=>`
  query QueryACP {
    pageAcp(locale:"${t}"){    
      data{
        attributes{
        
          SummaryPar{
            Title
            Subtitle
            Paragraph
            Media{
              ${$}
            }
          }
          
          ACPVideo{
            Link
            Paragraph
          }
          
          InfoHowItWorks{
            Title
            Subtitle
            Paragraph
          
          }
          
          Steps{
            Title
            Bullets{
              Title
              Text
            }
          }
          
          ${q}
        }
      }
    }
  }
    `,d0=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(c0,e)},zl=N(g(d0,"s_R1neS1rgBX0")),p0=()=>{const t=zl();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageAcp.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAcp.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAcp"]["data"]["attributes"]["SEO"]')}},3,"lm_0"),i(u0,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"lm_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"lm_2")},f0=m(g(p0,"s_clXmi6bmYdI")),g0=({resolveValue:t})=>{const a=t(zl).pageData.data.pageAcp.data.attributes.SEO;return G(a)},x0=Object.freeze(Object.defineProperty({__proto__:null,default:f0,head:g0,usePageData:zl},Symbol.toStringTag,{value:"Module"})),m0=t=>{W();const e=O(!0);return n("div",null,{class:"h-[550px] w-full  flex flex-col items-center justify-center"},[e.value?i(ne,{size:"250px",[s]:{size:s}},3,"a3_0"):null,n("iframe",null,{class:"w-3/4 my-4 h-full rounded-3xl",id:"iframe-appre-giveaway",loading:"lazy",onLoad$:I("s_b0xkTBodv54",[e]),src:u(a=>a.data.iFrame_link,[t],'p0.data["iFrame_link"]')},null,3,null)],1,"a3_1")},h0=m(g(m0,"s_VzseIswtUxM")),$0=t=>`query QueryAprGive {
        pageAprGive(locale:"${t}"){
          data{
            attributes{
              iFrame_link
              ${q}
            }
          }
        }
        }`,b0=async t=>{const e=t.params.lang==""?"en":"es-419";return await z($0,e)},Gl=N(g(b0,"s_xcQxq8lbgb0")),y0=()=>{const t=Gl();return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageAprGive.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAprGive.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAprGive"]["data"]["attributes"]["SEO"]')}},3,"kA_0"),i(h0,{get data(){return t.value.pageData.data.pageAprGive.data.attributes},[s]:{data:u(e=>e.value.pageData.data.pageAprGive.data.attributes,[t],'p0.value["pageData"]["data"]["pageAprGive"]["data"]["attributes"]')}},3,"kA_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"kA_2")},1,"kA_3")},v0=m(g(y0,"s_Py5O2s07X3c")),w0=({resolveValue:t})=>{const a=t(Gl).pageData.data.pageAprGive.data.attributes.SEO;return G(a)},_0=Object.freeze(Object.defineProperty({__proto__:null,default:v0,head:w0,usePageData:Gl},Symbol.toStringTag,{value:"Module"})),S0=t=>{W();const e=t.data.data.pageAprLead.data.attributes,a=O(!0);return n("div",null,{class:"flex flex-wrap px-8 items-center justify-center"},[n("div",null,{class:"flex flex-col items-center justify-center w-full md:w-1/2"},[n("div",null,{class:"relative h-[600px] w-[80%] flex flex-col items-center justify-center"},[i(P,{get media(){return e.zane_lead.bg_pic.data.attributes},height:"650",width:"650",[s]:{height:s,media:x(e.zane_lead.bg_pic.data,"attributes"),width:s}},3,"q7_0"),i(P,{clasN:"absolute flex rounded-full h-3/4 w-auto",get media(){return e.zane_lead.zane_pic.data.attributes},height:250,width:250,[s]:{clasN:s,height:s,media:x(e.zane_lead.zane_pic.data,"attributes"),width:s}},3,"q7_1"),i(P,{clasN:"absolute h-[10%] w-auto top-20 right-10",get media(){return e.zane_lead.tv_pic.data.attributes},height:"50",width:"50",[s]:{clasN:s,height:s,media:x(e.zane_lead.tv_pic.data,"attributes"),width:s}},3,"q7_2"),i(P,{clasN:"absolute bottom-10 h-[10%] w-auto left-5",get media(){return e.zane_lead.wifi_pic.data.attributes},height:"50",width:"50",[s]:{clasN:s,height:s,media:x(e.zane_lead.wifi_pic.data,"attributes"),width:s}},3,"q7_3"),i(P,{clasN:"absolute top-10 left-10 h-[10%] w-auto",get media(){return e.zane_lead.phone_pic.data.attributes.url},height:"50",width:"50",[s]:{clasN:s,height:s,media:x(e.zane_lead.phone_pic.data.attributes,"url"),width:s}},3,"q7_4"),n("div",null,{class:"absolute left-1/2 top-5 flex flex-row text-primary-blue bg-white items-center justify-center p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},i(P,{height:20,toWhite:!0,width:20,get media(){return e.zane_lead.give_pic.data.attributes},[s]:{height:s,media:x(e.zane_lead.give_pic.data,"attributes"),toWhite:s,width:s}},3,"q7_5"),1,null),"Price"],1,null),n("div",null,{class:"absolute w-fit h-fit bottom-0 left-1/2 flex flex-row text-primary-blue bg-white items-center justify-evenly p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},i(P,{height:20,toWhite:!0,width:20,get media(){return e.zane_lead.auto_pic.data.attributes},[s]:{height:s,media:x(e.zane_lead.auto_pic.data,"attributes"),toWhite:s,width:s}},3,"q7_6"),1,null),"Live Events"],1,null),n("div",null,{class:"absolute w-fit h-fit flex flex-row left-3/4 bottom-1/4 text-primary-blue bg-white items-center justify-evenly p-2 rounded-full"},[n("div",null,{class:"h-[25px] w-[25px] rounded-full  bg-secondary-red p-1"},i(P,{height:20,toWhite:!0,width:20,get media(){return e.zane_lead.cota_pic.data.attributes},[s]:{height:s,media:x(e.zane_lead.cota_pic.data,"attributes"),toWhite:s,width:s}},3,"q7_7"),1,null),"Discounts"],1,null),n("div",null,{class:"absolute w-fit h-fit flex flex-row justify-evenly left-0  text-primary-blue bg-white items-center p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},i(P,{height:20,toWhite:!0,width:20,get media(){return e.zane_lead.auto_pic.data.attributes},[s]:{height:s,media:x(e.zane_lead.auto_pic.data,"attributes"),toWhite:s,width:s}},3,"q7_8"),1,null),"Live Events"],1,null)],1,null),n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,{class:"text-xl text-center font-medium text-primary-blue"},_(e,"zane_description"),1,null),i(P,{get media(){return e.zane_banner.banner_pic.data.attributes},height:"78",width:"400",[s]:{height:s,media:x(e.zane_banner.banner_pic.data,"attributes"),width:s}},3,"q7_9"),n("div",null,{class:"flex flex-row items-center gap-5 justify-evenly my-5"},[n("div",null,{class:"bg-primary-blue text-white flex flex-col rounded-full items-center justify-center w-fit px-10 py-2"},[n("h2",null,{class:"text-sm text-center font-bold"},_(e.date_race,"Text"),1,null),n("p",null,{class:"text-sm text-center"},_(e.date_race,"Link"),1,null)],1,null),i(Z,{get text(){return e.button_promo.text},get link(){return e.button_promo.link},[s]:{link:x(e.button_promo,"link"),text:x(e.button_promo,"text")}},3,"q7_10")],1,null)],1,null)],1,null),n("div",null,{class:"w-full md:w-2/6 shadow-2xl rounded-2xl h-[500px]"},[a.value?i(ne,{size:"250px",[s]:{size:s}},3,"q7_11"):null,n("iframe",{src:_(e,"iFrame_link")},{class:"w-full  rounded-2xl h-full",id:"iframe-appre-lead",loading:"lazy",onLoad$:I("s_M94pZoIEeB0",[a])},null,3,null)],1,null)],1,"q7_12")},T0=m(g(S0,"s_0jvpiBD6mW4")),D0=t=>`query QueryPageAprLead {
        pageAprLead(locale:"${t}"){
          data {
            attributes {
              zane_lead {
                zane_pic {
                    ${$}
                }
                give_pic {
                    ${$}
                }
                cota_pic {
                    ${$}
                }
                auto_pic {
                    ${$}
                }
                live_pic {
                    ${$}
                }
                phone_pic {
                    ${$}
                }
                tv_pic {
                    ${$}
                }
                wifi_pic {
                    ${$}
                }
                bg_pic {
                    ${$}
                }
              }
              zane_banner {
                banner_pic {
                    ${$}
                }
              }
              zane_description
              iFrame_link
              date_race {
                Text
                Link
                Icon {
                  ${$}
                }
              }
              button_promo {
                text
                icon {
                  ${$}
                }
                link
              }
              pricing_box {
                Title
                Subtitle
                Pricing
                Period
                bg {
                  ${$}
                }
                Icon {
                  ${$}
                }
              }
              car {
                car_pic {
                  ${$}
                }
              }
              ${q}
              
            }
          }
        }
      }`,P0=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(D0,e)},Ql=N(g(P0,"s_05Sy9vG0VbY")),k0=()=>{const t=Ql();return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageAprLead.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAprLead.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAprLead"]["data"]["attributes"]["SEO"]')}},3,"LY_0"),i(T0,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"LY_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"LY_2")},1,"LY_3")},L0=m(g(k0,"s_32Qq7YbePEg")),C0=({resolveValue:t})=>{const a=t(Ql).pageData.data.pageAprLead.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},M0=Object.freeze(Object.defineProperty({__proto__:null,default:L0,head:C0,usePageData:Ql},Symbol.toStringTag,{value:"Module"})),j0=t=>n("div",null,{class:"text-center"},[n("div",null,{class:"bg-primary-blue bg-opacity-40 p-6 h-[310px] w-[310px] inline-block items-center justify-center rounded-full"},n("div",null,{class:"bg-primary-blue flex h-full w-full items-center justify-center  rounded-full bg-opacity-60 px-6 py-6 shadow-md"},n("div",null,{class:"bg-primary-blue flex flex-col h-full w-full items-center justify-around rounded-full shadow-md"},[n("div",null,{class:"flex flex-col items-center"},[i(P,{get media(){return t.award.Icon.data.attributes},height:40,width:40,[s]:{height:s,media:u(e=>e.award.Icon.data.attributes,[t],'p0.award["Icon"]["data"]["attributes"]'),width:s}},3,"5M_0"),n("p",null,{class:"text-l text-white font-semibold text-center"},u(e=>e.award.Title,[t],'p0.award["Title"]'),3,null),n("p",null,{class:"text-center text-sm font-light text-white leading-8"},u(e=>e.award.Award,[t],'p0.award["Award"]'),3,null)],1,null),n("a",null,{class:"text-white font-semibold",href:u(e=>e.award.Button.Link,[t],'p0.award["Button"]["Link"]'),target:"_blank"},u(e=>e.award.Button.Text,[t],'p0.award["Button"]["Text"]'),3,null)],1,null),1,null),1,null),n("p",null,{class:"text-3xl font-semibold text-primary-blue"},u(e=>e.award.Year,[t],'p0.award["Year"]'),3,null)],1,"5M_1"),E0=t=>{const e=t.data.data.pageAward.data.attributes,a=m(g(j0,"s_fwfHmjnV3nY")),l=e.Awards.map((r,o)=>i(a,{award:r},3,o));return n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"w-3/4"},[n("h1",null,{class:"text-center text-4xl font-bold text-primary-blue"},_(e,"Title"),1,null),i(C,{classN:"text-center",get text(){return e.Description},[s]:{classN:s,text:x(e,"Description")}},3,"5M_2")],1,null),n("div",null,{class:"w-full h-[500px] relative items-center justify-center overflow-hidden"},[n("div",null,{class:"h-full w-full absolute bg-opacity-50"},i(P,{clasN:"object-fill opacity-50",get media(){return e.Background.data.attributes},height:500,width:1200,[s]:{clasN:s,height:s,media:x(e.Background.data,"attributes"),width:s}},3,"5M_3"),1,null),n("div",null,{class:"h-full w-full flex items-center justify-center absolute"},i(Pt,{duration:3e3,hasPagination:!0,id:"awardsSlider",slides:l,[s]:{duration:s,hasPagination:s,id:s}},3,"5M_4"),1,null)],1,null)],1,"5M_5")},B0=m(g(E0,"s_DHWUiZRKjUc")),I0=t=>`query {
        pageAward(locale:"${t}"){
          data {
            attributes {
              Title
              Description
              
              Background {
                ${$}
              }
              
              Awards {
                Title
                Award
                Year
                Background {
                  ${$}
                }
                Icon {
                  ${$}
                }
                Button{
                  Text
                  Link
                }
              }
      
              ${q}
            }
          }
        }
      }`,O0=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(I0,e)},Hl=N(g(O0,"s_sqeXWQdLNKw")),A0=()=>{const t=Hl();return i(F,{get data(){return t.value.layoutData},children:i(B0,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"Q2_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Q2_1")},N0=m(g(A0,"s_YOAlBnNiDxQ")),R0=({resolveValue:t})=>{const a=t(Hl).pageData.data.pageAward.data.attributes.SEO;return G(a)},q0=Object.freeze(Object.defineProperty({__proto__:null,default:N0,head:R0,usePageData:Hl},Symbol.toStringTag,{value:"Module"})),F0=t=>{const e=(a,l)=>a.slice(0,l)+"...";return n("div",null,{class:"flex max-w-[1200px] flex-row-reverse items-center justify-center self-center px-8 py-4 max-[800px]:flex-col-reverse"},[n("div",null,{class:"flex  flex-col items-center justify-start  gap-4 px-10 min-[800px]:w-[60%]"},[n("div",null,{class:""},[n("div",null,{class:"my-4 text-[32px] font-[600] leading-10 text-[#2E5899] max-sm:text-[24px] max-sm:leading-7"},u(a=>a.post.Title,[t],'p0.post["Title"]'),3,null),n("div",null,null,i(C,{classN:"max-sm:text-[13px] text-[15px] text-[#2E5899] text-justify [&>h1]:text-[15px] [&>h1]:font-[600] [&>h2]:text-[15px] [&>h2]:font-[600] [&>h3]:text-[15px] [&>h3]:font-[600]",text:e(t.post.Description,500),[s]:{classN:s}},3,"su_0"),1,null)],1,null),i(Z,{get text(){return t.isES?"Leer Más":"Read More"},get link(){return`/${t.isES?`es/${[t.post.Slug.replace("-es","")]}`:[t.post.Slug]}`},[s]:{link:u(a=>`/${a.isES?`es/${[a.post.Slug.replace("-es","")]}`:[a.post.Slug]}`,[t],'`/${p0.isES?`es/${[p0.post["Slug"].replace("-es","")]}`:[p0.post["Slug"]]}`'),text:u(a=>a.isES?"Leer Más":"Read More",[t],'p0.isES?"Leer M\\xe1s":"Read More"')}},3,"su_1")],1,null),n("div",null,{class:"flex w-full items-center justify-center self-center p-4 min-[800px]:w-[40%]"},i(P,{get media(){return t.post.Cover.data.attributes},clasN:"rounded-[50px] shadow-2xl",height:"894",width:"1184",[s]:{clasN:s,height:s,media:u(a=>a.post.Cover.data.attributes,[t],'p0.post["Cover"]["data"]["attributes"]'),width:s}},3,"su_2"),1,null)],1,"su_3")},Wl=m(g(F0,"s_KKagOAzP0DM")),z0=t=>{const e=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],a=["January","February","March","April","May","June","July","August","September","October","November","December"];function l(c){const d=e[c.getDay()],p=c.getDate(),f=a[c.getMonth()],h=c.getFullYear();return`${d}, ${f} ${p}, ${h}`}const r=(c,d)=>c.slice(0,d)+"...",o=t.post.attributes.Slug.endsWith("-es");return n("div",null,{class:"mb-8 flex max-w-[300px] flex-col",id:u(c=>c.id,[t],"p0.id")},[i(P,{clasN:"rounded-2xl self-center object-cover h-[200px] w-[300px]",height:"894",width:"1184",get media(){return t.post.attributes.Cover.data.attributes},[s]:{clasN:s,height:s,media:u(c=>c.post.attributes.Cover.data.attributes,[t],'p0.post["attributes"]["Cover"]["data"]["attributes"]'),width:s}},3,"j0_0"),n("h3",null,{class:"px-3 py-1 font-[600] text-[15px] text-primary-blue "},["  ",r(t.post.attributes.Title,60)],1,null),n("span",null,{class:"px-3 text-[12px] font-[700]  text-primary-blue opacity-70"},l(new Date(t.post.attributes.Date)),1,null),n("span",null,{class:"px-3 text-primary-blue"},n("div",{dangerouslySetInnerHTML:fs(r(t.post.attributes.Description,120))},{class:"flex list-inside flex-col gap-3 text-justify text-[14px]"},null,3,null),1,null),n("div",null,{class:"mt-2 self-center"},i(Z,{link:`/${o?`es/${[t.post.attributes.Slug.replace("-es","")]}`:[t.post.attributes.Slug]}`,text:o?"Leer Más":"Read More"},3,"j0_1"),1,null)],1,"j0_2")},G0=m(g(z0,"s_KUqCzJ00kfw")),Q0=t=>{var c;const a=(c=vt().prevUrl)!=null&&c.pathname.includes("/es/")?"es-419":"en",l=O(t.posts.slice(1,(t.loadSize??6)+1)),r=O(!1),o=O(1);return n("div",{"document:onscroll$":I("s_t0DoAQDJl4Y",[a,r,o,t,l])},{class:"grid w-full max-w-[1200px] grid-cols-3 justify-evenly gap-4 px-4 max-[800px]:grid-cols-1 [&>*]:justify-self-center",id:"postLoader"},l.value.map((d,p)=>i(G0,{id:`post-${p.toString()}`,post:d},3,p)),0,"4a_0")},Ul=m(g(Q0,"s_HS0GyQ0UHYM")),H0=t=>n("div",null,{class:"flex flex-col items-center justify-center w-fit "},n("div",null,{class:"  px-2 mb-8  md:max-h-[150px]  overflow-y-scroll"},i(C,{classN:"text-[12.5px]",get text(){return t.slide.attributes.Content},[s]:{classN:s,text:u(e=>e.slide.attributes.Content,[t],'p0.slide["attributes"]["Content"]')}},3,"9l_0"),1,null),1,"9l_1"),W0=t=>{const e=t.data.TechTips.data,a=m(g(H0,"s_0D1CtJAueP4")),l=e.map((r,o)=>i(a,{slide:r},3,o));return n("div",null,{class:" gap-2 flex flex-row bg-white p-3 md:rounded-full rounded-3xl md:w-[750px] w-[90%] shadow-lg items-center"},[n("div",null,null,n("div",null,{class:"bg-[#2e5899] p-5 rounded-full shadow-lg md:min-h-[130px] md:max-w-[130px] md:max-h-[130px] max-w-[80px] flex justify-center items-center max-[768px]:hidden	"},n("div",null,{class:"bg-white md:p-5 p-2 w-fit h-fit items-center rounded-full shadow-lg shadow-inner"},i(Jd,{class:" md:w-[45px] md:h-[45px] w-[20px] h-[20px] fill-[#2e5899]",[s]:{class:s}},3,"9l_2"),1,null),1,null),1,null),n("div",null,{class:" justify-center items-center  md:w-[650px] max-w-[100%]"},[n("div",null,{class:"text-[18px] tracking-wide font-[600] leading-10 text-[#2E5899]"},u(r=>r.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"h-fit relative flex md:w-[650px] max-w-[90%]  items-center justify-center overflow-hidden   "},i(Pt,{addSpace:!1,hasArrows:!1,id:"techTipsCarousel",slides:l,slidesQty:1,[s]:{addSpace:s,hasArrows:s,id:s,slidesQty:s}},3,"9l_3"),1,null)],1,null)],1,"9l_4")},U0=m(g(W0,"s_600c5npFpQo")),Y0=t=>{var o;const a=(o=vt().prevUrl)==null?void 0:o.pathname.includes("/es/"),l=t.data.pageBlog.data.attributes,r=l.Posts.data[0].attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(U0,{get data(){return l.Tips},[s]:{data:x(l,"Tips")}},3,"LH_0"),i(Wl,{isES:a,post:r},3,"LH_1"),n("div",null,{class:"my-4"},null,3,null),i(Ul,{get posts(){return l.Posts.data},loadSize:3,type:"Blog",[s]:{loadSize:s,posts:x(l.Posts,"data"),type:s}},3,"LH_2")],1,"LH_3")},V0=m(g(Y0,"s_lTYqJJcPHc4")),Z0=t=>` query QueryBlog {
        pageBlog(locale:"${t}"){    
          data{
          attributes{
            Tips{
              Title
              TechTips(sort: "Date:desc", pagination: { limit: 10 }){
                data{
                  attributes{
                    Content
                  }
                }
              }
            }
            Posts(sort: "Date:desc", pagination: { limit: 100 }){
                data{
                  attributes{
                    Title
                    Date
                    Cover{
                      ${$}
                    }
                    Description
                    VideoLink
                    Gallery{
                      ${$}
                    }
                    Slug
                  }
                }
              }
          
            ${q}
          }
        }
        }
      }`,X0=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(Z0,e)},Yl=N(g(X0,"s_PlB05JNPqRo")),K0=()=>{const t=Yl();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageBlog.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageBlog.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBlog"]["data"]["attributes"]["SEO"]')}},3,"Yn_0"),i(V0,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Yn_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Yn_2")},J0=m(g(K0,"s_WiOXv30Ec4Y")),tf=({resolveValue:t})=>{const a=t(Yl).pageData.data.pageBlog.data.attributes.SEO;return G(a)},ef=Object.freeze(Object.defineProperty({__proto__:null,default:J0,head:tf,usePageData:Yl},Symbol.toStringTag,{value:"Module"})),af=t=>n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} bg-opacity-40 p-6 ${e.height??""} ${e.width??""} inline-block items-center justify-center rounded-full`,[t],'`${p0.color??"bg-[#2E5899]"} bg-opacity-40 p-6 ${p0.height??""} ${p0.width??""} inline-block items-center justify-center rounded-full`')},n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md`,[t],'`${p0.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md`')},n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md`,[t],'`${p0.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md`')},i(P,{clasN:"h-full w-full rounded-full object-cover",height:250,width:250,get media(){return t.media},[s]:{clasN:s,height:s,media:u(e=>e.media,[t],"p0.media"),width:s}},3,"03_0"),1,null),1,null),1,"03_1"),be=m(g(af,"s_CA0rJqJDom0")),lf=t=>n("div",null,{class:"flex w-fit flex-wrap gap-12 md:gap-20 m-5 items-center justify-center"},t.data.MembersGrid.map((e,a)=>W(n("div",null,{class:"w-[300px] h-[300px] items-center justify-around flex flex-col"},[i(be,{height:"h-[200px]",width:"w-[200px]",get media(){return e.Picture.data.attributes},[s]:{height:s,media:x(e.Picture.data,"attributes"),width:s}},3,"Q1_0"),n("h2",null,{class:"font-bold text-primary-blue text-xl"},[_(e,"FirstName")," ",_(e,"LastName")],1,null),n("p",null,{class:"text-sm text-primary-blue"},_(e,"Position"),1,null),e.SocialMedia.length>0&&n("a",{href:_(e.SocialMedia[0],"Link")},null,n("div",null,{class:"h-[30px] w-[30px] flex items-center justify-center bg-white shadow rounded-full p-1.5"},i(Bd,{class:"fill-primary-blue",[s]:{class:s}},3,"Q1_1"),1,null),1,"Q1_2")],1,a))),1,"Q1_3"),Vr=m(g(lf,"s_fHxbC9gELko")),nf=t=>`query QueryBoardOfDirectors{
        pageBDirectors(locale:"${t}"){
          data{
            attributes{
              ${Rr}
              ${q}
              }
            }
          }
        }`,sf=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(nf,e)},Vl=N(g(sf,"s_zIMYdRdJ00w")),rf=()=>{const t=Vl(),e=t.value.pageData.data.pageBDirectors.data.attributes;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageBDirectors.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageBDirectors.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBDirectors"]["data"]["attributes"]["SEO"]')}},3,"ts_0"),i(Vr,{data:e},3,"ts_1")],showHeader:!0,[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"ts_2")},1,"ts_3")},of=m(g(rf,"s_IBN44L8LT0g")),uf=({resolveValue:t})=>{const a=t(Vl).pageData.data.pageBDirectors.data.attributes.SEO;return G(a)},cf=Object.freeze(Object.defineProperty({__proto__:null,default:of,head:uf,usePageData:Vl},Symbol.toStringTag,{value:"Module"})),df=t=>{const e=t.data.pageBusiness.data.attributes.Services;return n("div",null,null,i(oe,{data:e},3,"zl_0"),1,"zl_1")},pf=m(g(df,"s_u188pr8UG0M")),ff=t=>`query QueryBusiness {
    pageBusiness(locale:"${t}"){    
      data{
        attributes{
          Services{
            Logo{
              ${$}
            }
            Media{
              ${$}
            }
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
             ${q}
  
        }
      }
    }
  }`,gf=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(ff,e)},Zl=N(g(gf,"s_oQUmv8Ne7NI")),xf=()=>{const t=Zl();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageBusiness.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageBusiness.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBusiness"]["data"]["attributes"]["SEO"]')}},3,"Uj_0"),i(pf,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Uj_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Uj_2")},mf=m(g(xf,"s_JufSC5OrOV4")),hf=({resolveValue:t})=>{const a=t(Zl).pageData.data.pageBusiness.data.attributes.SEO;return G(a)},$f=Object.freeze(Object.defineProperty({__proto__:null,default:mf,head:hf,usePageData:Zl},Symbol.toStringTag,{value:"Module"})),bf=t=>n("div",null,{class:"relative flex w-full items-center justify-center"},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 z-10 grid",style:{gridTemplateRows:"35px 35px 1fr 35px 35px",gridTemplateColumns:"100%"}},[n("div",null,{class:"bg-white opacity-50"},null,3,null),n("div",null,{class:"bg-white opacity-80"},null,3,null),n("div",null,{class:"bg-white "},null,3,null),n("div",null,{class:"bg-white opacity-80"},null,3,null),n("div",null,{class:"bg-white opacity-50"},null,3,null)],3,null),n("div",null,{class:"z-10 flex flex-wrap items-center justify-center px-8 text-center text-[30px] font-[700] text-primary-blue"},[i(P,{clasN:"w-[300px] max-[1000px]:hidden",get media(){return t.data.HeaderPictures.data[0].attributes},[s]:{clasN:s,media:u(e=>e.data.HeaderPictures.data[0].attributes,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]')}},3,"bE_0"),n("div",null,{class:"flex flex-col"},[n("span",null,null,"Join the",3,null),i(P,{clasN:"w-[200px]",get media(){return t.data.HeaderLogo.data.attributes},[s]:{clasN:s,media:u(e=>e.data.HeaderLogo.data.attributes,[t],'p0.data["HeaderLogo"]["data"]["attributes"]')}},3,"bE_1"),n("span",null,null,"Family",3,null)],1,null),i(P,{clasN:"w-[300px]",get media(){return t.data.HeaderPictures.data[1].attributes},[s]:{clasN:s,media:u(e=>e.data.HeaderPictures.data[1].attributes,[t],'p0.data["HeaderPictures"]["data"][1]["attributes"]')}},3,"bE_2")],1,null)],1,"bE_3"),yf=m(g(bf,"s_YWCAmY4twe0")),vf=t=>n("div",null,{class:"flex h-[250px] w-[170px] flex-col items-center justify-start gap-3 rounded-[16px] bg-white p-3 text-center shadow-lg"},[i(P,{clasN:"h-[80px] w-[100%] object-cover rounded-[16px] bg-primary-blue bg-opacity-10",get media(){return t.offer.Media.data.attributes},height:"120",width:"240",[s]:{clasN:s,height:s,media:u(e=>e.offer.Media.data.attributes,[t],'p0.offer["Media"]["data"]["attributes"]'),width:s}},3,"IA_0"),n("h3",null,{class:"text-[18px] font-[600]"},u(e=>e.offer.Title,[t],'p0.offer["Title"]'),3,null),n("p",null,{class:"text-[14px] font-[400]"},u(e=>e.offer.Paragraph,[t],'p0.offer["Paragraph"]'),3,null)],1,"IA_1"),wf=t=>{const e=m(g(vf,"s_7vgX9wWJy0Y"));return n("div",null,{class:"flex w-full justify-center px-8"},n("div",null,{class:"mt-10 flex max-w-[1400px] items-center justify-center gap-8 px-8 text-center text-primary-blue max-[1000px]:flex-col"},[n("div",null,{class:"flex w-[50%] flex-col max-[1000px]:w-[100%]"},[n("h3",null,{class:"mt-3 text-[40px] font-[700]"},u(a=>a.data.BeliefsTitle,[t],'p0.data["BeliefsTitle"]'),3,null),n("span",null,{class:"text-[28px] font-[600]"},u(a=>a.data.BeliefsSubtitle,[t],'p0.data["BeliefsSubtitle"]'),3,null),n("span",null,{class:"text-[26px] font-[600] text-secondary-red"},u(a=>a.data.Beliefs[0].Text,[t],'p0.data["Beliefs"][0]["Text"]'),3,null),n("p",null,{class:"mt-3 text-[20px]"},u(a=>a.data.BeliefsDescription,[t],'p0.data["BeliefsDescription"]'),3,null)],3,null),n("div",null,{class:"flex w-[50%] flex-col items-center justify-center max-[1000px]:w-[100%]"},[n("h4",null,{class:"text-[40px] font-[700]"},u(a=>a.data.OfferingTitle,[t],'p0.data["OfferingTitle"]'),3,null),n("div",null,{class:"mt-4 flex flex-wrap justify-center gap-6"},t.data.Offerings.map((a,l)=>i(e,{offer:a},3,l)),1,null)],1,null)],1,null),1,"IA_2")},_f=m(g(wf,"s_rLVOk7WyC5I")),Sf=t=>{const e=O("duties");return n("div",null,{class:"flex w-[60%] min-w-[310px] max-w-[550px] flex-col items-center rounded-[50px] bg-white p-8 text-primary-blue"},[n("div",null,{class:"mb-2 flex items-center gap-1"},[i(Rl,{class:"text-secondary-red",[s]:{class:s}},3,"H3_0"),n("span",null,{class:"text-[14px] opacity-60"},u(a=>a.data.Location,[t],'p0.data["Location"]'),3,null)],1,null),n("h4",null,{class:"mb-4 text-center text-[20px] font-[600] leading-7 text-primary-dark-blue"},u(a=>a.data.Name,[t],'p0.data["Name"]'),3,null),n("div",null,{class:"relative my-4 flex w-[300px] justify-between gap-2 overflow-hidden rounded-[30px] border border-primary-blue border-opacity-60 px-6 py-2"},[n("div",{class:`absolute bottom-0 transition-all ${e.value==="duties"?"left-0 right-[55%]":"left-[45%] right-0"} top-0 z-[1] rounded-[30px] bg-primary-blue shadow-sm`},null,null,3,null),n("div",null,{class:"z-[2] flex w-[45%] cursor-pointer items-center gap-1 px-2",onClick$:I("s_m2mi5sfy3GQ",[e])},[n("div",null,{class:"flex h-6 w-6 items-center justify-center rounded-full bg-white p-1"},i(Ad,{class:"text-secondary-red",[s]:{class:s}},3,"H3_1"),1,null),n("span",null,{class:u(a=>`font-[400] text-${a.value==="duties"?"white":"primary-blue"}`,[e],'`font-[400] text-${p0.value==="duties"?"white":"primary-blue"}`')},"Duties",3,null)],1,null),n("div",null,{class:"z-[2] flex w-[55%] cursor-pointer items-center gap-1 px-2",onClick$:I("s_ynhdzdQwHCA",[e])},[n("div",null,{class:"flex h-6 w-6 items-center justify-center rounded-full bg-white p-1"},i(Nd,{class:"text-secondary-red",[s]:{class:s}},3,"H3_2"),1,null),n("span",null,{class:u(a=>`font-[400] text-${a.value==="qualifications"?"white":"primary-blue"}`,[e],'`font-[400] text-${p0.value==="qualifications"?"white":"primary-blue"}`')},"Qualifications",3,null)],1,null)],1,null),n("div",null,{class:"relative flex h-[200px] w-full overflow-x-hidden text-[13px] leading-4 transition-all "},[n("div",null,{class:u(a=>`absolute h-[200px] w-full p-4 transition-all ${a.value!=="duties"?"right-full":" right-0"}`,[e],'`absolute h-[200px] w-full p-4 transition-all ${p0.value!=="duties"?"right-full":" right-0"}`')},i(C,{get text(){return t.data.Duties},[s]:{text:u(a=>a.data.Duties,[t],'p0.data["Duties"]')}},3,"H3_3"),1,null),n("div",null,{class:u(a=>`absolute h-[200px] w-full p-4 transition-all ${a.value!=="qualifications"?"left-full":"left-0"}`,[e],'`absolute h-[200px] w-full p-4 transition-all ${p0.value!=="qualifications"?"left-full":"left-0"}`')},i(C,{get text(){return t.data.Qualifications},[s]:{text:u(a=>a.data.Qualifications,[t],'p0.data["Qualifications"]')}},3,"H3_4"),1,null)],1,null)],1,"H3_5")},Tf=m(g(Sf,"s_kNPEZsb0EOk")),Df=()=>{const[t]=X();console.log("Enivando correo"),t.value="LOADING";const e=new FormData(document.getElementById("form_careers")),a=new FileReader,l=e.get("resume");l?a.readAsDataURL(l):console.error("No se encontró el archivo adjunto"),a.onload=async r=>{if(r.target&&r.target.result){const o=await r.target.result,c=await{from_name:e.get("from_name"),tel:e.get("tel"),from_email:e.get("from_email"),message:e.get("message"),resume1:o,template_id:"template_gwyyy7d"};await fetch("/api/emailjs/",{method:"POST",body:JSON.stringify(c),headers:{"Content-Type":"application/json"}}).then(d=>d.json()).then(d=>{d.resp==="OK"?t.value="SUCCESS":(console.log(d.resp),t.value="ERROR")}).catch(d=>{console.error(d),t.value="ERROR"})}else console.error("Error al obtener los datos Base64 del archivo.")}},Pf=()=>{const t=O("NONE"),e=O(!1),a=O(!1),l=O(!1),r=O(!1),c=yt(I("s_hP0gadtF5EA",[r,e,l,a,g(Df,"s_fws8LqT0OUc",[t])]));return n("div",null,{class:"flex flex-col w-full md:w-1/2 h-[560px] bg-blue-100 rounded-2xl p-4"},[n("p",null,{class:"text-center font-medium text-color-Primary"},"Fill out the form below and attach your resume to contact us today",3,null),n("form",null,{class:"mt-2 overflow-y-auto",id:"form_careers",onSubmit$:I("s_i05DmpZA0BU",[c])},[n("div",null,{class:"flex-col sm:flex-row flex justify-between"},[n("div",null,{class:"mb-4 gap-2 w-full flex flex-col mr-0 md:mr-4"},[n("label",null,{class:"block font-medium text-color-Primary",for:"from_name"},"Name",3,null),n("input",null,{class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",id:"from_name",name:"from_name",type:"text"},null,3,null)],3,null),n("div",null,{class:"mb-4 gap-2 w-full flex flex-col"},[n("label",null,{class:"block font-medium text-color-Primary",for:"tel"},"Phone",3,null),n("input",null,{class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",id:"tel",maxLength:14,name:"tel",type:"tel"},null,3,null),n("label",null,{class:u((d,p)=>`text-xs text-red-600 ${d.value==!1&&p.value==!0?"flex":"hidden"} bg-transparent`,[e,a],'`text-xs text-red-600 ${p0.value==false&&p1.value==true?"flex":"hidden"} bg-transparent`')},"phone number is invalid",3,null)],3,null)],3,null),n("div",null,{class:"mb-4 gap-2 flex flex-col"},[n("label",null,{class:"block font-medium text-color-Primary",for:"from_email"},"Email",3,null),n("input",null,{class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",id:"from_email",name:"from_email",required:!0,type:"email"},null,3,null),n("label",null,{class:u((d,p)=>`text-xs text-red-600 ${d.value==!1&&p.value==!0?"flex":"hidden"} bg-transparent`,[r,l],'`text-xs text-red-600 ${p0.value==false&&p1.value==true?"flex":"hidden"} bg-transparent`')},"email is invalid",3,null)],3,null),n("div",null,{class:"mb-4 gap-2 flex flex-col"},[n("label",null,{class:"block  font-medium text-color-Primary",for:"message"},"Message",3,null),n("textarea",null,{class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",id:"message",name:"message",required:!0,rows:4},null,3,null)],3,null),n("label",null,{class:"flex w-[200px] text-color-Primary p-2 justify-evenly rounded-md font-medium",for:"resume"},["Upload resume",i(lp,{class:"text-center font-bold",[s]:{class:s}},3,"ty_0")],1,null),n("input",null,{accept:".pdf",class:"w-full",id:"resume",name:"resume",required:!0,type:"file"},null,3,null),n("button",null,{class:"mt-4 bg-secondary-red text-white w-full font-semibold px-4 py-2 rounded-xl hover:bg-blue-600 focus:outline-none",type:"submit"},"Submit",3,null)],1,null)],1,"ty_1")},kf=m(g(Pf,"s_34gK8gnZN08")),Lf=()=>{const[t]=X();t.value=!0},Cf=t=>{const[e,a,l]=X();return n("div",null,{class:"flex h-[380px] w-[460px] flex-col justify-between rounded-[30px] bg-white p-6 text-center shadow-lg max-[800px]:h-[280px] "},[n("div",null,{class:"flex-col items-center"},[n("div",null,{class:"flex items-center justify-center gap-2"},[i(Rl,null,3,"At_0"),n("span",null,{class:"font-[500] opacity-60"},u(r=>r.position.Location,[t],'p0.position["Location"]'),3,null)],1,null),n("h4",null,{class:"mt-2 text-[19px] font-[700] text-primary-dark-blue"},u(r=>r.position.Name,[t],'p0.position["Name"]'),3,null),i(C,{classN:"text-[15px] max-[800px]:text-[13px]",get text(){return t.position.Summary},[s]:{classN:s,text:u(r=>r.position.Summary,[t],'p0.position["Summary"]')}},3,"At_1")],1,null),n("div",null,{class:"flex flex-col items-center gap-2"},[n("div",null,{class:"flex gap-1 text-[15px]"},[n("span",null,{class:"text-btn-green hover:cursor-pointer",onClick$:I("s_d5LXfHtAyog",[a,t,l])},"Learn more",3,null)," ",n("span",null,{class:"text-black"},"or",3,null)],3,null),i(Z,{onClick:e,text:"Submit Resume",[s]:{onClick:s,text:s}},3,"At_2")],1,null)],1,"At_3")},Mf=t=>{const e=O(!1),a=O(!1),l=O(t.data.Positions[0].attributes),o=m(g(Cf,"s_MLxpYci0h0Y",[g(Lf,"s_DxkiX1SABig",[e]),a,l])),c=t.data.Positions.map((d,p)=>i(o,{get position(){return d.attributes},[s]:{position:x(d,"attributes")}},3,p));return n("div",null,{class:"my-8 flex justify-center text-primary-blue"},[i(Za,{children:i(kf,null,3,"At_4"),showSignal:e,[s]:{showSignal:s}},1,"At_5"),i(Za,{children:i(Tf,{get data(){return l.value},[s]:{data:u(d=>d.value,[l],"p0.value")}},3,"At_6"),showSignal:a,[s]:{showSignal:s}},1,"At_7"),n("div",null,{class:"flex flex-col "},[n("h3",null,{class:"text-center text-[44px] font-[600]"},u(d=>d.data.PositionsTitle,[t],'p0.data["PositionsTitle"]'),3,null),n("div",null,{class:"flex-column flex w-[1200px] "},i(Pt,{hasArrows:!0,id:"carPositions",slides:c,[s]:{hasArrows:s,id:s}},3,"At_8"),1,null)],1,null)],1,"At_9")},jf=m(g(Mf,"s_Su5lXmtHgW0")),Ef=t=>{const e=t.data.pageCareers.data.attributes;return n("div",null,{onClick$:I("s_yJsNttxIAPY")},[i(yf,{data:{HeaderLogo:t.data.pageCareers.data.attributes.HeaderLogo,HeaderTitle:t.data.pageCareers.data.attributes.HeaderTitle,HeaderPictures:t.data.pageCareers.data.attributes.HeaderPictures}},3,"a0_0"),i(_f,{data:{Beliefs:t.data.pageCareers.data.attributes.Beliefs,BeliefsDescription:t.data.pageCareers.data.attributes.BeliefsDescription,BeliefsSubtitle:t.data.pageCareers.data.attributes.BeliefsSubtitle,BeliefsTitle:t.data.pageCareers.data.attributes.BeliefsTitle,Offerings:t.data.pageCareers.data.attributes.Offerings,OfferingTitle:t.data.pageCareers.data.attributes.OfferingTitle}},3,"a0_1"),n("div",null,{class:"flex w-full justify-center px-8"},n("div",null,{class:"max-w-[1200px] text-center text-primary-blue"},[n("h3",null,{class:"mb-4 mt-16 text-[38px] font-[800]"},_(e.FormParagraph,"Title"),1,null),i(C,{get text(){return e.FormParagraph.Paragraph},classN:"text-[18px] font-[400]",[s]:{classN:s,text:x(e.FormParagraph,"Paragraph")}},3,"a0_2")],1,null),1,null),i(jf,{data:{Positions:e.Positions.data,PositionsTitle:e.PositionsTitle}},3,"a0_3")],1,"a0_4")},Bf=m(g(Ef,"s_CHSZKaaPR2c")),If=t=>`query QueryCareers {
    pageCareers(locale:"${t}"){    
      data{
        attributes{
                  HeaderLogo{
                    ${$}
                  }
          HeaderPictures{
            ${$}
          }
          HeaderBackground{
           ${$}
          }
          HeaderTitle{
            Text
          }
          
          
          BeliefsTitle
          BeliefsSubtitle
          Beliefs{
            Text
          }
          BeliefsDescription
          
          
          OfferingTitle
          Offerings{
            Title
            Paragraph
            Media{
              ${$}
            }
          }
          
          PositionsTitle
          Positions(sort: "Name:Asc"){
            data{
              attributes{
                Location
                Name
                Summary
                Duties
                Qualifications
              }
            }
          }
          
          FormParagraph{
            Title
            Paragraph
          }
          FormCareers{
            Title
            Fields{
              Label
              Icon{
                ${$}
              }
            }
            ActionButton{
              Text
              Link
            }
          }
        ${q}
        }
      }
    }
  }`,Of=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(If,e)},Xl=N(g(Of,"s_bBcTtiHl1Tw")),Af=()=>{const t=Xl();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageCareers.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageCareers.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageCareers"]["data"]["attributes"]["SEO"]')}},3,"sa_0"),i(Bf,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"sa_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"sa_2")},Nf=m(g(Af,"s_KylSGhTDLNs")),Rf=({resolveValue:t})=>{const a=t(Xl).pageData.data.pageCareers.data.attributes.SEO;return G(a)},qf=Object.freeze(Object.defineProperty({__proto__:null,default:Nf,head:Rf,usePageData:Xl},Symbol.toStringTag,{value:"Module"})),Ff=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(C,{get text(){return t.data.TextContent},classN:"markdownTitle markdownh3 markdownHyper text-justify flex text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"27_0")],1,"27_1"),zf=m(g(Ff,"s_qLAYw5vO9og")),Gf=t=>`query QuerySupplement {
        pageSuppleTerms(locale:"${t}"){    
          ${Xe}
          ${q}
            }
          }
        }
      }`,Qf=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(Gf,e)},Kl=N(g(Qf,"s_LHhYaz4wQcQ")),Hf=()=>{const t=Kl(),e=t.value.pageData.data.pageSuppleTerms.data.attributes.Content;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(zf,{data:e},3,"NP_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"NP_1")},1,"NP_2")},Wf=m(g(Hf,"s_2WfoIGYZZ0E")),Uf=({resolveValue:t})=>{const a=t(Kl).pageData.data.pageSuppleTerms.data.attributes.SEO;return G(a)},Yf=Object.freeze(Object.defineProperty({__proto__:null,default:Wf,head:Uf,usePageData:Kl},Symbol.toStringTag,{value:"Module"})),Vf=t=>n("div",null,{class:"flex flex-col py-10 items-center justify-center"},[n("h1",null,{class:"text-2xl sm:text-4xl font-bold text-primary-blue"},u(e=>e.data.Introduction.Title,[t],'p0.data["Introduction"]["Title"]'),3,null),n("p",null,{class:"text-primary-blue text-center text-[16px] md:text-[18px] m-5"},u(e=>e.data.Introduction.Paragraph,[t],'p0.data["Introduction"]["Paragraph"]'),3,null),i(Z,{get text(){return t.data.Introduction.Buttons[0].Text},get link(){return t.data.Introduction.Buttons[0].Link},[s]:{link:u(e=>e.data.Introduction.Buttons[0].Link,[t],'p0.data["Introduction"]["Buttons"][0]["Link"]'),text:u(e=>e.data.Introduction.Buttons[0].Text,[t],'p0.data["Introduction"]["Buttons"][0]["Text"]')}},3,"wL_0"),n("div",null,{class:"flex flex-col items-center gap-2 px-4 py-4 my-10"},[n("h2",null,{class:"text-xl sm:text-2xl font-bold text-primary-blue"},u(e=>e.data.SocialMedia.Text,[t],'p0.data["SocialMedia"]["Text"]'),3,null),n("div",null,{class:"flex flex-row gap-4"},t.data.SocialMedia.SubOption.map((e,a)=>W(i(Gt,{get href(){return e.Link},children:[e.Link.includes("facebook")&&n("div",null,{class:"flex w-[50px] h-[50px] items-center justify-center rounded-full bg-primary-blue p-4"},i(P,{get media(){return e.Icon.data.attributes},toWhite:!0,[s]:{media:x(e.Icon.data,"attributes"),toWhite:s}},3,"wL_1"),1,"wL_2"),!e.Link.includes("facebook")&&n("div",null,{class:"flex w-[50px] h-[50px] items-center justify-center rounded-full bg-primary-blue p-3"},i(P,{get media(){return e.Icon.data.attributes},toWhite:!0,[s]:{media:x(e.Icon.data,"attributes"),toWhite:s}},3,"wL_3"),1,"wL_4")],[s]:{href:x(e,"Link")}},1,a))),1,null)],1,null),n("div",null,{class:"flex flex-col items-center justify-center"},[n("h3",null,{class:"text-xl sm:text-2xl font-bold text-primary-blue"},u(e=>e.data.OfficesTitle,[t],'p0.data["OfficesTitle"]'),3,null),n("div",null,{class:"flex flex-wrap gap-8 mt-5 justify-center items-start"},t.data.OfficesLocation.map((e,a)=>n("div",null,{class:"flex flex-col w-[200px]"},[n("a",{href:_(e.Buttons[0],"Link")},{class:"font-bold text-secondary-red"},_(e.Buttons[0],"Text"),1,null),n("a",{href:_(e.Buttons[1],"Link")},{class:"font-bold text-primary-blue"},_(e.Buttons[1],"Text"),1,null),n("p",null,{class:"tracking-wide font-normal text-sm text-primary-blue"},_(e,"Paragraph"),1,null)],1,a)),1,null)],1,null)],1,"wL_5"),Zf=m(g(Vf,"s_5L0HuXf9QnQ")),Xf=t=>`query QueryContactUs{
        pageContact(locale:"${t}"){
          data{
            attributes{
              Introduction{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              SocialMedia{
                Text
                SubOption{
                  Text
                  Link
                  Icon{
                    ${$}
                  }
                }
              }
              
              OfficesTitle
              OfficesLocation{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              ${q}
            }
          }
        }
      }`,Kf=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(Xf,e)},Jl=N(g(Kf,"s_QdheZerij2w")),Jf=()=>{const t=Jl(),e=t.value.pageData.data.pageContact.data.attributes;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(Zf,{data:e},3,"yX_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"yX_1")},1,"yX_2")},tg=m(g(Jf,"s_FZeWA02p0TI")),eg=({resolveValue:t})=>{const a=t(Jl).pageData.data.pageContact.data.attributes.SEO;return G(a)},ag=Object.freeze(Object.defineProperty({__proto__:null,default:tg,head:eg,usePageData:Jl},Symbol.toStringTag,{value:"Module"})),lg=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(C,{get text(){return t.data.TextContent},classN:"markdownTitle markdownHyper text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"NS_0")],1,"NS_1"),ng=m(g(lg,"s_gvsFRD0Vfkk")),sg=t=>`
query QueryCookies {
  pageCookies(locale:"${t}"){    
    ${Xe}
    ${q}
      }
    }
  }
}`,rg=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(sg,e)},tn=N(g(rg,"s_IqhWiqyXb00")),ig=()=>{const t=tn(),e=t.value.pageData.data.pageCookies.data.attributes.Content;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(ng,{data:e},3,"wB_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"wB_1")},1,"wB_2")},og=m(g(ig,"s_OmN9OIo5qbs")),ug=({resolveValue:t})=>{const a=t(tn).pageData.data.pageCookies.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},cg=Object.freeze(Object.defineProperty({__proto__:null,default:og,head:ug,usePageData:tn},Symbol.toStringTag,{value:"Module"})),dg=t=>(W(),t.media.url.includes(".mp4")?n("video",{src:St(t.media.url)},{autoplay:u(e=>e.autoplay??!1,[t],"p0.autoplay??false"),class:u(e=>(e.toWhite??!1?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(e.clasN??""),[t],'(p0.toWhite??false?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(p0.clasN??"")'),controls:u(e=>e.controls??!1,[t],"p0.controls??false"),height:u(e=>e.height,[t],"p0.height"),loop:u(e=>e.loop??!0,[t],"p0.loop??true"),muted:u(e=>e.muted??!0,[t],"p0.muted??true"),width:u(e=>e.width,[t],"p0.width")},null,3,"kf_0"):i(P,{get media(){return t.media},get width(){return t.width},get height(){return t.height},get toWhite(){return t.toWhite??!1},get clasN(){return t.clasN??""},[s]:{clasN:u(e=>e.clasN??"",[t],'p0.clasN??""'),height:u(e=>e.height,[t],"p0.height"),media:u(e=>e.media,[t],"p0.media"),toWhite:u(e=>e.toWhite??!1,[t],"p0.toWhite??false"),width:u(e=>e.width,[t],"p0.width")}},3,"kf_1")),Xa=m(g(dg,"s_GG0oZTUUfNc")),pg=t=>(console.log(t.data),n("div",null,{class:u(e=>`${e.data.isVisible?"":"hidden"} flex w-full flex-col items-center justify-center text-primary-blue`,[t],'`${p0.data["isVisible"]?"":"hidden"} flex w-full flex-col items-center justify-center text-primary-blue`')},n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center px-10 min-[800px]:w-[70%]"},[n("span",null,{class:"text-center text-[38px] font-[800] text-secondary-red max-[800px]:text-[30px]"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),i(C,{classN:"mb-3 w-full bg-primary-blue p-2 font-[600] text-[26px] max-[800px]:text-[20px] text-white text-center mx-4 rounded-full",get text(){return t.data.Description},[s]:{classN:s,text:u(e=>e.data.Description,[t],'p0.data["Description"]')}},3,"Sf_0"),i(C,{classN:"text-center text-[26px]",get text(){return t.data.Deal},[s]:{classN:s,text:u(e=>e.data.Deal,[t],'p0.data["Deal"]')}},3,"Sf_1"),i(C,{classN:"text-center text-[18px] mb-3",get text(){return t.data.Deals_description},[s]:{classN:s,text:u(e=>e.data.Deals_description,[t],'p0.data["Deals_description"]')}},3,"Sf_2"),n("div",null,{class:"mb-3 flex items-start justify-evenly gap-4 max-[600px]:flex-col"},t.data.Services.map((e,a)=>n("div",null,{class:"flex items-center justify-center gap-1"},[i(Xa,{get media(){return e.Icon.data.attributes},clasN:"w-[100px] max-[1000px]:w-[80px] ",muted:!0,[s]:{clasN:s,media:x(e.Icon.data,"attributes"),muted:s}},3,"Sf_3"),n("span",null,{class:"font-[600]"},_(e,"Title"),1,null)],1,a)),1,null),i(Z,{get text(){return t.data.Button.Text},get link(){return t.data.Button.Link},[s]:{link:u(e=>e.data.Button.Link,[t],'p0.data["Button"]["Link"]'),text:u(e=>e.data.Button.Text,[t],'p0.data["Button"]["Text"]')}},3,"Sf_4")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 max-[600px]:hidden min-[800px]:w-[30%]"},i(Xa,{get media(){return t.data.Media.data.attributes},autoplay:!0,clasN:"rounded-full  mr-[30px]",loop:!0,muted:!0,[s]:{autoplay:s,clasN:s,loop:s,media:u(e=>e.data.Media.data.attributes,[t],'p0.data["Media"]["data"]["attributes"]'),muted:s}},3,"Sf_5"),1,null)],1,null),1,"Sf_6")),fg=m(g(pg,"s_4av0zjglZmk")),gg=t=>n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"min-h-[200px] w-full bg-gradient-to-br from-primary-light-blue to-[#23477f] !text-white"},i(qt,{get data(){return t.data},backgroundColor:"primary-blue",color:"white",[s]:{backgroundColor:s,color:s,data:u(e=>e.data,[t],"p0.data")}},3,"tV_0"),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"tV_1"),xg=m(g(gg,"s_cJop3g0b1vg")),mg=t=>n("div",null,{class:"flex w-full items-center justify-center"},n("div",null,{class:"flex max-w-[1200px] flex-wrap items-start justify-evenly gap-6 p-8"},t.data.map((e,a)=>n("div",null,{class:"flex w-[280px] flex-col items-center gap-2"},[i(be,{get media(){return e.Media.data.attributes},color:a%2===0?"bg-[#2E5899]":"bg-secondary-red",height:"300px",width:"300px",[s]:{height:s,media:x(e.Media.data,"attributes"),width:s}},3,"lG_0"),i(C,{get text(){return e.Title},classN:"font-[600] text-center text-[18px] tracking-[-1px]",[s]:{classN:s,text:x(e,"Title")}},3,"lG_1"),i(C,{get text(){return e.Paragraph},classN:"text-center text-[16px]",[s]:{classN:s,text:x(e,"Paragraph")}},3,"lG_2")],1,a)),1,null),1,"lG_3"),hg=m(g(mg,"s_gpmIUuGz0sE")),$g=t=>{const e=t.data.pageDeals.data.attributes.Deals,a=t.data.pageDeals.data.attributes.RefInfo,l=t.data.pageDeals.data.attributes.Discounts,r=t.data.pageDeals.data.attributes.Disclaimer;return n("div",null,null,[i(fg,{data:e},3,"e6_0"),i(xg,{data:a},3,"e6_1"),i(hg,{data:l},3,"e6_2"),n("div",null,{class:"flex w-full items-center  justify-center p-8 text-center text-[14px] italic text-primary-dark-blue"},r,1,null)],1,"e6_3")},bg=m(g($g,"s_xtY1ub2ohjs")),yg=t=>`
  query QueryDeals{
    pageDeals(locale:"${t}"){
      data{
        attributes{
          Deals {
            isVisible
            Title
            Description
            Deal
            Deals_description
            Media {
              ${$}
            }
            Services {
              Title
              Icon {
                ${$}
              }
            }
            Button {
              Text
              Link
            }
          }
  
          RefInfo{
            Title
            Paragraph
            Media{
              ${$}
            }
            Buttons{
              Text
              Link
            }
          }
          RefBackground{
            ${$}
          }
          
          Discounts{
            Title
            Paragraph
            Media{
             ${$}
            }
          }
          Disclaimer
          
          ${q}
        }
      }
    }
  }
    `,vg=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(yg,e)},en=N(g(vg,"s_2jiG1A0ymzM")),wg=()=>{const t=en();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageDeals.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageDeals.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageDeals"]["data"]["attributes"]["SEO"]')}},3,"B3_0"),i(bg,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"B3_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"B3_2")},_g=m(g(wg,"s_OVAjdqBqgec")),Sg=({resolveValue:t})=>{const a=t(en).pageData.data.pageDeals.data.attributes.SEO;return G(a)},Tg=Object.freeze(Object.defineProperty({__proto__:null,default:_g,head:Sg,usePageData:en},Symbol.toStringTag,{value:"Module"})),Dg=t=>n("div",null,{class:"my-8"},[n("h1",null,{class:"text-center text-xl font-semibold text-primary-blue"},u(e=>e.data.Introduction.Titles[0].Text,[t],'p0.data["Introduction"]["Titles"][0]["Text"]'),3,null),n("h2",null,{class:"text-center text-primary-blue"},u(e=>e.data.Introduction.TextContent,[t],'p0.data["Introduction"]["TextContent"]'),3,null),n("div",null,{class:"px-4 md:px-10"},t.data.FAQList.map((e,a)=>W(i(_e,{get title(){return e.Title},children:[n("p",null,{class:"text-primary-blue"},_(e,"Paragraph"),1,null),e.Disclaimer!==null?n("div",null,{class:"flex flex-row items-center justify-center"},[i(Kd,{class:"text-secondary-red",[s]:{class:s}},3,"NP_0"),n("p",null,{class:"text-s text-primary-dark-blue"},_(e.Disclaimer,"Text"),1,null)],1,"NP_1"):null,e.Table!==null?n("div",null,{class:"flex flex-col item-center justify-center"},n("table",null,{class:"border-collapse border rounded-2xl border-gray-200 w-full"},n("tbody",null,null,e.Table.map((l,r)=>n("tr",{class:`${r===0?"bg-primary-blue text-white":r%2===1?"bg-blue-100 text-primary-blue":"bg-blue-200 text-primary-blue"}`},null,[n("td",null,null,_(l,"ColumnOne"),1,null),n("td",null,null,_(l,"ColumnTwo"),1,null),n("td",null,null,_(l,"ColumnThree"),1,null)],1,r)),1,null),1,null),1,"NP_2"):null],classChild:" text-sm md:text-base border-primary-blue",classContainer:"text-center bg-white text-primary-blue text-base md:text-lg shadow-xl",[s]:{classChild:s,classContainer:s,title:x(e,"Title")}},1,a))),1,null)],1,"NP_3"),Pg=m(g(Dg,"s_x7ihZ2PZWys")),kg=t=>`query QueryFAQ {
        pageFaq(locale:"${t}") {
          data{
            attributes{    
              Introduction{
                Titles{
                  Text
                }
                TextContent
              }
      
              FAQList{
                Title
                Paragraph
                Disclaimer{
                Icon{
                    ${$}
                }
                Title
                Text
                Caption
                }

                Table{
                ColumnOne
                ColumnTwo
                ColumnThree
                }
              }
              
              ${q}
            }
          }
        }
      }`,Lg=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(kg,e)},an=N(g(Lg,"s_SBnhqZ85K9A")),Cg=()=>{const t=an(),e=t.value.pageData.data.pageFaq.data.attributes;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(Pg,{data:e},3,"k1_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"k1_1")},1,"k1_2")},Mg=m(g(Cg,"s_jDEouB0mRKg")),jg=({resolveValue:t})=>{const a=t(an).pageData.data.pageFaq.data.attributes.SEO;return G(a)},Eg=Object.freeze(Object.defineProperty({__proto__:null,default:Mg,head:jg,usePageData:an},Symbol.toStringTag,{value:"Module"})),Bg=t=>n("div",null,{class:"flex md:flex-row flex-col-reverse w-full text-center items-center justify-center md:p-8 md:my-10"},[n("div",null,{class:"relative"},[n("div",null,{class:"flex w-[20vw] h-[20vw] min-w-[300px] min-h-[300px] items-center justify-center"},n("div",null,{class:"bg-[#2E5899] md:h-full h-[285px] md:w-full w-[285px] bg-opacity-40 p-6 inline-block items-center justify-center rounded-full"},n("div",null,{class:"bg-[#2E5899] flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md"},n("div",null,{class:"bg-[#2E5899] flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md"},n("div",null,{class:"flex flex-col items-center gap-5"},null,3,null),3,null),3,null),3,null),3,null),n("div",null,{class:"flex gap-3 flex-col absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full items-center justify-center"},[i(C,{get text(){return t.parData.Paragraph},classN:"text-white text-[18px] leading-none md:text-[1.75vw]",[s]:{classN:s,text:u(e=>e.parData.Paragraph,[t],'p0.parData["Paragraph"]')}},3,"nC_0"),t.parData.Buttons&&t.parData.Buttons.map((e,a)=>n("div",null,{class:"z-50"},i(Z,{get text(){return e.Text},get link(){return e.Link},[s]:{link:x(e,"Link"),text:x(e,"Text")}},3,"nC_1"),1,a))],1,null)],1,null),n("div",null,{class:"flex flex-col gap-5 md:px-[30px] px-[12vw] py-5"},[n("div",null,{class:"flex flex-col justify-center items-center"},[i(C,{get text(){return t.parData.Title},classN:"[&>h1]:text-[28px]",[s]:{classN:s,text:u(e=>e.parData.Title,[t],'p0.parData["Title"]')}},3,"nC_2"),i(P,{get media(){return t.parData.Logo.data.attributes},height:"100px",width:"400px",[s]:{height:s,media:u(e=>e.parData.Logo.data.attributes,[t],'p0.parData["Logo"]["data"]["attributes"]'),width:s}},3,"nC_3")],1,null),i(C,{get text(){return t.parData.Subtitle},classN:"[&>h2]:text-[18px]",[s]:{classN:s,text:u(e=>e.parData.Subtitle,[t],'p0.parData["Subtitle"]')}},3,"nC_4")],1,null),n("div",null,{class:"w-[20vw] h-[20vw] min-w-[300px] min-h-[300px] max-[930px]:hidden flex"},i(be,{get media(){return t.parData.Media.data.attributes},[s]:{media:u(e=>e.parData.Media.data.attributes,[t],'p0.parData["Media"]["data"]["attributes"]')}},3,"nC_5"),1,null)],1,"nC_6"),ln=m(g(Bg,"s_BQqIfxz8NXA")),Ig=t=>(W(),n("div",null,{class:"flex md:flex-row flex-col-reverse w-full text-center items-center justify-center p-8 bg-gradient-to-r from-blue-500 to-[#2e5899]"},n("div",null,{class:"max-w-[1300px] w-full flex flex-col"},[n("div",null,{class:"flex md:flex-row flex-col"},t.speedList&&t.speedList.map((e,a)=>n("div",null,{class:"bg-white/80 grow m-2 rounded-2xl drop-shadow-2xl p-5"},[n("h3",null,{class:"text-[#d20030] md:text-[28px] text-[22px] font-bold"},_(e,"Title"),1,null),n("span",null,{class:"text-[#2e5899] md:text-[18px] text-[15px]"},_(e,"Text"),1,null)],1,a)),1,null),t.parData&&i(kt,{color:"white",get title(){return t.parData.Title},get text(){return t.parData.Paragraph},get buttons(){return t.parData.Buttons},backgroundColor:"transparent",[s]:{backgroundColor:s,buttons:u(e=>e.parData.Buttons,[t],'p0.parData["Buttons"]'),color:s,text:u(e=>e.parData.Paragraph,[t],'p0.parData["Paragraph"]'),title:u(e=>e.parData.Title,[t],'p0.parData["Title"]')}},3,"uc_0")],1,null),1,"uc_1")),nn=m(g(Ig,"s_Fo7QUM6aBA8")),Og=t=>n("div",null,{class:"flex md:flex-row flex-col-reverse w-full text-center items-center justify-center md:py-8 py-2"},i(kt,{hasPricing:!1,reverse:!0,get text(){return t.parData.Paragraph},backgroundColor:"transparent",get title(){return t.parData.Title},get subtitle(){return t.parData.Subtitle},get image(){return t.parData.Media.data.attributes},get buttons(){return t.parData.Buttons},[s]:{backgroundColor:s,buttons:u(e=>e.parData.Buttons,[t],'p0.parData["Buttons"]'),hasPricing:s,image:u(e=>e.parData.Media.data.attributes,[t],'p0.parData["Media"]["data"]["attributes"]'),reverse:s,subtitle:u(e=>e.parData.Subtitle,[t],'p0.parData["Subtitle"]'),text:u(e=>e.parData.Paragraph,[t],'p0.parData["Paragraph"]'),title:u(e=>e.parData.Title,[t],'p0.parData["Title"]')}},3,"CM_0"),1,"CM_1"),sn=m(g(Og,"s_sknthmsoXlM")),Ag=t=>{const e=t.data.Logo.data.attributes;return n("div",null,{class:"min-h-screen w-full flex flex-col items-center"},[i(P,{clasN:"p-5",media:e,width:"200px",[s]:{clasN:s,width:s}},3,"of_0"),i(ln,{get parData(){return t.data.SectionHead},[s]:{parData:u(a=>a.data.SectionHead,[t],'p0.data["SectionHead"]')}},3,"of_1"),i(nn,{get parData(){return t.data.SectionSpeed},get speedList(){return t.data.SpeedBullets},[s]:{parData:u(a=>a.data.SectionSpeed,[t],'p0.data["SectionSpeed"]'),speedList:u(a=>a.data.SpeedBullets,[t],'p0.data["SpeedBullets"]')}},3,"of_2"),i(sn,{get parData(){return t.data.SectionRating},[s]:{parData:u(a=>a.data.SectionRating,[t],'p0.data["SectionRating"]')}},3,"of_3"),n("div",null,{class:"w-full bg-white  flex md:flex-row flex-col items-center justify-between"},[n("div",null,{class:" flex flex-row gap-5 p-1"},t.data.Footer&&t.data.Footer.map((a,l)=>i(Gt,{get href(){return a.Link},children:_(a,"Text"),class:" hover:text-primary-blue/60 text-primary-blue font-bold",[s]:{class:s,href:x(a,"Link")}},1,l)),1,null),n("div",null,{class:"text-primary-blue text-center"},"© 2024 Rural Telecommunications of America, Inc. All rights reserved.",3,null)],1,null)],1,"of_4")},Ng=m(g(Ag,"s_GHcg0KcOc4I")),Rg=t=>`query QueryLPNeighbor {
        lpNeighbor (locale:"${t}"){    
          data{
            attributes{
              Logo{
                ${$}
              }

              SectionHead{
                Title
                Subtitle
                Paragraph
                Logo{
                    ${$}
                }
                Media{
                    ${$}
                }
                Buttons{
                  Text
                  Link
                }
              }

              SpeedBullets{
                Title
                Text
              }

              SectionSpeed{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }

              SectionRating{
                Title
                Subtitle
                Paragraph
                Buttons{
                  Text
                  Link
                }
                Media{
                    ${$}
                }
              }
              
              Footer{
                Text
                Link
              }
            ${q}
            }
          }
        }
        
      }`,qg=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(Rg,e)},rn=N(g(qg,"s_yFRGQ10fxJ8")),Fg=()=>{const t=rn();return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(Ng,{get data(){return t.value.pageData.data.lpNeighbor.data.attributes},[s]:{data:u(e=>e.value.pageData.data.lpNeighbor.data.attributes,[t],'p0.value["pageData"]["data"]["lpNeighbor"]["data"]["attributes"]')}},3,"kh_0"),showHeader:!1,showMenus:!1,[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s,showMenus:s}},1,"kh_1")},1,"kh_2")},zg=m(g(Fg,"s_goRTr5J9aTM")),Gg=({resolveValue:t})=>{const a=t(rn).pageData.data.lpNeighbor.data.attributes.SEO;return G(a)},Qg=Object.freeze(Object.defineProperty({__proto__:null,default:zg,head:Gg,usePageData:rn},Symbol.toStringTag,{value:"Module"})),Hg=t=>n("div",null,{class:"relative z-0 h-3/4 w-[250px] text-center items-center justify-center }"},[i(P,{clasN:"object-fill h-full w-full",get media(){return t.update.Picture.data.attributes},height:500,width:250,[s]:{clasN:s,height:s,media:u(e=>e.update.Picture.data.attributes,[t],'p0.update["Picture"]["data"]["attributes"]'),width:s}},3,"2q_0"),n("a",null,{href:u(e=>e.update.Link,[t],'p0.update["Link"]')},n("div",null,{class:"absolute flex items-center justify-center flex-col inset-0 w-full h-full bg-black bg-opacity-30 text-white"},[n("h2",null,{class:"text-2xl font-semibold"},u(e=>e.update.Title,[t],'p0.update["Title"]'),3,null),n("p",null,{class:"text-xl"},u(e=>e.update.Subtitle,[t],'p0.update["Subtitle"]'),3,null)],3,null),3,null)],1,"2q_1"),Wg=t=>{const e=m(g(Hg,"s_SjfOqPww0ks")),a=t.carouselData.map((l,r)=>i(e,{update:l},3,r));return n("div",null,{class:"flex w-full items-center justify-center"},n("div",null,{class:"flex flex-row max-w-[1200px] items-center justify-center max-[800px]:flex-col h-full"},[n("h2",null,{class:"text-center p-5 text-4xl font-bold text-primary-blue max-[800px]:w-[40%]"},u(l=>l.title,[t],"p0.title"),3,null),n("div",null,{class:"h-fit w-[60%] flex items-center justify-center "},i(Pt,{addSpace:!1,fillSlide:!0,hasPagination:!1,id:"updatesSlider",slides:a,[s]:{addSpace:s,fillSlide:s,hasPagination:s,id:s}},3,"2q_2"),1,null)],1,null),1,"2q_3")},Ug=m(g(Wg,"s_kpGwS0aQJPs")),Yg=t=>n("iframe",null,{allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",allowFullscreen:!0,class:u(e=>`h-full w-full ${e.classN}`,[t],"`h-full w-full ${p0.classN}`"),frameBorder:"0",src:u(e=>`https://www.youtube.com/embed/${e.ytURL.split("v=")[1]}`,[t],'`https://www.youtube.com/embed/${p0.ytURL.split("v=")[1]}`')},null,3,"Fj_0"),ma=m(g(Yg,"s_jekwDGWyuec")),Vg=t=>n("div",null,{class:"flex flex-col lg:flex-row w-full px-10 items-center justify-center my-8"},[n("div",null,{class:"flex flex-col w-full lg:w-1/3 h-full text-center lg:text-end justify-evenly mr-4 my-4"},[n("h2",null,{class:"text-2xl font-semibold text-secondary-red"},u(e=>e.data.FeatInterview.Title,[t],'p0.data["FeatInterview"]["Title"]'),3,null),n("h3",null,{class:"text-2xl font-[350] text-primary-blue"},u(e=>e.data.FeatInterview.Subtitle,[t],'p0.data["FeatInterview"]["Subtitle"]'),3,null),i(C,{classN:"my-8 ml-4",get text(){return t.data.FeatInterview.Paragraph},[s]:{classN:s,text:u(e=>e.data.FeatInterview.Paragraph,[t],'p0.data["FeatInterview"]["Paragraph"]')}},3,"RS_0"),n("div",null,{class:"flex justify-center lg:justify-end"},n("a",null,{class:"text-end",href:u(e=>e.data.FeatInterview.Buttons[0].Link,[t],'p0.data["FeatInterview"]["Buttons"][0]["Link"]')},n("div",null,{class:"flex px-4 w-fit py-2 justify-evenly items-center rounded-2xl border-2 border-primary-blue"},[i(ep,{class:"fill-secondary-red mr-4 h-full",[s]:{class:s}},3,"RS_1"),n("p",null,null,u(e=>e.data.FeatInterview.Buttons[0].Text,[t],'p0.data["FeatInterview"]["Buttons"][0]["Text"]'),3,null)],1,null),1,null),1,null)],1,null),n("div",null,null,i(ma,{get ytURL(){return t.data.FeatVideo},classN:"rounded-2xl w-[460px] md:w-[530px] md:h-[350px] m-8",[s]:{classN:s,ytURL:u(e=>e.data.FeatVideo,[t],'p0.data["FeatVideo"]')}},3,"RS_2"),1,null)],1,"RS_3"),Zg=m(g(Vg,"s_liBh70ErorA")),Xg={url:"/uploads/youtube_67497ef97d.svg",alternativeText:"A vector of Youtube logo",caption:"Youtube logo icon | RTA"},Kg=t=>{const e=t.data.map((a,l)=>n("div",null,{class:"relative z-0 w-350 h-150 rounded-2xl"},[i(P,{clasN:"rounded-2xl",get media(){return a.Picture.data.attributes},height:150,width:350,[s]:{clasN:s,height:s,media:x(a.Picture.data,"attributes"),width:s}},3,"zz_0"),n("a",{href:_(a,"Link")},{class:"absolute inset-0 h-full w-full flex items-center justify-center"},i(P,{get media(){return Xg},height:50,toWhite:!0,width:50,[s]:{height:s,media:s,toWhite:s,width:s}},3,"zz_1"),1,null)],1,l));return n("div",null,{class:"w-full flex items-center justify-center"},i(Pt,{duration:5e3,hasPagination:!1,id:"InterviewCarousel",slides:e,[s]:{duration:s,hasPagination:s,id:s}},3,"zz_2"),1,"zz_3")},Jg=m(g(Kg,"s_w6lTa7I5NZ4")),tx=t=>n("div",null,null,[i(qt,{get data(){return t.data.Introduction},alt:!0,hasPricing:!1,reverse:!0,[s]:{alt:s,data:u(e=>e.data.Introduction,[t],'p0.data["Introduction"]'),hasPricing:s,reverse:s}},3,"NM_0"),i(Ug,{get title(){return t.data.UpdatesTitle},get carouselData(){return t.data.UpdatesCarousel},[s]:{carouselData:u(e=>e.data.UpdatesCarousel,[t],'p0.data["UpdatesCarousel"]'),title:u(e=>e.data.UpdatesTitle,[t],'p0.data["UpdatesTitle"]')}},3,"NM_1"),i(Zg,{get data(){return t.data},[s]:{data:u(e=>e.data,[t],"p0.data")}},3,"NM_2"),i(Jg,{get data(){return t.data.Interviews},[s]:{data:u(e=>e.data.Interviews,[t],'p0.data["Interviews"]')}},3,"NM_3")],1,"NM_4"),ex=m(g(tx,"s_bPCxBsh3t6w")),ax=t=>`query queryGfsn{
        pageGfSports(locale:"${t}"){
          data{
            attributes{
              
              Introduction{
                Title
                Subtitle
                Paragraph
                Media{
                 ${$}
                }
               
              }
              
              UpdatesTitle
              
              UpdatesCarousel{
                Picture{
                  ${$}
                }
                Link
                Title
                Subtitle
              }
              
              FeatInterview{
                Title
                Subtitle
                Paragraph
                
                Buttons{
                  Text
                  Link
                  Icon{
                    ${$}
                  }
                }
              }
              
              
              FeatVideo
              
              Interviews{
                Picture{
                  ${$}
                }
                Link
                Title
              }
              ${q}
            }
          }
        }
      }`,lx=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(ax,e)},on=N(g(lx,"s_BZfivgZf0o0")),nx=()=>{const t=on();return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageGfSports.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfSports.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfSports"]["data"]["attributes"]["SEO"]')}},3,"7u_0"),i(ex,{get data(){return t.value.pageData.data.pageGfSports.data.attributes},[s]:{data:u(e=>e.value.pageData.data.pageGfSports.data.attributes,[t],'p0.value["pageData"]["data"]["pageGfSports"]["data"]["attributes"]')}},3,"7u_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"7u_2")},1,"7u_3")},sx=m(g(nx,"s_KZzsv9nZPuQ")),rx=({resolveValue:t})=>{const a=t(on).pageData.data.pageGfSports.data.attributes.SEO;return G(a)},ix=Object.freeze(Object.defineProperty({__proto__:null,default:sx,head:rx,usePageData:on},Symbol.toStringTag,{value:"Module"})),ox=t=>{const e=t.data.pageGfCloud.data.attributes,a=t.data.sectionNetwork.data.attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(P,{get media(){return e.GNetworkLogo.data.attributes},height:95,width:500,[s]:{height:s,media:x(e.GNetworkLogo.data,"attributes"),width:s}},3,"JJ_0"),n("div",null,{class:"flex flex-wrap-reverse px-8 py-6 items-center justify-center"},[n("div",null,{class:"h-[450px] w-full md:w-1/2"},i(P,{get media(){return a.Map.MapPicture.data.attributes},height:490,width:500,[s]:{height:s,media:x(a.Map.MapPicture.data,"attributes"),width:s}},3,"JJ_1"),1,null),n("div",null,{class:"flex flex-col w-full md:w-1/2 items-center justify-center"},[i(C,{get text(){return a.Description.Paragraph},classN:"text-primary-blue",[s]:{classN:s,text:x(a.Description,"Paragraph")}},3,"JJ_2"),i(_e,{get title(){return a.Map.ServersTitle},children:n("div",null,{class:"flex flex-col py-4 text-primary-blue bg-white rounded-b-2xl"},a.Map.Servers.map((l,r)=>n("a",{href:_(l,"Link")},{class:"hover:text-secondary-red text-primary-blue"},_(l,"Text"),1,r)),1,null),classContainer:"rounded-full bg-white text-primary-blue shadow-xl",[s]:{classContainer:s,title:x(a.Map,"ServersTitle")}},1,"JJ_3")],1,null)],1,null),i(kt,{get title(){return e.GFCloud.Title},get text(){return e.GFCloud.Paragraph},get image(){return e.GFCloud.Media.data.attributes},get logo(){return e.GFCloud.Logo.data.attributes},get buttons(){return e.GFCloud.Buttons},[s]:{buttons:x(e.GFCloud,"Buttons"),image:x(e.GFCloud.Media.data,"attributes"),logo:x(e.GFCloud.Logo.data,"attributes"),text:x(e.GFCloud,"Paragraph"),title:x(e.GFCloud,"Title")}},3,"JJ_4")],1,"JJ_5")},ux=m(g(ox,"s_ee4CXUkPYJQ")),cx=t=>`query QueryGFCloud {
        pageGfCloud (locale:"${t}"){    
          data{
            attributes{
              GNetworkLogo{
                ${$}
              }
            GFCloud{
              Title
              Logo{
                ${$}
              }
              Paragraph
              Media{
                ${$}
              }
              Buttons{
                Text
                Link
              }
            }
              
            ${q}
            }
          }
        }
        sectionNetwork (locale:"${t}"){
          data {
            attributes {
              Map {
                MapPicture {
                  ${$}
                }
                ServersTitle
                Servers (pagination:{limit:50}){
                  Text
                  Link
                  Icon{
                    ${$}
                  }
                }
              }
              Description{
                Title
                Paragraph
              }
            }
          }
        }
      }`,dx=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(cx,e)},un=N(g(dx,"s_imQl8eEcDG0")),px=()=>{const t=un(),e=t.value.pageData.data;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageGfCloud.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageGfCloud.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfCloud"]["data"]["attributes"]["SEO"]')}},3,"Fb_0"),i(ux,{data:e},3,"Fb_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Fb_2")},1,"Fb_3")},fx=m(g(px,"s_8q0wwtngnhI")),gx=({resolveValue:t})=>{const a=t(un).pageData.data.pageGfCloud.data.attributes.SEO;return G(a)},xx=Object.freeze(Object.defineProperty({__proto__:null,default:fx,head:gx,usePageData:un},Symbol.toStringTag,{value:"Module"})),mx=t=>n("div",null,{class:"flex w-full flex-col items-center justify-center gap-3 rounded-xl bg-white p-8 shadow-xl"},[n("div",null,{class:"w-fit rounded-full bg-secondary-red p-2"},i(P,{get media(){return t.tip.Icon.data.attributes},height:17,toWhite:!0,width:17,[s]:{height:s,media:u(e=>e.tip.Icon.data.attributes,[t],'p0.tip["Icon"]["data"]["attributes"]'),toWhite:s,width:s}},3,"Ie_0"),1,null),n("h4",null,{class:"text-center font-[700] text-primary-blue"},u(e=>e.tip.Title,[t],'p0.tip["Title"]'),3,null),i(C,{classN:"text-[14px] font-[500]",get text(){return t.tip.Text},[s]:{classN:s,text:u(e=>e.tip.Text,[t],'p0.tip["Text"]')}},3,"Ie_1")],1,t.tip.Title),hx=t=>{const e=m(g(mx,"s_YpuX8PZv7fg"));return n("div",null,{class:"mt-6 flex w-full max-w-[1200px] flex-col items-center justify-center gap-4 p-8"},[n("h2",null,{class:"text-center text-[40px] font-[500] text-primary-blue"},u(a=>a.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"grid w-full grid-cols-3 gap-4  max-[800px]:grid-cols-1"},t.data.Bullets.slice(0,3).map((a,l)=>i(e,{tip:a},3,l)),1,null),n("div",null,{class:"grid w-full grid-cols-2 gap-4 max-[800px]:grid-cols-1"},t.data.Bullets.slice(3,5).map((a,l)=>i(e,{tip:a},3,l)),1,null)],1,"Ie_2")},$x=m(g(hx,"s_0W2ahleMHpc")),bx=t=>i(Q,{children:t.data.map((e,a)=>i(qt,{data:e,reverse:a%2===1,textPercentage:60,[s]:{textPercentage:s}},3,a))},1,"mL_0"),yx=m(g(bx,"s_GQ2BMpdgaAM")),vx=t=>{const e=t.data.pageGfIS.data.attributes;let a="";return e.WiFiListing.Bullets.forEach(l=>{a+="- "+l.Text+`
`}),n("div",null,{class:"flex w-full flex-col items-center justify-center",onClick$:I("s_wLQQzX3cS04")},[n("h1",null,{class:"max-w-[800px] px-8 text-center text-[42px] font-[600] text-primary-blue max-[600px]:text-[32px]"},_(e.Introduction,"Paragraph"),1,null),i($x,{get data(){return e.Tips},[s]:{data:x(e,"Tips")}},3,"5A_0"),i(yx,{get data(){return e.InternetInfo},[s]:{data:x(e,"InternetInfo")}},3,"5A_1"),n("div",null,{class:"flex max-w-[1200px] items-start justify-center gap-4 p-8 max-[800px]:flex-col"},[n("p",null,{class:"w-[60%] text-[15px] text-primary-blue max-[800px]:w-full"},_(e.InternetExample[0],"Text"),1,null),n("p",null,{class:"w-[40%] text-[15px] font-[600] text-primary-blue max-[800px]:w-full"},_(e.InternetExample[1],"Text"),1,null)],1,null),i(kt,{get title(){return e.WiFiListing.Title},text:a,get image(){return e.WiFiPicture.data.attributes},reverse:!0,textPercentage:50,[s]:{image:x(e.WiFiPicture.data,"attributes"),reverse:s,textPercentage:s,title:x(e.WiFiListing,"Title")}},3,"5A_2"),i(qt,{get data(){return e.TestPar},textPercentage:60,[s]:{data:x(e,"TestPar"),textPercentage:s}},3,"5A_3"),i(qe,{steps:e.TestStepss.map(l=>"**"+l.Title+`**

`+l.Text)},3,"5A_4"),i(kt,{get text(){return e.TestGlossary.Paragraph},get image(){return e.TestGlossary.Media.data.attributes},textPercentage:60,[s]:{image:x(e.TestGlossary.Media.data,"attributes"),text:x(e.TestGlossary,"Paragraph"),textPercentage:s}},3,"5A_5"),n("h3",null,{class:"text-[40px] font-[600] text-primary-blue"},_(e.TroubleSteps,"Title"),1,null),n("p",null,{class:"my-4 text-primary-blue"},_(e,"TroubleDescription"),1,null),n("div",null,{class:"max-w-[1200px]  px-8"},i(qe,{steps:e.TroubleSteps.Bullets.map(l=>l.Title?"**"+l.Title+`**
`+l.Text.replaceAll(`

`,`
`):"**"+l.Text.replaceAll(`

`,`
`)+"**")},3,"5A_6"),1,null)],1,"5A_7")},wx=m(g(vx,"s_DlDfET88Hb4")),_x=t=>`query {
    pageGfIS(locale:"${t}") {
      data {
        attributes {
          Introduction {
            Paragraph
            Media {
              ${$}
            }
          }
          Tips {
            Title
            Bullets {
              Title
              Text
              Icon {
               ${$}
              }
            }
          }
          InternetInfo {
            Title
            Paragraph
            Media {
              ${$}
            }
          }
          InternetExample {
            Text
          }
          WiFiPicture {
           ${$}
          }
          WiFiListing {
            Title
            Bullets {
              Title
              Text
            }
          }
          TestPar{
            Title
            Paragraph
            Media{
              ${$}
            }
          }
          TestStepss{
            Title
            Text
          }
          TestGlossary {
            Paragraph
            Media {
              ${$}
            }
          }
          TroubleSteps {
            Title
            Bullets {
              Title
              Text
            }
          }
          TroubleDescription
          ${q}
  
        }
      }
    }
  }`,Sx=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(_x,e)},cn=N(g(Sx,"s_YTLZ80iXjpk")),Tx=()=>{const t=cn();return i(F,{get data(){return t.value.layoutData},children:i(wx,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"0g_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"0g_1")},Dx=m(g(Tx,"s_sPmm4Hp5SbY")),Px=({resolveValue:t})=>{const a=t(cn).pageData.data.pageGfIS.data.attributes.SEO;return G(a)},kx=Object.freeze(Object.defineProperty({__proto__:null,default:Dx,head:Px,usePageData:cn},Symbol.toStringTag,{value:"Module"})),Lx=t=>(W(),n("div",null,{class:"flex min-h-[600px] w-fit max-w-[300px] flex-col items-center justify-between rounded-[35px] bg-white px-5"},[n("div",null,{class:"mt-8 flex w-fit max-w-full flex-col items-center self-center"},[t.isFullLogo??!1?n("div",null,{class:"flex flex-col justify-center items-center self-center gap-2 "},[i(P,{get media(){return t.logo},clasN:" w-full  overflow-hidden object-center",height:100,width:300,[s]:{clasN:s,height:s,media:u(e=>e.logo,[t],"p0.logo"),width:s}},3,"0s_0"),n("div",null,{class:" text-2xl font-bold leading-6 text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null)],1,"0s_1"):n("div",null,{class:"flex w-full items-start gap-5 self-center"},[i(P,{get media(){return t.logo},clasN:"aspect-square w-[70px] max-w-full items-center justify-center self-stretch overflow-hidden object-contain object-center",height:100,width:100,[s]:{clasN:s,height:s,media:u(e=>e.logo,[t],"p0.logo"),width:s}},3,"0s_2"),n("div",null,{class:"my-auto flex flex-col self-center"},n("div",null,{class:"self-start whitespace-nowrap text-2xl font-bold leading-6 text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),3,null)],1,null),n("div",null,{class:"mt-2 text-center text-base leading-4 tracking-tighter text-primary-blue"},[n("span",null,{class:"text-2xl font-light text-secondary-red"},"$",3,null),n("span",null,{class:"text-2xl font-light text-primary-blue"},u(e=>e.price,[t],"p0.price"),3,null),n("span",null,{class:" text-2xl text-primary-blue"},u(e=>e.priceTime,[t],"p0.priceTime"),3,null)],3,null),n("div",null,{class:"mt-5 text-center text-base text-primary-blue"},i(C,{get text(){return t.description},[s]:{text:u(e=>e.description,[t],"p0.description")}},3,"0s_3"),1,null),n("div",null,{class:"border-gary-500 my-4 h-[1px] w-full border-t-2"},null,3,null),n("div",null,{class:"mt-5 text-base text-primary-blue"},t.features.map((e,a)=>n("span",null,{class:"my-1 flex flex-row items-center justify-start"},[n("div",null,null,i(Fr,{class:"mx-2 h-[20px] w-[20px] fill-primary-blue text-primary-blue",[s]:{class:s}},3,"0s_4"),1,null),n("h3",null,{class:"text-sm font-light"},_(e,"Text"),1,a)],1,a)),1,null)],1,null),n("div",null,{class:"my-4 flex h-[80px] w-full flex-col items-center justify-center"},[n("div",null,{class:"border-gary-500 my-4 h-[1px] w-full border-t-2"},null,3,null),i(Z,{get text(){return t.btnText},get link(){return t.btnLink},[s]:{link:u(e=>e.btnLink,[t],"p0.btnLink"),text:u(e=>e.btnText,[t],"p0.btnText")}},3,"0s_5")],1,null)],1,"0s_6")),dn=m(g(Lx,"s_Ttt0gCfGtkU")),Cx=t=>n("div",null,{class:"flex flex-col items-center justify-around"},[n("div",null,{class:"mx-4 my-8 max-w-[500px]"},i(P,{get media(){return t.data.Logo.data.attributes},height:229,width:1230,[s]:{height:s,media:u(e=>e.data.Logo.data.attributes,[t],'p0.data["Logo"]["data"]["attributes"]'),width:s}},3,"6h_0"),1,null),n("div",null,{class:"mx-10 my-4 flex max-w-[800px] flex-col items-center justify-center gap-2 text-primary-blue"},[n("span",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(e=>e.data.Introduction.Title,[t],'p0.data["Introduction"]["Title"]'),3,null),i(C,{classN:"text-center",get text(){return t.data.Introduction.Paragraph},[s]:{classN:s,text:u(e=>e.data.Introduction.Paragraph,[t],'p0.data["Introduction"]["Paragraph"]')}},3,"6h_1"),i(Z,{get text(){return t.data.Introduction.Buttons[0].Text},get link(){return t.data.Introduction.Buttons[0].Link},[s]:{link:u(e=>e.data.Introduction.Buttons[0].Link,[t],'p0.data["Introduction"]["Buttons"][0]["Link"]'),text:u(e=>e.data.Introduction.Buttons[0].Text,[t],'p0.data["Introduction"]["Buttons"][0]["Text"]')}},3,"6h_2")],1,null),n("div",null,{class:"flex flex-wrap gap-10 justify-center mx-4 my-8 items-start"},t.data.PackTables.map((e,a)=>i(dn,{get title(){return e.Title},get logo(){return e.Logo.data.attributes},get description(){return e.Description},get features(){return e.Features},get price(){return e.Price},get priceTime(){return e.Pricetime},get btnLink(){return e.Button.Link},get btnText(){return e.Button.Text},[s]:{btnLink:x(e.Button,"Link"),btnText:x(e.Button,"Text"),description:x(e,"Description"),features:x(e,"Features"),logo:x(e.Logo.data,"attributes"),price:x(e,"Price"),priceTime:x(e,"Pricetime"),title:x(e,"Title")}},3,a)),1,null),i(C,{classN:"text-primary-blue text-center mx-4 my-8",get text(){return t.data.Disclaimer},[s]:{classN:s,text:u(e=>e.data.Disclaimer,[t],'p0.data["Disclaimer"]')}},3,"6h_3"),i(kt,{get text(){return t.data.GFInternetSupport.Paragraph},get title(){return t.data.GFInternetSupport.Title},get logo(){return t.data.GFInternetSupport.Logo.data.attributes},get buttons(){return t.data.GFInternetSupport.Buttons},get image(){return t.data.GFInternetSupport.Media.data.attributes},[s]:{buttons:u(e=>e.data.GFInternetSupport.Buttons,[t],'p0.data["GFInternetSupport"]["Buttons"]'),image:u(e=>e.data.GFInternetSupport.Media.data.attributes,[t],'p0.data["GFInternetSupport"]["Media"]["data"]["attributes"]'),logo:u(e=>e.data.GFInternetSupport.Logo.data.attributes,[t],'p0.data["GFInternetSupport"]["Logo"]["data"]["attributes"]'),text:u(e=>e.data.GFInternetSupport.Paragraph,[t],'p0.data["GFInternetSupport"]["Paragraph"]'),title:u(e=>e.data.GFInternetSupport.Title,[t],'p0.data["GFInternetSupport"]["Title"]')}},3,"6h_4")],1,"6h_5"),Mx=m(g(Cx,"s_30f4iq1HkIo")),jx=t=>`query QueryGFInternet {
        pageGfInternet(locale:"${t}"){
          data {
            attributes {
              Logo {
                ${$}
              }
              Introduction {
                Paragraph
                Buttons {
                  Text
                  Link
                }
              }
              PackTables {
                Logo {
                  ${$}
                }
                Title
                Subtitle
                Price
                Pricetime
                Description
                Features {
                  Text
                  Title
                }
                Button {
                  Link
                  Text
                }
              }
              Disclaimer
              GFInternetSupport {
                Title
                Subtitle
                Paragraph
                Logo {
                  ${$}
                }
                Media {
                  ${$}
                }
                Buttons {
                  Text
                  Link
                }
              }
              ${q}
            }
          }
        }
      }
      `,Ex=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(jx,e)},pn=N(g(Ex,"s_PG6JGbvGdSU")),Bx=()=>{const t=pn(),e=t.value.pageData.data.pageGfInternet.data.attributes;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageGfInternet.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageGfInternet.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfInternet"]["data"]["attributes"]["SEO"]')}},3,"TH_0"),i(Mx,{data:e},3,"TH_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"TH_2")},1,"TH_3")},Ix=m(g(Bx,"s_cj0XMKyWnnQ")),Ox=({resolveValue:t})=>{const a=t(pn).pageData.data.pageGfInternet.data.attributes.SEO;return G(a)},Ax=Object.freeze(Object.defineProperty({__proto__:null,default:Ix,head:Ox,usePageData:pn},Symbol.toStringTag,{value:"Module"})),Nx=t=>{const e=t.data.pageGfIoT.data.attributes.Services,a=t.data.pageGfIoT.data.attributes.Introduction,l=t.data.pageGfIoT.data.attributes.Logo.data.attributes,r=t.data.pageGfIoT.data.attributes.WeatherAnounce;return n("div",null,{class:"flex flex-col items-center justify-center "},[n("div",null,{class:"m-4 flex items-center justify-center gap-4 rounded-full bg-[#edf6ff] px-8 py-5 shadow-xl max-sm:flex-col"},[n("span",null,{class:"text-center text-[18px] font-[600] text-primary-blue max-md:text-[14px]"},_(r,"Paragraph"),1,null),i(Z,{get text(){return r.Buttons[0].Text},get link(){return r.Buttons[0].Link},[s]:{link:x(r.Buttons[0],"Link"),text:x(r.Buttons[0],"Text")}},3,"Ws_0")],1,null),n("div",null,{class:"mx-4 my-8 max-w-[500px]"},i(P,{height:229,media:l,width:1230,[s]:{height:s,width:s}},3,"Ws_1"),1,null),n("div",null,{class:"mx-10 my-4 flex max-w-[800px] flex-col items-center justify-center gap-2 text-primary-blue"},[n("span",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},_(a,"Title"),1,null),i(C,{classN:"text-justify",get text(){return a.Paragraph},[s]:{classN:s,text:x(a,"Paragraph")}},3,"Ws_2")],1,null),i(oe,{data:e},3,"Ws_3")],1,"Ws_4")},Rx=m(g(Nx,"s_1kXwT2q88rA")),qx=t=>`
  query QueryGFIoT {
    pageGfIoT(locale:"${t}"){
      data{
        attributes{
          Logo{
            ${$}
          }
          
          Introduction{
            Title
            Paragraph
          }
          
          WeatherAnounce{
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
          
          Services{
            Logo{
             ${$}
            }
            Title
            Paragraph
            Media{
             ${$}
            }
            Buttons{
              Text
              Link
            }
          }
          ${q}
        }
      }
    }
  }
    `,Fx=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(qx,e)},fn=N(g(Fx,"s_2v03ITQBdcI")),zx=()=>{const t=fn();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageGfIoT.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfIoT.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfIoT"]["data"]["attributes"]["SEO"]')}},3,"Mz_0"),i(Rx,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Mz_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Mz_2")},Gx=m(g(zx,"s_teV3ya9bjBI")),Qx=({resolveValue:t})=>{const a=t(fn).pageData.data.pageGfIoT.data.attributes.SEO;return G(a)},Hx=Object.freeze(Object.defineProperty({__proto__:null,default:Gx,head:Qx,usePageData:fn},Symbol.toStringTag,{value:"Module"})),Wx=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(C,{get text(){return t.data.TextContent},classN:"markdownTitle markdownh3 markdownHyper text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"Wt_0")],1,"Wt_1"),Ux=m(g(Wx,"s_wAqfRFn86VY")),Yx=t=>`query QuerygftvPrivacyP {
        pageGfTvPp(locale:"${t}"){    
          ${Xe}
          ${q}
            }
          }
        }
      }`,Vx=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(Yx,e)},gn=N(g(Vx,"s_o03PAaBI278")),Zx=()=>{const t=gn(),e=t.value.pageData.data.pageGfTvPp.data.attributes.Content;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(Ux,{data:e},3,"zG_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"zG_1")},1,"zG_2")},Xx=m(g(Zx,"s_0UMSXuOQgCA")),Kx=({resolveValue:t})=>{const a=t(gn).pageData.data.pageGfTvPp.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},Jx=Object.freeze(Object.defineProperty({__proto__:null,default:Xx,head:Kx,usePageData:gn},Symbol.toStringTag,{value:"Module"})),tm=async(t,e)=>{const a=St(t);try{const l=await fetch(a);if(!l.ok)throw new Error(`Error al descargar el archivo desde ${a}. Estado: ${l.status}`);const r=await l.arrayBuffer(),o=new Blob([r],{type:"application/pdf"}),c=window.URL.createObjectURL(o),d=document.createElement("a");d.href=c,d.download=e,d.click(),window.URL.revokeObjectURL(c)}catch(l){console.error(l)}},Zr=g(tm,"s_Vd02rPSFNlY"),em=()=>{const[t]=X();Zr(t.urlDoc,t.nameDoc)},am=t=>{const e=g(em,"s_L0UgBFqZ3XI",[t]);return n("div",null,{class:"flex flex-col h-[250px] w-[300px] bg-white shadow-2xl rounded-3xl justify-evenly items-center p-4"},[n("h3",null,{class:"text-2xl flex text-center font-bold text-[#2E5899]"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex w-fit items-center font-semibold justify-center gap-2 rounded-full border-2 border-teal-500 bg-white p-1 px-7 text-btn-green opacity-80 shadow-md transition-all hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:e},n("div",null,{class:"flex flex-row gap-2 items-center font-semibold text-center justify-center"},[u(a=>a.btnText,[t],"p0.btnText"),n("div",null,{class:"h-[25px] w-[25px] flex items-center justify-center font-bold text-white bg-teal-500 hover:text-teal-500 hover:bg-white rounded-full"},i(zr,{class:"stroke-current",[s]:{class:s}},3,"h5_0"),1,null)],1,null),1,null)],1,"h5_1")},Xr=m(g(am,"s_tF7T0UXX4O0")),lm=()=>{const[t]=X();Zr(t.urlDoc,t.nameDoc)},nm=t=>{const e=g(lm,"s_8SKPRTg50C4",[t]);return n("div",null,{class:"h-[370px] w-[400px] py-8 px-4 bg-white rounded-2xl pb-2 flex flex-col items-center justify-between shadow-2xl"},[n("div",null,{class:"relative flex w-full overflow-hidden"},i(P,{clasN:"object-fill w-full h-full rounded-t-2xl",height:"1500",width:"2076",get media(){return t.image},[s]:{clasN:s,height:s,media:u(a=>a.image,[t],"p0.image"),width:s}},3,"d0_0"),1,null),n("h2",null,{class:"text-2xl flex text-center font-bold text-[#2E5899]"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex w-fit items-center font-semibold justify-center gap-2 rounded-full border-2 border-teal-500 bg-white p-1 text-btn-green opacity-80 shadow-md transition-all hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:e},n("div",null,{class:"flex flex-row gap-2 items-center font-semibold text-center justify-center"},[u(a=>a.btnText,[t],"p0.btnText"),n("div",null,{class:"h-[25px] w-[25px] flex items-center justify-center font-bold text-white bg-teal-500 hover:text-teal-500 hover:bg-white rounded-full"},i(zr,{class:"stroke-current",[s]:{class:s}},3,"d0_1"),1,null)],1,null),1,null)],1,"d0_2")},Kr=m(g(nm,"s_OdYDJRaDcFY")),sm=t=>{const e=t.data.pageGfTvS.data.attributes,a=t.data.sectionChGuide.data.attributes;return n("div",null,{class:"flex flex-col justify-center items-center"},[n("div",null,{class:"flex flex-col md:flex-row px-8 items-center justify-center gap-5"},[n("h1",null,{class:"text-2xl text-center font-semibold text-primary-blue"},_(e,"IntroText"),1,null),n("div",null,{class:"h-[150px] relative w-[350px] flex mb-14"},[n("video",{src:St(e.IntroMedia.data[1].attributes.url)},{autoplay:!0,class:"absolute pt-2",loop:!0,muted:!0},null,3,null),i(P,{clasN:"absolute z-0",get media(){return e.IntroMedia.data[0].attributes},height:"786",width:"1082",[s]:{clasN:s,height:s,media:x(e.IntroMedia.data[0],"attributes"),width:s}},3,"yQ_0")],1,null)],1,null),n("div",null,{class:"flex my-20 w-full py-10 bg-primary-blue bg-opacity-40"},n("div",null,{class:"flex w-full py-10 bg-primary-blue bg-opacity-60"},n("div",null,{class:"flex w-full flex-col py-10 px-8 items-center justify-between bg-primary-blue bg-opacity-80"},[n("h2",null,{class:"font-bold text-3xl md:text-4xl my-5 text-white"},_(e,"DevicesTitle"),1,null),n("div",null,{class:"flex flex-wrap gap-5 items-center justify-center"},e.Devices.map((l,r)=>n("div",null,{class:"h-[300px] w-[300px] p-5 rounded-full bg-white bg-opacity-40"},n("div",null,{class:"h-full w-full p-5 rounded-full bg-white bg-opacity-60"},n("div",null,{class:"h-full w-full object-cover flex flex-col p-8 justify-center items-center rounded-full bg-white"},[n("h2",null,{class:"text-center font-semibold text-2xl text-primary-blue"},_(l,"Title"),1,null),i(C,{classN:"text-s text-primary-dark-blue",get text(){return l.Paragraph},[s]:{classN:s,text:x(l,"Paragraph")}},3,"yQ_1")],1,null),1,null),1,r)),1,null),n("p",null,{class:"text-center justify-end my-5 text-white"},_(e,"DevicesNote"),1,null)],1,null),1,null),1,null),n("div",null,{class:"flex flex-col justify-center px-8 items-center"},[n("div",null,{class:"w-full md:w-2/3 flex flex-col items-center"},[n("h2",null,{class:"text-3xl md:text-4xl text-center font-bold text-primary-blue"},_(e.GuidePar,"Title"),1,null),i(C,{classN:"text-center",get text(){return e.GuidePar.Paragraph},[s]:{classN:s,text:x(e.GuidePar,"Paragraph")}},3,"yQ_2")],1,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-10 my-5"},e.Guides.map((l,r)=>i(Xr,{get urlDoc(){return l.Guide.data.attributes.url},get title(){return l.Title},get btnText(){return l.BtnText},get nameDoc(){return l.Guide.data.attributes.name},[s]:{btnText:x(l,"BtnText"),nameDoc:x(l.Guide.data.attributes,"name"),title:x(l,"Title"),urlDoc:x(l.Guide.data.attributes,"url")}},3,r)),1,null)],1,null),n("div",null,{class:"flex w-full flex-col items-center justify-center"},n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex min-[800px]:w-[70%] flex-col items-center justify-center gap-4 px-10"},[n("div",null,{class:"max-w-[470px]"},i(P,{get media(){return a.Logo.data.attributes},height:"230",width:"1230",[s]:{height:s,media:x(a.Logo.data,"attributes"),width:s}},3,"yQ_3"),1,null),n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},_(a,"Title"),1,null),1,null),i(C,{get text(){return a.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{classN:s,text:x(a,"Paragraph")}},3,"yQ_4")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(Kr,{get nameDoc(){return a.GuideBox.Guide.data.attributes.name},get urlDoc(){return a.GuideBox.Guide.data.attributes.url},get image(){return a.Picture.data.attributes},get title(){return a.GuideBox.Title},get btnText(){return a.GuideBox.BtnText},[s]:{btnText:x(a.GuideBox,"BtnText"),image:x(a.Picture.data,"attributes"),nameDoc:x(a.GuideBox.Guide.data.attributes,"name"),title:x(a.GuideBox,"Title"),urlDoc:x(a.GuideBox.Guide.data.attributes,"url")}},3,"yQ_5"),1,null)],1,null),1,null)],1,"yQ_6")},rm=m(g(sm,"s_L3FZbhALRyo")),im=t=>`query gfTvSupport {
        pageGfTvS (locale:"${t}") {
          data {
            attributes {
              IntroText
              IntroMedia {
                ${$}
              }
              DevicesTitle
              Devices {
                Title
                Paragraph
                Buttons {
                  Text
                  Link
                }
              }
              DevicesNote
              GuidePar {
                Title
                Paragraph
              }
              Guides {
                Title
                BtnText
                Guide {
                  data {
                    attributes {
                      url
                      name
                    }
                  }
                }
              }
              ${q}
            }
          }
        }
        sectionChGuide{
          data{
            attributes{
              Logo{
                ${$}
              }
              Picture{
                ${$}
              }
              Title
              Paragraph
              GuideBox{
                Title
                BtnText
                Guide{
                  data{
                    attributes{
                      url
                      name
                    }
                  }
                }
              }
            }
          }
        }
      }
      `,om=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(im,e)},xn=N(g(om,"s_Y5JMYQJnIpI")),um=()=>{const t=xn(),e=t.value.pageData.data;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(rm,{data:e},3,"GS_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"GS_1")},1,"GS_2")},cm=m(g(um,"s_sZYBtsmoVg8")),dm=({resolveValue:t})=>{const a=t(xn).pageData.data.pageGfTvS.data.attributes.SEO;return G(a)},pm=Object.freeze(Object.defineProperty({__proto__:null,default:cm,head:dm,usePageData:xn},Symbol.toStringTag,{value:"Module"})),fm=t=>n("div",null,{class:"gap-10 w-ful flex flex-col"},t.data.map((e,a)=>W(a%2==0?n("div",null,{class:"bg-primary-blue bg-opacity-40 py-10"},n("div",null,{class:"bg-primary-blue bg-opacity-60 py-10"},n("div",null,{class:"bg-primary-blue"},i(kt,{color:"white",reverse:!0,get text(){return e.Paragraph},get image(){return e.Media.data.attributes},backgroundColor:"primary-blue",textPercentage:50,title:e.Title!=null?e.Title:"",[s]:{backgroundColor:s,color:s,image:x(e.Media.data,"attributes"),reverse:s,text:x(e,"Paragraph"),textPercentage:s}},3,a),1,null),1,null),1,a):i(kt,{reverse:!1,get text(){return e.Paragraph},get image(){return e.Media.data.attributes},textPercentage:50,title:e.Title!=null?e.Title:"",[s]:{image:x(e.Media.data,"attributes"),reverse:s,text:x(e,"Paragraph"),textPercentage:s}},3,a))),1,"1n_0"),gm=m(g(fm,"s_3YkhEsBDjTI")),xm=t=>(console.log("botón de ver más: ",t.btnSeeMoreLink),n("div",null,{class:"justify-between min-h-[670px] w-[300px] items-center shadow-lg bg-white flex flex-col px-5 pb-4 rounded-[35px]"},[n("div",null,{class:"items-center self-center flex w-[310px] max-w-full flex-col mt-8"},[n("div",null,{class:"items-start self-center flex w-full gap-5"},[i(P,{height:80,width:80,get media(){return t.logo},clasN:"aspect-square object-contain object-center w-[70px] justify-center items-center overflow-hidden self-stretch max-w-full",[s]:{clasN:s,height:s,media:u(e=>e.logo,[t],"p0.logo"),width:s}},3,"Tv_0"),n("div",null,{class:"self-center flex flex-col my-auto"},[n("div",null,{class:"text-blue-800 text-2xl font-bold leading-6 self-start whitespace-nowrap"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"justify-center text-rose-700 text-xl mt-2"},u(e=>e.subtitle,[t],"p0.subtitle"),3,null)],3,null)],1,null),n("div",null,{class:"text-blue-800 flex flex-row mt-5"},[n("span",null,{class:"font-light text-3xl text-rose-700"},"$",3,null),n("span",null,{class:"font-light text-3xl text-blue-800"},u(e=>e.price,[t],"p0.price"),3,null),n("span",null,{class:" text-blue-800"},["/",u(e=>e.priceTime,[t],"p0.priceTime")],3,null)],3,null),n("div",null,{class:"items-start self-stretch flex flex-col mt-5"},[n("div",null,{class:"justify-between items-start self-stretch flex w-full gap-5"},[n("div",null,{class:"text-blue-800 text-center text-base"},u(e=>e.description,[t],"p0.description"),3,null),i(xa,{get link(){return t.btnSeeMoreLink},get dataChannels(){return t.dataChannels},get planId(){return t.title},get channels(){return t.subtitle},get text(){return t.btnSeeMoreText},[s]:{channels:u(e=>e.subtitle,[t],"p0.subtitle"),dataChannels:u(e=>e.dataChannels,[t],"p0.dataChannels"),link:u(e=>e.btnSeeMoreLink,[t],"p0.btnSeeMoreLink"),planId:u(e=>e.title,[t],"p0.title"),text:u(e=>e.btnSeeMoreText,[t],"p0.btnSeeMoreText")}},3,"Tv_1")],1,null),n("div",null,{class:"justify-center items-start self-stretch flex gap-2.5 mt-2.5"},t.channels.map((e,a)=>i(P,{height:50,width:50,get media(){return e.attributes},clasN:"aspect-square object-contain object-center w-full overflow-hidden flex-1",[s]:{clasN:s,height:s,media:x(e,"attributes"),width:s}},3,a)),1,null)],1,null),n("div",null,{class:"border-gary-500 h-[1px] w-full border-t-2"},null,3,null),n("div",null,{class:"self-stretch w-full h-px mt-5 max-md:mx-0.5"},null,3,null),n("div",null,{class:"text-blue-800 text-base mt-5"},t.features.map((e,a)=>n("span",null,{class:"my-1 flex flex-row items-center justify-start"},[n("div",null,null,i(Fr,{class:"mx-2 h-[20px] w-[20px] fill-primary-blue text-primary-blue",[s]:{class:s}},3,"Tv_2"),1,null),n("h3",null,{class:"text-sm font-light"},_(e,"Text"),1,a)],1,a)),1,null)],1,null),i(xa,{get link(){return t.btnLink},get text(){return t.btnText},[s]:{link:u(e=>e.btnLink,[t],"p0.btnLink"),text:u(e=>e.btnText,[t],"p0.btnText")}},3,"Tv_3")],1,"Tv_4")),mm=m(g(xm,"s_0v0O47RLS1E")),hm=t=>n("div",null,{class:"flex flex-col items-center justify-center my-8 mx-4"},[n("h2",null,{class:"text-3xl text-center md:text-5xl font-semibold text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-5 lg:gap-10 my-6"},t.data.map((e,a)=>i(mm,{get logo(){return e.Logo.data.attributes},get title(){return e.Title},get subtitle(){return e.Subtitle},get price(){return e.Price},get priceTime(){return e.Pricetime},get description(){return e.Description},get channels(){return e.Channels.data},get btnSeeMoreLink(){return e.LineupButton.Link},get btnSeeMoreText(){return e.LineupButton.Text},get features(){return e.Features},get btnLink(){return e.Button.Link},get btnText(){return e.Button.Text},get dataChannels(){return t.dataChannels},[s]:{btnLink:x(e.Button,"Link"),btnSeeMoreLink:x(e.LineupButton,"Link"),btnSeeMoreText:x(e.LineupButton,"Text"),btnText:x(e.Button,"Text"),channels:x(e.Channels,"data"),dataChannels:u(l=>l.dataChannels,[t],"p0.dataChannels"),description:x(e,"Description"),features:x(e,"Features"),logo:x(e.Logo.data,"attributes"),price:x(e,"Price"),priceTime:x(e,"Pricetime"),subtitle:x(e,"Subtitle"),title:x(e,"Title")}},3,a)),1,null)],1,"q0_0"),$m=m(g(hm,"s_m0jKnAHnXds")),bm=t=>n("div",null,{class:"flex flex-col items-center justify-center px-6"},[n("h2",null,{class:"text-3xl md:text-5xl my-3 font-semibold text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap gap-8 items-start justify-center my-4"},t.data.map((e,a)=>n("div",null,{class:"flex flex-col w-full md:w-2/5 my-3 md:my-5 p-6 text-center items-center justify-center rounded-2xl bg-white shadow-xl"},[n("h3",null,{class:"text-primary-dark-blue my-4 font-semibold text-xl"},_(e,"Title"),1,null),i(C,{get text(){return e.Paragraph},[s]:{text:x(e,"Paragraph")}},3,"ys_0")],1,a)),1,null),i(C,{classN:"markdownli text-s",get text(){return t.disclaimers},[s]:{classN:s,text:u(e=>e.disclaimers,[t],"p0.disclaimers")}},3,"ys_1")],1,"ys_2"),ym=m(g(bm,"s_Sqd58asrM5U")),vm=t=>{let e=[];return n("div",null,{class:"flex flex-col items-center justify-center"},[n("h2",null,{class:"text-3xl text-center md:text-5xl my-3 font-semibold text-primary-blue"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap items-start justify-center my-6 gap-5"},t.data.map((a,l)=>n("div",null,{class:"w-[290px] min-h-[300px] py-6 px-2 flex-col items-center justify-center flex rounded-3xl bg-primary-blue"},[n("h2",null,{class:"text-3xl font-semibold text-white"},_(a,"Title"),1,null),n("div",null,{class:"flex flex-row"},[n("h2",null,{class:"text-white text-2xl"},["$ ",_(a,"Price")],1,null),n("p",null,{class:"text-white"},[" ",_(a,"Pricetime")],1,null)],1,null),n("div",null,{class:"flex flex-col bg-white w-full rounded-2xl mt-4 p-4"},a.Features.map((r,o)=>{if(W(),o<3)return e=[],n("div",null,{class:"flex flex-row gap-2 p-1 border-b-2"},[i(cs,{class:"text-secondary-red",[s]:{class:s}},3,"yk_0"),n("p",null,{class:"text-primary-blue"},_(r,"Title"),1,null)],1,o);if(o>=3&&(e.push(n("div",null,{class:"flex flex-row gap-2 p-1 border-b-2"},[i(cs,{class:"text-secondary-red",[s]:{class:s}},3,"yk_1"),n("p",null,{class:"text-primary-blue"},_(r,"Title"),1,null)],1,o)),o==3))return i(_e,{children:e,title:"Show all channels",[s]:{title:s}},1,"yk_2")}),1,null)],1,l)),1,null)],1,"yk_3")},wm=m(g(vm,"s_5iYsl7ZjuZc")),_m=t=>{const e=t.data.data.pageGfTv.data.attributes,a=t.data.data.sectionChGuide.data.attributes,l=t.data.data.channelLineups.data;return n("div",null,{class:"flex flex-col justify-around"},[n("div",null,{class:"flex flex-col my-6 items-center justify-center gap-4"},[i(P,{get media(){return e.Logo.data.attributes},height:200,width:500,[s]:{height:s,media:x(e.Logo.data,"attributes"),width:s}},3,"5L_0"),n("h2",null,{class:"text-[50px] font-bold text-center text-primary-blue"},_(e.Titles[0],"Text"),1,null),n("h2",null,{class:"text-[50px] font-bold text-center text-secondary-red"},_(e.Titles[1],"Text"),1,null)],1,null),i(gm,{get data(){return e.Features},[s]:{data:x(e,"Features")}},3,"5L_1"),n("div",null,{class:"flex flex-col text-center p-4 items-center justify-center my-8"},[n("h2",null,{class:"text-3xl md:text-5xl font-semibold text-primary-blue my-6"},_(e.Feature,"Title"),1,null),i(C,{get text(){return e.Feature.Paragraph},[s]:{text:x(e.Feature,"Paragraph")}},3,"5L_2")],1,null),i($m,{dataChannels:l,get data(){return e.ChPackTables},get title(){return e.ChPackTitle},[s]:{data:x(e,"ChPackTables"),title:x(e,"ChPackTitle")}},3,"5L_3"),i(wm,{get data(){return e.PremiumTables},get title(){return e.PremiumTitle},[s]:{data:x(e,"PremiumTables"),title:x(e,"PremiumTitle")}},3,"5L_4"),n("div",null,{class:"flex w-full flex-col items-center justify-center"},[n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex min-[800px]:w-[70%] flex-col items-center justify-center gap-4 px-10"},[n("div",null,{class:"max-w-[470px]"},i(P,{get media(){return a.Logo.data.attributes},height:"230",width:"1230",[s]:{height:s,media:x(a.Logo.data,"attributes"),width:s}},3,"5L_5"),1,null),n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},_(a,"Title"),1,null),1,null),i(C,{get text(){return a.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{classN:s,text:x(a,"Paragraph")}},3,"5L_6")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(Kr,{get nameDoc(){return a.GuideBox.Guide.data.attributes.name},get urlDoc(){return a.GuideBox.Guide.data.attributes.url},get image(){return a.Picture.data.attributes},get title(){return a.GuideBox.Title},get btnText(){return a.GuideBox.BtnText},[s]:{btnText:x(a.GuideBox,"BtnText"),image:x(a.Picture.data,"attributes"),nameDoc:x(a.GuideBox.Guide.data.attributes,"name"),title:x(a.GuideBox,"Title"),urlDoc:x(a.GuideBox.Guide.data.attributes,"url")}},3,"5L_7"),1,null)],1,null),i(ym,{get data(){return e.Additionals},get disclaimers(){return e.Disclaimers},get title(){return e.AdditionalsTitle},[s]:{data:x(e,"Additionals"),disclaimers:x(e,"Disclaimers"),title:x(e,"AdditionalsTitle")}},3,"5L_8")],1,null)],1,"5L_9")},Sm=m(g(_m,"s_dsszBuF1I7U")),Tm=t=>`sectionChGuide(locale:"${t}"){
        data{
          attributes{
            Logo{
              ${$}
            }
            Title
            Paragraph
            
            GuideBox{
              BtnText
              Guide{
                data{
                  attributes{
                    name
                    url
                  }
                }
              }
            }
            
            Picture{
             ${$}
            }
          }
        }
      }`,Dm=t=>`query {
        pageGfTv(locale:"${t}"){
          data {
            attributes {
              Logo {
               ${$}
              }
              Titles {
                Text
              }
              Features {
                Title
                Subtitle
                Paragraph
                Media {
                  ${$}
                }
              }
              Feature {
                Title
                Subtitle
                Paragraph
              }
              ChPackTitle
              ChPackTables {
                Logo {
                  ${$}
                }
                Title
                Subtitle
                Price
                Pricetime
                Description
                Channels {
                  ${$}
                }
                LineupButton{
                  Text
                  Link
                }
                Features {
                  Title
                  Text
                }
                Button {
                  Text
                  Link
                }
              }
              PremiumTitle
              PremiumTables {
                Title
                Price
                Pricetime
                Features {
                  Title
                }
              }
      
              
              
              AdditionalsTitle
              Additionals {
                Title
                Paragraph
              }
              Disclaimers
              
              ${q}
            }
          }
        }
        
        ${Tm(t)}

        channelLineups (pagination:{limit:250}){
          data{
            attributes{
              Channel_name
              Image{
                ${$}
              }
              Category
              package_tvs{
                data{
                  attributes{
                    package
                  }
                }
              }
            }
        }
        }
      }`,Pm=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(Dm,e)},mn=N(g(Pm,"s_dLnU84H8AgM")),km=()=>{const t=mn();return console.log(t.value.pageData),i(Q,{children:i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageGfTv.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfTv.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfTv"]["data"]["attributes"]["SEO"]')}},3,"ad_0"),i(Sm,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"ad_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"ad_2")},1,"ad_3")},Lm=m(g(km,"s_yF5Z09ey0P4")),Cm=({resolveValue:t})=>{const a=t(mn).pageData.data.pageGfTv.data.attributes.SEO;return G(a)},Mm=Object.freeze(Object.defineProperty({__proto__:null,default:Lm,head:Cm,usePageData:mn},Symbol.toStringTag,{value:"Module"})),jm=t=>{const e=t.data.pageGfVS.data.attributes,a=t.data.sectionPortGfv.data.attributes.Portability;return n("div",null,{class:"flex flex-col items-center"},[n("div",null,{class:"relative w-full md:w-2/3 h-[210px] md:h-[150px] bg-blue-200 flex flex-row justify-end items-center rounded-full"},[n("div",null,{class:"h-full absolute rounded-full w-3/4 bg-blue-300"},null,3,null),n("div",null,{class:"h-full absolute rounded-full w-2/4 bg-blue-400"},null,3,null),n("div",null,{class:"h-full absolute rounded-full w-1/4 bg-blue-600"},null,3,null),n("div",null,{class:"absolute w-full h-full flex flex-row p-5 justify-between items-center"},[n("h1",null,{class:"text-primary-blue lg:text-3xl md:text-2xl font-bold text-center text-xl"},_(e.Introduction,"Paragraph"),1,null),i(P,{get media(){return e.Introduction.Media.data.attributes},height:150,width:200,[s]:{height:s,media:x(e.Introduction.Media.data,"attributes"),width:s}},3,"T3_0")],1,null)],1,null),n("div",null,{class:"flex flex-col mt-10 justify-center px-8 items-center"},[n("div",null,{class:"w-full md:w-2/3 flex flex-col items-center"},[n("h2",null,{class:"text-3xl md:text-4xl text-center font-bold text-primary-blue"},_(e.GuidesPar,"Title"),1,null),i(C,{classN:"text-center",get text(){return e.GuidesPar.Paragraph},[s]:{classN:s,text:x(e.GuidesPar,"Paragraph")}},3,"T3_1")],1,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-10 my-5"},e.Guides.map((l,r)=>i(Xr,{get urlDoc(){return l.Guide.data.attributes.url},get title(){return l.Title},get btnText(){return l.BtnText},get nameDoc(){return l.Guide.data.attributes.name},[s]:{btnText:x(l,"BtnText"),nameDoc:x(l.Guide.data.attributes,"name"),title:x(l,"Title"),urlDoc:x(l.Guide.data.attributes,"url")}},3,r)),1,null)],1,null),n("div",null,null,i(kt,{get title(){return a.Title},get text(){return a.Paragraph},get logo(){return a.Logo.data.attributes},get image(){return a.Media.data.attributes},backgroundColor:"transparent",get buttons(){return a.Buttons},[s]:{backgroundColor:s,buttons:x(a,"Buttons"),image:x(a.Media.data,"attributes"),logo:x(a.Logo.data,"attributes"),text:x(a,"Paragraph"),title:x(a,"Title")}},3,"T3_2"),1,null)],1,"T3_3")},Em=m(g(jm,"s_BWUEQjQaK9s")),Bm=t=>`query queryGFTvSupport{
        pageGfVS(locale:"${t}"){
          data{
            attributes{
              Introduction{
                Paragraph
                Media{
                  ${$}
                }
              }
              GuidesPar{
                Title
                Paragraph
              }
              Guides{
                Title
                BtnText
                Guide{
                  data{
                    attributes{
                      url
                      name
                    }
                  }
                }
              }
              ${q}
            }
          }
        }
        sectionPortGfv(locale:"${t}"){
          data{
            attributes{
              Portability{
                Title
                Logo{
                 ${$}
                }
                Paragraph
                Media{
                 ${$}
                }
                Buttons{
                  Text
                  Link
                }
              }
            }
          }
        }
      }`,Im=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(Bm,e)},hn=N(g(Im,"s_MmL0KO3X80U")),Om=()=>{const t=hn();return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(Em,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Wc_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Wc_1")},1,"Wc_2")},Am=m(g(Om,"s_MnhzpLl96M8")),Nm=({resolveValue:t})=>{const a=t(hn).pageData.data.pageGfVS.data.attributes.SEO;return G(a)},Rm=Object.freeze(Object.defineProperty({__proto__:null,default:Am,head:Nm,usePageData:hn},Symbol.toStringTag,{value:"Module"})),qm=t=>n("div",null,{class:"flex w-full justify-center text-primary-blue"},n("div",null,{class:"mx-8 my-8 flex flex-col items-center gap-6 text-center text-[18px]"},[i(P,{get media(){return t.data.Logo.data.attributes},clasN:"mb-6",width:"450",[s]:{clasN:s,media:u(e=>e.data.Logo.data.attributes,[t],'p0.data["Logo"]["data"]["attributes"]'),width:s}},3,"0F_0"),i(C,{get text(){return t.data.Paragraph},[s]:{text:u(e=>e.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"0F_1"),i(Z,{get text(){return t.data.Buttons[0].Text},get link(){return t.data.Buttons[0].Link},[s]:{link:u(e=>e.data.Buttons[0].Link,[t],'p0.data["Buttons"][0]["Link"]'),text:u(e=>e.data.Buttons[0].Text,[t],'p0.data["Buttons"][0]["Text"]')}},3,"0F_2")],1,null),1,"0F_3"),Fm=m(g(qm,"s_Ue8VWX4F1hY")),zm=t=>n("div",null,{class:"max-w-1200 mx-8 flex flex-wrap justify-evenly gap-6"},t.data.map((e,a)=>i(dn,{get title(){return e.Title},get btnText(){return e.Button.Text},get btnLink(){return e.Button.Link},get description(){return e.Description},price:e.Price.toString(),get features(){return e.Features},get logo(){return e.Logo.data.attributes},get priceTime(){return e.Pricetime},[s]:{btnLink:x(e.Button,"Link"),btnText:x(e.Button,"Text"),description:x(e,"Description"),features:x(e,"Features"),logo:x(e.Logo.data,"attributes"),priceTime:x(e,"Pricetime"),title:x(e,"Title")}},3,a)),1,"mV_0"),Gm=m(g(zm,"s_2f78m38d8Zo")),Qm=t=>{const e={...t.data.pageGfV.data.attributes.Introduction,Logo:t.data.pageGfV.data.attributes.Logo},a=t.data.pageGfV.data.attributes.PackTables,l=t.data.sectionPortGfv.data.attributes.Portability;return n("div",null,null,[i(Fm,{data:e},3,"Pl_0"),n("div",null,{class:"mt-6"},i(Gm,{data:a},3,"Pl_1"),1,null),n("div",null,{class:"mt-6"},i(qt,{backgroundColor:"transparent",color:"primary-blue",data:l,[s]:{backgroundColor:s,color:s}},3,"Pl_2"),1,null)],1,"Pl_3")},Hm=m(g(Qm,"s_S2NF7hg0ZA8")),Wm=t=>`
  query {
    pageGfV(locale:"${t}") {
      data {
        attributes {
          Logo {
            ${$}
          }
          Introduction {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          PackTables {
            Logo {
              ${$}
            }
            Title
            Subtitle
            Price
            Pricetime
            Description
            Features {
              Title
              Text
            }
            Button {
              Text
              Link
              Icon {
                ${$}
              }
            }
          }
          ${q}
        
        }
      }
    }
    sectionPortGfv(locale:"${t}"){
        data{
          attributes{
            Portability{
              Title
              Logo{
               ${$}
              }
              Paragraph
              Media{
               ${$}
              }
              Buttons{
                Text
                Link
              }
            }
          }
        }
      }
  }
    `,Um=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(Wm,e)},$n=N(g(Um,"s_ThxJp560MGY")),Ym=()=>{const t=$n();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageGfV.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfV.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfV"]["data"]["attributes"]["SEO"]')}},3,"0t_0"),i(Hm,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"0t_1")],showHeader:!1,[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"0t_2")},Vm=m(g(Ym,"s_1bc90Wt0fJ4")),Zm=({resolveValue:t})=>{const a=t($n).pageData.data.pageGfV.data.attributes.SEO;return G(a)},Xm=Object.freeze(Object.defineProperty({__proto__:null,default:Vm,head:Zm,usePageData:$n},Symbol.toStringTag,{value:"Module"})),Km=t=>{const e=t.data.pageGivingBack.data.attributes.Helping;return n("div",null,{onClick$:I("s_IrVC6P6zSuQ")},i(oe,{data:e},3,"eb_0"),1,"eb_1")},Jm=m(g(Km,"s_g0kQhWSZ3HE")),th=t=>`
    query QueryGivingBack {
        pageGivingBack(locale:"${t}"){    
          data{
            attributes{
                 Title
              Helping{
                Logo{
                 ${$}
                }
                Media{
                  ${$}
                }
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              ${q}
            }
          }
        }
      }
    `,eh=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(th,e)},bn=N(g(eh,"s_HxhGEMn0sRc")),ah=()=>{const t=bn();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageGivingBack.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGivingBack.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGivingBack"]["data"]["attributes"]["SEO"]')}},3,"4m_0"),i(Jm,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"4m_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"4m_2")},lh=m(g(ah,"s_NbmekxDi7Vw")),nh=({resolveValue:t})=>{const a=t(bn).pageData.data.pageGivingBack.data.attributes.SEO;return G(a)},sh=Object.freeze(Object.defineProperty({__proto__:null,default:lh,head:nh,usePageData:bn},Symbol.toStringTag,{value:"Module"})),rh=t=>{const e=t.data.Logo.data.attributes;return n("div",null,{class:"min-h-screen w-full flex flex-col items-center"},[i(P,{clasN:"pt-5 px-5",height:"80px",media:e,width:"200px",[s]:{clasN:s,height:s,width:s}},3,"mB_0"),i(ln,{get parData(){return t.data.SectionHead},[s]:{parData:u(a=>a.data.SectionHead,[t],'p0.data["SectionHead"]')}},3,"mB_1"),i(nn,{get speedList(){return t.data.SpeedBullets},[s]:{speedList:u(a=>a.data.SpeedBullets,[t],'p0.data["SpeedBullets"]')}},3,"mB_2"),i(sn,{get parData(){return t.data.SectionRating},[s]:{parData:u(a=>a.data.SectionRating,[t],'p0.data["SectionRating"]')}},3,"mB_3"),n("div",null,{class:"w-full bg-white  flex md:flex-row flex-col items-center justify-between"},[n("div",null,{class:" flex flex-row gap-5 p-1"},t.data.Footer&&t.data.Footer.map((a,l)=>i(Gt,{get href(){return a.Link},children:_(a,"Text"),class:" hover:text-primary-blue/60 text-primary-blue font-bold",[s]:{class:s,href:x(a,"Link")}},1,l)),1,null),n("div",null,{class:"text-primary-blue text-center"},"© 2024 Rural Telecommunications of America, Inc. All rights reserved.",3,null)],1,null)],1,"mB_4")},ih=m(g(rh,"s_TtLrO4fYqlI")),oh=t=>`query QueryLPGoldsmith {
        lpGoldsmith (locale:"${t}"){    
          data{
            attributes{
              Logo{
                ${$}
              }

              SectionHead{
                Title
                Subtitle
                Paragraph
                Logo{
                    ${$}
                }
                Media{
                    ${$}
                }
                Buttons{
                  Text
                  Link
                }
              }

              SpeedBullets{
                Title
                Text
              }

              SectionRating{
                Title
                Subtitle
                Paragraph
                Buttons{
                  Text
                  Link
                }
                Media{
                    ${$}
                }
              }
              
              Footer{
                Text
                Link
              }
            ${q}
            }
          }
        }
        
      }`,uh=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(oh,e)},yn=N(g(uh,"s_VvrWzA20lF0")),ch=()=>{const t=yn();return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(ih,{get data(){return t.value.pageData.data.lpGoldsmith.data.attributes},[s]:{data:u(e=>e.value.pageData.data.lpGoldsmith.data.attributes,[t],'p0.value["pageData"]["data"]["lpGoldsmith"]["data"]["attributes"]')}},3,"BY_0"),showHeader:!1,showMenus:!1,[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s,showMenus:s}},1,"BY_1")},1,"BY_2")},dh=m(g(ch,"s_WHj3dLp4igs")),ph=({resolveValue:t})=>{const a=t(yn).pageData.data.lpGoldsmith.data.attributes.SEO;return G(a)},fh=Object.freeze(Object.defineProperty({__proto__:null,default:dh,head:ph,usePageData:yn},Symbol.toStringTag,{value:"Module"})),gh=t=>`query QueryLeadershipTeam{
        pageLeadershipT(locale:"${t}"){
          data{
            attributes{
              ${Rr}
              ${q}
              }
            }
          }
        }`,xh=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(gh,e)},vn=N(g(xh,"s_ZvTItzMmB40")),mh=()=>{const t=vn(),e=t.value.pageData.data.pageLeadershipT.data.attributes;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageLeadershipT.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageLeadershipT.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageLeadershipT"]["data"]["attributes"]["SEO"]')}},3,"cW_0"),i(Vr,{data:e},3,"cW_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"cW_2")},1,"cW_3")},hh=m(g(mh,"s_VJGz1Q1nMWA")),$h=({resolveValue:t})=>{const a=t(vn).pageData.data.pageLeadershipT.data.attributes.SEO;return G(a)},bh=Object.freeze(Object.defineProperty({__proto__:null,default:hh,head:$h,usePageData:vn},Symbol.toStringTag,{value:"Module"})),yh=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),n("h2",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[1].Text,[t],'p0.data["Titles"][1]["Text"]'),3,null),i(C,{get text(){return t.data.TextContent},classN:" text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"tP_0")],1,"tP_1"),vh=m(g(yh,"s_l6pybhQ4d3A")),wh=t=>`query QueryLegal {
        pageLegal(locale:"${t}"){    
          ${Xe}
          ${q}
            }
          }
        }
      }`,_h=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(wh,e)},wn=N(g(_h,"s_p9UoBCtfUPo")),Sh=()=>{const t=wn(),e=t.value.pageData.data.pageLegal.data.attributes.Content;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(vh,{data:e},3,"W8_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"W8_1")},1,"W8_2")},Th=m(g(Sh,"s_DAHSW75A6dQ")),Dh=({resolveValue:t})=>{const a=t(wn).pageData.data.pageLegal.data.attributes.SEO;return G(a)},Ph=Object.freeze(Object.defineProperty({__proto__:null,default:Th,head:Dh,usePageData:wn},Symbol.toStringTag,{value:"Module"})),kh=t=>{const e=t.data.pageLocWeather.data.attributes,a=l=>`https://raw.githubusercontent.com/visualcrossing/WeatherIcons/main/PNG/1st%20Set%20-%20Color/${l}.png`;return n("div",null,{class:"flex flex-wrap items-center justify-center gap-8 px-8 py-8 text-white",onClick$:I("s_VJdTV7fBj8k")},t.data.weatherData.data.map((l,r)=>n("div",null,{class:"relative h-[350px] w-[600px] max-[1200px]:h-[280px] max-[1200px]:w-[500px]"},[n("div",null,{class:"relative flex h-full w-[50%] flex-col justify-between overflow-hidden rounded-[30px] px-4 py-8 "},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-[6] h-full w-full"},i(P,{clasN:"h-[400px]",height:"3086",width:"2622",get media(){return e.LocTables.find(o=>o.Location===l.city).LocationPic.data.attributes},[s]:{clasN:s,height:s,media:x(e.LocTables.find(o=>o.Location===l.city).LocationPic.data,"attributes"),width:s}},3,"tT_0"),1,null),n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-[5] h-full w-full bg-black opacity-30"},null,3,null),n("div",null,{class:"flex flex-col"},[n("span",{onClick$:I("s_K3eGiPS50Ks",[l])},{class:"text-[20px] font-[700]"},aa(l.data.days[0].datetime).split(", ")[0],0,null),n("span",null,{class:"text-[12px]"},aa(l.data.days[0].datetime,!1),1,null),n("div",null,{class:"mt-2 flex items-center gap-3"},[i(Rl,{class:"text-[15px] text-white",[s]:{class:s}},3,"tT_1"),n("span",null,{class:"text-[17px] font-[600] max-[1200px]:text-[15px]"},_(l,"city"),1,null)],1,null)],1,null),n("div",null,null,[n("span",null,{class:"text-[18px] font-[700]"},_(l.data.days[0],"conditions"),1,null),n("img",{alt:`icon-${l.data.days[0].icon}`,src:a(l.data.days[0].icon),title:`icon-${l.data.days[0].icon}`},{height:"50",width:"50"},null,3,null)],1,null),n("div",null,{class:"flex w-full justify-evenly"},[n("div",null,{class:"flex flex-col items-center"},[n("span",null,{class:"text-[14px]"},"Min",3,null),n("span",null,{class:"text-[28px] font-[700] max-[1200px]:text-[20px]"},[_(l.data.days[0],"tempmin"),"°F"],1,null)],1,null),n("div",null,{class:"flex flex-col items-center"},[n("span",null,{class:"text-[14px]"},"Max",3,null),n("span",null,{class:"text-[28px] font-[700] max-[1200px]:text-[20px]"},[_(l.data.days[0],"tempmin"),"°F"],1,null)],1,null)],1,null)],1,null),n("div",null,{class:"absolute bottom-3 right-0 top-3 -z-[7] flex w-[56%] flex-col gap-1 rounded-[30px] bg-[#172c4b] py-8 pl-14 pr-6 text-[17px] max-[1200px]:text-[13px]"},[n("div",null,{class:"flex justify-between font-[700] "},[n("span",null,null,"PRECIPITATION",3,null),n("span",null,{class:"font-[300]"},[_(l.data.days[0],"precipprob"),"%"],1,null)],1,null),n("div",null,{class:"flex justify-between font-[700]"},[n("span",null,null,"HUMIDITY",3,null),n("span",null,{class:"font-[300]"},[_(l.data.days[0],"humidity"),"%"],1,null)],1,null),n("div",null,{class:"flex justify-between font-[700]"},[n("span",null,null,"WIND",3,null),n("span",null,{class:"font-[300]"},[_(l.data.days[0],"windspeed")," mph"],1,null)],1,null),n("div",null,{class:"mt-6 grid grid-cols-3 justify-center gap-1"},[1,2,3].map(o=>n("div",null,{class:"flex flex-col items-center gap-1 text-[12px] max-[1200px]:text-[9px]"},[n("img",{alt:`icon-${l.data.days[o].icon}`,src:a(l.data.days[o].icon),title:`icon-${l.data.days[o].icon}`},{height:"30",width:"30"},null,3,null),n("span",null,{class:""},aa(l.data.days[o].datetime).split(", ")[0],1,null),n("span",null,{class:"font-[600]"},[_(l.data.days[o],"tempmax"),"°F"],1,null),n("span",null,{class:"font-[600]"},[_(l.data.days[o],"tempmin"),"°F"],1,null)],1,o)),1,null)],1,null)],1,r)),1,"tT_2")},Lh=m(g(kh,"s_Eyqu8EYnqHs")),Ch=t=>`query locWeather{
        pageLocWeather(locale:"${t}"){
          data{
            attributes{
              LocTables{
                Location
                LocationPic{
                  ${$}
                }
              }
              ${q}
            }
          }
        }
      }`,Mh=async t=>{const e=t.params.lang==""?"en":"es-419",a=await z(Ch,e),l={status:"error",data:[]};for(const r of a.pageData.data.pageLocWeather.data.attributes.LocTables){const o=r.Location,c=await fetch(`https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${o}/next7days?unitGroup=us&include=days%2Ccurrent&key=J8MMBMZC9DTQTVGHBPNEWPPGS&contentType=json`);if(c.ok){const d=await c.json();l.data.push({city:o,data:d})}}return{...a,weatherData:l}},_n=N(g(Mh,"s_gwWti8fe82E")),jh=()=>{const t=_n();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageLocWeather.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageLocWeather.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageLocWeather"]["data"]["attributes"]["SEO"]')}},3,"rD_0"),i(Lh,{get data(){return{pageLocWeather:t.value.pageData.data.pageLocWeather,weatherData:t.value.weatherData}},[s]:{data:u(e=>({pageLocWeather:e.value.pageData.data.pageLocWeather,weatherData:e.value.weatherData}),[t],'{pageLocWeather:p0.value["pageData"]["data"]["pageLocWeather"],weatherData:p0.value["weatherData"]}')}},3,"rD_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"rD_2")},Eh=m(g(jh,"s_VS5ugbSZKZs")),Bh=({resolveValue:t})=>{const a=t(_n).pageData.data.pageLocWeather.data.attributes.SEO;return G(a)},Ih=Object.freeze(Object.defineProperty({__proto__:null,default:Eh,head:Bh,usePageData:_n},Symbol.toStringTag,{value:"Module"})),Oh=t=>{var o;const a=(o=vt().prevUrl)==null?void 0:o.pathname.includes("/es/"),l=t.data.pageNews.data.attributes,r=l.Posts.data[0].attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(Wl,{isES:a,post:r},3,"MY_0"),n("div",null,{class:"my-4"},null,3,null),i(Ul,{get posts(){return l.Posts.data},loadSize:3,type:"News",[s]:{loadSize:s,posts:x(l.Posts,"data"),type:s}},3,"MY_1")],1,"MY_2")},Ah=m(g(Oh,"s_d8TgHnXz650")),Nh=t=>` query QueryNews {
        pageNews(locale:"${t}"){    
          data{
          attributes{
            Posts(sort: "Date:desc", pagination: { limit: 100 }){
                data{
                  attributes{
                    Title
                    Date
                    Cover{
                      ${$}
                    }
                    Description
                    VideoLink
                    Gallery{
                      ${$}
                    }
                    Slug
                  }
                }
              }
            SugPages{
              Title
              Pages{
              Title
              Link
              Picture{
                ${$}
              }
              }
            }
            ${q}
          }
        }
        }
      }`,Rh=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(Nh,e)},Sn=N(g(Rh,"s_HdPbxCOsb5s")),qh=()=>{const t=Sn();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageNews.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageNews.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageNews"]["data"]["attributes"]["SEO"]')}},3,"7N_0"),i(Ah,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"7N_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"7N_2")},Fh=m(g(qh,"s_Afg1iFacoB8")),zh=({resolveValue:t})=>{const a=t(Sn).pageData.data.pageNews.data.attributes.SEO;return G(a)},Gh=Object.freeze(Object.defineProperty({__proto__:null,default:Fh,head:zh,usePageData:Sn},Symbol.toStringTag,{value:"Module"})),Qh=t=>n("div",null,{class:"flex flex-col items-center text-primary-blue"},[n("h2",null,{class:"px-4 md:px-8 text-center font-semibold text-secondary-red text-2xl md:text-3xl"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),n("h3",null,{class:"px-4 md:px-8 text-center text-xl md:text-2xl"},u(e=>e.data.Titles[1].Text,[t],'p0.data["Titles"][1]["Text"]'),3,null),n("div",null,{class:"flex px-4 md:px-8 mt-5 flex-wrap items-center justify-center"},[n("div",null,{class:"flex flex-col w-full lg:w-3/5 mx-5"},[n("h3",null,{class:"font-bold my-4 text-2xl md:text-4xl text-center"},u(e=>e.data.CommitmentPar.Title,[t],'p0.data["CommitmentPar"]["Title"]'),3,null),i(C,{get text(){return t.data.CommitmentPar.Paragraph},classN:"text-justify",[s]:{classN:s,text:u(e=>e.data.CommitmentPar.Paragraph,[t],'p0.data["CommitmentPar"]["Paragraph"]')}},3,"aa_0")],1,null),i(be,{height:"h-[350px]",width:"w-[350px]",get media(){return t.data.CommitmentPar.Media.data.attributes},[s]:{height:s,media:u(e=>e.data.CommitmentPar.Media.data.attributes,[t],'p0.data["CommitmentPar"]["Media"]["data"]["attributes"]'),width:s}},3,"aa_1")],1,null),n("div",null,{class:"flex px-8 mt-8 flex-col md:flex-row justify-center md:justify-around items-center md:items-start"},t.data.ColumnsPar.map((e,a)=>n("div",null,{class:"flex flex-col my-5 w-full md:w-1/2 justify-center items-center"},[n("h2",null,{class:"font-bold  text-2xl md:text-4xl text-center"},_(e,"Title"),1,null),i(C,{get text(){return e.Paragraph},[s]:{text:x(e,"Paragraph")}},3,"aa_2")],1,a)),1,null),n("h3",null,{class:"font-bold text-2xl md:text-4xl mt-8 text-center"},u(e=>e.data.SponsorshipsTitle,[t],'p0.data["SponsorshipsTitle"]'),3,null),n("div",null,{class:"flex items-center justify-center w-full my-4"},[n("div",null,{class:"w-full flex bg-primary-blue bg-opacity-30 my-4 h-[350px] py-10"},n("div",null,{class:"w-full bg-primary-blue py-10 bg-opacity-60"},n("div",null,{class:"w-full h-full bg-primary-blue"},null,3,null),3,null),3,null),t.data.Sponsorships.map((e,a)=>n("div",null,{class:"h-[350px] px-6 absolute flex flex-col justify-around items-center w-[250px] bg-white rounded-3xl shadow-xl"},[i(be,{height:"h-[200px]",width:"w-[200px]",get media(){return t.data.Sponsorships[0].Media.data.attributes},[s]:{height:s,media:u(l=>l.data.Sponsorships[0].Media.data.attributes,[t],'p0.data["Sponsorships"][0]["Media"]["data"]["attributes"]'),width:s}},3,"aa_3"),n("div",null,{class:"flex flex-col items-center"},[n("h3",null,{class:"text-secondary-red text-xl font-semibold"},_(e,"Title"),1,null),n("h3",null,{class:"text-secondary-red text-xl font-semibold"},_(e,"Subtitle"),1,null)],1,null),i(Z,{get text(){return e.Buttons[0].Text},get link(){return e.Buttons[0].Link},[s]:{link:x(e.Buttons[0],"Link"),text:x(e.Buttons[0],"Text")}},3,"aa_4")],1,a))],1,null)],1,"aa_5"),Hh=m(g(Qh,"s_RH3prNj9z7A")),Wh=t=>`query QueryOurStory{
        pageOurStory(locale:"${t}"){
          data{
            attributes{
              Titles{
                Text
              }
              CommitmentPar{
                Title
                Paragraph
                Media{
                ${$}
                }
              }
              
              ColumnsPar{
                Title
                Paragraph
              }
              
              SponsorshipsTitle
              Sponsorships{
                Title
                Subtitle
                Paragraph
                Media{
                ${$}
                }
                Buttons{
                  Text
                  Link
                }
              }
              ${q}
             
            }
          }
        }
      }`,Uh=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(Wh,e)},Tn=N(g(Uh,"s_I9YCjFVOHNE")),Yh=()=>{const t=Tn(),e=t.value.pageData.data.pageOurStory.data.attributes;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return e.SEO},[s]:{SEOdata:x(e,"SEO")}},3,"CH_0"),i(Hh,{data:e},3,"CH_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"CH_2")},1,"CH_3")},Vh=m(g(Yh,"s_ONSPkGdkwcs")),Zh=({resolveValue:t})=>{const a=t(Tn).pageData.data.pageOurStory.data.attributes.SEO;return G(a)},Xh=Object.freeze(Object.defineProperty({__proto__:null,default:Vh,head:Zh,usePageData:Tn},Symbol.toStringTag,{value:"Module"})),Kh=t=>{const e=t.data.Logo.data.attributes,a=t.data.Media.data.attributes;return n("div",null,{class:"flex max-w-[1200px] items-center justify-center self-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-4 px-10 min-[800px]:w-[70%]"},[n("div",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(l=>l.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"max-w-[470px]"},i(P,{height:230,media:e,width:1230,[s]:{height:s,width:s}},3,"Y3_0"),1,null),n("div",null,null,i(C,{classN:"max-sm:text-[15px] text-[18px] text-[#2E5899]",get text(){return t.data.Paragraph},[s]:{classN:s,text:u(l=>l.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"Y3_1"),1,null)],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(P,{height:1e3,media:a,width:1e3,[s]:{height:s,width:s}},3,"Y3_2"),1,null)],1,"Y3_3")},Jh=m(g(Kh,"s_G8eOcGEKYk4")),t$=t=>{const e=t.data.pagePortability.data.attributes.PortabilityActs,a=t.data.pagePortability.data.attributes.Introduction;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(Jh,{data:a},3,"C7_0"),i(oe,{data:e},3,"C7_1")],1,"C7_2")},e$=m(g(t$,"s_OvPpWmexBMU")),a$=t=>`
    query QueryPortability{
        pagePortability(locale:"${t}"){    
          data{
            attributes{
              Introduction{
                Title
                Subtitle
                Logo{
                ${$}
                }
                Paragraph
                Media{
                ${$}
                }
              }
              
              IntroductionBG{
                ${$}
              }
      
              PortabilityActs{
                Title
                Subtitle
                Buttons{
                  Text
                  Link
                }
                Logo{
                ${$}
                }
                Paragraph
                Media{
                ${$}
                }
              }
              ${q}
            }
          }
        }
      }
    `,l$=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(a$,e)},Dn=N(g(l$,"s_DV97RmVctT4")),n$=()=>{const t=Dn();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pagePortability.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pagePortability.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pagePortability"]["data"]["attributes"]["SEO"]')}},3,"eB_0"),i(e$,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"eB_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"eB_2")},s$=m(g(n$,"s_LbhuqOuteuA")),r$=({resolveValue:t})=>{const a=t(Dn).pageData.data.pagePortability.data.attributes.SEO;return G(a)},i$=Object.freeze(Object.defineProperty({__proto__:null,default:s$,head:r$,usePageData:Dn},Symbol.toStringTag,{value:"Module"})),Jr=new Date,o$=Jr.toISOString().substring(0,10),u$=Jr.toISOString().substring(11,19),ti=t=>`
    query QueryHome{
  pageHome(locale:"${t}"){
    data{
      attributes{
        
        VideoBGDesktop{
          ${$}
        }
        VideoBGMobile{
          ${$}
        }
        HeroCarSlideZS{
          Video{
            ${$}
          }
          Description
          Logo{
            ${$}
          }
          RaceDate
        }

        HeroCarSlides{
          Title
          Subtitle
          Logo{
          ${$}
          }
          Paragraph
          Media{
          ${$}
          }
          Buttons{
            Text
            Link
          }
        }
        HeroForm{
          Title
          ActionButton{
            Text
            Link
          }
        }
        ProsPar{
          Title
          Paragraph
        }

        ProsPicture{
          ${$}
        }
        ProsBackground{
          ${$}
        }
        ParACP{
          Title
          Subtitle
          Paragraph
          Logo{
          ${$}
          }
          Media{
          ${$}
          }
          Buttons{
            Text
            Link
          }
        }
        ParGFIPlans{
          Title
          Paragraph
          Disclaimer{
            Title
            Text
            Caption
            Icon{
          ${$}
            }
          }
          Table{
            ColumnOne
            ColumnTwo
            ColumnThree
          }

        }
        ParGFServices{
          Title
          Subtitle
          Logo{
          ${$}
          }
          Paragraph
          Media{
          ${$}
          }
          Buttons{
            Text
            Link
          }
        }
        SugsPages{
          Title
          Paragraph
          Media{
          ${$}
          }
          Buttons{
            Text
            Link
          }
        }
        SugsPagesBG{
          ${$}
        }
        ${q}
      }
    }
  }
  zaneRaces (
    filters: {RaceDay: {gte: "${o$}"}, RaceTime: {gte: "${u$}"}}, 
    locale:"en", 
    sort: "RaceDate"
    pagination: {limit: 1}) {
    data {
      attributes {
        Video {
          ${$}
        }
        Logo {
          ${$}
        }
        Description
        RaceDay
        RaceTime
      }
    }
  }
  sectionProsRta(locale:"${t}") {
    data {
      attributes {
        Pros {
          Icon {
            ${$}
          }
          Title
          Text
          Caption
        }
      }
    }
  }
  sectionNetwork {
    data {
      attributes {
        Map {
          MapPicture {
            ${$}
          }
        }
      }
    }
  }
}
`,c$=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang;return await z(ti,e)},d$=N(g(c$,"s_MfWlD1sVVR8")),p$=()=>n("div",null,null,"a",3,"yK_0"),f$=m(g(p$,"s_S2euYekMMCk")),g$=Object.freeze(Object.defineProperty({__proto__:null,default:f$,usePageData:d$},Symbol.toStringTag,{value:"Module"})),x$=t=>n("div",null,{class:"p-6"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(C,{get text(){return t.data.TextContent},classN:"markdownTitle markdownHyper text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{classN:s,text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]')}},3,"Vp_0")],1,"Vp_1"),m$=m(g(x$,"s_m0xHvviU9eM")),h$=t=>`
query QueryPrivacyP {
  pagePrivacyP(locale:"${t}"){    
    ${Xe}
    ${q}
      }
    }
  }
}
`,$$=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(h$,e)},Pn=N(g($$,"s_010w2sLh1OQ")),b$=()=>{const t=Pn(),e=t.value.pageData.data.pagePrivacyP.data.attributes.Content;return i(F,{get data(){return t.value.layoutData},children:i(m$,{data:e},3,"bX_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"bX_1")},y$=m(g(b$,"s_vRJXLmWn290")),v$=({resolveValue:t})=>{const a=t(Pn).pageData.data.pagePrivacyP.data.attributes.SEO;return G(a)},w$=Object.freeze(Object.defineProperty({__proto__:null,default:y$,head:v$,usePageData:Pn},Symbol.toStringTag,{value:"Module"})),_$=t=>{const e=t.data.Logo.data.attributes;return n("div",null,{class:"min-h-screen w-full flex flex-col items-center"},[i(P,{clasN:"pt-5 px-5",height:"80px",media:e,width:"200px",[s]:{clasN:s,height:s,width:s}},3,"Hd_0"),i(ln,{get parData(){return t.data.SectionHead},[s]:{parData:u(a=>a.data.SectionHead,[t],'p0.data["SectionHead"]')}},3,"Hd_1"),i(nn,{get speedList(){return t.data.SpeedBullets},[s]:{speedList:u(a=>a.data.SpeedBullets,[t],'p0.data["SpeedBullets"]')}},3,"Hd_2"),i(sn,{get parData(){return t.data.SectionRating},[s]:{parData:u(a=>a.data.SectionRating,[t],'p0.data["SectionRating"]')}},3,"Hd_3"),n("div",null,{class:"w-full bg-white  flex md:flex-row flex-col items-center justify-between"},[n("div",null,{class:" flex flex-row gap-5 p-1"},t.data.Footer&&t.data.Footer.map((a,l)=>i(Gt,{get href(){return a.Link},children:_(a,"Text"),class:" hover:text-primary-blue/60 text-primary-blue font-bold",[s]:{class:s,href:x(a,"Link")}},1,l)),1,null),n("div",null,{class:"text-primary-blue text-center"},"© 2024 Rural Telecommunications of America, Inc. All rights reserved.",3,null)],1,null)],1,"Hd_4")},S$=m(g(_$,"s_GrSLBBZP0DM")),T$=t=>`query QueryLPNeighborhood {
        lpNeighborhood (locale:"${t}"){    
          data{
            attributes{
              Logo{
                ${$}
              }

              SectionHead{
                Title
                Subtitle
                Paragraph
                Logo{
                    ${$}
                }
                Media{
                    ${$}
                }
                Buttons{
                  Text
                  Link
                }
              }

              SpeedBullets{
                Title
                Text
              }

              SectionRating{
                Title
                Subtitle
                Paragraph
                Buttons{
                  Text
                  Link
                }
                Media{
                    ${$}
                }
              }
              
              Footer{
                Text
                Link
              }
            ${q}
            }
          }
        }
        
      }`,D$=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(T$,e)},kn=N(g(D$,"s_6ulhbKSeU34")),P$=()=>{const t=kn();return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(S$,{get data(){return t.value.pageData.data.lpNeighborhood.data.attributes},[s]:{data:u(e=>e.value.pageData.data.lpNeighborhood.data.attributes,[t],'p0.value["pageData"]["data"]["lpNeighborhood"]["data"]["attributes"]')}},3,"iI_0"),showHeader:!1,showMenus:!1,[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s,showMenus:s}},1,"iI_1")},1,"iI_2")},k$=m(g(P$,"s_GygFChjqq7g")),L$=({resolveValue:t})=>{const a=t(kn).pageData.data.lpNeighborhood.data.attributes.SEO;return G(a)},C$=Object.freeze(Object.defineProperty({__proto__:null,default:k$,head:L$,usePageData:kn},Symbol.toStringTag,{value:"Module"})),M$=t=>n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"min-h-[200px] w-full bg-gradient-to-br from-primary-light-blue to-[#23477f] !text-white"},i(qt,{get data(){return t.data},backgroundColor:"primary-blue",color:"white",hasPricing:!1,reverse:!0,[s]:{backgroundColor:s,color:s,data:u(e=>e.data,[t],"p0.data"),hasPricing:s,reverse:s}},3,"7j_0"),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"7j_1"),j$=m(g(M$,"s_05kJ0dE4eLY")),E$=t=>{const e=t.data.pageReferralP.data.attributes,a=e.Steps.Bullets.map(l=>l.Text);return n("div",null,null,[i(j$,{get data(){return e.RefInfo},[s]:{data:x(e,"RefInfo")}},3,"Kl_0"),n("div",null,{class:"flex items-center justify-center px-8 py-8"},n("div",null,{class:" max-w-[1400px] "},[n("h4",null,{class:"mb-6 text-center text-[20px] font-[500] leading-6 text-primary-blue"},_(e,"StepsIntro"),1,null),n("h3",null,{class:"mb-6 text-center text-[42px] font-[700] leading-10 text-secondary-red"},_(e.Steps,"Title"),1,null),n("div",null,{class:"max-[799px]:hidden"},i(qe,{align:"center",direction:"vertical",steps:a,[s]:{align:s,direction:s}},3,"Kl_1"),1,null),n("div",null,{class:"min-[800px]:hidden"},i(qe,{align:"start",direction:"vertical",steps:a,[s]:{align:s,direction:s}},3,"Kl_2"),1,null)],1,null),1,null)],1,"Kl_3")},B$=m(g(E$,"s_lTuY9A29ePc")),I$=t=>`
  query QueryReferralProgram{
    pageReferralP(locale:"${t}"){
      data{
        attributes{
            RefInfo{
          Title
          Subtitle
          Paragraph
          Media{
            ${$}
          }
        }
          StepsIntro
          Steps{
            Title
            Bullets{
              Text
              Caption
            }
          }
          ${q}
        }
      }
    }
  }
    `,O$=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(I$,e)},Ln=N(g(O$,"s_xJNMjIe9Xxc")),A$=()=>{const t=Ln();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageReferralP.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageReferralP.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageReferralP"]["data"]["attributes"]["SEO"]')}},3,"Mu_0"),i(B$,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Mu_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Mu_2")},N$=m(g(A$,"s_jMvbzO8YesI")),R$=({resolveValue:t})=>{const a=t(Ln).pageData.data.pageReferralP.data.attributes.SEO;return G(a)},q$=Object.freeze(Object.defineProperty({__proto__:null,default:N$,head:R$,usePageData:Ln},Symbol.toStringTag,{value:"Module"})),F$=t=>{const e=t.data.pageResidential.data.attributes.Services;return n("div",null,null,i(oe,{data:e},3,"jS_0"),1,"jS_1")},z$=m(g(F$,"s_2a10udsh6KM")),G$=t=>`
  query QueryResidential {
    pageResidential(locale:"${t}"){    
      data{
        attributes{
          Services{
            Logo{
            ${$}
            }
            Media{
            ${$}
            }
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
          ${q}
        }
      }
    }
  }
    `,Q$=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(G$,e)},Cn=N(g(Q$,"s_LcXJ0iBV25I")),H$=()=>{const t=Cn();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageResidential.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageResidential.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageResidential"]["data"]["attributes"]["SEO"]')}},3,"O0_0"),i(z$,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"O0_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"O0_2")},W$=m(g(H$,"s_2tXslNmi0k4")),U$=({resolveValue:t})=>{const a=t(Cn).pageData.data.pageResidential.data.attributes.SEO;return G(a)},Y$=Object.freeze(Object.defineProperty({__proto__:null,default:W$,head:U$,usePageData:Cn},Symbol.toStringTag,{value:"Module"})),V$=t=>{const e=t.data.data.pageSupport.data.attributes,a=t.data.data.sectionContactBoxes.data;return n("div",null,{class:"flex flex-col px-8 justify-center items-center"},[n("div",null,{class:"h-[100px] p-6 flex flex-row justify-evenly items-center shadow-2xl rounded-full w-[350px] mb-5 bg-blue-100"},[n("p",null,{class:"text-primary-blue font-semibold text-xl"},_(e,"WTTTitle"),1,null),i(Z,{get text(){return e.WTTButton.Text},get link(){return e.WTTButton.Link},[s]:{link:x(e.WTTButton,"Link"),text:x(e.WTTButton,"Text")}},3,"t0_0")],1,null),n("div",null,{class:"text-center"},[n("h2",null,{class:"text-3xl md:text-[40px] my-4 font-bold text-primary-blue"},_(e.Introduction,"Title"),1,null),n("h3",null,{class:"text-secondary-red my-4 text-2xl font-semibold"},_(e.Introduction,"Subtitle"),1,null),i(C,{get text(){return e.Introduction.Paragraph},[s]:{text:x(e.Introduction,"Paragraph")}},3,"t0_1")],1,null),n("div",null,{class:"flex flex-col md:flex-row my-4 w-full"},a.map((l,r)=>n("div",null,{class:"flex flex-col w-full md:w-1/2 items-center px-4 justify-start"},[l.attributes.Title.map((o,c)=>n("div",null,null,n("p",null,{class:"text-center text-2xl text-primary-blue font-semibold"},_(o,"Text"),1,null),1,c)),l.attributes.BoxContent.map((o,c)=>n("div",null,{class:"min-h-[250px] my-4 w-full flex flex-col gap-5 justify-start items-center py-4 rounded-2xl shadow-xl"},[n("div",{class:`w-full flex justify-center py-2 items-center rounded-t-2xl ${r%2==0?"bg-primary-blue":"bg-secondary-red"}`},null,n("p",null,{class:"text-center text-2xl text-white font-semibold"},_(o,"Title"),1,null),1,null),i(C,{classN:"text-center px-4",get text(){return o.Paragraph},[s]:{classN:s,text:x(o,"Paragraph")}},3,"t0_2"),n("div",null,{class:"flex flex-wrap items-center justify-center gap-2"},o.Buttons.map((d,p)=>{var f;return i(Z,{get text(){return d.Text},get link(){return d.Link},type:(f=d.Link)!=null&&f.includes("tel:")?"action":"link",[s]:{link:x(d,"Link"),text:x(d,"Text")}},3,p)}),1,null)],1,c))],1,r)),1,null),n("div",null,{class:"flex flex-col my-4 md:flex-row gap-5"},e.SelfSupport.map((l,r)=>n("div",null,{class:"h-[290px] w-full md:w-[305px] rounded-3xl shadow-2xl flex p-6 flex-col items-center justify-between"},[i(P,{get media(){return l.Media.data.attributes},height:150,width:310,[s]:{height:s,media:x(l.Media.data,"attributes"),width:s}},3,"t0_3"),n("p",null,{class:"text-2xl md:text-3xl text-center font-semibold text-primary-blue"},_(l,"Title"),1,null),i(C,{classN:"text-center",get text(){return l.Paragraph},[s]:{classN:s,text:x(l,"Paragraph")}},3,"t0_4"),i(Z,{get text(){return l.Buttons[0].Text},get link(){return l.Buttons[0].Link},[s]:{link:x(l.Buttons[0],"Link"),text:x(l.Buttons[0],"Text")}},3,"t0_5")],1,r)),1,null)],1,"t0_6")},Z$=m(g(V$,"s_Vkf3Ha9y0kU")),X$=t=>`
        sectionContactBoxes(locale:"${t}"){
          data{
            attributes{
              Title{
                Text
              }
              BoxContent{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
            }
          }
      }`,K$=t=>`query QuerySupport{
        pageSupport(locale:"${t}"){
          data{
            attributes{
              Marquee
              
              WTTTitle
              WTTButton{
                Text
                Link
              }
              
              Introduction{
                Title
                Subtitle
                Paragraph
              }
              
              SelfSupport{
                Media{
                ${$}
                }
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              ${q}
            }
          }
        }
        ${X$(t)}
      }`,J$=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(K$,e)},Mn=N(g(J$,"s_PaoFf3TWb00")),t1=()=>{const t=Mn();return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageSupport.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageSupport.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageSupport"]["data"]["attributes"]["SEO"]')}},3,"Ez_0"),i(Z$,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"Ez_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Ez_2")},1,"Ez_3")},e1=m(g(t1,"s_BS8ceDijUKA")),a1=({resolveValue:t})=>{const a=t(Mn).pageData.data.pageSupport.data.attributes.SEO;return G(a)},l1=Object.freeze(Object.defineProperty({__proto__:null,default:e1,head:a1,usePageData:Mn},Symbol.toStringTag,{value:"Module"})),n1=t=>n("div",null,{class:"flex h-[190px]  max-w-[350px] flex-col items-center justify-center rounded-[20px] bg-white p-6 m-2 text-primary-blue"},[i(qd,{class:"text-[28px] text-secondary-red",[s]:{class:s}},3,"Gr_0"),n("span",null,{class:"text-[17px] font-[600]"},u(e=>e.testimonial.Title,[t],'p0.testimonial["Title"]'),3,null),i(C,{classN:"text-[12px] text-center",get text(){return t.testimonial.Text},[s]:{classN:s,text:u(e=>e.testimonial.Text,[t],'p0.testimonial["Text"]')}},3,"Gr_1")],1,"Gr_2"),s1=t=>{const e=t.data.pageTestimon.data.attributes,a=m(g(n1,"s_ikLHAV9ZIuk")),l=e.Testimonials.map((r,o)=>i(a,{testimonial:r},3,o));return n("div",null,{class:"flex w-full items-center justify-center px-8",onClick$:I("s_KMXVxiVFs3M")},n("div",null,{class:"my-16 flex max-w-[1400px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex w-[60%] flex-col items-center justify-center gap-2 max-[800px]:w-full"},[n("h2",null,{class:"text-[36px] max-[800px]:text-[20px] font-[600] text-primary-dark-blue"},_(e,"VideoTitle"),1,null),n("video",{src:St(e.Video.data.attributes.url)},{class:"rounded-[30px] max-[800px]:max-w-[400px]",controls:!0},null,3,null)],1,null),n("div",null,{class:"items-center w-[40%] flex-col px-1 justify-center max-[800px]:w-full max-h-[500px]  "},i(Pt,{hasArrows:!1,hasPagination:!0,id:"carTestimonials",slides:l,slidesQty:1,[s]:{hasArrows:s,hasPagination:s,id:s,slidesQty:s}},3,"Gr_3"),1,null)],1,null),1,"Gr_4")},r1=m(g(s1,"s_HE2Hm2x9r68")),i1=t=>`query queryTestimonials{
    pageTestimon(locale:"${t}"){
      data{
        attributes{
          Testimonials{
            Title
            Text
          }
          VideoTitle
          TestimBG{
           ${$}
          }
          Video{
            ${$}
          }
          ${q}
        }
      }
    }
  }`,o1=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(i1,e)},jn=N(g(o1,"s_R6fQva4FAkw")),u1=()=>{const t=jn();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageTestimon.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageTestimon.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageTestimon"]["data"]["attributes"]["SEO"]')}},3,"cR_0"),i(r1,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"cR_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"cR_2")},c1=m(g(u1,"s_jKMCOKr9uSw")),d1=({resolveValue:t})=>{const a=t(jn).pageData.data.pageTestimon.data.attributes.SEO;return G(a)},p1=Object.freeze(Object.defineProperty({__proto__:null,default:c1,head:d1,usePageData:jn},Symbol.toStringTag,{value:"Module"})),f1=t=>{var l;const a=(l=vt().prevUrl)==null?void 0:l.pathname.includes("/es/");return n("div",null,{class:"p-8"},[n("h1",null,{class:"text-center font-bold text-4xl mb-6 text-secondary-red"},a?"Encuentra tu locación":"Find your location",1,null),n("table",null,{class:"w-full rounded-2xl"},[n("thead",null,{class:"bg-primary-blue text-white font-semibold"},[n("th",null,null,a?"Nombre":"Name",1,null),n("th",null,null,a?"Código postal":"Zip code",1,null),n("th",null,null,a?"Oficina":"Office",1,null)],1,null),n("tbody",null,null,t.data.map((r,o)=>n("tr",{class:`text-center text-primary-dark-blue w-full h-full ${o%2==0?"bg-blue-100":"bg-blue-200"}`},null,[n("td",null,{class:"hover:text-secondary-red"},n("a",{href:a?("/es/texas/"+r.attributes.Slug).replace("-es","/"):r.attributes.Slug+"/"},null,_(r.attributes,"Name"),1,null),1,null),n("td",null,null,_(r.attributes,"ZipCode"),1,null),n("td",null,null,_(r.attributes.office.data.attributes,"Location"),1,null)],1,o)),1,null)],1,null)],1,"pd_0")},g1=m(g(f1,"s_YVNQC4aSS0M")),x1=t=>`query{
        locations(locale:"${t}", pagination:{limit:500}){
          data{
            attributes{
              Name
              ZipCode
              Description
              Slug
              office{
                data{
                  attributes{
                    Location
                  }
                }
              }
              ${q}
            }
          }
        }
      }`,m1=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(x1,e)},ei=N(g(m1,"s_0tHKviRSkdY")),h1=async t=>(t.params.lang==""?"en":"es-419").toString(),ai=N(g(h1,"s_5IMJ5tToq0s")),$1=()=>{const t=ei(),e=t.value.pageData.data.locations.data;return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(g1,{data:e},3,"N7_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"N7_1")},1,"N7_2")},b1=m(g($1,"s_7yoRSOyY1lA")),y1=({resolveValue:t})=>{const e=t(ai),a={MetaTitle:e=="en"?"Areas Served | RTA Rural Telecommunications of America":"Áreas de servicio | RTA Rural Telecommunications of America",MetaDescription:e=="en"?"Discover RTA's extensive service areas and expand your connectivity horizons. Explore reliable telecommunications solutions tailored for diverse regions!":"Descubre áreas de servicio de RTA y expande tus horizontes de conectividad. ¡Explora soluciones de telecomunicaciones confiables para diversas regiones!",Keywords:e=="en"?"Service coverage areas, Regional connectivity, Rural broadband solutions":"Áreas de cobertura de servicios, Conectividad regional, Soluciones de banda ancha rural"};return G(a)},v1=Object.freeze(Object.defineProperty({__proto__:null,default:b1,head:y1,useLang:ai,usePageData:ei},Symbol.toStringTag,{value:"Module"})),w1=t=>{const e=t.data.data.pageWholesale.data.attributes,a=t.data.data.sectionNetwork.data.attributes,l=e.NetworkDIA.Features,r=O(0);return yt(I("s_jeOJGnobZvM",[l,r])),n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"my-8 flex w-full flex-col items-center justify-center px-4 md:w-1/2"},[i(C,{classN:"text-center my-4",get text(){return e.Introduction.Paragraph},[s]:{classN:s,text:x(e.Introduction,"Paragraph")}},3,"Xs_0"),i(Z,{get text(){return e.Introduction.Buttons[0].Text},get link(){return e.Introduction.Buttons[0].Link},type:"action",[s]:{link:x(e.Introduction.Buttons[0],"Link"),text:x(e.Introduction.Buttons[0],"Text"),type:s}},3,"Xs_1")],1,null),i(P,{get media(){return e.NetworkLogo.data.attributes},height:180,width:400,[s]:{height:s,media:x(e.NetworkLogo.data,"attributes"),width:s}},3,"Xs_2"),n("div",null,{class:"flex w-full flex-col items-center justify-center"},n("div",null,{class:"my-4 flex max-w-[1200px] flex-row-reverse items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-4 px-10 min-[800px]:w-[70%]"},[n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},_(e.NetworkDIA,"Title"),1,null),1,null),i(C,{get text(){return e.NetworkDIA.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{classN:s,text:x(e.NetworkDIA,"Paragraph")}},3,"Xs_3"),n("div",null,{class:"flex flex-col items-center justify-end text-center"},[n("h2",null,{class:"font-semibold text-primary-blue"},_(e.NetworkDIA,"Subtitle"),1,null),n("p",null,{class:"text-2xl font-bold text-primary-blue"},_(e.NetworkDIA,"FeaturesTitle"),1,null)],1,null),n("div",null,{class:"text-center text-xl font-semibold text-secondary-red"},n("h2",null,{class:"animated-fadein-down animated-fadeout-down"},_(l[r.value],"Text"),1,null),1,null)],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(P,{get media(){return e.NetworkDIA.Media.data.attributes},height:"500",width:"597",[s]:{height:s,media:x(e.NetworkDIA.Media.data,"attributes"),width:s}},3,"Xs_4"),1,null)],1,null),1,null),i(kt,{get text(){return e.NetworkCircuits.Paragraph},backgroundColor:"transparent",get title(){return e.NetworkCircuits.Title},get image(){return e.NetworkCircuits.Media.data.attributes},[s]:{backgroundColor:s,image:x(e.NetworkCircuits.Media.data,"attributes"),text:x(e.NetworkCircuits,"Paragraph"),title:x(e.NetworkCircuits,"Title")}},3,"Xs_5"),n("div",null,{class:"my-4 flex flex-wrap-reverse items-center justify-center gap-8 px-8 py-6"},[n("div",{onClick$:I("s_VUkdu4BrA18",[e])},{class:"flex items-center justify-center"},i(P,{get media(){return e.NetworkMap.data.attributes.Map.MapPicture.data.attributes},height:500,width:500,[s]:{height:s,media:x(e.NetworkMap.data.attributes.Map.MapPicture.data,"attributes"),width:s}},3,"Xs_6"),0,null),n("div",null,{class:"flex w-full flex-col items-center justify-center md:w-1/2"},[i(C,{get text(){return a.Description.Paragraph},classN:"text-primary-blue",[s]:{classN:s,text:x(a.Description,"Paragraph")}},3,"Xs_7"),i(_e,{get title(){return a.Map.ServersTitle},children:n("div",null,{class:"flex flex-col rounded-b-2xl bg-white py-4 text-primary-blue"},a.Map.Servers.map((o,c)=>n("a",{href:_(o,"Link")},{class:"text-primary-blue hover:text-secondary-red"},_(o,"Text"),1,c)),1,null),classContainer:"rounded-full bg-white text-primary-blue shadow-xl",[s]:{classContainer:s,title:x(a.Map,"ServersTitle")}},1,"Xs_8")],1,null)],1,null),i(oe,{get data(){return e.GFServices},[s]:{data:x(e,"GFServices")}},3,"Xs_9")],1,"Xs_10")},_1=m(g(w1,"s_SvASKT7lKMw")),S1=t=>`query QueryWholesale {
        pageWholesale(locale:"${t}"){    
          data{
            attributes{
            Introduction{
              Title
              Paragraph
              Buttons{
                Text
                Link
              }
            }
              
            NetworkLogo{
                ${$}
            }
            NetworkDIA{
              Title
              Paragraph
              Subtitle
              FeaturesTitle
              Features{
                Text
              }
              Media{
                ${$}
              }
            }
            NetworkCircuits{
              Title
              Subtitle
              Paragraph
              Media{
                 ${$}
              }
            }
           
              
            GFServices{
              Title
              Logo{
                ${$}
              }
              Paragraph
              Media{
                ${$}
              }
              Buttons{
                Text
                Link
              }
            }
              ${q}
              NetworkMap {
                data {
                  attributes {
                    Map {
                      MapPicture {
                        ${$}
                      }
                    }
                  }
                }
              }
            }
          }
        }
        ${id(t)}
      }`,T1=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(S1,e)},En=N(g(T1,"s_odgwpNJ8jW8")),D1=()=>{const t=En();return i(Q,{children:i(F,{get data(){return t.value.layoutData},children:i(_1,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"3I_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"3I_1")},1,"3I_2")},P1=m(g(D1,"s_W611gmEC5Rk")),k1=({resolveValue:t})=>{const a=t(En).pageData.data.pageWholesale.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},L1=Object.freeze(Object.defineProperty({__proto__:null,default:P1,head:k1,usePageData:En},Symbol.toStringTag,{value:"Module"})),C1=t=>n("div",{style:{backgroundImage:`url(${St(t.slide.attributes.url)})`}},{class:"h-[350px] my-5 w-[280px] overflow-hidden rounded-[10px] bg-contain bg-no-repeat bg-center"},null,3,"0D_0"),M1=t=>{const e=t.data.pageWinnersC.data.attributes,a=e.Winners.data.reverse(),l=m(g(C1,"s_Kis0UnPgGnE")),r=a.map((o,c)=>i(l,{slide:o},3,c));return n("div",null,{class:"relative flex flex-col items-center justify-center",onClick$:I("s_na2GxJ32Wno")},[n("div",null,{class:"relative flex w-full items-center justify-center overflow-hidden"},[i(P,{clasN:"max-w-[1000px] w-fit z-10 object-cover",height:"603",width:"1024",get media(){return e.WinnersBG.data.attributes},[s]:{clasN:s,height:s,media:x(e.WinnersBG.data,"attributes"),width:s}},3,"0D_1"),n("div",null,{class:"absolute z-20 mb-[160px]  w-[290px] overflow-hidden  rounded-[10px] border border-gray-500 bg-[#171f2a] p-2"},i(Pt,{addSpace:!1,hasArrows:!1,id:"carouselWinners",slides:r,slidesQty:1,[s]:{addSpace:s,hasArrows:s,id:s,slidesQty:s}},3,"0D_2"),1,null),n("div",null,{class:"absolute bottom-0 left-0 right-0 h-[30%] bg-black"},null,3,null)],1,null),n("div",null,{class:"flex w-full overflow-hidden bg-cover pt-16 bg-black justify-center"},n("div",null,{class:"flex max-w-[1200px] gap-4  max-[1000px]:flex-col  justify-center items-center"},[n("div",null,{class:"flex w-[30%] flex-col "},[n("h2",null,{class:"text-center text-[36px] font-[600] leading-[36px] text-secondary-red"},_(e,"GiveawayCarTitle"),1,null),n("br",null,null,null,3,null),n("div",null,{class:"mb-6 flex items-center justify-center rounded-xl bg-white p-2"},i(Pt,{addSpace:!1,duration:5e3,hasArrows:!0,hasPagination:!1,id:"giveAnswers",slides:e.GiveawayAnswers.reverse().map((o,c)=>n("div",null,{class:"flex flex-col items-center justify-center gap-1.5 max-w-[180px]"},[n("p",null,{class:"text-center text-[15px] text-primary-blue"},["This question was answered on"," ",n("br",null,null,null,3,null),aa(o.AnswerDate,!1)],1,null),n("iframe",{src:`https://www.youtube.com/embed/${o.QuestionVideos.split("v=")[1]}`},{allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",allowFullscreen:!0,class:"rounded-[20px] shadow-xl",frameBorder:"0",height:270,width:160},null,3,null),n("span",null,{class:"text-secondary-red"},"Answer:",3,null),n("span",null,{class:"text-primary-blue"},_(o,"Answer"),1,null)],1,c)),slidesQty:1,[s]:{addSpace:s,duration:s,hasArrows:s,hasPagination:s,id:s,slidesQty:s}},3,"0D_3"),1,null)],1,null),n("div",null,{class:"flex md:w-[60%] w-[30%] h-full flex-col justify-center  overflow-hidden"},[n("h3",null,{class:"text-center text-[28px] font-[500] leading-[30px] text-primary-blue"},_(e,"TwitterFeedTitle"),1,null),n("br",null,null,null,3,null),n("iframe",{srcdoc:_(e,"TwitterFeedLink")},{class:"h-full",height:"100%",width:"100%"},null,3,null)],1,null)],1,null),1,null)],1,"0D_4")},j1=m(g(M1,"s_QYIFsZOPjHw")),E1=t=>`query queryWinnerCircle{
    pageWinnersC(locale:"${t}"){
      data{
        attributes{
          WinnersTitle
  
          WinnersBG{
            ${$}
          }
          
          WinnersCarBG{
           ${$}
          }
          Winners{
            ${$}
          }
         
          GiveawayCarTitle
          
          GiveawayAnswers{
            Description
            AnswerDate
            QuestionVideos
            Answer
          }
          TwitterFeedLink
          TwitterFeedTitle
  
          ${q}
        }
      }
    }
  }`,B1=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(E1,e)},Bn=N(g(B1,"s_6WeV0M8I1Do")),I1=()=>{const t=Bn();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageWinnersC.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageWinnersC.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageWinnersC"]["data"]["attributes"]["SEO"]')}},3,"00_0"),i(j1,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"00_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"00_2")},O1=m(g(I1,"s_0m9hLjn9QnA")),A1=({resolveValue:t})=>{const a=t(Bn).pageData.data.pageWinnersC.data.attributes.SEO;return G(a)},N1=Object.freeze(Object.defineProperty({__proto__:null,default:O1,head:A1,usePageData:Bn},Symbol.toStringTag,{value:"Module"})),R1=t=>n("div",null,{class:"flex max-w-[400px] flex-col items-center max-[900px]:place-self-center"},[n("section",null,{class:"flex h-fit w-full flex-col rounded-[35px] bg-white text-center shadow-lg"},[n("div",null,{class:"flex w-full items-center justify-center rounded-t-[35px] bg-gradient-to-r from-[#4caafd] to-[#1a7ee4] px-6 py-3 text-center"},i(P,{get media(){return t.data.RaceRepLogo.data.attributes},clasN:"h-[16px] w-fit",[s]:{clasN:s,media:u(e=>e.data.RaceRepLogo.data.attributes,[t],'p0.data["RaceRepLogo"]["data"]["attributes"]')}},3,"QP_0"),1,null),n("div",null,{class:"flex flex-col items-center justify-center p-4"},[i(ma,{get ytURL(){return t.data.RaceRepVids[0].Link},classN:"rounded-[30px] shadow-lg",[s]:{classN:s,ytURL:u(e=>e.data.RaceRepVids[0].Link,[t],'p0.data["RaceRepVids"][0]["Link"]')}},3,"QP_1"),i(C,{get text(){return t.data.RaceRepVids[0].Paragraph},classN:"text-[13px] p-1 mt-2",[s]:{classN:s,text:u(e=>e.data.RaceRepVids[0].Paragraph,[t],'p0.data["RaceRepVids"][0]["Paragraph"]')}},3,"QP_2"),n("div",null,{class:"h-[6px] w-full border-t border-gray-300"},null,3,null),n("div",null,{class:"h-[6px] w-full border-t border-gray-300"},null,3,null),n("div",null,{class:"mb-4 h-[6px] w-full border-t border-gray-300"},null,3,null),i(ma,{get ytURL(){return t.data.RaceRepVids[1].Link},classN:"rounded-[30px] shadow-lg",[s]:{classN:s,ytURL:u(e=>e.data.RaceRepVids[1].Link,[t],'p0.data["RaceRepVids"][1]["Link"]')}},3,"QP_3"),i(C,{get text(){return t.data.RaceRepVids[1].Paragraph},classN:"text-[13px] p-1 mt-2",[s]:{classN:s,text:u(e=>e.data.RaceRepVids[1].Paragraph,[t],'p0.data["RaceRepVids"][1]["Paragraph"]')}},3,"QP_4")],1,null)],1,null),n("a",null,{class:"mt-8 w-full rounded-full border-[6px] border-[#e7758f] bg-secondary-red px-8 py-1 text-center text-[14px] font-[600] leading-[18px] text-white shadow-lg",href:u(e=>e.data.HeaderButtons[0].Link,[t],'p0.data["HeaderButtons"][0]["Link"]'),target:"_blank"},u(e=>e.data.HeaderButtons[0].Text,[t],'p0.data["HeaderButtons"][0]["Text"]'),3,null)],1,"QP_5"),q1=t=>n("div",null,{class:"flex h-fit max-w-[600px] flex-col items-center justify-center  text-center text-white"},[i(P,{get media(){return t.data.LogoCorp.data.attributes},clasN:"h-[80px] w-[215px]",[s]:{clasN:s,media:u(e=>e.data.LogoCorp.data.attributes,[t],'p0.data["LogoCorp"]["data"]["attributes"]')}},3,"QP_6"),n("span",null,{class:"mb-4 text-[46px] font-[700] leading-[50px]"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),i(P,{get media(){return t.data.LogoSponsor.data.attributes},[s]:{media:u(e=>e.data.LogoSponsor.data.attributes,[t],'p0.data["LogoSponsor"]["data"]["attributes"]')}},3,"QP_7"),n("span",null,{class:"my-4 rounded-full bg-white px-4 text-[15px] font-[400] tracking-widest text-primary-blue"},t.data.Subtitle.toUpperCase(),1,null),i(P,{get media(){return t.data.HeaderPictures.data[0].attributes},clasN:"w-full h-fit px-4 pt-4",[s]:{clasN:s,media:u(e=>e.data.HeaderPictures.data[0].attributes,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]')}},3,"QP_8")],1,"QP_9"),F1=t=>{W();const e=O(1e3);yt(I("s_0vxrMcOslm0",[e]));const a=m(g(R1,"s_S9x7nXVXxQ0")),l=m(g(q1,"s_YXp1rsg61DU"));return n("div",null,{class:"flex min-h-[500px] w-full items-center justify-center bg-[conic-gradient(at_top,_var(--tw-gradient-stops))] from-[#001536] via-[#0E67BB] to-[#001536]"},n("div",null,{class:"flex max-w-[1200px] flex-col items-center justify-center px-8 pt-12"},n("div",null,{class:"grid items-start justify-center gap-6 max-[900px]:items-center",style:u(r=>({gridTemplateColumns:r.value>900?"250px 1fr 250px":"1fr"}),[e],'{gridTemplateColumns:p0.value>900?"250px 1fr 250px":"1fr"}')},[e.value<=900&&i(l,{get data(){return t.data},[s]:{data:u(r=>r.data,[t],"p0.data")}},3,"QP_10"),i(a,{get data(){return t.data},[s]:{data:u(r=>r.data,[t],"p0.data")}},3,"QP_11"),e.value>900&&i(l,{get data(){return t.data},[s]:{data:u(r=>r.data,[t],"p0.data")}},3,"QP_12"),n("div",null,{class:"flex max-w-[400px] flex-col items-center max-[900px]:place-self-center"},[n("section",null,{class:"flex h-fit w-full flex-col items-center justify-center rounded-[35px] bg-white p-4 text-center shadow-lg"},[n("div",null,{class:"h-[420px]"},i(ma,{get ytURL(){return t.data.GiveawayBox[0].Video.Link},classN:"rounded-[30px] shadow-lg",[s]:{classN:s,ytURL:u(r=>r.data.GiveawayBox[0].Video.Link,[t],'p0.data["GiveawayBox"][0]["Video"]["Link"]')}},3,"QP_13"),1,null),i(C,{get text(){return t.data.GiveawayBox[0].Video.Paragraph},classN:"text-[13px] p-1 mt-2",[s]:{classN:s,text:u(r=>r.data.GiveawayBox[0].Video.Paragraph,[t],'p0.data["GiveawayBox"][0]["Video"]["Paragraph"]')}},3,"QP_14"),i(Z,{get text(){return t.data.GiveawayBox[0].Button.Text},get link(){return t.data.GiveawayBox[0].Button.Link},[s]:{link:u(r=>r.data.GiveawayBox[0].Button.Link,[t],'p0.data["GiveawayBox"][0]["Button"]["Link"]'),text:u(r=>r.data.GiveawayBox[0].Button.Text,[t],'p0.data["GiveawayBox"][0]["Button"]["Text"]')}},3,"QP_15")],1,null),n("a",null,{class:"my-8 w-full rounded-full border-[6px] border-[#e7758f] bg-secondary-red px-8 py-1 text-center text-[14px] font-[600] leading-[18px] text-white shadow-lg",href:u(r=>r.data.HeaderButtons[1].Link,[t],'p0.data["HeaderButtons"][1]["Link"]')},u(r=>r.data.HeaderButtons[1].Text,[t],'p0.data["HeaderButtons"][1]["Text"]'),3,null)],1,null)],1,null),1,null),1,"QP_16")},z1=m(g(F1,"s_v9v6ItSeef4")),G1=t=>n("div",null,{class:"flex flex-col items-center justify-center text-center text-white"},[n("span",null,{class:"text-[24px]"},i(C,{classN:"text-white",get text(){return t.data.QuoteText},[s]:{classN:s,text:u(e=>e.data.QuoteText,[t],'p0.data["QuoteText"]')}},3,"0q_0"),1,null),n("div",null,{class:"mt-4 flex flex-col"},[n("span",null,{class:"text-[19px] font-[600] text-[#7bc8ff]"},u(e=>e.data.QuoteAuthor,[t],'p0.data["QuoteAuthor"]'),3,null),n("span",null,{class:"max-w-[200px] text-[14px] tracking-[2px]"},u(e=>e.data.QuoteADesc,[t],'p0.data["QuoteADesc"]'),3,null)],3,null)],1,"0q_1"),Q1=m(g(G1,"s_P6qdCyIENpU")),H1=t=>n("div",null,{class:"flex items-center justify-center gap-10 px-8 max-[800px]:flex-col"},[n("div",null,{class:"flex min-w-[300px] max-w-[400px] flex-col items-center justify-center rounded-[30px] bg-white p-8 text-primary-blue "},[i(P,{clasN:"h-fit w-[180px]",get media(){return t.data.AboutZane.Media.data.attributes},[s]:{clasN:s,media:u(e=>e.data.AboutZane.Media.data.attributes,[t],'p0.data["AboutZane"]["Media"]["data"]["attributes"]')}},3,"E0_0"),n("h2",null,{class:"mt-4 text-[30px] font-[500] text-secondary-red"},u(e=>e.data.AboutZane.Title,[t],'p0.data["AboutZane"]["Title"]'),3,null),i(C,{classN:"[&>h2]:text-[21px] [&>h2]:leading-10 [&>h2]:font-[600]",get text(){return t.data.AboutZane.Paragraph},[s]:{classN:s,text:u(e=>e.data.AboutZane.Paragraph,[t],'p0.data["AboutZane"]["Paragraph"]')}},3,"E0_1"),n("div",null,{class:"mb-4 flex w-full items-center justify-evenly gap-2 rounded-full bg-primary-blue p-2"},t.data.AboutZane.Buttons.filter(e=>!e.Text).map((e,a)=>n("div",{onClick$:I("s_aBdgclRoL4w",[e])},{class:"hover:cursor-pointer"},i(P,{clasN:"h-[20px]",toWhite:a!==0,get media(){return e.Icon.data.attributes},[s]:{clasN:s,media:x(e.Icon.data,"attributes")}},3,"E0_2"),0,a)),1,null),t.data.AboutZane.Buttons.filter(e=>e.Text).map((e,a)=>n("div",{onClick$:I("s_0qHArrAd29Q",[e])},{class:"flex gap-2 self-start hover:cursor-pointer"},[i(P,{clasN:"h-[24px] w-[24px]",get media(){return e.Icon.data.attributes},[s]:{clasN:s,media:x(e.Icon.data,"attributes")}},3,"E0_3"),n("span",null,{class:"text-[14px] font-[500]"},_(e,"Text"),1,null)],0,a))],1,null),n("div",null,{class:"flex flex-col text-white"},[n("span",null,{class:"mb-4 text-[40px] font-[600]"},u(e=>e.data.Highlights.Title,[t],'p0.data["Highlights"]["Title"]'),3,null),i(C,{classN:"text-white text-justify",get text(){return t.data.Highlights.Paragraph},[s]:{classN:s,text:u(e=>e.data.Highlights.Paragraph,[t],'p0.data["Highlights"]["Paragraph"]')}},3,"E0_4")],1,null)],1,"E0_5"),W1=m(g(H1,"s_CpEM5GsNAyg")),U1=t=>n("div",null,{class:"mt-[80px] flex flex-col items-center justify-center"},[n("div",null,{class:"mb-6 flex items-center justify-center gap-6"},[n("span",null,{class:"text-[40px] font-[600] text-white max-[800px]:hidden"},u(e=>e.data.AboutFRM.Title,[t],'p0.data["AboutFRM"]["Title"]'),3,null),i(P,{get media(){return t.data.AboutFRM.Logo.data.attributes},[s]:{media:u(e=>e.data.AboutFRM.Logo.data.attributes,[t],'p0.data["AboutFRM"]["Logo"]["data"]["attributes"]')}},3,"KU_0")],1,null),n("div",null,{class:"flex gap-8 max-[800px]:flex-col"},[n("div",null,{class:"flex w-[60%] flex-col items-center gap-4 max-[800px]:w-full"},[i(C,{classN:"text-white text-[18px] text-justify",get text(){return t.data.AboutFRM.Paragraph},[s]:{classN:s,text:u(e=>e.data.AboutFRM.Paragraph,[t],'p0.data["AboutFRM"]["Paragraph"]')}},3,"KU_1"),i(P,{clasN:"w-[80%] min-w-[300px] rounded-3xl",get media(){return t.data.FRMChamps.data.attributes},[s]:{clasN:s,media:u(e=>e.data.FRMChamps.data.attributes,[t],'p0.data["FRMChamps"]["data"]["attributes"]')}},3,"KU_2"),i(C,{classN:"text-white text-[12px]",get text(){return t.data.FRMChamps.data.attributes.caption},[s]:{classN:s,text:u(e=>e.data.FRMChamps.data.attributes.caption,[t],'p0.data["FRMChamps"]["data"]["attributes"]["caption"]')}},3,"KU_3"),i(C,{classN:"text-white text-[12px] text-justify",get text(){return t.data.AboutFRMPInfo},[s]:{classN:s,text:u(e=>e.data.AboutFRMPInfo,[t],'p0.data["AboutFRMPInfo"]')}},3,"KU_4")],1,null),n("div",null,{class:"flex w-[40%] flex-col items-center max-[800px]:w-full"},[i(C,{classN:"text-white text-[15px] font-[600]",get text(){return t.data.AboutFRM.Subtitle},[s]:{classN:s,text:u(e=>e.data.AboutFRM.Subtitle,[t],'p0.data["AboutFRM"]["Subtitle"]')}},3,"KU_5"),i(P,{clasN:"w-[80%] min-w-[180px] rounded-3xl my-2",get media(){return t.data.AboutFRM.Media.data.attributes},[s]:{clasN:s,media:u(e=>e.data.AboutFRM.Media.data.attributes,[t],'p0.data["AboutFRM"]["Media"]["data"]["attributes"]')}},3,"KU_6"),i(C,{classN:"text-white text-[13px]",get text(){return t.data.AboutFRM.Media.data.attributes.caption},[s]:{classN:s,text:u(e=>e.data.AboutFRM.Media.data.attributes.caption,[t],'p0.data["AboutFRM"]["Media"]["data"]["attributes"]["caption"]')}},3,"KU_7"),n("div",null,{class:"my-4 flex flex-col items-start justify-start gap-1 self-start"},t.data.AboutFRM.Buttons.map((e,a)=>n("div",{onClick$:I("s_TcbYAUHeCh4",[e])},{class:"flex items-center"},[i(P,{clasN:"h-[16px] w-[16px] mr-2",toWhite:!0,get media(){return e.Icon.data.attributes},[s]:{clasN:s,media:x(e.Icon.data,"attributes"),toWhite:s}},3,"KU_8"),n("span",null,{class:"text-white"},_(e,"Text"),1,null)],0,a)),1,null)],1,null)],1,null)],1,"KU_9"),Y1=m(g(U1,"s_uxm1007Tl9Q")),V1=t=>n("div",null,{class:"my-[80px] flex flex-col items-center justify-center text-white"},[n("span",null,{class:"text-center text-[40px] font-[600]"},u(e=>e.data.CarouselTitle,[t],'p0.data["CarouselTitle"]'),3,null),n("div",null,{class:"max-w-[1300px] px-8"},i(Pt,{addSpace:!0,direction:"horizontal",hasArrows:!0,id:"zss_carousel",slides:t.data.CarouselContent.map((e,a)=>n("div",{onClick$:I("s_LReiaiAXvdI",[e])},{class:"relative overflow-hidden rounded-3xl hover:cursor-pointer"},[n("div",null,{class:"absolute inset-0 z-20 flex items-center justify-center bg-black bg-opacity-10 text-[60px] font-[900] text-white"},"▷",3,null),i(P,{get media(){return e.Cover.data.attributes},[s]:{media:x(e.Cover.data,"attributes")}},3,"YI_0")],0,a)),slidesQty:3,[s]:{addSpace:s,direction:s,hasArrows:s,id:s,slidesQty:s}},3,"YI_1"),1,null)],1,"YI_2"),Z1=m(g(V1,"s_leW0062t5ac")),X1=t=>{const e=t.data.pageZaneSpon.data.attributes;return n("div",{onClick$:I("s_m03OOMoHREo",[e])},null,[i(z1,{data:e},3,"5E_0"),n("div",null,{class:"bg-gradient-to-b from-[#041630] to-[#153069]"},n("div",null,{class:" md:flex w-full justify-center items-center"},n("div",null,{class:"max-w-[1200px] px-8 pt-8"},[i(Q1,{data:e},3,"5E_1"),i(Z1,{data:e},3,"5E_2"),i(W1,{data:e},3,"5E_3"),i(Y1,{data:e},3,"5E_4")],1,null),1,null),1,null)],0,"5E_5")},K1=m(g(X1,"s_kYGFw8H412s")),J1=t=>`query {
    pageZaneSpon(locale:"${t}") {
      data {
        attributes {
          Title
          Subtitle
          LogoCorp {
            ${$}
          }
          LogoSponsor {
            ${$}
          }
          HeaderPictures {
            ${$}
          }
          HeaderButtons {
            Text
            Link
          }
          NascarSchedule {
            ${$}
          }
          yt {
            ${$}
          }
          GiveawayBox {
            Video {
              Link
              Paragraph
            }
            Button {
              Text
              Link
            }
          }
          QuoteText
          QuoteAuthor
          QuoteADesc
          RaceRepLogo {
            ${$}
          }
          RaceRepVids {
            Link
            Paragraph
          }
          CarouselTitle
          CarouselContent {
            Link
            Paragraph
            Cover {
                ${$}
            }
          }
          AboutZane {
            Title
            Subtitle
            Paragraph
            Media {
                ${$}
            }
            Buttons {
              Text
              Link
              Icon {
                ${$}
              }
            }
          }
          Highlights {
            Title
            Paragraph
          }
          AboutFRM {
            Title
            Subtitle
            Paragraph
            Buttons {
              Text
              Link
              Icon {
                ${$}
              }
            }
            Logo {
                ${$}
            }
            Media {
                ${$}
            }
          }
  
          Sponsors{
            ${$}
          }
  
            FRMChamps{
                ${$}
            }
  
          AboutFRMPInfo
  
          
          ${q}
          
        }
      }
    }
  }`,tb=async t=>{const e=t.params.lang==""?"en":"es-419";return await z(J1,e)},In=N(g(tb,"s_s1m2ueqRceg")),eb=()=>{const t=In();return i(F,{get data(){return t.value.layoutData},children:[i(K,{get SEOdata(){return t.value.pageData.data.pageZaneSpon.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageZaneSpon.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageZaneSpon"]["data"]["attributes"]["SEO"]')}},3,"zi_0"),i(K1,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"zi_1")],showHeader:!1,[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"zi_2")},ab=m(g(eb,"s_uWXfycW000o")),lb=({resolveValue:t})=>{const a=t(In).pageData.data.pageZaneSpon.data.attributes.SEO;return G(a)},nb=Object.freeze(Object.defineProperty({__proto__:null,default:ab,head:lb,usePageData:In},Symbol.toStringTag,{value:"Module"})),li=(t,e)=>`
  query QueryLocalPage {
    locations(
      filters: { Slug: { eq: "${e}${t==="en"?"":"-es"}" } }
      locale: "${t}"
    ) {
      data {
        attributes {
            office {
                data {
                  attributes {
                    Address
                    Schema
                    Phone{
                      Link
                      Text
                    }
                  }
                }
              }
          Name
          ZipCode
          Description
          Slug
          
          posts{
            data{
              attributes{
                Title
                Date
                Cover{
                  ${$}
                }
                Description
                VideoLink
                Gallery{
                  ${$}
                }
                Slug
              }
            }
          }
          
          SEO {
            MetaTitle
            MetaDescription
            preventIndexing
            Keywords
          }
        }
      }
    }
    lpPtGroup(locale:"${t}"){
        data{
          attributes{
            PricingTables{
              Logo{
                ${$}
              }
              Title
              Subtitle
              Price
              Pricetime
              Description
              Features{
                Text
              }
              Button{
                Text
                Link
              }
            }
          }
        }
      } 
  }  
    `,sb=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang,a=t.params.slug;return await Ke(li(Ne(e),a),e)},On=N(g(sb,"s_6eBD86DvEZM")),rb=async t=>(t.params.lang==""?"en":"es-419").toString(),ni=N(g(rb,"s_06oruSNHf7c")),ib=()=>{var o;W();const t=On(),e=t.value.pageData.data.locations.data[0].attributes,a=e.posts.data,r=(o=vt().prevUrl)==null?void 0:o.pathname.includes("/es/");return i(F,{get data(){return t.value.layoutData},children:a.length==0?n("div",null,{class:"h-full w-full flex items-center justify-center"},n("h2",null,{class:"font-bold text-2xl text-primary-blue p-[25px] text-center"},r==!1?"More news about this location coming soon. Stay tuned!":"Próximamente más noticias sobre esta localidad. ¡Mantente al tanto!",1,null),1,"xj_0"):n("div",null,{class:"flex flex-col items-center justify-center"},[i(Wl,{get post(){return a[0].attributes},isES:r,[s]:{post:x(a[0],"attributes")}},3,"xj_1"),n("div",null,{class:"my-4"},null,3,null),i(Ul,{get posts(){return e.posts.data},isLocalBlog:!0,loadSize:3,type:"locations",[s]:{isLocalBlog:s,loadSize:s,posts:x(e.posts,"data"),type:s}},3,"xj_2")],1,null),[s]:{data:u(c=>c.value.layoutData,[t],'p0.value["layoutData"]')}},1,"xj_3")},ob=m(g(ib,"s_LRpRHkCbXkY")),ub=({resolveValue:t})=>{const e=t(ni),l=t(On).pageData.data.locations.data[0].attributes,r=l.Name;console.log("el valor que se obtiene de las páginas es ",l);const o={MetaTitle:e=="en"?`${r} Local Blog | RTA Telecommunications`:`Blog Local en ${r} | RTA Telecommunications`,MetaDescription:e=="en"?`Explore the most recent and relevant news in ${r}. Stay informed about events, updates, and local news that impact your community.`:`Explora las noticias más recientes y relevantes en ${r}. Mantente informado sobre eventos y noticias locales que impactan tu comunidad.`,Keywords:e=="en"?"Technology news, Tech updates, Digital trends, Innovation insights, RTA, local blog":"Noticias de tecnología, Actualizaciones tecnológicas, Tendencias digitales, Novedades en innovación, RTA, blog local"};return G(o)},cb=Object.freeze(Object.defineProperty({__proto__:null,default:ob,head:ub,useLang:ni,usePageData:On},Symbol.toStringTag,{value:"Module"})),db=t=>{const e=t.data.Slug.substring(t.data.Slug.length-3,t.data.Slug.length)==="-es";return console.log(t.data),n("div",null,{class:"flex max-w-[1200px] gap-5 px-8 py-20 text-primary-blue max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-1 text-center min-[800px]:w-[40%] md:px-2"},[n("h1",null,{class:"md:text-[36px] text-[28px] font-[700] leading-10"},`gigFAST INTERNET ${e?"e":"i"}n ${t.data.Name}`,1,null),n("span",null,{class:"text-[24px]"},[u(a=>a.data.ZipCode,[t],'p0.data["ZipCode"]'),", TX"],3,null),n("span",null,{class:"text-[28px] font-[600]"},e?"Llama ahora":"Call now",1,null),i(Z,{type:"action",get link(){return t.data.office.data.attributes.Phone.Link},get text(){return t.data.office.data.attributes.Phone.Text},[s]:{link:u(a=>a.data.office.data.attributes.Phone.Link,[t],'p0.data["office"]["data"]["attributes"]["Phone"]["Link"]'),text:u(a=>a.data.office.data.attributes.Phone.Text,[t],'p0.data["office"]["data"]["attributes"]["Phone"]["Text"]'),type:s}},3,"pw_0")],1,null),n("div",null,{class:"text-justify text-[16px] max-[800px]:text-[13px] min-[800px]:w-[60%]"},i(C,{get text(){return t.data.Description},[s]:{text:u(a=>a.data.Description,[t],'p0.data["Description"]')}},3,"pw_1"),1,null)],1,"pw_2")},pb=m(g(db,"s_8eJAul3VU0U")),fb=t=>{const e=t.data.locations.data[0].attributes.Slug,a=e.substring(e.length-3,e.length)==="-es",l=t.data.lpPtGroup.data.attributes.PricingTables;return n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"flex min-h-[200px]  w-full items-center justify-center bg-gradient-to-br from-primary-light-blue to-[#23477f] p-8"},n("div",null,{class:"flex w-full max-w-[1200px] flex-col items-center justify-center"},[n("span",null,{class:"text-center text-[38px] font-[600] leading-10 text-white max-[800px]:text-[28px]"},a?"Encuentra ofertas disponibles en tu área":"Find available offers in your area",1,null),n("div",null,{class:"mt-8 flex w-full items-center justify-center gap-8 max-[1200px]:flex-col"},n("div",null,{class:"flex justify-evenly gap-4 max-[1400px]:flex-wrap"},l.map((r,o)=>i(dn,{get btnText(){return r.Button.Text},get btnLink(){return r.Button.Link},get description(){return r.Description},get logo(){return r.Logo.data.attributes},get features(){return r.Features},price:r.Price.toString(),get priceTime(){return r.Pricetime},get title(){return r.Title},isFullLogo:!0,[s]:{btnLink:x(r.Button,"Link"),btnText:x(r.Button,"Text"),description:x(r,"Description"),features:x(r,"Features"),isFullLogo:s,logo:x(r.Logo.data,"attributes"),priceTime:x(r,"Pricetime"),title:x(r,"Title")}},3,o)),1,null),1,null)],1,null),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"88_0")},gb=m(g(fb,"s_JRh1Z7hA4Tg")),xb=t=>{const e=t.data.Slug.substring(t.data.Slug.length-3,t.data.Slug.length)==="-es";return n("div",null,{class:"flex items-center justify-center text-primary-blue md:px-0 px-5 w-full md:mb-10 mb-5 "},n("div",null,{class:"flex grow max-w-[1200px] max-h-[800px] flex flex-row  max-[800px]:flex-col gap-5"},[n("div",null,{class:"flex grow flex-col items-center justify-center bg-[#2e5899] text-center text-white h-full w-full rounded-[20px] font-light overflow-hidden "},[n("p",null,{class:" bg-black/20 font-bold text-[16px] py-3 px-5 w-full animate-pulse"},e?"Explora la esencia de tu comunidad con RTA":"Explore your community's essence with RTA",1,null),n("p",null,{class:"h-full text-[14px] pt-5 px-5 grow"},e?"Descubre historias, eventos y joyas ocultas locales, todo ello impulsado por la tecnología y la innovación.":"Discover local stories, events, and hidden gems, all powered by technology and innovation.",1,null),n("div",null,{class:"p-5"},i(Z,{link:"local-blog/",text:e?"Ir ahora":"Go Now",[s]:{link:s}},3,"GF_0"),1,null)],1,null),n("div",null,{class:"w-full"},n("iframe",null,{class:"h-full w-full rounded-2xl",loading:"lazy",src:u(a=>a.data.office.data.attributes.Address,[t],'p0.data["office"]["data"]["attributes"]["Address"]')},null,3,null),3,null)],1,null),1,"GF_1")},mb=m(g(xb,"s_f34tx075FZE")),hb=t=>n("div",null,{class:"flex flex-col items-center justify-center"},[i(pb,{get data(){return t.data.locations.data[0].attributes},[s]:{data:u(e=>e.data.locations.data[0].attributes,[t],'p0.data["locations"]["data"][0]["attributes"]')}},3,"LA_0"),i(mb,{get data(){return t.data.locations.data[0].attributes},[s]:{data:u(e=>e.data.locations.data[0].attributes,[t],'p0.data["locations"]["data"][0]["attributes"]')}},3,"LA_1"),i(gb,{get data(){return t.data},[s]:{data:u(e=>e.data,[t],"p0.data")}},3,"LA_2")],1,"LA_3"),$b=m(g(hb,"s_xdmchVEPK4Q")),bb=()=>n("div",null,{class:"flex w-full items-center justify-center px-8 py-12 text-center text-primary-dark-blue"},n("div",null,{class:"flex max-w-[1000px] flex-col items-center justify-center"},[n("span",null,{class:"text-[50px] font-[300]"},"Oops!",3,null),n("span",null,{class:"text-[18px] font-[400]"},"The page you are looking for does not exist.",3,null),n("h1",null,{class:"text-[150px] font-[700] max-[400px]:text-[100px]"},"404",3,null),n("span",null,{class:"text-[30px] font-[500] text-secondary-red"},"Something went wrong.",3,null)],3,null),3,"7k_0"),si=m(g(bb,"s_6KpdMMBpLyc")),yb=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang,a=t.params.slug;return await Ke(li(Ne(e),a),e)},An=N(g(yb,"s_1P6SxAujDI0")),vb=()=>{W();const t=An(),a=t.value.pageData.data.locations.data.length>0?i($b,{get data(){return t.value.pageData.data},[s]:{data:u(l=>l.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"jm_1"):i(si,null,3,"jm_0");return i(F,{get data(){return t.value.layoutData},children:a,showHeader:!1,[s]:{data:u(l=>l.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"jm_2")},wb=m(g(vb,"s_7yVzYV6frbA")),_b=({resolveValue:t})=>{const e=t(An);if(e.pageData.data.locations.data.length==0)return G({MetaTitle:"Not Found",MetaDescription:"Error 404, location not found"});const a=e.pageData.data.locations.data[0].attributes.SEO;return a.schema=e.pageData.data.locations.data[0].attributes.office.data.attributes.Schema,G(a)},Sb=Object.freeze(Object.defineProperty({__proto__:null,default:wb,head:_b,usePageData:An},Symbol.toStringTag,{value:"Module"})),Tb=()=>{const[t,e,a,l,r]=X();e.value=!e.value,e.value&&(t.value=a.data.HeroForm.ActionButton.Link.replace("=pConf=","").replace("streetInput",l.value.value).replace("zipInput",r.value.value))},Db=t=>n("div",null,{class:"flex items-center justify-between gap-1"},[n("div",null,{class:"flex flex-col gap-1 max-[1000px]:gap-2"},[i(P,{clasN:"w-[160px]",width:"1667",get media(){return t.slide.Logo.data.attributes},[s]:{clasN:s,media:u(e=>e.slide.Logo.data.attributes,[t],'p0.slide["Logo"]["data"]["attributes"]'),width:s}},3,"2R_1"),n("div",null,{class:"mx-3 max-[1000px]:hidden"},i(C,{classN:"text-[13px]",get text(){return t.slide.Paragraph},[s]:{classN:s,text:u(e=>e.slide.Paragraph,[t],'p0.slide["Paragraph"]')}},3,"2R_2"),1,null),i(Z,{get text(){return t.slide.Buttons[0].Text},get link(){return t.slide.Buttons[0].Link},[s]:{link:u(e=>e.slide.Buttons[0].Link,[t],'p0.slide["Buttons"][0]["Link"]'),text:u(e=>e.slide.Buttons[0].Text,[t],'p0.slide["Buttons"][0]["Text"]')}},3,"2R_3")],1,null),i(Xa,{clasN:"rounded-full w-[150px] mr-[30px] max-[1000px]:w-[40%]",get media(){return t.slide.Media.data.attributes},get alt(){return t.slide.Media.data.attributes.alternativeText},get title(){return t.slide.Media.data.attributes.caption},autoplay:!0,loop:!0,muted:!0,[s]:{alt:u(e=>e.slide.Media.data.attributes.alternativeText,[t],'p0.slide["Media"]["data"]["attributes"]["alternativeText"]'),autoplay:s,clasN:s,loop:s,media:u(e=>e.slide.Media.data.attributes,[t],'p0.slide["Media"]["data"]["attributes"]'),muted:s,title:u(e=>e.slide.Media.data.attributes.caption,[t],'p0.slide["Media"]["data"]["attributes"]["caption"]')}},3,"2R_4")],1,"2R_5"),Pb=t=>{const[e]=X();return n("div",{class:`flex h-[230px] items-center  justify-center overflow-hidden bg-white   ${t.isMobile??!1?"w-full max-w-[420px] rounded-full min-[1000px]:hidden":"w-[420px] rounded-br-full rounded-tr-full bg-opacity-60 max-[1000px]:hidden"}`},null,i(Pt,{hasArrows:!1,slides:e,slidesQty:1,get id(){return`header_car_${t.isMobile??!1?"mobile":"desk"}`},[s]:{hasArrows:s,id:u(a=>`header_car_${a.isMobile??!1?"mobile":"desk"}`,[t],'`header_car_${p0.isMobile??false?"mobile":"desk"}`'),slidesQty:s}},3,"2R_6"),1,"2R_7")},kb=()=>{const[t,e,a,l]=X();clearTimeout(l.value),l.value=setTimeout(()=>{t.value.value.length>2&&fetch(`/api/get-streets?q=${encodeURIComponent(t.value.value)}`).then(r=>r.json()).then(r=>{const o=r.data;o.length===0?e.value="notfound":e.value="success",a.value=o})},1e3)},Lb=t=>{const e=O(n("input",null,null,null,3,"2R_0")),a=O(n("input",null,null,null,3,null)),l=O(""),r=O(!1),o=O(),c=O([]),d=O("none"),p=O(1e3);yt(I("s_OSAER37KIRU",[p]));const f=g(Tb,"s_fq93imJ971Y",[l,r,t,e,a]),h=m(g(Db,"s_bR2jjpv9PC0")),y=t.data.HeroCarSlides.map((D,L)=>i(h,{slide:D},3,L)),b=m(g(Pb,"s_mBlTNPrtMiQ",[y])),w=g(kb,"s_r2MqT6I0l2Y",[e,d,c,o]);return i(Q,{children:[n("div",null,{class:"relative flex h-[80vh] max-h-[750px] w-full items-center"},[n("div",null,{class:u(D=>`fixed bottom-0 left-0 right-0 bg-white top-${D.value?"0 z-[200]":"[100vh] -z-[200]"}  transition-all duration-1000 ease-in-out`,[r],'`fixed bottom-0 left-0 right-0 bg-white top-${p0.value?"0 z-[200]":"[100vh] -z-[200]"}  transition-all duration-1000 ease-in-out`')},[n("button",null,{"aria-label":"Close popup",class:'absolute right-2  mt-2 mx-0" bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] focus:outline-none z-[600]',onClick$:f},n("div",null,{class:"px-3 flex flex-row items-center text-xs gap-2"},["Back to site ",i(ql,null,3,"2R_8")],1,null),1,null),n("iframe",null,{class:"h-full w-full",frameBorder:"0",src:u(D=>D.value,[l],"p0.value"),title:"load popup"},null,3,null)],1,null),n("video",{poster:St(t.data.VideoBGDesktop.data.attributes.caption)},{autoplay:!0,class:"absolute left-0 top-0 -z-10 h-full w-full object-cover",loop:!0,muted:!0,preload:"auto"},n("source",{src:St(t.data[`${p.value<=800?"VideoBGMobile":"VideoBGDesktop"}`].data.attributes.url)+"#t=0.1"},{type:"video/mp4"},null,3,null),1,null),n("div",null,{class:"flex h-full w-full items-center justify-between max-[1000px]:flex-col-reverse max-[1000px]:px-4"},[i(b,null,3,"2R_9"),n("div",null,{class:"relative flex w-[420px] flex-col items-center justify-center gap-5 rounded-bl-full rounded-tl-full bg-white bg-opacity-60 max-[1000px]:mb-8 max-[1000px]:w-full max-[1000px]:max-w-[420px] max-[1000px]:rounded-full max-[1000px]:py-8 min-[1000px]:h-[230px]"},[n("div",{class:`absolute left-10 right-10 top-[90%] z-20 flex max-h-[200px] flex-col gap-3 overflow-y-auto rounded-xl bg-white p-6 text-primary-blue shadow-lg ${d.value==="none"||d.value==="selected"?"hidden":""}`},null,[u(D=>D.value.length===0?"Not found":"",[c],'p0.value.length===0?"Not found":""'),c.value.map((D,L)=>n("div",{onClick$:I("s_0WdAGCARSDU",[e,D,d,a])},{class:"grid items-center gap-4 hover:cursor-pointer",style:{gridTemplateColumns:"20px 1fr"}},[i(Fd,{class:"w-6 text-secondary-red",[s]:{class:s}},3,"2R_10"),n("span",null,{class:"text-[14px]"},_(D,"address"),1,null)],0,L))],1,null),n("div",null,{class:"px-8 text-center text-[22px] font-[600] text-primary-blue max-[1000px]:px-12"},u(D=>D.data.HeroForm.Title,[t],'p0.data["HeroForm"]["Title"]'),3,null),n("div",null,{class:"flex w-full items-center gap-4 px-6 max-[1000px]:flex-col "},[n("input",{ref:e},{class:"w-[50%] rounded-full px-3 py-2 placeholder-primary-blue",onKeyUp$:w,placeholder:"Address Search",type:"text"},null,3,null),n("input",{ref:a},{class:"w-[50%] rounded-full px-3 py-2 placeholder-primary-blue",placeholder:"Zip Code",type:"text"},null,3,null)],1,null),i(Z,{get text(){return t.data.HeroForm.ActionButton.Text},onClick:f,[s]:{onClick:s,text:u(D=>D.data.HeroForm.ActionButton.Text,[t],'p0.data["HeroForm"]["ActionButton"]["Text"]')}},3,"2R_11")],1,null)],1,null)],1,null),n("div",null,{class:"flex justify-center bg-gradient-to-r from-[#3d76c1] to-[#3568ae] px-4 pt-4"},i(b,{isMobile:!0,[s]:{isMobile:s}},3,"2R_12"),1,null)]},1,"2R_13")},Cb=m(g(Lb,"s_S18xoZmdQUw")),Mb=t=>n("div",null,{class:"z-20 flex w-full justify-center bg-gradient-to-br from-[#3d76c2] to-[#2e599a] px-10 py-6 text-white"},n("div",null,{class:"flex max-w-[1100px] items-center justify-center gap-8 max-[1000px]:flex-col"},[n("div",null,{class:"flex w-[50%] flex-col text-justify max-[1000px]:w-[100%]"},[n("div",null,{class:"text-[38px] font-bold max-sm:text-[28px]"},u(e=>e.data.prosPar.Title,[t],'p0.data.prosPar["Title"]'),3,null),n("div",null,{class:"text-[18px] max-sm:text-[15px]"},u(e=>e.data.prosPar.Paragraph,[t],'p0.data.prosPar["Paragraph"]'),3,null),n("div",null,{class:"mt-6 flex flex-col gap-4"},t.data.prosData.map((e,a)=>n("div",null,{class:"flex-row "},n("div",null,{class:"flex flex-col"},[n("div",null,{class:"flex flex-row gap-4 items-center"},[n("div",null,{class:" bg-secondary-red h-fit w-fit rounded-full p-2"},i(P,{height:20,toWhite:!0,width:20,get media(){return e.Icon.data.attributes},[s]:{height:s,media:x(e.Icon.data,"attributes"),toWhite:s,width:s}},3,"l8_0"),1,null),n("span",null,{class:"text-[28px] font-bold"},i(C,{get text(){return e.Title},classN:"text-white",[s]:{classN:s,text:x(e,"Title")}},3,"l8_1"),1,null)],1,null),n("span",null,{class:"text-[18px] "},i(C,{get text(){return e.Text},classN:"text-white",[s]:{classN:s,text:x(e,"Text")}},3,"l8_2"),1,null)],1,null),1,a)),1,null)],1,null),i(P,{height:"720",width:"656",get media(){return t.data.prosMap},clasN:"px-8  min-w-[250px]",[s]:{clasN:s,height:s,media:u(e=>e.data.prosMap,[t],"p0.data.prosMap"),width:s}},3,"l8_3")],1,null),1,"l8_4"),jb=m(g(Mb,"s_F6ekLiR69OY")),Eb=t=>{const e=t.data.Logo.data.attributes,a=t.data.Media.data.attributes;return n("div",null,{class:"mb-4 flex flex-row-reverse max-w-[1200px] items-center justify-center gap-4 self-center px-8 max-[800px]:flex-col-reverse"},[n("div",null,{class:"flex w-[400px] items-center justify-center self-center p-4 min-[800px]:w-[40%]"},i(P,{height:500,media:a,width:400,[s]:{height:s,width:s}},3,"a2_0"),1,null),n("div",null,{class:"flex flex-col items-center justify-center gap-4 min-[800px]:w-[60%]"},[n("div",null,{class:"max-w-[470px]"},i(P,{height:230,media:e,width:1230,[s]:{height:s,width:s}},3,"a2_1"),1,null),n("div",null,{class:"flex items-start gap-2"},[n("div",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(l=>l.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"text-center text-[28px] font-bold text-secondary-red max-sm:text-[18px]"},u(l=>l.data.Subtitle,[t],'p0.data["Subtitle"]'),3,null)],3,null),n("div",null,{class:"text-primary-blue"},[i(C,{classN:"text-justify max-sm:text-[15px] text-[18px] text-[#2E5899]",get text(){return t.data.Paragraph},[s]:{classN:s,text:u(l=>l.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"a2_2"),t.parGFIPlans.map((l,r)=>n("div",null,{class:"text-[22px]"},i(_e,{get title(){return l.Title},children:i(C,{classN:"text-[16px] text-justify",get text(){return l.Paragraph},[s]:{classN:s,text:x(l,"Paragraph")}},3,"a2_3"),classContainer:"bg-white shadow-xl",[s]:{classContainer:s,title:x(l,"Title")}},1,"a2_4"),1,r))],1,null),n("div",null,{class:"flex gap-4"},t.data.Buttons.map((l,r)=>i(Z,{get text(){return l.Text},get link(){return l.Link},[s]:{link:x(l,"Link"),text:x(l,"Text")}},3,r)),1,null)],1,null)],1,"a2_5")},Bb=m(g(Eb,"s_M9NFBwXMc48")),Ib=t=>n("div",null,{class:"flex items-center justify-evenly gap-4 px-8 py-6 max-[1200px]:flex-col"},t.data.map((e,a)=>n("div",null,{class:" flex max-w-[400px] flex-col items-center gap-2 text-center text-primary-blue"},[i(be,{get media(){return e.Media.data.attributes},color:"bg-primary-blue",width:"w-[360px]",[s]:{color:s,media:x(e.Media.data,"attributes"),width:s}},3,"pO_0"),n("h2",null,{class:"text-[24px] font-[700]"},_(e,"Title"),1,null),n("p",null,{class:"text-[17px] font-[400]"},_(e,"Paragraph"),1,null),i(Z,{get text(){return e.Buttons[0].Text},get link(){return e.Buttons[0].Link},[s]:{link:x(e.Buttons[0],"Link"),text:x(e.Buttons[0],"Text")}},3,"pO_1")],1,a)),1,"pO_2"),Ob=m(g(Ib,"s_PyTSx8biYlE")),Ab=t=>{const e=t.data.pageHome.data.attributes,a=t.data.sectionProsRta.data.attributes.Pros,l=e.ProsPicture.data.attributes;return n("div",null,{class:"relative ",onClick$:I("s_TkQ204PTgK8")},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-[100vh] -z-10 bg-white"},null,3,null),i(Cb,{data:e},3,"Ee_0"),i(jb,{data:{prosPar:e.ProsPar,prosData:a,prosMap:l}},3,"Ee_1"),i(qt,{get data(){return e.ParACP},reverse:!0,textPercentage:60,[s]:{data:x(e,"ParACP"),reverse:s,textPercentage:s}},3,"Ee_2"),n("div",null,{class:"flex w-full justify-center bg-[#ebf4fc]"},i(Bb,{data:e.ParGFServices[0],get parGFIPlans(){return e.ParGFIPlans},[s]:{parGFIPlans:x(e,"ParGFIPlans")}},3,"Ee_3"),1,null),i(oe,{data:e.ParGFServices.slice(1,e.ParGFServices.length)},3,"Ee_4"),n("div",null,{class:"bg-[#ebf4fc]"},i(Ob,{get data(){return e.SugsPages},[s]:{data:x(e,"SugsPages")}},3,"Ee_5"),1,null)],1,"Ee_6")},Nb=m(g(Ab,"s_G08oK4nfxwg")),Rb=t=>n("div",null,{class:"flex  w-full flex-col items-center justify-center px-8 text-primary-blue"},[n("div",null,{class:"flex max-w-[1400px] items-center justify-evenly gap-4 py-16 max-[800px]:flex-col"},[n("h1",null,{class:"w-[40%] text-center text-[42px] font-[600]  max-sm:text-[28px] leading-10 max-[800px]:w-full"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),i(P,{clasN:" rounded-2xl shadow-xl w-[40%] max-[800px]:w-full",height:"539",width:"833",get media(){return t.data.Cover.data.attributes},[s]:{clasN:s,height:s,media:u(e=>e.data.Cover.data.attributes,[t],'p0.data["Cover"]["data"]["attributes"]'),width:s}},3,"cD_0")],1,null),n("div",null,{class:"mb-8 max-w-[1400px]"},i(C,{get text(){return t.data.Description},classN:"text-justify",[s]:{classN:s,text:u(e=>e.data.Description,[t],'p0.data["Description"]')}},3,"cD_1"),1,null)],1,"cD_2"),qb=m(g(Rb,"s_QI52uAygONM")),Fb=(t,e)=>{const a=e==="es-419";return console.log(`query QueryPostPage {
    posts (filters: {Slug: {eq: "${t}${a?"-es":""}"}} pagination:{limit:1} locale:"${e}") {
      data {
        attributes {
          Title
          Date
          Description
          Slug
          Cover {
            ${$}
          }
          ${q}
        }
      }
    }
  }`),`query QueryPostPage {
        posts (filters: {Slug: {eq: "${t}${a?"-es":""}"}} pagination:{limit:1} locale:"${e}") {
          data {
            attributes {
              Title
              Date
              Description
              Slug
              Cover {
                ${$}
              }
              ${q} 
            }
          }
        }
      }`},zb=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang;let a={};if(e=="en"||e=="es-419")return a=await z(ti,e),{...a,type:"home"};const l=e.includes("es/")?"es-419":"en",r=e.includes("es/")?e.split("es/")[1]:e;return a=await Ke(Fb(r,l),l),{...a,type:a.pageData.data.posts.data.length>0?"post":"404"}},Nn=N(g(zb,"s_Up0e7VSBoHc")),Gb=()=>{W();const t=Nn();return i(F,{get data(){return t.value.layoutData},children:[t.value.type=="home"&&n("h1",null,{class:"absolute opacity-0"},"Rural Telecommunications of America Inc.",3,"2d_0"),t.value.type=="home"?i(Nb,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"2d_1"):t.value.type=="post"?i(qb,{get data(){return t.value.pageData.data.posts.data[0].attributes},[s]:{data:u(e=>e.value.pageData.data.posts.data[0].attributes,[t],'p0.value["pageData"]["data"]["posts"]["data"][0]["attributes"]')}},3,"2d_2"):i(si,null,3,"2d_3")],showHeader:!1,[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"2d_4")},Qb=m(g(Gb,"s_jpH0I2vriFs")),Hb=({resolveValue:t})=>{const e=t(Nn),a=e.type;let l;return a=="home"?l=e.pageData.data.pageHome.data.attributes.SEO:a=="post"?(l=e.pageData.data.posts.data[0].attributes.SEO,l||(l={MetaTitle:e.pageData.data.posts.data[0].attributes.Title,MetaDescription:e.pageData.data.posts.data[0].attributes.Description,preventIndexing:!0,Keywords:e.pageData.data.posts.data[0].attributes.Title})):l={MetaTitle:"Not found"},G(l)},Wb=Object.freeze(Object.defineProperty({__proto__:null,default:Qb,head:Hb,usePageData:Nn},Symbol.toStringTag,{value:"Module"})),Ub=[Tc],A=()=>$d,Yb=[["forms/",[A,()=>_d],"/forms/",["q-0wBsfSYw.js","q-DN6RY7-X.js"]],["[...lang]/api/emailjs/",[A,()=>Td],"/[...lang]/api/emailjs/",["q-0wBsfSYw.js"]],["[...lang]/api/get-streets/",[A,()=>kd],"/[...lang]/api/get-streets/",["q-0wBsfSYw.js"]],["[...lang]/api/graphql/",[A,()=>Cd],"/[...lang]/api/graphql/",["q-0wBsfSYw.js"]],["[...lang]/api/survey-pre-exit/",[A,()=>jd],"/[...lang]/api/survey-pre-exit/",["q-0wBsfSYw.js"]],["[...lang]/acp/",[A,()=>x0],"/[...lang]/acp/",["q-0wBsfSYw.js","q-Df2G01oV.js"]],["[...lang]/appreciation-giveaway/",[A,()=>_0],"/[...lang]/appreciation-giveaway/",["q-0wBsfSYw.js","q-DkeJ8BYN.js"]],["[...lang]/appreciation-lead/",[A,()=>M0],"/[...lang]/appreciation-lead/",["q-0wBsfSYw.js","q-DqDkZ8Ii.js"]],["[...lang]/awards/",[A,()=>q0],"/[...lang]/awards/",["q-0wBsfSYw.js","q-COSQLT24.js"]],["[...lang]/blog/",[A,()=>ef],"/[...lang]/blog/",["q-0wBsfSYw.js","q-f0LNHEkz.js"]],["[...lang]/board-members/",[A,()=>cf],"/[...lang]/board-members/",["q-0wBsfSYw.js","q-D38KVDSR.js"]],["[...lang]/business/",[A,()=>$f],"/[...lang]/business/",["q-0wBsfSYw.js","q-Dj1B00vv.js"]],["[...lang]/careers/",[A,()=>qf],"/[...lang]/careers/",["q-0wBsfSYw.js","q-CxZw4XKR.js"]],["[...lang]/client-services-agreement-general-terms-and-conditions/",[A,()=>Yf],"/[...lang]/client-services-agreement-general-terms-and-conditions/",["q-0wBsfSYw.js","q-DFFdexOw.js"]],["[...lang]/contact-us/",[A,()=>ag],"/[...lang]/contact-us/",["q-0wBsfSYw.js","q-DVY6OFRY.js"]],["[...lang]/cookies/",[A,()=>cg],"/[...lang]/cookies/",["q-0wBsfSYw.js","q-Dk9arxuE.js"]],["[...lang]/deals/",[A,()=>Tg],"/[...lang]/deals/",["q-0wBsfSYw.js","q-CGMZYcIO.js"]],["[...lang]/faq/",[A,()=>Eg],"/[...lang]/faq/",["q-0wBsfSYw.js","q-D7Vno4df.js"]],["[...lang]/free-install/",[A,()=>Qg],"/[...lang]/free-install/",["q-0wBsfSYw.js","q-DP10gXXy.js"]],["[...lang]/gfsn/",[A,()=>ix],"/[...lang]/gfsn/",["q-0wBsfSYw.js","q-CnGgiJUF.js"]],["[...lang]/gigfast-cloud/",[A,()=>xx],"/[...lang]/gigfast-cloud/",["q-0wBsfSYw.js","q-D13Y569l.js"]],["[...lang]/gigfast-internet-support/",[A,()=>kx],"/[...lang]/gigfast-internet-support/",["q-0wBsfSYw.js","q-CCE0SXUY.js"]],["[...lang]/gigfast-internet/",[A,()=>Ax],"/[...lang]/gigfast-internet/",["q-0wBsfSYw.js","q-CmDzROtz.js"]],["[...lang]/gigfast-iot/",[A,()=>Hx],"/[...lang]/gigfast-iot/",["q-0wBsfSYw.js","q-FPzQYyER.js"]],["[...lang]/gigfast-tv-privacy-policy/",[A,()=>Jx],"/[...lang]/gigfast-tv-privacy-policy/",["q-0wBsfSYw.js","q-BcCV9j0I.js"]],["[...lang]/gigfast-tv-support/",[A,()=>pm],"/[...lang]/gigfast-tv-support/",["q-0wBsfSYw.js","q-Ta-laJGZ.js"]],["[...lang]/gigfast-tv/",[A,()=>Mm],"/[...lang]/gigfast-tv/",["q-0wBsfSYw.js","q-24UJoryX.js"]],["[...lang]/gigfast-voice-support/",[A,()=>Rm],"/[...lang]/gigfast-voice-support/",["q-0wBsfSYw.js","q-DLdLyRUk.js"]],["[...lang]/gigfast-voice/",[A,()=>Xm],"/[...lang]/gigfast-voice/",["q-0wBsfSYw.js","q-DIgfas36.js"]],["[...lang]/giving-back/",[A,()=>sh],"/[...lang]/giving-back/",["q-0wBsfSYw.js","q-DxUydFx2.js"]],["[...lang]/goldsmith-tt/",[A,()=>fh],"/[...lang]/goldsmith-tt/",["q-0wBsfSYw.js","q-BaMkkgS2.js"]],["[...lang]/leadership-team/",[A,()=>bh],"/[...lang]/leadership-team/",["q-0wBsfSYw.js","q-JVjAc21A.js"]],["[...lang]/legal/",[A,()=>Ph],"/[...lang]/legal/",["q-0wBsfSYw.js","q-UOUNfNel.js"]],["[...lang]/local-weather-stations/",[A,()=>Ih],"/[...lang]/local-weather-stations/",["q-0wBsfSYw.js","q-C752OGh_.js"]],["[...lang]/news/",[A,()=>Gh],"/[...lang]/news/",["q-0wBsfSYw.js","q-nG2VT8e3.js"]],["[...lang]/our-story/",[A,()=>Xh],"/[...lang]/our-story/",["q-0wBsfSYw.js","q-BWbX35db.js"]],["[...lang]/portability/",[A,()=>i$],"/[...lang]/portability/",["q-0wBsfSYw.js","q-iFLxUPxB.js"]],["[...lang]/post_slug/",[A,()=>g$],"/[...lang]/post_slug/",["q-0wBsfSYw.js","q-ChkCkApL.js"]],["[...lang]/privacy-policy/",[A,()=>w$],"/[...lang]/privacy-policy/",["q-0wBsfSYw.js","q-BofStHEK.js"]],["[...lang]/pumptopper/",[A,()=>C$],"/[...lang]/pumptopper/",["q-0wBsfSYw.js","q-CyrIMsYy.js"]],["[...lang]/referral-program/",[A,()=>q$],"/[...lang]/referral-program/",["q-0wBsfSYw.js","q-BmZslR2L.js"]],["[...lang]/residential/",[A,()=>Y$],"/[...lang]/residential/",["q-0wBsfSYw.js","q-ftnB_JBi.js"]],["[...lang]/support/",[A,()=>l1],"/[...lang]/support/",["q-0wBsfSYw.js","q-swsnF8SH.js"]],["[...lang]/testimonials/",[A,()=>p1],"/[...lang]/testimonials/",["q-0wBsfSYw.js","q-DVH1iV8_.js"]],["[...lang]/texas/",[A,()=>v1],"/[...lang]/texas/",["q-0wBsfSYw.js","q-KJ-qj6LH.js"]],["[...lang]/wholesale/",[A,()=>L1],"/[...lang]/wholesale/",["q-0wBsfSYw.js","q-DaxFWIHv.js"]],["[...lang]/winners-circle/",[A,()=>N1],"/[...lang]/winners-circle/",["q-0wBsfSYw.js","q-DlXvQiZ2.js"]],["[...lang]/zane-smith-sponsorship/",[A,()=>nb],"/[...lang]/zane-smith-sponsorship/",["q-0wBsfSYw.js","q-B553HajC.js"]],["[...lang]/texas/[slug]/local-blog/",[A,()=>cb],"/[...lang]/texas/[slug]/local-blog/",["q-0wBsfSYw.js","q-D_bTMPsD.js"]],["[...lang]/texas/[slug]/",[A,()=>Sb],"/[...lang]/texas/[slug]/",["q-0wBsfSYw.js","q-BIyJVCUp.js"]],["[...lang]",[A,()=>Wb],"/[...lang]",["q-0wBsfSYw.js","q-_MlZt8Vd.js"]]],Vb=[],Zb=!0,ri="/",Xb=!0,uy={routes:Yb,serverPlugins:Ub,menus:Vb,trailingSlash:Zb,basePathname:ri,cacheModules:Xb};export{s as A,Ub as B,Yb as C,Vb as D,Zb as E,Q as F,ri as G,Xb as H,iy as Q,sy as R,it as S,Zi as _,ly as a,ey as b,yu as c,m as d,vt as e,i as f,n as g,u as h,g as i,ay as j,Y as k,_ as l,Rt as m,Al as n,Ft as o,yl as p,uy as q,X as r,ty as s,Ma as t,ry as u,ny as v,Nl as w,Bl as x,oy as y,ss as z};
