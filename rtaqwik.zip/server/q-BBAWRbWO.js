import{parse as yr}from"marked";import{createClient as wo}from"@supabase/supabase-js";import{jsPDF as So}from"jspdf";import _r from"html2canvas";const To=!0,Do=!1,Qe=t=>t&&typeof t.nodeType=="number",wr=t=>t.nodeType===9,Ge=t=>t.nodeType===1,He=t=>{const e=t.nodeType;return e===1||e===111},Po=t=>{const e=t.nodeType;return e===1||e===111||e===3},zt=t=>t.nodeType===111,Jl=t=>t.nodeType===3,Aa=t=>t.nodeType===8,Ke=(t,...e)=>tn(!1,t,...e),Sr=(t,...e)=>{throw tn(!1,t,...e)},Xl=(t,...e)=>tn(!0,t,...e),Ie=()=>{},ko=t=>t,tn=(t,e,...a)=>{const l=e instanceof Error?e:new Error(e);return console.error("%cQWIK ERROR","",l.message,...ko(a),l.stack),t&&setTimeout(()=>{throw l},0),l};const dl=t=>`Code(${t}) https://github.com/QwikDev/qwik/blob/main/packages/qwik/src/core/error/error.ts#L${8+t}`,ot=(t,...e)=>{const a=dl(t,...e);return Xl(a,...e)},Lo=()=>({isServer:To,importSymbol(t,e,a){var o;{const c=Ei(a),p=(o=globalThis.__qwik_reg_symbols)==null?void 0:o.get(c);if(p)return p}if(!e)throw ot(31,a);if(!t)throw ot(30,e,a);const l=Co(t.ownerDocument,t,e).toString(),r=new URL(l);return r.hash="",import(r.href).then(c=>c[a])},raf:t=>new Promise(e=>{requestAnimationFrame(()=>{e(t())})}),nextTick:t=>new Promise(e=>{setTimeout(()=>{e(t())})}),chunkForSymbol:(t,e)=>[t,e??"_"]}),Co=(t,e,a)=>{const l=t.baseURI,r=new URL(e.getAttribute("q:base")??l,l);return new URL(a,r)};let en=Lo();const R_=t=>en=t,pl=()=>en,Dt=()=>en.isServer,Ea=t=>{const e=Object.getPrototypeOf(t);return e===Object.prototype||e===null},Ht=t=>!!t&&typeof t=="object",lt=t=>Array.isArray(t),Be=t=>typeof t=="string",vt=t=>typeof t=="function",ct=t=>t&&typeof t.then=="function",fl=(t,e,a)=>{try{const l=t();return ct(l)?l.then(e,a):e(l)}catch(l){return a(l)}},X=(t,e)=>ct(t)?t.then(e):e(t),an=t=>t.some(ct)?Promise.all(t):t,na=t=>t.length>0?Promise.all(t):t,Tr=t=>t!=null,Mo=t=>new Promise(e=>{setTimeout(e,t)}),Ft=[],ft={},Na=t=>typeof document<"u"?document:t.nodeType===9?t:t.ownerDocument,jo="q:renderFn",Pt="q:slot",Dr="q:s",gl="q:style",Ao="q:sstyle",Pr="q:instance",kr=(t,e)=>t["qFuncs_"+e]||[],Eo="q:id",El=Symbol("proxy target"),sa=Symbol("proxy flags"),qt=Symbol("proxy manager"),s=Symbol("IMMUTABLE"),xl="_qc_",Tt=(t,e,a)=>t.setAttribute(e,a),Nt=(t,e)=>t.getAttribute(e),ln=t=>t.replace(/([A-Z])/g,"-$1").toLowerCase(),No=t=>t.replace(/-./g,e=>e[1].toUpperCase()),Io=/^(on|window:|document:)/,Lr="preventdefault:",nn=t=>t.endsWith("$")&&Io.test(t),sn=t=>{if(t.length===0)return Ft;if(t.length===1){const a=t[0];return[[a[0],[a[1]]]]}const e=[];for(let a=0;a<t.length;a++){const l=t[a][0];e.includes(l)||e.push(l)}return e.map(a=>[a,t.filter(l=>l[0]===a).map(l=>l[1])])},rn=(t,e,a,l)=>{if(e.endsWith("$"),e=Nl(e.slice(0,-1)),a)if(lt(a)){const r=a.flat(1/0).filter(o=>o!=null).map(o=>[e,Us(o,l)]);t.push(...r)}else t.push([e,Us(a,l)]);return e},Ws=["on","window:on","document:on"],Bo=["on","on-window","on-document"],Nl=t=>{let e="on";for(let a=0;a<Ws.length;a++){const l=Ws[a];if(t.startsWith(l)){e=Bo[a],t=t.slice(l.length);break}}return e+":"+(t=t.startsWith("-")?ln(t.slice(1)):t.toLowerCase())},Us=(t,e)=>(t.$setContainer$(e),t),Oo=(t,e)=>{const a=t.$element$.attributes,l=[];for(let r=0;r<a.length;r++){const{name:o,value:c}=a.item(r);if(o.startsWith("on:")||o.startsWith("on-window:")||o.startsWith("on-document:")){const p=c.split(`
`);for(const d of p){const f=_l(d,e);f.$capture$&&Di(f,t),l.push([o,f])}}}return l},qo=(t,e)=>{un(on(t,void 0),e)},Ys=(t,e)=>{un(on(t,"document"),e)},Ro=(t,e)=>{un(on(t,"window"),e)},on=(t,e)=>{const a=e!==void 0?e+":":"";return Array.isArray(t)?t.map(l=>`${a}on-${l}`):`${a}on-${t}`},un=(t,e)=>{if(e){const a=Sn(),l=yt(a.$hostElement$,a.$renderCtx$.$static$.$containerState$);typeof t=="string"?l.li.push([Nl(t),e]):l.li.push(...t.map(r=>[Nl(r),e])),l.$flags$|=Re}},zo=(t,e,a,l)=>{typeof CustomEvent=="function"&&t&&t.dispatchEvent(new CustomEvent(e,{detail:a,bubbles:l,composed:l}))},cn=(t,e,a=0)=>e.$proxyMap$.get(t)||(a!==0&&hl(t,a),Ia(t,e,void 0)),Ia=(t,e,a)=>{za(t),e.$proxyMap$.has(t);const l=e.$subsManager$.$createManager$(a),r=new Proxy(t,new Cr(e,l));return e.$proxyMap$.set(t,r),r},ml=()=>{const t={};return hl(t,2),t},hl=(t,e)=>{Object.defineProperty(t,sa,{value:e,enumerable:!1})},Fo=(t,e)=>{const a={};for(const l in t)e.includes(l)||(a[l]=t[l]);return a};class Cr{constructor(e,a){this.$containerState$=e,this.$manager$=a}deleteProperty(e,a){if(2&e[sa])throw ot(17);return typeof a=="string"&&delete e[a]&&(this.$manager$.$notifySubs$(lt(e)?void 0:a),!0)}get(e,a){var f;if(typeof a=="symbol")return a===El?e:a===qt?this.$manager$:e[a];const l=e[sa]??0,r=bt(),o=!!(1&l),c=e["$$"+a];let p,d;if(r&&(p=r.$subscriber$),!(2&l)||a in e&&!Qo((f=e[s])==null?void 0:f[a])||(p=null),c?(d=c.value,p=null):d=e[a],p){const x=lt(e);this.$manager$.$addSub$(p,x?void 0:a)}return o?Go(d,this.$containerState$):d}set(e,a,l){if(typeof a=="symbol")return e[a]=l,!0;const r=e[sa]??0;if(2&r)throw ot(17);const o=1&r?za(l):l;if(lt(e))return e[a]=o,this.$manager$.$notifySubs$(),!0;const c=e[a];return e[a]=o,c!==o&&this.$manager$.$notifySubs$(a),!0}has(e,a){if(a===El)return!0;const l=Object.prototype.hasOwnProperty;return!!l.call(e,a)||!(typeof a!="string"||!l.call(e,"$$"+a))}ownKeys(e){if(!(2&(e[sa]??0))){let l=null;const r=bt();r&&(l=r.$subscriber$),l&&this.$manager$.$addSub$(l)}return lt(e)?Reflect.ownKeys(e):Reflect.ownKeys(e).map(l=>typeof l=="string"&&l.startsWith("$$")?l.slice(2):l)}getOwnPropertyDescriptor(e,a){return lt(e)||typeof a=="symbol"?Object.getOwnPropertyDescriptor(e,a):{enumerable:!0,configurable:!0}}}const Qo=t=>t===s||mt(t),Go=(t,e)=>{if(Ht(t)){if(Object.isFrozen(t))return t;const a=za(t);if(a!==t||Ci(a))return t;if(Ea(a)||lt(a))return e.$proxyMap$.get(a)||cn(a,e,1)}return t},Ho=(t,e=0)=>{for(let a=0;a<t.length;a++)e=(e<<5)-e+t.charCodeAt(a),e|=0;return Number(Math.abs(e)).toString(36)},Vo=(t,e)=>`${Ho(t.$hash$)}-${e}`,Mr=t=>{const e=t.join("|");if(e.length>0)return e},Xe=()=>{const t=Sn(),e=yt(t.$hostElement$,t.$renderCtx$.$static$.$containerState$),a=e.$seq$||(e.$seq$=[]),l=t.$i$++;return{val:a[l],set:r=>a[l]=r,i:l,iCtx:t,elCtx:e}},Vt=t=>Object.freeze({id:ln(t)}),Ae=(t,e)=>{const{val:a,set:l,elCtx:r}=Xe();if(a!==void 0)return;(r.$contexts$||(r.$contexts$=new Map)).set(t.id,e),l(!0)},ga=(t,e)=>{const{val:a,set:l,iCtx:r,elCtx:o}=Xe();if(a!==void 0)return a;const c=jr(t,o,r.$renderCtx$.$static$.$containerState$);if(typeof e=="function")return l(xt(void 0,e,c));if(c!==void 0)return l(c);if(e!==void 0)return l(e);throw ot(13,t.id)},Wo=(t,e)=>{var r;let a=t,l=1;for(;a&&!((r=a.hasAttribute)!=null&&r.call(a,"q:container"));){for(;a=a.previousSibling;)if(Aa(a)){const o=a.__virtual;if(o){const c=o[xl];if(a===o.open)return c??yt(o,e);if(c!=null&&c.$parentCtx$)return c.$parentCtx$;a=o;continue}if(a.data==="/qv")l++;else if(a.data.startsWith("qv ")&&(l--,l===0))return yt(Ra(a),e)}a=t.parentElement,t=a}return null},Uo=(t,e)=>(t.$parentCtx$===void 0&&(t.$parentCtx$=Wo(t.$element$,e)),t.$parentCtx$),jr=(t,e,a)=>{var o;const l=t.id;if(!e)return;let r=e;for(;r;){const c=(o=r.$contexts$)==null?void 0:o.get(l);if(c)return c;r=Uo(r,a)}},Yo=Vt("qk-error"),dn=(t,e,a)=>{const l=kt(e);if(Dt())throw t;{const r=jr(Yo,l,a.$static$.$containerState$);if(r===void 0)throw t;r.error=t}},Zo=new Set(["animationIterationCount","aspectRatio","borderImageOutset","borderImageSlice","borderImageWidth","boxFlex","boxFlexGroup","boxOrdinalGroup","columnCount","columns","flex","flexGrow","flexShrink","gridArea","gridRow","gridRowEnd","gridRowStart","gridColumn","gridColumnEnd","gridColumnStart","fontWeight","lineClamp","lineHeight","opacity","order","orphans","scale","tabSize","widows","zIndex","zoom","MozAnimationIterationCount","MozBoxFlex","msFlex","msFlexPositive","WebkitAnimationIterationCount","WebkitBoxFlex","WebkitBoxOrdinalGroup","WebkitColumnCount","WebkitColumns","WebkitFlex","WebkitFlexGrow","WebkitFlexShrink","WebkitLineClamp"]),Ko=t=>Zo.has(t),Ya=(t,e,a)=>{e.$flags$&=~da,e.$flags$|=_n,e.$slots$=[],e.li.length=0;const l=e.$element$,r=e.$componentQrl$,o=e.$props$,c=_t(t.$static$.$locale$,l,void 0,"qRender"),p=c.$waitOn$=[],d=Ba(t);d.$cmpCtx$=e,d.$slotCtx$=void 0,c.$subscriber$=[0,l],c.$renderCtx$=t,r.$setContainer$(t.$static$.$containerState$.$containerEl$);const f=r.getFn(c);return fl(()=>f(o),x=>X(Dt()?X(na(p),()=>X(Eu(t.$static$.$containerState$,t),()=>na(p))):na(p),()=>{var m;if(e.$flags$&da){if(!(a&&a>100))return Ya(t,e,a?a+1:1);Ie(`Infinite loop detected. Element: ${(m=e.$componentQrl$)==null?void 0:m.$symbol$}`)}return{node:x,rCtx:d}}),x=>{var m;if(x===ii){if(!(a&&a>100))return X(na(p),()=>Ya(t,e,a?a+1:1));Ie(`Infinite loop detected. Element: ${(m=e.$componentQrl$)==null?void 0:m.$symbol$}`)}return dn(x,l,t),{node:xn,rCtx:d}})},Ar=(t,e)=>({$static$:{$doc$:t,$locale$:e.$serverData$.locale,$containerState$:e,$hostElements$:new Set,$operations$:[],$postOperations$:[],$roots$:[],$addSlots$:[],$rmSlots$:[],$visited$:[]},$cmpCtx$:null,$slotCtx$:void 0}),Ba=t=>({$static$:t.$static$,$cmpCtx$:t.$cmpCtx$,$slotCtx$:t.$slotCtx$}),pn=(t,e)=>{var a;return(a=e==null?void 0:e.$scopeIds$)!=null&&a.length?e.$scopeIds$.join(" ")+" "+Za(t):Za(t)},Za=t=>{if(!t)return"";if(Be(t))return t.trim();const e=[];if(lt(t))for(const a of t){const l=Za(a);l&&e.push(l)}else for(const[a,l]of Object.entries(t))l&&e.push(a.trim());return e.join(" ")},bl=t=>{if(t==null)return"";if(typeof t=="object"){if(lt(t))throw ot(0,t,"style");{const e=[];for(const a in t)if(Object.prototype.hasOwnProperty.call(t,a)){const l=t[a];l!=null&&(a.startsWith("--")?e.push(a+":"+l):e.push(ln(a)+":"+Jo(a,l)))}return e.join(";")}}return String(t)},Jo=(t,e)=>typeof e!="number"||e===0||Ko(t)?e:e+"px",wa=t=>ze(t.$static$.$containerState$.$elementIndex$++),Er=(t,e)=>{const a=wa(t);e.$id$=a},Sa=t=>mt(t)?Sa(t.value):t==null||typeof t=="boolean"?"":String(t);function Nr(t){return t.startsWith("aria-")}const Ir=(t,e)=>!!e.key&&(!ta(t)||!vt(t.type)&&t.key!=e.key),ht="dangerouslySetInnerHTML";var Br;const Ua="<!--qkssr-f-->";class Or{constructor(e){this.nodeType=e,this[Br]=null}}Br=xl;const Xo=()=>new Or(9),z_=async(t,e)=>{var w,D,v;const a=e.containerTagName,l=Ka(1).$element$,r=Dn(l,e.base??"/");r.$serverData$.locale=(w=e.serverData)==null?void 0:w.locale;const o=Xo(),c=Ar(o,r),p=e.beforeContent??[],d={$static$:{$contexts$:[],$headNodes$:a==="html"?p:[],$locale$:(D=e.serverData)==null?void 0:D.locale,$textNodes$:new Map},$projectedChildren$:void 0,$projectedCtxs$:void 0,$invocationContext$:void 0},f=(v=e.serverData)==null?void 0:v.locale,x=e.containerAttributes,m=x["q:render"];x["q:container"]="paused",x["q:version"]="1.8.0",x["q:render"]=(m?m+"-":"")+"ssr",x["q:base"]=e.base||"",x["q:locale"]=f,x["q:manifest-hash"]=e.manifestHash,x["q:instance"]=tu();const $=a==="html"?[t]:[p,t];a!=="html"&&(x.class="qc📦"+(x.class?" "+x.class:""));const y=r.$serverData$={...r.$serverData$,...e.serverData};y.containerAttributes={...y.containerAttributes,...x},(d.$invocationContext$=_t(f)).$renderCtx$=c;const P=n(a,null,x,$,da|Re,null);r.$hostsRendering$=new Set,await Promise.resolve().then(()=>eu(P,c,d,e.stream,r,e))},tu=()=>Math.random().toString(36).slice(2),eu=async(t,e,a,l,r,o)=>{const c=o.beforeClose;return await gn(t,e,a,l,0,c?p=>{const d=c(a.$static$.$contexts$,r,!1,a.$static$.$textNodes$);return jt(d,e,a,p,0,void 0)}:void 0),e},au=async(t,e,a,l,r)=>{l.write(Ua);const o=t.props.children;let c;if(vt(o)){const p=o({write(d){l.write(d),l.write(Ua)}});if(ct(p))return p;c=p}else c=o;for await(const p of c)await jt(p,e,a,l,r,void 0),l.write(Ua)},qr=(t,e,a,l,r,o,c,p)=>{var w;const d=t.props,f=d["q:renderFn"];if(f)return e.$componentQrl$=f,su(l,r,o,e,t,c,p);let x="<!--qv"+nu(d);const m="q:s"in d,$=t.key!=null?String(t.key):null;m&&((w=l.$cmpCtx$)==null||w.$id$,x+=" q:sref="+l.$cmpCtx$.$id$),$!=null&&(x+=" q:key="+$),x+="-->",o.write(x);const y=t.props[ht];if(y)return o.write(y),void o.write(Ml);if(a)for(const D of a)fn(D.type,D.props,o);const P=Rr(t.children,l,r,o,c);return X(P,()=>{var v;if(!m&&!p)return void o.write(Ml);let D;if(m){const L=(v=r.$projectedChildren$)==null?void 0:v[$];if(L){const[k,T]=r.$projectedCtxs$,I=Ba(k);I.$slotCtx$=e,r.$projectedChildren$[$]=void 0,D=jt(L,I,T,o,c)}}return p&&(D=X(D,()=>p(o))),X(D,()=>{o.write(Ml)})})},Ml="<!--/qv-->",lu=t=>{let e="";for(const a in t){if(a===ht)continue;const l=t[a];l!=null&&(e+=" "+(l===""?a:a+'="'+l+'"'))}return e},nu=t=>{let e="";for(const a in t){if(a==="children"||a===ht)continue;const l=t[a];l!=null&&(e+=" "+(l===""?a:a+"="+l))}return e},fn=(t,e,a)=>{if(a.write("<"+t+lu(e)+">"),Qr[t])return;const l=e[ht];l!=null&&a.write(l),a.write(`</${t}>`)},su=(t,e,a,l,r,o,c)=>(iu(t,l,r.props.props),X(Ya(t,l),p=>{const d=l.$element$,f=p.rCtx,x=_t(e.$static$.$locale$,d,void 0);x.$subscriber$=[0,d],x.$renderCtx$=f;const m={$static$:e.$static$,$projectedChildren$:ru(r.children,e),$projectedCtxs$:[t,e],$invocationContext$:x},$=[];if(l.$appendStyles$){const D=4&o?e.$static$.$headNodes$:$;for(const v of l.$appendStyles$)D.push(n("style",{[gl]:v.styleId,[ht]:v.content,hidden:""},null,null,0,null))}const y=wa(t),P=l.$scopeIds$?Mr(l.$scopeIds$):void 0,w=i(r.type,{[Ao]:P,[Eo]:y,children:p.node},0,r.key);return l.$id$=y,e.$static$.$contexts$.push(l),qr(w,l,$,f,m,a,o,D=>{if(l.$flags$&Re){const k=Ka(1),T=k.li;T.push(...l.li),l.$flags$&=~Re,k.$id$=wa(t);const I={type:"placeholder",hidden:"","q:id":k.$id$};e.$static$.$contexts$.push(k);const E=sn(T);for(const N of E){const j=Gr(N[0]);I[j]=Nn(N[1],t.$static$.$containerState$,k),Il(j,t.$static$.$containerState$)}fn("script",I,D)}const v=m.$projectedChildren$;let L;if(v){const k=Object.keys(v).map(N=>{const j=v[N];if(j)return n("q:template",{[Pt]:N||!0,hidden:!0,"aria-hidden":"true"},null,j,0,null)}),[T,I]=m.$projectedCtxs$,E=Ba(T);E.$slotCtx$=l,L=jt(k,E,I,D,0,void 0)}return c?X(L,()=>c(D)):L})})),ru=(t,e)=>{const a=zr(t,e);if(a===null)return;const l={};for(const r of a){let o="";ta(r)&&(o=r.props[Pt]||""),(l[o]||(l[o]=[])).push(r)}return l},Ka=t=>{const e=new Or(t);return vl(e)},gn=(t,e,a,l,r,o)=>{var f;const c=t.type,p=e.$cmpCtx$;if(typeof c=="string"){const x=t.key,m=t.props,$=t.immutableProps||ft,y=Ka(1),P=y.$element$,w=c==="head";let D="<"+c,v=!1,L=!1,k="",T=null;const I=(j,O,W)=>{if(j==="ref")return void(O!==void 0&&(Pn(O,P),L=!0));if(nn(j))return void rn(y.li,j,O,void 0);if(mt(O)&&(O=Gt(O,W?[1,P,O,p.$element$,j]:[2,p.$element$,O,P,j]),v=!0),j===ht)return void(T=O);let K;j.startsWith(Lr)&&Il(j.slice(15),e.$static$.$containerState$);const Y=j==="htmlFor"?"for":j;Y==="class"||Y==="className"?k=Za(O):Y==="style"?K=bl(O):Nr(Y)||Y==="draggable"||Y==="spellcheck"?(K=O!=null?String(O):null,O=K):K=O===!1||O==null?null:String(O),K!=null&&(Y==="value"&&c==="textarea"?T=ra(K):pu(Y)||(D+=" "+(O===!0?Y:Y+'="'+ra(K)+'"')))};for(const j in m){let O=!1,W;j in $?(O=!0,W=$[j],W===s&&(W=m[j])):W=m[j],I(j,W,O)}for(const j in $){if(j in m)continue;const O=$[j];O!==s&&I(j,O,!0)}const E=y.li;if(p){if((f=p.$scopeIds$)!=null&&f.length){const j=p.$scopeIds$.join(" ");k=k?`${j} ${k}`:j}p.$flags$&Re&&(E.push(...p.li),p.$flags$&=~Re)}if(w&&(r|=1),c in ou&&(r|=16),c in uu&&(r|=8),k&&(D+=' class="'+ra(k)+'"'),E.length>0){const j=sn(E),O=!!(16&r);for(const W of j){const K=O?Gr(W[0]):W[0];D+=" "+K+'="'+Nn(W[1],e.$static$.$containerState$,y)+'"',Il(K,e.$static$.$containerState$)}}if(x!=null&&(D+=' q:key="'+ra(x)+'"'),L||v||E.length>0){if(L||v||fu(E)){const j=wa(e);D+=' q:id="'+j+'"',y.$id$=j}a.$static$.$contexts$.push(y)}if(1&r&&(D+=" q:head"),D+=">",l.write(D),c in Qr)return;if(T!=null)return l.write(String(T)),void l.write(`</${c}>`);c==="html"?r|=4:r&=-5,2&t.flags&&(r|=1024);const N=jt(t.children,e,a,l,r);return X(N,()=>{if(w){for(const j of a.$static$.$headNodes$)fn(j.type,j.props,l);a.$static$.$headNodes$.length=0}if(o)return X(o(l),()=>{l.write(`</${c}>`)});l.write(`</${c}>`)})}if(c===Oe){const x=Ka(111);return e.$slotCtx$?(x.$parentCtx$=e.$slotCtx$,x.$realParentCtx$=e.$cmpCtx$):x.$parentCtx$=e.$cmpCtx$,p&&p.$flags$&wn&&gu(p,x),qr(t,x,void 0,e,a,l,r,o)}if(c===Hr)return void l.write(t.props.data);if(c===Vr)return au(t,e,a,l,r);const d=xt(a.$invocationContext$,c,t.props,t.key,t.flags,t.dev);return Ir(d,t)?gn(i(Oe,{children:d},0,t.key),e,a,l,r,o):jt(d,e,a,l,r,o)},jt=(t,e,a,l,r,o)=>{var c;if(t!=null&&typeof t!="boolean"){if(!Be(t)&&typeof t!="number"){if(ta(t))return gn(t,e,a,l,r,o);if(lt(t))return Rr(t,e,a,l,r);if(mt(t)){const p=8&r,d=(c=e.$cmpCtx$)==null?void 0:c.$element$;let f;if(d){if(!p){const x=wa(e);if(f=Gt(t,1024&r?[3,"#"+x,t,"#"+x]:[4,d,t,"#"+x]),Be(f)){const m=Sa(f);a.$static$.$textNodes$.set(m,x)}return l.write(`<!--t=${x}-->`),jt(f,e,a,l,r,o),void l.write("<!---->")}f=xt(a.$invocationContext$,()=>t.value)}return void l.write(ra(Sa(f)))}return ct(t)?(l.write(Ua),t.then(p=>jt(p,e,a,l,r,o))):void Ie()}l.write(ra(String(t)))}},Rr=(t,e,a,l,r)=>{if(t==null)return;if(!lt(t))return jt(t,e,a,l,r);const o=t.length;if(o===1)return jt(t[0],e,a,l,r);if(o===0)return;let c=0;const p=[];return t.reduce((d,f,x)=>{const m=[];p.push(m);const $=jt(f,e,a,d?{write(y){c===x?l.write(y):m.push(y)}}:l,r);if(d||ct($)){const y=()=>{c++,p.length>c&&p[c].forEach(P=>l.write(P))};return ct($)?d?Promise.all([$,d]).then(y):$.then(y):d.then(y)}c++},void 0)},zr=(t,e)=>{if(t==null)return null;const a=Fr(t,e),l=lt(a)?a:[a];return l.length===0?null:l},Fr=(t,e)=>{if(t==null)return null;if(lt(t))return t.flatMap(a=>Fr(a,e));if(ta(t)&&vt(t.type)&&t.type!==Hr&&t.type!==Vr&&t.type!==Oe){const a=xt(e.$invocationContext$,t.type,t.props,t.key,t.flags);return zr(a,e)}return t},iu=(t,e,a)=>{const l=Object.keys(a),r=ml();if(e.$props$=Ia(r,t.$static$.$containerState$),l.length===0)return;const o=r[s]=a[s]??ft;for(const c of l)c!=="children"&&c!==Pt&&(mt(o[c])?r["$$"+c]=o[c]:r[c]=a[c])},ou={head:!0,style:!0,script:!0,link:!0,meta:!0},uu={title:!0,style:!0,script:!0,noframes:!0,textarea:!0},Qr={area:!0,base:!0,basefont:!0,bgsound:!0,br:!0,col:!0,embed:!0,frame:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0},cu=/[&<>'"]/g,Il=(t,e)=>{e.$events$.add(ui(t))},ra=t=>t.replace(cu,e=>{switch(e){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";case'"':return"&quot;";case"'":return"&#39;";default:return""}}),du=/[>/="'\u0009\u000a\u000c\u0020]/,pu=t=>du.test(t),fu=t=>t.some(e=>e[1].$captureRef$&&e[1].$captureRef$.length>0),gu=(t,e)=>{const a=t.$dynamicSlots$||(t.$dynamicSlots$=[]);a.includes(e)||a.push(e)},Gr=t=>t==="on:qvisible"?"on-document:qinit":t,u=(t,e,a)=>new ql(t,e,a),xu=t=>{const e=t.$funcStr$;let a="";for(let l=0;l<t.$args$.length;l++)a+=`p${l},`;return`(${a})=>(${e})`},n=(t,e,a,l,r,o)=>{const c=o==null?null:String(o);return new xa(t,e||ft,a,l,r,c)},Z=(t,e,a,l,r,o)=>{let c=null;return e&&"children"in e&&(c=e.children,delete e.children),n(t,e,a,c,l,r)},i=(t,e,a,l,r)=>{const o=l==null?null:String(l),c=e??{};if(typeof t=="string"&&s in c){const d=c[s];delete c[s];const f=c.children;delete c.children;for(const[x,m]of Object.entries(d))m!==s&&(delete c[x],c[x]=m);return n(t,null,c,f,a,l)}const p=new xa(t,c,null,c.children,a,o);return typeof t=="string"&&e&&delete e.children,p},F_=(t,e,a)=>{const r=ya(()=>{const c=e.children;return typeof t=="string"&&delete e.children,c});return Be(t)&&"className"in e&&(e.class=e.className,delete e.className),new xa(t,e,null,r,0,null)};class xa{constructor(e,a,l,r,o,c=null){this.type=e,this.props=a,this.immutableProps=l,this.children=r,this.flags=o,this.key=c}}const Oe=t=>t.children,ta=t=>t instanceof xa,G=t=>t.children,xn=Symbol("skip render"),Hr=()=>null,Vr=()=>null,mn=(t,e,a)=>{const l=!(e.$flags$&_n),r=e.$element$,o=t.$static$.$containerState$;return o.$hostsStaging$.delete(e),o.$subsManager$.$clearSub$(r),X(Ya(t,e),c=>{const p=t.$static$,d=c.rCtx,f=_t(t.$static$.$locale$,r);if(p.$hostElements$.add(r),f.$subscriber$=[0,r],f.$renderCtx$=d,l&&e.$appendStyles$)for(const m of e.$appendStyles$)wc(p,m);const x=qe(c.node,f);return X(x,m=>{const $=mu(r,m),y=hn(e);return X(al(d,y,$,a),()=>{e.$vdom$=$})})})},hn=t=>(t.$vdom$||(t.$vdom$=ll(t.$element$)),t.$vdom$);class Qt{constructor(e,a,l,r,o,c){this.$type$=e,this.$props$=a,this.$immutableProps$=l,this.$children$=r,this.$flags$=o,this.$key$=c,this.$elm$=null,this.$text$="",this.$signal$=null,this.$id$=e+(c?":"+c:"")}}const Wr=(t,e)=>{const{key:a,type:l,props:r,children:o,flags:c,immutableProps:p}=t;let d="";if(Be(l))d=l;else{if(l!==Oe){if(vt(l)){const x=xt(e,l,r,a,c,t.dev);return Ir(x,t)?Wr(i(Oe,{children:x},0,a),e):qe(x,e)}throw ot(25,l)}d=pa}let f=Ft;return o!=null?X(qe(o,e),x=>(x!==void 0&&(f=lt(x)?x:[x]),new Qt(d,r,p,f,c,a))):new Qt(d,r,p,f,c,a)},mu=(t,e)=>{const a=e===void 0?Ft:lt(e)?e:[e],l=new Qt(":virtual",{},null,a,0,null);return l.$elm$=t,l},qe=(t,e)=>{if(t!=null&&typeof t!="boolean"){if(Ur(t)){const a=new Qt("#text",ft,null,Ft,0,null);return a.$text$=String(t),a}if(ta(t))return Wr(t,e);if(mt(t)){const a=new Qt("#signal",ft,null,Ft,0,null);return a.$signal$=t,a}if(lt(t)){const a=an(t.flatMap(l=>qe(l,e)));return X(a,l=>l.flat(100).filter(Tr))}return ct(t)?t.then(a=>qe(a,e)):t===xn?new Qt(":skipRender",ft,null,Ft,0,null):void Ie()}},Ur=t=>Be(t)||typeof t=="number",Yr=t=>{Nt(t,"q:container")==="paused"&&($u(t),Su(t))},hu=t=>{const e=Na(t),a=_u(t===e.documentElement?e.body:t,"type");if(a)return JSON.parse(yu(a.firstChild.data)||"{}")},bu=(t,e)=>{const a=JSON.parse(t);if(typeof a!="object")return null;const{_objs:l,_entry:r}=a;if(l===void 0||r===void 0)return null;let o={},c={};if(Qe(e)&&He(e)){const f=Tn(e);f&&(c=ma(f),o=f.ownerDocument)}const p=ki(c,o);for(let f=0;f<l.length;f++){const x=l[f];Be(x)&&(l[f]=x===wl?void 0:p.prepare(x))}const d=f=>l[Ot(f)];for(const f of l)Zr(f,d,p);return d(r)},$u=t=>{if(!nc(t))return void Ie();const e=t._qwikjson_??hu(t);if(t._qwikjson_=null,!e)return void Ie();const a=Na(t),l=t.getAttribute(Pr),r=kr(a,l),o=ma(t),c=new Map,p=new Map;let d=null,f=0;const x=a.createTreeWalker(t,oi);for(;d=x.nextNode();){const v=d.data;if(f===0){if(v.startsWith("qv ")){const L=Tu(v);L>=0&&c.set(L,d)}else if(v.startsWith("t=")){const L=v.slice(2),k=Ot(L),T=wu(d);c.set(k,T),p.set(k,T.data)}}v==="cq"?f++:v==="/cq"&&f--}const m=t.getElementsByClassName("qc📦").length!==0;t.querySelectorAll("[q\\:id]").forEach(v=>{if(m&&v.closest("[q\\:container]")!==t)return;const L=Nt(v,"q:id"),k=Ot(L);c.set(k,v)});const $=ki(o,a),y=new Map,P=new Set,w=v=>(typeof v=="string"&&v.length>0,y.has(v)?y.get(v):D(v)),D=v=>{if(v.startsWith("#")){const E=v.slice(1),N=Ot(E);c.has(N);const j=c.get(N);if(Aa(j)){if(!j.isConnected)return void y.set(v,void 0);const O=Ra(j);return y.set(v,O),yt(O,o),O}return Ge(j)?(y.set(v,j),yt(j,o),j):(y.set(v,j),j)}if(v.startsWith("@")){const E=v.slice(1),N=Ot(E);return r[N]}if(v.startsWith("*")){const E=v.slice(1),N=Ot(E);c.has(N);const j=p.get(N);return y.set(v,j),j}const L=Ot(v),k=e.objs;k.length>L;let T=k[L];Be(T)&&(T=T===wl?void 0:$.prepare(T));let I=T;for(let E=v.length-1;E>=0;E--){const N=kd[v[E]];if(!N)break;I=N(I,o)}return y.set(v,I),Ur(T)||P.has(L)||(P.add(L),vu(T,L,e.subs,w,o,$),Zr(T,w,$)),I};o.$elementIndex$=1e5,o.$pauseCtx$={getObject:w,meta:e.ctx,refs:e.refs},Tt(t,"q:container","resumed"),zo(t,"qresume",void 0,!0)},vu=(t,e,a,l,r,o)=>{const c=a[e];if(c){const p=[];let d=0;for(const f of c)if(f.startsWith("_"))d=parseInt(f.slice(1),10);else{const x=Ed(f,l);x&&p.push(x)}if(d>0&&hl(t,d),!o.subs(t,p)){const f=r.$proxyMap$.get(t);f?$t(f).$addSubs$(p):Ia(t,r,p)}}},Zr=(t,e,a)=>{if(!a.fill(t,e)&&t&&typeof t=="object"){if(lt(t))for(let l=0;l<t.length;l++)t[l]=e(t[l]);else if(Ea(t))for(const l in t)t[l]=e(t[l])}},yu=t=>t.replace(/\\x3C(\/?script)/gi,"<$1"),_u=(t,e)=>{let a=t.lastElementChild;for(;a;){if(a.tagName==="SCRIPT"&&Nt(a,e)==="qwik/json")return a;a=a.previousElementSibling}},wu=t=>{const e=t.nextSibling;if(Jl(e))return e;{const a=t.ownerDocument.createTextNode("");return t.parentElement.insertBefore(a,t),a}},Su=t=>{t.qwik={pause:()=>qc(t),state:ma(t)}},Tu=t=>{const e=t.indexOf("q:id=");return e>0?Ot(t.slice(e+5)):-1},U=()=>{const t=Zu();let e=t.$qrl$;if(e)e.$captureRef$;else{const a=t.$element$,l=Tn(a);e=_l(decodeURIComponent(String(t.$url$)),l),Yr(l);const r=yt(a,ma(l));Di(e,r)}return e.$captureRef$},Du=(t,e)=>{try{const a=e[0],l=t.$static$;switch(a){case 1:case 2:{let r,o;a===1?(r=e[1],o=e[3]):(r=e[3],o=e[1]);const c=kt(r);if(c==null)return;const p=e[4],d=r.namespaceURI===qa;l.$containerState$.$subsManager$.$clearSignal$(e);let f=Gt(e[2],e.slice(0,-1));p==="class"?f=pn(f,kt(o)):p==="style"&&(f=bl(f));const x=hn(c);return p in x.$props$&&x.$props$[p]===f?void 0:(x.$props$[p]=f,Ln(l,r,p,f,d))}case 3:case 4:{const r=e[3];if(!l.$visited$.includes(r)){l.$containerState$.$subsManager$.$clearSignal$(e);const o=void 0;let c=Gt(e[2],e.slice(0,-1));const p=Bd();Array.isArray(c)&&(c=new xa(Oe,{},null,c,0,null));let d=qe(c,o);if(ct(d))Ke("Rendering promises in JSX signals is not supported");else{d===void 0&&(d=qe("",o));const f=di(r),x=Pu(e[1]);if(t.$cmpCtx$=yt(x,t.$static$.$containerState$),f.$type$==d.$type$&&f.$key$==d.$key$&&f.$id$==d.$id$)la(t,f,d,0);else{const m=[],$=f.$elm$,y=Ye(t,d,0,m);m.length&&Ke("Rendering promises in JSX signals is not supported"),p[3]=y,oa(t.$static$,r.parentElement,y,$),$&&Mn(l,$)}}}}}}catch{}};function Pu(t){for(;t;){if(He(t))return t;t=t.parentElement}throw new Error("Not found")}const ku=(t,e)=>{if(t[0]===0){const a=t[1];yn(a)?bn(a,e):Lu(a,e)}else Cu(t,e)},Lu=(t,e)=>{const a=Dt();a||Yr(e.$containerEl$);const l=yt(t,e);if(l.$componentQrl$,!(l.$flags$&da))if(l.$flags$|=da,e.$hostsRendering$!==void 0)e.$hostsStaging$.add(l);else{if(a)return void Ie();e.$hostsNext$.add(l),$n(e)}},Cu=(t,e)=>{const a=e.$hostsRendering$!==void 0;e.$opsNext$.add(t),a||$n(e)},bn=(t,e)=>{t.$flags$&Je||(t.$flags$|=Je,e.$hostsRendering$!==void 0?e.$taskStaging$.add(t):(e.$taskNext$.add(t),$n(e)))},$n=t=>(t.$renderPromise$===void 0&&(t.$renderPromise$=pl().nextTick(()=>Kr(t))),t.$renderPromise$),Mu=()=>{const[t]=U();bn(t,ma(Tn(t.$el$)))},Kr=async t=>{const e=t.$containerEl$,a=Na(e);try{const l=Ar(a,t),r=l.$static$,o=t.$hostsRendering$=new Set(t.$hostsNext$);t.$hostsNext$.clear(),await Au(t,l),t.$hostsStaging$.forEach(d=>{o.add(d)}),t.$hostsStaging$.clear();const c=Array.from(t.$opsNext$);t.$opsNext$.clear();const p=Array.from(o);Iu(p),!t.$styleMoved$&&p.length>0&&(t.$styleMoved$=!0,(e===a.documentElement?a.body:e).querySelectorAll("style[q\\:style]").forEach(d=>{t.$styleIds$.add(Nt(d,gl)),$i(r,a.head,d)}));for(const d of p){const f=d.$element$;if(!r.$hostElements$.has(f)&&d.$componentQrl$){f.isConnected,r.$roots$.push(d);try{await mn(l,d,ju(f.parentElement))}catch(x){Ke(x)}}}return c.forEach(d=>{Du(l,d)}),r.$operations$.push(...r.$postOperations$),r.$operations$.length===0?(sr(r),void await Zs(t,l)):(await mc(r),sr(r),Zs(t,l))}catch(l){Ke(l)}},ju=t=>{let e=0;return t&&(t.namespaceURI===qa&&(e|=St),t.tagName==="HEAD"&&(e|=tl)),e},Zs=async(t,e)=>{const a=e.$static$.$hostElements$;await Nu(t,e,(l,r)=>!!(l.$flags$&Jr)&&(!r||a.has(l.$el$))),t.$hostsStaging$.forEach(l=>{t.$hostsNext$.add(l)}),t.$hostsStaging$.clear(),t.$hostsRendering$=void 0,t.$renderPromise$=void 0,t.$hostsNext$.size+t.$taskNext$.size+t.$opsNext$.size>0&&(t.$renderPromise$=Kr(t))},Bl=t=>!!(t.$flags$&Xr),Ks=t=>!!(t.$flags$&ti),Au=async(t,e)=>{const a=t.$containerEl$,l=[],r=[];t.$taskNext$.forEach(o=>{Bl(o)&&(r.push(X(o.$qrl$.$resolveLazy$(a),()=>o)),t.$taskNext$.delete(o)),Ks(o)&&(l.push(X(o.$qrl$.$resolveLazy$(a),()=>o)),t.$taskNext$.delete(o))});do if(t.$taskStaging$.forEach(o=>{Bl(o)?r.push(X(o.$qrl$.$resolveLazy$(a),()=>o)):Ks(o)?l.push(X(o.$qrl$.$resolveLazy$(a),()=>o)):t.$taskNext$.add(o)}),t.$taskStaging$.clear(),r.length>0){const o=await Promise.all(r);Ja(o),await Promise.all(o.map(c=>Xa(c,t,e))),r.length=0}while(t.$taskStaging$.size>0);if(l.length>0){const o=await Promise.all(l);Ja(o);for(const c of o)Xa(c,t,e)}},Eu=(t,e)=>{const a=t.$containerEl$,l=t.$taskStaging$;if(!l.size)return;const r=[];let o=20;const c=()=>{if(l.forEach(p=>{Bl(p)&&r.push(X(p.$qrl$.$resolveLazy$(a),()=>p))}),l.clear(),r.length>0)return Promise.all(r).then(async p=>{if(Ja(p),await Promise.all(p.map(d=>Xa(d,t,e))),r.length=0,--o&&l.size>0)return c();o||Ie(`Infinite task loop detected. Tasks:
${Array.from(l).map(d=>`  ${d.$qrl$.$symbol$}`).join(`
`)}`)})};return c()},Nu=async(t,e,a)=>{const l=[],r=t.$containerEl$;t.$taskNext$.forEach(o=>{a(o,!1)&&(o.$el$.isConnected&&l.push(X(o.$qrl$.$resolveLazy$(r),()=>o)),t.$taskNext$.delete(o))});do if(t.$taskStaging$.forEach(o=>{o.$el$.isConnected&&(a(o,!0)?l.push(X(o.$qrl$.$resolveLazy$(r),()=>o)):t.$taskNext$.add(o))}),t.$taskStaging$.clear(),l.length>0){const o=await Promise.all(l);Ja(o);for(const c of o)Xa(c,t,e);l.length=0}while(t.$taskStaging$.size>0)},Iu=t=>{t.sort((e,a)=>2&e.$element$.compareDocumentPosition(sl(a.$element$))?1:-1)},Ja=t=>{const e=Dt();t.sort((a,l)=>e||a.$el$===l.$el$?a.$index$<l.$index$?-1:1:2&a.$el$.compareDocumentPosition(sl(l.$el$))?1:-1)},Bu=t=>{const e=Ku(),a=vt(t)&&!On(t)?xt(void 0,t):t;return ac(a,e,0)},Ou=t=>{const{val:e,set:a}=Xe();return e??a(t=vt(t)&&!On(t)?t():t)},C=t=>Ou(()=>Bu(t)),Jr=1,Xr=2,ti=4,Je=16,vn=(t,e)=>{const{val:a,set:l,iCtx:r,i:o,elCtx:c}=Xe();if(a)return;const p=r.$renderCtx$.$static$.$containerState$,d=new $l(Je|Xr,o,c.$element$,t,void 0);l(!0),t.$resolveLazy$(p.$containerEl$),c.$tasks$||(c.$tasks$=[]),c.$tasks$.push(d),Xu(r,()=>ai(d,p,r.$renderCtx$)),Dt()&&Ol(d,e==null?void 0:e.eagerness)},wt=(t,e)=>{const{val:a,set:l,i:r,iCtx:o,elCtx:c}=Xe(),p=(e==null?void 0:e.strategy)??"intersection-observer";if(a)return void(Dt()&&Ol(a,p));const d=new $l(Jr,r,c.$element$,t,void 0),f=o.$renderCtx$.$static$.$containerState$;c.$tasks$||(c.$tasks$=[]),c.$tasks$.push(d),l(d),Ol(d,p),Dt()||(t.$resolveLazy$(f.$containerEl$),bn(d,f))},ei=t=>!!(t.$flags$&ti),qu=t=>!!(8&t.$flags$),Xa=async(t,e,a)=>(t.$flags$&Je,ei(t)?Ru(t,e,a):qu(t)?zu(t,e,a):ai(t,e,a)),Ru=(t,e,a,l)=>{t.$flags$&=~Je,Ta(t);const r=_t(a.$static$.$locale$,t.$el$,void 0,"qTask"),{$subsManager$:o}=e;r.$renderCtx$=a;const c=t.$qrl$.getFn(r,()=>{o.$clearSub$(t)}),p=[],d=t.$state$,f=za(d),x={track:(v,L)=>{if(vt(v)){const T=_t();return T.$renderCtx$=a,T.$subscriber$=[0,t],xt(T,v)}const k=$t(v);return k?k.$addSub$([0,t],L):Xl(dl(26),v),L?v[L]:mt(v)?v.value:v},cleanup(v){p.push(v)},cache(v){let L=0;L=v==="immutable"?1/0:v,d._cache=L},previous:f._resolved};let m,$,y=!1;const P=(v,L)=>!y&&(y=!0,v?(y=!0,d.loading=!1,d._state="resolved",d._resolved=L,d._error=void 0,m(L)):(y=!0,d.loading=!1,d._state="rejected",d._error=L,$(L)),!0);xt(r,()=>{d._state="pending",d.loading=!Dt(),d.value=new Promise((v,L)=>{m=v,$=L})}),t.$destroy$=Tl(()=>{y=!0,p.forEach(v=>v())});const w=fl(()=>X(l,()=>c(x)),v=>{P(!0,v)},v=>{P(!1,v)}),D=f._timeout;return D>0?Promise.race([w,Mo(D).then(()=>{P(!1,new Error("timeout"))&&Ta(t)})]):w},ai=(t,e,a)=>{t.$flags$&=~Je,Ta(t);const l=t.$el$,r=_t(a.$static$.$locale$,l,void 0,"qTask");r.$renderCtx$=a;const{$subsManager$:o}=e,c=t.$qrl$.getFn(r,()=>{o.$clearSub$(t)}),p=[];t.$destroy$=Tl(()=>{p.forEach(f=>f())});const d={track:(f,x)=>{if(vt(f)){const $=_t();return $.$subscriber$=[0,t],xt($,f)}const m=$t(f);return m?m.$addSub$([0,t],x):Xl(dl(26),f),x?f[x]:mt(f)?f.value:f},cleanup(f){p.push(f)}};return fl(()=>c(d),f=>{vt(f)&&p.push(f)},f=>{dn(f,l,a)})},zu=(t,e,a)=>{t.$state$,t.$flags$&=~Je,Ta(t);const l=t.$el$,r=_t(a.$static$.$locale$,l,void 0,"qComputed");r.$subscriber$=[0,t],r.$renderCtx$=a;const{$subsManager$:o}=e,c=t.$qrl$.getFn(r,()=>{o.$clearSub$(t)});return fl(c,p=>ya(()=>{const d=t.$state$;d[Da]&=~ri,d.untrackedValue=p,d[qt].$notifySubs$()}),p=>{dn(p,l,a)})},Ta=t=>{const e=t.$destroy$;if(e){t.$destroy$=void 0;try{e()}catch(a){Ke(a)}}},li=t=>{32&t.$flags$?(t.$flags$&=-33,(0,t.$qrl$)()):Ta(t)},Ol=(t,e)=>{e==="visible"||e==="intersection-observer"?qo("qvisible",jl(t)):e==="load"||e==="document-ready"?Ys("qinit",jl(t)):e!=="idle"&&e!=="document-idle"||Ys("qidle",jl(t))},jl=t=>{const e=t.$qrl$,a=Fa(e.$chunk$,"_hW",Mu,null,null,[t],e.$symbol$);return e.dev&&(a.dev=e.dev),a},yn=t=>Ht(t)&&t instanceof $l,Fu=(t,e)=>{let a=`${ze(t.$flags$)} ${ze(t.$index$)} ${e(t.$qrl$)} ${e(t.$el$)}`;return t.$state$&&(a+=` ${e(t.$state$)}`),a},Qu=t=>{const[e,a,l,r,o]=t.split(" ");return new $l(Ot(e),Ot(a),r,l,o)};class $l{constructor(e,a,l,r,o){this.$flags$=e,this.$index$=a,this.$el$=l,this.$qrl$=r,this.$state$=o}}function Gu(t){return Hu(t)&&t.nodeType===1}function Hu(t){return t&&typeof t.nodeType=="number"}const da=1,Re=2,_n=4,wn=8,kt=t=>t[xl],yt=(t,e)=>{const a=kt(t);if(a)return a;const l=vl(t),r=Nt(t,"q:id");if(r){const o=e.$pauseCtx$;if(l.$id$=r,o){const{getObject:c,meta:p,refs:d}=o;if(Gu(t)){const f=d[r];f&&(l.$refMap$=f.split(" ").map(c),l.li=Oo(l,e.$containerEl$))}else{const f=t.getAttribute("q:sstyle");l.$scopeIds$=f?f.split("|"):null;const x=p[r];if(x){const m=x.s,$=x.h,y=x.c,P=x.w;if(m&&(l.$seq$=m.split(" ").map(c)),P&&(l.$tasks$=P.split(" ").map(c)),y){l.$contexts$=new Map;for(const w of y.split(" ")){const[D,v]=w.split("=");l.$contexts$.set(D,c(v))}}if($){const[w,D]=$.split(" ");if(l.$flags$=_n,w&&(l.$componentQrl$=c(w)),D){const v=c(D);l.$props$=v,hl(v,2),v[s]=Vu(v)}else l.$props$=Ia(ml(),e)}}}}}return l},Vu=t=>{const e={},a=ea(t);for(const l in a)l.startsWith("$$")&&(e[l.slice(2)]=a[l]);return e},vl=t=>{const e={$flags$:0,$id$:"",$element$:t,$refMap$:[],li:[],$tasks$:null,$seq$:null,$slots$:null,$scopeIds$:null,$appendStyles$:null,$props$:null,$vdom$:null,$componentQrl$:null,$contexts$:null,$dynamicSlots$:null,$parentCtx$:void 0,$realParentCtx$:void 0};return t[xl]=e,e},Wu=(t,e)=>{var a;(a=t.$tasks$)==null||a.forEach(l=>{e.$clearSub$(l),li(l)}),t.$componentQrl$=null,t.$seq$=null,t.$tasks$=null};let ua;function Uu(t){if(ua===void 0){const e=bt();return e&&e.$locale$?e.$locale$:t}return ua}function Js(t,e){const a=ua;try{return ua=t,e()}finally{ua=a}}function Yu(t){ua=t}let va;const bt=()=>{if(!va){const t=typeof document<"u"&&document&&document.__q_context__;return t?lt(t)?document.__q_context__=ni(t):t:void 0}return va},Zu=()=>{const t=bt();if(!t)throw ot(14);return t},Sn=()=>{const t=bt();if(!t||t.$event$!=="qRender")throw ot(20);return t.$hostElement$,t.$waitOn$,t.$renderCtx$,t.$subscriber$,t},Ku=()=>Sn().$renderCtx$.$static$.$containerState$;function xt(t,e,...a){return Ju.call(this,t,e,a)}function Ju(t,e,a){const l=va;let r;try{va=t,r=e.apply(this,a)}finally{va=l}return r}const Xu=(t,e)=>{const a=t.$waitOn$;if(a.length===0){const l=e();ct(l)&&a.push(l)}else a.push(Promise.all(a).then(e))},ni=([t,e,a])=>{const l=t.closest("[q\\:container]"),r=(l==null?void 0:l.getAttribute("q:locale"))||void 0;return r&&Yu(r),_t(r,void 0,t,e,a)},_t=(t,e,a,l,r)=>({$url$:r,$i$:0,$hostElement$:e,$element$:a,$event$:l,$qrl$:void 0,$waitOn$:void 0,$subscriber$:void 0,$renderCtx$:void 0,$locale$:t||(typeof l=="object"&&l&&"locale"in l?l.locale:void 0)}),Tn=t=>t.closest("[q\\:container]"),ya=t=>xt(void 0,t),Xs=_t(void 0,void 0,void 0,"qRender"),Gt=(t,e)=>(Xs.$subscriber$=e,xt(Xs,()=>t.value)),tc=()=>{var e;const t=bt();if(t)return t.$element$??t.$hostElement$??((e=t.$qrl$)==null?void 0:e.$setContainer$(void 0))},ec=()=>{const t=bt();if(t)return t.$event$},z=t=>{const e=bt();return e&&e.$hostElement$&&e.$renderCtx$&&(yt(e.$hostElement$,e.$renderCtx$.$static$.$containerState$).$flags$|=wn),t};var si;const ac=(t,e,a,l)=>{const r=e.$subsManager$.$createManager$(l);return new Pa(t,r,a)},Da=Symbol("proxy manager"),lc=1,ri=2,ii=Symbol("unassigned signal");class Oa{}class Pa extends Oa{constructor(e,a,l){super(),this[si]=0,this.untrackedValue=e,this[qt]=a,this[Da]=l}valueOf(){}toString(){return`[Signal ${String(this.value)}]`}toJSON(){return{value:this.value}}get value(){var a;if(this[Da]&ri)throw ii;const e=(a=bt())==null?void 0:a.$subscriber$;return e&&this[qt].$addSub$(e),this.untrackedValue}set value(e){const a=this[qt];a&&this.untrackedValue!==e&&(this.untrackedValue=e,a.$notifySubs$())}}si=Da;class ql extends Oa{constructor(e,a,l){super(),this.$func$=e,this.$args$=a,this.$funcStr$=l}get value(){return this.$func$.apply(void 0,this.$args$)}}class Rl extends Oa{constructor(e,a){super(),this.ref=e,this.prop=a}get[qt](){return $t(this.ref)}get value(){return this.ref[this.prop]}set value(e){this.ref[this.prop]=e}}const mt=t=>t instanceof Oa,h=(t,e)=>{var r,o;if(!Ht(t))return t[e];if(t instanceof Oa)return t;const a=ea(t);if(a){const c=a["$$"+e];if(c)return c;if(((r=a[s])==null?void 0:r[e])!==!0)return new Rl(t,e)}const l=(o=t[s])==null?void 0:o[e];return mt(l)?l:s},S=(t,e)=>{const a=h(t,e);return a===s?t[e]:a},tr=Symbol("ContainerState"),ma=t=>{let e=t[tr];return e||(t[tr]=e=Dn(t,Nt(t,"q:base")??"/")),e},Dn=(t,e)=>{const a={};if(t){const r=t.attributes;if(r)for(let o=0;o<r.length;o++){const c=r[o];a[c.name]=c.value}}const l={$containerEl$:t,$elementIndex$:0,$styleMoved$:!1,$proxyMap$:new WeakMap,$opsNext$:new Set,$taskNext$:new Set,$taskStaging$:new Set,$hostsNext$:new Set,$hostsStaging$:new Set,$styleIds$:new Set,$events$:new Set,$serverData$:{containerAttributes:a},$base$:e,$renderPromise$:void 0,$hostsRendering$:void 0,$pauseCtx$:void 0,$subsManager$:null,$inlineFns$:new Map};return l.$subsManager$=Nd(l),l},Pn=(t,e)=>{if(vt(t))return t(e);if(mt(t))return Dt()?t.untrackedValue=e:t.value=e;throw ot(32,t)},oi=128,nc=t=>Ge(t)&&t.hasAttribute("q:container"),ze=t=>t.toString(36),Ot=t=>parseInt(t,36),ui=t=>{const e=t.indexOf(":");return t&&No(t.slice(e+1))},qa="http://www.w3.org/2000/svg",St=1,tl=2,el=[],al=(t,e,a,l)=>{e.$elm$;const r=a.$children$;if(r.length===1&&r[0].$type$===":skipRender")return void(a.$children$=e.$children$);const o=e.$elm$;let c=nl;e.$children$===el&&o.nodeName==="HEAD"&&(c=ic,l|=tl);const p=sc(e,c);return p.length>0&&r.length>0?rc(t,o,p,r,l):p.length>0&&r.length===0?kn(t.$static$,p,0,p.length-1):r.length>0?fi(t,o,null,r,0,r.length-1,l):void 0},sc=(t,e)=>{const a=t.$children$;return a===el?t.$children$=ci(t.$elm$,e):a},rc=(t,e,a,l,r)=>{let o=0,c=0,p=a.length-1,d=a[0],f=a[p],x=l.length-1,m=l[0],$=l[x],y,P,w;const D=[],v=t.$static$;for(;o<=p&&c<=x;)if(d==null)d=a[++o];else if(f==null)f=a[--p];else if(m==null)m=l[++c];else if($==null)$=l[--x];else if(d.$id$===m.$id$)D.push(la(t,d,m,r)),d=a[++o],m=l[++c];else if(f.$id$===$.$id$)D.push(la(t,f,$,r)),f=a[--p],$=l[--x];else if(d.$key$&&d.$id$===$.$id$)d.$elm$,f.$elm$,D.push(la(t,d,$,r)),_c(v,e,d.$elm$,f.$elm$),d=a[++o],$=l[--x];else if(f.$key$&&f.$id$===m.$id$)d.$elm$,f.$elm$,D.push(la(t,f,m,r)),oa(v,e,f.$elm$,d.$elm$),f=a[--p],m=l[++c];else{if(y===void 0&&(y=$c(a,o,p)),P=y[m.$key$],P===void 0){const k=Ye(t,m,r,D);oa(v,e,k,d==null?void 0:d.$elm$)}else if(w=a[P],w.$type$!==m.$type$){const k=Ye(t,m,r,D);X(k,T=>{oa(v,e,T,d==null?void 0:d.$elm$)})}else D.push(la(t,w,m,r)),a[P]=void 0,w.$elm$,oa(v,e,w.$elm$,d.$elm$);m=l[++c]}c<=x&&D.push(fi(t,e,l[x+1]==null?null:l[x+1].$elm$,l,c,x,r));let L=an(D);return o<=p&&(L=X(L,()=>{kn(v,a,o,p)})),L},ia=(t,e)=>{const a=zt(t)?t.close:null,l=[];let r=t.firstChild;for(;(r=jn(r))&&(e(r)&&l.push(r),r=r.nextSibling,r!==a););return l},ci=(t,e)=>ia(t,e).map(di),di=t=>{var e;return Ge(t)?((e=kt(t))==null?void 0:e.$vdom$)??ll(t):ll(t)},ll=t=>{if(He(t)){const e=new Qt(t.localName,{},null,el,0,Fl(t));return e.$elm$=t,e}if(Jl(t)){const e=new Qt(t.nodeName,ft,null,el,0,null);return e.$text$=t.data,e.$elm$=t,e}},ic=t=>{const e=t.nodeType;return e===1?t.hasAttribute("q:head"):e===111},zl=t=>t.nodeName==="Q:TEMPLATE",nl=t=>{const e=t.nodeType;if(e===3||e===111)return!0;if(e!==1)return!1;const a=t.nodeName;return a!=="Q:TEMPLATE"&&(a==="HEAD"?t.hasAttribute("q:head"):a!=="STYLE"||!t.hasAttribute(gl))},pi=t=>{const e={};for(const a of t){const l=oc(a);(e[l]??(e[l]=new Qt(pa,{[Dr]:""},null,[],0,l))).$children$.push(a)}return e},la=(t,e,a,l)=>{e.$type$,a.$type$,e.$key$,a.$key$,e.$id$,a.$id$;const r=e.$elm$,o=a.$type$,c=t.$static$,p=c.$containerState$,d=t.$cmpCtx$;if(a.$elm$=r,o==="#text"){c.$visited$.push(r);const $=a.$signal$;return $&&(a.$text$=Sa(Gt($,[4,d.$element$,$,r]))),void Fe(c,r,"data",a.$text$)}if(o==="#signal")return;const f=a.$props$,x=a.$flags$,m=yt(r,p);if(o!==pa){let $=!!(l&St);if($||o!=="svg"||(l|=St,$=!0),f!==ft){1&x||(m.li.length=0);const y=e.$props$;a.$props$=y;for(const P in f){let w=f[P];if(P!=="ref")if(nn(P)){const D=rn(m.li,P,w,p.$containerEl$);mi(c,r,D)}else mt(w)&&(w=Gt(w,[1,d.$element$,w,r,P])),P==="class"?w=pn(w,d):P==="style"&&(w=bl(w)),y[P]!==w&&(y[P]=w,Ln(c,r,P,w,$));else w!==void 0&&Pn(w,r)}}return 2&x||($&&o==="foreignObject"&&(l&=~St),f[ht]!==void 0)||o==="textarea"?void 0:al(t,e,a,l)}if("q:renderFn"in f){const $=f.props;xc(p,m,$);let y=!!(m.$flags$&da);return y||m.$componentQrl$||m.$element$.hasAttribute("q:id")||(Er(t,m),m.$componentQrl$=$["q:renderFn"],m.$componentQrl$,y=!0),y?X(mn(t,m,l),()=>er(t,m,a,l)):er(t,m,a,l)}if("q:s"in f)return d.$slots$,void d.$slots$.push(a);if(ht in f)Fe(c,r,"innerHTML",f[ht]);else if(!(2&x))return al(t,e,a,l)},er=(t,e,a,l)=>{if(2&a.$flags$)return;const r=t.$static$,o=pi(a.$children$),c=xi(e);for(const p in c.slots)if(!o[p]){const d=c.slots[p],f=ci(d,nl);if(f.length>0){const x=kt(d);x&&x.$vdom$&&(x.$vdom$.$children$=[]),kn(r,f,0,f.length-1)}}for(const p in c.templates){const d=c.templates[p];d&&!o[p]&&(c.templates[p]=void 0,Mn(r,d))}return an(Object.keys(o).map(p=>{const d=o[p],f=gi(r,c,e,p,t.$static$.$containerState$),x=hn(f),m=Ba(t),$=f.$element$;m.$slotCtx$=f,f.$vdom$=d,d.$elm$=$;let y=l&~St;$.isSvg&&(y|=St);const P=r.$addSlots$.findIndex(w=>w[0]===$);return P>=0&&r.$addSlots$.splice(P,1),al(m,x,d,y)}))},fi=(t,e,a,l,r,o,c)=>{const p=[];for(;r<=o;++r){const d=l[r],f=Ye(t,d,c,p);oa(t.$static$,e,f,a)}return na(p)},kn=(t,e,a,l)=>{for(;a<=l;++a){const r=e[a];r&&(r.$elm$,Mn(t,r.$elm$))}},gi=(t,e,a,l,r)=>{const o=e.slots[l];if(o)return yt(o,r);const c=e.templates[l];if(c)return yt(c,r);const p=vi(t.$doc$,l),d=vl(p);return d.$parentCtx$=a,Tc(t,a.$element$,p),e.templates[l]=p,d},oc=t=>t.$props$[Pt]??"",Ye=(t,e,a,l)=>{const r=e.$type$,o=t.$static$.$doc$,c=t.$cmpCtx$;if(r==="#text")return e.$elm$=o.createTextNode(e.$text$);if(r==="#signal"){const D=e.$signal$,v=D.value;if(ta(v)){const L=qe(v);if(mt(L))throw new Error("NOT IMPLEMENTED: Promise");if(Array.isArray(L))throw new Error("NOT IMPLEMENTED: Array");{const k=Ye(t,L,a,l);return Gt(D,4&a?[3,k,D,k]:[4,c.$element$,D,k]),e.$elm$=k}}{const L=o.createTextNode(e.$text$);return L.data=e.$text$=Sa(v),Gt(D,4&a?[3,L,D,L]:[4,c.$element$,D,L]),e.$elm$=L}}let p,d=!!(a&St);d||r!=="svg"||(a|=St,d=!0);const f=r===pa,x=e.$props$,m=t.$static$,$=m.$containerState$;f?p=Mc(o,d):r==="head"?(p=o.head,a|=tl):(p=Cn(o,r,d),a&=~tl),2&e.$flags$&&(a|=4),e.$elm$=p;const y=vl(p);if(t.$slotCtx$?(y.$parentCtx$=t.$slotCtx$,y.$realParentCtx$=t.$cmpCtx$):y.$parentCtx$=t.$cmpCtx$,f){if("q:renderFn"in x){const D=x["q:renderFn"],v=ml(),L=$.$subsManager$.$createManager$(),k=new Proxy(v,new Cr($,L)),T=x.props;if($.$proxyMap$.set(v,k),y.$props$=k,T!==ft){const E=v[s]=T[s]??ft;for(const N in T)if(N!=="children"&&N!==Pt){const j=E[N];mt(j)?v["$$"+N]=j:v[N]=T[N]}}Er(t,y),y.$componentQrl$=D;const I=X(mn(t,y,a),()=>{let E=e.$children$;if(E.length===0)return;E.length===1&&E[0].$type$===":skipRender"&&(E=E[0].$children$);const N=xi(y),j=[],O=pi(E);for(const W in O){const K=O[W],Y=gi(m,N,y,W,m.$containerState$),it=Ba(t),dt=Y.$element$;it.$slotCtx$=Y,Y.$vdom$=K,K.$elm$=dt;let nt=a&~St;dt.isSvg&&(nt|=St);for(const at of K.$children$){const pt=Ye(it,at,nt,j);at.$elm$,at.$elm$,$i(m,dt,pt)}}return na(j)});return ct(I)&&l.push(I),p}if("q:s"in x)c.$slots$,Lc(p,e.$key$),Tt(p,"q:sref",c.$id$),Tt(p,"q:s",""),c.$slots$.push(e),m.$addSlots$.push([p,c.$element$]);else if(ht in x)return Fe(m,p,"innerHTML",x[ht]),p}else{if(e.$immutableProps$){const D=x!==ft?Object.fromEntries(Object.entries(e.$immutableProps$).map(([v,L])=>[v,L===s?x[v]:L])):e.$immutableProps$;nr(m,y,c,D,d,!0)}if(x!==ft){y.$vdom$=e;const D=e.$immutableProps$?Object.fromEntries(Object.entries(x).filter(([v])=>!(v in e.$immutableProps$))):x;e.$props$=nr(m,y,c,D,d,!1)}if(d&&r==="foreignObject"&&(d=!1,a&=~St),c){const D=c.$scopeIds$;D&&D.forEach(v=>{p.classList.add(v)}),c.$flags$&Re&&(y.li.push(...c.li),c.$flags$&=~Re)}for(const D of y.li)mi(m,p,D[0]);if(x[ht]!==void 0)return p;d&&r==="foreignObject"&&(d=!1,a&=~St)}let P=e.$children$;if(P.length===0)return p;P.length===1&&P[0].$type$===":skipRender"&&(P=P[0].$children$);const w=P.map(D=>Ye(t,D,a,l));for(const D of w)ka(p,D);return p},uc=t=>{const e=t.$slots$;return e||(t.$element$.parentElement,t.$slots$=cc(t))},xi=t=>{const e=uc(t),a={},l={},r=Array.from(t.$element$.childNodes).filter(zl);for(const o of e)o.$elm$,a[o.$key$??""]=o.$elm$;for(const o of r)l[Nt(o,Pt)??""]=o;return{slots:a,templates:l}},cc=t=>{const e=t.$element$.parentElement;return Nc(e,"q:sref",t.$id$).map(ll)},dc=(t,e,a)=>(Fe(t,e.style,"cssText",a),!0),ar=(t,e,a)=>(e.namespaceURI===qa?La(t,e,"class",a):Fe(t,e,"className",a),!0),lr=(t,e,a,l)=>l in e&&((e[l]!==a||l==="value"&&!e.hasAttribute(l))&&(l==="value"&&e.tagName!=="OPTION"?yc(t,e,l,a):Fe(t,e,l,a)),!0),$a=(t,e,a,l)=>(La(t,e,l.toLowerCase(),a),!0),pc=(t,e,a)=>(Fe(t,e,"innerHTML",a),!0),fc=()=>!0,gc={style:dc,class:ar,className:ar,value:lr,checked:lr,href:$a,list:$a,form:$a,tabIndex:$a,download:$a,innerHTML:fc,[ht]:pc},Ln=(t,e,a,l,r)=>{if(Nr(a))return void La(t,e,a,l!=null?String(l):l);const o=gc[a];o&&o(t,e,l,a)||(r||!(a in e)?(a.startsWith(Lr)&&hi(a.slice(15)),La(t,e,a,l)):Fe(t,e,a,l))},nr=(t,e,a,l,r,o)=>{const c={},p=e.$element$;for(const d in l){let f=l[d];if(d!=="ref")if(nn(d))rn(e.li,d,f,t.$containerState$.$containerEl$);else{if(mt(f)&&(f=Gt(f,o?[1,p,f,a.$element$,d]:[2,a.$element$,f,p,d])),d==="class"){if(f=pn(f,a),!f)continue}else d==="style"&&(f=bl(f));c[d]=f,Ln(t,p,d,f,r)}else f!==void 0&&Pn(f,p)}return c},xc=(t,e,a)=>{let l=e.$props$;if(l||(e.$props$=l=Ia(ml(),t)),a===ft)return;const r=$t(l),o=ea(l),c=o[s]=a[s]??ft;for(const p in a)if(p!=="children"&&p!==Pt&&!c[p]){const d=a[p];o[p]!==d&&(o[p]=d,r.$notifySubs$(p))}},_a=(t,e,a,l)=>{if(a.$clearSub$(t),He(t)){if(l&&t.hasAttribute("q:s"))return void e.$rmSlots$.push(t);const r=kt(t);r&&Wu(r,a);const o=zt(t)?t.close:null;let c=t.firstChild;for(;(c=jn(c))&&(_a(c,e,a,!0),c=c.nextSibling,c!==o););}},mc=async t=>{kc(t)},ka=(t,e)=>{zt(e)?e.appendTo(t):t.appendChild(e)},hc=(t,e)=>{zt(e)?e.remove():t.removeChild(e)},bc=(t,e,a)=>{zt(e)?e.insertBeforeTo(t,(a==null?void 0:a.nextSibling)??null):t.insertBefore(e,(a==null?void 0:a.nextSibling)??null)},yl=(t,e,a)=>{zt(e)?e.insertBeforeTo(t,sl(a)):t.insertBefore(e,sl(a))},$c=(t,e,a)=>{const l={};for(let r=e;r<=a;++r){const o=t[r].$key$;o!=null&&(l[o]=r)}return l},mi=(t,e,a)=>{a.startsWith("on:")||La(t,e,a,""),hi(a)},hi=t=>{var e;{const a=ui(t);try{((e=globalThis).qwikevents||(e.qwikevents=[])).push(a)}catch{}}},La=(t,e,a,l)=>{t.$operations$.push({$operation$:vc,$args$:[e,a,l]})},vc=(t,e,a)=>{if(a==null||a===!1)t.removeAttribute(e);else{const l=a===!0?"":String(a);Tt(t,e,l)}},Fe=(t,e,a,l)=>{t.$operations$.push({$operation$:bi,$args$:[e,a,l]})},yc=(t,e,a,l)=>{t.$postOperations$.push({$operation$:bi,$args$:[e,a,l]})},bi=(t,e,a)=>{try{t[e]=a??"",a==null&&Qe(t)&&Ge(t)&&t.removeAttribute(e)}catch(l){Ke(dl(6),e,{node:t,value:a},l)}},Cn=(t,e,a)=>a?t.createElementNS(qa,e):t.createElement(e),oa=(t,e,a,l)=>(t.$operations$.push({$operation$:yl,$args$:[e,a,l||null]}),a),_c=(t,e,a,l)=>(t.$operations$.push({$operation$:bc,$args$:[e,a,l||null]}),a),$i=(t,e,a)=>(t.$operations$.push({$operation$:ka,$args$:[e,a]}),a),wc=(t,e)=>{t.$containerState$.$styleIds$.add(e.styleId),t.$postOperations$.push({$operation$:Sc,$args$:[t.$containerState$,e]})},Sc=(t,e)=>{const a=t.$containerEl$,l=Na(a),r=l.documentElement===a,o=l.head,c=l.createElement("style");Tt(c,gl,e.styleId),Tt(c,"hidden",""),c.textContent=e.content,r&&o?ka(o,c):yl(a,c,a.firstChild)},Tc=(t,e,a)=>{t.$operations$.push({$operation$:Dc,$args$:[e,a]})},Dc=(t,e)=>{yl(t,e,t.firstChild)},Mn=(t,e)=>{He(e)&&_a(e,t,t.$containerState$.$subsManager$,!0),t.$operations$.push({$operation$:Pc,$args$:[e,t]})},Pc=t=>{const e=t.parentElement;e&&hc(e,t)},vi=(t,e)=>{const a=Cn(t,"q:template",!1);return Tt(a,Pt,e),Tt(a,"hidden",""),Tt(a,"aria-hidden","true"),a},kc=t=>{for(const e of t.$operations$)e.$operation$.apply(void 0,e.$args$);Cc(t)},Fl=t=>Nt(t,"q:key"),Lc=(t,e)=>{e!==null&&Tt(t,"q:key",e)},Cc=t=>{const e=t.$containerState$.$subsManager$;for(const a of t.$rmSlots$){const l=Fl(a),r=ia(a,nl);if(r.length>0){const o=a.getAttribute("q:sref"),c=t.$roots$.find(p=>p.$id$===o);if(c){const p=c.$element$;if(p.isConnected)if(ia(p,zl).some(d=>Nt(d,Pt)===l))_a(a,t,e,!1);else{const d=vi(t.$doc$,l);for(const f of r)ka(d,f);yl(p,d,p.firstChild)}else _a(a,t,e,!1)}else _a(a,t,e,!1)}}for(const[a,l]of t.$addSlots$){const r=Fl(a),o=ia(l,zl).find(c=>c.getAttribute(Pt)===r);o&&(ia(o,nl).forEach(c=>{ka(a,c)}),o.remove())}},sr=()=>{},Mc=(t,e)=>{const a=t.createComment("qv "),l=t.createComment("/qv");return new yi(a,l,e)},jc=t=>{if(!t)return{};const e=t.split(" ");return Object.fromEntries(e.map(a=>{const l=a.indexOf("=");return l>=0?[a.slice(0,l),Bc(a.slice(l+1))]:[a,""]}))},Ac=t=>{const e=[];return Object.entries(t).forEach(([a,l])=>{e.push(l?`${a}=${Ic(l)}`:`${a}`)}),e.join(" ")},Ec=(t,e,a)=>t.ownerDocument.createTreeWalker(t,128,{acceptNode(l){const r=Ra(l);return r&&Nt(r,e)===a?1:2}}),Nc=(t,e,a)=>{const l=Ec(t,e,a),r=[];let o=null;for(;o=l.nextNode();)r.push(Ra(o));return r},Ic=t=>t.replace(/ /g,"+"),Bc=t=>t.replace(/\+/g," "),pa=":virtual";class yi{constructor(e,a,l){this.open=e,this.close=a,this.isSvg=l,this._qc_=null,this.nodeType=111,this.localName=pa,this.nodeName=pa;const r=this.ownerDocument=e.ownerDocument;this.$template$=Cn(r,"template",!1),this.$attributes$=jc(e.data.slice(3)),e.data.startsWith("qv "),e.__virtual=this,a.__virtual=this}insertBefore(e,a){const l=this.parentElement;return l?l.insertBefore(e,a||this.close):this.$template$.insertBefore(e,a),e}remove(){const e=this.parentElement;if(e){const a=this.childNodes;this.$template$.childElementCount,e.removeChild(this.open);for(let l=0;l<a.length;l++)this.$template$.appendChild(a[l]);e.removeChild(this.close)}}appendChild(e){return this.insertBefore(e,null)}insertBeforeTo(e,a){const l=this.childNodes;e.insertBefore(this.open,a);for(const r of l)e.insertBefore(r,a);e.insertBefore(this.close,a),this.$template$.childElementCount}appendTo(e){this.insertBeforeTo(e,null)}get namespaceURI(){var e;return((e=this.parentElement)==null?void 0:e.namespaceURI)??""}removeChild(e){this.parentElement?this.parentElement.removeChild(e):this.$template$.removeChild(e)}getAttribute(e){return this.$attributes$[e]??null}hasAttribute(e){return e in this.$attributes$}setAttribute(e,a){this.$attributes$[e]=a,this.open.data=rr(this.$attributes$)}removeAttribute(e){delete this.$attributes$[e],this.open.data=rr(this.$attributes$)}matches(e){return!1}compareDocumentPosition(e){return this.open.compareDocumentPosition(e)}closest(e){const a=this.parentElement;return a?a.closest(e):null}querySelectorAll(e){const a=[];return ia(this,Po).forEach(l=>{He(l)&&(l.matches(e)&&a.push(l),a.concat(Array.from(l.querySelectorAll(e))))}),a}querySelector(e){for(const a of this.childNodes)if(Ge(a)){if(a.matches(e))return a;const l=a.querySelector(e);if(l!==null)return l}return null}get innerHTML(){return""}set innerHTML(e){const a=this.parentElement;a?(this.childNodes.forEach(l=>this.removeChild(l)),this.$template$.innerHTML=e,a.insertBefore(this.$template$.content,this.close)):this.$template$.innerHTML=e}get firstChild(){if(this.parentElement){const e=this.open.nextSibling;return e===this.close?null:e}return this.$template$.firstChild}get nextSibling(){return this.close.nextSibling}get previousSibling(){return this.open.previousSibling}get childNodes(){if(!this.parentElement)return Array.from(this.$template$.childNodes);const e=[];let a=this.open;for(;(a=a.nextSibling)&&a!==this.close;)e.push(a);return e}get isConnected(){return this.open.isConnected}get parentElement(){return this.open.parentElement}}const rr=t=>`qv ${Ac(t)}`,jn=t=>{if(t==null)return null;if(Aa(t)){const e=Ra(t);if(e)return e}return t},Oc=t=>{let e=t,a=1;for(;e=e.nextSibling;)if(Aa(e)){const l=e.__virtual;if(l)e=l;else if(e.data.startsWith("qv "))a++;else if(e.data==="/qv"&&(a--,a===0))return e}},Ra=t=>{var a;const e=t.__virtual;if(e)return e;if(t.data.startsWith("qv ")){const l=Oc(t);return new yi(t,l,((a=t.parentElement)==null?void 0:a.namespaceURI)===qa)}return null},sl=t=>t==null?null:zt(t)?t.open:t,Q_=async t=>{const e=Dn(null,null),a=_i(e);let l;for(J(t,a,!1);(l=a.$promises$).length>0;){a.$promises$=[];const f=await Promise.allSettled(l);for(const x of f)x.status==="rejected"&&console.error(x.reason)}const r=Array.from(a.$objSet$.keys());let o=0;const c=new Map;for(const f of r)c.set(f,ze(o)),o++;if(a.$noSerialize$.length>0){const f=c.get(void 0);for(const x of a.$noSerialize$)c.set(x,f)}const p=f=>{let x="";if(ct(f)){const $=wi(f);if(!$)throw ot(27,f);f=$.value,x+=$.resolved?"~":"_"}if(Ht(f)){const $=ea(f);$&&(x+="!",f=$)}const m=c.get(f);if(m===void 0)throw ot(27,f);return m+x},d=Ti(r,p,null,a,e);return JSON.stringify({_entry:p(t),_objs:d})},qc=async t=>{const e=Na(t),a=e.documentElement,l=wr(t)?a:t;if(Nt(l,"q:container")==="paused")throw ot(21);const r=l===e.documentElement?e.body:l,o=ma(l),c=zc(l,Uc);Tt(l,"q:container","paused");for(const m of c){const $=m.$element$,y=m.li;if(m.$scopeIds$){const P=Mr(m.$scopeIds$);P&&$.setAttribute("q:sstyle",P)}if(m.$id$&&$.setAttribute("q:id",m.$id$),Ge($)&&y.length>0){const P=sn(y);for(const w of P)$.setAttribute(w[0],Nn(w[1],o,m))}}const p=await Rc(c,o,m=>Qe(m)&&Jl(m)?Kc(m,o):null),d=e.createElement("script");Tt(d,"type","qwik/json"),d.textContent=Hc(JSON.stringify(p.state,void 0,void 0)),r.appendChild(d);const f=Array.from(o.$events$,m=>JSON.stringify(m)),x=e.createElement("script");return x.textContent=`(window.qwikevents||=[]).push(${f.join(", ")})`,r.appendChild(x),p},Rc=async(t,e,a,l)=>{var k;const r=_i(e);l==null||l.forEach((T,I)=>{r.$seen$.add(I)});let o=!1;for(const T of t)if(T.$tasks$)for(const I of T.$tasks$)ei(I)&&r.$resources$.push(I.$state$),li(I);for(const T of t){const I=T.$element$,E=T.li;for(const N of E)if(Ge(I)){const j=N[1],O=j.$captureRef$;if(O)for(const W of O)J(W,r,!0);r.$qrls$.push(j),o=!0}}if(!o)return{state:{refs:{},ctx:{},objs:[],subs:[]},objs:[],funcs:[],qrls:[],resources:r.$resources$,mode:"static"};let c;for(;(c=r.$promises$).length>0;)r.$promises$=[],await Promise.all(c);const p=r.$elements$.length>0;if(p){for(const T of r.$deferElements$)An(T,r,T.$element$);for(const T of t)Fc(T,r)}for(;(c=r.$promises$).length>0;)r.$promises$=[],await Promise.all(c);const d=new Map,f=Array.from(r.$objSet$.keys()),x=new Map,m=T=>{let I="";if(ct(T)){const j=wi(T);if(!j)return null;T=j.value,I+=j.resolved?"~":"_"}if(Ht(T)){const j=ea(T);if(j)I+="!",T=j;else if(He(T)){const O=(W=>{let K=d.get(W);return K===void 0&&(K=Zc(W),K||console.warn("Missing ID",W),d.set(W,K)),K})(T);return O?"#"+O+I:null}}const E=x.get(T);if(E)return E+I;const N=l==null?void 0:l.get(T);return N?"*"+N:a?a(T):null},$=T=>{const I=m(T);if(I===null){if(Bn(T)){const E=ze(x.size);return x.set(T,E),E}throw ot(27,T)}return I},y=new Map;for(const T of f){const I=(k=Yc(T,e))==null?void 0:k.$subs$;if(!I)continue;const E=ji(T)??0,N=[];1&E&&N.push(E);for(const j of I){const O=j[1];j[0]===0&&Qe(O)&&zt(O)&&!r.$elements$.includes(kt(O))||N.push(j)}N.length>0&&y.set(T,N)}f.sort((T,I)=>(y.has(T)?0:1)-(y.has(I)?0:1));let P=0;for(const T of f)x.set(T,ze(P)),P++;if(r.$noSerialize$.length>0){const T=x.get(void 0);for(const I of r.$noSerialize$)x.set(I,T)}const w=[];for(const T of f){const I=y.get(T);if(I==null)break;w.push(I.map(E=>typeof E=="number"?`_${E}`:Ad(E,m)).filter(Tr))}w.length,y.size;const D=Ti(f,$,m,r,e),v={},L={};for(const T of t){const I=T.$element$,E=T.$id$,N=T.$refMap$,j=T.$props$,O=T.$contexts$,W=T.$tasks$,K=T.$componentQrl$,Y=T.$seq$,it={},dt=zt(I)&&r.$elements$.includes(T);if(N.length>0){const nt=Ze(N,$," ");nt&&(L[E]=nt)}else if(p){let nt=!1;if(dt){const at=m(j);it.h=$(K)+(at?" "+at:""),nt=!0}else{const at=m(j);at&&(it.h=" "+at,nt=!0)}if(W&&W.length>0){const at=Ze(W,m," ");at&&(it.w=at,nt=!0)}if(dt&&Y&&Y.length>0){const at=Ze(Y,$," ");it.s=at,nt=!0}if(O){const at=[];O.forEach((It,Bt)=>{const Ct=m(It);Ct&&at.push(`${Bt}=${Ct}`)});const pt=at.join(" ");pt&&(it.c=pt,nt=!0)}nt&&(v[E]=it)}}return{state:{refs:L,ctx:v,objs:D,subs:w},objs:f,funcs:r.$inlinedFunctions$,resources:r.$resources$,qrls:r.$qrls$,mode:p?"render":"listeners"}},Ze=(t,e,a)=>{let l="";for(const r of t){const o=e(r);o!==null&&(l!==""&&(l+=a),l+=o)}return l},zc=(t,e)=>{const a=[],l=e(t);l!==void 0&&a.push(l);const r=t.ownerDocument.createTreeWalker(t,1|oi,{acceptNode(o){if(Wc(o))return 2;const c=e(o);return c!==void 0&&a.push(c),3}});for(;r.nextNode(););return a},Fc=(t,e)=>{var r;const a=t.$realParentCtx$||t.$parentCtx$,l=t.$props$;if(a&&l&&!Si(l)&&e.$elements$.includes(a)){const o=(r=$t(l))==null?void 0:r.$subs$,c=t.$element$;if(o)for(const[p,d]of o)p===0?(d!==c&&fa($t(l),e,!1),Qe(d)?Gc(d,e):J(d,e,!0)):(J(l,e,!1),fa($t(l),e,!1))}},_i=t=>{const e=[];return t.$inlineFns$.forEach((a,l)=>{for(;e.length<=a;)e.push("");e[a]=l}),{$containerState$:t,$seen$:new Set,$objSet$:new Set,$prefetch$:0,$noSerialize$:[],$inlinedFunctions$:e,$resources$:[],$elements$:[],$qrls$:[],$deferElements$:[],$promises$:[]}},Qc=(t,e)=>{const a=kt(t);e.$elements$.includes(a)||(e.$elements$.push(a),a.$flags$&wn?(e.$prefetch$++,An(a,e,!0),e.$prefetch$--):e.$deferElements$.push(a))},Gc=(t,e)=>{const a=kt(t);if(a){if(e.$elements$.includes(a))return;e.$elements$.push(a),An(a,e,t)}},An=(t,e,a)=>{if(t.$props$&&!Si(t.$props$)&&(J(t.$props$,e,a),fa($t(t.$props$),e,a)),t.$componentQrl$&&J(t.$componentQrl$,e,a),t.$seq$)for(const l of t.$seq$)J(l,e,a);if(t.$tasks$){const l=e.$containerState$.$subsManager$.$groupToManagers$;for(const r of t.$tasks$)l.has(r)&&J(r,e,a)}if(a===!0&&(ir(t,e),t.$dynamicSlots$))for(const l of t.$dynamicSlots$)ir(l,e)},ir=(t,e)=>{for(;t;){if(t.$contexts$)for(const a of t.$contexts$.values())J(a,e,!0);t=t.$parentCtx$}},Hc=t=>t.replace(/<(\/?script)/gi,"\\x3C$1"),fa=(t,e,a)=>{if(e.$seen$.has(t))return;e.$seen$.add(t);const l=t.$subs$;for(const r of l)if(r[0]>0&&J(r[2],e,a),a===!0){const o=r[1];Qe(o)&&zt(o)?r[0]===0&&Qc(o,e):J(o,e,!0)}},Ql=Symbol(),Vc=t=>t.then(e=>(t[Ql]={resolved:!0,value:e},e),e=>(t[Ql]={resolved:!1,value:e},e)),wi=t=>t[Ql],J=(t,e,a)=>{if(t!=null){const l=typeof t;switch(l){case"function":case"object":{if(e.$seen$.has(t))return;if(e.$seen$.add(t),Ci(t))return e.$objSet$.add(void 0),void e.$noSerialize$.push(t);const r=t,o=ea(t);if(o){const c=!(2&ji(t=o));if(a&&c&&fa($t(r),e,a),Mi(r))return void e.$objSet$.add(t)}if(Dd(t,e,a))return void e.$objSet$.add(t);if(ct(t))return void e.$promises$.push(Vc(t).then(c=>{J(c,e,a)}));if(l==="object"){if(Qe(t))return;if(lt(t))for(let c=0;c<t.length;c++)J(r[c],e,a);else if(Ea(t))for(const c in t)J(r[c],e,a)}break}}}e.$objSet$.add(t)},Wc=t=>Ge(t)&&t.hasAttribute("q:container"),Uc=t=>{const e=jn(t);if(He(e)){const a=kt(e);if(a&&a.$id$)return a}},Yc=(t,e)=>{if(!Ht(t))return;if(t instanceof Pa)return $t(t);const a=e.$proxyMap$.get(t);return a?$t(a):void 0},Zc=t=>{const e=kt(t);return e?e.$id$:null},Kc=(t,e)=>{const a=t.previousSibling;if(a&&Aa(a)&&a.data.startsWith("t="))return"#"+a.data.slice(2);const l=t.ownerDocument,r=ze(e.$elementIndex$++),o=l.createComment(`t=${r}`),c=l.createComment(""),p=t.parentElement;return p.insertBefore(o,t),p.insertBefore(c,t.nextSibling),"#"+r},Si=t=>Object.keys(t).length===0;function Ti(t,e,a,l,r){return t.map(o=>{if(o===null)return null;const c=typeof o;switch(c){case"undefined":return wl;case"number":if(!Number.isFinite(o))break;return o;case"string":if(o.charCodeAt(0)<32)break;return o;case"boolean":return o}const p=Pd(o,e,l,r);if(p!==void 0)return p;if(c==="object"){if(lt(o))return o.map(e);if(Ea(o)){const d={};for(const f in o)if(a){const x=a(o[f]);x!==null&&(d[f]=x)}else d[f]=e(o[f]);return d}}throw ot(3,o)})}const g=(t,e,a=Ft)=>Fa(null,e,t,null,null,a,null),B=(t,e=Ft)=>Fa(null,t,null,null,null,e,null),En=(t,e={})=>{var f,x;let a=t.$symbol$,l=t.$chunk$;const r=t.$refSymbol$??a,o=pl();if(o){const m=o.chunkForSymbol(r,l,(f=t.dev)==null?void 0:f.file);m?(l=m[1],t.$refSymbol$||(a=m[0])):console.error("serializeQRL: Cannot resolve symbol",a,"in",l,(x=t.dev)==null?void 0:x.file)}if(l==null)throw ot(31,t.$symbol$);if(l.startsWith("./")&&(l=l.slice(2)),Od(t))if(e.$containerState$){const m=e.$containerState$,$=t.resolved.toString();let y=m.$inlineFns$.get($);y===void 0&&(y=m.$inlineFns$.size,m.$inlineFns$.set($,y)),a=String(y)}else Sr("Sync QRL without containerState");let c=`${l}#${a}`;const p=t.$capture$,d=t.$captureRef$;return d&&d.length?e.$getObjId$?c+=`[${Ze(d,e.$getObjId$," ")}]`:e.$addRefMap$&&(c+=`[${Ze(d,e.$addRefMap$," ")}]`):p&&p.length>0&&(c+=`[${p.join(" ")}]`),c},Nn=(t,e,a)=>{a.$element$;const l={$containerState$:e,$addRefMap$:r=>Jc(a.$refMap$,r)};return Ze(t,r=>En(r,l),`
`)},_l=(t,e)=>{const a=t.length,l=or(t,0,"#"),r=or(t,l,"["),o=Math.min(l,r),c=t.substring(0,o),p=l==a?l:l+1,d=p==r?"default":t.substring(p,r),f=r===a?Ft:t.substring(r+1,a-1).split(" "),x=Fa(c,d,null,null,f,null,null);return e&&x.$setContainer$(e),x},or=(t,e,a)=>{const l=t.length,r=t.indexOf(a,e==l?0:e);return r==-1?l:r},Jc=(t,e)=>{const a=t.indexOf(e);return a===-1?(t.push(e),String(t.length-1)):String(a)},Di=(t,e)=>(t.$capture$,t.$captureRef$=t.$capture$.map(a=>{const l=parseInt(a,10),r=e.$refMap$[l];return e.$refMap$.length>l,r})),G_=(t,e)=>(globalThis.__qwik_reg_symbols===void 0&&(globalThis.__qwik_reg_symbols=new Map),globalThis.__qwik_reg_symbols.set(e,t),t),Xc=t=>({__brand:"resource",value:void 0,loading:!Dt(),_resolved:void 0,_error:void 0,_state:"pending",_timeout:(t==null?void 0:t.timeout)??-1,_cache:0}),td=t=>Ht(t)&&t.__brand==="resource",ed=(t,e)=>{const a=t._state;return a==="resolved"?`0 ${e(t._resolved)}`:a==="pending"?"1":`2 ${e(t._error)}`},ad=t=>{const[e,a]=t.split(" "),l=Xc(void 0);return l.value=Promise.resolve(),e==="0"?(l._state="resolved",l._resolved=a,l.loading=!1):e==="1"?(l._state="pending",l.value=new Promise(()=>{}),l.loading=!0):e==="2"&&(l._state="rejected",l._error=a,l.loading=!1),l},ut=t=>i(Oe,{[Dr]:""},0,t.name??""),wl="";function st(t){return{$prefixCode$:t.$prefix$.charCodeAt(0),$prefixChar$:t.$prefix$,$test$:t.$test$,$serialize$:t.$serialize$,$prepare$:t.$prepare$,$fill$:t.$fill$,$collect$:t.$collect$,$subs$:t.$subs$}}const ld=st({$prefix$:"",$test$:t=>Bn(t),$collect$:(t,e,a)=>{if(t.$captureRef$)for(const l of t.$captureRef$)J(l,e,a);e.$prefetch$===0&&e.$qrls$.push(t)},$serialize$:(t,e)=>En(t,{$getObjId$:e}),$prepare$:(t,e)=>_l(t,e.$containerEl$),$fill$:(t,e)=>{t.$capture$&&t.$capture$.length>0&&(t.$captureRef$=t.$capture$.map(e),t.$capture$=null)}}),nd=st({$prefix$:"",$test$:t=>yn(t),$collect$:(t,e,a)=>{J(t.$qrl$,e,a),t.$state$&&(J(t.$state$,e,a),a===!0&&t.$state$ instanceof Pa&&fa(t.$state$[qt],e,!0))},$serialize$:(t,e)=>Fu(t,e),$prepare$:t=>Qu(t),$fill$:(t,e)=>{t.$el$=e(t.$el$),t.$qrl$=e(t.$qrl$),t.$state$&&(t.$state$=e(t.$state$))}}),sd=st({$prefix$:"",$test$:t=>td(t),$collect$:(t,e,a)=>{J(t.value,e,a),J(t._resolved,e,a)},$serialize$:(t,e)=>ed(t,e),$prepare$:t=>ad(t),$fill$:(t,e)=>{if(t._state==="resolved")t._resolved=e(t._resolved),t.value=Promise.resolve(t._resolved);else if(t._state==="rejected"){const a=Promise.reject(t._error);a.catch(()=>null),t._error=e(t._error),t.value=a}}}),rd=st({$prefix$:"",$test$:t=>t instanceof URL,$serialize$:t=>t.href,$prepare$:t=>new URL(t)}),id=st({$prefix$:"",$test$:t=>t instanceof Date,$serialize$:t=>t.toISOString(),$prepare$:t=>new Date(t)}),od=st({$prefix$:"\x07",$test$:t=>t instanceof RegExp,$serialize$:t=>`${t.flags} ${t.source}`,$prepare$:t=>{const e=t.indexOf(" "),a=t.slice(e+1),l=t.slice(0,e);return new RegExp(a,l)}}),ud=st({$prefix$:"",$test$:t=>t instanceof Error,$serialize$:t=>t.message,$prepare$:t=>{const e=new Error(t);return e.stack=void 0,e}}),cd=st({$prefix$:"",$test$:t=>!!t&&typeof t=="object"&&wr(t),$prepare$:(t,e,a)=>a}),rl=Symbol("serializable-data"),dd=st({$prefix$:"",$test$:t=>On(t),$serialize$:(t,e)=>{const[a]=t[rl];return En(a,{$getObjId$:e})},$prepare$:(t,e)=>{const a=_l(t,e.$containerEl$);return b(a)},$fill$:(t,e)=>{var l;const[a]=t[rl];(l=a.$capture$)!=null&&l.length&&(a.$captureRef$=a.$capture$.map(e),a.$capture$=null)}}),pd=st({$prefix$:"",$test$:t=>t instanceof ql,$collect$:(t,e,a)=>{if(t.$args$)for(const l of t.$args$)J(l,e,a)},$serialize$:(t,e,a)=>{const l=xu(t);let r=a.$inlinedFunctions$.indexOf(l);return r<0&&(r=a.$inlinedFunctions$.length,a.$inlinedFunctions$.push(l)),Ze(t.$args$,e," ")+" @"+ze(r)},$prepare$:t=>{const e=t.split(" "),a=e.slice(0,-1),l=e[e.length-1];return new ql(l,a,l)},$fill$:(t,e)=>{t.$func$,t.$func$=e(t.$func$),t.$args$=t.$args$.map(e)}}),fd=st({$prefix$:"",$test$:t=>t instanceof Pa,$collect$:(t,e,a)=>(J(t.untrackedValue,e,a),a===!0&&!(t[Da]&lc)&&fa(t[qt],e,!0),t),$serialize$:(t,e)=>e(t.untrackedValue),$prepare$:(t,e)=>{var a;return new Pa(t,(a=e==null?void 0:e.$subsManager$)==null?void 0:a.$createManager$(),0)},$subs$:(t,e)=>{t[qt].$addSubs$(e)},$fill$:(t,e)=>{t.untrackedValue=e(t.untrackedValue)}}),gd=st({$prefix$:"",$test$:t=>t instanceof Rl,$collect$(t,e,a){if(J(t.ref,e,a),Mi(t.ref)){const l=$t(t.ref);Ld(e.$containerState$.$subsManager$,l,a)&&J(t.ref[t.prop],e,a)}return t},$serialize$:(t,e)=>`${e(t.ref)} ${t.prop}`,$prepare$:t=>{const[e,a]=t.split(" ");return new Rl(e,a)},$fill$:(t,e)=>{t.ref=e(t.ref)}}),xd=st({$prefix$:"",$test$:t=>typeof t=="number",$serialize$:t=>String(t),$prepare$:t=>Number(t)}),md=st({$prefix$:"",$test$:t=>t instanceof URLSearchParams,$serialize$:t=>t.toString(),$prepare$:t=>new URLSearchParams(t)}),hd=st({$prefix$:"",$test$:t=>typeof FormData<"u"&&t instanceof globalThis.FormData,$serialize$:t=>{const e=[];return t.forEach((a,l)=>{e.push(typeof a=="string"?[l,a]:[l,a.name])}),JSON.stringify(e)},$prepare$:t=>{const e=JSON.parse(t),a=new FormData;for(const[l,r]of e)a.append(l,r);return a}}),bd=st({$prefix$:"",$test$:t=>ta(t),$collect$:(t,e,a)=>{J(t.children,e,a),J(t.props,e,a),J(t.immutableProps,e,a),J(t.key,e,a);let l=t.type;l===ut?l=":slot":l===G&&(l=":fragment"),J(l,e,a)},$serialize$:(t,e)=>{let a=t.type;return a===ut?a=":slot":a===G&&(a=":fragment"),`${e(a)} ${e(t.props)} ${e(t.immutableProps)} ${e(t.key)} ${e(t.children)} ${t.flags}`},$prepare$:t=>{const[e,a,l,r,o,c]=t.split(" ");return new xa(e,a,l,o,parseInt(c,10),r)},$fill$:(t,e)=>{t.type=Cd(e(t.type)),t.props=e(t.props),t.immutableProps=e(t.immutableProps),t.key=e(t.key),t.children=e(t.children)}}),$d=st({$prefix$:"",$test$:t=>typeof t=="bigint",$serialize$:t=>t.toString(),$prepare$:t=>BigInt(t)}),vd=st({$prefix$:"",$test$:t=>t instanceof Uint8Array,$serialize$:t=>{let e="";for(const a of t)e+=String.fromCharCode(a);return btoa(e).replace(/=+$/,"")},$prepare$:t=>{const e=atob(t),a=new Uint8Array(e.length);let l=0;for(const r of e)a[l++]=r.charCodeAt(0);return a},$fill$:void 0}),ca=Symbol(),yd=st({$prefix$:"",$test$:t=>t instanceof Set,$collect$:(t,e,a)=>{t.forEach(l=>J(l,e,a))},$serialize$:(t,e)=>Array.from(t).map(e).join(" "),$prepare$:t=>{const e=new Set;return e[ca]=t,e},$fill$:(t,e)=>{const a=t[ca];t[ca]=void 0;const l=a.length===0?[]:a.split(" ");for(const r of l)t.add(e(r))}}),_d=st({$prefix$:"",$test$:t=>t instanceof Map,$collect$:(t,e,a)=>{t.forEach((l,r)=>{J(l,e,a),J(r,e,a)})},$serialize$:(t,e)=>{const a=[];return t.forEach((l,r)=>{a.push(e(r)+" "+e(l))}),a.join(" ")},$prepare$:t=>{const e=new Map;return e[ca]=t,e},$fill$:(t,e)=>{const a=t[ca];t[ca]=void 0;const l=a.length===0?[]:a.split(" ");l.length%2;for(let r=0;r<l.length;r+=2)t.set(e(l[r]),e(l[r+1]))}}),wd=st({$prefix$:"\x1B",$test$:t=>!!Pi(t)||t===wl,$serialize$:t=>t,$prepare$:t=>t}),Sl=[ld,nd,sd,rd,id,od,ud,cd,dd,pd,fd,gd,xd,md,hd,bd,$d,yd,_d,wd,vd],ur=(()=>{const t=[];return Sl.forEach(e=>{const a=e.$prefixCode$;for(;t.length<a;)t.push(void 0);t.push(e)}),t})();function Pi(t){if(typeof t=="string"){const e=t.charCodeAt(0);if(e<ur.length)return ur[e]}}const Sd=Sl.filter(t=>t.$collect$),Td=t=>{for(const e of Sl)if(e.$test$(t))return!0;return!1},Dd=(t,e,a)=>{for(const l of Sd)if(l.$test$(t))return l.$collect$(t,e,a),!0;return!1},Pd=(t,e,a,l)=>{for(const r of Sl)if(r.$test$(t)){let o=r.$prefixChar$;return r.$serialize$&&(o+=r.$serialize$(t,e,a,l)),o}if(typeof t=="string")return t},ki=(t,e)=>{const a=new Map,l=new Map;return{prepare(r){const o=Pi(r);if(o){const c=o.$prepare$(r.slice(1),t,e);return o.$fill$&&a.set(c,o),o.$subs$&&l.set(c,o),c}return r},subs(r,o){const c=l.get(r);return!!c&&(c.$subs$(r,o,t),!0)},fill(r,o){const c=a.get(r);return!!c&&(c.$fill$(r,o,t),!0)}}},kd={"!":(t,e)=>e.$proxyMap$.get(t)??cn(t,e),"~":t=>Promise.resolve(t),_:t=>Promise.reject(t)},Ld=(t,e,a)=>{if(typeof a=="boolean")return a;const l=t.$groupToManagers$.get(a);return!!(l&&l.length>0)&&(l.length!==1||l[0]!==e)},Cd=t=>t===":slot"?ut:t===":fragment"?G:t,H_=(t,e)=>Gl(t,new Set,"_",e),Gl=(t,e,a,l)=>{const r=za(t);if(r==null)return t;if(Md(r)){if(e.has(r)||(e.add(r),Td(r)))return t;const o=typeof r;switch(o){case"object":if(ct(r)||Qe(r))return t;if(lt(r)){let p=0;return r.forEach((d,f)=>{if(f!==p)throw ot(3,r);Gl(d,e,a+"["+f+"]"),p=f+1}),t}if(Ea(r)){for(const[p,d]of Object.entries(r))Gl(d,e,a+"."+p);return t}break;case"boolean":case"string":case"number":return t}let c="";if(c=l||"Value cannot be serialized",a!=="_"&&(c+=` in ${a},`),o==="object")c+=` because it's an instance of "${t==null?void 0:t.constructor.name}". You might need to use 'noSerialize()' or use an object literal instead. Check out https://qwik.dev/docs/advanced/dollar/`;else if(o==="function"){const p=t.name;c+=` because it's a function named "${p}". You might need to convert it to a QRL using $(fn):

const ${p} = $(${String(t)});

Please check out https://qwik.dev/docs/advanced/qrl/ for more information.`}console.error("Trying to serialize",t),Sr(c)}return t},In=new WeakSet,Li=new WeakSet,Md=t=>!Ht(t)&&!vt(t)||!In.has(t),Ci=t=>In.has(t),Mi=t=>Li.has(t),Tl=t=>(t!=null&&In.add(t),t),jd=t=>(Li.add(t),t),za=t=>Ht(t)?ea(t)??t:t,ea=t=>t[El],$t=t=>t[qt],ji=t=>t[sa],Ad=(t,e)=>{const a=t[0],l=typeof t[1]=="string"?t[1]:e(t[1]);if(!l)return;let r=a+" "+l,o;if(a===0)o=t[2];else{const c=e(t[2]);if(!c)return;a<=2?(o=t[5],r+=` ${c} ${cr(e(t[3]))} ${t[4]}`):a<=4&&(o=t[4],r+=` ${c} ${typeof t[3]=="string"?t[3]:cr(e(t[3]))}`)}return o&&(r+=` ${encodeURI(o)}`),r},Ed=(t,e)=>{const a=t.split(" "),l=parseInt(a[0],10);a.length>=2;const r=e(a[1]);if(!r||yn(r)&&!r.$el$)return;const o=[l,r];return l===0?(a.length<=3,o.push(Al(a[2]))):l<=2?(a.length===5||a.length,o.push(e(a[2]),e(a[3]),a[4],Al(a[5]))):l<=4&&(a.length===4||a.length,o.push(e(a[2]),e(a[3]),Al(a[4]))),o},Al=t=>{if(t!==void 0)return decodeURI(t)},Nd=t=>{const e=new Map;return{$groupToManagers$:e,$createManager$:l=>new Id(e,t,l),$clearSub$:l=>{const r=e.get(l);if(r){for(const o of r)o.$unsubGroup$(l);e.delete(l),r.length=0}},$clearSignal$:l=>{const r=e.get(l[1]);if(r)for(const o of r)o.$unsubEntry$(l)}}};class Id{constructor(e,a,l){this.$groupToManagers$=e,this.$containerState$=a,this.$subs$=[],l&&this.$addSubs$(l)}$addSubs$(e){this.$subs$.push(...e);for(const a of this.$subs$)this.$addToGroup$(a[1],this)}$addToGroup$(e,a){let l=this.$groupToManagers$.get(e);l||this.$groupToManagers$.set(e,l=[]),l.includes(a)||l.push(a)}$unsubGroup$(e){const a=this.$subs$;for(let l=0;l<a.length;l++)a[l][1]===e&&(a.splice(l,1),l--)}$unsubEntry$(e){const[a,l,r,o]=e,c=this.$subs$;if(a===1||a===2){const p=e[4];for(let d=0;d<c.length;d++){const f=c[d];f[0]===a&&f[1]===l&&f[2]===r&&f[3]===o&&f[4]===p&&(c.splice(d,1),d--)}}else if(a===3||a===4)for(let p=0;p<c.length;p++){const d=c[p];d[0]===a&&d[1]===l&&d[2]===r&&d[3]===o&&(c.splice(p,1),p--)}}$addSub$(e,a){const l=this.$subs$,r=e[1];e[0]===0&&l.some(([o,c,p])=>o===0&&c===r&&p===a)||(l.push(Ai=[...e,a]),this.$addToGroup$(r,this))}$notifySubs$(e){const a=this.$subs$;for(const l of a){const r=l[l.length-1];e&&r&&r!==e||ku(l,this.$containerState$)}}}let Ai;function Bd(){return Ai}const cr=t=>{if(t==null)throw Ke("must be non null",t);return t},Bn=t=>typeof t=="function"&&typeof t.getSymbol=="function",Od=t=>Bn(t)&&t.$symbol$=="<sync>",Fa=(t,e,a,l,r,o,c)=>{let p;const d=async function(...v){return await y.call(this,bt())(...v)},f=v=>(p||(p=v),p),x=v=>typeof v!="function"||!(r!=null&&r.length)&&!(o!=null&&o.length)?v:function(...L){let k=bt();if(k){const T=k.$qrl$;k.$qrl$=d;const I=k.$event$;k.$event$===void 0&&(k.$event$=this);try{return v.apply(this,L)}finally{k.$qrl$=T,k.$event$=I}}return k=_t(),k.$qrl$=d,k.$event$=this,xt.call(this,k,v,...L)},m=async v=>{if(a!==null)return a;if(v&&f(v),t===""){const T=p.getAttribute(Pr),I=kr(p.ownerDocument,T);return d.resolved=a=I[Number(e)]}const L=zd(),k=bt();{const T=pl().importSymbol(p,t,e);a=X(T,I=>d.resolved=a=x(I))}return a.finally(()=>qd(e,k==null?void 0:k.$element$,L)),a},$=v=>a!==null?a:m(v);function y(v,L){return(...k)=>X($(),T=>{if(!vt(T))throw ot(10);if(L&&L()===!1)return;const I=P(v);return xt.call(this,I,T,...k)})}const P=v=>v==null?_t():lt(v)?ni(v):v,w=c??e,D=Ei(w);return Object.assign(d,{getSymbol:()=>w,getHash:()=>D,getCaptured:()=>o,resolve:m,$resolveLazy$:$,$setContainer$:f,$chunk$:t,$symbol$:e,$refSymbol$:c,$hash$:D,getFn:y,$capture$:r,$captureRef$:o,dev:null,resolved:void 0}),a&&(a=X(a,v=>d.resolved=a=x(v))),d},Ei=t=>{const e=t.lastIndexOf("_");return e>-1?t.slice(e+1):t};const dr=new Set,qd=(t,e,a)=>{dr.has(t)||(dr.add(t),Rd("qsymbol",{symbol:t,element:e,reqTime:a}))},Rd=(t,e)=>{Dt()||typeof document!="object"||document.dispatchEvent(new CustomEvent(t,{bubbles:!1,detail:e}))},zd=()=>Dt()?0:typeof performance=="object"?performance.now():0,Fd=function(t,e){return Fa("","<sync>",t,null,null,null,null)},b=t=>{function e(a,l,r){const o=t.$hash$.slice(0,4)+":"+(l||"");return i(Oe,{[jo]:t,[Pt]:a[Pt],[s]:a[s],children:a.children,props:a},r,o)}return e[rl]=[t],e},On=t=>typeof t=="function"&&t[rl]!==void 0,Ee=(t,e)=>{const{val:a,set:l,iCtx:r}=Xe();if(a!=null)return a;const o=vt(t)?xt(void 0,t):t;if((e==null?void 0:e.reactive)===!1)return l(o),o;{const c=cn(o,r.$renderCtx$.$static$.$containerState$,(e==null?void 0:e.deep)??!0?1:0);return l(c),c}};function qn(t,e){var l;const a=bt();return((l=a==null?void 0:a.$renderCtx$)==null?void 0:l.$static$.$containerState$.$serverData$[t])??e}const Qd=t=>{Gd(t,e=>e)},Gd=(t,e,a)=>{const{val:l,set:r,iCtx:o,i:c,elCtx:p}=Xe();if(l)return l;const d=Vo(t,c),f=o.$renderCtx$.$static$.$containerState$;if(r(d),p.$appendStyles$||(p.$appendStyles$=[]),p.$scopeIds$||(p.$scopeIds$=[]),f.$styleIds$.has(d))return d;f.$styleIds$.add(d);const x=t.$resolveLazy$(f.$containerEl$),m=$=>{p.$appendStyles$,p.$appendStyles$.push({styleId:d,content:e($,d)})};return ct(x)?o.$waitOn$.push(x.then(m)):m(x),d},pr={defaultLocale:{lang:"en",currency:"USD",timeZone:"America/Los_Angeles"},supportedLocales:[{lang:"en",currency:"USD",timeZone:"America/Los_Angeles"},{lang:"es",currency:"USD",timeZone:"America/Los_Angeles"}],assets:["app"]},Hd=({params:t,locale:e})=>{const a=pr.supportedLocales.find(r=>r.lang===t.lang);console.log(t);const l=a?a.lang:!t.lang&&pr.defaultLocale.lang;l&&e(l)},Vd=Object.freeze(Object.defineProperty({__proto__:null,onRequest:Hd},Symbol.toStringTag,{value:"Module"})),Wd='((i,a,r,s)=>{r=e=>{const t=document.querySelector("[q\\\\:base]");t&&a.active&&a.active.postMessage({type:"qprefetch",base:t.getAttribute("q:base"),...e})},document.addEventListener("qprefetch",e=>{const t=e.detail;a?r(t):i.push(t)}),navigator.serviceWorker.register("/service-worker.js").then(e=>{s=()=>{a=e,i.forEach(r),r({bundles:i})},e.installing?e.installing.addEventListener("statechange",t=>{t.target.state=="activated"&&s()}):e.active&&s()}).catch(e=>console.error(e))})([])',Ni=Vt("qc-s"),Ud=Vt("qc-c"),Ii=Vt("qc-ic"),Bi=Vt("qc-h"),Oi=Vt("qc-l"),qi=Vt("qc-n"),Ri=Vt("qc-a"),Yd=Vt("qc-ir"),Zd=t=>{const e=window,a=location.pathname+location.search,l="_qCitySPA",r="_qCityHistoryPatch",o="_qCityBootstrap",c="_qCityInitPopstate",p="_qCityInitAnchors",d="_qCityInitVisibility",f="_qCityInitScroll",x="_qCityScrollEnabled",m="_qCityScrollDebounce",$="_qCityScroll",y=D=>{D&&e.scrollTo(D.x,D.y)},P=()=>{const D=document.documentElement;return{x:D.scrollLeft,y:D.scrollTop,w:Math.max(D.scrollWidth,D.clientWidth),h:Math.max(D.scrollHeight,D.clientHeight)}},w=D=>{const v=history.state||{};v[$]=D||P(),history.replaceState(v,"")};if(!e[l]&&!e[c]&&!e[p]&&!e[d]&&!e[f]){if(w(),e[c]=()=>{var D;if(!e[l]){if(e[x]=!1,clearTimeout(e[m]),a!==location.pathname+location.search){const L=t.closest("[q\\:container]").querySelector('a[q\\:key="AD_1"]');if(L){const k=L.closest("[q\\:container]"),T=L.cloneNode();T.setAttribute("q:nbs",""),T.style.display="none",k.appendChild(T),e[o]=T,T.click()}else location.reload()}else if(history.scrollRestoration==="manual"){const v=(D=history.state)==null?void 0:D[$];y(v),e[x]=!0}}},!e[r]){e[r]=!0;const D=history.pushState,v=history.replaceState,L=k=>(k===null||typeof k>"u"?k={}:(k==null?void 0:k.constructor)!==Object&&(k={_data:k}),k._qCityScroll=k._qCityScroll||P(),k);history.pushState=(k,T,I)=>(k=L(k),D.call(history,k,T,I)),history.replaceState=(k,T,I)=>(k=L(k),v.call(history,k,T,I))}e[p]=D=>{if(e[l]||D.defaultPrevented)return;const v=D.target.closest("a[href]");if(v&&!v.hasAttribute("preventdefault:click")){const L=v.getAttribute("href"),k=new URL(location.href),T=new URL(L,k),I=T.origin===k.origin,E=T.pathname+T.search===k.pathname+k.search;if(I&&E)if(D.preventDefault(),T.href!==k.href&&history.pushState(null,"",T),!T.hash)T.href.endsWith("#")?window.scrollTo(0,0):(e[x]=!1,clearTimeout(e[m]),w({...P(),x:0,y:0}),location.reload());else{const N=T.hash.slice(1),j=document.getElementById(N);j&&j.scrollIntoView()}}},e[d]=()=>{!e[l]&&e[x]&&document.visibilityState==="hidden"&&w()},e[f]=()=>{e[l]||!e[x]||(clearTimeout(e[m]),e[m]=setTimeout(()=>{w(),e[m]=void 0},200))},e[x]=!0,setTimeout(()=>{addEventListener("popstate",e[c]),addEventListener("scroll",e[f],{passive:!0}),document.body.addEventListener("click",e[p]),e.navigation||document.addEventListener("visibilitychange",e[d],{passive:!0})},0)}},Kd=g(Zd,"s_DyVc0YBIqQU"),Jd=()=>{{const[t,e]=pl().chunkForSymbol(Kd.getSymbol(),null),a=_o+"build/"+e;return`(${Xd.toString()})('${a}','${t}');`}},Xd=async(t,e)=>{var a;if(!window._qcs&&history.scrollRestoration==="manual"){window._qcs=!0;const l=(a=history.state)==null?void 0:a._qCityScroll;l&&window.scrollTo(l.x,l.y);const r=document.currentScript;(await import(t))[e](r)}},tp=()=>{const t=Jd();z();const e=qn("nonce"),a=ga(Ii);if(a.value&&a.value.length>0){const l=a.value.length;let r=null;for(let o=l-1;o>=0;o--)a.value[o].default&&(r=i(a.value[o].default,{children:r},1,"zl_0"));return i(G,{children:[r,n("script",{dangerouslySetInnerHTML:t},{nonce:e},null,3,null)]},1,"zl_1")}return xn},V_=b(g(tp,"s_e0ssiDXoeAM")),Ha=new Map,zi="qaction",fr=t=>t.pathname+t.search+t.hash,Ne=(t,e)=>new URL(t,e.href),Fi=(t,e)=>t.origin===e.origin,gr=t=>t.endsWith("/")?t:t+"/",Qi=({pathname:t},{pathname:e})=>{const a=Math.abs(t.length-e.length);return a===0?t===e:a===1&&gr(t)===gr(e)},ep=(t,e)=>t.search===e.search,Gi=(t,e)=>ep(t,e)&&Qi(t,e),ap=(t,e,a)=>{let l=e??"";return a&&(l+=(l?"&":"?")+zi+"="+encodeURIComponent(a.id)),t+(t.endsWith("/")?"":"/")+"q-data.json"+l},lp=(t,e)=>{const a=t.href;if(typeof a=="string"&&typeof t.target!="string"&&!t.reload)try{const l=Ne(a.trim(),e.url),r=Ne("",e.url);if(Fi(l,r))return fr(l)}catch(l){console.error(l)}else if(t.reload)return fr(Ne("",e.url));return null},np=(t,e)=>{if(t){const a=Ne(t,e.url),l=Ne("",e.url);return!Gi(a,l)}return!1},sp=(t,e)=>{if(t){const a=Ne(t,e.url),l=Ne("",e.url);return!Qi(a,l)}return!1},rp=t=>t&&typeof t.then=="function",ip=(t,e,a,l)=>{const r=Hi(),c={head:r,withLocale:p=>Js(l,p),resolveValue:p=>{const d=p.__id;if(p.__brand==="server_loader"&&!(d in t.loaders))throw new Error("You can not get the returned data of a loader that has not been executed for this request.");const f=t.loaders[d];if(rp(f))throw new Error("Loaders returning a promise can not be resolved for the head function.");return f},...e};for(let p=a.length-1;p>=0;p--){const d=a[p]&&a[p].head;d&&(typeof d=="function"?xr(r,Js(l,()=>d(c))):typeof d=="object"&&xr(r,d))}return c.head},xr=(t,e)=>{typeof e.title=="string"&&(t.title=e.title),Va(t.meta,e.meta),Va(t.links,e.links),Va(t.styles,e.styles),Va(t.scripts,e.scripts),Object.assign(t.frontmatter,e.frontmatter)},Va=(t,e)=>{if(Array.isArray(e))for(const a of e){if(typeof a.key=="string"){const l=t.findIndex(r=>r.key===a.key);if(l>-1){t[l]=a;continue}}t.push(a)}},Hi=()=>({title:"",meta:[],links:[],styles:[],scripts:[],frontmatter:{}});let mr;(function(t){t[t.EOL=0]="EOL",t[t.OPEN_BRACKET=91]="OPEN_BRACKET",t[t.CLOSE_BRACKET=93]="CLOSE_BRACKET",t[t.DOT=46]="DOT",t[t.SLASH=47]="SLASH"})(mr||(mr={}));const op=t=>{},up=async(t,e,a)=>{const l=t.pathname,r=t.search,o=ap(l,r,a==null?void 0:a.action);let c;a!=null&&a.action||(c=Ha.get(o)),a==null||a.prefetchSymbols;let p;if(!c){const d=cp(a==null?void 0:a.action);a!=null&&a.action&&(a.action.data=void 0),c=fetch(o,d).then(f=>{const x=new URL(f.url),m=x.pathname.endsWith("/q-data.json");if(x.origin!==location.origin||!m){location.href=x.href;return}if((f.headers.get("content-type")||"").includes("json"))return f.text().then($=>{const y=bu($,e);if(!y){location.href=t.href;return}if(a!=null&&a.clearCache&&Ha.delete(o),y.redirect)location.href=y.redirect;else if(a!=null&&a.action){const{action:P}=a,w=y.loaders[P.id];p=()=>{P.resolve({status:f.status,result:w})}}return y});location.href=t.href}),a!=null&&a.action||Ha.set(o,c)}return c.then(d=>(d||Ha.delete(o),p&&p(),d))},cp=t=>{const e=t==null?void 0:t.data;if(e)return e instanceof FormData?{method:"POST",body:e}:{method:"POST",body:JSON.stringify(e),headers:{"Content-Type":"application/json, charset=UTF-8"}}},W_=()=>ga(Bi),rt=()=>ga(Oi),Vi=()=>ga(qi),dp=()=>ga(Ri),Wi=()=>Tl(qn("qwikcity")),pp=":root{view-transition-name:none}",fp=async(t,e)=>{const[a,l,r,o]=U(),{type:c="link",forceReload:p=t===void 0,replaceState:d=!1,scroll:f=!0}=typeof e=="object"?e:{forceReload:e},x=r.value.dest,m=t===void 0?x:Ne(t,o.url);if(Fi(m,x)&&!(!p&&Gi(m,x)))return r.value={type:c,dest:m,forceReload:p,replaceState:d,scroll:f},a.value=void 0,o.isNavigating=!0,new Promise($=>{l.r=$})},gp=({track:t})=>{const[e,a,l,r,o,c,p,d,f,x,m]=U();async function $(){const[P,w]=t(()=>[x.value,e.value]),D=Uu(""),v=m.url,L=w?"form":P.type;P.replaceState;let k,T,I=null;if(k=new URL(P.dest,m.url),I=o.loadedRoute,T=o.response,I){const[E,N,j,O]=I,W=j,K=W[W.length-1];m.prevUrl=v,m.url=k,m.params={...N},x.untrackedValue={type:L,dest:k};const Y=ip(T,m,W,D);a.headings=K.headings,a.menu=O,l.value=Tl(W),r.links=Y.links,r.meta=Y.meta,r.styles=Y.styles,r.scripts=Y.scripts,r.title=Y.title,r.frontmatter=Y.frontmatter}}return $()},xp=t=>{Qd(g(pp,"s_RPDJAz33WLA"));const e=Wi();if(!(e!=null&&e.params))throw new Error("Missing Qwik City Env Data");const a=qn("url");if(!a)throw new Error("Missing Qwik URL Env Data");const l=new URL(a),r=Ee({url:l,params:e.params,isNavigating:!1,prevUrl:void 0},{deep:!1}),o={},c=jd(Ee(e.response.loaders,{deep:!1})),p=C({type:"initial",dest:l,forceReload:!1,replaceState:!1,scroll:!0}),d=Ee(Hi),f=Ee({headings:void 0,menu:void 0}),x=C(),m=e.response.action,$=m?e.response.loaders[m]:void 0,y=C($?{id:m,data:e.response.formData,output:{result:$,status:e.response.status}}:void 0),P=g(fp,"s_fX0bDjeJa0E",[y,o,p,r]);return Ae(Ud,f),Ae(Ii,x),Ae(Bi,d),Ae(Oi,r),Ae(qi,P),Ae(Ni,c),Ae(Ri,y),Ae(Yd,p),vn(g(gp,"s_02wMImzEAbk",[y,f,x,d,e,P,c,o,t,p,r])),i(ut,null,3,"qY_0")},U_=b(g(xp,"s_TxCFOy819ag")),mp=(t,e)=>{var a;if(!((a=navigator.connection)!=null&&a.saveData)&&e&&e.href){const l=new URL(e.href);op(l.pathname),e.hasAttribute("data-prefetch")&&up(l,e,{prefetchSymbols:!1})}},hp=async(t,e)=>{const[a,l,r,o]=U();t.defaultPrevented&&(e.hasAttribute("q:nbs")?await a(location.href,{type:"popstate"}):e.href&&(e.setAttribute("aria-pressed","true"),await a(e.href,{forceReload:l,replaceState:r,scroll:o}),e.removeAttribute("aria-pressed")))},bp=t=>{const e=Vi(),a=rt(),{onClick$:l,prefetch:r,reload:o,replaceState:c,scroll:p,...d}=t,f=ya(()=>lp({...d,reload:o},a));d["link:app"]=!!f,d.href=f||t.href;const x=ya(()=>!!f&&r!==!1&&r!=="js"&&np(f,a)||void 0),$=ya(()=>x||!!f&&r!==!1&&sp(f,a))?g(mp,"s_Osdg8FnYTw4"):void 0,y=f?Fd((w,D)=>{w.metaKey||w.ctrlKey||w.shiftKey||w.altKey||w.preventDefault()}):void 0;return Z("a",{...d,children:i(ut,null,3,"AD_0"),"data-prefetch":x,onClick$:[y,l,f?g(hp,"s_pIf0khHUxfY",[e,o,c,p]):void 0],onFocus$:[d.onFocus$,$],onMouseOver$:[d.onMouseOver$,$],onQVisible$:[d.onQVisible$,$]},null,0,"AD_1")},Rt=b(g(bp,"s_8gdLBszqbaM")),Y_=t=>n("script",{nonce:S(t,"nonce")},{dangerouslySetInnerHTML:Wd},null,3,"1Z_0"),$p=(t={})=>{throw U(),new Error(`Actions can not be invoked within the server during SSR.
Action.run() can only be called on the browser, for example when a user clicks a button, or submits a form.`)},vp=(t,...e)=>{const{id:a,validators:l}=Yi(e,t);function r(){const o=rt(),c=dp(),p={actionPath:`?${zi}=${a}`,isRunning:!1,status:void 0,value:void 0,formData:void 0},d=Ee(()=>{const x=c.value;if(x&&(x==null?void 0:x.id)===a){const m=x.data;if(m instanceof FormData&&(p.formData=m),x.output){const{status:$,result:y}=x.output;p.status=$,p.value=y}}return p}),f=g($p,"s_A5bZC7WO00A",[c,a,o,d]);return p.submit=f,d}return r.__brand="server_action",r.__validators=l,r.__qrl=t,r.__id=a,Object.freeze(r),r},Ui=(t,...e)=>{const a=vp(t,...e);return typeof globalThis._qwikActionsMap>"u"&&(globalThis._qwikActionsMap=new Map),globalThis._qwikActionsMap.set(a.__id,a),a},R=(t,...e)=>{const{id:a,validators:l}=Yi(e,t);function r(){return ga(Ni,o=>{if(!(a in o))throw new Error(`routeLoader$ "${t.getSymbol()}" was invoked in a route where it was not declared.
    This is because the routeLoader$ was not exported in a 'layout.tsx' or 'index.tsx' file of the existing route.
    For more information check: https://qwik.builder.io/qwikcity/route-loader/

    If your are managing reusable logic or a library it is essential that this function is re-exported from within 'layout.tsx' or 'index.tsx file of the existing route otherwise it will not run or throw exception.
    For more information check: https://qwik.builder.io/docs/cookbook/re-exporting-loaders/`);return S(o,a)})}return r.__brand="server_loader",r.__qrl=t,r.__validators=l,r.__id=a,Object.freeze(r),r},yp=async function(...t){var a;const[e]=U();t.length>0&&t[0]instanceof AbortSignal&&t.shift();{const l=[(a=Wi())==null?void 0:a.ev,this,ec()].find(r=>r&&Object.prototype.hasOwnProperty.call(r,"sharedMap")&&Object.prototype.hasOwnProperty.call(r,"cookie"));return e.apply(l,t)}},Z_=t=>{{const a=t.getCaptured();if(a&&a.length>0&&!tc())throw new Error("For security reasons, we cannot serialize QRLs that capture lexical scope.")}function e(){return g(yp,"s_wOIPfiQ04l4",[t])}return e()},Yi=(t,e)=>{let a;const l=[];if(t.length===1){const r=t[0];r&&typeof r=="object"&&("validate"in r?l.push(r):(a=r.id,r.validation&&l.push(...r.validation)))}else t.length>1&&l.push(...t.filter(r=>!!r));return typeof a=="string"?a=`id_${a}`:a=e.getHash(),{validators:l.reverse(),id:a}},_p=({action:t,spaReset:e,reloadDocument:a,onSubmit$:l,...r},o)=>(z(),t?Z("form",{...r,action:S(t,"actionPath"),"preventdefault:submit":!a,"data-spa-reset":e?"true":void 0,onSubmit$:[a?void 0:t.submit,l]},{method:"post"},0,o):i(Tp,{onSubmit$:l,reloadDocument:a,spaReset:e,...r},0,o)),wp=async(t,e)=>{const[a]=U(),l=new FormData(e),r=new URLSearchParams;l.forEach((o,c)=>{typeof o=="string"&&r.append(c,o)}),a("?"+r.toString(),{type:"form",forceReload:!0}).then(()=>{e.getAttribute("data-spa-reset")==="true"&&e.reset(),e.dispatchEvent(new CustomEvent("submitcompleted",{bubbles:!1,cancelable:!1,composed:!1,detail:{status:200}}))})},Sp=t=>{const e=Fo(t,["action","spaReset","reloadDocument","onSubmit$"]),a=Vi();return Z("form",{...e,children:i(ut,null,3,"BC_0"),onSubmit$:g(wp,"s_p9MSze0ojs4",[a])},{action:"get","data-spa-reset":u(l=>l.spaReset?"true":void 0,[t],'p0.spaReset?"true":undefined'),"preventdefault:submit":u(l=>!l.reloadDocument,[t],"!p0.reloadDocument")},0,"BC_1")},Tp=b(g(Sp,"s_Nk9PlpjQm9Y")),Dp=t=>n("div",null,{class:"w-fit h-fit flex items-center justify-center",role:"status"},n("svg",null,{"aria-hidden":"true",class:u(e=>`w-[${e.size}] h-[${e.size}] text-gray-200 animate-spin dark:text-blue-300 fill-primary-blue`,[t],"`w-[${p0.size}] h-[${p0.size}] text-gray-200 animate-spin dark:text-blue-300 fill-primary-blue`"),viewBox:"0 0 100 101",fill:"none",xmlns:"http://www.w3.org/2000/svg"},[n("path",null,{d:"M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",fill:"currentColor"},null,3,null),n("path",null,{d:"M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",fill:"currentFill"},null,3,null)],3,null),3,"73_0"),At=b(g(Dp,"s_kpSoQCQrots")),Pp="https://strapi.rtatel.com",kp="http://10.5.24.40:1337",Lp=`${kp}/graphql`,gt=t=>`${Pp}${t}`,Ca=t=>t==="es"?"es-419":t,_=`
data {
    attributes {
        url
        alternativeText
        caption
        formats
    }
}
`,V=t=>{let e=[],a=!0;return t.schema&&(t.schema.includes('<script type="application/ld+json">')&&(a=!1),e=t.schema.split(a?"<script>":'<script type="application/ld+json">').flatMap(l=>l.split(a?"<script>":'<script type="application/ld+json">')).flatMap(l=>l.replace("<\/script>","")).reduce((l,r)=>r?[...l,r]:l,[])),e.flat(),{title:t.MetaTitle,scripts:[...e.map(l=>({props:a?{}:{type:"application/ld+json"},script:l}))],meta:[{name:"description",content:t.MetaDescription},{name:"keywords",content:t.Keywords}]}},H=`
SEO {
    MetaTitle
    MetaDescription
    Keywords
    preventIndexing
    schema
}
`,aa=`
data{
      attributes{
       	Content{
          Titles{
            Text
          }
          TextContent
        }
`,Zi=`
MembersGrid{
           Picture{
         ${_}
        }
        FirstName
        LastName
        Position
        SocialMedia{
          Icon{
            ${_}
          }
          Link
        }
      }
`,Cp=t=>`
sectionNetwork (locale:"${t}"){
  data {
    attributes {
      Map {
        MapPicture {
          ${_}
        }
        ServersTitle
        Servers (pagination:{limit:50}){
          Text
          Link
          Icon{
            ${_}
          }
        }
      }
      Description{
        Title
        Paragraph
      }
    }
  }
}
`,Mp=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],jp=["January","February","March","April","May","June","July","August","September","October","November","December"];function Hl(t,e=!0){const a=new Date(t),l=Mp[a.getDay()],r=a.getDate(),o=jp[a.getMonth()],c=a.getFullYear();return`${e?l+", ":""}${e?o:o.slice(0,3)} ${r}, ${c}`}const Ap=()=>n("div",null,{class:"flex absolute flex-col items-center justify-center m-auto gap-2 h-full w-full bg-gradient-radial from-white via-slate-200 to-slate-300"},[n("img",null,{src:gt("/uploads/RTA_db22afd96e.webp"),alt:"RTA image loading",width:250,height:200},null,3,null),i(At,{size:"150px",[s]:{size:s}},3,"yL_0")],1,"yL_1"),Ep=b(g(Ap,"s_BeMhGs9mjvk")),Np=async({cacheControl:t})=>{t({staleWhileRevalidate:604800,maxAge:5})},Ip=()=>({date:new Date().toISOString()}),Bp=R(g(Ip,"s_GQamrjryd1Y")),Op=()=>{const[t]=U();t.value=!0},qp=()=>{z();const t=C(!0);return vn(g(Op,"s_lROQwus8zWc",[t])),wt(B("s_Ku7AU0gi0Go",[t])),i(G,{children:t.value?n("div",null,{id:"splash",class:"h-full w-full flex"},i(Ep,null,3,"XF_0"),1,"XF_1"):i(ut,null,3,"XF_2")},1,"XF_3")},Rp=b(g(qp,"s_VkLNXphUh5s")),zp=Object.freeze(Object.defineProperty({__proto__:null,default:Rp,onGet:Np,useServerTimeLoader:Bp},Symbol.toStringTag,{value:"Module"})),Fp=()=>{const t=["https://images.unsplash.com/photo-1693825948507-acd866203fae?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8MXx8fGVufDB8fHx8fA%3D%3D","https://images.unsplash.com/photo-1694476053120-d729a3f6a7ed?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8fA%3D%3D","https://images.unsplash.com/photo-1695256294687-5df561945542?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8MTB8fHxlbnwwfHx8fHw%3D"],e=C(0);return wt(B("s_aXdoh0xz8cQ",[t,e])),n("div",null,null,n("img",{src:t[e.value]},{class:"transition-opacity duration-2000 ease-in-out opacity-100",alt:"Slider",width:150,height:150},null,3,null),1,"Sz_0")},Qp=b(g(Fp,"s_X6NIVA8H4IM")),Gp=()=>i(G,{children:i(Qp,null,3,"Ch_0")},1,"Ch_1"),Hp=b(g(Gp,"s_nUdxvD3SCSo")),Vp=Object.freeze(Object.defineProperty({__proto__:null,default:Hp},Symbol.toStringTag,{value:"Module"})),Wp=async(t,e,a)=>{const r=await fetch(`https://autosuggest.search.hereapi.com/v1/autosuggest?apiKey=IbuSA9oJnZ_SSAN3hiD9EFv0fxE0mijeZF2QQjcjl6Y&q=${t}&at=${e},${a}&in=countryCode:USA`);if(r.status!==200)return[];let c=(await r.json()).items;return c=c.filter(d=>d.resultType!=="locality"&&d.resultType!=="intersection"&&d.resultType!=="postalCodePoint"),c.map(d=>{var f,x,m,$;if(d.resultType=="place"){const y=d.address.label;if(y!=null||y!=""){const P=y.split(",").slice(1).join(",").trim();d.address.label=P}}return{resultType:d.resultType,address:((f=d.address)==null?void 0:f.label)||"",zip:(($=(m=(x=d.address)==null?void 0:x.label)==null?void 0:m.split(", ")[2])==null?void 0:$.split(" ")[1])||"",position:d.position}})},Up=async({json:t,query:e})=>{const a=e.get("q");if(!a)t(400,{message:"Bad request (need ?q param)"});else{const l=await Wp(a,29.62540053919014,-95.39478748016545);t(200,{data:l})}},Yp=Object.freeze(Object.defineProperty({__proto__:null,onGet:Up},Symbol.toStringTag,{value:"Module"})),Ki=t=>`
query QueryLayout {
    generalMenu(locale: "${t}") {
      data {
        attributes {
          TopOptions {
            Icon {
              ${_}
            }
            Text
            Link
          }
  
          localizations {
            data {
              attributes {
                MainOptions {
                  Text
                  Link
                  SubOption {
                    Text
                    Link
                  }
                }
              }
            }
          }
  
          MainMenu {
            Logo {
              ${_}
            }
            Switcher {
              Text
              Link
              Icon {
                ${_}
              }
            }
          }
          MainOptions {
            Text
            Link
            SubOption {
              Text
              Link
              MenuOption {
                data {
                  attributes {
                    SubOption {
                      Text
                      Link
                    }
                  }
                }
              }
            }
          }
          ClientOptions {
            Text
            Link
          }
          gigfastOptions {
            Text
            Link
            Icon {
              ${_}
            }
          }
        }
      }
    }
    generalFooter(locale: "${t}") {
      data {
        attributes {
          SupportSection {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          CorpInfo {
            Media {
              ${_}
            }
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          Menus {
            Text
            SubOption {
              Text
              Link
            }
          }
          SocialMedia {
            Text
            SubOption {
              Icon {
                ${_}
              }
              Link
            }
          }
        }
      }
    }
    generalHeader(locale: "${t}")  {
      data {
        attributes {
          Slide {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          CallButton{
            Text
            Link
          }
        }
      }
    }
  } 
`;async function Ma(t){return await(await fetch(Lp,{method:"POST",cache:"no-cache",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:t})})).json()}async function Q(t,e="en",a=!0){let l={};a&&(l=await Ma(Ki(Ca(e))));const r=await Ma(t(Ca(e)));return{layoutData:l,pageData:r}}async function Qa(t,e="en",a=!0){let l={};a&&(l=await Ma(Ki(Ca(e))));const r=await Ma(t);return{layoutData:l,pageData:r}}const Zp=async t=>{const e=await t.parseBody(),a=await Ma(e.query);t.json(200,a)},Kp=Object.freeze(Object.defineProperty({__proto__:null,onPost:Zp},Symbol.toStringTag,{value:"Module"}));async function Jp(t,e,a,l,r,o){const p=`https://supa42.rtatel.com/notifications/api${o?"/attachment":""}`,d={action:"rtaMail",subject:e,template:t,mailto:a,variables:l};o&&(d.attachment={filename:"resume.pdf",file:o});try{const f=await fetch(p,{method:"POST",body:JSON.stringify(d),headers:{"Content-Type":"application/json"}});if(f.ok){location.reload();const x=r.includes("es")?"¡Enviado Correctamente!":"Successfully Sent!";alert(x)}else{const x=await f.json(),m=r.includes("es")?"Error al enviar el formulario: ":"Error while trying to send the form: ";alert(`${m} ${x.message}`)}}catch(f){console.error("Error en la solicitud:",f),alert("Hubo un error al enviar el formulario.")}}const Xp=Object.freeze(Object.defineProperty({__proto__:null,sendMail:Jp},Symbol.toStringTag,{value:"Module"})),tf=async({request:t,json:e})=>{const a=await t.json();e(200,{body:a})},ef=Object.freeze(Object.defineProperty({__proto__:null,onPost:tf},Symbol.toStringTag,{value:"Module"})),af=t=>n("img",{src:gt(t.media.url),srcset:t.media.formats&&t.media.formats.small&&`${gt(t.media.formats.small.url)} 40w, ${gt(t.media.url)} 800w`},{width:u(e=>e.width??150,[t],"p0.width??150"),height:u(e=>e.height??150,[t],"p0.height??150"),title:u(e=>e.media.caption,[t],'p0.media["caption"]'),alt:u(e=>e.media.alternativeText,[t],'p0.media["alternativeText"]'),class:u(e=>(e.toWhite??!1?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+(e.clasN??""),[t],'(p0.toWhite??false?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+""+(p0.clasN??"")'),sizes:"(max-width: 600px) 40px, 800px"},null,3,"cI_0"),A=b(g(af,"s_LQFPgtOeNdI")),lf=t=>Z("svg",{...t,children:n("path",null,{d:"M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"xG_0"),nf=t=>Z("svg",{...t,children:n("path",null,{d:"M201.4 342.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 274.7 86.6 137.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"xH_0"),sf=t=>Z("svg",{...t,children:n("path",null,{d:"M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"GB_0"),rf=t=>Z("svg",{...t,children:n("path",null,{d:"M96 32V64H48C21.5 64 0 85.5 0 112v48H448V112c0-26.5-21.5-48-48-48H352V32c0-17.7-14.3-32-32-32s-32 14.3-32 32V64H160V32c0-17.7-14.3-32-32-32S96 14.3 96 32zM448 192H0V464c0 26.5 21.5 48 48 48H400c26.5 0 48-21.5 48-48V192z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"nO_0"),of=t=>Z("svg",{...t,children:n("path",null,{d:"M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"p8_0"),uf=t=>Z("svg",{...t,children:n("path",null,{d:"M0 256a256 256 0 1 0 512 0A256 256 0 1 0 0 256zM281 385c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l71-71L136 280c-13.3 0-24-10.7-24-24s10.7-24 24-24l182.1 0-71-71c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0L393 239c9.4 9.4 9.4 24.6 0 33.9L281 385z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 512 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"tx_0"),cf=t=>Z("svg",{...t,children:n("path",null,{d:"M256 448c141.4 0 256-93.1 256-208S397.4 32 256 32S0 125.1 0 240c0 45.1 17.7 86.8 47.7 120.9c-1.9 24.5-11.4 46.3-21.4 62.9c-5.5 9.2-11.1 16.6-15.2 21.6c-2.1 2.5-3.7 4.4-4.9 5.7c-.6 .6-1 1.1-1.3 1.4l-.3 .3 0 0 0 0 0 0 0 0c-4.6 4.6-5.9 11.4-3.4 17.4c2.5 6 8.3 9.9 14.8 9.9c28.7 0 57.6-8.9 81.6-19.3c22.9-10 42.4-21.9 54.3-30.6c31.8 11.5 67 17.9 104.1 17.9zM128 208a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 0a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm96 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 512 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Bu_0"),Rn=t=>Z("svg",{...t,children:n("path",null,{d:"M429.6 92.1c4.9-11.9 2.1-25.6-7-34.7s-22.8-11.9-34.7-7l-352 144c-14.2 5.8-22.2 20.8-19.3 35.8s16.1 25.8 31.4 25.8H224V432c0 15.3 10.8 28.4 25.8 31.4s30-5.1 35.8-19.3l144-352z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"ak_0"),Dl=t=>Z("svg",{...t,children:n("path",null,{d:"M384 192c0 87.4-117 243-168.3 307.2c-12.3 15.3-35.1 15.3-47.4 0C117 435 0 279.4 0 192C0 86 86 0 192 0S384 86 384 192z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 384 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"6Z_0"),df=t=>Z("svg",{...t,children:n("path",null,{d:"M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 384 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"4m_0"),pf=t=>{const e=C(!1);return n("div",null,{class:"relative w-fit"},[n("span",null,{class:u(a=>`${a.containerClass??""} flex cursor-pointer items-center gap-2`,[t],'`${p0.containerClass??""} flex cursor-pointer items-center gap-2`'),onClick$:B("s_F3aQ057DSxY",[e]),onFocusout$:B("s_eygkshVHA6I",[e])},[n("span",null,null,u(a=>a.title,[t],"p0.title"),3,null),i(nf,null,3,"bO_0")],1,null),n("div",null,{class:u(a=>`absolute bottom-0 left-0 right-0 top-full z-10 min-w-[140px]  rounded-md bg-white shadow-lg transition-all duration-300 ${a.value?"":"hidden"}`,[e],'`absolute bottom-0 left-0 right-0 top-full z-10 min-w-[140px]  rounded-md bg-white shadow-lg transition-all duration-300 ${p0.value?"":"hidden"}`')},i(ut,null,3,"bO_1"),1,null)],1,"bO_2")},il=b(g(pf,"s_f0Yr0C5H5Es")),ff=()=>{const[t]=U();let e="";t?e="/"+window.location.pathname.split("/es/")[1]:e="/es"+window.location.pathname,window.location.pathname=e},gf=t=>{var r;const a=(r=rt().prevUrl)==null?void 0:r.pathname.includes("/es/");return n("div",null,{class:"relative flex cursor-pointer items-center justify-center self-center rounded-full bg-gray-100 shadow-sm",onClick$:g(ff,"s_W5KXXUmo6j8",[a])},[i(A,{get media(){return t.data[0].Icon.data.attributes},clasN:`h-[36px] w-[36px] m-1 rounded-full ${a?"opacity-30":"border-2 border-primary-blue border-opacity-50"}`,[s]:{media:u(o=>o.data[0].Icon.data.attributes,[t],'p0.data[0]["Icon"]["data"]["attributes"]')}},3,"tf_0"),i(A,{get media(){return t.data[1].Icon.data.attributes},clasN:`h-[36px] w-[36px] m-1 rounded-full ${a?"border-2 border-primary-blue border-opacity-50":"opacity-30"}  `,[s]:{media:u(o=>o.data[1].Icon.data.attributes,[t],'p0.data[1]["Icon"]["data"]["attributes"]')}},3,"tf_1")],1,"tf_2")},xf=b(g(gf,"s_mIn2RUIc9QU")),mf=t=>{z();const e=C(!0);return n("div",null,{class:"bg-blue-900 h-[550px] w-full sm:w-4/5 flex flex-col justify-between items-center p-6 rounded-2xl"},[n("h2",null,{class:"text-white font-bold text-xl md:text-4xl mb-2"},"Get in contact with us",3,null),e.value?i(At,{size:"250px",[s]:{size:s}},3,"iV_0"):null,n("iframe",null,{id:"portability-request",class:"w-full h-full overflow-x-visible overflow-y-visible",src:u(a=>a.link,[t],"p0.link"),onLoad$:B("s_fXnkVThI4oM",[e])},null,3,null)],1,"iV_1")},hf=b(g(mf,"s_fvFnDV0yuRY")),bf=t=>Z("svg",{...t,children:n("path",null,{d:"M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v5.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V4.5z"},null,3,null)},{class:"bi bi-arrow-down-circle-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"4H_0"),$f=t=>Z("svg",{...t,children:n("path",null,{d:"M8 4a.5.5 0 0 1 .5.5v5.793l2.146-2.147a.5.5 0 0 1 .708.708l-3 3a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L7.5 10.293V4.5A.5.5 0 0 1 8 4z","fill-rule":"evenodd"},null,3,null)},{class:"bi bi-arrow-down-short","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Iw_0"),vf=t=>Z("svg",{...t,children:n("path",null,{d:"M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z","fill-rule":"evenodd"},null,3,null)},{class:"bi bi-arrow-right-short","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Gz_0"),Ji=t=>Z("svg",{...t,children:n("path",null,{d:"M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"},null,3,null)},{class:"bi bi-check-circle-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Dp_0"),hr=t=>Z("svg",{...t,children:n("path",null,{d:"M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"},null,3,null)},{class:"bi bi-check","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"0U_0"),Xi=t=>Z("svg",{...t,children:[n("path",null,{d:"M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"},null,3,null),n("path",null,{d:"M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"},null,3,null)]},{class:"bi bi-download","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"ME_0"),Vl=t=>Z("svg",{...t,children:[n("path",null,{d:"M2 2A2 2 0 0 0 .05 3.555L8 8.414l7.95-4.859A2 2 0 0 0 14 2H2Zm-2 9.8V4.698l5.803 3.546L0 11.801Zm6.761-2.97-6.57 4.026A2 2 0 0 0 2 14h6.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.606-3.446l-.367-.225L8 9.586l-1.239-.757ZM16 9.671V4.697l-5.803 3.546.338.208A4.482 4.482 0 0 1 12.5 8c1.414 0 2.675.652 3.5 1.671Z"},null,3,null),n("path",null,{d:"M15.834 12.244c0 1.168-.577 2.025-1.587 2.025-.503 0-1.002-.228-1.12-.648h-.043c-.118.416-.543.643-1.015.643-.77 0-1.259-.542-1.259-1.434v-.529c0-.844.481-1.4 1.26-1.4.585 0 .87.333.953.63h.03v-.568h.905v2.19c0 .272.18.42.411.42.315 0 .639-.415.639-1.39v-.118c0-1.277-.95-2.326-2.484-2.326h-.04c-1.582 0-2.64 1.067-2.64 2.724v.157c0 1.867 1.237 2.654 2.57 2.654h.045c.507 0 .935-.07 1.18-.18v.731c-.219.1-.643.175-1.237.175h-.044C10.438 16 9 14.82 9 12.646v-.214C9 10.36 10.421 9 12.485 9h.035c2.12 0 3.314 1.43 3.314 3.034v.21Zm-4.04.21v.227c0 .586.227.8.581.8.31 0 .564-.17.564-.743v-.367c0-.516-.275-.708-.572-.708-.346 0-.573.245-.573.791Z"},null,3,null)]},{class:"bi bi-envelope-at-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"9e_0"),zn=t=>Z("svg",{...t,children:n("path",null,{d:"M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"},null,3,null)},{class:"bi bi-geo-alt-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"62_0"),Pl=t=>Z("svg",{...t,children:[n("path",null,{d:"M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"},null,3,null),n("path",null,{d:"m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6Z"},null,3,null)]},{class:"bi bi-house-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"fX_0"),to=t=>Z("svg",{...t,children:n("path",null,{d:"M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"},null,3,null)},{class:"bi bi-info-circle-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"SU_0"),yf=t=>Z("svg",{...t,children:n("path",null,{d:"M2 6a6 6 0 1 1 10.174 4.31c-.203.196-.359.4-.453.619l-.762 1.769A.5.5 0 0 1 10.5 13h-5a.5.5 0 0 1-.46-.302l-.761-1.77a1.964 1.964 0 0 0-.453-.618A5.984 5.984 0 0 1 2 6zm3 8.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1l-.224.447a1 1 0 0 1-.894.553H6.618a1 1 0 0 1-.894-.553L5.5 15a.5.5 0 0 1-.5-.5z"},null,3,null)},{class:"bi bi-lightbulb-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"IC_0"),Wl=t=>Z("svg",{...t,children:n("path",null,{d:"M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"},null,3,null)},{class:"bi bi-person-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"iB_0"),_f=t=>Z("svg",{...t,children:n("path",null,{d:"M0 12V4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm6.79-6.907A.5.5 0 0 0 6 5.5v5a.5.5 0 0 0 .79.407l3.5-2.5a.5.5 0 0 0 0-.814l-3.5-2.5z"},null,3,null)},{class:"bi bi-play-btn-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"YD_0"),wf=t=>Z("svg",{...t,children:n("path",null,{d:"M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"},null,3,null)},{class:"bi bi-search","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"l7_0"),Ul=t=>Z("svg",{...t,children:n("path",null,{d:"M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"},null,3,null)},{class:"bi bi-star-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"jB_0"),Sf=t=>Z("svg",{...t,children:n("path",null,{d:"M5.354 5.119 7.538.792A.516.516 0 0 1 8 .5c.183 0 .366.097.465.292l2.184 4.327 4.898.696A.537.537 0 0 1 16 6.32a.548.548 0 0 1-.17.445l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256a.52.52 0 0 1-.146.05c-.342.06-.668-.254-.6-.642l.83-4.73L.173 6.765a.55.55 0 0 1-.172-.403.58.58 0 0 1 .085-.302.513.513 0 0 1 .37-.245l4.898-.696zM8 12.027a.5.5 0 0 1 .232.056l3.686 1.894-.694-3.957a.565.565 0 0 1 .162-.505l2.907-2.77-4.052-.576a.525.525 0 0 1-.393-.288L8.001 2.223 8 2.226v9.8z"},null,3,null)},{class:"bi bi-star-half","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"VK_0"),Tf=t=>Z("svg",{...t,children:n("path",null,{d:"M2 1a1 1 0 0 0-1 1v4.586a1 1 0 0 0 .293.707l7 7a1 1 0 0 0 1.414 0l4.586-4.586a1 1 0 0 0 0-1.414l-7-7A1 1 0 0 0 6.586 1H2zm4 3.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"},null,3,null)},{class:"bi bi-tag-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"vL_0"),kl=t=>Z("svg",{...t,children:n("path",null,{d:"M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z","fill-rule":"evenodd"},null,3,null)},{class:"bi bi-telephone-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"nW_0"),Df=t=>Z("svg",{...t,children:[n("path",null,{d:"M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"},null,3,null),n("path",null,{d:"M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"},null,3,null)]},{class:"bi bi-upload","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"pX_0"),eo=t=>Z("svg",{...t,children:n("path",null,{d:"M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"},null,3,null)},{class:"bi bi-x-lg","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"fv_0"),Pf=t=>n("div",{dangerouslySetInnerHTML:yr(t.text),class:`flex list-outside flex-col gap-3 text-primary-blue tracking-[0.15px] font-[350]
                [&>*>a]:text-secondary-red
                min-[1000px]:[&>h1]:text-[45px]
                [&>h1]:text-[15px]
                [&>h1]:leading-tight
                [&>h1]:font-[400]
                [&>h2]:text-[26px]
                [&>h3]:text-[26px]
                [&>ul]:flex
                [&>ul]:flex-col
                [&>ul]:gap-3 
                ${t.classN??""}`},null,null,3,"Cb_0"),M=b(g(Pf,"s_RjmVkFh5HBg")),kf=t=>{const[e]=U(),a=t.target.value.replace(/\D/g,"");let l="";a.length>0&&(l="("+a.substring(0,3)),a.length>=3&&(l+=") "+a.substring(3,6)),a.length>=7&&(l+="-"+a.substring(6,10)),t.target.value=l,e.value=/^\(\d{3}\) \d{3}-\d{4}$/.test(l)},Lf=t=>{var m;z();const a=(m=rt().prevUrl)==null?void 0:m.pathname.includes("/es/"),l=C("NONE"),r=C(!1),o=C(!1),c=C(!1),p=C(!1),f=wt(B("s_azU0komrCE4",[p,r,l,g(kf,"s_tmA6HPouQK8",[r]),c,o,t]));return n("div",null,{class:"flex flex-col rounded-3xl bg-white p-6 text-start  md:w-full w-[90vw] md:m-0 m-2 max-h-[80vh] overflow-y-auto"},n("form",null,{class:"mt-2 ",id:"contact_form","preventdefault:submit":!0,onSubmit$:B("s_mKzn6gnXAQk",[f])},[n("div",null,{class:"flex flex-col mb-2"},n("div",null,{class:"w-full"},i(M,{text:a?`### **¿Tienes alguna pregunta o necesitas ayuda?**
Rellena el formulario y nos pondremos en contacto contigo lo antes posible.`:`### **Have a question or need help?**
Fill out the form and we'll get back to you as soon as possible.`,classN:"!text-center items-center leading-none !text-[14px] ",[s]:{classN:s}},3,"T4_0"),1,null),1,null),n("div",null,{class:"flex flex-row gap-4 !z-[9999]"},[n("div",null,{class:"mb-4 w-full"},[n("label",null,{for:"from_name",class:"block py-1 font-regular tracking-[0.5px] text-[14px]"},[a?"Nombre":"Name"," ",n("span",null,{class:"text-red-300"},"*",3,null)," "],1,null),n("div",null,{class:"flex items-center p-2 gap-1 bg-white rounded-full border border-[#2e5899] border-opacity-40"},[i(Wl,{style:{color:"#2e5899",opacity:"0.5",width:"14px"},[s]:{style:s}},3,"T4_1"),n("input",{placeholder:a?"Tu nombre":"Your name"},{type:"text",name:"from_name",class:"w-full focus:outline-none text-[13px] ",required:!0},null,3,null)],1,null)],1,null),n("div",null,{class:"mb-4 w-full  md:w-2/3"},[n("label",null,{for:"from_zip_code",class:"block py-1 font-regular tracking-[0.5px] text-[14px]"},[a?"Código Postal":"Zip Code"," ",n("span",null,{class:"text-red-300"},"*",3,null)," "],1,null),n("div",null,{class:"flex items-center gap-1 p-2 bg-white rounded-full border border-[#2e5899] border-opacity-40"},[i(zn,{style:{color:"#2e5899",opacity:"0.5",width:"14px"},[s]:{style:s}},3,"T4_2"),n("input",{placeholder:a?"Código Postal":"Zip Code"},{type:"number",name:"zip_code",class:"w-full focus:outline-none text-[13px]",minLength:5,maxLength:5,required:!0},null,3,null)],1,null)],1,null)],1,null),n("div",null,{class:"flex flex-col md:flex-row gap-4 !z-[9999]"},[n("div",null,{class:"mb-4 w-full"},[n("label",null,{for:"from_email",class:"block py-1 font-regular tracking-[0.5px] text-[14px]"},[a?"Correo electrónico":"E-mail"," ",n("span",null,{class:"text-red-300"},"*",3,null)],1,null),n("div",null,{class:"flex items-center p-2 bg-white rounded-full border border-[#2e5899] border-opacity-40"},[n("div",null,{class:"mr-2"},i(Vl,{style:{color:"#2e5899",opacity:"0.5",width:"14px"},[s]:{style:s}},3,"T4_3"),1,null),n("input",{placeholder:a?"tu@correo.com":"your@mail.com"},{type:"email",name:"from_email",id:"from_email",class:"w-full focus:outline-none text-[13px]",required:!0},null,3,null)],1,null),n("label",null,{class:u(($,y)=>`text-xs text-red-300 ${$.value==!1&&y.value==!0?"flex":"hidden"} bg-transparent`,[p,c],'`text-xs text-red-300 ${p0.value==false&&p1.value==true?"flex":"hidden"} bg-transparent`')},a?"Por favor, usa un correo electrónico válido.":"Please, use a valid email address.",1,null)],1,null),n("div",null,{class:"mb-4 w-full"},[n("label",null,{for:"tel",class:"block py-1 font-regular tracking-[0.5px] text-[14px]"},a?"Número de teléfono":"Phone Number",1,null),n("div",null,{class:"flex items-center p-2 bg-white rounded-full border border-[#2e5899] border-opacity-40"},[n("div",null,{class:"mr-2"},i(kl,{style:{color:"#2e5899",opacity:"0.5",width:"14px"},[s]:{style:s}},3,"T4_4"),1,null),n("input",{placeholder:a?"ejemplo: (555) 000-0000":"example: (555) 000-0000"},{type:"tel",name:"tel",id:"tel",class:"w-full focus:outline-none text-[13px]"},null,3,null)],1,null),n("label",null,{class:u(($,y)=>`text-xs text-red-300 ${$.value==!1&&y.value==!0?"flex":"hidden"} bg-transparent`,[r,o],'`text-xs text-red-300 ${p0.value==false&&p1.value==true?"flex":"hidden"} bg-transparent`')},a?"Por favor, usa un número de teléfono válido.":"Please, use a valid phone number.",1,null)],1,null)],1,null),n("div",null,{class:"mb-4"},[n("label",null,{for:"message",class:"block py-1 font-regular tracking-[0.5px] text-[14px]"},[a?"Mensaje":"Message"," ",n("span",null,{class:"text-red-300"},"*",3,null)],1,null),n("div",null,{class:"flex items-center rounded"},n("textarea",null,{name:"message",class:"w-full rounded-2xl border border-[#2e5899] text-[14px] border-opacity-40 p-2 focus:border-blue-500 focus:outline-none",rows:4,required:!0},null,3,null),3,null)],1,null),n("button",{class:`flex w-full items-center justify-center rounded-full px-4 py-2 text-base font-semibold border border-primary-blue hover:bg-opacity-95 ${l.value==="LOADING"?"cursor-wait bg-primary-blue":l.value==="SUCCESS"?"bg-teal-500":""} focus:outline-none`},{type:"submit",disabled:u($=>$.value==="LOADING"||$.value==="SUCCESS",[l],'p0.value==="LOADING"||p0.value==="SUCCESS"')},l.value==="NONE"?a?"Enviar":"Send":l.value==="LOADING"?i(At,{size:"28px",[s]:{size:s}},3,"T4_5"):l.value==="ERROR"?"Error":a?"¡Mensaje enviado!":"Email Sent!",1,null)],1,null),1,"T4_6")},Cf=b(g(Lf,"s_UlMR3Hqos6E")),Mf=()=>{const[t,e]=U();e.value=t},jf=t=>{var m;const e=new Set(t.data.map($=>$.attributes.Category)),a=t.data.filter($=>$.attributes.Category==="Sports"),l=t.data.filter($=>$.attributes.Category==="Movies"),r=t.data.filter($=>$.attributes.Category==="News"),o=t.data.filter($=>$.attributes.Category==="Music"),c=t.data.filter($=>$.attributes.Category==="Kids"),p=(m=t.planId)==null?void 0:m.slice(0,2),d=C(0),f=$=>$.map((y,P)=>{const w=y.attributes.package_tvs.data.some(v=>v.attributes.package.includes(p)),D=y.attributes.package_tvs.data.some(v=>v.attributes.package.includes("comingSoon"));return n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",{class:`h-[40px] w-[40px] md:h-[60px] md:w-[60px] ${w?"":"opacity-20"} flex flex-col rounded-full border-2 p-1`},null,i(A,{height:50,width:50,get media(){return y.attributes.Image.data.attributes},[s]:{height:s,width:s,media:h(y.attributes.Image.data,"attributes")}},3,"wr_0"),1,null),D?n("div",null,{class:"rounded-full bg-primary-blue p-0.5 text-center text-xs text-white"},"Coming Soon",3,"wr_1"):null,n("p",null,{class:"text-center text-xs text-primary-blue"},S(y.attributes,"Channel_name"),1,null)],1,P)}),x=Array.from(e).map(($,y)=>n("div",null,{class:"grid w-full grid-cols-3 gap-4 py-4 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8"},$==="General"?f(t.data):$==="Sports"?f(a):$==="News"?f(r):$==="Music"?f(o):$==="Movies"?f(l):$==="Kids"?f(c):null,1,y));return n("div",null,{class:"h-[800px] w-full rounded-3xl bg-blue-700 p-5 md:h-[500px] md:w-[800px] md:p-10"},[n("div",null,{class:"flex flex-col content-start items-center justify-start md:flex-row md:justify-between"},[n("h1",null,{class:"text-2xl font-semibold text-white md:text-4xl"},u($=>$.planId,[t],"p0.planId"),3,null),n("p",null,{class:"text-xl font-light text-white md:text-2xl"},u($=>$.channels,[t],"p0.channels"),3,null)],3,null),n("div",null,{class:"my-1 flex h-fit flex-row items-start justify-start gap-4 overflow-x-auto rounded-t-2xl bg-white px-2 py-2 font-bold text-primary-blue md:items-center md:justify-between md:overflow-clip"},Array.from(e).map(($,y)=>n("button",{class:`${d.value==y?"bg-gray-200":""} rounded-xl p-2`,onClick$:g(Mf,"s_jPiPOXcEB6E",[y,d])},null,$,0,y)),1,null),n("div",null,{class:"flex h-3/4 w-full items-center justify-center rounded-b-3xl bg-white p-6"},Array.from(e).map(($,y)=>d.value==y?n("div",null,{class:"flex h-full w-full overflow-y-auto overflow-x-hidden rounded-2xl border-2 border-primary-blue bg-white py-4"},x[y],1,y):null),1,null)],1,"wr_2")},Af=b(g(jf,"s_bUc7uFb70ZI")),Ef=t=>`query {
        offices (filters:{locations:{ZipCode:{eq:${t}}}}) {
          data {
            attributes {
              InstanceLink
            }
          }
        }
      }`,Nf=t=>`query {
        offices(filters: { locations: { ZipCode: { eq: ${t} } } }) {
          data {
            attributes {
              Location
              Phone {
                Link
                Text
              }
            }
          }
        }
      }`,If=async t=>{let e=null;const a=await Qa(Ef(t["zip-code"].toString()));return a.pageData.data.offices.data.length>0&&(e=await a.pageData.data.offices.data[0].attributes.InstanceLink),e},Bf=Ui(g(If,"s_Aa7HFHe6DLE")),Of=async t=>{let e=null;const a=await Qa(Nf(t["zip-code"].toString()));return a.pageData.data.offices.data.length>0&&(e=await a.pageData.data.offices.data[0].attributes),e};Ui(g(Of,"s_txZGYKoQ0E8"));const qf=()=>{},Rf=t=>{var o;z();const e=Bf(),a=C(!1),r=(o=rt().prevUrl)==null?void 0:o.pathname.includes("/es/");return n("div",null,{class:" z-[800] flex h-fit w-[600px] flex-col items-center justify-center gap-4 rounded-full bg-blue-100 p-8"},[n("p",null,{class:"text-center text-4xl font-bold text-primary-blue"},u(c=>c.title,[t],"p0.title"),3,null),n("p",null,{class:"font-light"},u(c=>c.description,[t],"p0.description"),3,null),i(_p,{class:"w-full",action:e,onSubmit$:g(qf,"s_SuMdNt0qey8"),children:n("div",null,{class:"flex flex-row items-center justify-center gap-4 px-4"},[n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(zn,{style:{color:"#2e5899"},[s]:{style:s}},3,"PA_0"),1,null),n("input",null,{type:"text",maxLength:5,name:"zip-code",placeholder:"Zip-code",required:!0,class:"rounded-full border border-gray-300 p-2 placeholder:text-primary-blue focus:border-blue-500 focus:outline-none"},null,3,null)],1,null),n("button",null,{class:"w-1/4 rounded-full border-2 border-teal-500 bg-white px-4 py-2 font-bold text-teal-500 hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",type:"submit",onClick$:B("s_odOkENLwWr0",[a,e])},u(c=>c.btnText,[t],"p0.btnText"),3,null)],1,null),[s]:{class:s,action:s,onSubmit$:s}},1,"PA_1"),t.popup==="login"&&e.isRunning&&i(At,{size:"50px",[s]:{size:s}},3,"PA_2"),t.popup==="login"&&!e.isRunning&&e.value!=null&&n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,null,"Portal found",3,null),n("a",null,{href:u(c=>c.value.toString(),[e],"p0.value.toString()")},n("button",null,{class:"w-full rounded-full border-2 border-teal-500 bg-white px-4 py-2 font-bold text-teal-500 hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"},r?"Ir al portal":"Go to portal",1,null),1,null)],1,"PA_3"),t.popup==="login"&&!e.isRunning&&e.value==null&&a.value&&n("p",null,{class:"text-2xl text-secondary-red"},r?"Portal no encontrado":"Portal not found",1,"PA_4"),t.popup!=="login"&&e.isRunning&&i(At,{size:"50px",[s]:{size:s}},3,"PA_5"),t.popup!=="login"&&!e.isRunning&&e.value!=null&&n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,null,e.value.Location.toString(),1,null),n("a",null,{href:u(c=>c.value.Phone.Link.toString(),[e],'p0.value["Phone"]["Link"].toString()')},n("button",null,{class:"w-full rounded-full border-2 border-teal-500 bg-white px-4 py-2 font-bold text-teal-500 hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"},u(c=>c.value.Phone.Text,[e],'p0.value["Phone"]["Text"]'),3,null),3,null)],1,"PA_6"),t.popup!=="login"&&!e.isRunning&&e.value==null&&a.value&&n("p",null,{class:"text-xs text-primary-blue"},u(c=>c.notFountText,[t],"p0.notFountText"),3,"PA_7")],1,"PA_8")},Yl=b(g(Rf,"s_7GiaINstLc4")),zf=t=>n("div",null,{class:"fixed bottom-0 left-0 right-0 bg-white top-0 z-[200] transition-all duration-1000 ease-in-out"},n("iframe",null,{src:u(e=>e.route,[t],"p0.route"),class:"h-full w-full",frameBorder:"0"},null,3,null),3,"V0_0"),Fn=b(g(zf,"s_R079dt5Nweo")),Ff=t=>{const e=C(!1);return wt(B("s_rTgprikOCoA",[e,t])),n("div",{class:`flex items-center justify-start hover:cursor-pointer ${e.value?"text-white bg-primary-blue":"text-primary-dark-blue bg-white"}  shadow-2xl px-4 rounded-2xl h-[50px] ${t.classN}`},null,[n("input",null,{id:u(a=>a.id,[t],"p0.id"),name:"answer",value:u(a=>a.text,[t],"p0.text"),type:"radio",class:"peer appearance-none border border-primary-dark-blue w-4 h-4 rounded-full mr-[20px] checked:bg-btn-green checked:border-white"},null,3,null),n("label",null,{for:u(a=>a.id,[t],"p0.id"),class:"w-full hover:cursor-pointer h-full flex items-center font-bold"},u(a=>a.text,[t],"p0.text"),3,null)],3,"ss_0")},Qf=b(g(Ff,"s_HFec7A1uToc")),Gf=t=>{const e=C(!1),a=C(!0);return wt(B("s_nLcxs1o4e5w",[e,t])),n("div",null,{class:u(l=>`flex flex-col w-full shadow-2xl p-3 rounded-2xl ${l.value?"bg-primary-blue text-white":"bg-white text-primary-dark-blue"}`,[e],'`flex flex-col w-full shadow-2xl p-3 rounded-2xl ${p0.value?"bg-primary-blue text-white":"bg-white text-primary-dark-blue"}`')},[n("div",null,{class:u(l=>`flex flex-row items-center gap-3 justify-start hover:cursor-pointer ${l.classN} `,[t],"`flex flex-row items-center gap-3 justify-start hover:cursor-pointer ${p0.classN} `")},[n("input",null,{id:u(l=>l.id,[t],"p0.id"),name:"answer",value:u(l=>"followup-"+l.text,[t],'"followup-"+p0.text'),type:"radio",class:"peer appearance-none border border-primary-dark-blue w-4 h-4 shrink-0 rounded-full checked:bg-btn-green checked:border-white"},null,3,null),n("label",null,{for:u(l=>l.id,[t],"p0.id"),class:"hover:cursor-pointer flex flex-col w-full"},n("span",null,{class:"font-bold"},u(l=>l.text,[t],"p0.text"),3,null),3,null)],3,null),n("div",null,{class:u(l=>`${l.value?"flex flex-col gap-2":"hidden"}`,[e],'`${p0.value?"flex flex-col gap-2":"hidden"}`')},[n("div",null,{class:"flex flex-col"},[n("span",null,{class:"text-[12px]"},u(l=>(l.description??"")!=""?`(${l.description??""})`:null,[t],'(p0.description??"")!=""?`(${p0.description??""})`:null'),3,null),n("textarea",{class:`appearance-none border rounded-2xl text-primary-dark-blue px-1 text-[15px]
                                ${e.value&&a.value?"border-secondary-red":"border-primary-dark-blue"}`},{rows:3,name:u(l=>`${l.id}-textarea`,[t],"`${p0.id}-textarea`"),id:u(l=>`${l.id}-textarea`,[t],"`${p0.id}-textarea`"),required:u(l=>l.value,[e],"p0.value"),onInput$:B("s_ToLfq0NWlcw",[t])},null,3,null)],1,null),n("div",null,{class:"flex flex-col"},[n("span",null,{class:"font-semibold text-md"},"E-mail",3,null),n("span",null,{class:"text-[12px]"},"Add your e-mail in case you want us to reach to you.",3,null),n("input",null,{type:"email",name:"mailinput",id:"mailinput",class:"appearance-none border rounded-full text-primary-dark-blue p-1 text-[15px]",onInput$:B("s_kzRrICtFjgc",[t])},null,3,null)],3,null)],1,null)],1,"CH_0")},Hf=b(g(Gf,"s_5IvA0RZVpzA")),Vf="https://supa41.rtatel.com",Wf="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ewogICAgInJvbGUiOiAiYW5vbiIsCiAgICAiaXNzIjogInN1cGFiYXNlIiwKICAgICJpYXQiOiAxNjg0ODI1MjAwLAogICAgImV4cCI6IDE4NDI2NzgwMDAKfQ.Atj9wTNbdEEVPOjstsO14DtxbY2SEpnr50elVXBgAmM",Qn=wo(Vf,Wf),ao=2,Uf=async()=>{const{data:t,error:e}=await Qn.schema("rta_surveys").from("questions").select("*").eq("survey_id",ao);if(e)throw console.error("Error en getQuestions: "+e),e;return t},Yf=g(Uf,"s_gpAjyx0B0K8"),Zf=async()=>{const{data:t,error:e}=await Qn.schema("rta_surveys").from("survey_answers").insert([{survey_id:ao,created_at:new Date().toISOString()}]).select("id");if(e)throw console.log("Error en insertSurveyAnswers: "+e),e;return t},Kf=g(Zf,"s_EyLLGHYmCDI"),Jf=async(t,e,a)=>{const{data:l,error:r}=await Qn.schema("rta_surveys").from("answers").insert([{survey_answers_id:t,question_id:e,answer:a,created_at:new Date().toISOString()}]);if(r)throw console.log("Error en insertAnswers: "+r),r;return l},br=g(Jf,"s_Pz1fK0TDz5w"),Xf=async()=>{const[t,e]=U();(await Yf()).map(l=>{l.is_radio?e.push({id:l.id,survey_id:l.survey_id,question:l.question,answers:[l.radio1,l.radio2,l.radio3,l.radio4]}):t.push({id:l.id,survey_id:l.survey_id,question:l.question,answers:[l.radio1]})})},tg=async()=>{var y,P;const[t,e,a,l,r,o,c]=U();t.value=!0;const p=document.getElementById("form-leaving"),d=new FormData(p);let f="";const x="followup-",m=[...l,...a];d.forEach((w,D)=>{D.includes("answer")&&(f=w)});const $=f.length>0&&(f.includes(x)&&c.value!==""||!f.includes(x));try{if($){o.value=!0;const w=f.includes(x)?c.value:f,D=(y=m.find(k=>f.includes(x)?k.answers[0]===f.split(x).pop():k.answers.find(T=>T===f)))==null?void 0:y.id,v=await Kf();await br(v[0].id,D??0,w);const L=(P=m.find(k=>k.question==="email"))==null?void 0:P.id;e.value!=""&&L&&await br(v[0].id,L??0,e.value),r.signalPopupLeaving.value=!1,r.signalMainPopup.value=!1,window.localStorage.setItem("sendform_leaving","true")}}catch(w){throw console.log("Error: "+w),w}},eg=t=>{const e=Ee([]),a=Ee([]),l=C(!1),r=C(!1),o=C(""),c=C("");vn(g(Xf,"s_0QW8yCiluKc",[a,e]));const p=g(tg,"s_q00AFmMZ9Pg",[r,c,a,e,t,l,o]);return n("div",null,{class:"fixed flex items-center justify-center h-full w-full bottom-0 left-0 right-0 bg-blue-300 bg-opacity-50 top-0 z-[700]"},n("div",null,{class:"flex flex-col items-center justify-evenly md:h-fit h-[90vh] md:w-1/2 w-[80%] max-w-[600px] bg-[#DFEDFF] rounded-3xl p-5 pb-4 transition-all duration-1000 ease-in-out"},[n("form",null,{id:"form-leaving",class:"flex flex-col flex-1 overflow-hidden items-center w-full"},n("div",null,{class:"flex flex-col gap-4 flex-1 w-full overflow-y-auto pr-2"},e.map((d,f)=>n("div",null,{class:"w-full shrink-0"},[n("div",{class:`w-full ${f==0?"min-h-[100px]":""} flex flex-col items-center justify-center bg-gradient-to-tr from-primary-blue to-primary-light-blue rounded-2xl text-white mb-4 p-4 text-center`},null,[f==0?n("h2",null,{class:"font-bold sm:text-[35px] text-[24px]"},"Leaving so soon?",3,"O0_0"):"",n("p",null,null,S(d,"question"),1,null)],1,null),n("div",null,{class:"flex flex-col gap-2"},d.answers.map((x,m)=>{z();const $=a.find(y=>y.answers[0]===x);return $?i(Hf,{get id(){return $.id},text:x,get description(){return $.question},textareaSignal:o,emailInputSignal:c,[s]:{id:h($,"id"),description:h($,"question"),textareaSignal:s,emailInputSignal:s}},3,m):i(Qf,{classN:"w-full",text:x,id:d.id+"-"+m,[s]:{classN:s}},3,m)}),1,null)],1,f)),1,null),1,null),n("div",{class:`w-full rounded-3xl bg-white outline outline-secondary-red bg-opacity-60 text-center mt-1 p-1 text-[12px] text-secondary-red ${r.value&&l.value==!1?"":"hidden"}`},null,"Please ensure all required fields have been confirmed or completed.",3,null),n("button",null,{class:"text-white bg-btn-green font-bold py-2 px-4 w-fit h-fit rounded-3xl mt-4",onClick$:B("s_N36GmA7Tgos",[p])},"Submit",3,null)],1,null),1,"O0_1")},Ll=b(g(eg,"s_F0u0TUxd0sI")),ag=t=>{var c,p;z();const a=(c=rt().prevUrl)==null?void 0:c.pathname.includes("/es/");let l=null;if(t.link.includes("=pConf=")){const d=t.link.replace("=pConf=","");l=i(Fn,{route:d},3,"Y1_0")}else if(t.link.includes("=pIFrame=")){const d=t.link.replaceAll("=pIFrame=","");l=i(hf,{link:d},3,"Y1_1")}else if(t.link.includes("=pContactEmail=")){const d=t.link.split("=");l=i(Cf,{templateID:d[2],mailto:d[3],subject:d[4],lang:a?"es":"en"},3,"Y1_2")}else t.link.includes("=pChannelLineup=")?l=i(Af,{get channels(){return t.channels},get planId(){return t.planId},get data(){return t.dataChannels},[s]:{channels:u(d=>d.channels,[t],"p0.channels"),planId:u(d=>d.planId,[t],"p0.planId"),data:u(d=>d.dataChannels,[t],"p0.dataChannels")}},3,"Y1_3"):t.link.includes("=pLogin")?l=i(Yl,{title:a?"Inicia sesión en el portal de tu zona":"Log into the portal of your area",description:a?"Simplemente ingrese su código postal.":"Just enter your Zip code.",btnText:a?"Ir ahora":"Go Now",popup:"login",[s]:{popup:s}},3,"Y1_4"):t.link.includes("=pOfficeCall")&&(l=i(Yl,{popup:"location",title:a?"Llame a su oficina local":"Call your local office",description:a?"Descubra exactamente qué servicios ofrece RTA en su ciudad natal. Ingrese su código postal para el número de teléfono de su oficina local.":"Find out exactly what services RTA has to offer in your hometown. Input your zip code for your local office phone number.",notFountText:a?"Desafortunadamente, RTA no está disponible actualmente en su área. Sin embargo, RTA continúa expandiéndose en todo Estados Unidos. Si está interesado en los servicios de RTA en su área, envíenos un correo electrónico o llame a nuestra oficina principal.":"Find out exactly what services RTA has to offer in your hometown. Input your zip code for your local office phone number.",btnText:a?"Comprobar ahora":"Check Now",[s]:{popup:s}},3,"Y1_5"));const r=C(!1),o=C(!1);return n("div",null,{class:"relative flex"},[t.link.includes("=pConf=")&&(!((p=t.text)!=null&&p.includes("Check"))||!t.text.includes("Buscar"))?n("div",null,{class:"flex w-fit items-center justify-center rounded-full outline outline-teal-500 bg-white p-1 transition-all delay-150 ease-in-out hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white text-btn-green",onClick$:B("s_gRyPmBMRMEM",[r])},[n("p",null,{class:"min-sm:text-[13px] mx-2 text-[15px] font-[600] tracking-wide max-md:text-[14px] "},u(d=>d.text,[t],"p0.text"),3,null),n("div",null,{class:"flex h-[30px] w-[30px] items-center justify-center rounded-full bg-teal-500 p-0 text-white"},i(Tf,{class:"fill-white text-white font-bold",[s]:{class:s}},3,"Y1_6"),1,null)],1,"Y1_7"):t.hasStyle??!0?n("button",{class:`flex w-fit items-center justify-center gap-2 ${t.link.includes("=pChannelLineup=")?"":"rounded-full outline outline-teal-500 p-1 px-7 transition-all  hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"}  bg-white  text-[15px] font-[600]  text-btn-green opacity-80 max-md:text-[14px] max-sm:text-[13px] `},{onClick$:B("s_LMY0q14Gz9I",[r])},u(d=>d.text,[t],"p0.text"),3,null):n("div",null,{onClick$:B("s_CtCqQvywDJo",[r])},[i(ut,null,3,"Y1_8")," "],1,"Y1_9"),r.value&&n("div",null,{class:"fixed inset-0 z-[999999] !z-[999999] pointer-events-auto flex flex-col items-center justify-center bg-black bg-opacity-40"},n("div",null,{class:u(d=>` ${d.link.includes("=pConf=")?"w-full h-full flex-row-reverse ":"flex-col-reverse md:flex-row w-fit"} animate-zoomIn flex `,[t],'` ${p0.link.includes("=pConf=")?"w-full h-full flex-row-reverse ":"flex-col-reverse md:flex-row w-fit"} animate-zoomIn flex `')},[n("div",null,{class:"flex p-4 flex-wrap overflow-hidden items-center justify-center "},[l,t.link.includes("=pConf=")&&o.value&&window.localStorage.getItem("sendform_leaving")!="true"?i(Ll,{signalMainPopup:r,signalPopupLeaving:o,[s]:{signalMainPopup:s,signalPopupLeaving:s}},3,"Y1_10"):null],1,null),n("button",{class:`${t.link.includes("=pConf=")?"mt-2 mx-0":"w-[30px] p-4"} bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] focus:outline-none z-[600]`},{"aria-label":"Close popup",onClick$:B("s_Hg5lk0TunCg",[t,r,o])},t.link.includes("=pConf=")?n("div",null,{class:"px-3 flex flex-row items-center text-xs gap-2"},["Back to site ",i(Pl,null,3,"Y1_11")],1,"Y1_12"):n("div",null,null,i(eo,null,3,"Y1_13"),1,null),1,null)],1,null),1,"Y1_14")],1,"Y1_15")},ol=b(g(ag,"s_G7PwpIAJKRA")),lg=t=>{var r;z();const a=(r=rt().prevUrl)==null?void 0:r.pathname.includes("/es/"),l=t.link.startsWith("/");return t.link.startsWith("/")||t.link.startsWith("http")||t.link.startsWith("tel:")?i(Rt,{get class(){return t.classN??""},href:(a&&l?"/es":"")+t.link,prefetch:!0,get target(){return t.link.startsWith("http")?"_blank":"_self"},children:i(ut,null,3,"8s_0"),[s]:{class:u(o=>o.classN??"",[t],'p0.classN??""'),prefetch:s,target:u(o=>o.link.startsWith("http")?"_blank":"_self",[t],'p0.link.startsWith("http")?"_blank":"_self"')}},1,"8s_1"):t.link.startsWith("=")&&t.link?i(ol,{get link(){return t.link},get text(){return t.text??""},get hasStyle(){return t.hasStyle??!0},children:[" ",n("div",null,{class:u(o=>`${o.classN??""} cursor-pointer`,[t],'`${p0.classN??""} cursor-pointer`')},i(ut,null,3,"8s_2"),1,null)],[s]:{link:u(o=>o.link,[t],"p0.link"),text:u(o=>o.text??"",[t],'p0.text??""'),hasStyle:u(o=>o.hasStyle??!0,[t],"p0.hasStyle??true")}},1,"8s_3"):n("div",null,{class:u(o=>o.classN??"",[t],'p0.classN??""')},i(ut,null,3,"8s_4"),1,"8s_5")},Mt=b(g(lg,"s_nqL2AObZq60")),ng=t=>n("div",null,{class:"relative z-10 shadow-[0_5px_40px_-25px_rgba(0,0,0,0.2)]"},[n("div",null,{class:" fixed top-0 w-full shadow-[0_5px_40px_-25px_rgba(0,0,0,0.2)]"},[n("div",null,{class:"flex h-[28px] flex-row items-center justify-end gap-4 bg-primary-blue px-5 py-[4px] text-[12px] font-bold text-white max-sm:justify-evenly max-sm:text-[10px] max-sm:font-normal max-[400px]:text-[9px]"},t.data.TopOptions.map((e,a)=>i(Mt,{get link(){return e.Link},hasStyle:!1,get text(){return e.Text},children:n("div",null,{class:"flex flex-row items-center gap-2"},[n("div",null,{class:"w-[12px]"},i(A,{get media(){return e.Icon.data.attributes},toWhite:!0,width:"16",height:"16",[s]:{media:h(e.Icon.data,"attributes"),toWhite:s,width:s,height:s}},3,"Qt_0"),1,null),S(e,"Text")],1,null),[s]:{link:h(e,"Link"),hasStyle:s,text:h(e,"Text")}},1,a)),1,null),n("div",null,{class:"grid grid-cols-3 items-center justify-evenly bg-white px-3 py-1 min-[800px]:flex"},[n("button",null,{class:"mx-4 flex h-fit w-fit items-center justify-center rounded-3xl bg-primary-blue p-2 active:bg-primary-light-blue min-[800px]:hidden"},n("div",null,{onClick$:B("s_EXeZ7SCEUFc",[t])},i(sf,{class:"fill-white object-fill min-[800px]:hidden",[s]:{class:s}},3,"Qt_1"),1,null),1,null),n("div",null,{class:"flex items-center justify-center"},n("div",null,{class:"w-[125px] py-1"},i(Mt,{link:"/",children:i(A,{get media(){return t.data.MainMenu.Logo.data.attributes},width:150,height:80,[s]:{media:u(e=>e.data.MainMenu.Logo.data.attributes,[t],'p0.data["MainMenu"]["Logo"]["data"]["attributes"]'),width:s,height:s}},3,"Qt_2"),[s]:{link:s}},1,"Qt_3"),1,null),1,null),n("div",null,{class:"flex items-center justify-center gap-4 px-3 text-[15px] max-[1200px]:text-[13px] max-[800px]:hidden"},t.data.MainOptions.map(function(e,a){z();const l=e.SubOption.length>0;return n("div",null,{class:" font-bold text-primary-blue "},l?i(il,{get title(){return e.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},e.SubOption.map((r,o)=>{z();const c=r.MenuOption.data;return c?i(il,{get title(){return r.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},c.attributes.SubOption.map((p,d)=>i(Mt,{get link(){return p.Link},children:S(p,"Text"),[s]:{link:h(p,"Link")}},1,d)),1,null),[s]:{title:h(r,"Text")}},1,"Qt_5"):i(Mt,{classN:"text-primary-blue",get link(){return r.Link},hasStyle:!1,children:S(r,"Text"),[s]:{classN:s,link:h(r,"Link"),hasStyle:s}},1,o)}),1,null),[s]:{title:h(e,"Text")}},1,"Qt_6"):i(Mt,{classN:"text-primary-blue",get link(){return e.Link},hasStyle:!1,children:S(e,"Text"),[s]:{classN:s,link:h(e,"Link"),hasStyle:s}},1,"Qt_4"),1,a)}),1,null),n("div",null,{class:"flex items-center justify-center"},i(xf,{get data(){return t.data.MainMenu.Switcher},[s]:{data:u(e=>e.data.MainMenu.Switcher,[t],'p0.data["MainMenu"]["Switcher"]')}},3,"Qt_7"),1,null)],1,null)],1,null),n("div",null,{class:"mt-[89px] flex h-[32px] flex-row items-center justify-center gap-6 bg-secondary-red py-[2px] text-[14px] font-semibold tracking-[1px] text-white max-sm:text-[11px]"},t.data.ClientOptions.map((e,a)=>i(Mt,{get link(){return e.Link},children:S(e,"Text"),[s]:{link:h(e,"Link")}},1,a)),1,null),n("div",null,{class:"flex flex-row items-center justify-evenly bg-white py-1 max-[800px]:hidden"},t.data.gigfastOptions.map((e,a)=>i(Mt,{get link(){return e.Link},children:n("div",null,{class:"w-[130px] rounded-md p-1 hover:bg-slate-50"},i(A,{get media(){return e.Icon.data.attributes},width:"311",height:"60",[s]:{media:h(e.Icon.data,"attributes"),width:s,height:s}},3,"Qt_8"),1,null),[s]:{link:h(e,"Link")}},1,a)),1,null)],1,"Qt_9"),sg=b(g(ng,"s_qJ0s4sH5iHo")),rg=t=>{z();const e=C(!1);return n("div",null,{class:"my-3 w-full"},[n("div",{class:`flex cursor-pointer flex-row items-center transition ${t.inFooter??!1?"":e.value?"rounded-b-none rounded-t-2xl":"rounded-full"} justify-between ${t.classContainer} p-2 `},{onClick$:B("s_n7LVHyx9gZ0",[e])},[n("h3",null,{class:"flex w-full items-center justify-center font-bold"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:u(a=>`flex h-[20px] w-[20px] items-center justify-center ${a.inFooter??!1?"":"rounded-full bg-secondary-red text-white"}`,[t],'`flex h-[20px] w-[20px] items-center justify-center ${p0.inFooter??false?"":"rounded-full bg-secondary-red text-white"}`')},n("span",null,{class:"w-1/8 flex items-center justify-end text-xs"},u(a=>a.value?"▲":"▼",[e],'p0.value?"▲":"▼"'),3,null),3,null)],3,null),e.value&&n("div",null,{class:u(a=>`${a.classChild} ${a.inFooter??!1?"":"rounded-b-2xl rounded-t-none border-t-2 bg-white"} p-2 text-center transition-all duration-500 ease-in-out`,[t],'`${p0.classChild} ${p0.inFooter??false?"":"rounded-b-2xl rounded-t-none border-t-2 bg-white"} p-2 text-center transition-all duration-500 ease-in-out`')},i(ut,null,3,"vV_0"),1,"vV_1")],1,"vV_2")},Ga=b(g(rg,"s_znBlgckysPY")),ig=()=>{const[t]=U();if(t.link){if(t.link.includes("http"))return window.open(t.link,"_blank");window.location.href=t.link}(t.onClick??(()=>{}))()},og=t=>{var a;z();const e=g(ig,"s_5VUQoQPBpDA",[t]);return(t.type??"link")==="link"?(a=t.link)!=null&&a.startsWith("=")&&t.link?i(ol,{get link(){return t.link},get text(){return t.text},[s]:{link:u(l=>l.link,[t],"p0.link"),text:u(l=>l.text,[t],"p0.text")}},3,"ky_0"):n("div",{class:`flex w-fit items-center justify-center rounded-full outline ${(t.style??"default")=="default"?" outline-teal-500 bg-white text-btn-green font-[600]":(t.style??"default")=="full"?"bg-teal-500 text-white outline-teal-500":"outline-black bg-transparent text-black hover:!bg-black"} p-1 transition-all delay-150 ease-in-out hover:cursor-pointer hover:outline-transparent hover:bg-teal-500 hover:!text-white`},{onClick$:B("s_v30BEZ050tM",[e])},[n("p",null,{class:u(l=>` ${(l.style??"default")=="default",""} whitespace-nowrap min-sm:text-[13px] mx-2 text-[15px] font-[600] max-md:text-[14px]`,[t],'` ${(p0.style??"default")=="default"?"":""} whitespace-nowrap min-sm:text-[13px] mx-2 text-[15px] font-[600] max-md:text-[14px]`')},u(l=>l.text,[t],"p0.text"),3,null),n("div",{class:`${(t.style??"default")=="default"?"bg-teal-500 p-0 h-[28px] min-h-[28px] w-[28px] min-w-[28px]":(t.style??"default")=="full"?"bg-teal-500 h-[30px] min-h-[30px] w-[30px] min-w-[30px]":"bg-black"} text-white flex items-center justify-center rounded-full transition-transform duration-300`},null,i(vf,{class:"text-3xl transition-colors duration-300 text-white",style:{width:"24px",height:"24px"},[s]:{class:s,style:s}},3,"ky_1"),1,null)],1,"ky_2"):n("div",null,{class:"flex w-fit items-center justify-center  rounded-full bg-teal-500 p-1 px-1 opacity-90 transition-all  delay-150  ease-in-out hover:cursor-pointer hover:bg-teal-600",onClick$:B("s_eSPP9CLbtZw",[e])},[n("p",null,{class:"min-sm:text-[13px] mx-2 text-[15px] font-[600] tracking-wide  text-white max-md:text-[14px] "},u(l=>l.text,[t],"p0.text"),3,null),n("div",null,{class:"flex h-[25px] w-[25px] items-center justify-center rounded-full bg-white p-0 opacity-70 text-btn-green"},i(kl,null,3,"ky_3"),1,null)],1,"ky_4")},tt=b(g(og,"s_FRLwbQyPTTI")),ug=t=>n("div",null,{id:"footer",class:""},[n("div",null,{class:"flex flex-col items-center bg-primary-blue px-4 py-3 text-white"},[n("p",null,{class:"text-[22px] font-semibold"},u(e=>e.data.SupportSection.Title,[t],'p0.data["SupportSection"]["Title"]'),3,null),n("p",null,{class:"text-s lm:w-1/2 text-center sm:w-3/4"},u(e=>e.data.SupportSection.Paragraph,[t],'p0.data["SupportSection"]["Paragraph"]'),3,null)],3,null),n("div",null,{class:"flex flex-col flex-wrap justify-around bg-primary-dark-blue px-3 py-3 text-white lg:flex-row"},[n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"mb-4 w-[180px]"},i(A,{width:970,height:359,get media(){return t.data.CorpInfo.Media.data.attributes},[s]:{width:s,height:s,media:u(e=>e.data.CorpInfo.Media.data.attributes,[t],'p0.data["CorpInfo"]["Media"]["data"]["attributes"]')}},3,"Zn_0"),1,null),i(M,{get text(){return t.data.CorpInfo.Paragraph},classN:"text-white font-extralight mb-4 max-w-sm text-center text-[14px]",[s]:{text:u(e=>e.data.CorpInfo.Paragraph,[t],'p0.data["CorpInfo"]["Paragraph"]'),classN:s}},3,"Zn_1"),i(tt,{type:"action",get link(){return t.data.CorpInfo.Buttons[0].Link},get text(){return t.data.CorpInfo.Buttons[0].Text},[s]:{type:s,link:u(e=>e.data.CorpInfo.Buttons[0].Link,[t],'p0.data["CorpInfo"]["Buttons"][0]["Link"]'),text:u(e=>e.data.CorpInfo.Buttons[0].Text,[t],'p0.data["CorpInfo"]["Buttons"][0]["Text"]')}},3,"Zn_2")],1,null),n("div",null,{class:"container sm:hidden"},t.data.Menus.map((e,a)=>i(Ga,{inFooter:!0,get title(){return e.Text},classContainer:"text-md text-primary-light-blue font-semibold border-b-2 border-t-2 border-primary-light-blue",children:e.SubOption.map((l,r)=>i(Rt,{get href(){return l.Link},class:"mb-4 hover:text-blue-600",children:n("p",null,{class:"font-light text-[14px]"},S(l,"Text"),1,null),[s]:{href:h(l,"Link"),class:s}},1,r)),[s]:{inFooter:s,title:h(e,"Text"),classContainer:s}},1,a)),1,null),n("div",null,{class:"flex justify-around gap-6"},t.data.Menus.map((e,a)=>n("div",null,{class:"hidden w-1/4 sm:block"},[n("p",null,{class:"text-2xl text-primary-light-blue font-semibold"},S(e,"Text"),1,null),e.SubOption.map((l,r)=>i(Rt,{get href(){return l.Link},class:"hover:text-blue-600",children:n("p",null,{class:"font-light text-[14px] py-1"},S(l,"Text"),1,null),[s]:{href:h(l,"Link"),class:s}},1,r))],1,a)),1,null)],1,null),n("div",null,{class:"flex flex-col items-center gap-2 bg-primary-dark-blue px-4 py-4 text-white"},[n("p",null,{class:"text-[14px]"},u(e=>e.data.SocialMedia.Text,[t],'p0.data["SocialMedia"]["Text"]'),3,null),n("div",null,{class:"flex flex-row gap-4"},t.data.SocialMedia.SubOption.map((e,a)=>z(i(Rt,{get href(){return e.Link},children:[e.Link.includes("facebook")&&n("div",null,{class:"flex h-7 w-7 items-center justify-center rounded-full bg-primary-blue p-2"},i(A,{height:20,width:20,get media(){return e.Icon.data.attributes},toWhite:!0,[s]:{height:s,width:s,media:h(e.Icon.data,"attributes"),toWhite:s}},3,"Zn_3"),1,"Zn_4"),!e.Link.includes("facebook")&&n("div",null,{class:"flex h-7 w-7 items-center justify-center rounded-full bg-primary-blue p-1"},i(A,{height:20,width:20,get media(){return e.Icon.data.attributes},toWhite:!0,[s]:{height:s,width:s,media:h(e.Icon.data,"attributes"),toWhite:s}},3,"Zn_5"),1,"Zn_6")],[s]:{href:h(e,"Link")}},1,a))),1,null)],1,null)],1,"Zn_7"),cg=b(g(ug,"s_ecsQS6so2H0")),dg=()=>{const[t,e,a,l]=U();clearTimeout(l.value),l.value=setTimeout(()=>{t.value.value.length>2&&fetch(`/api/get-streets?q=${encodeURIComponent(t.value.value)}`).then(r=>r.json()).then(r=>{const o=r.data;o.length===0?e.value="notfound":e.value="success",a.value=o})},1e3)},pg=async()=>{const[t,e,a,l,r,o,c]=U();if(t.value.value.length>0){a.value=!1,l.value=!0,r.value=t.value.value;try{const p=t.value.value.split(", ")[0];e.value=e.value.replace("=pConf=","").replace("streetInput",p).replace("zipInput",c.value),o.value=!0}catch(p){console.error("Error at configurator call:",p)}}else a.value=!0},fg=t=>{var D,v;z();const e=C(),a=C([]),l=C("none"),r=C(!1),o=C(!1),c=(D=t.data.Slide)==null?void 0:D.find(L=>{var k,T,I;return(I=(T=(k=L==null?void 0:L.Buttons)==null?void 0:k[0])==null?void 0:T.Link)==null?void 0:I.includes("=pConf=")}),p=(v=c==null?void 0:c.Buttons)==null?void 0:v[0],d=C((p==null?void 0:p.Link)||"=pConf=https://ecom.rtatel.com/#/prefill/?address=streetInput&zipcode=zipInput"),f=C(n("input",null,null,null,3,"DG_0")),x=C(""),m=C(!1),$=C(!1),y=C(""),P=g(dg,"s_9tNNwBc30z8",[f,l,a,e]),w=g(pg,"s_DqvSialek3c",[f,d,$,m,x,o,y]);return n("div",null,{class:u(L=>`flex flex-col items-center justify-center ${L.showForm??!0?"p-4":"p-0"} gap-2 w-full`,[t],'`flex flex-col items-center justify-center ${p0.showForm??true?"p-4":"p-0"} gap-2 w-full`')},[t.data.CallButton&&(t.showCallButton??!0)&&i(Rt,{get href(){return t.data.CallButton.Link},children:n("div",{class:`bg-teal-500 fixed flex flex-row right-0 md:bottom-auto ${t.showForm??!0?"":"md:mt-10"} bottom-10 rounded-full rounded-r-none !z-[999] p-2 shadow-xl shadow-primary-blue/30 items-center gap-2`},null,[n("div",null,{class:"flex h-[25px] w-[25px] items-center justify-center rounded-full bg-white p-0 opacity-70 text-btn-green"},i(kl,null,3,"DG_1"),1,null),i(M,{get text(){return t.data.CallButton.Text},classN:"!text-white text-[12px] !tracking-wider",[s]:{text:u(L=>L.data.CallButton.Text,[t],'p0.data["CallButton"]["Text"]'),classN:s}},3,"DG_2")],1,null),[s]:{href:u(L=>L.data.CallButton.Link,[t],'p0.data["CallButton"]["Link"]')}},1,"DG_3"),(t.showForm??!0)&&n("div",null,{class:"flex flex-row gap-2 items-center justify-center animate-fade-in"},[i(zn,{style:{color:"#d20053",width:"14px"},[s]:{style:s}},3,"DG_4"),n("p",null,{class:"text-primary-blue font-semibold md:text-[18px] text-[15px]"},(c==null?void 0:c.Title)??"Explore coverage in your service area:",1,null)],1,"DG_5"),(t.showForm??!0)&&n("div",null,{class:"relative flex rounded-full bg-white shadow-xl shadow-primary-blue/30 items-center justify-around gap-2 p-1 !z-[5] w-full max-w-[600px] animate-slide-in-right"},[n("form",null,{action:"",class:"w-full flex items-center justify-center gap-2 flex-row grow"},[n("div",null,{class:"w-full bg-primary-light-blue/5 flex items-center p-2 gap-2 rounded-full border border-[#2e5899] border-opacity-10"},[i(wf,{style:{color:"#2e5899",opacity:"0.65",width:"14px"},[s]:{style:s}},3,"DG_6"),n("input",{placeholder:(c==null?void 0:c.Paragraph)??"Type an address and select",ref:f},{name:"search-address",id:"search-address",class:" w-full focus:outline-none  text-[15px] bg-transparent placeholder-primary-blue/70 md:min-w-[250px]",required:!0,type:"text",onKeyUp$:P},null,3,null)],1,null),n("div",null,{class:"inline-block"},i(tt,{style:"full",text:(p==null?void 0:p.Text)??"Check for plans",onClick:w,[s]:{style:s,onClick:s}},3,"DG_7"),1,null)],1,null),n("div",{class:`absolute left-0 top-full mt-2 w-full z-10 flex max-h-[200px] flex-col gap-3 overflow-y-auto rounded-xl bg-white p-4 text-primary-blue shadow-lg
  ${l.value==="none"||l.value==="selected"?"hidden":""}`},null,[u(L=>L.value.length===0?"Not found":"",[a],'p0.value.length===0?"Not found":""'),a.value.map((L,k)=>n("div",{onClick$:B("s_mXPMV0XdvEY",[f,L,l,y])},{class:"grid items-center gap-4 hover:cursor-pointer",style:{gridTemplateColumns:"20px 1fr"}},[i(Dl,{class:"w-6",[s]:{class:s}},3,"DG_8"),n("span",null,{class:"text-[14px]"},S(L,"address"),1,null)],0,k))],1,null)],1,"DG_9"),o.value&&n("div",null,{class:"fixed inset-0 z-[200] flex flex-col items-center justify-center bg-black bg-opacity-40"},n("div",null,{class:"w-full h-full flex-row-reverse  animate-zoomIn flex "},[n("div",null,{class:"flex p-4 flex-wrap overflow-hidden items-center justify-center "},[i(Fn,{get route(){return d.value},[s]:{route:u(L=>L.value,[d],"p0.value")}},3,"DG_10"),r.value&&window.localStorage.getItem("sendform_leaving")!="true"?i(Ll,{signalMainPopup:o,signalPopupLeaving:r,[s]:{signalMainPopup:s,signalPopupLeaving:s}},3,"DG_11"):null],1,null),n("button",null,{"aria-label":"Close popup",class:"mt-2 mx-0 bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] focus:outline-none z-[600]",onClick$:B("s_uXChW58fn0g",[d,o,r])},n("div",null,{class:"px-3 flex flex-row items-center text-xs gap-2"},["Back to site ",i(Pl,null,3,"DG_12")],1,null),1,null)],1,null),1,"DG_13")],1,null)},gg=b(g(fg,"s_BIrsaZMr3LY")),xg=t=>n("div",{class:`fixed left-0 right-0 top-0 z-[500] flex h-screen items-center justify-center bg-primary-dark-blue bg-opacity-30 transition-all duration-300 ${t.showSignal.value?"":"hidden"}`},{id:"modalback",onClick$:B("s_0718nqiE4KE",[t])},[n("div",null,{onClick$:B("s_Wu4a00SV7hw",[t])},i(df,{class:"absolute right-2 top-2 rounded-full bg-secondary-red p-1 text-[30px] font-[200] text-white hover:cursor-pointer",[s]:{class:s}},3,"kj_0"),1,null),i(ut,null,3,"kj_1")],1,"kj_2"),Zl=b(g(xg,"s_oHrF0mun03M")),mg=t=>{var r;const a=(r=rt().prevUrl)==null?void 0:r.pathname.includes("/es/"),l=C(!1);return n("div",null,{class:"flex flex-col gap-4 px-4 py-6 text-[15px] tracking-tight text-white"},[n("div",null,{class:"text-primary-blue"},i(Zl,{showSignal:l,children:i(Yl,{title:a?"Inicia sesión en el portal de tu zona":"Log into the portal of your area",description:a?"Ingrese su código postal.":"Just enter your Zip code.",btnText:a?"Ir ahora":"Go Now",popup:"login",[s]:{popup:s}},3,"Ux_0"),[s]:{showSignal:s}},1,"Ux_1"),1,null),t.data.MainOptions.map(function(o,c){z();const p=o.SubOption.length>0;return n("div",null,{class:""},p?i(il,{get title(){return o.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},o.SubOption.map((d,f)=>{z();const x=d.MenuOption.data;return x?i(il,{get title(){return d.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},x.attributes.SubOption.map((m,$)=>i(Mt,{get link(){return m.Link},hasStyle:!1,children:S(m,"Text"),[s]:{link:h(m,"Link"),hasStyle:s}},1,$)),1,null),[s]:{title:h(d,"Text")}},1,"Ux_4"):d.Link.includes("Login")?n("div",null,{class:"hover:cursor-pointer",onClick$:B("s_SnfOjeOrlzY",[l])},S(d,"Text"),1,"Ux_3"):i(Mt,{get link(){return d.Link},hasStyle:!1,children:S(d,"Text"),[s]:{link:h(d,"Link"),hasStyle:s}},1,f)}),1,null),[s]:{title:h(o,"Text")}},1,"Ux_5"):i(Mt,{get link(){return o.Link},children:S(o,"Text"),[s]:{link:h(o,"Link")}},1,"Ux_2"),1,c)}),n("div",null,{class:"w-full border border-white border-opacity-40"},null,3,null),n("div",null,{class:"flex w-fit flex-col gap-5"},t.data.gigfastOptions.map((o,c)=>i(Mt,{get link(){return o.Link},classN:"rounded-full bg-white px-4 py-1 shadow-lg",children:n("div",null,{class:"w-[130px] rounded-md p-1"},i(A,{get media(){return o.Icon.data.attributes},width:"311",height:"60",[s]:{media:h(o.Icon.data,"attributes"),width:s,height:s}},3,"Ux_6"),1,null),[s]:{link:h(o,"Link"),classN:s}},1,c)),1,null)],1,"Ux_7")},hg=b(g(mg,"s_jSaadUqLWqI")),bg=t=>{z();const e=C(!1);return n("div",null,{class:u(a=>`relative overflow-hidden transition-all duration-500 ${a.value?"overflow-y-hidden":"z-50"}`,[e],'`relative overflow-hidden transition-all duration-500 ${p0.value?"overflow-y-hidden":"z-50"}`'),style:u(a=>a.value?{perspective:"9000px"}:{},[e],'p0.value?{perspective:"9000px"}:{}')},[n("div",null,{class:u(a=>`absolute inset-0 ${a.value?"bg-gradient-to-l from-[#2e599a] to-[#182d4d] ":"bg-white !important"}   ${a.value?"overflow-y-hidden":"z-50"}`,[e],'`absolute inset-0 ${p0.value?"bg-gradient-to-l from-[#2e599a] to-[#182d4d] ":"bg-white !important"}   ${p0.value?"overflow-y-hidden":"z-50"}`')},i(hg,{get data(){return t.data.data.generalMenu.data.attributes},[s]:{data:u(a=>a.data.data.generalMenu.data.attributes,[t],'p0.data["data"]["generalMenu"]["data"]["attributes"]')}},3,"m8_0"),1,null),n("div",null,{class:u(a=>`relative transition-all duration-500 ${a.value?"overflow-y-hidden":"z-50"}`,[e],'`relative transition-all duration-500 ${p0.value?"overflow-y-hidden":"z-50"}`'),style:u(a=>a.value?{transform:"rotateY(-30deg) translateX(250px) translateY(200px)",transformStyle:"preserve-3d"}:{},[e],'p0.value?{transform:"rotateY(-30deg) translateX(250px) translateY(200px)",transformStyle:"preserve-3d"}:{}')},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-10 bg-gradient-to-l from-[#FFFFFF] to-[#C8D8ED]"},null,3,null),(t.showMenus??!0)&&i(sg,{get data(){return t.data.data.generalMenu.data.attributes},mobMenuOpen:e,[s]:{data:u(a=>a.data.data.generalMenu.data.attributes,[t],'p0.data["data"]["generalMenu"]["data"]["attributes"]'),mobMenuOpen:s}},3,"m8_1"),n("div",null,{class:u(a=>`${a.value?"overflow-y-hidden":""}`,[e],'`${p0.value?"overflow-y-hidden":""}`')},[(t.showMarquee??!1)&&t.marqueeData&&n("div",{class:`${t.marqueeData.Display?"flex flex-wrap":"hidden"} p-1  w-full items-center text-center justify-center bg-[#f1eb3f] w-full text-black flex flex-row md:text-[15px] text-[13px] font-semibold gap-2`},null,[n("p",null,{class:"animate-pulse"},u(a=>a.marqueeData.Text,[t],'p0.marqueeData["Text"]'),3,null),n("div",null,{class:"z-[8]"},i(tt,{style:"basic",get text(){return t.marqueeData.Button.Text},get link(){return t.marqueeData.Button.Link},[s]:{style:s,text:u(a=>a.marqueeData.Button.Text,[t],'p0.marqueeData["Button"]["Text"]'),link:u(a=>a.marqueeData.Button.Link,[t],'p0.marqueeData["Button"]["Link"]')}},3,"m8_2"),1,null)],1,"m8_3"),n("div",null,{class:"flex w-full items-center justify-center"},i(gg,{get data(){return t.data.data.generalHeader.data.attributes},get showForm(){return t.showHeader??!0},[s]:{data:u(a=>a.data.data.generalHeader.data.attributes,[t],'p0.data["data"]["generalHeader"]["data"]["attributes"]'),showForm:u(a=>a.showHeader??!0,[t],"p0.showHeader??true")}},3,"m8_4"),1,null),n("div",null,{class:"relative"},i(ut,null,3,"m8_5"),1,null),(t.showMenus??!0)&&i(cg,{get data(){return t.data.data.generalFooter.data.attributes},[s]:{data:u(a=>a.data.data.generalFooter.data.attributes,[t],'p0.data["data"]["generalFooter"]["data"]["attributes"]')}},3,"m8_6")],1,null)],1,null)],1,"m8_7")},F=b(g(bg,"s_vumpf0PbXbo")),$g=t=>{const e=t.customText?t.customText:t.SEOdata.MetaTitle.split(" |")[0];return!t.SEOdata&&!t.customText?n("h1",null,{class:"absolute opacity-0"},"RTA",3,"Yj_0"):n("h1",null,{class:"absolute opacity-0"},e,1,"Yj_1")},et=b(g($g,"s_SOxRNst40is")),vg=t=>{z();const e=C(!0);return n("div",null,{class:"h-[550px] w-full  flex flex-col items-center justify-center"},[e.value?i(At,{size:"250px",[s]:{size:s}},3,"a3_0"):null,n("iframe",null,{id:"iframe-appre-giveaway",class:"w-3/4 my-4 h-full rounded-3xl",src:u(a=>a.data.iFrame_link,[t],'p0.data["iFrame_link"]'),loading:"lazy",onLoad$:B("s_b0xkTBodv54",[e])},null,3,null)],1,"a3_1")},yg=b(g(vg,"s_VzseIswtUxM")),_g=t=>`query QueryAprGive {
        pageAprGive(locale:"${t}"){
          data{
            attributes{
              iFrame_link
              ${H}
            }
          }
        }
        }`,wg=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(_g,e)},Gn=R(g(wg,"s_xcQxq8lbgb0")),Sg=()=>{const t=Gn();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageAprGive.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAprGive.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAprGive"]["data"]["attributes"]["SEO"]')}},3,"kA_0"),i(yg,{get data(){return t.value.pageData.data.pageAprGive.data.attributes},[s]:{data:u(e=>e.value.pageData.data.pageAprGive.data.attributes,[t],'p0.value["pageData"]["data"]["pageAprGive"]["data"]["attributes"]')}},3,"kA_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"kA_2")},1,"kA_3")},Tg=b(g(Sg,"s_Py5O2s07X3c")),Dg=({resolveValue:t})=>{const a=t(Gn).pageData.data.pageAprGive.data.attributes.SEO;return V(a)},Pg=Object.freeze(Object.defineProperty({__proto__:null,default:Tg,head:Dg,usePageData:Gn},Symbol.toStringTag,{value:"Module"})),kg=t=>{z();const e=t.data.data.pageAprLead.data.attributes,a=C(!0);return n("div",null,{class:"flex flex-wrap px-8 items-center justify-center"},[n("div",null,{class:"flex flex-col items-center justify-center w-full md:w-1/2"},[n("div",null,{class:"relative h-[600px] w-[80%] flex flex-col items-center justify-center"},[i(A,{get media(){return e.zane_lead.bg_pic.data.attributes},width:"650",height:"650",[s]:{media:h(e.zane_lead.bg_pic.data,"attributes"),width:s,height:s}},3,"q7_0"),i(A,{clasN:"absolute flex rounded-full h-3/4 w-auto",get media(){return e.zane_lead.zane_pic.data.attributes},height:250,width:250,[s]:{clasN:s,media:h(e.zane_lead.zane_pic.data,"attributes"),height:s,width:s}},3,"q7_1"),i(A,{clasN:"absolute h-[10%] w-auto top-20 right-10",get media(){return e.zane_lead.tv_pic.data.attributes},height:"50",width:"50",[s]:{clasN:s,media:h(e.zane_lead.tv_pic.data,"attributes"),height:s,width:s}},3,"q7_2"),i(A,{clasN:"absolute bottom-10 h-[10%] w-auto left-5",get media(){return e.zane_lead.wifi_pic.data.attributes},height:"50",width:"50",[s]:{clasN:s,media:h(e.zane_lead.wifi_pic.data,"attributes"),height:s,width:s}},3,"q7_3"),i(A,{clasN:"absolute top-10 left-10 h-[10%] w-auto",get media(){return e.zane_lead.phone_pic.data.attributes.url},height:"50",width:"50",[s]:{clasN:s,media:h(e.zane_lead.phone_pic.data.attributes,"url"),height:s,width:s}},3,"q7_4"),n("div",null,{class:"absolute left-1/2 top-5 flex flex-row text-primary-blue bg-white items-center justify-center p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},i(A,{toWhite:!0,width:20,height:20,get media(){return e.zane_lead.give_pic.data.attributes},[s]:{toWhite:s,width:s,height:s,media:h(e.zane_lead.give_pic.data,"attributes")}},3,"q7_5"),1,null),"Price"],1,null),n("div",null,{class:"absolute w-fit h-fit bottom-0 left-1/2 flex flex-row text-primary-blue bg-white items-center justify-evenly p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},i(A,{toWhite:!0,width:20,height:20,get media(){return e.zane_lead.auto_pic.data.attributes},[s]:{toWhite:s,width:s,height:s,media:h(e.zane_lead.auto_pic.data,"attributes")}},3,"q7_6"),1,null),"Live Events"],1,null),n("div",null,{class:"absolute w-fit h-fit flex flex-row left-3/4 bottom-1/4 text-primary-blue bg-white items-center justify-evenly p-2 rounded-full"},[n("div",null,{class:"h-[25px] w-[25px] rounded-full  bg-secondary-red p-1"},i(A,{toWhite:!0,width:20,height:20,get media(){return e.zane_lead.cota_pic.data.attributes},[s]:{toWhite:s,width:s,height:s,media:h(e.zane_lead.cota_pic.data,"attributes")}},3,"q7_7"),1,null),"Discounts"],1,null),n("div",null,{class:"absolute w-fit h-fit flex flex-row justify-evenly left-0  text-primary-blue bg-white items-center p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},i(A,{toWhite:!0,width:20,height:20,get media(){return e.zane_lead.auto_pic.data.attributes},[s]:{toWhite:s,width:s,height:s,media:h(e.zane_lead.auto_pic.data,"attributes")}},3,"q7_8"),1,null),"Live Events"],1,null)],1,null),n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,{class:"text-xl text-center font-medium text-primary-blue"},S(e,"zane_description"),1,null),i(A,{get media(){return e.zane_banner.banner_pic.data.attributes},width:"400",height:"78",[s]:{media:h(e.zane_banner.banner_pic.data,"attributes"),width:s,height:s}},3,"q7_9"),n("div",null,{class:"flex flex-row items-center gap-5 justify-evenly my-5"},[n("div",null,{class:"bg-primary-blue text-white flex flex-col rounded-full items-center justify-center w-fit px-10 py-2"},[n("h2",null,{class:"text-sm text-center font-bold"},S(e.date_race,"Text"),1,null),n("p",null,{class:"text-sm text-center"},S(e.date_race,"Link"),1,null)],1,null),i(tt,{get text(){return e.button_promo.text},get link(){return e.button_promo.link},[s]:{text:h(e.button_promo,"text"),link:h(e.button_promo,"link")}},3,"q7_10")],1,null)],1,null)],1,null),n("div",null,{class:"w-full md:w-2/6 shadow-2xl rounded-2xl h-[500px]"},[a.value?i(At,{size:"250px",[s]:{size:s}},3,"q7_11"):null,n("iframe",{src:S(e,"iFrame_link")},{id:"iframe-appre-lead",loading:"lazy",class:"w-full  rounded-2xl h-full",onLoad$:B("s_M94pZoIEeB0",[a])},null,3,null)],1,null)],1,"q7_12")},Lg=b(g(kg,"s_0jvpiBD6mW4")),Cg=t=>`query QueryPageAprLead {
        pageAprLead(locale:"${t}"){
          data {
            attributes {
              zane_lead {
                zane_pic {
                    ${_}
                }
                give_pic {
                    ${_}
                }
                cota_pic {
                    ${_}
                }
                auto_pic {
                    ${_}
                }
                live_pic {
                    ${_}
                }
                phone_pic {
                    ${_}
                }
                tv_pic {
                    ${_}
                }
                wifi_pic {
                    ${_}
                }
                bg_pic {
                    ${_}
                }
              }
              zane_banner {
                banner_pic {
                    ${_}
                }
              }
              zane_description
              iFrame_link
              date_race {
                Text
                Link
                Icon {
                  ${_}
                }
              }
              button_promo {
                text
                icon {
                  ${_}
                }
                link
              }
              pricing_box {
                Title
                Subtitle
                Pricing
                Period
                bg {
                  ${_}
                }
                Icon {
                  ${_}
                }
              }
              car {
                car_pic {
                  ${_}
                }
              }
              ${H}
              
            }
          }
        }
      }`,Mg=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Cg,e)},Hn=R(g(Mg,"s_05Sy9vG0VbY")),jg=()=>{const t=Hn();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageAprLead.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAprLead.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAprLead"]["data"]["attributes"]["SEO"]')}},3,"LY_0"),i(Lg,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"LY_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"LY_2")},1,"LY_3")},Ag=b(g(jg,"s_32Qq7YbePEg")),Eg=({resolveValue:t})=>{const a=t(Hn).pageData.data.pageAprLead.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},Ng=Object.freeze(Object.defineProperty({__proto__:null,default:Ag,head:Eg,usePageData:Hn},Symbol.toStringTag,{value:"Module"})),Ig=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(M,{get text(){return t.data.TextContent},classN:" text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"gg_0")],1,"gg_1"),Bg=b(g(Ig,"s_aBW0sNB4lDQ")),Og=t=>`query QueryAUP {
        pageAuPolicy(locale:"${t}"){    
          ${aa}
          ${H}
            }
          }
        }
      }`,qg=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Og,e)},Vn=R(g(qg,"s_0Vm0zDWr0rg")),Rg=()=>{const t=Vn(),e=t.value.pageData.data.pageAuPolicy.data.attributes.Content;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(Bg,{data:e},3,"TO_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"TO_1")},1,"TO_2")},zg=b(g(Rg,"s_NmxpHX8KAHk")),Fg=({resolveValue:t})=>{const a=t(Vn).pageData.data.pageAuPolicy.data.attributes.SEO;return V(a)},Qg=Object.freeze(Object.defineProperty({__proto__:null,default:zg,head:Fg,usePageData:Vn},Symbol.toStringTag,{value:"Module"})),lo=({qty:t})=>{if(t!==void 0)return t;if(typeof window<"u"){const e=window.innerWidth;return e>1200?3:e>800?2:1}else return 1},Gg=()=>{const[t,e]=U();t.value=lo({qty:e})},Hg=()=>{const[t]=U();t()},Vg=({slidesQty:t})=>{const e=C(lo({qty:t})),a=g(Gg,"s_zVG057gY2pI",[e,t]);return wt(B("s_hQsoJzDpgeo",[a])),Ro("resize",g(Hg,"s_WB2t7tmOijA",[a])),e},Wg=t=>{const e=Vg({slidesQty:t.slidesQty});return wt(B("s_xmo13ab0hsk",[e,t])),i(G,{children:n("section",null,{class:"splide max-w-screen overflow-hidden",id:u(a=>`${a.id?a.id:""}`,[t],'`${p0.id?p0.id:""}`'),"aria-label":"Componente Carousel"},n("div",null,{class:u(a=>` splide__track  ${a.addSpace??!0?"p-8":""}`,[t],'` splide__track  ${p0.addSpace??true?"p-8":""}`')},n("div",null,{class:"splide__list justify-between "},t.slides.map((a,l)=>n("div",null,{class:"splide__slide w-full items-center"},n("div",null,{class:u(r=>`${r.fillSlide??!1?"w-full h-full object-cover":"object-center"} flex items-center  ${r.addSpace??!0?"mx-10":""}  justify-center`,[t],'`${p0.fillSlide??false?"w-full h-full object-cover":"object-center"} flex items-center  ${p0.addSpace??true?"mx-10":""}  justify-center`')},a,1,null),1,l)),1,null),1,null),1,null)},1,"cE_0")},Et=b(g(Wg,"s_UuwASfcxtbw")),Ug=t=>n("div",null,{class:"text-center"},[n("div",null,{class:"bg-primary-blue bg-opacity-40 p-6 h-[310px] w-[310px] inline-block items-center justify-center rounded-full"},n("div",null,{class:"bg-primary-blue flex h-full w-full items-center justify-center  rounded-full bg-opacity-60 px-6 py-6 shadow-md"},n("div",null,{class:"bg-primary-blue flex flex-col h-full w-full items-center justify-around rounded-full shadow-md"},[n("div",null,{class:"flex flex-col items-center"},[i(A,{get media(){return t.award.Icon.data.attributes},height:40,width:40,[s]:{media:u(e=>e.award.Icon.data.attributes,[t],'p0.award["Icon"]["data"]["attributes"]'),height:s,width:s}},3,"5M_0"),n("p",null,{class:"text-l text-white font-semibold text-center"},u(e=>e.award.Title,[t],'p0.award["Title"]'),3,null),n("p",null,{class:"text-center text-sm font-light text-white leading-8"},u(e=>e.award.Award,[t],'p0.award["Award"]'),3,null)],1,null),n("a",null,{class:"text-white font-semibold",target:"_blank",href:u(e=>e.award.Button.Link,[t],'p0.award["Button"]["Link"]')},u(e=>e.award.Button.Text,[t],'p0.award["Button"]["Text"]'),3,null)],1,null),1,null),1,null),n("p",null,{class:"text-3xl font-semibold text-primary-blue"},u(e=>e.award.Year,[t],'p0.award["Year"]'),3,null)],1,"5M_1"),Yg=t=>{const e=t.data.data.pageAward.data.attributes,a=b(g(Ug,"s_fwfHmjnV3nY")),l=e.Awards.map((r,o)=>i(a,{award:r},3,o));return n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"w-3/4"},[n("h1",null,{class:"text-center text-4xl font-bold text-primary-blue"},S(e,"Title"),1,null),i(M,{classN:"text-center",get text(){return e.Description},[s]:{classN:s,text:h(e,"Description")}},3,"5M_2")],1,null),n("div",null,{class:"w-full h-[500px] relative items-center justify-center overflow-hidden"},[n("div",null,{class:"h-full w-full absolute bg-opacity-50"},i(A,{clasN:"object-fill opacity-50",get media(){return e.Background.data.attributes},height:500,width:1200,[s]:{clasN:s,media:h(e.Background.data,"attributes"),height:s,width:s}},3,"5M_3"),1,null),n("div",null,{class:"h-full w-full flex items-center justify-center absolute"},i(Et,{slides:l,id:"awardsSlider",hasPagination:!0,duration:3e3,[s]:{id:s,hasPagination:s,duration:s}},3,"5M_4"),1,null)],1,null)],1,"5M_5")},Zg=b(g(Yg,"s_DHWUiZRKjUc")),Kg=t=>`query {
        pageAward(locale:"${t}"){
          data {
            attributes {
              Title
              Description
              
              Background {
                ${_}
              }
              
              Awards {
                Title
                Award
                Year
                Background {
                  ${_}
                }
                Icon {
                  ${_}
                }
                Button{
                  Text
                  Link
                }
              }
      
              ${H}
            }
          }
        }
      }`,Jg=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Kg,e)},Wn=R(g(Jg,"s_sqeXWQdLNKw")),Xg=()=>{const t=Wn();return i(F,{get data(){return t.value.layoutData},children:i(Zg,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"Q2_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Q2_1")},t0=b(g(Xg,"s_YOAlBnNiDxQ")),e0=({resolveValue:t})=>{const a=t(Wn).pageData.data.pageAward.data.attributes.SEO;return V(a)},a0=Object.freeze(Object.defineProperty({__proto__:null,default:t0,head:e0,usePageData:Wn},Symbol.toStringTag,{value:"Module"})),no=async(t,e,a)=>{const r=await(await fetch(`https://cblsrvr1.rtatel.com/planbuilder/validate/coverage?lat=${t}&long=${e}&zipcode=${a}`)).json(),o=r.result.coverage,c=r.result.locationgroup,p=r.result.type;return{coverage:o,type:p,locationgroup:c}},l0=async(t,e,a,l,r,o)=>{const c=`https://api.mapbox.com/v4/uzzielpalma99.cm86cp9fg0fdp1otla8ttr421-5s8um/tilequery/${e},${t}.json?radius=${a}&limit=${l}&geometry=${r}&access_token=${o}`;return(await fetch(c)).json()},n0=async(t,e,a,l)=>{try{const r=a.toUpperCase(),o=l.includes("-")?l.split("-")[0]:l,c=await fetch("https://u-n8n.virtalus.cbluna-dev.com/webhook/rta_search_bastrop_location_cover",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({lat:t,long:e,address:r,zipcode:o})});if(!c.ok)throw new Error(`Error en la respuesta: ${c.status}`);const d=(await c.json()).data;return d==="bastrop_nofiber"||d==="bastrop_elegible"||d==="bastrop_nocoverage"?d:"unknown"}catch(r){return console.error("Error al consultar la cobertura bastrop location:",r),"unknown"}},s0=async(t,e,a,l)=>{const r=async(f,x,m)=>(await l0(t,e,x,m,f,o)).features,o="pk.eyJ1IjoidXp6aWVscGFsbWE5OSIsImEiOiJja3hoeWxxaHUwYjVhMndvYzdkMW4wbTAzIn0.JGPo9_pMeml93PD7bELQRg",p=(await r("polygon","0","5")).some(f=>f.properties.folder==="bastrop_county_outline");let d="unknown";return d=p?await n0(t,e,a,l):"notbastrop",{serviceType:d}},r0=t=>{const[e]=U(),a=t.target.value.replace(/\D/g,"");let l="";a.length>0&&(l="("+a.substring(0,3)),a.length>=3&&(l+=") "+a.substring(3,6)),a.length>=7&&(l+="-"+a.substring(6,10)),t.target.value=l,e.value=/^\(\d{3}\) \d{3}-\d{4}$/.test(l)},i0=t=>{z();const e=t.lang=="es",a=C("NONE"),l=C(!1),r=C(!1),o=C(!1),c=C(!1),p=C(!1),d=C(!1),x=wt(B("s_dp4YDfQHqh0",[p,d,c,l,a,g(r0,"s_I79lnzaeDZQ",[l]),o,r,e,t])),$=[{serviceType:"bastrop_elegible",title:e?"¡Instalación gratuita!":"Free Installation!",paragraph:e?`Tu dirección es elegible para recibir _**gigFAST INTERNET®**_ con instalación gratuita. 
  Regístrate ahora y te mantendremos informado cuando estemos listos para conectarte.`:`Your address is eligible to receive _**gigFAST INTERNET®**_ with free installation. 
  Sign up now and we’ll keep you informed when we’re ready to connect you.`},{serviceType:"bastrop_nofiber",title:e?"¡Buenas noticias!":"Great News!",paragraph:e?`Estamos expandiendo la red _**gigFAST INTERNET®**_ cerca de tu zona.
  Regístrate hoy y te mantendremos informado cuando comencemos el despliegue en tu vecindario.`:`We’re expanding the _**gigFAST INTERNET®**_ network near your area.
  Sign up today and we’ll keep you informed when we begin deploying in your neighborhood.`},{serviceType:"bastrop_nocoverage",title:e?"Gracias por contactarnos":"Thank You for Contacting Us",paragraph:e?`Tu dirección está en el Condado de Bastrop, pero aún no está en nuestra red.
  Nos pondremos en contacto contigo para informarte si podremos ofrecerte servicio.`:`Your address is in Bastrop County, but not yet on our network.
  We will reach out to let you know if and when we will be able to offer service.`},{serviceType:"notbastrop",title:e?"Dirección fuera de cobertura":"Out of Coverage Area",paragraph:e?`Lo sentimos, esta dirección no aparece dentro del Condado de Bastrop, Texas.
  Si crees que esto es un error, intenta ingresar tu dirección nuevamente o llama a nuestra oficina para verificar la cobertura.`:`Sorry, this address does not appear to be in Bastrop County, Texas.
  If you believe this is an error, please try entering your address again or call our office to verify service availability.`}].find(w=>w.serviceType===t.service_type),{title:y,paragraph:P}=$??{title:e?"¡Gracias!":`Thank You! service type: ${t.service_type}`,paragraph:e?"Gracias por tu interés en gigFAST INTERNET®.":"Thank you for your interest in gigFAST INTERNET®."};return n("div",null,{class:"flex flex-col rounded-3xl bg-white p-6 text-start  md:w-full w-[90vw] md:m-0 max-h-[90vh] overflow-y-auto "},[i(M,{text:y,classN:"md:text-[38px] text-[22px] font-bold",[s]:{classN:s}},3,"YT_0"),i(M,{text:P,classN:"!max-w-[600px] text-[12px] md:!text-[14px]",[s]:{classN:s}},3,"YT_1"),n("form",null,{class:"mt-2 ",id:"bastrop_form","preventdefault:submit":!0,onSubmit$:B("s_6H5Py2rk6BE",[x])},[n("div",null,{class:"mb-4 w-full"},[n("label",null,{for:"from_address",class:"block py-1 font-regular tracking-[0.5px] text-[14px]"},[e?"Dirección":"Address"," ",n("span",null,{class:"text-red-300"},"*",3,null)],1,null),n("div",null,{class:"flex items-center p-2 bg-white rounded-full border border-[#2e5899] border-opacity-40"},[n("div",null,{class:"mr-2"},i(Vl,{style:{color:"#2e5899",opacity:"0.5",width:"14px"},[s]:{style:s}},3,"YT_2"),1,null),n("input",null,{type:"text",name:"from_address",id:"from_address",class:"w-full focus:outline-none text-[13px]",required:!0,value:u(w=>w.bastrop_address,[t],"p0.bastrop_address")},null,3,null)],1,null)],1,null),n("div",null,{class:"flex flex-col md:flex-row md:gap-4"},[n("div",null,{class:"mb-4 w-full"},[n("label",null,{for:"from_first_name",class:"block py-1 font-regular tracking-[0.5px] text-[14px]"},[e?"Primer Nombre":"First Name"," ",n("span",null,{class:"text-red-300"},"*",3,null)," "],1,null),n("div",null,{class:"flex items-center p-2 gap-1 bg-white rounded-full border border-[#2e5899] border-opacity-40"},[i(Wl,{style:{color:"#2e5899",opacity:"0.5",width:"14px"},[s]:{style:s}},3,"YT_3"),n("input",{placeholder:e?"Tu primer nombre":"Your first name"},{type:"text",name:"from_first_name",class:"w-full focus:outline-none text-[13px] ",required:!0},null,3,null)],1,null)],1,null),n("div",null,{class:"mb-4 w-full"},[n("label",null,{for:"from_last_name",class:"block py-1 font-regular tracking-[0.5px] text-[14px]"},[e?"Apellido":"Last Name"," ",n("span",null,{class:"text-red-300"},"*",3,null)," "],1,null),n("div",null,{class:"flex items-center p-2 gap-1 bg-white rounded-full border border-[#2e5899] border-opacity-40"},[i(Wl,{style:{color:"#2e5899",opacity:"0.5",width:"14px"},[s]:{style:s}},3,"YT_4"),n("input",{placeholder:e?"Tu apellido":"Your last name"},{type:"text",name:"from_last_name",class:"w-full focus:outline-none text-[13px] ",required:!0},null,3,null)],1,null)],1,null)],1,null),n("div",null,{class:"flex flex-col items-center gap-2"},[n("div",null,{class:"flex flex-col md:flex-row md:gap-4 w-full"},[n("div",null,{class:"mb-4 w-full"},[n("label",null,{for:"from_email",class:"flex flex-row py-1 font-regular tracking-[0.5px] text-[14px] gap-2"},[e?"Correo electrónico":"E-mail"," ",n("span",null,{class:u(w=>`text-red-300 ${w.value?"flex":"hidden"}`,[p],'`text-red-300 ${p0.value?"flex":"hidden"}`')},"*",3,null)],1,null),n("div",null,{class:"flex items-center p-2 bg-white rounded-full border border-[#2e5899] border-opacity-40"},[n("div",null,{class:"mr-2"},i(Vl,{style:{color:"#2e5899",opacity:"0.5",width:"14px"},[s]:{style:s}},3,"YT_5"),1,null),n("input",{placeholder:e?"tu@correo.com":"your@mail.com"},{type:"email",name:"from_email",id:"from_email",class:"w-full focus:outline-none text-[13px]",required:u(w=>w.value,[p],"p0.value")},null,3,null)],1,null),n("label",null,{class:u((w,D,v)=>`text-xs text-red-300 ${!D.value&&v.value&&w.value?"flex":"hidden"} bg-transparent`,[p,c,o],'`text-xs text-red-300 ${!p1.value&&p2.value&&p0.value?"flex":"hidden"} bg-transparent`')},[e?"Por favor, usa un correo electrónico válido.":"Please, use a valid email address."," ",n("span",null,{class:u(w=>`text-red-300 ${w.value?"flex":"hidden"}`,[d],'`text-red-300 ${p0.value?"flex":"hidden"}`')},"*",3,null)],1,null)],1,null),n("div",null,{class:"mb-4 w-full"},[n("label",null,{for:"tel",class:"flex flex-row py-1 font-regular tracking-[0.5px] text-[14px] gap-2"},[e?"Número de teléfono":"Mobile Phone Number"," ",n("span",null,{class:u(w=>`text-red-300 ${w.value?"flex":"hidden"}`,[d],'`text-red-300 ${p0.value?"flex":"hidden"}`')},"*",3,null)],1,null),n("div",null,{class:"flex items-center p-2 bg-white rounded-full border border-[#2e5899] border-opacity-40"},[n("div",null,{class:"mr-2"},i(kl,{style:{color:"#2e5899",opacity:"0.5",width:"14px"},[s]:{style:s}},3,"YT_6"),1,null),n("input",{placeholder:e?"ejemplo: (555) 000-0000":"example: (555) 000-0000"},{type:"tel",name:"tel",id:"tel",class:"w-full focus:outline-none text-[13px]",required:u(w=>w.value,[d],"p0.value")},null,3,null)],1,null),n("label",null,{class:u((w,D,v)=>`text-xs text-red-300 ${!D.value&&v.value&&w.value?"flex":"hidden"} bg-transparent`,[d,l,r],'`text-xs text-red-300 ${!p1.value&&p2.value&&p0.value?"flex":"hidden"} bg-transparent`')},e?"Por favor, usa un número de teléfono válido.":"Please, use a valid phone number.",1,null)],1,null)],1,null),n("div",null,{class:" w-full flex items-start"},n("label",null,{class:u((w,D)=>`text-xs text-red-300 ${!D.value&&!w.value?"flex":"hidden"} bg-transparent`,[p,d],'`text-xs text-red-300 ${!p1.value&&!p0.value?"flex":"hidden"} bg-transparent`')},e?"Selecciona por lo menos un método para contactarte, por favor.":"Please, select at least one contact method.",1,null),1,null),n("div",null,{class:" w-full flex items-start"},[n("input",null,{type:"checkbox",id:"accept_mail",name:"accept_mail",class:"mt-1 cursor-pointer",required:u(w=>!w.value,[d],"!p0.value")},null,3,null),n("label",null,{for:"accept_mail",class:"ml-2 text-sm"},e?"Acepto recibir correos electrónicos de la empresa.":"I agree to receive e-mails from the company.",1,null)],1,null),n("div",null,{class:"mb-4 w-full flex items-start"},[n("input",null,{type:"checkbox",id:"accept_sms",name:"accept_sms",class:"mt-1 cursor-pointer",required:u(w=>!w.value,[p],"!p0.value")},null,3,null),n("label",null,{for:"accept_sms",class:"ml-2 text-sm"},e?"Acepto recibir mensajes de texto de la empresa.":"I agree to receive text messages from the company.",1,null)],1,null)],1,null),n("button",{class:`flex w-full items-center justify-center rounded-full px-4 py-2 text-base font-semibold border border-primary-blue hover:bg-opacity-95 ${a.value==="LOADING"?"cursor-wait bg-primary-blue":a.value==="SUCCESS"?"bg-teal-500":""} focus:outline-none`},{type:"submit",disabled:u(w=>w.value==="LOADING"||w.value==="SUCCESS",[a],'p0.value==="LOADING"||p0.value==="SUCCESS"')},a.value==="NONE"?e?"Enviar":"Send":a.value==="LOADING"?i(At,{size:"28px",[s]:{size:s}},3,"YT_7"):a.value==="ERROR"?"Error":e?"¡Mensaje enviado!":"Email Sent!",1,null)],1,null)],1,"YT_8")},o0=b(g(i0,"s_NC2MtXp4BOs")),u0=(t,e,a)=>t.replace("=pConf=","").replace("streetInput",e).replace("zipInput",a),c0=async()=>{const[t,e,a,l,r,o,c,p,d,f,x]=U();if(t.value.value.length>0)if(l.value=!1,c.value!==""&&p.value!==""){o.value=!0,f.value=t.value.value;try{const m=t.value.value.split(", ")[0],$=await s0(c.value,p.value,m,x.value);a.value=$.serviceType,a.value==="bastrop_nocoverage"&&(await no(c.value,p.value,x.value)).coverage&&(a.value="notbastrop"),a.value=="notbastrop"&&(e.value=u0(d.confLink,m,x.value)),r.value=!0}catch(m){console.error("Error al buscar cobertura:",m)}o.value=!1,c.value="",p.value=""}else o.value=!1;else l.value=!0},d0=()=>{const[t,e,a,l]=U();clearTimeout(l.value),l.value=setTimeout(()=>{t.value.value.length>2&&fetch(`/api/get-streets?q=${encodeURIComponent(t.value.value)}`).then(r=>r.json()).then(r=>{const o=r.data;o.length===0?e.value="notfound":e.value="success",a.value=o})},1e3)},p0=()=>{const[t,e]=U();window.localStorage.getItem("sendform_leaving")!="true"?e.value=!0:t.value=!1},f0=t=>{var T,I;z();const e=C(n("input",null,null,null,3,"BA_0")),a=C(""),l=C(""),r=C(!1),o=C("unknown"),c=C(!1),p=C(!1),d=C(!1),f=C(""),x=C(""),m=C(""),$=C(),y=C([]),P=C("none"),w=g(c0,"s_KLb3N6vaxZM",[e,l,o,d,p,c,f,x,t,a,m]),D=g(d0,"s_KVQ76UL7hYo",[e,P,y,$]),v=g(p0,"s_qZl6Molr9jA",[p,r]),L=((T=t.formData)==null?void 0:T.Fields)??[{Placeholder:t.isES?"Busca una dirección":"Address Search"}],k=((I=t.formData)==null?void 0:I.ActionButton)??{Text:t.isES?"Consultar":"Check"};return n("div",null,{class:"w-full"},[p.value&&n("div",null,{class:"fixed inset-0 z-[9999] flex items-center justify-center bg-black bg-opacity-40 bastrop-form"},[n("div",null,{class:"relative animate-zoomIn flex flex-col-reverse md:flex-row w-fit max-w-full max-h-full"},[o.value!=="notbastrop"&&n("button",null,{"aria-label":"Close popup",class:"absolute top-2 right-2 bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] w-[30px] focus:outline-none z-[9999] hover:bg-red-600",onClick$:B("s_CW4V0u4zLUo",[p])},i(eo,null,3,"BA_1"),1,"BA_2"),n("div",null,{class:"flex p-4 flex-wrap overflow-hidden items-center justify-center"},o.value==="notbastrop"?i(Fn,{get route(){return l.value},[s]:{route:u(E=>E.value,[l],"p0.value")}},3,"BA_3"):i(o0,{get lang(){return t.isES?"es":"en"},get service_type(){return o.value},get bastrop_address(){return a.value},[s]:{lang:u(E=>E.isES?"es":"en",[t],'p0.isES?"es":"en"'),service_type:u(E=>E.value,[o],"p0.value"),bastrop_address:u(E=>E.value,[a],"p0.value")}},3,"BA_4"),1,null)],1,null),(o.value==="notbastrop"||o.value==="bastrop_nocoverage")&&n("button",null,{"aria-label":"Close popup",class:"absolute top-2 right-12 bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] px-3 text-xs gap-2 z-[9999]",onClick$:B("s_TEnIKP0S6UA",[v,p])},["Back to site ",i(Pl,null,3,"BA_5")],1,"BA_6"),n("div",null,null,r.value&&window.localStorage.getItem("sendform_leaving")!="true"?i(Ll,{signalMainPopup:p,signalPopupLeaving:r,[s]:{signalMainPopup:s,signalPopupLeaving:s}},3,"BA_7"):null,1,null)],1,"BA_8"),n("div",null,{class:"flex gap-2 text-primary-blue justify-center items-center flex-col grow w-full"},[n("div",null,{class:"flex bg-white md:rounded-full rounded-[20px] md:w-auto w-full flex-col items-center justify-around p-4 gap-2"},[n("form",null,{action:"",class:"w-full flex items-center justify-center gap-2 md:flex-row flex-col grow"},[n("input",{placeholder:S(L[0],"Placeholder"),ref:e},{name:"search-address",id:"search-address",class:"w-full rounded-full px-3 py-2 placeholder-primary-blue bg-primary-light-blue/20",required:!0,type:"text",onKeyUp$:D},null,3,null),n("div",null,{class:""},i(tt,{get text(){return k.Text},onClick:w,[s]:{text:h(k,"Text"),onClick:s}},3,"BA_9"),1,null)],1,null),n("p",null,{class:u(E=>`${E.value?"hidden":"flex"} text-secondary-red text-sm font-bold`,[o],'`${p0.value?"hidden":"flex"} text-secondary-red text-sm font-bold`')},u(E=>E.isES?"Lamentablemente, no hay cobertura en tu área.":"Unfortunately, there is no coverage in your area.",[t],'p0.isES?"Lamentablemente, no hay cobertura en tu área.":"Unfortunately, there is no coverage in your area."'),3,null),n("p",null,{class:u(E=>`${E.value?"flex":"hidden"} text-secondary-red text-sm font-bold`,[d],'`${p0.value?"flex":"hidden"} text-secondary-red text-sm font-bold`')},u(E=>E.isES?"Por favor, ingresa una dirección.":"Please, enter an address.",[t],'p0.isES?"Por favor, ingresa una dirección.":"Please, enter an address."'),3,null)],1,null),n("div",{class:`flex max-h-[200px] flex-col gap-3 overflow-y-auto rounded-xl bg-white p-6 text-primary-blue shadow-lg ${P.value==="none"||P.value==="selected"?"hidden":""}`},null,[u(E=>E.value.length===0?"Not found":"",[y],'p0.value.length===0?"Not found":""'),y.value.map((E,N)=>n("div",{onClick$:B("s_t4xeCnqn2rs",[e,f,x,E,P,m])},{class:"grid items-center gap-4 hover:cursor-pointer",style:{gridTemplateColumns:"20px 1fr"}},[i(Dl,{class:"w-6",[s]:{class:s}},3,"BA_10"),n("span",null,{class:"text-[14px]"},S(E,"address"),1,null)],0,N))],1,null),c.value&&i(At,{size:"70px",[s]:{size:s}},3,"BA_11"),o.value&&c.value==!1&&n("div",null,{class:" flex flex-grow justify-center place-items-center"},i(ut,null,3,"BA_12"),1,"BA_13")],1,null)],1,null)},g0=b(g(f0,"s_JA5fMtSZEX4")),x0=t=>{const[e]=U();e.openIndex=e.openIndex===t?-1:t},m0=t=>{var o;const a=(o=rt().prevUrl)==null?void 0:o.pathname.includes("/es/"),l=Ee({openIndex:-1,heights:{},showAll:t.listall??!0});wt(B("s_vqQKBqHOQos",[l]));const r=g(x0,"s_Ka6XEsBpGVE",[l]);return n("div",null,{class:"w-full mx-auto p-4 flex flex-col"},[t.faqs.map((c,p)=>{if(z(),!(l.showAll||p<8))return null;const f=l.openIndex===p,x=/\[([^\]]+)\]\((=p[^)]+)\)/g,$=[...c.Paragraph.matchAll(x)].map(P=>({text:P[1],id:P[2]})),y=c.Paragraph.replace(x,()=>"");return n("div",null,{class:"border-b border-primary-blue/30"},[n("button",{"aria-expanded":f,onClick$:B("s_JzawDrVthkQ",[p,r])},{class:"w-full flex justify-between items-center py-4 text-left font-medium text-gray-700 hover:text-gray-900 focus:outline-none gap-2"},[n("div",null,{class:"grow"},S(c,"Title"),1,null),n("div",{class:`flex h-[30px] min-h-[30px] w-[30px] min-w-[30px] items-center justify-center rounded-full p-0 text-white transition-transform duration-300 ${l.openIndex===p?"rotate-180 bg-primary-blue/10":"rotate-0 bg-primary-blue"}`},null,i($f,{class:`text-3xl transition-colors duration-300 ${l.openIndex===p?"text-primary-blue/70":"text-white"}`,style:{width:"24px",height:"24px"},[s]:{style:s}},3,"dt_0"),1,null)],0,null),n("div",{style:{maxHeight:f?`${l.heights[p]||0}px`:"0px",opacity:f?1:0}},{class:"flex flex-col faq-content overflow-hidden transition-all duration-300 ease-in-out w-full"},[i(M,{text:y,classN:"text-primary-blue p-2 !text-[14px]",[s]:{classN:s}},3,"dt_1"),$.map(P=>i(tt,{get text(){return P.text},get link(){return P.id},[s]:{text:h(P,"text"),link:h(P,"id")}},3,"dt_2")),c.Disclaimer&&n("div",null,{class:"flex flex-row items-center justify-center gap-2"},[i(to,{class:"text-secondary-red",[s]:{class:s}},3,"dt_3"),i(M,{get text(){return c.Disclaimer.Text},classN:"text-[12px] text-primary-dark-blue",[s]:{text:h(c.Disclaimer,"Text"),classN:s}},3,"dt_4")],1,"dt_5"),c.Table&&n("div",null,{class:"flex flex-col justify-center w-full"},n("table",null,{class:"border-collapse border rounded-2xl border-gray-200 w-full"},n("tbody",null,{class:"bg-purple-300 m-2"},c.Table.map((P,w)=>z(n("div",null,{class:""},P.ColumnThree.includes("Title")?n("tr",null,{class:"bg-white text-start flex w-full"},n("th",{colSpan:P.ColumnThree.includes("Column")?2:3},null,i(M,{get text(){return P.ColumnOne},classN:"px-2 text-start",[s]:{text:h(P,"ColumnOne"),classN:s}},3,"dt_6"),1,null),1,w):n("tr",{class:`flex ${w===0?"text-white bg-primary-blue":w%2===1?"bg-blue-100 text-primary-blue text-[13px]":"bg-blue-200 text-primary-blue text-[13px]"}`},null,[n("td",null,{class:"flex w-full"},[i(M,{get text(){return P.ColumnOne},classN:`text-start px-2 ${w===0?"text-white ":"text-primary-blue"}`,[s]:{text:h(P,"ColumnOne")}},3,"dt_7")," "],1,null),n("td",null,{class:"flex w-full"},i(M,{get text(){return P.ColumnTwo},classN:`text-start px-2 ${w===0?"text-white ":"text-primary-blue"}`,[s]:{text:h(P,"ColumnTwo")}},3,"dt_8"),1,null),!P.ColumnThree.includes("Column")&&!P.ColumnThree.includes("Title")&&n("td",null,{class:"flex w-full"},i(M,{get text(){return P.ColumnThree},classN:`text-start px-2 ${w===0?"text-white ":"text-primary-blue"}`,[s]:{text:h(P,"ColumnThree")}},3,"dt_9"),1,"dt_10")],1,w),1,"dt_11"))),1,null),1,null),1,"dt_12")],1,null)],1,p)}),n("div",null,{class:u(c=>`${c.listall??!0?"hidden":"flex"} justify-center mt-4`,[t],'`${p0.listall??true?"hidden":"flex"} justify-center mt-4`')},n("button",null,{class:"text-primary-blue underline hover:text-primary-blue/70 transition",onClick$:B("s_G9gEd1W0zBA",[t,l])},l.showAll?a?"Ver menos preguntas":"View fewer questions":a?"Ver más preguntas":"View more questions",1,null),1,null)],1,"dt_13")},Un=b(g(m0,"s_01KmxcaZZHY")),h0=t=>(z(),n("div",null,{class:"md:min-h-[85vh] flex md:flex-row flex-col items-start justify-center w-full bg-white rounded-[30px] gap-4 p-2 "},[n("section",null,{class:"flex-1 w-full md:w-1/2 min-w-0 h-full flex flex-col "},n("div",null,{class:"rounded-[30px] overflow-hidden flex items-start justify-center relative  bg-black "},[i(A,{get media(){return t.introPar.Media.data.attributes},clasN:"absolute min-w-full min-h-full object-cover pointer-events-none opacity-80",[s]:{media:u(e=>e.introPar.Media.data.attributes,[t],"p0.introPar.Media.data.attributes"),clasN:s}},3,"eY_0"),n("div",null,{class:"relative w-full h-full grow flex items-start justify-center min-h-[90vh]"},n("div",null,{class:"flex flex-col items-center justify-center h-full grow"},n("div",null,{class:"text-center p-6 flex flex-col items-center justify-center gap-4 h-full grow"},[t.introPar.Title&&n("h1",null,{class:"text-3xl md:text-[3.5vw] font-medium leading-none tracking-tighter text-white font-heading"},u(e=>e.introPar.Title,[t],"p0.introPar.Title"),3,"eY_1"),t.introPar.Subtitle&&n("p",null,{class:"text-l  mb-6 text-white font-thin tracking-[1px]"},u(e=>e.introPar.Subtitle,[t],"p0.introPar.Subtitle"),3,"eY_2"),t.introPar.Paragraph&&n("div",null,{class:"max-w-2xl"},i(M,{get text(){return t.introPar.Paragraph},classN:"text-white text-[12px] md:text-[14px] leading-6",[s]:{text:u(e=>e.introPar.Paragraph,[t],"p0.introPar.Paragraph"),classN:s}},3,"eY_3"),1,"eY_4"),i(g0,{get isES(){return t.isES},get confLink(){return t.confLink},[s]:{isES:u(e=>e.isES,[t],"p0.isES"),confLink:u(e=>e.confLink,[t],"p0.confLink")}},3,"eY_5"),n("div",null,{class:"max-w-2xl"},i(M,{get text(){return t.isES?"* Ingresa tu dirección y selecciona una opción de la lista":"* Type your address and choose an option from the dropdown list"},classN:"text-white font-extrabold text-[12px] md:text-[14px]",[s]:{text:u(e=>e.isES?"* Ingresa tu dirección y selecciona una opción de la lista":"* Type your address and choose an option from the dropdown list",[t],'p0.isES?"* Ingresa tu dirección y selecciona una opción de la lista":"* Type your address and choose an option from the dropdown list"'),classN:s}},3,"eY_6"),1,null)],1,null),1,null),1,null)],1,null),1,null),n("section",null,{class:"flex-1 w-full md:w-1/2 min-w-0 !z-0 flex-col"},[t.faqPar&&n("div",null,{class:"px-4 flex flex-col"},i(M,{get text(){return t.faqPar.Title},classN:"md:!text-[35px] !text-[20px] mt-4 md:text-start text-center",[s]:{text:u(e=>e.faqPar.Title,[t],"p0.faqPar.Title"),classN:s}},3,"eY_7"),1,"eY_8"),i(Un,{get faqs(){return t.faqs},listall:!1,analyticsOrigin:"bastrop_faq",[s]:{faqs:u(e=>e.faqs,[t],"p0.faqs"),listall:s,analyticsOrigin:s}},3,"eY_9")],1,null)],1,"eY_10")),b0=b(g(h0,"s_Ss47YWFGgTk")),$0=t=>(z(),n("div",{class:`flex w-full flex-col items-center justify-center ${t.alt??!1?"bg-white":"bg-[#e2eefa]"}
        ${t.backgroundColor&&`bg-${t.backgroundColor}`}`},null,[(t.alt??!1)&&i(G,{children:[n("div",null,{class:"h-8 w-full bg-[#ebf4fc]"},null,3,null),n("div",null,{class:"h-8 w-full bg-[#f7fafe]"},null,3,null)]},3,"9K_0"),n("div",null,{class:u(e=>`my-4 flex ${e.reverse??!1?"flex-row-reverse":""} max-w-[1200px] items-center justify-center max-[800px]:flex-col`,[t],'`my-4 flex ${p0.reverse??false?"flex-row-reverse":""} max-w-[1200px] items-center justify-center max-[800px]:flex-col`')},[n("div",null,{class:u(e=>`flex ${e.image&&`min-[800px]:w-[${(e.textPercentage??70).toString()}%]`}  flex-col items-center justify-center gap-4 px-10`,[t],"`flex ${p0.image&&`min-[800px]:w-[${(p0.textPercentage??70).toString()}%]`}  flex-col items-center justify-center gap-4 px-10`")},[t.logo&&n("div",null,{class:"max-w-[470px]"},i(A,{get media(){return t.logo},width:"1230",height:"230",[s]:{media:u(e=>e.logo,[t],"p0.logo"),width:s,height:s}},3,"9K_1"),1,"9K_2"),n("div",null,{class:u(e=>`flex ${!(e.hasPricing??!0)&&"flex-col"} justify-center gap-2 text-${e.color??"primary-blue"}`,[t],'`flex ${!(p0.hasPricing??true)&&"flex-col"} justify-center gap-2 text-${p0.color??"primary-blue"}`')},[t.title&&n("h2",null,{class:"text-center !text-[32px]  font-semibold max-sm:text-[28px]"},u(e=>e.title,[t],"p0.title"),3,"9K_3"),t.subtitle&&n("h3",{class:`text-[28px] font-bold
                  ${t.backgroundColor&&t.backgroundColor.trim()!=="transparent"?"text-white":"text-secondary-red"}
                  ${t.hasPricing??!0?"":"text-center "} max-sm:text-[20px]`},null,u(e=>e.subtitle,[t],"p0.subtitle"),3,"9K_4")],1,null),i(M,{get text(){return t.text},get classN(){return`text-[16px] max-sm:text-[15px] text-${t.color??"primary-blue"}`},[s]:{text:u(e=>e.text,[t],"p0.text"),classN:u(e=>`text-[16px] max-sm:text-[15px] text-${e.color??"primary-blue"}`,[t],'`text-[16px] max-sm:text-[15px] text-${p0.color??"primary-blue"}`')}},3,"9K_5"),n("div",null,{class:"flex gap-4"},t.buttons&&t.buttons.map((e,a)=>i(tt,{get text(){return e.Text},get link(){return e.Link},type:e.Link.startsWith("tel:")?"action":"link",children:i(uf,{color:"#13B295",class:"text-[21px] opacity-60",[s]:{color:s,class:s}},3,"9K_6"),[s]:{text:h(e,"Text"),link:h(e,"Link")}},1,a)),1,null)],1,null),t.image&&n("div",null,{class:u(e=>`flex items-center justify-center self-center ${e.imageLink&&"cursor-pointer"}`,[t],'`flex items-center justify-center self-center ${p0.imageLink&&"cursor-pointer"}`'),onClick$:B("s_0a2swupHwgA",[t])},n("div",null,{class:"flex md:w-[400px] w-[350px] items-center justify-center self-center p-4"},i(A,{get media(){return t.image},width:"400",height:"400",[s]:{media:u(e=>e.image,[t],"p0.image"),width:s,height:s}},3,"9K_7"),1,null),1,"9K_8"),t.customComponent&&n("div",null,{class:u(e=>`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${(100-(e.textPercentage??70)).toString()}%]`,[t],"`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${(100-(p0.textPercentage??70)).toString()}%]`")},u(e=>e.customComponent,[t],"p0.customComponent"),3,"9K_9")],1,null),(t.alt??!1)&&i(G,{children:[n("div",null,{class:"h-8 w-full bg-[#f7fafe]"},null,3,null),n("div",null,{class:"h-8 w-full bg-[#ebf4fc]"},null,3,null)]},3,"9K_10")],1,"9K_11")),Lt=b(g($0,"s_QAc0HW5bNAE")),v0=t=>i(Lt,{get logo(){return t.data.Logo&&t.data.Logo.data&&t.data.Logo.data.attributes},get image(){return t.data.Media&&t.data.Media.data&&t.data.Media.data.attributes},get title(){return t.data.Title},get subtitle(){return t.data.Subtitle},get text(){return t.data.Paragraph},get buttons(){return t.data.Buttons},get reverse(){return t.reverse??!1},get color(){return t.color??"primary-blue"},get alt(){return t.alt??!1},get hasPricing(){return t.hasPricing??!0},get textPercentage(){return t.textPercentage??70},get customComponent(){return t.customComponent},get backgroundColor(){return t.backgroundColor},imageLink:t.data.Media&&t.data.Media.data&&t.data.Media.data.attributes.caption.includes("http")?t.data.Media.data.attributes.caption:t.imageLink,[s]:{logo:u(e=>e.data.Logo&&e.data.Logo.data&&e.data.Logo.data.attributes,[t],'p0.data["Logo"]&&p0.data["Logo"]["data"]&&p0.data["Logo"]["data"]["attributes"]'),image:u(e=>e.data.Media&&e.data.Media.data&&e.data.Media.data.attributes,[t],'p0.data["Media"]&&p0.data["Media"]["data"]&&p0.data["Media"]["data"]["attributes"]'),title:u(e=>e.data.Title,[t],'p0.data["Title"]'),subtitle:u(e=>e.data.Subtitle,[t],'p0.data["Subtitle"]'),text:u(e=>e.data.Paragraph,[t],'p0.data["Paragraph"]'),buttons:u(e=>e.data.Buttons,[t],'p0.data["Buttons"]'),reverse:u(e=>e.reverse??!1,[t],"p0.reverse??false"),color:u(e=>e.color??"primary-blue",[t],'p0.color??"primary-blue"'),alt:u(e=>e.alt??!1,[t],"p0.alt??false"),hasPricing:u(e=>e.hasPricing??!0,[t],"p0.hasPricing??true"),textPercentage:u(e=>e.textPercentage??70,[t],"p0.textPercentage??70"),customComponent:u(e=>e.customComponent,[t],"p0.customComponent"),backgroundColor:u(e=>e.backgroundColor,[t],"p0.backgroundColor")}},3,"9K_12"),Ve=b(g(v0,"s_Itm0b43i6oU")),y0=t=>i(G,{children:t.data.map((e,a)=>i(Ve,{data:e,reverse:a%2===0,alt:a%2===0,get color(){return t.color??"primary-blue"},[s]:{color:u(l=>l.color??"primary-blue",[t],'p0.color??"primary-blue"')}},3,a))},1,"9K_13"),We=b(g(y0,"s_0DQ5Kmfc4bA")),_0=t=>(z(),t.media.url.includes(".mp4")?Z("video",{get width(){return t.width},get height(){return t.height},src:gt(t.media.url),...t.autoplay??!1?{autoplay:!0}:{},...t.controls??!1?{controls:!0}:{},...t.loop??!0?{loop:!0}:{},...t.muted??!0?{muted:!0}:{},playsInline:!0,get class(){return(t.toWhite??!1?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(t.clasN??"")}},{width:u(e=>e.width,[t],"p0.width"),height:u(e=>e.height,[t],"p0.height"),playsInline:s,class:u(e=>(e.toWhite??!1?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(e.clasN??""),[t],'(p0.toWhite??false?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(p0.clasN??"")')},0,"kf_0"):i(A,{get media(){return t.media},get width(){return t.width},get height(){return t.height},get toWhite(){return t.toWhite??!1},get clasN(){return t.clasN??""},[s]:{media:u(e=>e.media,[t],"p0.media"),width:u(e=>e.width,[t],"p0.width"),height:u(e=>e.height,[t],"p0.height"),toWhite:u(e=>e.toWhite??!1,[t],"p0.toWhite??false"),clasN:u(e=>e.clasN??"",[t],'p0.clasN??""')}},3,"kf_1")),ja=b(g(_0,"s_GG0oZTUUfNc")),w0=t=>{var f;z();const a=(f=rt().prevUrl)==null?void 0:f.pathname.includes("/es/"),l=t.data.pageBastropP.data.attributes,r=t.data.pageHome.data.attributes.HeroForm.ActionButton.Link,o=l.HeaderDesktop.data.attributes,c=l.HeaderMobile.data.attributes,p=l.FaqList.find(x=>x.Table.length>0&&(x.Paragraph.includes("plans")||x.Paragraph.includes("planes"))),d=p&&p.Table.filter(x=>!x.ColumnOne.startsWith("**"));return n("div",null,{class:"flex flex-col items-center justify-center"},[o&&n("div",null,{class:"bg-white w-full !max-h-[250px] min-[600px]:flex hidden"},i(ja,{media:o,width:900,height:924,[s]:{width:s,height:s}},3,"T0_0"),1,"T0_1"),c&&n("div",null,{class:"bg-white w-full !max-h-[250px] min-[600px]:hidden flex"},i(ja,{media:c,width:650,height:650,[s]:{width:s,height:s}},3,"T0_2"),1,"T0_3"),n("div",null,{class:"max-w-[1200px] flex flex-col text-primary-blue items-center justify-center gap-10"},[i(b0,{get introPar(){return l.IntroPar},get faqPar(){return l.FaqPar},get faqs(){return l.FaqList},isES:a,confLink:r,[s]:{introPar:h(l,"IntroPar"),faqPar:h(l,"FaqPar"),faqs:h(l,"FaqList")}},3,"T0_4"),n("div",null,{class:"flex flex-col w-full"},[i(Lt,{title:a?"Nuestros planes":"Our Plans",logo:{url:"/uploads/gig_FAST_Internet_0253314cce.webp"},text:a?"Dale un vistazo a las ofertas disponibles en esta área":"Take a look of the available offers in this area",backgroundColor:"transparent",[s]:{logo:s,backgroundColor:s}},3,"T0_5"),n("div",null,{class:"flex justify-evenly gap-4 max-[1400px]:flex-wrap "},d&&d.map((x,m)=>n("div",{class:`relative ${m%2==0?"bg-blue-500":"bg-primary-blue"} text-white px-4 py-8 w-48 h-40 rounded-xl overflow-hidden shadow-lg !-z-[10]`},null,[n("div",{class:`absolute -top-5 -right-5 w-14 h-14 ${m%2==0?"bg-primary-blue":"bg-blue-500"} rounded-full`},null,null,3,null),n("h2",null,{class:"text-2xl font-bold"},S(x,"ColumnOne"),1,null),n("p",null,{class:"text-sm"},S(x,"ColumnTwo"),1,null),n("p",null,{class:"text-xl py-4 font-bold"},[S(x,"ColumnThree"),n("span",null,{class:"text-sm font-thin"},"/mo",3,null)],1,null)],1,"T0_6")),1,null)],1,null)],1,null),n("div",null,{class:"w-full justify-center bg-[#ebf4fc]"},i(We,{get data(){return l.BottomPars},[s]:{data:h(l,"BottomPars")}},3,"T0_7"),1,null)],1,"T0_8")},so=b(g(w0,"s_HmxGCRBiunA")),ro=t=>`query QueryBastropProject {
                pageBastropP(locale:"${t}") {
                    data{
                        attributes{    

                            HeaderDesktop{
                                ${_}
                            }
                            
                            HeaderMobile{
                                ${_}
                            }

                            IntroPar{
              	                Title
                                Paragraph
                                Media{
                                    ${_}
                                }
                                Buttons{
                                    Text
                                    Link
                                }
                            }

                            FaqPar{
              	                Title
                                Paragraph
                                Buttons{
                                    Text
                                    Link
                                }
                            }
                            
                            FaqList(pagination:{limit:50}){
                                Title
                                Paragraph
                                Disclaimer{
                                    Icon{
                                        ${_}
                                    }
                                    Title
                                    Text
                                    Caption
                                }
                                    
                                Table(pagination: { limit: 50 }){
                                    ColumnOne
                                    ColumnTwo
                                    ColumnThree
                                }
                            }

                            BottomPars{
              	                Title
                                Paragraph
                                Media{
                                    ${_}
                                }
                                Buttons{
                                    Text
                                    Link
                                }
                            }
              
                            ${H}
                        }
                    }
                }

                pageHome(locale:"${t}"){
                    data{
                        attributes{
                            HeroForm{
                                ActionButton{
                                    Link
                                }
                            }
                        }
                    }
                }
            }`,S0=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(ro,e)},Yn=R(g(S0,"s_weqlTobfNs4")),T0=()=>{const t=Yn();return i(F,{get data(){return t.value.layoutData},showHeader:!1,children:i(so,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"IJ_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"IJ_1")},D0=b(g(T0,"s_SV4gBpY0O00")),P0=({resolveValue:t})=>{const a=t(Yn).pageData.data.pageBastropP.data.attributes.SEO;return V(a)},k0=Object.freeze(Object.defineProperty({__proto__:null,default:D0,head:P0,usePageData:Yn},Symbol.toStringTag,{value:"Module"})),L0=t=>{const e=(a,l)=>a.slice(0,l)+"...";return n("div",null,{class:"flex max-w-[1200px] flex-row-reverse items-center justify-center self-center px-8 py-4 max-[800px]:flex-col-reverse"},[n("div",null,{class:"flex  flex-col items-center justify-start  gap-4 px-10 min-[800px]:w-[60%]"},[n("div",null,{class:""},[n("div",null,{class:"my-4 text-[32px] font-[600] leading-10 text-[#2E5899] max-sm:text-[24px] max-sm:leading-7"},u(a=>a.post.Title,[t],'p0.post["Title"]'),3,null),n("div",null,null,i(M,{classN:"max-sm:text-[13px] text-[15px] text-[#2E5899] text-justify [&>h1]:text-[15px] [&>h1]:font-[600] [&>h2]:text-[15px] [&>h2]:font-[600] [&>h3]:text-[15px] [&>h3]:font-[600]",text:e(t.post.Description,500),[s]:{classN:s}},3,"su_0"),1,null)],1,null),i(tt,{get text(){return t.isES?"Leer Más":"Read More"},get link(){return`/${t.isES?`es/${[t.post.Slug.replace("-es","")]}`:[t.post.Slug]}`},[s]:{text:u(a=>a.isES?"Leer Más":"Read More",[t],'p0.isES?"Leer Más":"Read More"'),link:u(a=>`/${a.isES?`es/${[a.post.Slug.replace("-es","")]}`:[a.post.Slug]}`,[t],'`/${p0.isES?`es/${[p0.post["Slug"].replace("-es","")]}`:[p0.post["Slug"]]}`')}},3,"su_1")],1,null),n("div",null,{class:"flex w-full items-center justify-center self-center p-4 min-[800px]:w-[40%]"},i(A,{get media(){return t.post.Cover.data.attributes},clasN:"rounded-[50px] shadow-2xl",width:"1184",height:"894",[s]:{media:u(a=>a.post.Cover.data.attributes,[t],'p0.post["Cover"]["data"]["attributes"]'),clasN:s,width:s,height:s}},3,"su_2"),1,null)],1,"su_3")},Zn=b(g(L0,"s_KKagOAzP0DM")),C0=t=>{const e=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],a=["January","February","March","April","May","June","July","August","September","October","November","December"];function l(c){const p=e[c.getDay()],d=c.getDate(),f=a[c.getMonth()],x=c.getFullYear();return`${p}, ${f} ${d}, ${x}`}const r=(c,p)=>c.slice(0,p)+"...",o=t.post.attributes.Slug.endsWith("-es");return n("div",null,{id:u(c=>c.id,[t],"p0.id"),class:"mb-8 flex max-w-[300px] flex-col"},[i(A,{width:"1184",height:"894",clasN:"rounded-2xl self-center object-cover h-[200px] w-[300px]",get media(){return t.post.attributes.Cover.data.attributes},[s]:{width:s,height:s,clasN:s,media:u(c=>c.post.attributes.Cover.data.attributes,[t],'p0.post["attributes"]["Cover"]["data"]["attributes"]')}},3,"j0_0"),n("h3",null,{class:"px-3 py-1 font-[600] text-[15px] text-primary-blue "},["  ",r(t.post.attributes.Title,60)],1,null),n("span",null,{class:"px-3 text-[12px] font-[700]  text-primary-blue opacity-70"},l(new Date(t.post.attributes.Date)),1,null),n("span",null,{class:"px-3 text-primary-blue"},n("div",{dangerouslySetInnerHTML:yr(r(t.post.attributes.Description,120))},{class:"flex list-inside flex-col gap-3 text-justify text-[14px]"},null,3,null),1,null),n("div",null,{class:"mt-2 self-center"},i(tt,{text:o?"Leer Más":"Read More",link:`/${o?`es/${[t.post.attributes.Slug.replace("-es","")]}`:[t.post.attributes.Slug]}`},3,"j0_1"),1,null)],1,"j0_2")},io=b(g(C0,"s_KUqCzJ00kfw")),M0=t=>{var c;const a=(c=rt().prevUrl)!=null&&c.pathname.includes("/es/")?"es-419":"en",l=C(t.posts.slice(1,(t.loadSize??6)+1)),r=C(!1),o=C(1);return n("div",{"document:onscroll$":B("s_t0DoAQDJl4Y",[a,r,o,t,l])},{id:"postLoader",class:"grid w-full max-w-[1200px] grid-cols-3 justify-evenly gap-4 px-4 max-[800px]:grid-cols-1 [&>*]:justify-self-center"},l.value.map((p,d)=>i(io,{post:p,id:`post-${d.toString()}`},3,d)),0,"4a_0")},Kn=b(g(M0,"s_HS0GyQ0UHYM")),j0=t=>n("div",null,{class:"flex flex-col items-center justify-center w-fit "},n("div",null,{class:"  px-2 mb-8  md:max-h-[150px]  overflow-y-scroll"},i(M,{classN:"text-[12.5px]",get text(){return t.slide.attributes.Content},[s]:{classN:s,text:u(e=>e.slide.attributes.Content,[t],'p0.slide["attributes"]["Content"]')}},3,"9l_0"),1,null),1,"9l_1"),A0=t=>{const e=t.data.TechTips.data,a=b(g(j0,"s_0D1CtJAueP4")),l=e.map((r,o)=>i(a,{slide:r},3,o));return n("div",null,{class:" gap-2 flex flex-row bg-white p-3 md:rounded-full rounded-3xl md:w-[750px] w-[90%] shadow-lg items-center"},[n("div",null,null,n("div",null,{class:"bg-[#2e5899] p-5 rounded-full shadow-lg md:min-h-[130px] md:max-w-[130px] md:max-h-[130px] max-w-[80px] flex justify-center items-center max-[768px]:hidden	"},n("div",null,{class:"bg-white md:p-5 p-2 w-fit h-fit items-center rounded-full  text-[#2e5899]"},i(yf,{class:" md:w-[55px] md:h-[55px] w-[30px] h-[30px] fill-[#2e5899]",[s]:{class:s}},3,"9l_2"),1,null),1,null),1,null),n("div",null,{class:" justify-center items-center  md:w-[650px] max-w-[100%]"},[n("div",null,{class:"text-[18px] tracking-wide font-[600] leading-10 text-[#2E5899]"},u(r=>r.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"h-fit relative flex md:w-[650px] max-w-[90%]  items-center justify-center overflow-hidden   "},i(Et,{slides:l,slidesQty:1,id:"techTipsCarousel",addSpace:!1,hasArrows:!1,[s]:{slidesQty:s,id:s,addSpace:s,hasArrows:s}},3,"9l_3"),1,null)],1,null)],1,"9l_4")},E0=b(g(A0,"s_600c5npFpQo")),N0=t=>{var o;const a=(o=rt().prevUrl)==null?void 0:o.pathname.includes("/es/"),l=t.data.pageBlog.data.attributes,r=l.Posts.data[0].attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(E0,{get data(){return l.Tips},[s]:{data:h(l,"Tips")}},3,"LH_0"),i(Zn,{post:r,isES:a},3,"LH_1"),n("div",null,{class:"my-4"},null,3,null),i(Kn,{get posts(){return l.Posts.data},loadSize:3,type:"Blog",[s]:{posts:h(l.Posts,"data"),loadSize:s,type:s}},3,"LH_2")],1,"LH_3")},I0=b(g(N0,"s_lTYqJJcPHc4")),B0=t=>` query QueryBlog {
        pageBlog(locale:"${t}"){    
          data{
          attributes{
            Tips{
              Title
              TechTips(sort: "Date:desc", pagination: { limit: 10 }){
                data{
                  attributes{
                    Content
                  }
                }
              }
            }
            Posts(sort: "Date:desc", pagination: { limit: 100 }){
                data{
                  attributes{
                    Title
                    Date
                    Cover{
                      ${_}
                    }
                    Description
                    VideoLink
                    Gallery{
                      ${_}
                    }
                    Slug
                  }
                }
              }
          
            ${H}
          }
        }
        }
      }`,O0=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(B0,e)},Jn=R(g(O0,"s_PlB05JNPqRo")),q0=()=>{const t=Jn();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageBlog.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageBlog.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBlog"]["data"]["attributes"]["SEO"]')}},3,"Yn_0"),i(I0,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Yn_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Yn_2")},R0=b(g(q0,"s_WiOXv30Ec4Y")),z0=({resolveValue:t})=>{const a=t(Jn).pageData.data.pageBlog.data.attributes.SEO;return V(a)},F0=Object.freeze(Object.defineProperty({__proto__:null,default:R0,head:z0,usePageData:Jn},Symbol.toStringTag,{value:"Module"})),Q0=t=>n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} bg-opacity-40 p-6 ${e.height??""} ${e.width??""} inline-block items-center justify-center rounded-full`,[t],'`${p0.color??"bg-[#2E5899]"} bg-opacity-40 p-6 ${p0.height??""} ${p0.width??""} inline-block items-center justify-center rounded-full`')},n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md`,[t],'`${p0.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md`')},n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md`,[t],'`${p0.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md`')},i(A,{clasN:"h-full w-full rounded-full object-cover",height:250,width:250,get media(){return t.media},[s]:{clasN:s,height:s,width:s,media:u(e=>e.media,[t],"p0.media")}},3,"03_0"),1,null),1,null),1,"03_1"),ha=b(g(Q0,"s_CA0rJqJDom0")),G0=t=>n("div",null,{class:"flex w-fit flex-wrap gap-12 md:gap-20 m-5 items-center justify-center"},t.data.MembersGrid.map((e,a)=>z(n("div",null,{class:"w-[300px] h-[300px] items-center justify-around flex flex-col"},[i(ha,{width:"w-[200px]",height:"h-[200px]",get media(){return e.Picture.data.attributes},[s]:{width:s,height:s,media:h(e.Picture.data,"attributes")}},3,"Q1_0"),n("h2",null,{class:"font-bold text-primary-blue text-xl"},[S(e,"FirstName")," ",S(e,"LastName")],1,null),n("p",null,{class:"text-sm text-primary-blue"},S(e,"Position"),1,null),e.SocialMedia.length>0&&n("a",{href:S(e.SocialMedia[0],"Link")},null,n("div",null,{class:"h-[30px] w-[30px] flex items-center justify-center bg-white shadow rounded-full p-1.5"},i(lf,{class:"fill-primary-blue",[s]:{class:s}},3,"Q1_1"),1,null),1,"Q1_2")],1,a))),1,"Q1_3"),oo=b(g(G0,"s_fHxbC9gELko")),H0=t=>`query QueryBoardOfDirectors{
        pageBDirectors(locale:"${t}"){
          data{
            attributes{
              ${Zi}
              ${H}
              }
            }
          }
        }`,V0=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(H0,e)},Xn=R(g(V0,"s_zIMYdRdJ00w")),W0=()=>{const t=Xn(),e=t.value.pageData.data.pageBDirectors.data.attributes;return i(G,{children:i(F,{get data(){return t.value.layoutData},showHeader:!0,children:[i(et,{get SEOdata(){return t.value.pageData.data.pageBDirectors.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageBDirectors.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBDirectors"]["data"]["attributes"]["SEO"]')}},3,"ts_0"),i(oo,{data:e},3,"ts_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"ts_2")},1,"ts_3")},U0=b(g(W0,"s_IBN44L8LT0g")),Y0=({resolveValue:t})=>{const a=t(Xn).pageData.data.pageBDirectors.data.attributes.SEO;return V(a)},Z0=Object.freeze(Object.defineProperty({__proto__:null,default:U0,head:Y0,usePageData:Xn},Symbol.toStringTag,{value:"Module"})),K0=async(t,e)=>{const a=await fetch("https://cblsrvr1.rtatel.com/planbuilder/api",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"products",networkType:e,customerType:"residential",locationgroup:t})}),l=await fetch("https://cblsrvr1.rtatel.com/planbuilder/api",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"products",networkType:e,customerType:"business",locationgroup:t})});a.ok||console.error("Error residential products search"),l.ok||console.error("Error business product search");const r=await a.json(),o=await l.json(),{gigfastInternetProductsResidential:c,gigfastVoiceResidential:p}=r.result.reduce((x,m)=>(m.family==="gigFastInternet"?x.gigfastInternetProductsResidential.push(m):m.family==="gigFastVoice"&&x.gigfastVoiceResidential.push(m),x),{gigfastInternetProductsResidential:[],gigfastVoiceResidential:[]}),{gigfastInternetProductsBusiness:d,gigfastVoiceBusiness:f}=o.result.reduce((x,m)=>(m.family==="gigFastInternet"?x.gigfastInternetProductsBusiness.push(m):m.family==="gigFastVoice"&&x.gigfastVoiceBusiness.push(m),x),{gigfastInternetProductsBusiness:[],gigfastVoiceBusiness:[]});return console.log(c),{residentialInternet:c,businessInternet:d,residentialVoice:p,businessVoice:f}};function J0(t){const e=Object.keys(t),a=Object.values(t);return[e.join(","),a.join(",")].join(`
`)}function X0(t,e){const a=J0(t),l=new Blob([a],{type:"text/csv;charset=utf-8;"}),r=document.createElement("a");if(r.download!==void 0){const o=URL.createObjectURL(l);r.setAttribute("href",o),r.setAttribute("download",e),r.style.visibility="hidden",document.body.appendChild(r),r.click(),document.body.removeChild(r)}}const tx=t=>{const e=document.getElementById(t),a=t.replace("div-plan-","");e.querySelectorAll("hr").forEach(l=>{l.style.marginTop="5px",l.style.marginBottom="5px"}),_r(e,{scale:1}).then(l=>{const r=l.toDataURL("image/png"),o=325/96*25.4,c=1300/96*25.4,p=new So("p","mm",[o,c]),d=o,f=l.height*d/l.width;p.addImage(r,"PNG",0,0,d,f),e.querySelectorAll("a").forEach(m=>{const $=m.getAttribute("href"),y=m.getBoundingClientRect(),P=y.left/96*25.4,w=y.top/96*25.4,D=y.width/96*25.4,v=y.height/96*25.4;p.link(P,w,D,v,{url:$})}),p.save(a+".pdf")}),e.querySelectorAll("hr").forEach(l=>{l.style.marginTop="0px",l.style.marginBottom="0px"})},ex=t=>{const e=document.getElementById(t),a=t.replace("div-plan-","");e.querySelectorAll("hr").forEach(l=>{l.style.marginTop="5px",l.style.marginBottom="5px"}),_r(e,{scale:1}).then(l=>{const r=l.toDataURL("image/png"),o=document.createElement("a");o.href=r,o.download=`${a}.png`,o.style.visibility="hidden",document.body.appendChild(o),o.click(),document.body.removeChild(o)}),e.querySelectorAll("hr").forEach(l=>{l.style.marginTop="0px",l.style.marginBottom="0px"})},ax=()=>{const[t]=U();return X0(t,`${t.unique_plan_id}.csv`)},lx=()=>{const[t]=U();return tx("div-plan-"+t.unique_plan_id)},nx=()=>{const[t]=U();return ex("div-plan-"+t.unique_plan_id)},sx=t=>{var p;const e={unique_plan_id:t.unique_plan_id,provider_name:t.providerName??"Rural Telecommunications of America",service_plan_name:t.service_plan_name,tier_plan_name:t.tier_plan_name,connection_type:t.connection_type,monthly_price:t.monthly_price,intro_rate:t.intro_rate==="N/A"?"NULL":t.intro_rate,intro_rate_price:t.intro_rate_price,intro_rate_time:t.intro_rate_time==="N/A"?"0":t.intro_rate_time,contract_req:t.contract_req==="N/A"?"NULL":t.contract_req,contract_time:t.contract_time==="N/A"?"0":t.contract_time,contract_terms_url:t.contract_terms_url,early_termination_fee:t.early_termination_fee==="N/A"?"NULL":t.early_termination_fee,single_purchase_fee_descr:t.single_purchase_fee_descr==="N/A"?"NULL":t.single_purchase_fee_descr,single_purchase_fees:t.single_purchase_fees==="N/A"?"NULL":t.single_purchase_fees,monthly_provider_fee_descr:t.monthly_provider_fee_descr==="N/A"?"NULL":t.monthly_provider_fee_descr,monthly_provider_fee:t.monthly_provider_fee==="N/A"?"NULL":t.monthly_provider_fee,tax:t.tax,bundle_discounts_url:t.bundle_discounts_url,typical_download_speed:t.typical_download_speed,typical_upload_speed:t.typical_upload_speed,typical_latency:t.typical_latency==="N/A"?"0":t.typical_latency,monthly_data_allow:t.monthly_data_allow==="N/A"?"NULL":t.monthly_data_allow,over_usage_data_price:t.over_usage_data_price==="N/A"?"0":t.over_usage_data_price,additional_data_increment:t.additional_data_increment==="N/A"?"0":t.additional_data_increment,data_allowance_policy_url:t.data_allowance_policy_url,network_management_policy_url:t.network_management_policy_url,privacy_policy_url:t.privacy_policy_url,customer_support_phone:t.customer_support_phone,customer_support_web:t.customer_support_web},l=(p=rt().prevUrl)==null?void 0:p.pathname.includes("/es/"),r=g(ax,"s_dGbD0aEN34E",[e]),o=g(lx,"s_c4OlAowgKj0",[e]),c=g(nx,"s_hkOekiixbYM",[e]);return n("div",null,{class:"flex flex-col items-start"},[n("div",{id:"div-plan-"+e.unique_plan_id},{class:"mx-2 my-5 overflow-hidden w-[325px] min-h-[1000px] p-3 border-4 border-black bg-white shrink-0"},[n("header",null,null,[n("h2",null,{class:"text-2xl font-extrabold text-center"},t.isVoice==!0?l?"Información del Servicio telefónico":"Phone Service Facts":l?"Información de Internet de Banda Ancha":"Broadband Facts",1,null),n("hr",null,{class:"border-black border-2"},null,3,null),n("p",null,{class:"text-base font-bold"},u(d=>d.providerName??"Rural Telecommunications of America",[t],'p0.providerName??"Rural Telecommunications of America"'),3,null),n("p",null,{class:"text-base font-extrabold"},S(e,"service_plan_name"),1,null),n("p",null,{class:"text-base"},l?"Declaración de transparencia para el usuario de servicios de internet de banda ancha fija.":`${t.connection_type} Broadband Consumer Disclosure`,1,null)],1,null),n("hr",null,{class:"border-black border-4"},null,3,null),n("div",null,{class:"grid grid-cols-2 font-extrabold"},[n("p",null,null,l?"Precio mensual":"Monthly Price",1,null),n("p",null,{class:"text-right"},["$ ",S(e,"monthly_price")],1,null)],1,null),n("hr",null,{class:"border-2 border-black"},null,3,null),n("div",null,{class:"grid grid-cols-2 text-sm gap-2"},[n("p",null,null,l?"Este precio mensual corresponde a una tarifa inicial":"This monthly price is an introductory rate",1,null),n("p",null,{class:"text-right"},u(d=>d.intro_rate,[t],"p0.intro_rate"),3,null),n("p",null,null,l?"Lapso al que se aplica la tarifa inicial":"Time the introductory rate applies",1,null),n("p",null,{class:"text-right"},l?`${t.intro_rate_time} meses`:`${t.intro_rate_time} months`,1,null),n("p",null,null,l?"Precio mensual posterior a la tarifa inicial":"Monthly price after the introductory rate",1,null),n("p",null,{class:"text-right"},["$",S(e,"intro_rate_price")],1,null),n("p",null,null,l?"Duración del contrato":"Length of contract",1,null),n("p",null,{class:"text-right"},u(d=>d.contract_time,[t],"p0.contract_time"),3,null),n("p",null,{class:"col-span-2"},l?"Enlace a los términos del contrato":"Link to Terms of Contract",1,null)],1,null),e.contract_terms_url&&n("p",null,{class:"text-sm"},n("a",{href:S(e,"contract_terms_url")},null,S(e,"contract_terms_url"),1,null),1,"F7_0"),n("hr",null,{class:"border-2 border-black"},null,3,null),n("div",null,{class:"text-sm"},[n("p",null,{class:"font-bold"},l?"Cargos y condiciones adicionales":"Additional Charges & Terms",1,null),n("div",null,{class:"grid grid-cols-[2fr_1fr] gap-1 p-2"},[n("p",null,{class:"col-span-2"},l?"Tarifas mensuales del proveedor":"Provider Monthly Fees",1,null),n("div",null,{class:"col-span-2 h-2"},null,3,null),n("p",null,{class:"col-span-2"},l?"Tarifas cobradas una sola vez":"One-Time Purchase Fees",1,null),n("div",null,{class:"col-span-2 h-2"},null,3,null),n("p",null,null,l?"Tarifa por fin del servicio antes de lo pactado":"Early Termination Fee",1,null),n("p",null,{class:"text-right font-bold"},u(d=>d.early_termination_fee,[t],"p0.early_termination_fee"),3,null),n("p",null,null,l?"Impuestos gubernamentales":"Government Taxes",1,null),n("p",null,{class:"text-right font-bold"},l?"Varía según la ubicación":"Varies by Location",1,null)],1,null)],1,null),n("hr",null,{class:"border-2 border-black"},null,3,null),n("div",null,{class:"text-sm"},[n("p",null,{class:"font-bold"},l?"Descuentos y servicios combinados":"Discounts & Bundles",1,null),n("p",null,null,n("a",{href:S(e,"bundle_discounts_url")},null,[" ",S(e,"bundle_discounts_url")],1,null),1,null)],1,null),n("hr",null,{class:"border-2 border-black"},null,3,null),t.isVoice!=!0&&i(G,{children:[n("div",null,{class:"text-sm"},[n("p",null,{class:"font-bold"},l?"Velocidades de internet proporcionadas con este plan":"Speeds Provided with Plan",1,null),n("div",null,{class:"grid grid-cols-[2fr_1fr] gap-1 p-2"},[n("p",null,null,l?"Velocidad típica de descarga de datos":"Typical Download Speed",1,null),n("p",null,{class:"text-right font-bold"},u(d=>d.typical_download_speed+" Mbps",[t],'p0.typical_download_speed+" Mbps"'),3,null),n("p",null,null,l?"Velocidad típica de carga de datos":"Typical Upload Speed",1,null),n("p",null,{class:"text-right font-bold"},u(d=>d.typical_upload_speed+" Mbps",[t],'p0.typical_upload_speed+" Mbps"'),3,null),n("p",null,null,l?"Latencia típica":"Typical latency",1,null),n("p",null,{class:"text-right font-bold"},[u(d=>d.typical_latency,[t],"p0.typical_latency")," ms"],3,null)],1,null)],1,null),n("hr",null,{class:"border-black"},null,3,null),n("div",null,{class:"text-sm grid grid-cols-[3fr_1fr]"},[n("p",null,{class:"font-bold"},l?"Volumen de datos incluido en este precio mensual":"Data Included with Monthly Price",1,null),n("p",null,{class:"text-right font-bold"},u(d=>d.monthly_data_allow,[t],"p0.monthly_data_allow"),3,null),n("div",null,{class:"p-2 col-span-2"},[n("div",null,{class:"grid grid-cols-2 gap-1"},[n("p",null,null,l?"Cargos por uso adicional de datos ":"Charges for Additional Data Usage",1,null),n("p",null,{class:"text-right font-bold"},["$",u(d=>d.over_usage_data_price,[t],"p0.over_usage_data_price")],3,null)],1,null),t.data_allowance_policy_url!="N/A"&&n("p",null,{class:"text-sm"},n("a",{href:S(e,"data_allowance_policy_url")},null,S(e,"data_allowance_policy_url"),1,null),1,"F7_1")],1,null)],1,null),n("hr",null,{class:"border-2 border-black"},null,3,null)]},1,"F7_2"),n("div",null,{class:"text-sm"},[n("p",null,null,n("strong",null,null,l?"Política de administración de redes":"Network Management Policy",1,null),1,null),n("a",{href:S(e,"network_management_policy_url")},{class:"px-2",target:"_blank",rel:"noreferrer"},S(e,"network_management_policy_url"),1,null),n("p",null,null,n("strong",null,null,l?"Políticas de privacidad":"Privacy Policy",1,null),1,null),n("a",{href:S(e,"privacy_policy_url")},{class:"px-2",target:"_blank",rel:"noreferrer"},S(e,"privacy_policy_url"),1,null)],1,null),n("hr",null,{class:"border-4 border-black"},null,3,null),n("div",null,{class:"text-sm"},[n("p",null,{class:"font-bold"},l?"Política de privacidad":"Customer Support",1,null),n("p",null,{class:"px-2"},[l?"Teléfono:":"Phone:"," ",n("a",{href:`tel:${e.customer_support_phone}`},null,S(e,"customer_support_phone"),1,null)],1,null),n("p",null,{class:"px-2"},[l?"Sitio web:":"Website:"," ",n("a",{href:S(e,"customer_support_web")},{target:"_blank",rel:"noreferrer"},S(e,"customer_support_web"),1,null)],1,null)],1,null),n("hr",null,{class:"border border-black"},null,3,null),n("p",null,{class:"text-sm"},[" ",l?"Familiarícese con el lenguaje utilizado en esta etiqueta. Visite el sitio web del área de recursos para el consumidor, de la Comisión Federal de Comunicaciones (FCC).":"Learn more about the terms used on this label by visiting the Federal Communications Commission's Consumer Resource Center."],1,null),n("p",null,{class:"text-sm text-right"},n("strong",null,null,n("a",null,{href:"https://fcc.gov/consumer",target:"_blank",rel:"noreferrer"},"fcc.gov/consumer",3,null),3,null),3,null),e.unique_plan_id!="N/A"&&n("p",null,{class:"text-sm"},l?`Identificador Único de Plan: ${e.unique_plan_id}`:`Unique Plan Identifier: ${e.unique_plan_id}`,1,"F7_3")],1,null),n("div",null,{class:"flex flex-col items-center justify-evenly gap-2 w-full"},[i(tt,{text:"Download as CSV",onClick:r,[s]:{text:s,onClick:s}},3,"F7_4"),i(tt,{text:"Download as PDF",onClick:o,[s]:{text:s,onClick:s}},3,"F7_5"),i(tt,{text:"Download as PNG",onClick:c,[s]:{text:s,onClick:s}},3,"F7_6")],1,null)],1,"F7_7")},Kl=b(g(sx,"s_bo6y7DBk1eY")),rx=t=>{if(!t.isVisible||t.plans.length===0)return null;const e=t.plans.sort((a,l)=>a.name.includes("ESSENTIALgig")&&!l.name.includes("ESSENTIALgig")?-1:!a.name.includes("ESSENTIALgig")&&l.name.includes("ESSENTIALgig")?1:0);return n("div",null,{class:u(a=>`w-full flex-col gap-2 ${a.isVisible?"flex":"hidden"}`,[t],'`w-full flex-col gap-2 ${p0.isVisible?"flex":"hidden"}`')},[n("div",null,{class:"my-8 max-w-[350px] sm:max-w-[500px] mx-auto"},n("img",{src:gt(t.broadbandPageData.LogoServices.data[t.index].attributes.url)},{width:1230,height:229,alt:u(a=>a.broadbandPageData.LogoServices.data[a.index].attributes.alternativeText,[t],'p0.broadbandPageData["LogoServices"]["data"][p0.index]["attributes"]["alternativeText"]')},null,3,null),1,null),n("h2",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(a=>a.broadbandPageData.CustomerType[a.customerTypeIndex].title,[t],'p0.broadbandPageData["CustomerType"][p0.customerTypeIndex]["title"]'),3,null),n("div",null,{class:u(a=>`flex w-full overflow-x-auto gap-1 px-4 flex-row ${a.plans.length>3?"justify-start":"xl:justify-center"}  mb-4 pb-4`,[t],'`flex w-full overflow-x-auto gap-1 px-4 flex-row ${p0.plans.length>3?"justify-start":"xl:justify-center"}  mb-4 pb-4`'),style:"scrollbar-width: thin; scrollbar-color: #2E5698 #f1f1f1;"},e.map((a,l)=>{var r,o,c,p,d,f,x,m,$,y,P,w,D,v,L,k,T,I,E,N,j,O,W,K,Y,it,dt,nt,at,pt,It,Bt,Ct,Wt,Ut,Yt,Zt,Kt,Jt,Xt,te,ee,ae,le,ne,se,re,ie,oe,ue,ce,de,pe,fe,ge,xe,me,he,be,$e,ve,ye,_e,we,Se,Te,De,Pe,ke,Le,Ce,Me,je;return i(Kl,{tier_plan_name:"NULL",connection_type:((c=(o=(r=a.values)==null?void 0:r.connection_type)==null?void 0:o[0])==null?void 0:c.data)||"N/A",monthly_price:((d=(p=a.values)==null?void 0:p.monthly_price)==null?void 0:d[0].data)||a.price,get service_plan_name(){return a.name},intro_rate:((m=(x=(f=a.values)==null?void 0:f.intro_rate)==null?void 0:x[0])==null?void 0:m.data)||"No",intro_rate_price:((P=(y=($=a.values)==null?void 0:$.intro_rate_price)==null?void 0:y[0])==null?void 0:P.data)||"0.00",intro_rate_time:((v=(D=(w=a.values)==null?void 0:w.intro_rate_time)==null?void 0:D[0])==null?void 0:v.data)||"N/A",contract_req:((T=(k=(L=a.values)==null?void 0:L.contract_req)==null?void 0:k[0])==null?void 0:T.data)||"No",contract_time:((N=(E=(I=a.values)==null?void 0:I.contract_time)==null?void 0:E[0])==null?void 0:N.data)||"N/A",contract_terms_url:((W=(O=(j=a.values)==null?void 0:j.contract_terms_url)==null?void 0:O[0])==null?void 0:W.data)||"",early_termination_fee:((it=(Y=(K=a.values)==null?void 0:K.early_termination_fee)==null?void 0:Y[0])==null?void 0:it.data)||"0.00",single_purchase_fee_descr:((at=(nt=(dt=a.values)==null?void 0:dt.single_purchase_fee_descr)==null?void 0:nt[0])==null?void 0:at.data)||"",single_purchase_fees:((Bt=(It=(pt=a.values)==null?void 0:pt.single_purchase_fees)==null?void 0:It[0])==null?void 0:Bt.data)||"",monthly_provider_fee_descr:((Ut=(Wt=(Ct=a.values)==null?void 0:Ct.monthly_provider_fee_descr)==null?void 0:Wt[0])==null?void 0:Ut.data)||"",monthly_provider_fee:((Kt=(Zt=(Yt=a.values)==null?void 0:Yt.monthly_provider_fee)==null?void 0:Zt[0])==null?void 0:Kt.data)||"",tax:((te=(Xt=(Jt=a.values)==null?void 0:Jt.tax)==null?void 0:Xt[0])==null?void 0:te.data)||"Varies",bundle_discounts_url:((le=(ae=(ee=a.values)==null?void 0:ee.bundle_discounts_url)==null?void 0:ae[0])==null?void 0:le.data)||"",get typical_download_speed(){return a.values.typical_download_speed[0].data},get typical_upload_speed(){return a.values.typical_upload_speed[0].data},typical_latency:((re=(se=(ne=a.values)==null?void 0:ne.typical_latency)==null?void 0:se[0])==null?void 0:re.data)||"N/A",unique_plan_id:((oe=(ie=a.values.unique_plan_id)==null?void 0:ie[0])==null?void 0:oe.data)||"N/A",monthly_data_allow:((de=(ce=(ue=a.values)==null?void 0:ue.monthly_data_allow)==null?void 0:ce[0])==null?void 0:de.data)||"Unlimited",over_usage_data_price:((ge=(fe=(pe=a.values)==null?void 0:pe.over_usage_data_price)==null?void 0:fe[0])==null?void 0:ge.data)||"N/A",additional_data_increment:((he=(me=(xe=a.values)==null?void 0:xe.additional_data_increment)==null?void 0:me[0])==null?void 0:he.data)||"N/A",data_allowance_policy_url:((ve=($e=(be=a.values)==null?void 0:be.data_allowance_policy_url)==null?void 0:$e[0])==null?void 0:ve.data)||"",network_management_policy_url:((we=(_e=(ye=a.values)==null?void 0:ye.network_management_policy_url)==null?void 0:_e[0])==null?void 0:we.data)||"",privacy_policy_url:((De=(Te=(Se=a.values)==null?void 0:Se.privacy_policy_url)==null?void 0:Te[0])==null?void 0:De.data)||"",customer_support_phone:((Le=(ke=(Pe=a.values)==null?void 0:Pe.customer_support_phone)==null?void 0:ke[0])==null?void 0:Le.data)||"",customer_support_web:((je=(Me=(Ce=a.values)==null?void 0:Ce.customer_support_web)==null?void 0:Me[0])==null?void 0:je.data)||"",get isVoice(){return t.isVoice??!1},[s]:{tier_plan_name:s,service_plan_name:h(a,"name"),typical_download_speed:h(a.values.typical_download_speed[0],"data"),typical_upload_speed:h(a.values.typical_upload_speed[0],"data"),isVoice:u(Ue=>Ue.isVoice??!1,[t],"p0.isVoice??false")}},3,`Broadband-${t.isVoice??!1?"Voice":"Internet"}-${t.customerTypeIndex}-${l}`)}),1,null)],1,"pq_0")},Wa=b(g(rx,"s_sFxDBHRht1E")),ix=()=>{const[t,e,a,l,r,o,c,p,d,f,x]=U();a.value!=""&&l.value!=""?(e.value=!0,c.value=[],o.value=[],p.value=[],d.value=[],no(a.value,l.value,x.value.value).then($=>{t.value=$.coverage,r.value=$.locationgroup,f.value=$.type,t.value&&r.value!=""&&f.value!=""&&K0(r.value,f.value).then(y=>{e.value=!1,c.value=[...y.residentialInternet],o.value=[...y.businessInternet],p.value=[...y.businessVoice],d.value=[...y.residentialVoice]})}),t.value=!0,l.value="",a.value=""):t.value=!1},ox=()=>{const[t,e,a,l]=U();clearTimeout(l.value),l.value=setTimeout(()=>{t.value.value.length>2&&fetch(`/api/get-streets?q=${encodeURIComponent(t.value.value)}`).then(r=>r.json()).then(r=>{const o=r.data;o.length===0?e.value="notfound":e.value="success",a.value=o})},1e3)},ux=t=>{var E;z();const a=(E=rt().prevUrl)==null?void 0:E.pathname.includes("/es/"),l=t.data.pageBroadbandlabel.data.attributes,r=C(n("input",null,null,null,3,"9H_0")),o=C(n("input",null,null,null,3,null)),c=C(!0),p=C(!1),d=C(""),f=C(""),x=C(!1),m=C(""),$=C(""),y=C([]),P=C([]),w=C([]),D=C([]),v=C(),L=C([]),k=C("none"),T=g(ix,"s_oOiYJTdwxCg",[c,p,m,$,d,P,y,D,w,f,o]),I=g(ox,"s_FHeWve9kCIk",[r,k,L,v]);return n("div",null,{class:"flex flex-col items-center justify-around"},[n("h1",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},S(l,"Title"),1,null),n("div",null,{class:"bg-white md:h-[200px] h-[220px] rounded-full md:w-1/2 w-[90%] flex flex-col items-center justify-around my-5 gap-2"},[n("p",null,{class:"px-8 text-center text-[22px] font-[600] text-primary-blue max-[1000px]:px-12"},S(l.Form,"Title"),1,null),n("form",null,{action:"",class:"w-3/4 flex items-center justify-center gap-4 md:flex-row flex-col"},[n("input",{placeholder:S(l.Form.Fields[0],"Placeholder"),ref:r},{class:"md:w-[50%] w-[80%] rounded-full px-3 py-2 placeholder-primary-blue bg-primary-light-blue/20",required:!0,type:"text",onKeyUp$:I},null,3,null),n("input",{ref:o},{class:"w-[60%] rounded-full px-3 py-2 hidden placeholder-primary-blue",placeholder:"Zip Code",type:"text"},null,3,null),i(tt,{get text(){return l.Form.ActionButton.Text},onClick:T,[s]:{text:h(l.Form.ActionButton,"Text"),onClick:s}},3,"9H_1")],1,null),n("p",null,{class:"text-xs text-primary-blue text-center "},a?"Ingresa tu dirección y selecciona la opción correcta de la lista desplegable que aparecerá":"Enter your address and select the correct option from the dropdown list that appears",1,null),n("label",null,{class:u(N=>`${N.value===!0?"flex":"hidden"} inline-flex items-center mb-5 cursor-pointer`,[c],'`${p0.value===true?"flex":"hidden"} inline-flex items-center mb-5 cursor-pointer`')},[n("input",null,{type:"checkbox",checked:u(N=>N.value,[x],"p0.value"),class:"sr-only peer",onChange$:B("s_fwlhznFW0dw",[x])},null,3,null),n("span",null,{class:"me-3 text-sm font-medium text-primary-blue"},S(l.CustomerType[0],"title"),1,null),n("div",null,{class:"relative w-11 h-6 bg-secondary-red peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full  rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:w-5 after:h-5 after:transition-all peer-checked:bg-primary-blue"},null,3,null),n("span",null,{class:"ms-3 text-sm font-medium text-primary-blue"},S(l.CustomerType[1],"title"),1,null)],1,null),n("p",null,{class:u(N=>`${N.value?"hidden":"flex"} text-secondary-red text-xl font-bold`,[c],'`${p0.value?"hidden":"flex"} text-secondary-red text-xl font-bold`')},S(l,"Message"),1,null)],1,null),n("div",{class:`flex max-h-[200px] flex-col gap-3 overflow-y-auto rounded-xl bg-white p-6 text-primary-blue shadow-lg ${k.value==="none"||k.value==="selected"?"hidden":""}`},null,[u(N=>N.value.length===0?"Not found":"",[L],'p0.value.length===0?"Not found":""'),L.value.map((N,j)=>n("div",{onClick$:B("s_Rx2cqo40ueo",[r,m,$,N,k,o])},{class:"grid items-center gap-4 hover:cursor-pointer",style:{gridTemplateColumns:"20px 1fr"}},[i(Dl,{class:"w-6 text-secondary-red",[s]:{class:s}},3,"9H_2"),n("span",null,{class:"text-[14px]"},S(N,"address"),1,null)],0,j))],1,null),p.value&&i(At,{size:"100px",[s]:{size:s}},3,"9H_3"),c.value&&i(G,{children:[i(Wa,{get isVisible(){return!x.value},get plans(){return y.value},broadbandPageData:l,index:0,customerTypeIndex:0,[s]:{isVisible:u(N=>!N.value,[x],"!p0.value"),plans:u(N=>N.value,[y],"p0.value"),index:s,customerTypeIndex:s}},3,"9H_4"),i(Wa,{get isVisible(){return x.value},get plans(){return P.value},broadbandPageData:l,index:0,customerTypeIndex:1,[s]:{isVisible:u(N=>N.value,[x],"p0.value"),plans:u(N=>N.value,[P],"p0.value"),index:s,customerTypeIndex:s}},3,"9H_5"),i(Wa,{get isVisible(){return!x.value},get plans(){return w.value},broadbandPageData:l,index:1,customerTypeIndex:0,isVoice:!0,[s]:{isVisible:u(N=>!N.value,[x],"!p0.value"),plans:u(N=>N.value,[w],"p0.value"),index:s,customerTypeIndex:s,isVoice:s}},3,"9H_6"),i(Wa,{get isVisible(){return x.value},get plans(){return D.value},broadbandPageData:l,index:1,customerTypeIndex:1,isVoice:!0,[s]:{isVisible:u(N=>N.value,[x],"p0.value"),plans:u(N=>N.value,[D],"p0.value"),index:s,customerTypeIndex:s,isVoice:s}},3,"9H_7")]},1,"9H_8")],1,null)},cx=b(g(ux,"s_0yKdtlPJIF0")),dx=t=>`query{
  pageBroadbandlabel(locale:"${t}"){
    data{
      attributes{
        Title
        Form{
          Title
          Fields{
            Placeholder
          }
            ActionButton{
            Text
          }
        }
        
        LogoServices{
          data{
            attributes{
              url
              alternativeText
              caption
            }
          }
        }
        
        CustomerType{
          title
        }
        
        Message

        ${H}
      }
    }
  }
}`,px=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(dx,e)},ts=R(g(px,"s_gl1xJfSALxI")),fx=()=>{const t=ts();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageBroadbandlabel.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageBroadbandlabel.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBroadbandlabel"]["data"]["attributes"]["SEO"]')}},3,"LE_0"),i(cx,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"LE_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"LE_2")},gx=b(g(fx,"s_OUtP24mMYqU")),xx=({resolveValue:t})=>{const a=t(ts).pageData.data.pageBroadbandlabel.data.attributes.SEO;return V(a)},mx=Object.freeze(Object.defineProperty({__proto__:null,default:gx,head:xx,usePageData:ts},Symbol.toStringTag,{value:"Module"})),hx=t=>{const e=t.data.pageBusiness.data.attributes.Services;return n("div",null,null,i(We,{data:e},3,"zl_0"),1,"zl_1")},bx=b(g(hx,"s_u188pr8UG0M")),$x=t=>`query QueryBusiness {
    pageBusiness(locale:"${t}"){    
      data{
        attributes{
          Services{
            Logo{
              ${_}
            }
            Media{
              ${_}
            }
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
             ${H}
  
        }
      }
    }
  }`,vx=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q($x,e)},es=R(g(vx,"s_oQUmv8Ne7NI")),yx=()=>{const t=es();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageBusiness.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageBusiness.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBusiness"]["data"]["attributes"]["SEO"]')}},3,"Uj_0"),i(bx,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Uj_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Uj_2")},_x=b(g(yx,"s_JufSC5OrOV4")),wx=({resolveValue:t})=>{const a=t(es).pageData.data.pageBusiness.data.attributes.SEO;return V(a)},Sx=Object.freeze(Object.defineProperty({__proto__:null,default:_x,head:wx,usePageData:es},Symbol.toStringTag,{value:"Module"})),Tx=t=>(console.log(t.data),n("div",null,{class:"relative flex w-full items-center justify-center z-0"},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 z-10 grid",style:{gridTemplateRows:"35px 35px 1fr 35px 35px",gridTemplateColumns:"100%"}},[n("div",null,{class:"bg-white opacity-50"},null,3,null),n("div",null,{class:"bg-white opacity-80"},null,3,null),n("div",null,{class:"bg-white "},null,3,null),n("div",null,{class:"bg-white opacity-80"},null,3,null),n("div",null,{class:"bg-white opacity-50"},null,3,null)],3,null),n("div",null,{class:"z-10 flex flex-wrap items-center justify-center px-8 text-center text-[30px] font-[700] text-primary-blue"},[i(A,{clasN:"w-[300px] max-[1000px]:hidden",get media(){return t.data.HeaderPictures.data[0].attributes},[s]:{clasN:s,media:u(e=>e.data.HeaderPictures.data[0].attributes,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]')}},3,"bE_0"),n("div",null,{class:"flex flex-col items-center justify-center max-w-[400px]"},[i(A,{clasN:"w-[200px]",get media(){return t.data.HeaderLogo.data.attributes},[s]:{clasN:s,media:u(e=>e.data.HeaderLogo.data.attributes,[t],'p0.data["HeaderLogo"]["data"]["attributes"]')}},3,"bE_1"),t.data.HeaderTitle&&t.data.HeaderTitle.map(e=>n("span",null,null,S(e,"Text"),1,"bE_2"))],1,null),i(A,{clasN:"w-[300px]",get media(){return t.data.HeaderPictures.data[1].attributes},[s]:{clasN:s,media:u(e=>e.data.HeaderPictures.data[1].attributes,[t],'p0.data["HeaderPictures"]["data"][1]["attributes"]')}},3,"bE_3")],1,null)],1,"bE_4")),Dx=b(g(Tx,"s_YWCAmY4twe0")),Px=t=>n("div",null,{class:"flex h-[250px] w-[170px] flex-col items-center justify-start gap-3 rounded-[16px] bg-white p-3 text-center shadow-lg"},[i(A,{clasN:"h-[80px] w-[100%] object-cover rounded-[16px] bg-primary-blue bg-opacity-10",get media(){return t.offer.Media.data.attributes},width:"240",height:"120",[s]:{clasN:s,media:u(e=>e.offer.Media.data.attributes,[t],'p0.offer["Media"]["data"]["attributes"]'),width:s,height:s}},3,"IA_0"),n("h3",null,{class:"text-[18px] font-[600]"},u(e=>e.offer.Title,[t],'p0.offer["Title"]'),3,null),n("p",null,{class:"text-[14px] font-[400]"},u(e=>e.offer.Paragraph,[t],'p0.offer["Paragraph"]'),3,null)],1,"IA_1"),kx=t=>{const e=b(g(Px,"s_7vgX9wWJy0Y"));return n("div",null,{class:"flex w-full justify-center px-8"},n("div",null,{class:"mt-10 flex max-w-[1400px] items-center justify-center gap-8 px-8 text-center text-primary-blue max-[1000px]:flex-col"},[n("div",null,{class:"flex w-[50%] flex-col max-[1000px]:w-[100%]"},[n("h3",null,{class:"mt-3 text-[40px] font-[700]"},u(a=>a.data.BeliefsTitle,[t],'p0.data["BeliefsTitle"]'),3,null),n("span",null,{class:"text-[28px] font-[600]"},u(a=>a.data.BeliefsSubtitle,[t],'p0.data["BeliefsSubtitle"]'),3,null),n("span",null,{class:"text-[26px] font-[600] text-secondary-red"},u(a=>a.data.Beliefs[0].Text,[t],'p0.data["Beliefs"][0]["Text"]'),3,null),n("p",null,{class:"mt-3 text-[20px]"},u(a=>a.data.BeliefsDescription,[t],'p0.data["BeliefsDescription"]'),3,null)],3,null),n("div",null,{class:"flex w-[50%] flex-col items-center justify-center max-[1000px]:w-[100%]"},[n("h4",null,{class:"text-[40px] font-[700]"},u(a=>a.data.OfferingTitle,[t],'p0.data["OfferingTitle"]'),3,null),n("div",null,{class:"mt-4 flex flex-wrap justify-center gap-6"},t.data.Offerings.map((a,l)=>i(e,{offer:a},3,l)),1,null)],1,null)],1,null),1,"IA_2")},Lx=b(g(kx,"s_rLVOk7WyC5I")),Cx=t=>{const e=C("duties");return n("div",null,{class:"flex w-[60%] min-w-[310px] max-w-[550px] flex-col items-center rounded-[50px] bg-white p-8 text-primary-blue"},[n("div",null,{class:"mb-2 flex items-center gap-1"},[i(Rn,{class:"text-secondary-red",[s]:{class:s}},3,"H3_0"),n("span",null,{class:"text-[14px] opacity-60"},u(a=>a.data.Location,[t],'p0.data["Location"]'),3,null)],1,null),n("h4",null,{class:"mb-4 text-center text-[20px] font-[600] leading-7 text-primary-dark-blue"},u(a=>a.data.Name,[t],'p0.data["Name"]'),3,null),n("div",null,{class:"relative my-4 flex w-[300px] justify-between gap-2 overflow-hidden rounded-[30px] border border-primary-blue border-opacity-60 px-6 py-2"},[n("div",{class:`absolute bottom-0 transition-all ${e.value==="duties"?"left-0 right-[55%]":"left-[45%] right-0"} top-0 z-[1] rounded-[30px] bg-primary-blue shadow-sm`},null,null,3,null),n("div",null,{class:"z-[2] flex w-[45%] cursor-pointer items-center gap-1 px-2",onClick$:B("s_m2mi5sfy3GQ",[e])},[n("div",null,{class:"flex h-6 w-6 items-center justify-center rounded-full bg-white p-1"},i(rf,{class:"text-secondary-red",[s]:{class:s}},3,"H3_1"),1,null),n("span",null,{class:u(a=>`font-[400] text-${a.value==="duties"?"white":"primary-blue"}`,[e],'`font-[400] text-${p0.value==="duties"?"white":"primary-blue"}`')},"Duties",3,null)],1,null),n("div",null,{class:"z-[2] flex w-[55%] cursor-pointer items-center gap-1 px-2",onClick$:B("s_ynhdzdQwHCA",[e])},[n("div",null,{class:"flex h-6 w-6 items-center justify-center rounded-full bg-white p-1"},i(of,{class:"text-secondary-red",[s]:{class:s}},3,"H3_2"),1,null),n("span",null,{class:u(a=>`font-[400] text-${a.value==="qualifications"?"white":"primary-blue"}`,[e],'`font-[400] text-${p0.value==="qualifications"?"white":"primary-blue"}`')},"Qualifications",3,null)],1,null)],1,null),n("div",null,{class:"relative flex h-[200px] w-full overflow-x-hidden text-[13px] leading-4 transition-all "},[n("div",null,{class:u(a=>`absolute h-[200px] w-full p-4 transition-all ${a.value!=="duties"?"right-full":" right-0"}`,[e],'`absolute h-[200px] w-full p-4 transition-all ${p0.value!=="duties"?"right-full":" right-0"}`')},i(M,{get text(){return t.data.Duties},[s]:{text:u(a=>a.data.Duties,[t],'p0.data["Duties"]')}},3,"H3_3"),1,null),n("div",null,{class:u(a=>`absolute h-[200px] w-full p-4 transition-all ${a.value!=="qualifications"?"left-full":"left-0"}`,[e],'`absolute h-[200px] w-full p-4 transition-all ${p0.value!=="qualifications"?"left-full":"left-0"}`')},i(M,{get text(){return t.data.Qualifications},[s]:{text:u(a=>a.data.Qualifications,[t],'p0.data["Qualifications"]')}},3,"H3_4"),1,null)],1,null)],1,"H3_5")},Mx=b(g(Cx,"s_kNPEZsb0EOk")),jx=t=>{var f;z();const a=(f=rt().prevUrl)==null?void 0:f.pathname.includes("/es/"),l=C("NONE"),r=C(!1),o=C(!1),c=C(!1),p=C(!1),d=wt(B("s_hP0gadtF5EA",[p,r,l,c,o,t]));return n("div",null,{class:"flex flex-col w-full md:w-1/2 h-[560px] bg-blue-100 rounded-2xl p-4"},[n("p",null,{class:"text-center font-medium text-color-Primary"},"Fill out the form below and attach your resume to contact us today",3,null),n("form",null,{id:"form_careers",class:"mt-2 overflow-y-auto",onSubmit$:B("s_i05DmpZA0BU",[d])},[n("div",null,{class:"flex-col sm:flex-row flex justify-between"},[n("div",null,{class:"mb-4 gap-2 w-full flex flex-col mr-0 md:mr-4"},[n("label",null,{for:"from_name",class:"block font-medium text-color-Primary"},"Name",3,null),n("input",null,{type:"text",id:"from_name",name:"from_name",class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500"},null,3,null)],3,null),n("div",null,{class:"mb-4 gap-2 w-full flex flex-col"},[n("label",null,{for:"tel",class:"block font-medium text-color-Primary"},"Phone",3,null),n("input",null,{type:"tel",id:"tel",name:"tel",maxLength:14,class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500"},null,3,null),n("label",null,{class:u((x,m)=>`text-xs text-red-600 ${x.value==!1&&m.value==!0?"flex":"hidden"} bg-transparent`,[r,o],'`text-xs text-red-600 ${p0.value==false&&p1.value==true?"flex":"hidden"} bg-transparent`')},"phone number is invalid",3,null)],3,null)],3,null),n("div",null,{class:"mb-4 gap-2 flex flex-col"},[n("label",null,{for:"from_email",class:"block font-medium text-color-Primary"},"Email",3,null),n("input",null,{type:"email",id:"from_email",name:"from_email",class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",required:!0},null,3,null),n("label",null,{class:u((x,m)=>`text-xs text-red-600 ${x.value==!1&&m.value==!0?"flex":"hidden"} bg-transparent`,[p,c],'`text-xs text-red-600 ${p0.value==false&&p1.value==true?"flex":"hidden"} bg-transparent`')},"email is invalid",3,null)],3,null),n("div",null,{class:"mb-4 gap-2 flex flex-col"},[n("label",null,{for:"message",class:"block  font-medium text-color-Primary"},"Message",3,null),n("textarea",null,{id:"message",name:"message",rows:4,class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",required:!0},null,3,null)],3,null),n("label",null,{for:"resume",class:"flex w-[200px] text-color-Primary p-2 justify-evenly rounded-md font-medium"},["Upload resume",i(Df,{class:"text-center font-bold",[s]:{class:s}},3,"ty_0")],1,null),n("input",null,{type:"file",required:!0,accept:".pdf",id:"resume",name:"resume",class:"w-full"},null,3,null),n("button",{class:`flex flex-row items-center justify-center mt-4 bg-secondary-red text-white w-full font-semibold px-4 py-2 rounded-xl hover:bg-blue-600 focus:outline-none ${l.value==="LOADING"?"cursor-wait bg-primary-blue":l.value==="SUCCESS"?"bg-teal-500":""} focus:outline-none`},{type:"submit",disabled:u(x=>x.value==="LOADING"||x.value==="SUCCESS",[l],'p0.value==="LOADING"||p0.value==="SUCCESS"')},l.value==="NONE"?a?"Enviar":"Send":l.value==="LOADING"?i(At,{size:"28px",[s]:{size:s}},3,"ty_1"):l.value==="ERROR"?"Error":a?"¡Mensaje enviado!":"Email Sent!",1,null)],1,null)],1,"ty_2")},Ax=b(g(jx,"s_34gK8gnZN08")),Ex=({positionName:t})=>{const[e,a]=U();a.value=t,e.value=!0},Nx=t=>{const[e,a,l]=U();return n("div",null,{class:"flex h-[380px] w-[460px] flex-col justify-between rounded-[30px] bg-white p-6 text-center shadow-lg max-[800px]:h-[280px] "},[n("div",null,{class:"flex-col items-center"},[n("div",null,{class:"flex items-center justify-center gap-2"},[i(Rn,null,3,"At_0"),n("span",null,{class:"font-[500] opacity-60"},u(r=>r.position.Location,[t],'p0.position["Location"]'),3,null)],1,null),n("h4",null,{class:"mt-2 text-[19px] font-[700] text-primary-dark-blue"},u(r=>r.position.Name,[t],'p0.position["Name"]'),3,null),i(M,{classN:"text-[15px] max-[800px]:text-[13px]",get text(){return t.position.Summary},[s]:{classN:s,text:u(r=>r.position.Summary,[t],'p0.position["Summary"]')}},3,"At_1")],1,null),n("div",null,{class:"flex flex-col items-center gap-2"},[n("div",null,{class:"flex gap-1 text-[15px]"},[n("span",null,{class:"text-btn-green hover:cursor-pointer",onClick$:B("s_d5LXfHtAyog",[a,t,l])},"Learn more",3,null)," ",n("span",null,{class:"text-black"},"or",3,null)],3,null),n("button",null,{class:"flex w-fit items-center justify-center rounded-full border-2 border-teal-500 border-opacity-70 bg-white p-0.5 px-1 text-btn-green opacity-90 shadow-md delay-150 ease-in-out hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:B("s_O0F0Jjn1jLU",[e,t])}," Submit Resume ",3,null)],3,null)],1,"At_2")},Ix=t=>{var m;const e=C(!1),a=C(!1),l=C(t.data.Positions[0].attributes),r=C(""),o=t.data.FormInfo.split("="),p=(m=rt().prevUrl)==null?void 0:m.pathname.includes("/es/"),f=b(g(Nx,"s_MLxpYci0h0Y",[g(Ex,"s_DxkiX1SABig",[e,r]),a,l])),x=t.data.Positions.map(($,y)=>i(f,{get position(){return $.attributes},[s]:{position:h($,"attributes")}},3,y));return n("div",null,{class:"my-8 flex justify-center text-primary-blue"},[i(Zl,{showSignal:e,children:i(Ax,{templateID:o[2],mailto:o[3],subject:o[4],lang:p?"es":"en",get position(){return r.value},[s]:{position:u($=>$.value,[r],"p0.value")}},3,"At_3"),[s]:{showSignal:s}},1,"At_4"),i(Zl,{showSignal:a,children:i(Mx,{get data(){return l.value},[s]:{data:u($=>$.value,[l],"p0.value")}},3,"At_5"),[s]:{showSignal:s}},1,"At_6"),n("div",null,{class:"flex flex-col "},[n("h3",null,{class:"text-center text-[44px] font-[600]"},u($=>$.data.PositionsTitle,[t],'p0.data["PositionsTitle"]'),3,null),n("div",null,{class:"flex-column flex w-[1200px] "},i(Et,{slides:x,id:"carPositions",hasArrows:!0,[s]:{id:s,hasArrows:s}},3,"At_7"),1,null)],1,null)],1,"At_8")},Bx=b(g(Ix,"s_Su5lXmtHgW0")),Ox=t=>{const e=t.data.pageCareers.data.attributes;return n("div",null,{onClick$:B("s_yJsNttxIAPY")},[i(Dx,{data:{HeaderLogo:t.data.pageCareers.data.attributes.HeaderLogo,HeaderTitle:t.data.pageCareers.data.attributes.HeaderTitle,HeaderPictures:t.data.pageCareers.data.attributes.HeaderPictures}},3,"a0_0"),i(Lx,{data:{Beliefs:t.data.pageCareers.data.attributes.Beliefs,BeliefsDescription:t.data.pageCareers.data.attributes.BeliefsDescription,BeliefsSubtitle:t.data.pageCareers.data.attributes.BeliefsSubtitle,BeliefsTitle:t.data.pageCareers.data.attributes.BeliefsTitle,Offerings:t.data.pageCareers.data.attributes.Offerings,OfferingTitle:t.data.pageCareers.data.attributes.OfferingTitle}},3,"a0_1"),n("div",null,{class:"flex w-full justify-center px-8"},n("div",null,{class:"max-w-[1200px] text-center text-primary-blue"},[n("h3",null,{class:"mb-4 mt-16 text-[38px] font-[800]"},S(e.FormParagraph,"Title"),1,null),i(M,{get text(){return e.FormParagraph.Paragraph},classN:"text-[18px] font-[400]",[s]:{text:h(e.FormParagraph,"Paragraph"),classN:s}},3,"a0_2")],1,null),1,null),i(Bx,{data:{Positions:e.Positions.data,PositionsTitle:e.PositionsTitle,FormInfo:e.FormParagraph.Buttons[0].Link}},3,"a0_3")],1,"a0_4")},qx=b(g(Ox,"s_CHSZKaaPR2c")),Rx=t=>`query QueryCareers {
    pageCareers(locale:"${t}"){    
      data{
        attributes{
                  HeaderLogo{
                    ${_}
                  }
          HeaderPictures{
            ${_}
          }
          HeaderBackground{
           ${_}
          }
          HeaderTitle{
            Text
          }
          
          
          BeliefsTitle
          BeliefsSubtitle
          Beliefs{
            Text
          }
          BeliefsDescription
          
          
          OfferingTitle
          Offerings{
            Title
            Paragraph
            Media{
              ${_}
            }
          }
          
          PositionsTitle
          Positions(sort: "Name:Asc"){
            data{
              attributes{
                Location
                Name
                Summary
                Duties
                Qualifications
              }
            }
          }
          
          FormParagraph{
            Title
            Paragraph
            Buttons{
            Link
            }
          }
          FormCareers{
            Title
            Fields{
              Label
              Icon{
                ${_}
              }
            }
            ActionButton{
              Text
              Link
            }
          }
        ${H}
        }
      }
    }
  }`,zx=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Rx,e)},as=R(g(zx,"s_bBcTtiHl1Tw")),Fx=()=>{const t=as();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageCareers.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageCareers.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageCareers"]["data"]["attributes"]["SEO"]')}},3,"sa_0"),i(qx,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"sa_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"sa_2")},Qx=b(g(Fx,"s_KylSGhTDLNs")),Gx=({resolveValue:t})=>{const a=t(as).pageData.data.pageCareers.data.attributes.SEO;return V(a)},Hx=Object.freeze(Object.defineProperty({__proto__:null,default:Qx,head:Gx,usePageData:as},Symbol.toStringTag,{value:"Module"})),Vx=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(M,{get text(){return t.data.TextContent},classN:"markdownTitle markdownh3 markdownHyper text-justify flex text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"27_0")],1,"27_1"),Wx=b(g(Vx,"s_qLAYw5vO9og")),Ux=t=>`query QuerySupplement {
        pageSuppleTerms(locale:"${t}"){    
          ${aa}
          ${H}
            }
          }
        }
      }`,Yx=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Ux,e)},ls=R(g(Yx,"s_LHhYaz4wQcQ")),Zx=()=>{const t=ls(),e=t.value.pageData.data.pageSuppleTerms.data.attributes.Content;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(Wx,{data:e},3,"NP_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"NP_1")},1,"NP_2")},Kx=b(g(Zx,"s_2WfoIGYZZ0E")),Jx=({resolveValue:t})=>{const a=t(ls).pageData.data.pageSuppleTerms.data.attributes.SEO;return V(a)},Xx=Object.freeze(Object.defineProperty({__proto__:null,default:Kx,head:Jx,usePageData:ls},Symbol.toStringTag,{value:"Module"})),tm=t=>n("div",null,{class:"flex flex-col py-10 items-center justify-center"},[n("h1",null,{class:"text-2xl sm:text-4xl font-bold text-primary-blue"},u(e=>e.data.Introduction.Title,[t],'p0.data["Introduction"]["Title"]'),3,null),n("p",null,{class:"text-primary-blue text-center text-[16px] md:text-[18px] m-5"},u(e=>e.data.Introduction.Paragraph,[t],'p0.data["Introduction"]["Paragraph"]'),3,null),i(tt,{get text(){return t.data.Introduction.Buttons[0].Text},get link(){return t.data.Introduction.Buttons[0].Link},[s]:{text:u(e=>e.data.Introduction.Buttons[0].Text,[t],'p0.data["Introduction"]["Buttons"][0]["Text"]'),link:u(e=>e.data.Introduction.Buttons[0].Link,[t],'p0.data["Introduction"]["Buttons"][0]["Link"]')}},3,"wL_0"),n("div",null,{class:"flex flex-col items-center gap-2 px-4 py-4 my-10"},[n("h2",null,{class:"text-xl sm:text-2xl font-bold text-primary-blue"},u(e=>e.data.SocialMedia.Text,[t],'p0.data["SocialMedia"]["Text"]'),3,null),n("div",null,{class:"flex flex-row gap-4"},t.data.SocialMedia.SubOption.map((e,a)=>z(i(Rt,{get href(){return e.Link},children:[e.Link.includes("facebook")&&n("div",null,{class:"flex w-[50px] h-[50px] items-center justify-center rounded-full bg-primary-blue p-4"},i(A,{get media(){return e.Icon.data.attributes},toWhite:!0,[s]:{media:h(e.Icon.data,"attributes"),toWhite:s}},3,"wL_1"),1,"wL_2"),!e.Link.includes("facebook")&&n("div",null,{class:"flex w-[50px] h-[50px] items-center justify-center rounded-full bg-primary-blue p-3"},i(A,{get media(){return e.Icon.data.attributes},toWhite:!0,[s]:{media:h(e.Icon.data,"attributes"),toWhite:s}},3,"wL_3"),1,"wL_4")],[s]:{href:h(e,"Link")}},1,a))),1,null)],1,null),n("div",null,{class:"flex flex-col items-center justify-center"},[n("h3",null,{class:"text-xl sm:text-2xl font-bold text-primary-blue"},u(e=>e.data.OfficesTitle,[t],'p0.data["OfficesTitle"]'),3,null),n("div",null,{class:"flex flex-wrap gap-8 mt-5 justify-center items-start"},t.data.OfficesLocation.map((e,a)=>n("div",null,{class:"flex flex-col w-[200px]"},[n("a",{href:S(e.Buttons[0],"Link")},{class:"font-bold text-secondary-red"},S(e.Buttons[0],"Text"),1,null),n("a",{href:S(e.Buttons[1],"Link")},{class:"font-bold text-primary-blue"},S(e.Buttons[1],"Text"),1,null),n("p",null,{class:"tracking-wide font-normal text-sm text-primary-blue"},S(e,"Paragraph"),1,null)],1,a)),1,null)],1,null)],1,"wL_5"),em=b(g(tm,"s_5L0HuXf9QnQ")),am=t=>`query QueryContactUs{
        pageContact(locale:"${t}"){
          data{
            attributes{
              Introduction{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              SocialMedia{
                Text
                SubOption{
                  Text
                  Link
                  Icon{
                    ${_}
                  }
                }
              }
              
              OfficesTitle
              OfficesLocation{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              ${H}
            }
          }
        }
      }`,lm=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(am,e)},ns=R(g(lm,"s_QdheZerij2w")),nm=()=>{const t=ns(),e=t.value.pageData.data.pageContact.data.attributes;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(em,{data:e},3,"yX_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"yX_1")},1,"yX_2")},sm=b(g(nm,"s_FZeWA02p0TI")),rm=({resolveValue:t})=>{const a=t(ns).pageData.data.pageContact.data.attributes.SEO;return V(a)},im=Object.freeze(Object.defineProperty({__proto__:null,default:sm,head:rm,usePageData:ns},Symbol.toStringTag,{value:"Module"})),om=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(M,{get text(){return t.data.TextContent},classN:"markdownTitle markdownHyper text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"NS_0")],1,"NS_1"),um=b(g(om,"s_gvsFRD0Vfkk")),cm=t=>`
query QueryCookies {
  pageCookies(locale:"${t}"){    
    ${aa}
    ${H}
      }
    }
  }
}`,dm=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(cm,e)},ss=R(g(dm,"s_IqhWiqyXb00")),pm=()=>{const t=ss(),e=t.value.pageData.data.pageCookies.data.attributes.Content;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(um,{data:e},3,"wB_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"wB_1")},1,"wB_2")},fm=b(g(pm,"s_OmN9OIo5qbs")),gm=({resolveValue:t})=>{const a=t(ss).pageData.data.pageCookies.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},xm=Object.freeze(Object.defineProperty({__proto__:null,default:fm,head:gm,usePageData:ss},Symbol.toStringTag,{value:"Module"})),mm=t=>n("div",null,{class:u(e=>`${e.data.isVisible?"":"hidden"} flex w-full flex-col items-center justify-center text-primary-blue`,[t],'`${p0.data["isVisible"]?"":"hidden"} flex w-full flex-col items-center justify-center text-primary-blue`')},n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center px-10 min-[800px]:w-[70%]"},[n("span",null,{class:"text-center text-[38px] font-[800] text-secondary-red max-[800px]:text-[30px]"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),i(M,{classN:"mb-3 w-full bg-primary-blue p-2 font-[600] text-[26px] max-[800px]:text-[20px] text-white text-center mx-4 rounded-full",get text(){return t.data.Description},[s]:{classN:s,text:u(e=>e.data.Description,[t],'p0.data["Description"]')}},3,"Sf_0"),i(M,{classN:"text-center text-[26px]",get text(){return t.data.Deal},[s]:{classN:s,text:u(e=>e.data.Deal,[t],'p0.data["Deal"]')}},3,"Sf_1"),i(M,{classN:"text-center text-[18px] mb-3",get text(){return t.data.Deals_description},[s]:{classN:s,text:u(e=>e.data.Deals_description,[t],'p0.data["Deals_description"]')}},3,"Sf_2"),n("div",null,{class:"mb-3 flex items-start justify-evenly gap-4 max-[600px]:flex-col"},t.data.Services.map((e,a)=>n("div",null,{class:"flex items-center justify-center gap-1"},[i(ja,{get media(){return e.Icon.data.attributes},clasN:"w-[100px] max-[1000px]:w-[80px] ",muted:!0,[s]:{media:h(e.Icon.data,"attributes"),clasN:s,muted:s}},3,"Sf_3"),n("span",null,{class:"font-[600]"},S(e,"Title"),1,null)],1,a)),1,null),i(tt,{get text(){return t.data.Button.Text},get link(){return t.data.Button.Link},[s]:{text:u(e=>e.data.Button.Text,[t],'p0.data["Button"]["Text"]'),link:u(e=>e.data.Button.Link,[t],'p0.data["Button"]["Link"]')}},3,"Sf_4")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 max-[600px]:hidden min-[800px]:w-[30%]"},i(ja,{get media(){return t.data.Media.data.attributes},clasN:"rounded-full  mr-[30px]",autoplay:!0,loop:!0,muted:!0,[s]:{media:u(e=>e.data.Media.data.attributes,[t],'p0.data["Media"]["data"]["attributes"]'),clasN:s,autoplay:s,loop:s,muted:s}},3,"Sf_5"),1,null)],1,null),1,"Sf_6"),hm=b(g(mm,"s_4av0zjglZmk")),bm=t=>n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"min-h-[200px] w-full bg-gradient-to-br from-primary-light-blue to-[#23477f] !text-white"},i(Ve,{get data(){return t.data},color:"white",backgroundColor:"primary-blue",[s]:{data:u(e=>e.data,[t],"p0.data"),color:s,backgroundColor:s}},3,"tV_0"),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"tV_1"),$m=b(g(bm,"s_cJop3g0b1vg")),vm=t=>n("div",null,{class:"flex w-full items-center justify-center"},n("div",null,{class:"flex max-w-[1200px] flex-wrap items-start justify-evenly gap-6 p-8"},t.data.map((e,a)=>n("div",null,{class:"flex w-[280px] flex-col items-center gap-2"},[i(ha,{get media(){return e.Media.data.attributes},color:a%2===0?"bg-[#2E5899]":"bg-secondary-red",width:"300px",height:"300px",[s]:{media:h(e.Media.data,"attributes"),width:s,height:s}},3,"lG_0"),i(M,{get text(){return e.Title},classN:"font-[600] text-center text-[18px] tracking-[-1px]",[s]:{text:h(e,"Title"),classN:s}},3,"lG_1"),i(M,{get text(){return e.Paragraph},classN:"text-center text-[16px]",[s]:{text:h(e,"Paragraph"),classN:s}},3,"lG_2")],1,a)),1,null),1,"lG_3"),ym=b(g(vm,"s_gpmIUuGz0sE")),_m=t=>{const e=t.data.pageDeals.data.attributes.Deals,a=t.data.pageDeals.data.attributes.RefInfo,l=t.data.pageDeals.data.attributes.Discounts,r=t.data.pageDeals.data.attributes.Disclaimer;return n("div",null,null,[i(hm,{data:e},3,"e6_0"),i($m,{data:a},3,"e6_1"),i(ym,{data:l},3,"e6_2"),n("div",null,{class:"flex w-full items-center  justify-center p-8 text-center text-[14px] italic text-primary-dark-blue"},r,1,null)],1,"e6_3")},wm=b(g(_m,"s_xtY1ub2ohjs")),Sm=t=>`
  query QueryDeals{
    pageDeals(locale:"${t}"){
      data{
        attributes{
          Deals {
            isVisible
            Title
            Description
            Deal
            Deals_description
            Media {
              ${_}
            }
            Services {
              Title
              Icon {
                ${_}
              }
            }
            Button {
              Text
              Link
            }
          }
  
          RefInfo{
            Title
            Paragraph
            Media{
              ${_}
            }
            Buttons{
              Text
              Link
            }
          }
          RefBackground{
            ${_}
          }
          
          Discounts{
            Title
            Paragraph
            Media{
             ${_}
            }
          }
          Disclaimer
          
          ${H}
        }
      }
    }
  }
    `,Tm=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Sm,e)},rs=R(g(Tm,"s_2jiG1A0ymzM")),Dm=()=>{const t=rs();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageDeals.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageDeals.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageDeals"]["data"]["attributes"]["SEO"]')}},3,"B3_0"),i(wm,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"B3_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"B3_2")},Pm=b(g(Dm,"s_OVAjdqBqgec")),km=({resolveValue:t})=>{const a=t(rs).pageData.data.pageDeals.data.attributes.SEO;return V(a)},Lm=Object.freeze(Object.defineProperty({__proto__:null,default:Pm,head:km,usePageData:rs},Symbol.toStringTag,{value:"Module"})),Cm=t=>n("div",null,{class:"my-8 flex flex-col items-center"},[n("h1",null,{class:"text-center text-xl font-semibold text-primary-blue"},u(e=>e.data.Introduction.Titles[0].Text,[t],'p0.data["Introduction"]["Titles"][0]["Text"]'),3,null),n("h2",null,{class:"text-center text-primary-blue"},u(e=>e.data.Introduction.TextContent,[t],'p0.data["Introduction"]["TextContent"]'),3,null),n("div",null,{class:"px-4 md:px-10 bg-white flex flex-col items-center justify-center rounded-[30px] m-8 max-w-[1000px]"},i(Un,{get faqs(){return t.data.FAQList},[s]:{faqs:u(e=>e.data.FAQList,[t],'p0.data["FAQList"]')}},3,"NP_0"),1,null)],1,"NP_1"),Mm=b(g(Cm,"s_x7ihZ2PZWys")),jm=t=>`query QueryFAQ {
        pageFaq(locale:"${t}") {
          data{
            attributes{    
              Introduction{
                Titles{
                  Text
                }
                TextContent
              }
      
              FAQList{
                Title
                Paragraph
                Disclaimer{
                Icon{
                    ${_}
                }
                Title
                Text
                Caption
                }

                Table(pagination: { limit: 50 }){
                ColumnOne
                ColumnTwo
                ColumnThree
                }
              }
              
              ${H}
            }
          }
        }
      }`,Am=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(jm,e)},is=R(g(Am,"s_SBnhqZ85K9A")),Em=()=>{const t=is(),e=t.value.pageData.data.pageFaq.data.attributes;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(Mm,{data:e},3,"k1_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"k1_1")},1,"k1_2")},Nm=b(g(Em,"s_jDEouB0mRKg")),Im=({resolveValue:t})=>{const a=t(is).pageData.data.pageFaq.data.attributes.SEO;return V(a)},Bm=Object.freeze(Object.defineProperty({__proto__:null,default:Nm,head:Im,usePageData:is},Symbol.toStringTag,{value:"Module"})),Om=t=>(z(),n("div",null,{class:"flex md:flex-row flex-col-reverse w-full text-center items-center justify-center md:p-8 md:my-10"},[n("div",null,{class:"relative"},[n("div",null,{class:"flex w-[20vw] h-[20vw] min-w-[300px] min-h-[300px] items-center justify-center"},n("div",null,{class:"bg-[#2E5899] md:h-full h-[285px] md:w-full w-[285px] bg-opacity-40 p-6 inline-block items-center justify-center rounded-full"},n("div",null,{class:"bg-[#2E5899] flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md"},n("div",null,{class:"bg-[#2E5899] flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md"},n("div",null,{class:"flex flex-col items-center gap-5"},null,3,null),3,null),3,null),3,null),3,null),n("div",null,{class:"flex gap-3 flex-col absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full items-center justify-center"},[i(M,{get text(){return t.parData.Paragraph},classN:"text-white text-[18px] leading-none md:text-[1.75vw]",[s]:{text:u(e=>e.parData.Paragraph,[t],'p0.parData["Paragraph"]'),classN:s}},3,"nC_0"),t.parData.Buttons&&t.parData.Buttons.map((e,a)=>n("div",null,{class:"z-50"},i(tt,{get text(){return e.Text},get link(){return e.Link},[s]:{text:h(e,"Text"),link:h(e,"Link")}},3,"nC_1"),1,a))],1,null)],1,null),n("div",null,{class:"flex flex-col gap-5 md:px-[30px] px-[12vw] py-5"},[n("div",null,{class:"flex flex-col justify-center items-center"},[i(M,{get text(){return t.parData.Title},classN:"[&>h1]:text-[28px]",[s]:{text:u(e=>e.parData.Title,[t],'p0.parData["Title"]'),classN:s}},3,"nC_2"),i(A,{get media(){return t.parData.Logo.data.attributes},width:"400px",height:"100px",[s]:{media:u(e=>e.parData.Logo.data.attributes,[t],'p0.parData["Logo"]["data"]["attributes"]'),width:s,height:s}},3,"nC_3")],1,null),t.parData.Subtitle&&i(M,{get text(){return t.parData.Subtitle},classN:"[&>h2]:text-[18px]",[s]:{text:u(e=>e.parData.Subtitle,[t],'p0.parData["Subtitle"]'),classN:s}},3,"nC_4")],1,null),n("div",null,{class:"w-[20vw] h-[20vw] min-w-[300px] min-h-[300px] max-[930px]:hidden flex"},i(ha,{get media(){return t.parData.Media.data.attributes},[s]:{media:u(e=>e.parData.Media.data.attributes,[t],'p0.parData["Media"]["data"]["attributes"]')}},3,"nC_5"),1,null)],1,"nC_6")),os=b(g(Om,"s_BQqIfxz8NXA")),qm=t=>(z(),n("div",null,{class:" flex md:flex-row flex-col-reverse w-full text-center items-center justify-center p-8 bg-gradient-to-r from-blue-600 to-[#2e5899]"},n("div",null,{class:"max-w-[1300px] w-full flex flex-col"},[n("div",null,{class:"flex md:flex-row flex-col"},t.speedList&&t.speedList.map((e,a)=>z(n("div",null,{class:"bg-white/80 grow m-2 rounded-2xl drop-shadow-2xl p-5 flex flex-row items-center justify-center gap-5"},[t.addIcons&&i(Ul,{class:"text-[#d20030]",[s]:{class:s}},3,"uc_0"),n("div",null,null,[n("h3",null,{class:"text-[#d20030] md:text-[28px] text-[22px] font-bold"},S(e,"Title"),1,null),i(M,{get text(){return e.Text},classN:"md:text-[25px] text-[18px]",[s]:{text:h(e,"Text"),classN:s}},3,"uc_1")],1,null),t.addIcons&&i(Ul,{class:"text-[#d20030]",[s]:{class:s}},3,"uc_2"),"                        "],1,a))),1,null),t.parData&&i(Lt,{color:"white",get title(){return t.parData.Title},get text(){return t.parData.Paragraph},get buttons(){return t.parData.Buttons},backgroundColor:"transparent",[s]:{color:s,title:u(e=>e.parData.Title,[t],'p0.parData["Title"]'),text:u(e=>e.parData.Paragraph,[t],'p0.parData["Paragraph"]'),buttons:u(e=>e.parData.Buttons,[t],'p0.parData["Buttons"]'),backgroundColor:s}},3,"uc_3")],1,null),1,"uc_4")),Cl=b(g(qm,"s_Fo7QUM6aBA8")),Rm=t=>n("div",null,{class:"flex md:flex-row flex-col-reverse w-full text-center items-center justify-center md:py-8 py-2"},i(Lt,{hasPricing:!1,reverse:!0,get text(){return t.parData.Paragraph},backgroundColor:"transparent",get title(){return t.parData.Title},get subtitle(){return t.parData.Subtitle},get image(){return t.parData.Media.data.attributes},get buttons(){return t.parData.Buttons},[s]:{hasPricing:s,reverse:s,text:u(e=>e.parData.Paragraph,[t],'p0.parData["Paragraph"]'),backgroundColor:s,title:u(e=>e.parData.Title,[t],'p0.parData["Title"]'),subtitle:u(e=>e.parData.Subtitle,[t],'p0.parData["Subtitle"]'),image:u(e=>e.parData.Media.data.attributes,[t],'p0.parData["Media"]["data"]["attributes"]'),buttons:u(e=>e.parData.Buttons,[t],'p0.parData["Buttons"]')}},3,"CM_0"),1,"CM_1"),us=b(g(Rm,"s_sknthmsoXlM")),zm=t=>{const e=t.data.Logo.data.attributes;return n("div",null,{class:"min-h-screen w-full flex flex-col items-center"},[i(A,{width:"200px",media:e,clasN:"p-5",[s]:{width:s,clasN:s}},3,"of_0"),i(os,{get parData(){return t.data.SectionHead},[s]:{parData:u(a=>a.data.SectionHead,[t],'p0.data["SectionHead"]')}},3,"of_1"),i(Cl,{get parData(){return t.data.SectionSpeed},get speedList(){return t.data.SpeedBullets},[s]:{parData:u(a=>a.data.SectionSpeed,[t],'p0.data["SectionSpeed"]'),speedList:u(a=>a.data.SpeedBullets,[t],'p0.data["SpeedBullets"]')}},3,"of_2"),i(us,{get parData(){return t.data.SectionRating},[s]:{parData:u(a=>a.data.SectionRating,[t],'p0.data["SectionRating"]')}},3,"of_3"),n("div",null,{class:"w-full bg-white  flex md:flex-row flex-col items-center justify-between"},[n("div",null,{class:" flex flex-row gap-5 p-1"},t.data.Footer&&t.data.Footer.map((a,l)=>i(Rt,{get href(){return a.Link},class:" hover:text-primary-blue/60 text-primary-blue font-bold",children:S(a,"Text"),[s]:{href:h(a,"Link"),class:s}},1,l)),1,null),n("div",null,{class:"text-primary-blue text-center"},"© 2024 Rural Telecommunications of America, Inc. All rights reserved.",3,null)],1,null)],1,"of_4")},Fm=b(g(zm,"s_GHcg0KcOc4I")),Qm=t=>`query QueryLPNeighbor {
        lpNeighbor (locale:"${t}"){    
          data{
            attributes{
              Logo{
                ${_}
              }

              SectionHead{
                Title
                Subtitle
                Paragraph
                Logo{
                    ${_}
                }
                Media{
                    ${_}
                }
                Buttons{
                  Text
                  Link
                }
              }

              SpeedBullets{
                Title
                Text
              }

              SectionSpeed{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }

              SectionRating{
                Title
                Subtitle
                Paragraph
                Buttons{
                  Text
                  Link
                }
                Media{
                    ${_}
                }
              }
              
              Footer{
                Text
                Link
              }
            ${H}
            }
          }
        }
        
      }`,Gm=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Qm,e)},cs=R(g(Gm,"s_yFRGQ10fxJ8")),Hm=()=>{const t=cs();return i(G,{children:i(F,{get data(){return t.value.layoutData},showMenus:!1,showHeader:!1,children:i(Fm,{get data(){return t.value.pageData.data.lpNeighbor.data.attributes},[s]:{data:u(e=>e.value.pageData.data.lpNeighbor.data.attributes,[t],'p0.value["pageData"]["data"]["lpNeighbor"]["data"]["attributes"]')}},3,"kh_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showMenus:s,showHeader:s}},1,"kh_1")},1,"kh_2")},Vm=b(g(Hm,"s_goRTr5J9aTM")),Wm=({resolveValue:t})=>{const a=t(cs).pageData.data.lpNeighbor.data.attributes.SEO;return V(a)},Um=Object.freeze(Object.defineProperty({__proto__:null,default:Vm,head:Wm,usePageData:cs},Symbol.toStringTag,{value:"Module"})),Ym=t=>n("div",null,{class:"relative z-0 h-3/4 w-[250px] text-center items-center justify-center }"},[i(A,{clasN:"object-fill h-full w-full",get media(){return t.update.Picture.data.attributes},height:500,width:250,[s]:{clasN:s,media:u(e=>e.update.Picture.data.attributes,[t],'p0.update["Picture"]["data"]["attributes"]'),height:s,width:s}},3,"2q_0"),n("a",null,{href:u(e=>e.update.Link,[t],'p0.update["Link"]')},n("div",null,{class:"absolute flex items-center justify-center flex-col inset-0 w-full h-full bg-black bg-opacity-30 text-white"},[n("h2",null,{class:"text-2xl font-semibold"},u(e=>e.update.Title,[t],'p0.update["Title"]'),3,null),n("p",null,{class:"text-xl"},u(e=>e.update.Subtitle,[t],'p0.update["Subtitle"]'),3,null)],3,null),3,null)],1,"2q_1"),Zm=t=>{const e=b(g(Ym,"s_SjfOqPww0ks")),a=t.carouselData.map((l,r)=>i(e,{update:l},3,r));return n("div",null,{class:"flex w-full items-center justify-center"},n("div",null,{class:"flex flex-row max-w-[1200px] items-center justify-center max-[800px]:flex-col h-full"},[n("h2",null,{class:"text-center p-5 text-4xl font-bold text-primary-blue max-[800px]:w-[40%]"},u(l=>l.title,[t],"p0.title"),3,null),n("div",null,{class:"h-fit w-[60%] flex items-center justify-center "},i(Et,{slides:a,fillSlide:!0,addSpace:!1,id:"updatesSlider",hasPagination:!1,[s]:{fillSlide:s,addSpace:s,id:s,hasPagination:s}},3,"2q_2"),1,null)],1,null),1,"2q_3")},Km=b(g(Zm,"s_kpGwS0aQJPs")),Jm=t=>n("iframe",null,{src:u(e=>`https://www.youtube.com/embed/${e.ytURL.split("v=")[1]}`,[t],'`https://www.youtube.com/embed/${p0.ytURL.split("v=")[1]}`'),class:u(e=>`h-full w-full ${e.classN}`,[t],"`h-full w-full ${p0.classN}`"),frameBorder:"0",allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",allowFullscreen:!0},null,3,"Fj_0"),ul=b(g(Jm,"s_jekwDGWyuec")),Xm=t=>n("div",null,{class:"flex flex-col lg:flex-row w-full px-10 items-center justify-center my-8"},[n("div",null,{class:"flex flex-col w-full lg:w-1/3 h-full text-center lg:text-end justify-evenly mr-4 my-4"},[n("h2",null,{class:"text-2xl font-semibold text-secondary-red"},u(e=>e.data.FeatInterview.Title,[t],'p0.data["FeatInterview"]["Title"]'),3,null),n("h3",null,{class:"text-2xl font-[350] text-primary-blue"},u(e=>e.data.FeatInterview.Subtitle,[t],'p0.data["FeatInterview"]["Subtitle"]'),3,null),i(M,{classN:"my-8 ml-4",get text(){return t.data.FeatInterview.Paragraph},[s]:{classN:s,text:u(e=>e.data.FeatInterview.Paragraph,[t],'p0.data["FeatInterview"]["Paragraph"]')}},3,"RS_0"),n("div",null,{class:"flex justify-center lg:justify-end"},n("a",null,{class:"text-end",href:u(e=>e.data.FeatInterview.Buttons[0].Link,[t],'p0.data["FeatInterview"]["Buttons"][0]["Link"]')},n("div",null,{class:"flex px-4 w-fit py-2 justify-evenly items-center rounded-2xl border-2 border-primary-blue"},[i(_f,{class:"fill-secondary-red mr-4 h-full",[s]:{class:s}},3,"RS_1"),n("p",null,null,u(e=>e.data.FeatInterview.Buttons[0].Text,[t],'p0.data["FeatInterview"]["Buttons"][0]["Text"]'),3,null)],1,null),1,null),1,null)],1,null),n("div",null,null,i(ul,{get ytURL(){return t.data.FeatVideo},classN:"rounded-2xl w-[460px] md:w-[530px] md:h-[350px] m-8",[s]:{ytURL:u(e=>e.data.FeatVideo,[t],'p0.data["FeatVideo"]'),classN:s}},3,"RS_2"),1,null)],1,"RS_3"),th=b(g(Xm,"s_liBh70ErorA")),eh={url:"/uploads/youtube_67497ef97d.svg",alternativeText:"A vector of Youtube logo",caption:"Youtube logo icon | RTA"},ah=t=>{const e=t.data.map((a,l)=>n("div",null,{class:"relative z-0 w-350 h-150 rounded-2xl"},[i(A,{clasN:"rounded-2xl",get media(){return a.Picture.data.attributes},width:350,height:150,[s]:{clasN:s,media:h(a.Picture.data,"attributes"),width:s,height:s}},3,"zz_0"),n("a",{href:S(a,"Link")},{class:"absolute inset-0 h-full w-full flex items-center justify-center"},i(A,{get media(){return eh},toWhite:!0,height:50,width:50,[s]:{media:s,toWhite:s,height:s,width:s}},3,"zz_1"),1,null)],1,l));return n("div",null,{class:"w-full flex items-center justify-center"},i(Et,{slides:e,id:"InterviewCarousel",duration:5e3,hasPagination:!1,[s]:{id:s,duration:s,hasPagination:s}},3,"zz_2"),1,"zz_3")},lh=b(g(ah,"s_w6lTa7I5NZ4")),nh=t=>n("div",null,null,[i(Ve,{get data(){return t.data.Introduction},hasPricing:!1,alt:!0,reverse:!0,[s]:{data:u(e=>e.data.Introduction,[t],'p0.data["Introduction"]'),hasPricing:s,alt:s,reverse:s}},3,"NM_0"),i(Km,{get title(){return t.data.UpdatesTitle},get carouselData(){return t.data.UpdatesCarousel},[s]:{title:u(e=>e.data.UpdatesTitle,[t],'p0.data["UpdatesTitle"]'),carouselData:u(e=>e.data.UpdatesCarousel,[t],'p0.data["UpdatesCarousel"]')}},3,"NM_1"),i(th,{get data(){return t.data},[s]:{data:u(e=>e.data,[t],"p0.data")}},3,"NM_2"),i(lh,{get data(){return t.data.Interviews},[s]:{data:u(e=>e.data.Interviews,[t],'p0.data["Interviews"]')}},3,"NM_3")],1,"NM_4"),sh=b(g(nh,"s_bPCxBsh3t6w")),rh=t=>`query queryGfsn{
        pageGfSports(locale:"${t}"){
          data{
            attributes{
              
              Introduction{
                Title
                Subtitle
                Paragraph
                Media{
                 ${_}
                }
               
              }
              
              UpdatesTitle
              
              UpdatesCarousel{
                Picture{
                  ${_}
                }
                Link
                Title
                Subtitle
              }
              
              FeatInterview{
                Title
                Subtitle
                Paragraph
                
                Buttons{
                  Text
                  Link
                  Icon{
                    ${_}
                  }
                }
              }
              
              
              FeatVideo
              
              Interviews{
                Picture{
                  ${_}
                }
                Link
                Title
              }
              ${H}
            }
          }
        }
      }`,ih=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(rh,e)},ds=R(g(ih,"s_BZfivgZf0o0")),oh=()=>{const t=ds();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGfSports.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfSports.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfSports"]["data"]["attributes"]["SEO"]')}},3,"7u_0"),i(sh,{get data(){return t.value.pageData.data.pageGfSports.data.attributes},[s]:{data:u(e=>e.value.pageData.data.pageGfSports.data.attributes,[t],'p0.value["pageData"]["data"]["pageGfSports"]["data"]["attributes"]')}},3,"7u_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"7u_2")},1,"7u_3")},uh=b(g(oh,"s_KZzsv9nZPuQ")),ch=({resolveValue:t})=>{const a=t(ds).pageData.data.pageGfSports.data.attributes.SEO;return V(a)},dh=Object.freeze(Object.defineProperty({__proto__:null,default:uh,head:ch,usePageData:ds},Symbol.toStringTag,{value:"Module"})),ph=t=>{const e=t.data.pageGfCloud.data.attributes,a=t.data.sectionNetwork.data.attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(A,{get media(){return e.GNetworkLogo.data.attributes},width:500,height:95,[s]:{media:h(e.GNetworkLogo.data,"attributes"),width:s,height:s}},3,"JJ_0"),n("div",null,{class:"flex flex-wrap-reverse px-8 py-6 items-center justify-center"},[n("div",null,{class:"h-[450px] w-full md:w-1/2"},i(A,{get media(){return a.Map.MapPicture.data.attributes},width:500,height:490,[s]:{media:h(a.Map.MapPicture.data,"attributes"),width:s,height:s}},3,"JJ_1"),1,null),n("div",null,{class:"flex flex-col w-full md:w-1/2 items-center justify-center"},[i(M,{get text(){return a.Description.Paragraph},classN:"text-primary-blue",[s]:{text:h(a.Description,"Paragraph"),classN:s}},3,"JJ_2"),i(Ga,{get title(){return a.Map.ServersTitle},classContainer:"rounded-full bg-white text-primary-blue shadow-xl",children:n("div",null,{class:"flex flex-col py-4 text-primary-blue bg-white rounded-b-2xl"},a.Map.Servers.map((l,r)=>n("a",{href:S(l,"Link")},{class:"hover:text-secondary-red text-primary-blue"},S(l,"Text"),1,r)),1,null),[s]:{title:h(a.Map,"ServersTitle"),classContainer:s}},1,"JJ_3")],1,null)],1,null),i(Lt,{get title(){return e.GFCloud.Title},get text(){return e.GFCloud.Paragraph},get image(){return e.GFCloud.Media.data.attributes},get logo(){return e.GFCloud.Logo.data.attributes},get buttons(){return e.GFCloud.Buttons},[s]:{title:h(e.GFCloud,"Title"),text:h(e.GFCloud,"Paragraph"),image:h(e.GFCloud.Media.data,"attributes"),logo:h(e.GFCloud.Logo.data,"attributes"),buttons:h(e.GFCloud,"Buttons")}},3,"JJ_4")],1,"JJ_5")},fh=b(g(ph,"s_ee4CXUkPYJQ")),gh=t=>`query QueryGFCloud {
        pageGfCloud (locale:"${t}"){    
          data{
            attributes{
              GNetworkLogo{
                ${_}
              }
            GFCloud{
              Title
              Logo{
                ${_}
              }
              Paragraph
              Media{
                ${_}
              }
              Buttons{
                Text
                Link
              }
            }
              
            ${H}
            }
          }
        }
        sectionNetwork (locale:"${t}"){
          data {
            attributes {
              Map {
                MapPicture {
                  ${_}
                }
                ServersTitle
                Servers (pagination:{limit:50}){
                  Text
                  Link
                  Icon{
                    ${_}
                  }
                }
              }
              Description{
                Title
                Paragraph
              }
            }
          }
        }
      }`,xh=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(gh,e)},ps=R(g(xh,"s_imQl8eEcDG0")),mh=()=>{const t=ps(),e=t.value.pageData.data;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGfCloud.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageGfCloud.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfCloud"]["data"]["attributes"]["SEO"]')}},3,"Fb_0"),i(fh,{data:e},3,"Fb_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Fb_2")},1,"Fb_3")},hh=b(g(mh,"s_8q0wwtngnhI")),bh=({resolveValue:t})=>{const a=t(ps).pageData.data.pageGfCloud.data.attributes.SEO;return V(a)},$h=Object.freeze(Object.defineProperty({__proto__:null,default:hh,head:bh,usePageData:ps},Symbol.toStringTag,{value:"Module"})),vh=t=>n("div",null,{class:"flex w-full flex-col items-center justify-center gap-3 rounded-xl bg-white p-8 shadow-xl"},[n("div",null,{class:"w-fit rounded-full bg-secondary-red p-2"},i(A,{get media(){return t.tip.Icon.data.attributes},width:17,height:17,toWhite:!0,[s]:{media:u(e=>e.tip.Icon.data.attributes,[t],'p0.tip["Icon"]["data"]["attributes"]'),width:s,height:s,toWhite:s}},3,"Ie_0"),1,null),n("h4",null,{class:"text-center font-[700] text-primary-blue"},u(e=>e.tip.Title,[t],'p0.tip["Title"]'),3,null),i(M,{classN:"text-[14px] font-[500]",get text(){return t.tip.Text},[s]:{classN:s,text:u(e=>e.tip.Text,[t],'p0.tip["Text"]')}},3,"Ie_1")],1,t.tip.Title),yh=t=>{const e=b(g(vh,"s_YpuX8PZv7fg"));return n("div",null,{class:"mt-6 flex w-full max-w-[1200px] flex-col items-center justify-center gap-4 p-8"},[n("h2",null,{class:"text-center text-[40px] font-[500] text-primary-blue"},u(a=>a.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"grid w-full grid-cols-3 gap-4  max-[800px]:grid-cols-1"},t.data.Bullets.slice(0,3).map((a,l)=>i(e,{tip:a},3,l)),1,null),n("div",null,{class:"grid w-full grid-cols-2 gap-4 max-[800px]:grid-cols-1"},t.data.Bullets.slice(3,5).map((a,l)=>i(e,{tip:a},3,l)),1,null)],1,"Ie_2")},_h=b(g(yh,"s_0W2ahleMHpc")),wh=t=>i(G,{children:t.data.map((e,a)=>i(Ve,{data:e,reverse:a%2===1,textPercentage:60,[s]:{textPercentage:s}},3,a))},1,"mL_0"),Sh=b(g(wh,"s_GQ2BMpdgaAM")),Th=t=>n("div",null,{class:"relative flex h-full w-full items-center justify-center overflow-hidden"},[!(t.isFirst??!1)&&n("div",null,{class:"absolute bottom-[calc(50%+20px)] top-0 border-l-2 border-secondary-red"},null,3,"9r_0"),!(t.isLast??!1)&&n("div",null,{class:"absolute bottom-0 top-[calc(50%+20px)] border-l-2 border-secondary-red"},null,3,"9r_1"),n("div",null,{class:"flex h-[36px] w-[36px] items-center justify-center self-center rounded-full border border-secondary-red bg-transparent"},n("div",null,{class:"flex h-[30px] w-[30px] items-center justify-center rounded-full bg-secondary-red text-white"},u(e=>e.caption,[t],"p0.caption"),3,null),3,null)],1,"9r_2"),Dh=t=>{const e=b(g(Th,"s_2AZJZ0GqJyo"));return(t.direction??"vertical")==="vertical"?n("div",null,{class:"grid w-fit items-center justify-around",style:u(a=>({gridTemplateColumns:(a.align??"start")==="center"?"1fr 60px 1fr":(a.align??"start")==="end"?"1fr 60px":"60px 1fr"}),[t],'{gridTemplateColumns:(p0.align??"start")==="center"?"1fr 60px 1fr":(p0.align??"start")==="end"?"1fr 60px":"60px 1fr"}')},t.steps.map((a,l)=>z(i(G,{children:[(t.align??"start")!=="center"&&i(G,{children:[(t.align??"start")==="start"&&i(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_3"),n("div",null,{class:u(r=>`my-[20px] ${(r.align??"start")==="end"&&"ml-auto"} flex w-full flex-row items-center justify-center rounded-[50px] bg-white p-6 shadow-xl`,[t],'`my-[20px] ${(p0.align??"start")==="end"&&"ml-auto"} flex w-full flex-row items-center justify-center rounded-[50px] bg-white p-6 shadow-xl`')},i(M,{classN:"text-center",text:a,[s]:{classN:s}},3,"9r_4"),1,l),(t.align??"start")==="end"&&i(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_5")]},1,"9r_6"),(t.align??"start")==="center"&&i(G,{children:[n("div",null,{class:"flex w-fit flex-row items-center rounded-[50px] bg-white px-6 py-10 shadow-lg"},i(M,{classN:"text-center",text:a,[s]:{classN:s}},3,"9r_7"),1,l),l%2===0?i(G,{children:[i(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_8"),n("div",null,null,null,3,null),n("div",null,null,null,3,null),l+1<t.steps.length&&i(e,{caption:(l+2).toString(),isLast:l===t.steps.length},3,"9r_9")]},1,"9r_10"):i(G,null,3,"9r_11")]},1,"9r_12")]},1,"9r_13"))),1,"9r_14"):n("div",null,{class:"flex flex-row justify-between"},t.steps.map((a,l)=>n("div",null,{class:"flex flex-col items-center"},[n("div",null,{class:"h-2 w-2 rounded-full bg-primary-blue"},null,3,null),n("div",null,{class:"text-primary-blue"},a,1,null)],1,l)),1,null)},cl=b(g(Dh,"s_Zd6X64AupUo")),Ph=t=>{const e=t.data.pageGfIS.data.attributes;let a="";return e.WiFiListing.Bullets.forEach(l=>{a+="- "+l.Text+`
`}),n("div",null,{class:"flex w-full flex-col items-center justify-center",onClick$:B("s_wLQQzX3cS04")},[n("h1",null,{class:"max-w-[800px] px-8 text-center text-[42px] font-[600] text-primary-blue max-[600px]:text-[32px]"},S(e.Introduction,"Paragraph"),1,null),i(_h,{get data(){return e.Tips},[s]:{data:h(e,"Tips")}},3,"5A_0"),i(Sh,{get data(){return e.InternetInfo},[s]:{data:h(e,"InternetInfo")}},3,"5A_1"),n("div",null,{class:"flex max-w-[1200px] items-start justify-center gap-4 p-8 max-[800px]:flex-col"},[n("p",null,{class:"w-[60%] text-[15px] text-primary-blue max-[800px]:w-full"},S(e.InternetExample[0],"Text"),1,null),n("p",null,{class:"w-[40%] text-[15px] font-[600] text-primary-blue max-[800px]:w-full"},S(e.InternetExample[1],"Text"),1,null)],1,null),i(Lt,{get title(){return e.WiFiListing.Title},text:a,get image(){return e.WiFiPicture.data.attributes},textPercentage:50,reverse:!0,[s]:{title:h(e.WiFiListing,"Title"),image:h(e.WiFiPicture.data,"attributes"),textPercentage:s,reverse:s}},3,"5A_2"),i(Ve,{get data(){return e.TestPar},textPercentage:60,[s]:{data:h(e,"TestPar"),textPercentage:s}},3,"5A_3"),i(cl,{steps:e.TestStepss.map(l=>"**"+l.Title+`**

`+l.Text)},3,"5A_4"),i(Lt,{get text(){return e.TestGlossary.Paragraph},get image(){return e.TestGlossary.Media.data.attributes},textPercentage:60,[s]:{text:h(e.TestGlossary,"Paragraph"),image:h(e.TestGlossary.Media.data,"attributes"),textPercentage:s}},3,"5A_5"),n("h3",null,{class:"text-[40px] font-[600] text-primary-blue"},S(e.TroubleSteps,"Title"),1,null),n("p",null,{class:"my-4 text-primary-blue"},S(e,"TroubleDescription"),1,null),n("div",null,{class:"max-w-[1200px]  px-8"},i(cl,{steps:e.TroubleSteps.Bullets.map(l=>l.Title?"**"+l.Title+`**
`+l.Text.replaceAll(`

`,`
`):"**"+l.Text.replaceAll(`

`,`
`)+"**")},3,"5A_6"),1,null)],1,"5A_7")},kh=b(g(Ph,"s_DlDfET88Hb4")),Lh=t=>`query {
    pageGfIS(locale:"${t}") {
      data {
        attributes {
          Introduction {
            Paragraph
            Media {
              ${_}
            }
          }
          Tips {
            Title
            Bullets {
              Title
              Text
              Icon {
               ${_}
              }
            }
          }
          InternetInfo {
            Title
            Paragraph
            Media {
              ${_}
            }
          }
          InternetExample {
            Text
          }
          WiFiPicture {
           ${_}
          }
          WiFiListing {
            Title
            Bullets {
              Title
              Text
            }
          }
          TestPar{
            Title
            Paragraph
            Media{
              ${_}
            }
          }
          TestStepss{
            Title
            Text
          }
          TestGlossary {
            Paragraph
            Media {
              ${_}
            }
          }
          TroubleSteps {
            Title
            Bullets {
              Title
              Text
            }
          }
          TroubleDescription
          ${H}
  
        }
      }
    }
  }`,Ch=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Lh,e)},fs=R(g(Ch,"s_YTLZ80iXjpk")),Mh=()=>{const t=fs();return i(F,{get data(){return t.value.layoutData},children:i(kh,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"0g_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"0g_1")},jh=b(g(Mh,"s_sPmm4Hp5SbY")),Ah=({resolveValue:t})=>{const a=t(fs).pageData.data.pageGfIS.data.attributes.SEO;return V(a)},Eh=Object.freeze(Object.defineProperty({__proto__:null,default:jh,head:Ah,usePageData:fs},Symbol.toStringTag,{value:"Module"})),Nh=t=>(z(),n("div",null,{class:"flex w-fit max-w-[300px] flex-col items-center justify-between rounded-[35px] bg-white px-5"},[n("div",null,{class:"mt-8 flex w-fit max-w-full flex-col items-center self-center"},[t.isFullLogo??!1?n("div",null,{class:"flex flex-col justify-center items-center self-center gap-2 "},[i(A,{get media(){return t.logo},height:100,width:300,clasN:" w-full  overflow-hidden object-center",[s]:{media:u(e=>e.logo,[t],"p0.logo"),height:s,width:s,clasN:s}},3,"0s_0"),n("div",null,{class:" text-2xl font-bold leading-6 text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null)],1,"0s_1"):n("div",null,{class:"flex w-full items-start gap-5 self-center"},[i(A,{get media(){return t.logo},height:100,width:100,clasN:"aspect-square w-[70px] max-w-full items-center justify-center self-stretch overflow-hidden object-contain object-center",[s]:{media:u(e=>e.logo,[t],"p0.logo"),height:s,width:s,clasN:s}},3,"0s_2"),n("div",null,{class:"my-auto flex flex-col self-center"},n("div",null,{class:"self-start whitespace-nowrap text-2xl font-bold leading-6 text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),3,null)],1,null),t.price&&t.priceTime&&n("div",null,{class:"mt-2 text-center text-base leading-4 tracking-tighter text-primary-blue"},[n("span",null,{class:"text-2xl font-light text-secondary-red"},"$",3,null),n("span",null,{class:"text-2xl font-light text-primary-blue"},u(e=>e.price,[t],"p0.price"),3,null),n("span",null,{class:" text-2xl text-primary-blue"},u(e=>e.priceTime,[t],"p0.priceTime"),3,null)],3,"0s_3"),n("div",null,{class:"mt-5 text-center text-base text-primary-blue"},i(M,{get text(){return t.description},[s]:{text:u(e=>e.description,[t],"p0.description")}},3,"0s_4"),1,null),n("div",null,{class:"border-gary-500 my-4 h-[1px] w-full border-t-2"},null,3,null),n("div",null,{class:"mt-5 text-base text-primary-blue"},t.features.map((e,a)=>n("span",null,{class:"my-1 flex flex-row items-center justify-start gap-2"},[n("div",null,null,i(Ji,{class:"mx-2 h-[20px] w-[20px] fill-primary-blue text-primary-blue",[s]:{class:s}},3,"0s_5"),1,null),n("h3",null,{class:"text-sm font-light"},S(e,"Text"),1,a)],1,a)),1,null)],1,null),n("div",null,{class:"my-4 flex w-full flex-col items-center justify-center"},[n("div",null,{class:"border-gary-500 my-4 h-[1px] w-full border-t-2"},null,3,null),t.btnText&&t.btnLink&&i(tt,{get text(){return t.btnText},get link(){return t.btnLink},[s]:{text:u(e=>e.btnText,[t],"p0.btnText"),link:u(e=>e.btnLink,[t],"p0.btnLink")}},3,"0s_6")],1,null)],1,"0s_7")),gs=b(g(Nh,"s_Ttt0gCfGtkU")),Ih=t=>n("div",null,{class:"flex flex-col items-center justify-around"},[n("div",null,{class:"mx-4 my-8 max-w-[500px]"},i(A,{get media(){return t.data.Logo.data.attributes},width:1230,height:229,[s]:{media:u(e=>e.data.Logo.data.attributes,[t],'p0.data["Logo"]["data"]["attributes"]'),width:s,height:s}},3,"6h_0"),1,null),n("div",null,{class:"mx-10 my-4 flex max-w-[800px] flex-col items-center justify-center gap-2 text-primary-blue"},[n("span",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(e=>e.data.Introduction.Title,[t],'p0.data["Introduction"]["Title"]'),3,null),i(M,{classN:"text-center",get text(){return t.data.Introduction.Paragraph},[s]:{classN:s,text:u(e=>e.data.Introduction.Paragraph,[t],'p0.data["Introduction"]["Paragraph"]')}},3,"6h_1")],1,null),n("div",null,{class:"flex flex-wrap gap-10 justify-center mx-4 my-8 items-start"},t.data.PackTables.map((e,a)=>i(gs,{get title(){return e.Title},get logo(){return e.Logo.data.attributes},get description(){return e.Description},get features(){return e.Features},[s]:{title:h(e,"Title"),logo:h(e.Logo.data,"attributes"),description:h(e,"Description"),features:h(e,"Features")}},3,a)),1,null),i(tt,{get text(){return t.data.ButtonConfig.Text},get link(){return t.data.ButtonConfig.Link},[s]:{text:u(e=>e.data.ButtonConfig.Text,[t],'p0.data["ButtonConfig"]["Text"]'),link:u(e=>e.data.ButtonConfig.Link,[t],'p0.data["ButtonConfig"]["Link"]')}},3,"6h_2"),i(M,{classN:"text-primary-blue text-center mx-4 my-8",get text(){return t.data.Disclaimer},[s]:{classN:s,text:u(e=>e.data.Disclaimer,[t],'p0.data["Disclaimer"]')}},3,"6h_3"),i(Lt,{get text(){return t.data.GFInternetSupport.Paragraph},get title(){return t.data.GFInternetSupport.Title},get logo(){return t.data.GFInternetSupport.Logo.data.attributes},get buttons(){return t.data.GFInternetSupport.Buttons},get image(){return t.data.GFInternetSupport.Media.data.attributes},[s]:{text:u(e=>e.data.GFInternetSupport.Paragraph,[t],'p0.data["GFInternetSupport"]["Paragraph"]'),title:u(e=>e.data.GFInternetSupport.Title,[t],'p0.data["GFInternetSupport"]["Title"]'),logo:u(e=>e.data.GFInternetSupport.Logo.data.attributes,[t],'p0.data["GFInternetSupport"]["Logo"]["data"]["attributes"]'),buttons:u(e=>e.data.GFInternetSupport.Buttons,[t],'p0.data["GFInternetSupport"]["Buttons"]'),image:u(e=>e.data.GFInternetSupport.Media.data.attributes,[t],'p0.data["GFInternetSupport"]["Media"]["data"]["attributes"]')}},3,"6h_4")],1,"6h_5"),Bh=b(g(Ih,"s_30f4iq1HkIo")),Oh=t=>`query QueryGFInternet {
        pageGfInternet(locale:"${t}"){
          data {
            attributes {
              Logo {
                ${_}
              }
              Introduction {
                Paragraph
                Buttons {
                  Text
                  Link
                }
              }
              PackTables {
                Logo {
                  ${_}
                }
                Title
                Subtitle
                Price
                Pricetime
                Description
                Features {
                  Text
                  Title
                }
                Button {
                  Link
                  Text
                }
              }
              Disclaimer
              ButtonConfig{
                Text
                Link
              }
              GFInternetSupport {
                Title
                Subtitle
                Paragraph
                Logo {
                  ${_}
                }
                Media {
                  ${_}
                }
                Buttons {
                  Text
                  Link
                }
              }
              ${H}
            }
          }
        }
      }
      `,qh=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Oh,e)},xs=R(g(qh,"s_PG6JGbvGdSU")),Rh=()=>{const t=xs(),e=t.value.pageData.data.pageGfInternet.data.attributes;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGfInternet.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageGfInternet.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfInternet"]["data"]["attributes"]["SEO"]')}},3,"TH_0"),i(Bh,{data:e},3,"TH_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"TH_2")},1,"TH_3")},zh=b(g(Rh,"s_cj0XMKyWnnQ")),Fh=({resolveValue:t})=>{const a=t(xs).pageData.data.pageGfInternet.data.attributes.SEO;return V(a)},Qh=Object.freeze(Object.defineProperty({__proto__:null,default:zh,head:Fh,usePageData:xs},Symbol.toStringTag,{value:"Module"})),Gh=t=>{const e=t.data.pageGfIoT.data.attributes.Services,a=t.data.pageGfIoT.data.attributes.Introduction,l=t.data.pageGfIoT.data.attributes.Logo.data.attributes,r=t.data.pageGfIoT.data.attributes.WeatherAnounce;return n("div",null,{class:"flex flex-col items-center justify-center "},[n("div",null,{class:"m-4 flex items-center justify-center gap-4 rounded-full bg-[#edf6ff] px-8 py-5 shadow-xl max-sm:flex-col"},[n("span",null,{class:"text-center text-[18px] font-[600] text-primary-blue max-md:text-[14px]"},S(r,"Paragraph"),1,null),i(tt,{get text(){return r.Buttons[0].Text},get link(){return r.Buttons[0].Link},[s]:{text:h(r.Buttons[0],"Text"),link:h(r.Buttons[0],"Link")}},3,"Ws_0")],1,null),n("div",null,{class:"mx-4 my-8 max-w-[500px]"},i(A,{media:l,width:1230,height:229,[s]:{width:s,height:s}},3,"Ws_1"),1,null),n("div",null,{class:"mx-10 my-4 flex max-w-[800px] flex-col items-center justify-center gap-2 text-primary-blue"},[n("span",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},S(a,"Title"),1,null),i(M,{classN:"text-justify",get text(){return a.Paragraph},[s]:{classN:s,text:h(a,"Paragraph")}},3,"Ws_2")],1,null),i(We,{data:e},3,"Ws_3")],1,"Ws_4")},Hh=b(g(Gh,"s_1kXwT2q88rA")),Vh=t=>`
  query QueryGFIoT {
    pageGfIoT(locale:"${t}"){
      data{
        attributes{
          Logo{
            ${_}
          }
          
          Introduction{
            Title
            Paragraph
          }
          
          WeatherAnounce{
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
          
          Services{
            Logo{
             ${_}
            }
            Title
            Paragraph
            Media{
             ${_}
            }
            Buttons{
              Text
              Link
            }
          }
          ${H}
        }
      }
    }
  }
    `,Wh=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Vh,e)},ms=R(g(Wh,"s_2v03ITQBdcI")),Uh=()=>{const t=ms();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGfIoT.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfIoT.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfIoT"]["data"]["attributes"]["SEO"]')}},3,"Mz_0"),i(Hh,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Mz_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Mz_2")},Yh=b(g(Uh,"s_teV3ya9bjBI")),Zh=({resolveValue:t})=>{const a=t(ms).pageData.data.pageGfIoT.data.attributes.SEO;return V(a)},Kh=Object.freeze(Object.defineProperty({__proto__:null,default:Yh,head:Zh,usePageData:ms},Symbol.toStringTag,{value:"Module"})),Jh=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(M,{get text(){return t.data.TextContent},classN:"markdownTitle markdownh3 markdownHyper text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"Wt_0")],1,"Wt_1"),Xh=b(g(Jh,"s_wAqfRFn86VY")),tb=t=>`query QuerygftvPrivacyP {
        pageGfTvPp(locale:"${t}"){    
          ${aa}
          ${H}
            }
          }
        }
      }`,eb=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(tb,e)},hs=R(g(eb,"s_o03PAaBI278")),ab=()=>{const t=hs(),e=t.value.pageData.data.pageGfTvPp.data.attributes.Content;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(Xh,{data:e},3,"zG_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"zG_1")},1,"zG_2")},lb=b(g(ab,"s_0UMSXuOQgCA")),nb=({resolveValue:t})=>{const a=t(hs).pageData.data.pageGfTvPp.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},sb=Object.freeze(Object.defineProperty({__proto__:null,default:lb,head:nb,usePageData:hs},Symbol.toStringTag,{value:"Module"})),rb=async(t,e)=>{const a=gt(t);try{const l=await fetch(a);if(!l.ok)throw new Error(`Error al descargar el archivo desde ${a}. Estado: ${l.status}`);const r=await l.arrayBuffer(),o=new Blob([r],{type:"application/pdf"}),c=window.URL.createObjectURL(o),p=document.createElement("a");p.href=c,p.download=e,p.click(),window.URL.revokeObjectURL(c)}catch(l){console.error(l)}},uo=g(rb,"s_Vd02rPSFNlY"),ib=()=>{const[t]=U();uo(t.urlDoc,t.nameDoc)},ob=t=>{const e=g(ib,"s_L0UgBFqZ3XI",[t]);return n("div",null,{class:"flex flex-col h-[250px] w-[300px] bg-white shadow-2xl rounded-3xl justify-evenly items-center p-4"},[n("h3",null,{class:"text-2xl flex text-center font-bold text-[#2E5899]"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex w-fit items-center font-semibold justify-center gap-2 rounded-full border-2 border-teal-500 bg-white p-1 px-7 text-btn-green opacity-80 shadow-md transition-all hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:e},n("div",null,{class:"flex flex-row gap-2 items-center font-semibold text-center justify-center"},[u(a=>a.btnText,[t],"p0.btnText"),n("div",null,{class:"h-[25px] w-[25px] flex items-center justify-center font-bold text-white bg-teal-500 hover:text-teal-500 hover:bg-white rounded-full"},i(Xi,{class:"stroke-current",[s]:{class:s}},3,"h5_0"),1,null)],1,null),1,null)],1,"h5_1")},co=b(g(ob,"s_tF7T0UXX4O0")),ub=()=>{const[t]=U();uo(t.urlDoc,t.nameDoc)},cb=t=>{const e=g(ub,"s_8SKPRTg50C4",[t]);return n("div",null,{class:"h-[370px] w-[400px] py-8 px-4 bg-white rounded-2xl pb-2 flex flex-col items-center justify-between shadow-2xl"},[n("div",null,{class:"relative flex w-full overflow-hidden"},i(A,{clasN:"object-fill w-full h-full rounded-t-2xl",width:"2076",height:"1500",get media(){return t.image},[s]:{clasN:s,width:s,height:s,media:u(a=>a.image,[t],"p0.image")}},3,"d0_0"),1,null),n("h2",null,{class:"text-2xl flex text-center font-bold text-[#2E5899]"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex w-fit items-center font-semibold justify-center gap-2 rounded-full border-2 border-teal-500 bg-white p-1 text-btn-green opacity-80 shadow-md transition-all hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:e},n("div",null,{class:"flex flex-row gap-2 items-center font-semibold text-center justify-center"},[u(a=>a.btnText,[t],"p0.btnText"),n("div",null,{class:"h-[25px] w-[25px] flex items-center justify-center font-bold text-white bg-teal-500 hover:text-teal-500 hover:bg-white rounded-full"},i(Xi,{class:"stroke-current",[s]:{class:s}},3,"d0_1"),1,null)],1,null),1,null)],1,"d0_2")},po=b(g(cb,"s_OdYDJRaDcFY")),db=t=>{const e=t.data.pageGfTvS.data.attributes,a=t.data.sectionChGuide.data.attributes;return n("div",null,{class:"flex flex-col justify-center items-center"},[n("div",null,{class:"flex flex-col md:flex-row px-8 items-center justify-center gap-5"},[n("h1",null,{class:"text-2xl text-center font-semibold text-primary-blue"},S(e,"IntroText"),1,null),n("div",null,{class:"h-[150px] relative w-[350px] flex mb-14"},[n("video",{src:gt(e.IntroMedia.data[1].attributes.url)},{class:"absolute pt-2",autoplay:!0,loop:!0,muted:!0},null,3,null),i(A,{clasN:"absolute z-0",get media(){return e.IntroMedia.data[0].attributes},width:"1082",height:"786",[s]:{clasN:s,media:h(e.IntroMedia.data[0],"attributes"),width:s,height:s}},3,"yQ_0")],1,null)],1,null),n("div",null,{class:"flex my-20 w-full py-10 bg-primary-blue bg-opacity-40"},n("div",null,{class:"flex w-full py-10 bg-primary-blue bg-opacity-60"},n("div",null,{class:"flex w-full flex-col py-10 px-8 items-center justify-between bg-primary-blue bg-opacity-80"},[n("h2",null,{class:"font-bold text-3xl md:text-4xl my-5 text-white"},S(e,"DevicesTitle"),1,null),n("div",null,{class:"flex flex-wrap gap-5 items-center justify-center"},e.Devices.map((l,r)=>n("div",null,{class:"h-[300px] w-[300px] p-5 rounded-full bg-white bg-opacity-40"},n("div",null,{class:"h-full w-full p-5 rounded-full bg-white bg-opacity-60"},n("div",null,{class:"h-full w-full object-cover flex flex-col p-8 justify-center items-center rounded-full bg-white"},[n("h2",null,{class:"text-center font-semibold text-2xl text-primary-blue"},S(l,"Title"),1,null),i(M,{classN:"text-s text-primary-dark-blue",get text(){return l.Paragraph},[s]:{classN:s,text:h(l,"Paragraph")}},3,"yQ_1")],1,null),1,null),1,r)),1,null),n("p",null,{class:"text-center justify-end my-5 text-white"},S(e,"DevicesNote"),1,null)],1,null),1,null),1,null),n("div",null,{class:"flex flex-col justify-center px-8 items-center"},[n("div",null,{class:"w-full md:w-2/3 flex flex-col items-center"},[n("h2",null,{class:"text-3xl md:text-4xl text-center font-bold text-primary-blue"},S(e.GuidePar,"Title"),1,null),i(M,{classN:"text-center",get text(){return e.GuidePar.Paragraph},[s]:{classN:s,text:h(e.GuidePar,"Paragraph")}},3,"yQ_2")],1,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-10 my-5"},e.Guides.map((l,r)=>i(co,{get urlDoc(){return l.Guide.data.attributes.url},get title(){return l.Title},get btnText(){return l.BtnText},get nameDoc(){return l.Guide.data.attributes.name},[s]:{urlDoc:h(l.Guide.data.attributes,"url"),title:h(l,"Title"),btnText:h(l,"BtnText"),nameDoc:h(l.Guide.data.attributes,"name")}},3,r)),1,null)],1,null),n("div",null,{class:"flex w-full flex-col items-center justify-center"},n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex min-[800px]:w-[70%] flex-col items-center justify-center gap-4 px-10"},[n("div",null,{class:"max-w-[470px]"},i(A,{get media(){return a.Logo.data.attributes},width:"1230",height:"230",[s]:{media:h(a.Logo.data,"attributes"),width:s,height:s}},3,"yQ_3"),1,null),n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},S(a,"Title"),1,null),1,null),i(M,{get text(){return a.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{text:h(a,"Paragraph"),classN:s}},3,"yQ_4")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(po,{get nameDoc(){return a.GuideBox.Guide.data.attributes.name},get urlDoc(){return a.GuideBox.Guide.data.attributes.url},get image(){return a.Picture.data.attributes},get title(){return a.GuideBox.Title},get btnText(){return a.GuideBox.BtnText},[s]:{nameDoc:h(a.GuideBox.Guide.data.attributes,"name"),urlDoc:h(a.GuideBox.Guide.data.attributes,"url"),image:h(a.Picture.data,"attributes"),title:h(a.GuideBox,"Title"),btnText:h(a.GuideBox,"BtnText")}},3,"yQ_5"),1,null)],1,null),1,null)],1,"yQ_6")},pb=b(g(db,"s_L3FZbhALRyo")),fb=t=>`query gfTvSupport {
        pageGfTvS (locale:"${t}") {
          data {
            attributes {
              IntroText
              IntroMedia {
                ${_}
              }
              DevicesTitle
              Devices {
                Title
                Paragraph
                Buttons {
                  Text
                  Link
                }
              }
              DevicesNote
              GuidePar {
                Title
                Paragraph
              }
              Guides {
                Title
                BtnText
                Guide {
                  data {
                    attributes {
                      url
                      name
                    }
                  }
                }
              }
              ${H}
            }
          }
        }
        sectionChGuide{
          data{
            attributes{
              Logo{
                ${_}
              }
              Picture{
                ${_}
              }
              Title
              Paragraph
              GuideBox{
                Title
                BtnText
                Guide{
                  data{
                    attributes{
                      url
                      name
                    }
                  }
                }
              }
            }
          }
        }
      }
      `,gb=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(fb,e)},bs=R(g(gb,"s_Y5JMYQJnIpI")),xb=()=>{const t=bs(),e=t.value.pageData.data;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(pb,{data:e},3,"GS_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"GS_1")},1,"GS_2")},mb=b(g(xb,"s_sZYBtsmoVg8")),hb=({resolveValue:t})=>{const a=t(bs).pageData.data.pageGfTvS.data.attributes.SEO;return V(a)},bb=Object.freeze(Object.defineProperty({__proto__:null,default:mb,head:hb,usePageData:bs},Symbol.toStringTag,{value:"Module"})),$b=t=>n("div",null,{class:"gap-10 w-ful flex flex-col"},t.data.map((e,a)=>z(a%2==0?n("div",null,{class:"bg-primary-blue bg-opacity-40 py-10"},n("div",null,{class:"bg-primary-blue bg-opacity-60 py-10"},n("div",null,{class:"bg-primary-blue"},i(Lt,{color:"white",reverse:!0,get text(){return e.Paragraph},get image(){return e.Media.data.attributes},title:e.Title!=null?e.Title:"",textPercentage:50,backgroundColor:"primary-blue",[s]:{color:s,reverse:s,text:h(e,"Paragraph"),image:h(e.Media.data,"attributes"),textPercentage:s,backgroundColor:s}},3,a),1,null),1,null),1,a):i(Lt,{reverse:!1,get text(){return e.Paragraph},get image(){return e.Media.data.attributes},textPercentage:50,title:e.Title!=null?e.Title:"",[s]:{reverse:s,text:h(e,"Paragraph"),image:h(e.Media.data,"attributes"),textPercentage:s}},3,a))),1,"1n_0"),vb=b(g($b,"s_3YkhEsBDjTI")),yb=t=>(z(),n("div",null,{class:"justify-between min-h-[670px] w-[300px] items-center shadow-lg bg-white flex flex-col px-5 pb-4 rounded-[35px]"},[n("div",null,{class:"items-center self-center flex w-[310px] max-w-full flex-col mt-8"},[n("div",null,{class:"items-start self-center flex w-full gap-5"},[i(A,{width:80,height:80,get media(){return t.logo},clasN:"aspect-square object-contain object-center w-[70px] justify-center items-center overflow-hidden self-stretch max-w-full",[s]:{width:s,height:s,media:u(e=>e.logo,[t],"p0.logo"),clasN:s}},3,"Tv_0"),n("div",null,{class:"self-center flex flex-col my-auto"},[n("div",null,{class:"text-blue-800 text-2xl font-bold leading-6 self-start whitespace-nowrap"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"justify-center text-rose-700 text-xl mt-2"},u(e=>e.subtitle,[t],"p0.subtitle"),3,null)],3,null)],1,null),n("div",null,{class:"text-blue-800 flex flex-row mt-5"},[n("span",null,{class:"font-light text-3xl text-rose-700"},"$",3,null),n("span",null,{class:"font-light text-3xl text-blue-800"},u(e=>e.price,[t],"p0.price"),3,null),n("span",null,{class:" text-blue-800"},["/",u(e=>e.priceTime,[t],"p0.priceTime")],3,null)],3,null),n("div",null,{class:"items-start self-stretch flex flex-col mt-5"},[n("div",null,{class:"justify-between items-start self-stretch flex w-full gap-5"},[n("div",null,{class:"text-blue-800 text-center text-base"},u(e=>e.description,[t],"p0.description"),3,null),i(ol,{get link(){return t.btnSeeMoreLink},get dataChannels(){return t.dataChannels},get planId(){return t.title},get channels(){return t.subtitle},get text(){return t.btnSeeMoreText},[s]:{link:u(e=>e.btnSeeMoreLink,[t],"p0.btnSeeMoreLink"),dataChannels:u(e=>e.dataChannels,[t],"p0.dataChannels"),planId:u(e=>e.title,[t],"p0.title"),channels:u(e=>e.subtitle,[t],"p0.subtitle"),text:u(e=>e.btnSeeMoreText,[t],"p0.btnSeeMoreText")}},3,"Tv_1")],1,null),n("div",null,{class:"justify-center items-start self-stretch flex gap-2.5 mt-2.5"},t.channels.map((e,a)=>i(A,{width:50,height:50,get media(){return e.attributes},clasN:"aspect-square object-contain object-center w-full overflow-hidden flex-1",[s]:{width:s,height:s,media:h(e,"attributes"),clasN:s}},3,a)),1,null)],1,null),n("div",null,{class:"border-gary-500 h-[1px] w-full border-t-2"},null,3,null),n("div",null,{class:"self-stretch w-full h-px mt-5 max-md:mx-0.5"},null,3,null),n("div",null,{class:"text-blue-800 text-base mt-5"},t.features.map((e,a)=>n("span",null,{class:"my-1 flex flex-row items-center justify-start gap-2"},[n("div",null,null,i(Ji,{class:"mx-2 h-[20px] w-[20px] fill-primary-blue text-primary-blue",[s]:{class:s}},3,"Tv_2"),1,null),n("h3",null,{class:"text-sm font-light"},S(e,"Text"),1,a)],1,a)),1,null)],1,null),t.btnLink&&t.btnText&&i(ol,{get link(){return t.btnLink},get text(){return t.btnText},[s]:{link:u(e=>e.btnLink,[t],"p0.btnLink"),text:u(e=>e.btnText,[t],"p0.btnText")}},3,"Tv_3")],1,"Tv_4")),_b=b(g(yb,"s_0v0O47RLS1E")),wb=t=>n("div",null,{class:"flex flex-col items-center justify-center my-8 mx-4"},[n("h2",null,{class:"text-3xl text-center md:text-5xl font-semibold text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-5 lg:gap-10 my-6"},t.data.map((e,a)=>{var l,r;return i(_b,{get logo(){return e.Logo.data.attributes},get title(){return e.Title},get subtitle(){return e.Subtitle},get price(){return e.Price},get priceTime(){return e.Pricetime},get description(){return e.Description},get channels(){return e.Channels.data},get btnSeeMoreLink(){return e.LineupButton.Link},get btnSeeMoreText(){return e.LineupButton.Text},get features(){return e.Features},btnLink:(l=e.Button)==null?void 0:l.Link,btnText:(r=e.Button)==null?void 0:r.Text,get dataChannels(){return t.dataChannels},[s]:{logo:h(e.Logo.data,"attributes"),title:h(e,"Title"),subtitle:h(e,"Subtitle"),price:h(e,"Price"),priceTime:h(e,"Pricetime"),description:h(e,"Description"),channels:h(e.Channels,"data"),btnSeeMoreLink:h(e.LineupButton,"Link"),btnSeeMoreText:h(e.LineupButton,"Text"),features:h(e,"Features"),dataChannels:u(o=>o.dataChannels,[t],"p0.dataChannels")}},3,a)}),1,null)],1,"q0_0"),Sb=b(g(wb,"s_m0jKnAHnXds")),Tb=t=>n("div",null,{class:"flex flex-col items-center justify-center px-6"},[n("h2",null,{class:"text-3xl md:text-5xl my-3 font-semibold text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap gap-8 items-start justify-center my-4"},t.data.map((e,a)=>n("div",null,{class:"flex flex-col w-full md:w-2/5 my-3 md:my-5 p-6 text-center items-center justify-center rounded-2xl bg-white shadow-xl"},[n("h3",null,{class:"text-primary-dark-blue my-4 font-semibold text-xl"},S(e,"Title"),1,null),i(M,{get text(){return e.Paragraph},[s]:{text:h(e,"Paragraph")}},3,"ys_0")],1,a)),1,null),i(M,{classN:"markdownli text-s",get text(){return t.disclaimers},[s]:{classN:s,text:u(e=>e.disclaimers,[t],"p0.disclaimers")}},3,"ys_1")],1,"ys_2"),Db=b(g(Tb,"s_Sqd58asrM5U")),Pb=t=>{let e=[];return n("div",null,{class:"flex flex-col items-center justify-center"},[n("h2",null,{class:"text-3xl text-center md:text-5xl my-3 font-semibold text-primary-blue"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap items-start justify-center my-6 gap-5"},t.data.map((a,l)=>n("div",null,{class:"w-[290px] min-h-[300px] py-6 px-2 flex-col items-center justify-center flex rounded-3xl bg-primary-blue"},[n("h2",null,{class:"text-3xl font-semibold text-white"},S(a,"Title"),1,null),n("div",null,{class:"flex flex-row"},[n("h2",null,{class:"text-white text-2xl"},["$ ",S(a,"Price")],1,null),n("p",null,{class:"text-white"},[" ",S(a,"Pricetime")],1,null)],1,null),n("div",null,{class:"flex flex-col bg-white w-full rounded-2xl mt-4 p-4"},a.Features.map((r,o)=>{if(z(),o<3)return e=[],n("div",null,{class:"flex flex-row gap-2 p-1 border-b-2"},[i(hr,{class:"text-secondary-red",[s]:{class:s}},3,"yk_0"),n("p",null,{class:"text-primary-blue"},S(r,"Title"),1,null)],1,o);if(o>=3&&(e.push(n("div",null,{class:"flex flex-row gap-2 p-1 border-b-2"},[i(hr,{class:"text-secondary-red",[s]:{class:s}},3,"yk_1"),n("p",null,{class:"text-primary-blue"},S(r,"Title"),1,null)],1,o)),o==3))return i(Ga,{title:"Show all channels",children:e,[s]:{title:s}},1,"yk_2")}),1,null)],1,l)),1,null)],1,"yk_3")},kb=b(g(Pb,"s_5iYsl7ZjuZc")),Lb=t=>{const e=t.data.data.pageGfTv.data.attributes,a=t.data.data.sectionChGuide.data.attributes,l=t.data.data.channelLineups.data;return n("div",null,{class:"flex flex-col justify-around"},[n("div",null,{class:"flex flex-col my-6 items-center justify-center gap-4"},[i(A,{get media(){return e.Logo.data.attributes},height:200,width:500,[s]:{media:h(e.Logo.data,"attributes"),height:s,width:s}},3,"5L_0"),n("h2",null,{class:"text-[50px] font-bold text-center text-primary-blue"},S(e.Titles[0],"Text"),1,null),n("h2",null,{class:"text-[50px] font-bold text-center text-secondary-red"},S(e.Titles[1],"Text"),1,null)],1,null),i(vb,{get data(){return e.Features},[s]:{data:h(e,"Features")}},3,"5L_1"),n("div",null,{class:"flex flex-col text-center p-4 items-center justify-center my-8"},[n("h2",null,{class:"text-3xl md:text-5xl font-semibold text-primary-blue my-6"},S(e.Feature,"Title"),1,null),i(M,{get text(){return e.Feature.Paragraph},[s]:{text:h(e.Feature,"Paragraph")}},3,"5L_2")],1,null),i(Sb,{dataChannels:l,get data(){return e.ChPackTables},get title(){return e.ChPackTitle},[s]:{data:h(e,"ChPackTables"),title:h(e,"ChPackTitle")}},3,"5L_3"),i(kb,{get data(){return e.PremiumTables},get title(){return e.PremiumTitle},[s]:{data:h(e,"PremiumTables"),title:h(e,"PremiumTitle")}},3,"5L_4"),n("div",null,{class:"flex w-full flex-col items-center justify-center"},[n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex min-[800px]:w-[70%] flex-col items-center justify-center gap-4 px-10"},[n("div",null,{class:"max-w-[470px]"},i(A,{get media(){return a.Logo.data.attributes},width:"1230",height:"230",[s]:{media:h(a.Logo.data,"attributes"),width:s,height:s}},3,"5L_5"),1,null),n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},S(a,"Title"),1,null),1,null),i(M,{get text(){return a.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{text:h(a,"Paragraph"),classN:s}},3,"5L_6")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(po,{get nameDoc(){return a.GuideBox.Guide.data.attributes.name},get urlDoc(){return a.GuideBox.Guide.data.attributes.url},get image(){return a.Picture.data.attributes},get title(){return a.GuideBox.Title},get btnText(){return a.GuideBox.BtnText},[s]:{nameDoc:h(a.GuideBox.Guide.data.attributes,"name"),urlDoc:h(a.GuideBox.Guide.data.attributes,"url"),image:h(a.Picture.data,"attributes"),title:h(a.GuideBox,"Title"),btnText:h(a.GuideBox,"BtnText")}},3,"5L_7"),1,null)],1,null),i(Db,{get data(){return e.Additionals},get disclaimers(){return e.Disclaimers},get title(){return e.AdditionalsTitle},[s]:{data:h(e,"Additionals"),disclaimers:h(e,"Disclaimers"),title:h(e,"AdditionalsTitle")}},3,"5L_8")],1,null)],1,"5L_9")},Cb=b(g(Lb,"s_dsszBuF1I7U")),Mb=t=>`sectionChGuide(locale:"${t}"){
        data{
          attributes{
            Logo{
              ${_}
            }
            Title
            Paragraph
            
            GuideBox{
              BtnText
              Guide{
                data{
                  attributes{
                    name
                    url
                  }
                }
              }
            }
            
            Picture{
             ${_}
            }
          }
        }
      }`,jb=t=>`query {
        pageGfTv(locale:"${t}"){
          data {
            attributes {
              Logo {
               ${_}
              }
              Titles {
                Text
              }
              Features {
                Title
                Subtitle
                Paragraph
                Media {
                  ${_}
                }
              }
              Feature {
                Title
                Subtitle
                Paragraph
              }
              ChPackTitle
              ChPackTables {
                Logo {
                  ${_}
                }
                Title
                Subtitle
                Price
                Pricetime
                Description
                Channels {
                  ${_}
                }
                LineupButton{
                  Text
                  Link
                }
                Features {
                  Title
                  Text
                }
                Button {
                  Text
                  Link
                }
              }
              PremiumTitle
              PremiumTables {
                Title
                Price
                Pricetime
                Features {
                  Title
                }
              }
      
              
              
              AdditionalsTitle
              Additionals {
                Title
                Paragraph
              }
              Disclaimers
              
              ${H}
            }
          }
        }
        
        ${Mb(t)}

        channelLineups (pagination:{limit:250}){
          data{
            attributes{
              Channel_name
              Image{
                ${_}
              }
              Category
              package_tvs{
                data{
                  attributes{
                    package
                  }
                }
              }
            }
        }
        }
      }`,Ab=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(jb,e)},$s=R(g(Ab,"s_dLnU84H8AgM")),Eb=()=>{const t=$s();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGfTv.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfTv.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfTv"]["data"]["attributes"]["SEO"]')}},3,"ad_0"),i(Cb,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"ad_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"ad_2")},1,"ad_3")},Nb=b(g(Eb,"s_yF5Z09ey0P4")),Ib=({resolveValue:t})=>{const a=t($s).pageData.data.pageGfTv.data.attributes.SEO;return V(a)},Bb=Object.freeze(Object.defineProperty({__proto__:null,default:Nb,head:Ib,usePageData:$s},Symbol.toStringTag,{value:"Module"})),Ob=t=>{const e=t.data.pageGfVS.data.attributes,a=t.data.sectionPortGfv.data.attributes.Portability;return n("div",null,{class:"flex flex-col items-center"},[n("div",null,{class:"relative w-full md:w-2/3 h-[210px] md:h-[150px] bg-blue-200 flex flex-row justify-end items-center rounded-full"},[n("div",null,{class:"h-full absolute rounded-full w-3/4 bg-blue-300"},null,3,null),n("div",null,{class:"h-full absolute rounded-full w-2/4 bg-blue-400"},null,3,null),n("div",null,{class:"h-full absolute rounded-full w-1/4 bg-blue-600"},null,3,null),n("div",null,{class:"absolute w-full h-full flex flex-row p-5 justify-between items-center"},[n("h1",null,{class:"text-primary-blue lg:text-3xl md:text-2xl font-bold text-center text-xl"},S(e.Introduction,"Paragraph"),1,null),i(A,{get media(){return e.Introduction.Media.data.attributes},width:200,height:150,[s]:{media:h(e.Introduction.Media.data,"attributes"),width:s,height:s}},3,"T3_0")],1,null)],1,null),n("div",null,{class:"flex flex-col mt-10 justify-center px-8 items-center"},[n("div",null,{class:"w-full md:w-2/3 flex flex-col items-center"},[n("h2",null,{class:"text-3xl md:text-4xl text-center font-bold text-primary-blue"},S(e.GuidesPar,"Title"),1,null),i(M,{classN:"text-center",get text(){return e.GuidesPar.Paragraph},[s]:{classN:s,text:h(e.GuidesPar,"Paragraph")}},3,"T3_1")],1,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-10 my-5"},e.Guides.map((l,r)=>i(co,{get urlDoc(){return l.Guide.data.attributes.url},get title(){return l.Title},get btnText(){return l.BtnText},get nameDoc(){return l.Guide.data.attributes.name},[s]:{urlDoc:h(l.Guide.data.attributes,"url"),title:h(l,"Title"),btnText:h(l,"BtnText"),nameDoc:h(l.Guide.data.attributes,"name")}},3,r)),1,null)],1,null),n("div",null,null,i(Lt,{get title(){return a.Title},get text(){return a.Paragraph},get logo(){return a.Logo.data.attributes},get image(){return a.Media.data.attributes},backgroundColor:"transparent",get buttons(){return a.Buttons},[s]:{title:h(a,"Title"),text:h(a,"Paragraph"),logo:h(a.Logo.data,"attributes"),image:h(a.Media.data,"attributes"),backgroundColor:s,buttons:h(a,"Buttons")}},3,"T3_2"),1,null)],1,"T3_3")},qb=b(g(Ob,"s_BWUEQjQaK9s")),Rb=t=>`query queryGFTvSupport{
        pageGfVS(locale:"${t}"){
          data{
            attributes{
              Introduction{
                Paragraph
                Media{
                  ${_}
                }
              }
              GuidesPar{
                Title
                Paragraph
              }
              Guides{
                Title
                BtnText
                Guide{
                  data{
                    attributes{
                      url
                      name
                    }
                  }
                }
              }
              ${H}
            }
          }
        }
        sectionPortGfv(locale:"${t}"){
          data{
            attributes{
              Portability{
                Title
                Logo{
                 ${_}
                }
                Paragraph
                Media{
                 ${_}
                }
                Buttons{
                  Text
                  Link
                }
              }
            }
          }
        }
      }`,zb=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Rb,e)},vs=R(g(zb,"s_MmL0KO3X80U")),Fb=()=>{const t=vs();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(qb,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Wc_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Wc_1")},1,"Wc_2")},Qb=b(g(Fb,"s_MnhzpLl96M8")),Gb=({resolveValue:t})=>{const a=t(vs).pageData.data.pageGfVS.data.attributes.SEO;return V(a)},Hb=Object.freeze(Object.defineProperty({__proto__:null,default:Qb,head:Gb,usePageData:vs},Symbol.toStringTag,{value:"Module"})),Vb=t=>n("div",null,{class:"flex w-full justify-center text-primary-blue"},n("div",null,{class:"mx-8 my-8 flex flex-col items-center gap-6 text-center text-[18px]"},[i(A,{get media(){return t.data.Logo.data.attributes},width:"450",clasN:"mb-6",[s]:{media:u(e=>e.data.Logo.data.attributes,[t],'p0.data["Logo"]["data"]["attributes"]'),width:s,clasN:s}},3,"0F_0"),i(M,{get text(){return t.data.Paragraph},[s]:{text:u(e=>e.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"0F_1")],1,null),1,"0F_2"),Wb=b(g(Vb,"s_Ue8VWX4F1hY")),Ub=t=>n("div",null,{class:"max-w-1200 mx-8 flex flex-wrap justify-evenly gap-6"},t.data.map((e,a)=>{var l,r;return i(gs,{get title(){return e.Title},btnText:(l=e.Button)==null?void 0:l.Text,btnLink:(r=e.Button)==null?void 0:r.Link,get description(){return e.Description},price:e.Price.toString(),get features(){return e.Features},get logo(){return e.Logo.data.attributes},get priceTime(){return e.Pricetime},[s]:{title:h(e,"Title"),description:h(e,"Description"),features:h(e,"Features"),logo:h(e.Logo.data,"attributes"),priceTime:h(e,"Pricetime")}},3,a)}),1,"mV_0"),Yb=b(g(Ub,"s_2f78m38d8Zo")),Zb=t=>{const e={...t.data.pageGfV.data.attributes.Introduction,Logo:t.data.pageGfV.data.attributes.Logo},a=t.data.pageGfV.data.attributes.PackTables,l=t.data.sectionPortGfv.data.attributes.Portability;return n("div",null,null,[i(Wb,{data:e},3,"Pl_0"),n("div",null,{class:"mt-6"},i(Yb,{data:a},3,"Pl_1"),1,null),n("div",null,{class:"mt-6"},i(Ve,{data:l,color:"primary-blue",backgroundColor:"transparent",[s]:{color:s,backgroundColor:s}},3,"Pl_2"),1,null)],1,"Pl_3")},Kb=b(g(Zb,"s_S2NF7hg0ZA8")),Jb=t=>`
  query {
    pageGfV(locale:"${t}") {
      data {
        attributes {
          Logo {
            ${_}
          }
          Introduction {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          PackTables {
            Logo {
              ${_}
            }
            Title
            Subtitle
            Price
            Pricetime
            Description
            Features {
              Title
              Text
            }
            Button {
              Text
              Link
              Icon {
                ${_}
              }
            }
          }
          ${H}
        
        }
      }
    }
    sectionPortGfv(locale:"${t}"){
        data{
          attributes{
            Portability{
              Title
              Logo{
               ${_}
              }
              Paragraph
              Media{
               ${_}
              }
              Buttons{
                Text
                Link
              }
            }
          }
        }
      }
  }
    `,Xb=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Jb,e)},ys=R(g(Xb,"s_ThxJp560MGY")),t1=()=>{const t=ys();return i(F,{get data(){return t.value.layoutData},showHeader:!1,children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGfV.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfV.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfV"]["data"]["attributes"]["SEO"]')}},3,"0t_0"),i(Kb,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"0t_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"0t_2")},e1=b(g(t1,"s_1bc90Wt0fJ4")),a1=({resolveValue:t})=>{const a=t(ys).pageData.data.pageGfV.data.attributes.SEO;return V(a)},l1=Object.freeze(Object.defineProperty({__proto__:null,default:e1,head:a1,usePageData:ys},Symbol.toStringTag,{value:"Module"})),n1=t=>{const e=t.data.pageGivingBack.data.attributes.Helping;return n("div",null,{onClick$:B("s_IrVC6P6zSuQ")},i(We,{data:e},3,"eb_0"),1,"eb_1")},s1=b(g(n1,"s_g0kQhWSZ3HE")),r1=t=>`
    query QueryGivingBack {
        pageGivingBack(locale:"${t}"){    
          data{
            attributes{
                 Title
              Helping{
                Logo{
                 ${_}
                }
                Media{
                  ${_}
                }
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              ${H}
            }
          }
        }
      }
    `,i1=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(r1,e)},_s=R(g(i1,"s_HxhGEMn0sRc")),o1=()=>{const t=_s();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGivingBack.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGivingBack.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGivingBack"]["data"]["attributes"]["SEO"]')}},3,"4m_0"),i(s1,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"4m_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"4m_2")},u1=b(g(o1,"s_NbmekxDi7Vw")),c1=({resolveValue:t})=>{const a=t(_s).pageData.data.pageGivingBack.data.attributes.SEO;return V(a)},d1=Object.freeze(Object.defineProperty({__proto__:null,default:u1,head:c1,usePageData:_s},Symbol.toStringTag,{value:"Module"})),p1=t=>{const e=t.data.Logo.data.attributes;return n("div",null,{class:"min-h-screen w-full flex flex-col items-center"},[i(A,{width:"200px",height:"80px",media:e,clasN:"pt-5 px-5",[s]:{width:s,height:s,clasN:s}},3,"mB_0"),i(os,{get parData(){return t.data.SectionHead},[s]:{parData:u(a=>a.data.SectionHead,[t],'p0.data["SectionHead"]')}},3,"mB_1"),i(Cl,{get speedList(){return t.data.SpeedBullets},[s]:{speedList:u(a=>a.data.SpeedBullets,[t],'p0.data["SpeedBullets"]')}},3,"mB_2"),i(us,{get parData(){return t.data.SectionRating},[s]:{parData:u(a=>a.data.SectionRating,[t],'p0.data["SectionRating"]')}},3,"mB_3"),n("div",null,{class:"w-full bg-white  flex md:flex-row flex-col items-center justify-between"},[n("div",null,{class:" flex flex-row gap-5 p-1"},t.data.Footer&&t.data.Footer.map((a,l)=>i(Rt,{get href(){return a.Link},class:" hover:text-primary-blue/60 text-primary-blue font-bold",children:S(a,"Text"),[s]:{href:h(a,"Link"),class:s}},1,l)),1,null),n("div",null,{class:"text-primary-blue text-center"},"© 2024 Rural Telecommunications of America, Inc. All rights reserved.",3,null)],1,null)],1,"mB_4")},f1=b(g(p1,"s_TtLrO4fYqlI")),g1=t=>`query QueryLPGoldsmith {
        lpGoldsmith (locale:"${t}"){    
          data{
            attributes{
              Logo{
                ${_}
              }

              SectionHead{
                Title
                Subtitle
                Paragraph
                Logo{
                    ${_}
                }
                Media{
                    ${_}
                }
                Buttons{
                  Text
                  Link
                }
              }

              SpeedBullets{
                Title
                Text
              }

              SectionRating{
                Title
                Subtitle
                Paragraph
                Buttons{
                  Text
                  Link
                }
                Media{
                    ${_}
                }
              }
              
              Footer{
                Text
                Link
              }
            ${H}
            }
          }
        }
        
      }`,x1=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(g1,e)},ws=R(g(x1,"s_VvrWzA20lF0")),m1=()=>{const t=ws();return i(G,{children:i(F,{get data(){return t.value.layoutData},showMenus:!1,showHeader:!1,children:i(f1,{get data(){return t.value.pageData.data.lpGoldsmith.data.attributes},[s]:{data:u(e=>e.value.pageData.data.lpGoldsmith.data.attributes,[t],'p0.value["pageData"]["data"]["lpGoldsmith"]["data"]["attributes"]')}},3,"BY_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showMenus:s,showHeader:s}},1,"BY_1")},1,"BY_2")},h1=b(g(m1,"s_WHj3dLp4igs")),b1=({resolveValue:t})=>{const a=t(ws).pageData.data.lpGoldsmith.data.attributes.SEO;return V(a)},$1=Object.freeze(Object.defineProperty({__proto__:null,default:h1,head:b1,usePageData:ws},Symbol.toStringTag,{value:"Module"})),v1=t=>n("div",null,{class:"w-full flex flex-row items-center justify-center"},n("div",null,{class:"px-4 py-2 md:px-10 md:py-2 max-w-[1200px]"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(M,{get text(){return t.data.TextContent},classN:" text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"YK_0")],1,null),1,"YK_1"),y1=b(g(v1,"s_kXmVcxHZMiE")),_1=t=>`query QueryInternetTransparency {
        pageTransparency(locale:"${t}"){    
          ${aa}
          ${H}
            }
          }
        }
      }`,w1=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(_1,e)},Ss=R(g(w1,"s_6Qn0TGy9U7E")),S1=()=>{const t=Ss(),e=t.value.pageData.data.pageTransparency.data.attributes.Content;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(y1,{data:e},3,"7b_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"7b_1")},1,"7b_2")},T1=b(g(S1,"s_lgP2BOg1kq8")),D1=({resolveValue:t})=>{const a=t(Ss).pageData.data.pageTransparency.data.attributes.SEO;return V(a)},P1=Object.freeze(Object.defineProperty({__proto__:null,default:T1,head:D1,usePageData:Ss},Symbol.toStringTag,{value:"Module"})),k1=t=>`query QueryLeadershipTeam{
        pageLeadershipT(locale:"${t}"){
          data{
            attributes{
              ${Zi}
              ${H}
              }
            }
          }
        }`,L1=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(k1,e)},Ts=R(g(L1,"s_ZvTItzMmB40")),C1=()=>{const t=Ts(),e=t.value.pageData.data.pageLeadershipT.data.attributes;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageLeadershipT.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageLeadershipT.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageLeadershipT"]["data"]["attributes"]["SEO"]')}},3,"cW_0"),i(oo,{data:e},3,"cW_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"cW_2")},1,"cW_3")},M1=b(g(C1,"s_VJGz1Q1nMWA")),j1=({resolveValue:t})=>{const a=t(Ts).pageData.data.pageLeadershipT.data.attributes.SEO;return V(a)},A1=Object.freeze(Object.defineProperty({__proto__:null,default:M1,head:j1,usePageData:Ts},Symbol.toStringTag,{value:"Module"})),E1=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),n("h2",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[1].Text,[t],'p0.data["Titles"][1]["Text"]'),3,null),i(M,{get text(){return t.data.TextContent},classN:" text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"tP_0")],1,"tP_1"),N1=b(g(E1,"s_l6pybhQ4d3A")),I1=t=>`query QueryLegal {
        pageLegal(locale:"${t}"){    
          ${aa}
          ${H}
            }
          }
        }
      }`,B1=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(I1,e)},Ds=R(g(B1,"s_p9UoBCtfUPo")),O1=()=>{const t=Ds(),e=t.value.pageData.data.pageLegal.data.attributes.Content;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(N1,{data:e},3,"W8_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"W8_1")},1,"W8_2")},q1=b(g(O1,"s_DAHSW75A6dQ")),R1=({resolveValue:t})=>{const a=t(Ds).pageData.data.pageLegal.data.attributes.SEO;return V(a)},z1=Object.freeze(Object.defineProperty({__proto__:null,default:q1,head:R1,usePageData:Ds},Symbol.toStringTag,{value:"Module"})),F1=t=>{const e=t.data.pageLocWeather.data.attributes,a=l=>`https://raw.githubusercontent.com/visualcrossing/WeatherIcons/main/PNG/1st%20Set%20-%20Color/${l}.png`;return n("div",null,{class:"flex flex-wrap items-center justify-center gap-8 px-8 py-8 text-white",onClick$:B("s_VJdTV7fBj8k")},t.data.weatherData.data.map((l,r)=>n("div",null,{class:"relative h-[350px] w-[600px] max-[1200px]:h-[280px] max-[1200px]:w-[500px]"},[n("div",null,{class:"relative flex h-full w-[50%] flex-col justify-between overflow-hidden rounded-[30px] px-4 py-8 "},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-[6] h-full w-full"},i(A,{clasN:"h-[400px]",width:"2622",height:"3086",get media(){return e.LocTables.find(o=>o.Location===l.city).LocationPic.data.attributes},[s]:{clasN:s,width:s,height:s,media:h(e.LocTables.find(o=>o.Location===l.city).LocationPic.data,"attributes")}},3,"tT_0"),1,null),n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-[5] h-full w-full bg-black opacity-30"},null,3,null),n("div",null,{class:"flex flex-col"},[n("span",null,{class:"text-[20px] font-[700]",onClick$:B("s_K3eGiPS50Ks")},Hl(l.data.days[0].datetime).split(", ")[0],1,null),n("div",null,{class:"mt-2 flex items-center gap-3"},[i(Rn,{class:"text-[15px] text-white",[s]:{class:s}},3,"tT_1"),n("span",null,{class:"text-[17px] font-[600] max-[1200px]:text-[15px]"},S(l,"city"),1,null)],1,null)],1,null),n("div",null,null,[n("span",null,{class:"text-[18px] font-[700]"},S(l.data.days[0],"conditions"),1,null),n("img",{src:a(l.data.days[0].icon),alt:`icon-${l.data.days[0].icon}`,title:`icon-${l.data.days[0].icon}`},{width:"50",height:"50"},null,3,null)],1,null),n("div",null,{class:"flex w-full justify-evenly"},[n("div",null,{class:"flex flex-col items-center"},[n("span",null,{class:"text-[14px]"},"Min",3,null),n("span",null,{class:"text-[28px] font-[700] max-[1200px]:text-[20px]"},[S(l.data.days[0],"tempmin"),"°F"],1,null)],1,null),n("div",null,{class:"flex flex-col items-center"},[n("span",null,{class:"text-[14px]"},"Max",3,null),n("span",null,{class:"text-[28px] font-[700] max-[1200px]:text-[20px]"},[S(l.data.days[0],"tempmin"),"°F"],1,null)],1,null)],1,null)],1,null),n("div",null,{class:"absolute bottom-3 right-0 top-3 -z-[7] flex w-[56%] flex-col gap-1 rounded-[30px] bg-[#172c4b] py-8 pl-14 pr-6 text-[17px] max-[1200px]:text-[13px]"},[n("div",null,{class:"flex justify-between font-[700] "},[n("span",null,null,"PRECIPITATION",3,null),n("span",null,{class:"font-[300]"},[S(l.data.days[0],"precipprob"),"%"],1,null)],1,null),n("div",null,{class:"flex justify-between font-[700]"},[n("span",null,null,"HUMIDITY",3,null),n("span",null,{class:"font-[300]"},[S(l.data.days[0],"humidity"),"%"],1,null)],1,null),n("div",null,{class:"flex justify-between font-[700]"},[n("span",null,null,"WIND",3,null),n("span",null,{class:"font-[300]"},[S(l.data.days[0],"windspeed")," mph"],1,null)],1,null),n("div",null,{class:"mt-6 grid grid-cols-3 justify-center gap-1"},[1,2,3].map(o=>n("div",null,{class:"flex flex-col items-center gap-1 text-[12px] max-[1200px]:text-[9px]"},[n("img",{src:a(l.data.days[o].icon),alt:`icon-${l.data.days[o].icon}`,title:`icon-${l.data.days[o].icon}`},{width:"30",height:"30"},null,3,null),n("span",null,{class:""},Hl(l.data.days[o].datetime).split(", ")[0],1,null),n("span",null,{class:"font-[600]"},[S(l.data.days[o],"tempmax"),"°F"],1,null),n("span",null,{class:"font-[600]"},[S(l.data.days[o],"tempmin"),"°F"],1,null)],1,o)),1,null)],1,null)],1,r)),1,"tT_2")},Q1=b(g(F1,"s_Eyqu8EYnqHs")),G1=t=>`query locWeather{
        pageLocWeather(locale:"${t}"){
          data{
            attributes{
              LocTables{
                Location
                LocationPic{
                  ${_}
                }
              }
              ${H}
            }
          }
        }
      }`,H1=async t=>{const e=t.params.lang==""?"en":"es-419",a=await Q(G1,e),l={status:"error",data:[]};for(const r of a.pageData.data.pageLocWeather.data.attributes.LocTables){const o=r.Location,c=await fetch(`https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${o}/next7days?unitGroup=us&include=days%2Ccurrent&key=J8MMBMZC9DTQTVGHBPNEWPPGS&contentType=json`);if(c.ok){const p=await c.json();l.data.push({city:o,data:p})}}return{...a,weatherData:l}},Ps=R(g(H1,"s_gwWti8fe82E")),V1=()=>{const t=Ps();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageLocWeather.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageLocWeather.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageLocWeather"]["data"]["attributes"]["SEO"]')}},3,"rD_0"),i(Q1,{get data(){return{pageLocWeather:t.value.pageData.data.pageLocWeather,weatherData:t.value.weatherData}},[s]:{data:u(e=>({pageLocWeather:e.value.pageData.data.pageLocWeather,weatherData:e.value.weatherData}),[t],'{pageLocWeather:p0.value["pageData"]["data"]["pageLocWeather"],weatherData:p0.value["weatherData"]}')}},3,"rD_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"rD_2")},W1=b(g(V1,"s_VS5ugbSZKZs")),U1=({resolveValue:t})=>{const a=t(Ps).pageData.data.pageLocWeather.data.attributes.SEO;return V(a)},Y1=Object.freeze(Object.defineProperty({__proto__:null,default:W1,head:U1,usePageData:Ps},Symbol.toStringTag,{value:"Module"})),Z1=t=>{var o;const a=(o=rt().prevUrl)==null?void 0:o.pathname.includes("/es/"),l=t.data.pageNews.data.attributes,r=l.Posts.data[0].attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(Zn,{post:r,isES:a},3,"MY_0"),n("div",null,{class:"my-4"},null,3,null),i(Kn,{get posts(){return l.Posts.data},loadSize:3,type:"News",[s]:{posts:h(l.Posts,"data"),loadSize:s,type:s}},3,"MY_1")],1,"MY_2")},K1=b(g(Z1,"s_d8TgHnXz650")),J1=t=>` query QueryNews {
        pageNews(locale:"${t}"){    
          data{
          attributes{
            Posts(sort: "Date:desc", pagination: { limit: 100 }){
                data{
                  attributes{
                    Title
                    Date
                    Cover{
                      ${_}
                    }
                    Description
                    VideoLink
                    Gallery{
                      ${_}
                    }
                    Slug
                  }
                }
              }
            SugPages{
              Title
              Pages{
              Title
              Link
              Picture{
                ${_}
              }
              }
            }
            ${H}
          }
        }
        }
      }`,X1=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(J1,e)},ks=R(g(X1,"s_HdPbxCOsb5s")),t$=()=>{const t=ks();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageNews.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageNews.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageNews"]["data"]["attributes"]["SEO"]')}},3,"7N_0"),i(K1,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"7N_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"7N_2")},e$=b(g(t$,"s_Afg1iFacoB8")),a$=({resolveValue:t})=>{const a=t(ks).pageData.data.pageNews.data.attributes.SEO;return V(a)},l$=Object.freeze(Object.defineProperty({__proto__:null,default:e$,head:a$,usePageData:ks},Symbol.toStringTag,{value:"Module"})),n$=t=>n("div",null,{class:"flex flex-col items-center text-primary-blue"},[n("h2",null,{class:"px-4 md:px-8 text-center font-semibold text-secondary-red text-2xl md:text-3xl"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),n("h3",null,{class:"px-4 md:px-8 text-center text-xl md:text-2xl"},u(e=>e.data.Titles[1].Text,[t],'p0.data["Titles"][1]["Text"]'),3,null),n("div",null,{class:"flex px-4 md:px-8 mt-5 flex-wrap items-center justify-center"},[n("div",null,{class:"flex flex-col w-full lg:w-3/5 mx-5"},[n("h3",null,{class:"font-bold my-4 text-2xl md:text-4xl text-center"},u(e=>e.data.CommitmentPar.Title,[t],'p0.data["CommitmentPar"]["Title"]'),3,null),i(M,{get text(){return t.data.CommitmentPar.Paragraph},classN:"text-justify",[s]:{text:u(e=>e.data.CommitmentPar.Paragraph,[t],'p0.data["CommitmentPar"]["Paragraph"]'),classN:s}},3,"aa_0")],1,null),i(ha,{height:"h-[350px]",width:"w-[350px]",get media(){return t.data.CommitmentPar.Media.data.attributes},[s]:{height:s,width:s,media:u(e=>e.data.CommitmentPar.Media.data.attributes,[t],'p0.data["CommitmentPar"]["Media"]["data"]["attributes"]')}},3,"aa_1")],1,null),n("div",null,{class:"flex px-8 mt-8 flex-col md:flex-row justify-center md:justify-around items-center md:items-start"},t.data.ColumnsPar.map((e,a)=>n("div",null,{class:"flex flex-col my-5 w-full md:w-1/2 justify-center items-center"},[n("h2",null,{class:"font-bold  text-2xl md:text-4xl text-center"},S(e,"Title"),1,null),i(M,{get text(){return e.Paragraph},[s]:{text:h(e,"Paragraph")}},3,"aa_2")],1,a)),1,null)],1,"aa_3"),s$=b(g(n$,"s_RH3prNj9z7A")),r$=t=>`query QueryOurStory{
        pageOurStory(locale:"${t}"){
          data{
            attributes{
              Titles{
                Text
              }
              CommitmentPar{
                Title
                Paragraph
                Media{
                ${_}
                }
              }
              
              ColumnsPar{
                Title
                Paragraph
              }
              
              SponsorshipsTitle
              Sponsorships{
                Title
                Subtitle
                Paragraph
                Media{
                ${_}
                }
                Buttons{
                  Text
                  Link
                }
              }
              ${H}
             
            }
          }
        }
      }`,i$=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(r$,e)},Ls=R(g(i$,"s_I9YCjFVOHNE")),o$=()=>{const t=Ls(),e=t.value.pageData.data.pageOurStory.data.attributes;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return e.SEO},[s]:{SEOdata:h(e,"SEO")}},3,"CH_0"),i(s$,{data:e},3,"CH_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"CH_2")},1,"CH_3")},u$=b(g(o$,"s_ONSPkGdkwcs")),c$=({resolveValue:t})=>{const a=t(Ls).pageData.data.pageOurStory.data.attributes.SEO;return V(a)},d$=Object.freeze(Object.defineProperty({__proto__:null,default:u$,head:c$,usePageData:Ls},Symbol.toStringTag,{value:"Module"})),p$=t=>{const e=t.data.Logo.data.attributes,a=t.data.Media.data.attributes;return n("div",null,{class:"flex max-w-[1200px] items-center justify-center self-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-4 px-10 min-[800px]:w-[70%]"},[n("div",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(l=>l.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"max-w-[470px]"},i(A,{media:e,width:1230,height:230,[s]:{width:s,height:s}},3,"Y3_0"),1,null),n("div",null,null,i(M,{classN:"max-sm:text-[15px] text-[18px] text-[#2E5899]",get text(){return t.data.Paragraph},[s]:{classN:s,text:u(l=>l.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"Y3_1"),1,null)],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(A,{media:a,width:1e3,height:1e3,[s]:{width:s,height:s}},3,"Y3_2"),1,null)],1,"Y3_3")},f$=b(g(p$,"s_G8eOcGEKYk4")),g$=t=>{const e=t.data.pagePortability.data.attributes.PortabilityActs,a=t.data.pagePortability.data.attributes.Introduction;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(f$,{data:a},3,"C7_0"),i(We,{data:e},3,"C7_1")],1,"C7_2")},x$=b(g(g$,"s_OvPpWmexBMU")),m$=t=>`
    query QueryPortability{
        pagePortability(locale:"${t}"){    
          data{
            attributes{
              Introduction{
                Title
                Subtitle
                Logo{
                ${_}
                }
                Paragraph
                Media{
                ${_}
                }
              }
              
              IntroductionBG{
                ${_}
              }
      
              PortabilityActs{
                Title
                Subtitle
                Buttons{
                  Text
                  Link
                }
                Logo{
                ${_}
                }
                Paragraph
                Media{
                ${_}
                }
              }
              ${H}
            }
          }
        }
      }
    `,h$=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(m$,e)},Cs=R(g(h$,"s_DV97RmVctT4")),b$=()=>{const t=Cs();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pagePortability.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pagePortability.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pagePortability"]["data"]["attributes"]["SEO"]')}},3,"eB_0"),i(x$,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"eB_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"eB_2")},$$=b(g(b$,"s_LbhuqOuteuA")),v$=({resolveValue:t})=>{const a=t(Cs).pageData.data.pagePortability.data.attributes.SEO;return V(a)},y$=Object.freeze(Object.defineProperty({__proto__:null,default:$$,head:v$,usePageData:Cs},Symbol.toStringTag,{value:"Module"})),fo=new Date,_$=fo.toISOString().substring(0,10),w$=fo.toISOString().substring(11,19),go=t=>`
    query QueryHome{
  pageHome(locale:"${t}"){
    data{
      attributes{
        
        VideoBGDesktop{
          ${_}
        }
        VideoBGMobile{
          ${_}
        }
        HeroCarSlideZS{
          Video{
            ${_}
          }
          Description
          Logo{
            ${_}
          }
          RaceDate
        }

        HeroCarSlides{
          Title
          Subtitle
          Logo{
          ${_}
          }
          Paragraph
          Media{
          ${_}
          }
          Buttons{
            Text
            Link
          }
        }
        HeroForm{
          Title
          ActionButton{
            Text
            Link
          }
        }

        Testimonials{
          Name
          Text
          Rating
        }

        ProsPar{
          Title
          Paragraph
        }

        ProsPicture{
          ${_}
        }
        ProsBackground{
          ${_}
        }
        ParACP{
          Title
          Subtitle
          Paragraph
          Logo{
          ${_}
          }
          Media{
          ${_}
          }
          Buttons{
            Text
            Link
          }
        }
        ParGFIPlans{
          Title
          Paragraph
          Disclaimer{
            Title
            Text
            Caption
            Icon{
          ${_}
            }
          }
          Table{
            ColumnOne
            ColumnTwo
            ColumnThree
          }

        }
        ParGFServices{
          Title
          Subtitle
          Logo{
          ${_}
          }
          Paragraph
          Media{
          ${_}
          }
          Buttons{
            Text
            Link
          }
        }
        SugsPages{
          Title
          Paragraph
          Media{
          ${_}
          }
          Buttons{
            Text
            Link
          }
        }
        SugsPagesBG{
          ${_}
        }
        ${H}
      }
    }
  }
  zaneRaces (
    filters: {RaceDay: {gte: "${_$}"}, RaceTime: {gte: "${w$}"}}, 
    locale:"en", 
    sort: "RaceDate"
    pagination: {limit: 1}) {
    data {
      attributes {
        Video {
          ${_}
        }
        Logo {
          ${_}
        }
        Description
        RaceDay
        RaceTime
      }
    }
  }
  sectionProsRta(locale:"${t}") {
    data {
      attributes {
        Pros {
          Icon {
            ${_}
          }
          Title
          Text
          Caption
        }
      }
    }
  }

  generalPromoBanner(locale:"${t}"){
        data{
          attributes{
            Title
            Caption
            Display            
          }
        }
      }

  generalMarquee(locale:"${t}"){
      data{
        attributes{
          Text
          Button{
            Text
            Link
          }
          Display            
        }
      }
    }
        
  sectionNetwork {
    data {
      attributes {
        Map {
          MapPicture {
            ${_}
          }
        }
      }
    }
  }
}
`,S$=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang;return await Q(go,e)},T$=R(g(S$,"s_MfWlD1sVVR8")),D$=()=>n("div",null,null,"a",3,"yK_0"),P$=b(g(D$,"s_S2euYekMMCk")),k$=Object.freeze(Object.defineProperty({__proto__:null,default:P$,usePageData:T$},Symbol.toStringTag,{value:"Module"})),L$=t=>n("div",null,{class:"p-6"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(M,{get text(){return t.data.TextContent},classN:"markdownTitle markdownHyper text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"Vp_0")],1,"Vp_1"),C$=b(g(L$,"s_m0xHvviU9eM")),M$=t=>`
query QueryPrivacyP {
  pagePrivacyP(locale:"${t}"){    
    ${aa}
    ${H}
      }
    }
  }
}
`,j$=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(M$,e)},Ms=R(g(j$,"s_010w2sLh1OQ")),A$=()=>{const t=Ms(),e=t.value.pageData.data.pagePrivacyP.data.attributes.Content;return i(F,{get data(){return t.value.layoutData},children:i(C$,{data:e},3,"bX_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"bX_1")},E$=b(g(A$,"s_vRJXLmWn290")),N$=({resolveValue:t})=>{const a=t(Ms).pageData.data.pagePrivacyP.data.attributes.SEO;return V(a)},I$=Object.freeze(Object.defineProperty({__proto__:null,default:E$,head:N$,usePageData:Ms},Symbol.toStringTag,{value:"Module"})),B$=t=>{const e=t.data.Logo.data.attributes;return n("div",null,{class:"min-h-screen w-full flex flex-col items-center"},[i(A,{width:"200px",height:"80px",media:e,clasN:"pt-5 px-5",[s]:{width:s,height:s,clasN:s}},3,"Hd_0"),i(os,{get parData(){return t.data.SectionHead},[s]:{parData:u(a=>a.data.SectionHead,[t],'p0.data["SectionHead"]')}},3,"Hd_1"),i(Cl,{get speedList(){return t.data.SpeedBullets},[s]:{speedList:u(a=>a.data.SpeedBullets,[t],'p0.data["SpeedBullets"]')}},3,"Hd_2"),i(us,{get parData(){return t.data.SectionRating},[s]:{parData:u(a=>a.data.SectionRating,[t],'p0.data["SectionRating"]')}},3,"Hd_3"),n("div",null,{class:"w-full bg-white  flex md:flex-row flex-col items-center justify-between"},[n("div",null,{class:" flex flex-row gap-5 p-1"},t.data.Footer&&t.data.Footer.map((a,l)=>i(Rt,{get href(){return a.Link},class:" hover:text-primary-blue/60 text-primary-blue font-bold",children:S(a,"Text"),[s]:{href:h(a,"Link"),class:s}},1,l)),1,null),n("div",null,{class:"text-primary-blue text-center"},"© 2024 Rural Telecommunications of America, Inc. All rights reserved.",3,null)],1,null)],1,"Hd_4")},O$=b(g(B$,"s_GrSLBBZP0DM")),q$=t=>`query QueryLPNeighborhood {
        lpNeighborhood (locale:"${t}"){    
          data{
            attributes{
              Logo{
                ${_}
              }

              SectionHead{
                Title
                Subtitle
                Paragraph
                Logo{
                    ${_}
                }
                Media{
                    ${_}
                }
                Buttons{
                  Text
                  Link
                }
              }

              SpeedBullets{
                Title
                Text
              }

              SectionRating{
                Title
                Subtitle
                Paragraph
                Buttons{
                  Text
                  Link
                }
                Media{
                    ${_}
                }
              }
              
              Footer{
                Text
                Link
              }
            ${H}
            }
          }
        }
        
      }`,R$=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(q$,e)},js=R(g(R$,"s_6ulhbKSeU34")),z$=()=>{const t=js();return i(G,{children:i(F,{get data(){return t.value.layoutData},showMenus:!1,showHeader:!1,children:i(O$,{get data(){return t.value.pageData.data.lpNeighborhood.data.attributes},[s]:{data:u(e=>e.value.pageData.data.lpNeighborhood.data.attributes,[t],'p0.value["pageData"]["data"]["lpNeighborhood"]["data"]["attributes"]')}},3,"iI_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showMenus:s,showHeader:s}},1,"iI_1")},1,"iI_2")},F$=b(g(z$,"s_GygFChjqq7g")),Q$=({resolveValue:t})=>{const a=t(js).pageData.data.lpNeighborhood.data.attributes.SEO;return V(a)},G$=Object.freeze(Object.defineProperty({__proto__:null,default:F$,head:Q$,usePageData:js},Symbol.toStringTag,{value:"Module"})),H$=t=>n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"min-h-[200px] w-full bg-gradient-to-br from-primary-light-blue to-[#23477f] !text-white"},i(Ve,{get data(){return t.data},color:"white",reverse:!0,backgroundColor:"primary-blue",hasPricing:!1,[s]:{data:u(e=>e.data,[t],"p0.data"),color:s,reverse:s,backgroundColor:s,hasPricing:s}},3,"7j_0"),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"7j_1"),V$=b(g(H$,"s_05kJ0dE4eLY")),W$=t=>{const e=t.data.pageReferralP.data.attributes,a=e.Steps.Bullets.map(l=>l.Text);return n("div",null,null,[i(V$,{get data(){return e.RefInfo},[s]:{data:h(e,"RefInfo")}},3,"Kl_0"),n("div",null,{class:"flex items-center justify-center px-8 py-8"},n("div",null,{class:" max-w-[1400px] "},[n("h4",null,{class:"mb-6 text-center text-[20px] font-[500] leading-6 text-primary-blue"},S(e,"StepsIntro"),1,null),n("h3",null,{class:"mb-6 text-center text-[42px] font-[700] leading-10 text-secondary-red"},S(e.Steps,"Title"),1,null),n("div",null,{class:"max-[799px]:hidden"},i(cl,{steps:a,direction:"vertical",align:"center",[s]:{direction:s,align:s}},3,"Kl_1"),1,null),n("div",null,{class:"min-[800px]:hidden"},i(cl,{steps:a,direction:"vertical",align:"start",[s]:{direction:s,align:s}},3,"Kl_2"),1,null)],1,null),1,null)],1,"Kl_3")},U$=b(g(W$,"s_lTuY9A29ePc")),Y$=t=>`
  query QueryReferralProgram{
    pageReferralP(locale:"${t}"){
      data{
        attributes{
            RefInfo{
          Title
          Subtitle
          Paragraph
          Media{
            ${_}
          }
        }
          StepsIntro
          Steps{
            Title
            Bullets{
              Text
              Caption
            }
          }
          ${H}
        }
      }
    }
  }
    `,Z$=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Y$,e)},As=R(g(Z$,"s_xJNMjIe9Xxc")),K$=()=>{const t=As();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageReferralP.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageReferralP.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageReferralP"]["data"]["attributes"]["SEO"]')}},3,"Mu_0"),i(U$,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Mu_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Mu_2")},J$=b(g(K$,"s_jMvbzO8YesI")),X$=({resolveValue:t})=>{const a=t(As).pageData.data.pageReferralP.data.attributes.SEO;return V(a)},tv=Object.freeze(Object.defineProperty({__proto__:null,default:J$,head:X$,usePageData:As},Symbol.toStringTag,{value:"Module"})),ev=t=>{const e=t.data.pageResidential.data.attributes.Services;return n("div",null,null,i(We,{data:e},3,"jS_0"),1,"jS_1")},av=b(g(ev,"s_2a10udsh6KM")),lv=t=>`
  query QueryResidential {
    pageResidential(locale:"${t}"){    
      data{
        attributes{
          Services{
            Logo{
            ${_}
            }
            Media{
            ${_}
            }
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
          ${H}
        }
      }
    }
  }
    `,nv=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(lv,e)},Es=R(g(nv,"s_LcXJ0iBV25I")),sv=()=>{const t=Es();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageResidential.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageResidential.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageResidential"]["data"]["attributes"]["SEO"]')}},3,"O0_0"),i(av,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"O0_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"O0_2")},rv=b(g(sv,"s_2tXslNmi0k4")),iv=({resolveValue:t})=>{const a=t(Es).pageData.data.pageResidential.data.attributes.SEO;return V(a)},ov=Object.freeze(Object.defineProperty({__proto__:null,default:rv,head:iv,usePageData:Es},Symbol.toStringTag,{value:"Module"})),uv=t=>{const e=t.broadbandlabelnternet.sort((a,l)=>a.values.name[0].data.includes("ESSENTIALgig")&&!l.values.name[0].data.includes("ESSENTIALgig")?-1:!a.values.name[0].data.includes("ESSENTIALgig")&&l.values.name[0].data.includes("ESSENTIALgig")?1:0);return n("div",null,{class:"flex flex-col items-center justify-around"},[n("h1",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(a=>a.pageData.data.attributes.Title,[t],'p0.pageData["data"]["attributes"]["Title"]'),3,null),n("div",null,{class:"w-full flex-col gap-2 flex px-4"},[n("div",null,{class:"my-8 max-w-[350px] sm:max-w-[500px] mx-auto"},n("img",{src:gt(t.pageData.data.attributes.Services[0].Picture.data.attributes.url)},{width:1230,height:229,alt:u(a=>a.pageData.data.attributes.Services[0].Picture.data.attributes.alternativeText,[t],'p0.pageData["data"]["attributes"]["Services"][0]["Picture"]["data"]["attributes"]["alternativeText"]')},null,3,null),1,null),n("div",null,{class:"flex w-full overflow-x-auto gap-1 flex-row justify-start mb-4 pb-4 px-4",style:"scrollbar-width: thin; scrollbar-color: #2E5698 #f1f1f1;"},e.map((a,l)=>{var r,o,c,p,d,f,x,m,$,y,P,w,D,v,L,k,T,I,E,N,j,O,W,K,Y,it,dt,nt,at,pt,It,Bt,Ct,Wt,Ut,Yt,Zt,Kt,Jt,Xt,te,ee,ae,le,ne,se,re,ie,oe,ue,ce,de,pe,fe,ge,xe,me,he,be,$e,ve,ye,_e,we,Se,Te,De,Pe,ke,Le,Ce,Me,je,Ue,ba,Hs,Vs;return i(Kl,{tier_plan_name:"NULL",connection_type:((c=(o=(r=a.values)==null?void 0:r.connection_type)==null?void 0:o[0])==null?void 0:c.data)||"N/A",monthly_price:((d=(p=a.values)==null?void 0:p.monthly_price)==null?void 0:d[0].data)||((x=(f=a.values)==null?void 0:f.price)==null?void 0:x[0].data[0].amount),get service_plan_name(){return a.values.name[0].data},intro_rate:((y=($=(m=a.values)==null?void 0:m.intro_rate)==null?void 0:$[0])==null?void 0:y.data)||"No",intro_rate_price:((D=(w=(P=a.values)==null?void 0:P.intro_rate_price)==null?void 0:w[0])==null?void 0:D.data)||"0.00",intro_rate_time:((k=(L=(v=a.values)==null?void 0:v.intro_rate_time)==null?void 0:L[0])==null?void 0:k.data)||"N/A",contract_req:((E=(I=(T=a.values)==null?void 0:T.contract_req)==null?void 0:I[0])==null?void 0:E.data)||"No",contract_time:((O=(j=(N=a.values)==null?void 0:N.contract_time)==null?void 0:j[0])==null?void 0:O.data)||"N/A",contract_terms_url:((Y=(K=(W=a.values)==null?void 0:W.contract_terms_url)==null?void 0:K[0])==null?void 0:Y.data)||"",early_termination_fee:((nt=(dt=(it=a.values)==null?void 0:it.early_termination_fee)==null?void 0:dt[0])==null?void 0:nt.data)||"0.00",single_purchase_fee_descr:((It=(pt=(at=a.values)==null?void 0:at.single_purchase_fee_descr)==null?void 0:pt[0])==null?void 0:It.data)||"",single_purchase_fees:((Wt=(Ct=(Bt=a.values)==null?void 0:Bt.single_purchase_fees)==null?void 0:Ct[0])==null?void 0:Wt.data)||"",monthly_provider_fee_descr:((Zt=(Yt=(Ut=a.values)==null?void 0:Ut.monthly_provider_fee_descr)==null?void 0:Yt[0])==null?void 0:Zt.data)||"",monthly_provider_fee:((Xt=(Jt=(Kt=a.values)==null?void 0:Kt.monthly_provider_fee)==null?void 0:Jt[0])==null?void 0:Xt.data)||"",tax:((ae=(ee=(te=a.values)==null?void 0:te.tax)==null?void 0:ee[0])==null?void 0:ae.data)||"Varies",bundle_discounts_url:((se=(ne=(le=a.values)==null?void 0:le.bundle_discounts_url)==null?void 0:ne[0])==null?void 0:se.data)||"",typical_download_speed:((re=a.values.typical_download_speed)==null?void 0:re[0].data)||"N/A",typical_upload_speed:((ie=a.values.typical_upload_speed)==null?void 0:ie[0].data)||"N/A",typical_latency:((ce=(ue=(oe=a.values)==null?void 0:oe.typical_latency)==null?void 0:ue[0])==null?void 0:ce.data)||"N/A",unique_plan_id:((pe=(de=a.values.unique_plan_id)==null?void 0:de[0])==null?void 0:pe.data)||"N/A",monthly_data_allow:((xe=(ge=(fe=a.values)==null?void 0:fe.monthly_data_allow)==null?void 0:ge[0])==null?void 0:xe.data)||"Unlimited",over_usage_data_price:((be=(he=(me=a.values)==null?void 0:me.over_usage_data_price)==null?void 0:he[0])==null?void 0:be.data)||"N/A",additional_data_increment:((ye=(ve=($e=a.values)==null?void 0:$e.additional_data_increment)==null?void 0:ve[0])==null?void 0:ye.data)||"N/A",data_allowance_policy_url:((Se=(we=(_e=a.values)==null?void 0:_e.data_allowance_policy_url)==null?void 0:we[0])==null?void 0:Se.data)||"",network_management_policy_url:((Pe=(De=(Te=a.values)==null?void 0:Te.network_management_policy_url)==null?void 0:De[0])==null?void 0:Pe.data)||"",privacy_policy_url:((Ce=(Le=(ke=a.values)==null?void 0:ke.privacy_policy_url)==null?void 0:Le[0])==null?void 0:Ce.data)||"",customer_support_phone:((Ue=(je=(Me=a.values)==null?void 0:Me.customer_support_phone)==null?void 0:je[0])==null?void 0:Ue.data)||"",customer_support_web:((Vs=(Hs=(ba=a.values)==null?void 0:ba.customer_support_web)==null?void 0:Hs[0])==null?void 0:Vs.data)||"",isVoice:!1,[s]:{tier_plan_name:s,service_plan_name:h(a.values.name[0],"data"),isVoice:s}},3,`Broadband-Internet}-${l}`)}),1,null)],1,null),n("div",null,{class:"w-full flex-col gap-2 flex px-4"},[n("div",null,{class:"my-8 max-w-[350px] sm:max-w-[500px] mx-auto"},n("img",{src:gt(t.pageData.data.attributes.Services[1].Picture.data.attributes.url)},{width:1230,height:229,alt:u(a=>a.pageData.data.attributes.Services[1].Picture.data.attributes.alternativeText,[t],'p0.pageData["data"]["attributes"]["Services"][1]["Picture"]["data"]["attributes"]["alternativeText"]')},null,3,null),1,null),n("div",null,{class:"flex w-full overflow-x-auto gap-1 flex-row justify-start mb-4 pb-4 px-4",style:"scrollbar-width: thin; scrollbar-color: #2E5698 #f1f1f1;"},t.braodbandlabelVoice.map((a,l)=>{var r,o,c,p,d,f,x,m,$,y,P,w,D,v,L,k,T,I,E,N,j,O,W,K,Y,it,dt,nt,at,pt,It,Bt,Ct,Wt,Ut,Yt,Zt,Kt,Jt,Xt,te,ee,ae,le,ne,se,re,ie,oe,ue,ce,de,pe,fe,ge,xe,me,he,be,$e,ve,ye,_e,we,Se,Te,De,Pe,ke,Le,Ce,Me,je,Ue,ba;return i(Kl,{tier_plan_name:"NULL",connection_type:((c=(o=(r=a.values)==null?void 0:r.connection_type)==null?void 0:o[0])==null?void 0:c.data)||"N/A",monthly_price:((d=(p=a.values)==null?void 0:p.monthly_price)==null?void 0:d[0].data)||((x=(f=a.values)==null?void 0:f.price)==null?void 0:x[0].data[0].amount),get service_plan_name(){return a.values.name[0].data},intro_rate:((y=($=(m=a.values)==null?void 0:m.intro_rate)==null?void 0:$[0])==null?void 0:y.data)||"No",intro_rate_price:((D=(w=(P=a.values)==null?void 0:P.intro_rate_price)==null?void 0:w[0])==null?void 0:D.data)||"0.00",intro_rate_time:((k=(L=(v=a.values)==null?void 0:v.intro_rate_time)==null?void 0:L[0])==null?void 0:k.data)||"N/A",contract_req:((E=(I=(T=a.values)==null?void 0:T.contract_req)==null?void 0:I[0])==null?void 0:E.data)||"No",contract_time:((O=(j=(N=a.values)==null?void 0:N.contract_time)==null?void 0:j[0])==null?void 0:O.data)||"N/A",contract_terms_url:((Y=(K=(W=a.values)==null?void 0:W.contract_terms_url)==null?void 0:K[0])==null?void 0:Y.data)||"",early_termination_fee:((nt=(dt=(it=a.values)==null?void 0:it.early_termination_fee)==null?void 0:dt[0])==null?void 0:nt.data)||"0.00",single_purchase_fee_descr:((It=(pt=(at=a.values)==null?void 0:at.single_purchase_fee_descr)==null?void 0:pt[0])==null?void 0:It.data)||"",single_purchase_fees:((Wt=(Ct=(Bt=a.values)==null?void 0:Bt.single_purchase_fees)==null?void 0:Ct[0])==null?void 0:Wt.data)||"",monthly_provider_fee_descr:((Zt=(Yt=(Ut=a.values)==null?void 0:Ut.monthly_provider_fee_descr)==null?void 0:Yt[0])==null?void 0:Zt.data)||"",monthly_provider_fee:((Xt=(Jt=(Kt=a.values)==null?void 0:Kt.monthly_provider_fee)==null?void 0:Jt[0])==null?void 0:Xt.data)||"",tax:((ae=(ee=(te=a.values)==null?void 0:te.tax)==null?void 0:ee[0])==null?void 0:ae.data)||"Varies",bundle_discounts_url:((se=(ne=(le=a.values)==null?void 0:le.bundle_discounts_url)==null?void 0:ne[0])==null?void 0:se.data)||"",get typical_download_speed(){return a.download_mbps},get typical_upload_speed(){return a.upload_mbps},typical_latency:((oe=(ie=(re=a.values)==null?void 0:re.typical_latency)==null?void 0:ie[0])==null?void 0:oe.data)||"N/A",unique_plan_id:((ce=(ue=a.values.unique_plan_id)==null?void 0:ue[0])==null?void 0:ce.data)||"N/A",monthly_data_allow:((fe=(pe=(de=a.values)==null?void 0:de.monthly_data_allow)==null?void 0:pe[0])==null?void 0:fe.data)||"Unlimited",over_usage_data_price:((me=(xe=(ge=a.values)==null?void 0:ge.over_usage_data_price)==null?void 0:xe[0])==null?void 0:me.data)||"N/A",additional_data_increment:(($e=(be=(he=a.values)==null?void 0:he.additional_data_increment)==null?void 0:be[0])==null?void 0:$e.data)||"N/A",data_allowance_policy_url:((_e=(ye=(ve=a.values)==null?void 0:ve.data_allowance_policy_url)==null?void 0:ye[0])==null?void 0:_e.data)||"",network_management_policy_url:((Te=(Se=(we=a.values)==null?void 0:we.network_management_policy_url)==null?void 0:Se[0])==null?void 0:Te.data)||"",privacy_policy_url:((ke=(Pe=(De=a.values)==null?void 0:De.privacy_policy_url)==null?void 0:Pe[0])==null?void 0:ke.data)||"",customer_support_phone:((Me=(Ce=(Le=a.values)==null?void 0:Le.customer_support_phone)==null?void 0:Ce[0])==null?void 0:Me.data)||"",customer_support_web:((ba=(Ue=(je=a.values)==null?void 0:je.customer_support_web)==null?void 0:Ue[0])==null?void 0:ba.data)||"",isVoice:!0,[s]:{tier_plan_name:s,service_plan_name:h(a.values.name[0],"data"),typical_download_speed:h(a,"download_mbps"),typical_upload_speed:h(a,"upload_mbps"),isVoice:s}},3,`Broadband-Voice}-${l}`)}),1,null)],1,null)],1,"Dy_0")},cv=b(g(uv,"s_htIyo0LMbVc")),dv=t=>`query {
  pageAllBroadbandlabel (locale:"${t}"){
    data{
      attributes{
        Title
        Services{
          Picture{
            ${_}
          }
          
          Title
        }

        ${H}
        
      }
    }
  }
}`,pv=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(dv,e)},Ns=R(g(pv,"s_9IWRh3ruVPY")),fv=async()=>{const e=await(await fetch("https://cblsrvr1.rtatel.com/planbuilder/api",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({apikey:"3cBEFVR4qQleIRO2yWu0FcOCDdyZbuaU",action:"productsBroadbanLabels"})})).json(),{gigfastInternet:a,gigfastVoice:l}=e.result.reduce((r,o)=>(o.family==="gigFastInternet"&&o.values.networkType&&o.values.unique_plan_id?r.gigfastInternet.push(o):o.family==="gigFastVoice"&&o.groups.length==0&&o.values.unique_plan_id&&r.gigfastVoice.push(o),r),{gigfastInternet:[],gigfastVoice:[]});return{gigfastVoice:l,gigfastInternet:a}},xo=R(g(fv,"s_gpghoPhX4N8")),gv=()=>{const t=Ns(),e=xo(),a=e.value.gigfastVoice,l=e.value.gigfastInternet;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageAllBroadbandlabel.data.attributes.SEO},[s]:{SEOdata:u(r=>r.value.pageData.data.pageAllBroadbandlabel.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAllBroadbandlabel"]["data"]["attributes"]["SEO"]')}},3,"eH_0"),i(cv,{get pageData(){return t.value.pageData.data.pageAllBroadbandlabel},braodbandlabelVoice:a,broadbandlabelnternet:l,[s]:{pageData:u(r=>r.value.pageData.data.pageAllBroadbandlabel,[t],'p0.value["pageData"]["data"]["pageAllBroadbandlabel"]')}},3,"eH_1")],[s]:{data:u(r=>r.value.layoutData,[t],'p0.value["layoutData"]')}},1,"eH_2")},1,"eH_3")},xv=b(g(gv,"s_wWrbrx5LJeU")),mv=({resolveValue:t})=>{const a=t(Ns).pageData.data.pageAllBroadbandlabel.data.attributes.SEO;return V(a)},hv=Object.freeze(Object.defineProperty({__proto__:null,default:xv,head:mv,useAllBroadbandLabels:xo,usePageData:Ns},Symbol.toStringTag,{value:"Module"})),bv=t=>(z(),n("div",null,{class:"flex md:flex-row flex-col-reverse w-full text-center items-center justify-center md:pt-8 md:mt-10 pt-5"},[n("div",null,{class:"flex flex-col gap-5 md:px-[30px] px-[12vw] py-5"},[n("div",null,{class:"flex flex-col justify-center items-center gap-4"},[i(M,{get text(){return t.parData.Title},classN:"[&>h1]:text-[28px]",[s]:{text:u(e=>e.parData.Title,[t],'p0.parData["Title"]'),classN:s}},3,"4I_0"),i(A,{get media(){return t.parData.Logo.data.attributes},width:"200px",height:"100px",[s]:{media:u(e=>e.parData.Logo.data.attributes,[t],'p0.parData["Logo"]["data"]["attributes"]'),width:s,height:s}},3,"4I_1")],1,null),t.parData.Subtitle&&i(M,{get text(){return t.parData.Subtitle},classN:"[&>h2]:text-[18px]",[s]:{text:u(e=>e.parData.Subtitle,[t],'p0.parData["Subtitle"]'),classN:s}},3,"4I_2")],1,null),n("div",null,{class:"w-[20vw] h-[20vw] min-w-[300px] min-h-[300px] motion-safe:animate-[spin_8s_ease-in-out_infinite] flex w-[350px] h-[350px] "},i(ha,{get media(){return t.parData.Media.data.attributes},color:"bg-[#f6f307]",width:"w-[350px]",height:"h-[350px]",[s]:{media:u(e=>e.parData.Media.data.attributes,[t],'p0.parData["Media"]["data"]["attributes"]'),color:s,width:s,height:s}},3,"4I_3"),1,null)],1,"4I_4")),$v=b(g(bv,"s_xEBb0M1LJb0")),vv=t=>n("div",null,{class:"flex md:flex-row flex-col-reverse w-full text-center items-center justify-center md:py-8 py-2 "},[n("iframe",null,{src:"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1736.3807968615524!2d-96.67390131916709!3d29.49415252000683!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8643c6852e7d344b%3A0x50f1f549eff32e39!2sSheridan%20Community%20Center!5e0!3m2!1sen!2smx!4v1720731455582!5m2!1sen!2smx",class:" md:min-w-[400px] md:h-[300px] h-full rounded-2xl shadow-xl",loading:"lazy"},null,3,null),n("div",null,{class:"mx-5 "},[i(M,{get text(){return`## ${t.parData.Title}`},classN:"text-center [&>h2]:text-[36px] font-bold max-sm:text-[28px]",[s]:{text:u(e=>`## ${e.parData.Title}`,[t],'`## ${p0.parData["Title"]}`'),classN:s}},3,"zf_0"),i(M,{get text(){return`### ${t.parData.Subtitle}`},classN:"text-center text-[38px] text-secondary-red font-bold max-sm:text-[28px]",[s]:{text:u(e=>`### ${e.parData.Subtitle}`,[t],'`### ${p0.parData["Subtitle"]}`'),classN:s}},3,"zf_1"),i(M,{get text(){return t.parData.Paragraph},[s]:{text:u(e=>e.parData.Paragraph,[t],'p0.parData["Paragraph"]')}},3,"zf_2")],1,null)],1,"zf_3"),yv=b(g(vv,"s_fhIN6LW0PY4")),_v=t=>{const e=t.data.Logo.data.attributes;return n("div",null,{class:"min-h-screen w-full flex flex-col items-center"},[i(A,{width:"200px",height:"80px",media:e,clasN:"pt-5 px-5",[s]:{width:s,height:s,clasN:s}},3,"Ja_0"),i($v,{get parData(){return t.data.SectionHead},[s]:{parData:u(a=>a.data.SectionHead,[t],'p0.data["SectionHead"]')}},3,"Ja_1"),i(yv,{get parData(){return t.data.SectionRating},[s]:{parData:u(a=>a.data.SectionRating,[t],'p0.data["SectionRating"]')}},3,"Ja_2"),i(Cl,{get speedList(){return t.data.Bullets},addIcons:!0,[s]:{speedList:u(a=>a.data.Bullets,[t],'p0.data["Bullets"]'),addIcons:s}},3,"Ja_3"),n("div",null,{class:"w-full bg-white  flex md:flex-row flex-col items-center justify-between"},[n("div",null,{class:" flex flex-row gap-5 p-1"},t.data.Footer&&t.data.Footer.map((a,l)=>i(Rt,{get href(){return a.Link},class:" hover:text-primary-blue/60 text-primary-blue font-bold",children:S(a,"Text"),[s]:{href:h(a,"Link"),class:s}},1,l)),1,null),n("div",null,{class:"text-primary-blue text-center"},"© 2024 Rural Telecommunications of America, Inc. All rights reserved.",3,null)],1,null)],1,"Ja_4")},wv=b(g(_v,"s_xUsaCVca204")),Sv=t=>`query QueryLPSheridan {
        lpSheridan (locale:"${t}"){    
          data{
            attributes{
              Logo{
                ${_}
              }

              SectionHead{
                Title
                Subtitle
                Paragraph
                Logo{
                    ${_}
                }
                Media{
                    ${_}
                }
                Buttons{
                  Text
                  Link
                }
              }

             Bullets{
                Title
                Text
              }

              SectionRating{
                Title
                Subtitle
                Paragraph
                Buttons{
                  Text
                  Link
                }
                Media{
                    ${_}
                }
              }
              
              Footer{
                Text
                Link
              }
            ${H}
            }
          }
        }
        
      }`,Tv=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Sv,e)},Is=R(g(Tv,"s_FJJL67QA0KE")),Dv=()=>{const t=Is();return i(G,{children:i(F,{get data(){return t.value.layoutData},showMenus:!1,showHeader:!1,children:i(wv,{get data(){return t.value.pageData.data.lpSheridan.data.attributes},[s]:{data:u(e=>e.value.pageData.data.lpSheridan.data.attributes,[t],'p0.value["pageData"]["data"]["lpSheridan"]["data"]["attributes"]')}},3,"M0_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showMenus:s,showHeader:s}},1,"M0_1")},1,"M0_2")},Pv=b(g(Dv,"s_0tltbtVbnp0")),kv=({resolveValue:t})=>{const a=t(Is).pageData.data.lpSheridan.data.attributes.SEO;return V(a)},Lv=Object.freeze(Object.defineProperty({__proto__:null,default:Pv,head:kv,usePageData:Is},Symbol.toStringTag,{value:"Module"})),Cv=t=>{const e=t.data.data.pageSupport.data.attributes,a=t.data.data.sectionContactBoxes.data;return n("div",null,{class:"flex flex-col px-8 justify-center items-center"},[n("div",null,{class:"flex flex-row gap-3 p-3 items-center shadow-2xl rounded-full bg-primary-blue"},[n("p",null,{class:"text-white font-semibold text-md"},S(e,"WTTTitle"),1,null),i(tt,{get text(){return e.WTTButton.Text},get link(){return e.WTTButton.Link},[s]:{text:h(e.WTTButton,"Text"),link:h(e.WTTButton,"Link")}},3,"t0_0")],1,null),n("div",null,{class:"text-center"},[n("h2",null,{class:"text-3xl md:text-[40px] my-4 font-bold text-primary-blue"},S(e.Introduction,"Title"),1,null),n("h3",null,{class:"text-secondary-red my-4 text-2xl font-semibold"},S(e.Introduction,"Subtitle"),1,null),i(M,{get text(){return e.Introduction.Paragraph},[s]:{text:h(e.Introduction,"Paragraph")}},3,"t0_1")],1,null),n("div",null,{class:"flex flex-col md:flex-row my-4 w-full"},a.map((l,r)=>n("div",null,{class:"flex flex-col w-full md:w-1/2 items-center px-4 justify-start"},[l.attributes.Title.map((o,c)=>n("div",null,null,n("p",null,{class:"text-center text-2xl text-primary-blue font-semibold"},S(o,"Text"),1,null),1,c)),l.attributes.BoxContent.map((o,c)=>n("div",null,{class:"md:min-h-[350px] my-4 w-full flex flex-col gap-5 justify-start items-center py-4 rounded-2xl shadow-xl"},[n("div",{class:`w-full flex justify-center py-2 items-center rounded-t-2xl ${r%2==0?"bg-primary-blue":"bg-secondary-red"}`},null,n("p",null,{class:"text-center text-2xl text-white font-semibold"},S(o,"Title"),1,null),1,null),i(M,{classN:"text-center px-4",get text(){return o.Paragraph},[s]:{classN:s,text:h(o,"Paragraph")}},3,"t0_2"),n("div",null,{class:"flex flex-wrap items-center justify-center gap-2"},o.Buttons.map((p,d)=>{var f;return i(tt,{get text(){return p.Text},get link(){return p.Link},type:(f=p.Link)!=null&&f.includes("tel:")?"action":"link",[s]:{text:h(p,"Text"),link:h(p,"Link")}},3,d)}),1,null)],1,c))],1,r)),1,null),n("div",null,{class:"flex flex-col my-4 md:flex-row gap-5"},e.SelfSupport.map((l,r)=>n("div",null,{class:"h-[290px] w-full md:w-[305px] rounded-3xl shadow-2xl flex p-6 flex-col items-center justify-between"},[i(A,{get media(){return l.Media.data.attributes},height:150,width:310,[s]:{media:h(l.Media.data,"attributes"),height:s,width:s}},3,"t0_3"),n("p",null,{class:"text-2xl md:text-3xl text-center font-semibold text-primary-blue"},S(l,"Title"),1,null),i(M,{classN:"text-center",get text(){return l.Paragraph},[s]:{classN:s,text:h(l,"Paragraph")}},3,"t0_4"),i(tt,{get text(){return l.Buttons[0].Text},get link(){return l.Buttons[0].Link},[s]:{text:h(l.Buttons[0],"Text"),link:h(l.Buttons[0],"Link")}},3,"t0_5")],1,r)),1,null)],1,"t0_6")},Mv=b(g(Cv,"s_Vkf3Ha9y0kU")),jv=t=>`
        sectionContactBoxes(locale:"${t}"){
          data{
            attributes{
              Title{
                Text
              }
              BoxContent{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
            }
          }
      }`,Av=t=>`query QuerySupport{
        pageSupport(locale:"${t}"){
          data{
            attributes{
              Marquee
              
              WTTTitle
              WTTButton{
                Text
                Link
              }
              
              Introduction{
                Title
                Subtitle
                Paragraph
              }
              
              SelfSupport{
                Media{
                ${_}
                }
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              ${H}
            }
          }
        }
        ${jv(t)}
      }`,Ev=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Av,e)},Bs=R(g(Ev,"s_PaoFf3TWb00")),Nv=()=>{const t=Bs();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageSupport.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageSupport.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageSupport"]["data"]["attributes"]["SEO"]')}},3,"Ez_0"),i(Mv,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"Ez_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Ez_2")},1,"Ez_3")},Iv=b(g(Nv,"s_BS8ceDijUKA")),Bv=({resolveValue:t})=>{const a=t(Bs).pageData.data.pageSupport.data.attributes.SEO;return V(a)},Ov=Object.freeze(Object.defineProperty({__proto__:null,default:Iv,head:Bv,usePageData:Bs},Symbol.toStringTag,{value:"Module"})),qv=t=>n("div",null,{class:"flex h-[190px]  max-w-[350px] flex-col items-center justify-center rounded-[20px] bg-white p-6 m-2 text-primary-blue"},[i(cf,{class:"text-[28px] text-secondary-red",[s]:{class:s}},3,"Gr_0"),n("span",null,{class:"text-[17px] font-[600]"},u(e=>e.testimonial.Title,[t],'p0.testimonial["Title"]'),3,null),i(M,{classN:"text-[12px] text-center",get text(){return t.testimonial.Text},[s]:{classN:s,text:u(e=>e.testimonial.Text,[t],'p0.testimonial["Text"]')}},3,"Gr_1")],1,"Gr_2"),Rv=t=>{const e=t.data.pageTestimon.data.attributes,a=b(g(qv,"s_ikLHAV9ZIuk")),l=e.Testimonials.map((r,o)=>i(a,{testimonial:r},3,o));return n("div",null,{class:"flex w-full items-center justify-center px-8",onClick$:B("s_KMXVxiVFs3M")},n("div",null,{class:"my-16 flex max-w-[1400px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex w-[60%] flex-col items-center justify-center gap-2 max-[800px]:w-full"},[n("h2",null,{class:"text-[36px] max-[800px]:text-[20px] font-[600] text-primary-dark-blue"},S(e,"VideoTitle"),1,null),n("video",{src:gt(e.Video.data.attributes.url)},{class:"rounded-[30px] max-[800px]:max-w-[400px]",controls:!0},null,3,null)],1,null),n("div",null,{class:"items-center w-[40%] flex-col px-1 justify-center max-[800px]:w-full max-h-[500px]  "},i(Et,{slides:l,id:"carTestimonials",hasArrows:!1,hasPagination:!0,slidesQty:1,[s]:{id:s,hasArrows:s,hasPagination:s,slidesQty:s}},3,"Gr_3"),1,null)],1,null),1,"Gr_4")},zv=b(g(Rv,"s_HE2Hm2x9r68")),Fv=t=>`query queryTestimonials{
    pageTestimon(locale:"${t}"){
      data{
        attributes{
          Testimonials{
            Title
            Text
          }
          VideoTitle
          TestimBG{
           ${_}
          }
          Video{
            ${_}
          }
          ${H}
        }
      }
    }
  }`,Qv=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Fv,e)},Os=R(g(Qv,"s_R6fQva4FAkw")),Gv=()=>{const t=Os();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageTestimon.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageTestimon.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageTestimon"]["data"]["attributes"]["SEO"]')}},3,"cR_0"),i(zv,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"cR_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"cR_2")},Hv=b(g(Gv,"s_jKMCOKr9uSw")),Vv=({resolveValue:t})=>{const a=t(Os).pageData.data.pageTestimon.data.attributes.SEO;return V(a)},Wv=Object.freeze(Object.defineProperty({__proto__:null,default:Hv,head:Vv,usePageData:Os},Symbol.toStringTag,{value:"Module"})),Uv=t=>{var l;const a=(l=rt().prevUrl)==null?void 0:l.pathname.includes("/es/");return n("div",null,{class:"p-8"},[n("h1",null,{class:"text-center font-bold text-4xl mb-6 text-secondary-red"},a?"Encuentra tu locación":"Find your location",1,null),n("table",null,{class:"w-full rounded-2xl"},[n("thead",null,{class:"bg-primary-blue text-white font-semibold"},[n("th",null,null,a?"Nombre":"Name",1,null),n("th",null,null,a?"Código postal":"Zip code",1,null),n("th",null,null,a?"Ubicación de oficina local":"Local Office Location",1,null)],1,null),n("tbody",null,null,t.data.map((r,o)=>n("tr",{class:`text-center text-primary-dark-blue w-full h-full ${o%2==0?"bg-blue-100":"bg-blue-200"}`},null,[n("td",null,{class:"hover:text-secondary-red"},n("a",{href:a?("/es/texas/"+r.attributes.Slug).replace("-es","/"):r.attributes.Slug+"/"},null,[S(r.attributes,"Name"),", TX"],1,null),1,null),n("td",null,null,S(r.attributes,"ZipCode"),1,null),n("td",null,null,S(r.attributes.office.data.attributes,"Location"),1,null)],1,o)),1,null)],1,null)],1,"pd_0")},Yv=b(g(Uv,"s_YVNQC4aSS0M")),Zv=t=>`query{
        locations(locale:"${t}", pagination:{limit:500}){
          data{
            attributes{
              Name
              ZipCode
              Description
              Slug
              office{
                data{
                  attributes{
                    Location
                  }
                }
              }
              ${H}
            }
          }
        }
      }`,Kv=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Zv,e)},mo=R(g(Kv,"s_0tHKviRSkdY")),Jv=async t=>(t.params.lang==""?"en":"es-419").toString(),ho=R(g(Jv,"s_5IMJ5tToq0s")),Xv=()=>{const t=mo(),e=t.value.pageData.data.locations.data;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(Yv,{data:e},3,"N7_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"N7_1")},1,"N7_2")},ty=b(g(Xv,"s_7yoRSOyY1lA")),ey=({resolveValue:t})=>{const e=t(ho),a={MetaTitle:e=="en"?"Areas Served | RTA Rural Telecommunications of America":"Áreas de servicio | RTA Rural Telecommunications of America",MetaDescription:e=="en"?"Discover RTA's extensive service areas and expand your connectivity horizons. Explore reliable telecommunications solutions tailored for diverse regions!":"Descubre áreas de servicio de RTA y expande tus horizontes de conectividad. ¡Explora soluciones de telecomunicaciones confiables para diversas regiones!",Keywords:e=="en"?"Service coverage areas, Regional connectivity, Rural broadband solutions":"Áreas de cobertura de servicios, Conectividad regional, Soluciones de banda ancha rural"};return V(a)},ay=Object.freeze(Object.defineProperty({__proto__:null,default:ty,head:ey,useLang:ho,usePageData:mo},Symbol.toStringTag,{value:"Module"})),ly=t=>{const e=t.data.data.pageWholesale.data.attributes,a=t.data.data.sectionNetwork.data.attributes,l=e.NetworkDIA.Features,r=e.Introduction.Paragraph||"",[o,c]=r.split("+++",2),p=C(0);return wt(B("s_jeOJGnobZvM",[l,p])),n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"p-8 flex md:flex-row flex-col w-full max-w-[1200px] items-stretch justify-center gap-8"},[n("div",null,{class:"flex flex-col gap-4 md:flex-1 w-full items-center justify-center"},[n("h1",null,{class:"text-primary-blue min-[1000px]:text-[45px] text-[30px] !font-bold md:text-start text-center"},S(e.Introduction,"Title"),1,null),i(M,{classN:"md:text-start text-center",text:o.trim(),[s]:{classN:s}},3,"Xs_0")],1,null),n("div",null,{class:"relative bg-primary-blue border-[30px] border-solid border-blue-500 text-white rounded-full p-2 flex flex-col items-center justify-center w-full md:w-auto md:aspect-square md:h-auto md:min-h-[120px] md:min-w-[120px] gap-4 grow-0"},[i(M,{classN:"text-center text-white md:max-w-[350px]",text:(c==null?void 0:c.trim())||"",[s]:{classN:s}},3,"Xs_1"),i(tt,{get text(){return e.Introduction.Buttons[0].Text},get link(){return e.Introduction.Buttons[0].Link},type:"action",[s]:{text:h(e.Introduction.Buttons[0],"Text"),link:h(e.Introduction.Buttons[0],"Link"),type:s}},3,"Xs_2")],1,null)],1,null),i(A,{get media(){return e.NetworkLogo.data.attributes},height:180,width:400,[s]:{media:h(e.NetworkLogo.data,"attributes"),height:s,width:s}},3,"Xs_3"),n("div",null,{class:"flex w-full flex-col items-center justify-center"},n("div",null,{class:"my-4 flex max-w-[1200px] flex-row-reverse items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-4 px-10 min-[800px]:w-[70%]"},[n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},S(e.NetworkDIA,"Title"),1,null),1,null),i(M,{get text(){return e.NetworkDIA.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{text:h(e.NetworkDIA,"Paragraph"),classN:s}},3,"Xs_4"),n("div",null,{class:"flex flex-col items-center justify-end text-center"},[n("h2",null,{class:"font-semibold text-primary-blue"},S(e.NetworkDIA,"Subtitle"),1,null),n("p",null,{class:"text-2xl font-bold text-primary-blue"},S(e.NetworkDIA,"FeaturesTitle"),1,null)],1,null),n("div",null,{class:"text-center text-xl font-semibold text-secondary-red"},n("h2",null,{class:"animated-fadein-down animated-fadeout-down"},S(l[p.value],"Text"),1,null),1,null)],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(A,{get media(){return e.NetworkDIA.Media.data.attributes},width:"597",height:"500",[s]:{media:h(e.NetworkDIA.Media.data,"attributes"),width:s,height:s}},3,"Xs_5"),1,null)],1,null),1,null),i(Lt,{get text(){return e.NetworkCircuits.Paragraph},backgroundColor:"transparent",get title(){return e.NetworkCircuits.Title},get image(){return e.NetworkCircuits.Media.data.attributes},[s]:{text:h(e.NetworkCircuits,"Paragraph"),backgroundColor:s,title:h(e.NetworkCircuits,"Title"),image:h(e.NetworkCircuits.Media.data,"attributes")}},3,"Xs_6"),n("div",null,{class:"my-4 flex flex-wrap-reverse items-center justify-center gap-8 px-8 py-6"},[n("div",{onClick$:B("s_VUkdu4BrA18",[e])},{class:"flex items-center justify-center"},i(A,{get media(){return e.NetworkMap.data.attributes.Map.MapPicture.data.attributes},width:500,height:500,[s]:{media:h(e.NetworkMap.data.attributes.Map.MapPicture.data,"attributes"),width:s,height:s}},3,"Xs_7"),0,null),n("div",null,{class:"flex w-full flex-col items-center justify-center md:w-1/2"},[i(M,{get text(){return a.Description.Paragraph},classN:"text-primary-blue",[s]:{text:h(a.Description,"Paragraph"),classN:s}},3,"Xs_8"),i(Ga,{get title(){return a.Map.ServersTitle},classContainer:"rounded-full bg-white text-primary-blue shadow-xl",children:n("div",null,{class:"flex flex-col rounded-b-2xl bg-white py-4 text-primary-blue"},a.Map.Servers.map((d,f)=>n("a",{href:S(d,"Link")},{class:"text-primary-blue hover:text-secondary-red"},S(d,"Text"),1,f)),1,null),[s]:{title:h(a.Map,"ServersTitle"),classContainer:s}},1,"Xs_9")],1,null)],1,null),i(We,{get data(){return e.GFServices},[s]:{data:h(e,"GFServices")}},3,"Xs_10")],1,"Xs_11")},ny=b(g(ly,"s_SvASKT7lKMw")),sy=t=>`query QueryWholesale {
        pageWholesale(locale:"${t}"){    
          data{
            attributes{
            Introduction{
              Title
              Paragraph
              Buttons{
                Text
                Link
              }
            }
              
            NetworkLogo{
                ${_}
            }
            NetworkDIA{
              Title
              Paragraph
              Subtitle
              FeaturesTitle
              Features{
                Text
              }
              Media{
                ${_}
              }
            }
            NetworkCircuits{
              Title
              Subtitle
              Paragraph
              Media{
                 ${_}
              }
            }
           
              
            GFServices{
              Title
              Logo{
                ${_}
              }
              Paragraph
              Media{
                ${_}
              }
              Buttons{
                Text
                Link
              }
            }
              ${H}
              NetworkMap {
                data {
                  attributes {
                    Map {
                      MapPicture {
                        ${_}
                      }
                    }
                  }
                }
              }
            }
          }
        }
        ${Cp(t)}
      }`,ry=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(sy,e)},qs=R(g(ry,"s_odgwpNJ8jW8")),iy=()=>{const t=qs();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageWholesale.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageWholesale.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageWholesale"]["data"]["attributes"]["SEO"]')}},3,"3I_0"),i(ny,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"3I_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"3I_2")},1,"3I_3")},oy=b(g(iy,"s_W611gmEC5Rk")),uy=({resolveValue:t})=>{const a=t(qs).pageData.data.pageWholesale.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},cy=Object.freeze(Object.defineProperty({__proto__:null,default:oy,head:uy,usePageData:qs},Symbol.toStringTag,{value:"Module"})),dy=t=>n("div",{style:{backgroundImage:`url(${gt(t.slide.attributes.url)})`}},{class:"h-[350px] my-5 w-[280px] overflow-hidden rounded-[10px] bg-contain bg-no-repeat bg-center"},null,3,"0D_0"),py=t=>{const e=t.data.pageWinnersC.data.attributes,a=e.Winners.data.reverse(),l=b(g(dy,"s_Kis0UnPgGnE")),r=a.map((o,c)=>i(l,{slide:o},3,c));return n("div",null,{class:"relative flex flex-col items-center justify-center",onClick$:B("s_na2GxJ32Wno")},[n("div",null,{class:"relative flex w-full items-center justify-center overflow-hidden"},[i(A,{width:"1024",height:"603",clasN:"max-w-[1000px] w-fit z-10 object-cover",get media(){return e.WinnersBG.data.attributes},[s]:{width:s,height:s,clasN:s,media:h(e.WinnersBG.data,"attributes")}},3,"0D_1"),n("div",null,{class:"absolute z-20 mb-[160px]  w-[290px] overflow-hidden  rounded-[10px] border border-gray-500 bg-[#171f2a] p-2"},i(Et,{slides:r,id:"carouselWinners",slidesQty:1,hasArrows:!1,addSpace:!1,[s]:{id:s,slidesQty:s,hasArrows:s,addSpace:s}},3,"0D_2"),1,null),n("div",null,{class:"absolute bottom-0 left-0 right-0 h-[30%] bg-black"},null,3,null)],1,null),n("div",null,{class:"flex w-full overflow-hidden bg-cover pt-16 bg-black justify-center"},n("div",null,{class:"flex max-w-[1200px] gap-4  max-[1000px]:flex-col  justify-center items-center"},[n("div",null,{class:"flex w-[30%] flex-col "},[n("h2",null,{class:"text-center text-[36px] font-[600] leading-[36px] text-secondary-red"},S(e,"GiveawayCarTitle"),1,null),n("br",null,null,null,3,null),n("div",null,{class:"mb-6 flex items-center justify-center rounded-xl bg-white p-2"},i(Et,{id:"giveAnswers",hasPagination:!1,slidesQty:1,duration:5e3,addSpace:!1,hasArrows:!0,slides:e.GiveawayAnswers.reverse().map((o,c)=>n("div",null,{class:"flex flex-col items-center justify-center gap-1.5 max-w-[180px]"},[n("p",null,{class:"text-center text-[15px] text-primary-blue"},["This question was answered on"," ",n("br",null,null,null,3,null),Hl(o.AnswerDate,!1)],1,null),n("iframe",{src:`https://www.youtube.com/embed/${o.QuestionVideos.split("v=")[1]}`},{class:"rounded-[20px] shadow-xl",frameBorder:"0",height:270,width:160,allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",allowFullscreen:!0},null,3,null),n("span",null,{class:"text-secondary-red"},"Answer:",3,null),n("span",null,{class:"text-primary-blue"},S(o,"Answer"),1,null)],1,c)),[s]:{id:s,hasPagination:s,slidesQty:s,duration:s,addSpace:s,hasArrows:s}},3,"0D_3"),1,null)],1,null),n("div",null,{class:"flex md:w-[60%] w-[30%] h-full flex-col justify-center  overflow-hidden"},[n("h3",null,{class:"text-center text-[28px] font-[500] leading-[30px] text-primary-blue"},S(e,"TwitterFeedTitle"),1,null),n("br",null,null,null,3,null),n("iframe",{srcdoc:S(e,"TwitterFeedLink")},{class:"h-full",height:"100%",width:"100%"},null,3,null)],1,null)],1,null),1,null)],1,"0D_4")},fy=b(g(py,"s_QYIFsZOPjHw")),gy=t=>`query queryWinnerCircle{
    pageWinnersC(locale:"${t}"){
      data{
        attributes{
          WinnersTitle
  
          WinnersBG{
            ${_}
          }
          
          WinnersCarBG{
           ${_}
          }
          Winners{
            ${_}
          }
         
          GiveawayCarTitle
          
          GiveawayAnswers{
            Description
            AnswerDate
            QuestionVideos
            Answer
          }
          TwitterFeedLink
          TwitterFeedTitle
  
          ${H}
        }
      }
    }
  }`,xy=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(gy,e)},Rs=R(g(xy,"s_6WeV0M8I1Do")),my=()=>{const t=Rs();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageWinnersC.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageWinnersC.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageWinnersC"]["data"]["attributes"]["SEO"]')}},3,"00_0"),i(fy,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"00_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"00_2")},hy=b(g(my,"s_0m9hLjn9QnA")),by=({resolveValue:t})=>{const a=t(Rs).pageData.data.pageWinnersC.data.attributes.SEO;return V(a)},$y=Object.freeze(Object.defineProperty({__proto__:null,default:hy,head:by,usePageData:Rs},Symbol.toStringTag,{value:"Module"})),vy=t=>n("div",null,{class:"flex max-w-[400px] flex-col items-center max-[900px]:place-self-center"},[n("section",null,{class:"flex h-fit w-full flex-col rounded-[35px] bg-white text-center shadow-lg"},[n("div",null,{class:"flex w-full items-center justify-center rounded-t-[35px] bg-gradient-to-r from-[#4caafd] to-[#1a7ee4] px-6 py-3 text-center"},i(A,{get media(){return t.data.RaceRepLogo.data.attributes},clasN:"h-[16px] w-fit",[s]:{media:u(e=>e.data.RaceRepLogo.data.attributes,[t],'p0.data["RaceRepLogo"]["data"]["attributes"]'),clasN:s}},3,"QP_0"),1,null),n("div",null,{class:"flex flex-col items-center justify-center p-4"},[i(ul,{get ytURL(){return t.data.RaceRepVids[0].Link},classN:"rounded-[30px] shadow-lg",[s]:{ytURL:u(e=>e.data.RaceRepVids[0].Link,[t],'p0.data["RaceRepVids"][0]["Link"]'),classN:s}},3,"QP_1"),i(M,{get text(){return t.data.RaceRepVids[0].Paragraph},classN:"text-[13px] p-1 mt-2",[s]:{text:u(e=>e.data.RaceRepVids[0].Paragraph,[t],'p0.data["RaceRepVids"][0]["Paragraph"]'),classN:s}},3,"QP_2"),n("div",null,{class:"h-[6px] w-full border-t border-gray-300"},null,3,null),n("div",null,{class:"h-[6px] w-full border-t border-gray-300"},null,3,null),n("div",null,{class:"mb-4 h-[6px] w-full border-t border-gray-300"},null,3,null),i(ul,{get ytURL(){return t.data.RaceRepVids[1].Link},classN:"rounded-[30px] shadow-lg",[s]:{ytURL:u(e=>e.data.RaceRepVids[1].Link,[t],'p0.data["RaceRepVids"][1]["Link"]'),classN:s}},3,"QP_3"),i(M,{get text(){return t.data.RaceRepVids[1].Paragraph},classN:"text-[13px] p-1 mt-2",[s]:{text:u(e=>e.data.RaceRepVids[1].Paragraph,[t],'p0.data["RaceRepVids"][1]["Paragraph"]'),classN:s}},3,"QP_4")],1,null)],1,null),n("a",null,{href:u(e=>e.data.HeaderButtons[0].Link,[t],'p0.data["HeaderButtons"][0]["Link"]'),target:"_blank",class:"mt-8 w-full rounded-full border-[6px] border-[#e7758f] bg-secondary-red px-8 py-1 text-center text-[14px] font-[600] leading-[18px] text-white shadow-lg"},u(e=>e.data.HeaderButtons[0].Text,[t],'p0.data["HeaderButtons"][0]["Text"]'),3,null)],1,"QP_5"),yy=t=>n("div",null,{class:"flex h-fit max-w-[600px] flex-col items-center justify-center  text-center text-white"},[i(A,{get media(){return t.data.LogoCorp.data.attributes},clasN:"h-[80px] w-[215px]",[s]:{media:u(e=>e.data.LogoCorp.data.attributes,[t],'p0.data["LogoCorp"]["data"]["attributes"]'),clasN:s}},3,"QP_6"),n("span",null,{class:"mb-4 text-[46px] font-[700] leading-[50px]"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),i(A,{get media(){return t.data.LogoSponsor.data.attributes},[s]:{media:u(e=>e.data.LogoSponsor.data.attributes,[t],'p0.data["LogoSponsor"]["data"]["attributes"]')}},3,"QP_7"),n("span",null,{class:"my-4 rounded-full bg-white px-4 text-[15px] font-[400] tracking-widest text-primary-blue"},t.data.Subtitle.toUpperCase(),1,null),i(A,{get media(){return t.data.HeaderPictures.data[0].attributes},clasN:"w-full h-fit px-4 pt-4",[s]:{media:u(e=>e.data.HeaderPictures.data[0].attributes,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]'),clasN:s}},3,"QP_8")],1,"QP_9"),_y=t=>{z();const e=C(1e3);wt(B("s_0vxrMcOslm0",[e]));const a=b(g(vy,"s_S9x7nXVXxQ0")),l=b(g(yy,"s_YXp1rsg61DU"));return n("div",null,{class:"flex min-h-[500px] w-full items-center justify-center bg-[conic-gradient(at_top,_var(--tw-gradient-stops))] from-[#001536] via-[#0E67BB] to-[#001536]"},n("div",null,{class:"flex max-w-[1200px] flex-col items-center justify-center px-8 pt-12"},n("div",null,{class:"grid items-start justify-center gap-6 max-[900px]:items-center",style:u(r=>({gridTemplateColumns:r.value>900?"250px 1fr 250px":"1fr"}),[e],'{gridTemplateColumns:p0.value>900?"250px 1fr 250px":"1fr"}')},[e.value<=900&&i(l,{get data(){return t.data},[s]:{data:u(r=>r.data,[t],"p0.data")}},3,"QP_10"),i(a,{get data(){return t.data},[s]:{data:u(r=>r.data,[t],"p0.data")}},3,"QP_11"),e.value>900&&i(l,{get data(){return t.data},[s]:{data:u(r=>r.data,[t],"p0.data")}},3,"QP_12"),n("div",null,{class:"flex max-w-[400px] flex-col items-center max-[900px]:place-self-center"},[n("section",null,{class:"flex h-fit w-full flex-col items-center justify-center rounded-[35px] bg-white p-4 text-center shadow-lg"},[n("div",null,{class:"h-[420px]"},i(ul,{get ytURL(){return t.data.GiveawayBox[0].Video.Link},classN:"rounded-[30px] shadow-lg",[s]:{ytURL:u(r=>r.data.GiveawayBox[0].Video.Link,[t],'p0.data["GiveawayBox"][0]["Video"]["Link"]'),classN:s}},3,"QP_13"),1,null),i(M,{get text(){return t.data.GiveawayBox[0].Video.Paragraph},classN:"text-[13px] p-1 mt-2",[s]:{text:u(r=>r.data.GiveawayBox[0].Video.Paragraph,[t],'p0.data["GiveawayBox"][0]["Video"]["Paragraph"]'),classN:s}},3,"QP_14"),i(tt,{get text(){return t.data.GiveawayBox[0].Button.Text},get link(){return t.data.GiveawayBox[0].Button.Link},[s]:{text:u(r=>r.data.GiveawayBox[0].Button.Text,[t],'p0.data["GiveawayBox"][0]["Button"]["Text"]'),link:u(r=>r.data.GiveawayBox[0].Button.Link,[t],'p0.data["GiveawayBox"][0]["Button"]["Link"]')}},3,"QP_15")],1,null),n("a",null,{href:u(r=>r.data.HeaderButtons[1].Link,[t],'p0.data["HeaderButtons"][1]["Link"]'),class:"my-8 w-full rounded-full border-[6px] border-[#e7758f] bg-secondary-red px-8 py-1 text-center text-[14px] font-[600] leading-[18px] text-white shadow-lg"},u(r=>r.data.HeaderButtons[1].Text,[t],'p0.data["HeaderButtons"][1]["Text"]'),3,null)],1,null)],1,null),1,null),1,"QP_16")},wy=b(g(_y,"s_v9v6ItSeef4")),Sy=t=>n("div",null,{class:"flex flex-col items-center justify-center text-center text-white"},[n("span",null,{class:"text-[24px]"},i(M,{classN:"text-white",get text(){return t.data.QuoteText},[s]:{classN:s,text:u(e=>e.data.QuoteText,[t],'p0.data["QuoteText"]')}},3,"0q_0"),1,null),n("div",null,{class:"mt-4 flex flex-col"},[n("span",null,{class:"text-[19px] font-[600] text-[#7bc8ff]"},u(e=>e.data.QuoteAuthor,[t],'p0.data["QuoteAuthor"]'),3,null),n("span",null,{class:"max-w-[200px] text-[14px] tracking-[2px]"},u(e=>e.data.QuoteADesc,[t],'p0.data["QuoteADesc"]'),3,null)],3,null)],1,"0q_1"),Ty=b(g(Sy,"s_P6qdCyIENpU")),Dy=t=>n("div",null,{class:"flex items-center justify-center gap-10 px-8 max-[800px]:flex-col"},[n("div",null,{class:"flex min-w-[300px] max-w-[400px] flex-col items-center justify-center rounded-[30px] bg-white p-8 text-primary-blue "},[i(A,{clasN:"h-fit w-[180px]",get media(){return t.data.AboutZane.Media.data.attributes},[s]:{clasN:s,media:u(e=>e.data.AboutZane.Media.data.attributes,[t],'p0.data["AboutZane"]["Media"]["data"]["attributes"]')}},3,"E0_0"),n("h2",null,{class:"mt-4 text-[30px] font-[500] text-secondary-red"},u(e=>e.data.AboutZane.Title,[t],'p0.data["AboutZane"]["Title"]'),3,null),i(M,{classN:"[&>h2]:text-[21px] [&>h2]:leading-10 [&>h2]:font-[600]",get text(){return t.data.AboutZane.Paragraph},[s]:{classN:s,text:u(e=>e.data.AboutZane.Paragraph,[t],'p0.data["AboutZane"]["Paragraph"]')}},3,"E0_1"),n("div",null,{class:"mb-4 flex w-full items-center justify-evenly gap-2 rounded-full bg-primary-blue p-2"},t.data.AboutZane.Buttons.filter(e=>!e.Text).map((e,a)=>n("div",{onClick$:B("s_aBdgclRoL4w",[e])},{class:"hover:cursor-pointer"},i(A,{clasN:"h-[20px]",toWhite:a!==0,get media(){return e.Icon.data.attributes},[s]:{clasN:s,media:h(e.Icon.data,"attributes")}},3,"E0_2"),0,a)),1,null),t.data.AboutZane.Buttons.filter(e=>e.Text).map((e,a)=>n("div",{onClick$:B("s_0qHArrAd29Q",[e])},{class:"flex gap-2 self-start hover:cursor-pointer"},[i(A,{clasN:"h-[24px] w-[24px]",get media(){return e.Icon.data.attributes},[s]:{clasN:s,media:h(e.Icon.data,"attributes")}},3,"E0_3"),n("span",null,{class:"text-[14px] font-[500]"},S(e,"Text"),1,null)],0,a))],1,null),n("div",null,{class:"flex flex-col text-white"},[n("span",null,{class:"mb-4 text-[40px] font-[600]"},u(e=>e.data.Highlights.Title,[t],'p0.data["Highlights"]["Title"]'),3,null),i(M,{classN:"text-white text-justify",get text(){return t.data.Highlights.Paragraph},[s]:{classN:s,text:u(e=>e.data.Highlights.Paragraph,[t],'p0.data["Highlights"]["Paragraph"]')}},3,"E0_4")],1,null)],1,"E0_5"),Py=b(g(Dy,"s_CpEM5GsNAyg")),ky=t=>n("div",null,{class:"mt-[80px] flex flex-col items-center justify-center"},[n("div",null,{class:"mb-6 flex items-center justify-center gap-6"},[n("span",null,{class:"text-[40px] font-[600] text-white max-[800px]:hidden"},u(e=>e.data.AboutFRM.Title,[t],'p0.data["AboutFRM"]["Title"]'),3,null),i(A,{get media(){return t.data.AboutFRM.Logo.data.attributes},[s]:{media:u(e=>e.data.AboutFRM.Logo.data.attributes,[t],'p0.data["AboutFRM"]["Logo"]["data"]["attributes"]')}},3,"KU_0")],1,null),n("div",null,{class:"flex gap-8 max-[800px]:flex-col"},[n("div",null,{class:"flex w-[60%] flex-col items-center gap-4 max-[800px]:w-full"},[i(M,{classN:"text-white text-[18px] text-justify",get text(){return t.data.AboutFRM.Paragraph},[s]:{classN:s,text:u(e=>e.data.AboutFRM.Paragraph,[t],'p0.data["AboutFRM"]["Paragraph"]')}},3,"KU_1"),i(A,{clasN:"w-[80%] min-w-[300px] rounded-3xl",get media(){return t.data.FRMChamps.data.attributes},[s]:{clasN:s,media:u(e=>e.data.FRMChamps.data.attributes,[t],'p0.data["FRMChamps"]["data"]["attributes"]')}},3,"KU_2"),i(M,{classN:"text-white text-[12px]",get text(){return t.data.FRMChamps.data.attributes.caption},[s]:{classN:s,text:u(e=>e.data.FRMChamps.data.attributes.caption,[t],'p0.data["FRMChamps"]["data"]["attributes"]["caption"]')}},3,"KU_3"),i(M,{classN:"text-white text-[12px] text-justify",get text(){return t.data.AboutFRMPInfo},[s]:{classN:s,text:u(e=>e.data.AboutFRMPInfo,[t],'p0.data["AboutFRMPInfo"]')}},3,"KU_4")],1,null),n("div",null,{class:"flex w-[40%] flex-col items-center max-[800px]:w-full"},[i(M,{classN:"text-white text-[15px] font-[600]",get text(){return t.data.AboutFRM.Subtitle},[s]:{classN:s,text:u(e=>e.data.AboutFRM.Subtitle,[t],'p0.data["AboutFRM"]["Subtitle"]')}},3,"KU_5"),i(A,{clasN:"w-[80%] min-w-[180px] rounded-3xl my-2",get media(){return t.data.AboutFRM.Media.data.attributes},[s]:{clasN:s,media:u(e=>e.data.AboutFRM.Media.data.attributes,[t],'p0.data["AboutFRM"]["Media"]["data"]["attributes"]')}},3,"KU_6"),i(M,{classN:"text-white text-[13px]",get text(){return t.data.AboutFRM.Media.data.attributes.caption},[s]:{classN:s,text:u(e=>e.data.AboutFRM.Media.data.attributes.caption,[t],'p0.data["AboutFRM"]["Media"]["data"]["attributes"]["caption"]')}},3,"KU_7"),n("div",null,{class:"my-4 flex flex-col items-start justify-start gap-1 self-start"},t.data.AboutFRM.Buttons.map((e,a)=>n("div",{onClick$:B("s_TcbYAUHeCh4",[e])},{class:"flex items-center"},[i(A,{clasN:"h-[16px] w-[16px] mr-2",toWhite:!0,get media(){return e.Icon.data.attributes},[s]:{clasN:s,toWhite:s,media:h(e.Icon.data,"attributes")}},3,"KU_8"),n("span",null,{class:"text-white"},S(e,"Text"),1,null)],0,a)),1,null)],1,null)],1,null)],1,"KU_9"),Ly=b(g(ky,"s_uxm1007Tl9Q")),Cy=t=>n("div",null,{class:"my-[80px] flex flex-col items-center justify-center text-white"},[n("span",null,{class:"text-center text-[40px] font-[600]"},u(e=>e.data.CarouselTitle,[t],'p0.data["CarouselTitle"]'),3,null),n("div",null,{class:"max-w-[1300px] px-8"},i(Et,{direction:"horizontal",addSpace:!0,slidesQty:3,hasArrows:!0,id:"zss_carousel",slides:t.data.CarouselContent.map((e,a)=>n("div",{onClick$:B("s_LReiaiAXvdI",[e])},{class:"relative overflow-hidden rounded-3xl hover:cursor-pointer"},[n("div",null,{class:"absolute inset-0 z-20 flex items-center justify-center bg-black bg-opacity-10 text-[60px] font-[900] text-white"},"▷",3,null),i(A,{get media(){return e.Cover.data.attributes},[s]:{media:h(e.Cover.data,"attributes")}},3,"YI_0")],0,a)),[s]:{direction:s,addSpace:s,slidesQty:s,hasArrows:s,id:s}},3,"YI_1"),1,null)],1,"YI_2"),My=b(g(Cy,"s_leW0062t5ac")),jy=t=>{const e=t.data.pageZaneSpon.data.attributes;return n("div",null,{onClick$:B("s_m03OOMoHREo")},[i(wy,{data:e},3,"5E_0"),n("div",null,{class:"bg-gradient-to-b from-[#041630] to-[#153069]"},n("div",null,{class:" md:flex w-full justify-center items-center"},n("div",null,{class:"max-w-[1200px] px-8 pt-8"},[i(Ty,{data:e},3,"5E_1"),i(My,{data:e},3,"5E_2"),i(Py,{data:e},3,"5E_3"),i(Ly,{data:e},3,"5E_4")],1,null),1,null),1,null)],1,"5E_5")},Ay=b(g(jy,"s_kYGFw8H412s")),Ey=t=>`query {
    pageZaneSpon(locale:"${t}") {
      data {
        attributes {
          Title
          Subtitle
          LogoCorp {
            ${_}
          }
          LogoSponsor {
            ${_}
          }
          HeaderPictures {
            ${_}
          }
          HeaderButtons {
            Text
            Link
          }
          NascarSchedule {
            ${_}
          }
          yt {
            ${_}
          }
          GiveawayBox {
            Video {
              Link
              Paragraph
            }
            Button {
              Text
              Link
            }
          }
          QuoteText
          QuoteAuthor
          QuoteADesc
          RaceRepLogo {
            ${_}
          }
          RaceRepVids {
            Link
            Paragraph
          }
          CarouselTitle
          CarouselContent {
            Link
            Paragraph
            Cover {
                ${_}
            }
          }
          AboutZane {
            Title
            Subtitle
            Paragraph
            Media {
                ${_}
            }
            Buttons {
              Text
              Link
              Icon {
                ${_}
              }
            }
          }
          Highlights {
            Title
            Paragraph
          }
          AboutFRM {
            Title
            Subtitle
            Paragraph
            Buttons {
              Text
              Link
              Icon {
                ${_}
              }
            }
            Logo {
                ${_}
            }
            Media {
                ${_}
            }
          }
  
          Sponsors{
            ${_}
          }
  
            FRMChamps{
                ${_}
            }
  
          AboutFRMPInfo
  
          
          ${H}
          
        }
      }
    }
  }`,Ny=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Ey,e)},zs=R(g(Ny,"s_s1m2ueqRceg")),Iy=()=>{const t=zs();return i(F,{get data(){return t.value.layoutData},showHeader:!1,children:[i(et,{get SEOdata(){return t.value.pageData.data.pageZaneSpon.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageZaneSpon.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageZaneSpon"]["data"]["attributes"]["SEO"]')}},3,"zi_0"),i(Ay,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"zi_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"zi_2")},By=b(g(Iy,"s_uWXfycW000o")),Oy=({resolveValue:t})=>{const a=t(zs).pageData.data.pageZaneSpon.data.attributes.SEO;return V(a)},qy=Object.freeze(Object.defineProperty({__proto__:null,default:By,head:Oy,usePageData:zs},Symbol.toStringTag,{value:"Module"})),bo=(t,e)=>`
  query QueryLocalPage {
    locations(
      filters: { Slug: { eq: "${e}${t==="en"?"":"-es"}" } }
      locale: "${t}"
    ) {
      data {
        attributes {
            office {
                data {
                  attributes {
                    Address
                    Schema
                    Phone{
                      Link
                      Text
                    }
                  }
                }
              }
          Name
          ZipCode
          Description
          Slug
          
          posts(sort: "Date:desc", pagination: { limit: 100 }){
            data{
              attributes{
                Title
                Date
                Cover{
                  ${_}
                }
                Description
                VideoLink
                Gallery{
                  ${_}
                }
                Slug
              }
            }
          }
          
          SEO {
            MetaTitle
            MetaDescription
            preventIndexing
            Keywords
          }
        }
      }
    }
    sectionProsRta(locale:"${t}") {
    data {
      attributes {
        Pros {
          Icon {
            ${_}
          }
          Title
          Text
          Caption
        }
      }
    }
  }

  pageHome(locale:"${t}"){
    data{
      attributes{

        ProsPar{
          Title
          Paragraph
        }

        ProsPicture{
          ${_}
        }
      }
    }
  }

    lpPtGroup(locale:"${t}"){
        data{
          attributes{
            PricingTables{
              Logo{
                ${_}
              }
              Title
              Subtitle
              Price
              Pricetime
              Description
              Features{
                Text
              }
              Button{
                Text
                Link
              }
            }
          }
        }
      } 
  }  
    `,Ry=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang,a=t.params.slug;return await Qa(bo(Ca(e),a),e)},Fs=R(g(Ry,"s_6eBD86DvEZM")),zy=async t=>(t.params.lang==""?"en":"es-419").toString(),$o=R(g(zy,"s_06oruSNHf7c")),Fy=()=>{var o;z();const t=Fs(),e=t.value.pageData.data.locations.data[0].attributes,a=e.posts.data,r=(o=rt().prevUrl)==null?void 0:o.pathname.includes("/es/");return i(F,{get data(){return t.value.layoutData},children:[i(et,{customText:r?`Blog Local en ${e.Name} | RTA Telecommunications`:`${e.Name} Local Blog | RTA Telecommunications`},3,"xj_0"),a.length==0?n("div",null,{class:"h-full w-full flex items-center justify-center"},n("h2",null,{class:"font-bold text-2xl text-primary-blue p-[25px] text-center"},r==!1?"More news about this location coming soon. Stay tuned!":"Próximamente más noticias sobre esta localidad. ¡Mantente al tanto!",1,null),1,"xj_1"):n("div",null,{class:"flex flex-col items-center justify-center"},[i(Zn,{get post(){return a[0].attributes},isES:r,[s]:{post:h(a[0],"attributes")}},3,"xj_2"),n("div",null,{class:"my-4"},null,3,null),i(Kn,{get posts(){return e.posts.data},loadSize:3,type:"locations",isLocalBlog:!0,[s]:{posts:h(e.posts,"data"),loadSize:s,type:s,isLocalBlog:s}},3,"xj_3")],1,null)],[s]:{data:u(c=>c.value.layoutData,[t],'p0.value["layoutData"]')}},1,"xj_4")},Qy=b(g(Fy,"s_LRpRHkCbXkY")),Gy=({resolveValue:t})=>{const e=t($o),r=t(Fs).pageData.data.locations.data[0].attributes.Name,o={MetaTitle:e=="en"?`${r} Local Blog | RTA Telecommunications`:`Blog Local en ${r} | RTA Telecommunications`,MetaDescription:e=="en"?`Explore the most recent and relevant news in ${r}. Stay informed about events, updates, and local news that impact your community.`:`Explora las noticias más recientes y relevantes en ${r}. Mantente informado sobre eventos y noticias locales que impactan tu comunidad.`,Keywords:e=="en"?"Technology news, Tech updates, Digital trends, Innovation insights, RTA, local blog":"Noticias de tecnología, Actualizaciones tecnológicas, Tendencias digitales, Novedades en innovación, RTA, blog local"};return V(o)},Hy=Object.freeze(Object.defineProperty({__proto__:null,default:Qy,head:Gy,useLang:$o,usePageData:Fs},Symbol.toStringTag,{value:"Module"})),Vy=t=>{const e=t.data.Slug.substring(t.data.Slug.length-3,t.data.Slug.length)==="-es";return n("div",null,{class:"flex max-w-[1200px] gap-5 px-8 py-20 text-primary-blue max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-1 text-center min-[800px]:w-[40%] md:px-2"},[n("h1",null,{class:"md:text-[36px] text-[28px] font-[700] leading-10"},`gigFAST INTERNET ${e?"e":"i"}n ${t.data.Name}`,1,null),n("span",null,{class:"text-[24px]"},[u(a=>a.data.ZipCode,[t],'p0.data["ZipCode"]'),", TX"],3,null),n("span",null,{class:"text-[28px] font-[600]"},e?"Llama ahora":"Call now",1,null),i(tt,{type:"action",get link(){return t.data.office.data.attributes.Phone.Link},get text(){return t.data.office.data.attributes.Phone.Text},[s]:{type:s,link:u(a=>a.data.office.data.attributes.Phone.Link,[t],'p0.data["office"]["data"]["attributes"]["Phone"]["Link"]'),text:u(a=>a.data.office.data.attributes.Phone.Text,[t],'p0.data["office"]["data"]["attributes"]["Phone"]["Text"]')}},3,"pw_0"),n("div",null,{class:"w-full h-full mt-4"},n("iframe",null,{src:u(a=>a.data.office.data.attributes.Address,[t],'p0.data["office"]["data"]["attributes"]["Address"]'),class:"h-full w-full rounded-2xl",loading:"lazy"},null,3,null),3,null)],1,null),n("div",null,{class:"text-justify text-[16px] max-[800px]:text-[13px] min-[800px]:w-[60%]"},i(M,{get text(){return t.data.Description},[s]:{text:u(a=>a.data.Description,[t],'p0.data["Description"]')}},3,"pw_1"),1,null)],1,"pw_2")},Wy=b(g(Vy,"s_8eJAul3VU0U")),Uy=t=>{const e=t.data.locations.data[0].attributes.Slug,a=e.substring(e.length-3,e.length)==="-es",l=t.data.lpPtGroup.data.attributes.PricingTables;return n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"flex min-h-[200px]  w-full items-center justify-center bg-gradient-to-br from-primary-light-blue to-[#23477f] p-8"},n("div",null,{class:"flex w-full max-w-[1200px] flex-col items-center justify-center"},[n("span",null,{class:"text-center text-[38px] font-[600] leading-10 text-white max-[800px]:text-[28px]"},a?"Encuentra ofertas disponibles en tu área":"Find available offers in your area",1,null),n("div",null,{class:"mt-8 flex w-full items-center justify-center gap-8 max-[1200px]:flex-col"},n("div",null,{class:"flex justify-evenly gap-4 max-[1400px]:flex-wrap"},l.map((r,o)=>{var c,p;return i(gs,{btnText:(c=r.Button)==null?void 0:c.Text,btnLink:(p=r.Button)==null?void 0:p.Link,get description(){return r.Description},get logo(){return r.Logo.data.attributes},get features(){return r.Features},price:r.Price.toString(),get priceTime(){return r.Pricetime},get title(){return r.Title},isFullLogo:!0,[s]:{description:h(r,"Description"),logo:h(r.Logo.data,"attributes"),features:h(r,"Features"),priceTime:h(r,"Pricetime"),title:h(r,"Title"),isFullLogo:s}},3,o)}),1,null),1,null)],1,null),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"88_0")},Yy=b(g(Uy,"s_JRh1Z7hA4Tg")),Zy=t=>n("div",null,{class:"z-20 flex w-full justify-center bg-gradient-to-br from-[#3d76c2] to-[#2e599a] px-10 py-6 text-white"},n("div",null,{class:"flex max-w-[1100px] items-center justify-center gap-8 max-[1000px]:flex-col"},[n("div",null,{class:"flex w-[50%] flex-col text-justify max-[1000px]:w-[100%]"},[n("div",null,{class:"text-[38px] font-bold max-sm:text-[28px]"},u(e=>e.data.prosPar.Title,[t],'p0.data.prosPar["Title"]'),3,null),n("div",null,{class:"text-[18px] max-sm:text-[15px]"},u(e=>e.data.prosPar.Paragraph,[t],'p0.data.prosPar["Paragraph"]'),3,null),n("div",null,{class:"mt-6 flex flex-col gap-4"},t.data.prosData.map((e,a)=>n("div",null,{class:"flex-row "},n("div",null,{class:"flex flex-col"},[n("div",null,{class:"flex flex-row gap-4 items-center"},[n("div",null,{class:" bg-secondary-red h-fit w-fit rounded-full p-2"},i(A,{toWhite:!0,width:20,height:20,get media(){return e.Icon.data.attributes},[s]:{toWhite:s,width:s,height:s,media:h(e.Icon.data,"attributes")}},3,"l8_0"),1,null),n("span",null,{class:"text-[28px] font-bold"},i(M,{get text(){return e.Title},classN:"text-white",[s]:{text:h(e,"Title"),classN:s}},3,"l8_1"),1,null)],1,null),n("span",null,{class:"text-[18px] "},i(M,{get text(){return e.Text},classN:"text-white",[s]:{text:h(e,"Text"),classN:s}},3,"l8_2"),1,null)],1,null),1,a)),1,null)],1,null),i(A,{width:"656",height:"720",get media(){return t.data.prosMap},clasN:"px-8  min-w-[250px]",[s]:{width:s,height:s,media:u(e=>e.data.prosMap,[t],"p0.data.prosMap"),clasN:s}},3,"l8_3")],1,null),1,"l8_4"),vo=b(g(Zy,"s_F6ekLiR69OY")),Ky=t=>{const e=t.data.locations.data[0].attributes,a=e.Slug.substring(e.Slug.length-3,e.Slug.length)==="-es",l=t.data.sectionProsRta.data.attributes.Pros,r=t.data.pageHome.data.attributes,o=r.ProsPicture.data.attributes,c=e.posts.data.slice(0,3);return n("div",null,{class:"flex flex-col items-center justify-center"},[i(Wy,{get data(){return t.data.locations.data[0].attributes},[s]:{data:u(p=>p.data.locations.data[0].attributes,[t],'p0.data["locations"]["data"][0]["attributes"]')}},3,"LA_0"),i(vo,{data:{prosPar:r.ProsPar,prosData:l,prosMap:o}},3,"LA_1"),n("div",null,{class:"flex flex-col items-center justify-center my-5"},[n("h3",null,{class:"text-center text-[38px] font-[600] leading-10 text-primary-blue max-[800px]:text-[28px]"},a?"Explora la esencia de tu comunidad con RTA":"Explore your community's essence with RTA",1,null),n("div",null,{class:"flex flex-wrap w-full items-top justify-center gap-10 my-5"},c.map((p,d)=>n("div",null,{class:"m-4"},i(io,{post:p,id:`post-${d.toString()}`},3,d),1,"LA_2")),1,null),n("p",null,{class:"p-4 text-center text-[16px] text-primary-blue max-[800px]:text-[13px]"},a?"Descubre historias locales, eventos y joyas ocultas, todo impulsado por la tecnología y la innovación.":"Discover local stories, events, and hidden gems, all powered by technology and innovation.",1,null),i(tt,{link:"local-blog/",text:a?"Ver más posts":"See more posts",[s]:{link:s}},3,"LA_3")],1,null),i(Yy,{get data(){return t.data},[s]:{data:u(p=>p.data,[t],"p0.data")}},3,"LA_4")],1,"LA_5")},Jy=b(g(Ky,"s_xdmchVEPK4Q")),Xy=()=>n("div",null,{class:"flex w-full items-center justify-center px-8 py-12 text-center text-primary-dark-blue"},n("div",null,{class:"flex max-w-[1000px] flex-col items-center justify-center"},[n("span",null,{class:"text-[50px] font-[300]"},"Oops!",3,null),n("span",null,{class:"text-[18px] font-[400]"},"The page you are looking for does not exist.",3,null),n("h1",null,{class:"text-[150px] font-[700] max-[400px]:text-[100px]"},"404",3,null),n("span",null,{class:"text-[30px] font-[500] text-secondary-red"},"Something went wrong.",3,null)],3,null),3,"7k_0"),yo=b(g(Xy,"s_6KpdMMBpLyc")),t_=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang,a=t.params.slug;if(a==="gigfast-internet-in-bastrop"){const r=await Q(ro,e);return{type:"bastrop",layoutData:r.layoutData,pageData:r.pageData}}const l=await Qa(bo(Ca(e),a),e);return{type:"location",layoutData:l.layoutData,pageData:l.pageData}},Qs=R(g(t_,"s_1P6SxAujDI0")),e_=()=>{z();const t=Qs();if(t.value.type==="bastrop")return i(F,{get data(){return t.value.layoutData},showHeader:!1,children:i(so,{get data(){return t.value.pageData.data},[s]:{data:u(l=>l.value.pageData.data,[t],"p0.value.pageData.data")}},3,"jm_0"),[s]:{data:u(l=>l.value.layoutData,[t],"p0.value.layoutData"),showHeader:s}},1,"jm_1");const a=t.value.pageData.data.locations.data.length>0?i(Jy,{get data(){return t.value.pageData.data},[s]:{data:u(l=>l.value.pageData.data,[t],"p0.value.pageData.data")}},3,"jm_3"):i(yo,null,3,"jm_2");return i(F,{get data(){return t.value.layoutData},showHeader:!0,children:a,[s]:{data:u(l=>l.value.layoutData,[t],"p0.value.layoutData"),showHeader:s}},1,"jm_4")},a_=b(g(e_,"s_yFB0AuNay2A")),l_=({resolveValue:t})=>{const e=t(Qs);if(e.type==="bastrop"){const l=e.pageData.data.pageBastropP.data.attributes.SEO;return V(l)}if(e.pageData.data.locations.data.length===0)return V({MetaTitle:"Not Found",MetaDescription:"Error 404, location not found"});const a=e.pageData.data.locations.data[0].attributes.SEO;return a.schema=e.pageData.data.locations.data[0].attributes.office.data.attributes.Schema,V(a)},n_=Object.freeze(Object.defineProperty({__proto__:null,default:a_,head:l_,usePageData:Qs},Symbol.toStringTag,{value:"Module"})),s_=t=>{z();const e=a=>{z();const l=[],r=Math.floor(a);for(let o=0;o<r;o++)l.push(i(Ul,null,3,"sl_0"));return l};return n("div",null,{class:"flex flex-col w-full items-center justify-around mx-10"},[n("div",null,{class:"flex flex-row gap-3 items-center justify-center"},[n("p",null,{class:"text-secondary-red font-bold text-[16px]"},u(a=>a.name,[t],"p0.name"),3,null),n("div",null,{class:"text-yellow-500 flex flex-row"},[e(t.rating),t.rating%1!=0&&i(Sf,null,3,"sl_1")],1,null)],1,null),n("p",null,{class:"text-primary-blue font-semibold  text-[14px] text-center"},u(a=>a.testimonial,[t],"p0.testimonial"),3,null)],1,"sl_2")},r_=t=>{const e=b(g(s_,"s_ZS48Bh4qLTw")),a=t.testimonials.map((l,r)=>i(e,{index:r,get name(){return l.Name},get testimonial(){return l.Text},get rating(){return l.Rating},[s]:{name:h(l,"Name"),testimonial:h(l,"Text"),rating:h(l,"Rating")}},3,r));return n("div",null,{class:"relative w-full flex items-center justify-center"},n("div",null,{class:"my-5 sm:w-[80%] md:w-[60%] w-full flex items-center bg-white/80 backdrop-blur-sm rounded-full p-2 overflow-hidden"},i(Et,{slides:a,hasPagination:!1,slidesQty:1,addSpace:!1,get id(){return`header_Carousel_testimonials_${t.isMobile??!1?"mobile":"desk"}`},[s]:{hasPagination:s,slidesQty:s,addSpace:s,id:u(l=>`header_Carousel_testimonials_${l.isMobile??!1?"mobile":"desk"}`,[t],'`header_Carousel_testimonials_${p0.isMobile??false?"mobile":"desk"}`')}},3,"sl_3"),1,null),1,"sl_4")},$r=b(g(r_,"s_Kgfw0buq0zs")),i_=t=>i(G,{children:n("div",{class:`${t.data.Display&&t.data.Display?"flex flex-col":"hidden"} overflow-hidden bg-black rounded-bl-full rounded-tl-full text-white gap-1  max-[1000px]:w-full min-[1000px]:max-w-[420px] max-[1000px]:rounded-[30px]`},null,[n("div",null,{class:"md:block hidden bg-white w-full text-black flex flex-row text-[8px] font-bold tracking-[4px] whitespace-nowrap"},"PROMO PROMO PROMO PROMO PROMO PROMO PROMO PROMO PROMO PROMO",3,null),n("div",null,{class:"flex flex-row items-center"},[n("div",null,{class:"animate-[bounce_2s_ease-in-out_infinite] m-2 bg-primary-blue bg-opacity-40 p-2 inline-block items-center justify-center rounded-full"},n("div",null,{class:"bg-primary-blue flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 p-2 shadow-md"},n("div",null,{class:"bg-blue-500 flex h-[35px] w-[35px] items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md"},i(bf,{class:"fill-white font-bold text-[20px]",[s]:{class:s}},3,"K5_0"),1,null),1,null),1,null),n("div",null,{class:"flex flex-col"},[i(M,{get text(){return t.data.Title},classN:"!text-white",[s]:{text:u(e=>e.data.Title,[t],'p0.data["Title"]'),classN:s}},3,"K5_1"),i(M,{get text(){return t.data.Caption},classN:"!text-[12px] !text-white",[s]:{text:u(e=>e.data.Caption,[t],'p0.data["Caption"]'),classN:s}},3,"K5_2")],1,null)],1,null),n("div",null,{class:"md:block hidden bg-white w-full text-black flex flex-row text-[8px] font-bold tracking-[4px] whitespace-nowrap"},"PROMO PROMO PROMO PROMO PROMO PROMO PROMO PROMO PROMO PROMO",3,null)],1,null)},1,"K5_3"),vr=b(g(i_,"s_Qm8J7nekmjE")),o_=()=>{const[t,e,a,l,r]=U();e.value=!e.value;const o=l.value.value.split(", ")[0];e.value&&(t.value=a.data.HeroForm.ActionButton.Link.replace("=pConf=","").replace("streetInput",o).replace("zipInput",r.value.value))},u_=()=>{const[t,e]=U();window.localStorage.getItem("sendform_leaving")!="true"?e.value=!0:t.value=!1},c_=t=>(z(),n("div",null,{class:"flex items-center justify-between gap-1"},[n("div",null,{class:"flex flex-col gap-1 max-[1000px]:gap-2"},[t.slide.Logo.data&&i(A,{clasN:"w-[160px]",width:"1667",get media(){return t.slide.Logo.data.attributes},[s]:{clasN:s,width:s,media:u(e=>e.slide.Logo.data.attributes,[t],'p0.slide["Logo"]["data"]["attributes"]')}},3,"2R_1"),n("div",null,{class:"mx-3 max-[1000px]:hidden"},i(M,{classN:"text-[13px]",get text(){return t.slide.Paragraph},[s]:{classN:s,text:u(e=>e.slide.Paragraph,[t],'p0.slide["Paragraph"]')}},3,"2R_2"),1,null),i(tt,{get text(){return t.slide.Buttons[0].Text},get link(){return t.slide.Buttons[0].Link},[s]:{text:u(e=>e.slide.Buttons[0].Text,[t],'p0.slide["Buttons"][0]["Text"]'),link:u(e=>e.slide.Buttons[0].Link,[t],'p0.slide["Buttons"][0]["Link"]')}},3,"2R_3")],1,null),i(ja,{clasN:"rounded-full w-[150px] mr-[30px] max-[1000px]:w-[40%]",get media(){return t.slide.Media.data.attributes},get alt(){return t.slide.Media.data.attributes.alternativeText},get title(){return t.slide.Media.data.attributes.caption},autoplay:!0,loop:!0,muted:!0,[s]:{clasN:s,media:u(e=>e.slide.Media.data.attributes,[t],'p0.slide["Media"]["data"]["attributes"]'),alt:u(e=>e.slide.Media.data.attributes.alternativeText,[t],'p0.slide["Media"]["data"]["attributes"]["alternativeText"]'),title:u(e=>e.slide.Media.data.attributes.caption,[t],'p0.slide["Media"]["data"]["attributes"]["caption"]'),autoplay:s,loop:s,muted:s}},3,"2R_4")],1,"2R_5")),d_=t=>{const[e]=U();return n("div",{class:`flex h-[200px] items-center  justify-center overflow-hidden bg-white   ${t.isMobile??!1?"w-full max-w-[420px] rounded-full min-[1000px]:hidden":"w-[420px] rounded-br-full rounded-tr-full bg-white/60 backdrop-blur-sm border border-white/60 max-[1000px]:hidden"}`},null,i(Et,{slides:e,hasArrows:!1,slidesQty:1,get id(){return`header_car_${t.isMobile??!1?"mobile":"desk"}`},[s]:{hasArrows:s,slidesQty:s,id:u(a=>`header_car_${a.isMobile??!1?"mobile":"desk"}`,[t],'`header_car_${p0.isMobile??false?"mobile":"desk"}`')}},3,"2R_6"),1,"2R_7")},p_=()=>{const[t,e,a,l]=U();clearTimeout(l.value),l.value=setTimeout(()=>{t.value.value.length>2&&fetch(`/api/get-streets?q=${encodeURIComponent(t.value.value)}`).then(r=>r.json()).then(r=>{const o=r.data;o.length===0?e.value="notfound":e.value="success",a.value=o})},1e3)},f_=t=>{z();const e=t.data.Testimonials.length<1,a=C(n("input",null,null,null,3,"2R_0")),l=C(n("input",null,null,null,3,null)),r=C(""),o=C(!1),c=C(!1),p=C(),d=C([]),f=C("none"),x=C(1e3);wt(B("s_OSAER37KIRU",[x]));const m=g(o_,"s_fq93imJ971Y",[r,o,t,a,l]),$=g(u_,"s_onW18RDz0a0",[o,c]),y=b(g(c_,"s_bR2jjpv9PC0")),P=t.data.HeroCarSlides.map((v,L)=>i(y,{slide:v},3,L)),w=b(g(d_,"s_mBlTNPrtMiQ",[P])),D=g(p_,"s_r2MqT6I0l2Y",[a,f,d,p]);return i(G,{children:[n("div",null,{class:"relative flex h-[80vh] max-h-[750px] w-full items-center "},[n("div",null,{class:u(v=>`fixed bottom-0 left-0 right-0 bg-white top-${v.value?"0 z-[200]":"[100vh] -z-[200]"}  transition-all duration-1000 ease-in-out`,[o],'`fixed bottom-0 left-0 right-0 bg-white top-${p0.value?"0 z-[200]":"[100vh] -z-[200]"}  transition-all duration-1000 ease-in-out`')},[n("button",null,{"aria-label":"Close popup",class:'absolute right-2  mt-2 mx-0" bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] focus:outline-none z-[600]',onClick$:$},n("div",null,{class:"px-3 flex flex-row items-center text-xs gap-2"},["Back to site ",i(Pl,null,3,"2R_8")],1,null),1,null),n("iframe",null,{src:u(v=>v.value,[r],"p0.value"),title:"load popup",class:"h-full w-full",frameBorder:"0"},null,3,null)],1,null),n("div",null,null,c.value&&window.localStorage.getItem("sendform_leaving")!="true"?i(Ll,{signalMainPopup:o,signalPopupLeaving:c,[s]:{signalMainPopup:s,signalPopupLeaving:s}},3,"2R_9"):null,1,null),n("video",{poster:gt(t.data.VideoBGDesktop.data.attributes.caption)},{class:"absolute left-0 top-0 -z-10 h-full w-full object-cover",preload:"auto",autoplay:!0,playsInline:!0,loop:!0,muted:!0},n("source",{src:gt(t.data[`${x.value<=800?"VideoBGMobile":"VideoBGDesktop"}`].data.attributes.url)+"#t=0.1"},{type:"video/mp4"},null,3,null),1,null),n("div",null,{class:"flex flex-col items-center justify-between h-full w-full md:mb-10"},[n("div",null,{class:"flex h-full w-full items-center justify-between max-[1000px]:flex-col max-[1000px]:px-4"},[n("div",null,{class:"flex flex-col gap-4"},[n("div",null,{class:"opacity-0"},i(vr,{get data(){return t.bannerData},[s]:{data:u(v=>v.bannerData,[t],"p0.bannerData")}},3,"2R_10"),1,null),i(w,null,3,"2R_11")],1,null),n("div",null,{class:"flex flex-col gap-4"},[i(vr,{get data(){return t.bannerData},[s]:{data:u(v=>v.bannerData,[t],"p0.bannerData")}},3,"2R_12"),n("div",null,{class:"flex w-[420px] !z-[5] flex-col items-center justify-center gap-3 rounded-bl-full rounded-tl-full bg-white/60 backdrop-blur-sm max-[1000px]:mb-8 max-[1000px]:w-full max-[1000px]:max-w-[420px] max-[1000px]:rounded-[30px] max-[1000px]:py-2 max-[1000px]:my-5 min-[1000px]:h-[200px] border border-white/60 "},[n("div",{class:`absolute left-10 right-10 top-[90%] flex max-h-[200px] flex-col gap-3 overflow-y-auto rounded-xl bg-white p-6 text-primary-blue shadow-lg ${f.value==="none"||f.value==="selected"?"hidden":""}`},null,[u(v=>v.value.length===0?"Not found":"",[d],'p0.value.length===0?"Not found":""'),d.value.map((v,L)=>n("div",{onClick$:B("s_b1eZjTuNLgA",[a,v,f,l])},{class:"grid items-center gap-4 hover:cursor-pointer",style:{gridTemplateColumns:"20px 1fr"}},[i(Dl,{class:"w-6 text-secondary-red",[s]:{class:s}},3,"2R_13"),n("span",null,{class:"text-[14px]"},S(v,"address"),1,null)],0,L))],1,null),n("div",null,{class:" text-center text-[20px] font-[600] text-primary-blue "},u(v=>v.data.HeroForm.Title,[t],'p0.data["HeroForm"]["Title"]'),3,null),n("div",null,{class:"flex w-full items-center gap-3 px-6  "},n("input",{ref:a},{class:"w-[100%] rounded-full px-3 py-2 placeholder-primary-blue",placeholder:"Address Search",type:"text",onKeyUp$:D},null,3,null),1,null),i(tt,{get text(){return t.data.HeroForm.ActionButton.Text},onClick:m,[s]:{text:u(v=>v.data.HeroForm.ActionButton.Text,[t],'p0.data["HeroForm"]["ActionButton"]["Text"]'),onClick:s}},3,"2R_14")],1,null)],1,null)],1,null),e?null:n("div",null,{class:"block max-[1000px]:hidden w-full"},i($r,{get testimonials(){return t.data.Testimonials},[s]:{testimonials:u(v=>v.data.Testimonials,[t],'p0.data["Testimonials"]')}},3,"2R_15"),1,"2R_16")],1,null)],1,null),n("div",null,{class:"flex flex-col  justify-evenly items-center bg-gradient-to-r from-[#3d76c1] to-[#3568ae] px-4 pt-4"},[i(w,{isMobile:!0,[s]:{isMobile:s}},3,"2R_17"),e?null:n("div",null,{class:"max-[1000px]:block hidden w-full"},i($r,{get testimonials(){return t.data.Testimonials},isMobile:!0,[s]:{testimonials:u(v=>v.data.Testimonials,[t],'p0.data["Testimonials"]'),isMobile:s}},3,"2R_18"),1,"2R_19")],1,null)]},1,"2R_20")},g_=b(g(f_,"s_S18xoZmdQUw")),x_=t=>{const e=t.data.Logo.data.attributes,a=t.data.Media.data.attributes;return n("div",null,{class:"mb-4 flex flex-row-reverse max-w-[1200px] items-center justify-center gap-4 self-center px-8 max-[800px]:flex-col-reverse"},[n("div",null,{class:"flex w-[400px] items-center justify-center self-center p-4 min-[800px]:w-[40%]"},i(A,{media:a,width:400,height:500,[s]:{width:s,height:s}},3,"a2_0"),1,null),n("div",null,{class:"flex flex-col items-center justify-center gap-4 min-[800px]:w-[60%]"},[n("div",null,{class:"max-w-[470px]"},i(A,{media:e,width:1230,height:230,[s]:{width:s,height:s}},3,"a2_1"),1,null),n("div",null,{class:"flex items-start gap-2"},[n("div",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(l=>l.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"text-center text-[28px] font-bold text-secondary-red max-sm:text-[18px]"},u(l=>l.data.Subtitle,[t],'p0.data["Subtitle"]'),3,null)],3,null),n("div",null,{class:"text-primary-blue"},[i(M,{classN:"text-justify max-sm:text-[15px] text-[18px] text-[#2E5899]",get text(){return t.data.Paragraph},[s]:{classN:s,text:u(l=>l.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"a2_2"),n("div",null,{class:"rounded-[20px] bg-white"},i(Un,{get faqs(){return t.parGFIPlans},[s]:{faqs:u(l=>l.parGFIPlans,[t],"p0.parGFIPlans")}},3,"a2_3"),1,null)],1,null),n("div",null,{class:"flex gap-4"},t.data.Buttons.map((l,r)=>i(tt,{get text(){return l.Text},get link(){return l.Link},[s]:{text:h(l,"Text"),link:h(l,"Link")}},3,r)),1,null)],1,null)],1,"a2_4")},m_=b(g(x_,"s_M9NFBwXMc48")),h_=t=>n("div",null,{class:"flex items-center justify-evenly gap-4 px-8 py-6 max-[1200px]:flex-col"},t.data.map((e,a)=>n("div",null,{class:" flex max-w-[400px] flex-col items-center gap-2 text-center text-primary-blue"},[i(ha,{get media(){return e.Media.data.attributes},width:"w-[360px]",color:"bg-primary-blue",[s]:{media:h(e.Media.data,"attributes"),width:s,color:s}},3,"pO_0"),n("h2",null,{class:"text-[24px] font-[700]"},S(e,"Title"),1,null),n("p",null,{class:"text-[17px] font-[400]"},S(e,"Paragraph"),1,null),i(tt,{get text(){return e.Buttons[0].Text},get link(){return e.Buttons[0].Link},[s]:{text:h(e.Buttons[0],"Text"),link:h(e.Buttons[0],"Link")}},3,"pO_1")],1,a)),1,"pO_2"),b_=b(g(h_,"s_PyTSx8biYlE")),$_=t=>{const e=t.data.pageHome.data.attributes,a=t.data.sectionProsRta.data.attributes.Pros,l=e.ProsPicture.data.attributes,r=t.data.generalPromoBanner.data.attributes;return n("div",null,{class:"relative ",onClick$:B("s_TkQ204PTgK8")},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-[100vh] -z-10 bg-white"},null,3,null),i(g_,{data:e,bannerData:r},3,"Ee_0"),i(vo,{data:{prosPar:e.ProsPar,prosData:a,prosMap:l}},3,"Ee_1"),i(Ve,{get data(){return e.ParACP},reverse:!0,textPercentage:60,[s]:{data:h(e,"ParACP"),reverse:s,textPercentage:s}},3,"Ee_2"),n("div",null,{class:"flex w-full justify-center bg-[#ebf4fc]"},i(m_,{data:e.ParGFServices[0],get parGFIPlans(){return e.ParGFIPlans},[s]:{parGFIPlans:h(e,"ParGFIPlans")}},3,"Ee_3"),1,null),i(We,{data:e.ParGFServices.slice(1,e.ParGFServices.length)},3,"Ee_4"),n("div",null,{class:"bg-[#ebf4fc]"},i(b_,{get data(){return e.SugsPages},[s]:{data:h(e,"SugsPages")}},3,"Ee_5"),1,null)],1,"Ee_6")},v_=b(g($_,"s_G08oK4nfxwg")),y_=t=>i(G,{children:t.faqList.map((e,a)=>z(i(Ga,{get title(){return e.Title},classContainer:"text-center bg-white text-primary-blue text-base shadow-xl",classChild:"text-sm md:text-base border-primary-blue",children:[i(M,{get text(){return e.Paragraph},classN:"text-primary-blue p-2",[s]:{text:h(e,"Paragraph"),classN:s}},3,"eN_0"),e.Disclaimer!==null?n("div",null,{class:"flex flex-row items-center justify-center gap-2"},[i(to,{class:"text-secondary-red",[s]:{class:s}},3,"eN_1"),i(M,{get text(){return e.Disclaimer.Text},classN:"text-[10px] text-primary-dark-blue",[s]:{text:h(e.Disclaimer,"Text"),classN:s}},3,"eN_2")],1,"eN_3"):null,e.Table!==null?n("div",null,{class:"flex flex-col items-center justify-center"},n("table",null,{class:"border-collapse border rounded-2xl border-gray-200 w-full"},n("tbody",null,null,e.Table.map((l,r)=>{var o,c;return z(n("tr",{class:(o=l.ColumnThree)!=null&&o.includes("Title")?"bg-white text-start":r===0?"text-white bg-primary-blue":r%2===1?"bg-blue-100 text-primary-blue text-[13px]":"bg-blue-200 text-primary-blue text-[13px]"},null,(c=l.ColumnThree)!=null&&c.includes("Title")?n("th",null,{colSpan:2},i(M,{get text(){return l.ColumnOne},classN:"px-2 text-start",[s]:{text:h(l,"ColumnOne"),classN:s}},3,"eN_4"),1,"eN_5"):i(G,{children:[n("td",null,null,i(M,{get text(){return l.ColumnOne},classN:`text-start px-2 ${r===0?"text-white":"text-primary-blue"}`,[s]:{text:h(l,"ColumnOne")}},3,"eN_6"),1,null),n("td",null,null,i(M,{get text(){return l.ColumnTwo},classN:`text-start px-2 ${r===0?"text-white":"text-primary-blue"}`,[s]:{text:h(l,"ColumnTwo")}},3,"eN_7"),1,null)]},1,"eN_8"),1,r))}),1,null),1,null),1,"eN_9"):null],[s]:{title:h(e,"Title"),classContainer:s,classChild:s}},1,a)))},1,"eN_10"),__=b(g(y_,"s_HjOYZib6Xes")),w_=t=>{z();const e=t.data.Slug.endsWith("-es");return n("div",null,{class:"flex  w-full flex-col items-center justify-center px-8 text-primary-blue"},[n("div",null,{class:"flex !max-w-[1200px] items-center justify-evenly gap-4 py-16 max-[800px]:flex-col"},[n("h1",null,{class:"w-[40%] text-center text-[42px] font-[600]  max-sm:text-[28px] leading-10 max-[800px]:w-full"},u(a=>a.data.Title,[t],'p0.data["Title"]'),3,null),i(A,{width:"833",height:"539",clasN:" rounded-2xl shadow-xl w-[40%] max-[800px]:w-full",get media(){return t.data.Cover.data.attributes},[s]:{width:s,height:s,clasN:s,media:u(a=>a.data.Cover.data.attributes,[t],'p0.data["Cover"]["data"]["attributes"]')}},3,"cD_0")],1,null),n("div",null,{class:"mb-8 !max-w-[1200px]"},i(M,{get text(){return t.data.Description},classN:"text-justify",[s]:{text:u(a=>a.data.Description,[t],'p0.data["Description"]'),classN:s}},3,"cD_1"),1,null),t.data.FAQ.length>0&&n("div",null,{class:"flex w-full flex-col m-4 max-w-[800px]"},[n("h3",null,{class:"text-center text-[38px] font-[600] leading-10 text-primary-blue max-[800px]:text-[28px]"},e?"¿Tienes preguntas?":"Do you have questions?",1,null),n("h4",null,{class:"text-center text-[18px] font-[500] leading-10 text-primary-blue max-[800px]:text-[14px]"},e?"Aquí puedes empezar.":"Here is where to start.",1,null),i(__,{get faqList(){return t.data.FAQ},[s]:{faqList:u(a=>a.data.FAQ,[t],'p0.data["FAQ"]')}},3,"cD_2")],1,"cD_3")],1,"cD_4")},S_=b(g(w_,"s_QI52uAygONM")),T_=(t,e)=>`query QueryPostPage {
        posts (filters: {Slug: {eq: "${t}${e==="es-419"?"-es":""}"}} pagination:{limit:1} locale:"${e}") {
          data {
            attributes {
              Title
              Date
              Description
              Slug
              Cover {
                ${_}
              }

              FAQ{
                Title
                Paragraph
                Disclaimer{
                Icon{
                    ${_}
                }
                Title
                Text
                Caption
                }

                Table(pagination: { limit: 50 }){
                ColumnOne
                ColumnTwo
                ColumnThree
                }
              }

              ${H} 
            }
          }
        }
      }`,D_=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang;let a={};if(e=="en"||e=="es-419")return a=await Q(go,e),{...a,type:"home"};const l=e.includes("es/")?"es-419":"en",r=e.includes("es/")?e.split("es/")[1]:e;return a=await Qa(T_(r,l),l),{...a,type:a.pageData.data.posts.data.length>0?"post":"404"}},Gs=R(g(D_,"s_Up0e7VSBoHc")),P_=()=>{var l,r,o,c,p;z();const t=Gs(),e=t.value.type=="home",a=e?(p=(c=(o=(r=(l=t.value)==null?void 0:l.pageData)==null?void 0:r.data)==null?void 0:o.generalMarquee)==null?void 0:c.data)==null?void 0:p.attributes:void 0;return i(F,{get data(){return t.value.layoutData},marqueeData:a,showHeader:!1,showMarquee:e,children:[t.value.type=="home"&&n("h1",null,{class:"absolute opacity-0"},"Rural Telecommunications of America Inc.",3,"2d_0"),t.value.type=="home"?i(v_,{get data(){return t.value.pageData.data},[s]:{data:u(d=>d.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"2d_1"):t.value.type=="post"?i(S_,{get data(){return t.value.pageData.data.posts.data[0].attributes},[s]:{data:u(d=>d.value.pageData.data.posts.data[0].attributes,[t],'p0.value["pageData"]["data"]["posts"]["data"][0]["attributes"]')}},3,"2d_2"):i(yo,null,3,"2d_3")],[s]:{data:u(d=>d.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"2d_4")},k_=b(g(P_,"s_0WMiPe1m3D0")),L_=({resolveValue:t})=>{const e=t(Gs),a=e.type;let l;return a=="home"?l=e.pageData.data.pageHome.data.attributes.SEO:a=="post"?(l=e.pageData.data.posts.data[0].attributes.SEO,l||(l={MetaTitle:e.pageData.data.posts.data[0].attributes.Title,MetaDescription:e.pageData.data.posts.data[0].attributes.Description,preventIndexing:!0,Keywords:e.pageData.data.posts.data[0].attributes.Title})):l={MetaTitle:"Not found"},V(l)},C_=Object.freeze(Object.defineProperty({__proto__:null,default:k_,head:L_,usePageData:Gs},Symbol.toStringTag,{value:"Module"})),M_=[Vd],q=()=>zp,j_=[["forms/",[q,()=>Vp],"/forms/",["q-CPQL4AzV.js","q-Be-Iv5zg.js"]],["[...lang]/api/get-streets/",[q,()=>Yp],"/[...lang]/api/get-streets/",["q-CPQL4AzV.js"]],["[...lang]/api/graphql/",[q,()=>Kp],"/[...lang]/api/graphql/",["q-CPQL4AzV.js"]],["[...lang]/api/sendmail/",[q,()=>Xp],"/[...lang]/api/sendmail/",["q-CPQL4AzV.js","q-DNK43GNe.js"]],["[...lang]/api/survey-pre-exit/",[q,()=>ef],"/[...lang]/api/survey-pre-exit/",["q-CPQL4AzV.js"]],["[...lang]/appreciation-giveaway/",[q,()=>Pg],"/[...lang]/appreciation-giveaway/",["q-CPQL4AzV.js","q-VPKiWkWX.js"]],["[...lang]/appreciation-lead/",[q,()=>Ng],"/[...lang]/appreciation-lead/",["q-CPQL4AzV.js","q-BN-qSSXl.js"]],["[...lang]/aup/",[q,()=>Qg],"/[...lang]/aup/",["q-CPQL4AzV.js","q-kqy376_s.js"]],["[...lang]/awards/",[q,()=>a0],"/[...lang]/awards/",["q-CPQL4AzV.js","q-Cfx2zZEw.js"]],["[...lang]/bastrop-project/",[q,()=>k0],"/[...lang]/bastrop-project/",["q-CPQL4AzV.js","q-CHpKT4f_.js"]],["[...lang]/blog/",[q,()=>F0],"/[...lang]/blog/",["q-CPQL4AzV.js","q-9-6wdrA_.js"]],["[...lang]/board-members/",[q,()=>Z0],"/[...lang]/board-members/",["q-CPQL4AzV.js","q-DMunuWg2.js"]],["[...lang]/broadbandlabels/",[q,()=>mx],"/[...lang]/broadbandlabels/",["q-CPQL4AzV.js","q-C1bGPTjW.js"]],["[...lang]/business/",[q,()=>Sx],"/[...lang]/business/",["q-CPQL4AzV.js","q-BIlBS7BU.js"]],["[...lang]/careers/",[q,()=>Hx],"/[...lang]/careers/",["q-CPQL4AzV.js","q-6HtwOxnv.js"]],["[...lang]/client-services-agreement-general-terms-and-conditions/",[q,()=>Xx],"/[...lang]/client-services-agreement-general-terms-and-conditions/",["q-CPQL4AzV.js","q-Dgf59cOi.js"]],["[...lang]/contact-us/",[q,()=>im],"/[...lang]/contact-us/",["q-CPQL4AzV.js","q-C8VZulN9.js"]],["[...lang]/cookies/",[q,()=>xm],"/[...lang]/cookies/",["q-CPQL4AzV.js","q-BDxP-Etw.js"]],["[...lang]/deals/",[q,()=>Lm],"/[...lang]/deals/",["q-CPQL4AzV.js","q-C4Wnhbz3.js"]],["[...lang]/faq/",[q,()=>Bm],"/[...lang]/faq/",["q-CPQL4AzV.js","q-C0Q-RPdq.js"]],["[...lang]/free-install/",[q,()=>Um],"/[...lang]/free-install/",["q-CPQL4AzV.js","q-DLg_S1UE.js"]],["[...lang]/gfsn/",[q,()=>dh],"/[...lang]/gfsn/",["q-CPQL4AzV.js","q-DRE9nV5n.js"]],["[...lang]/gigfast-cloud/",[q,()=>$h],"/[...lang]/gigfast-cloud/",["q-CPQL4AzV.js","q-BvT2CXAe.js"]],["[...lang]/gigfast-internet-support/",[q,()=>Eh],"/[...lang]/gigfast-internet-support/",["q-CPQL4AzV.js","q-CM_Ud4MX.js"]],["[...lang]/gigfast-internet/",[q,()=>Qh],"/[...lang]/gigfast-internet/",["q-CPQL4AzV.js","q-BNnRi4Wy.js"]],["[...lang]/gigfast-iot/",[q,()=>Kh],"/[...lang]/gigfast-iot/",["q-CPQL4AzV.js","q-TRq8QRqh.js"]],["[...lang]/gigfast-tv-privacy-policy/",[q,()=>sb],"/[...lang]/gigfast-tv-privacy-policy/",["q-CPQL4AzV.js","q-BGXZleK0.js"]],["[...lang]/gigfast-tv-support/",[q,()=>bb],"/[...lang]/gigfast-tv-support/",["q-CPQL4AzV.js","q-8lanA9Rg.js"]],["[...lang]/gigfast-tv/",[q,()=>Bb],"/[...lang]/gigfast-tv/",["q-CPQL4AzV.js","q-Dr8mDYlT.js"]],["[...lang]/gigfast-voice-support/",[q,()=>Hb],"/[...lang]/gigfast-voice-support/",["q-CPQL4AzV.js","q-C0wyQE79.js"]],["[...lang]/gigfast-voice/",[q,()=>l1],"/[...lang]/gigfast-voice/",["q-CPQL4AzV.js","q-BQWp9see.js"]],["[...lang]/giving-back/",[q,()=>d1],"/[...lang]/giving-back/",["q-CPQL4AzV.js","q-Dhcmq7JT.js"]],["[...lang]/goldsmith-tt/",[q,()=>$1],"/[...lang]/goldsmith-tt/",["q-CPQL4AzV.js","q-LuRiKCIJ.js"]],["[...lang]/internet-transparency-statement/",[q,()=>P1],"/[...lang]/internet-transparency-statement/",["q-CPQL4AzV.js","q-DVEguNAS.js"]],["[...lang]/leadership-team/",[q,()=>A1],"/[...lang]/leadership-team/",["q-CPQL4AzV.js","q-Bx51r1VO.js"]],["[...lang]/legal/",[q,()=>z1],"/[...lang]/legal/",["q-CPQL4AzV.js","q-Btpgi5Ad.js"]],["[...lang]/local-weather-stations/",[q,()=>Y1],"/[...lang]/local-weather-stations/",["q-CPQL4AzV.js","q-TVEL1EK0.js"]],["[...lang]/news/",[q,()=>l$],"/[...lang]/news/",["q-CPQL4AzV.js","q-BmA2qTtL.js"]],["[...lang]/our-story/",[q,()=>d$],"/[...lang]/our-story/",["q-CPQL4AzV.js","q-E0DNxHqG.js"]],["[...lang]/portability/",[q,()=>y$],"/[...lang]/portability/",["q-CPQL4AzV.js","q-SiPTNSup.js"]],["[...lang]/post_slug/",[q,()=>k$],"/[...lang]/post_slug/",["q-CPQL4AzV.js","q-BNFWwz_l.js"]],["[...lang]/privacy-policy/",[q,()=>I$],"/[...lang]/privacy-policy/",["q-CPQL4AzV.js","q-BwO9J_Da.js"]],["[...lang]/pumptopper/",[q,()=>G$],"/[...lang]/pumptopper/",["q-CPQL4AzV.js","q-8Y6x6bjJ.js"]],["[...lang]/referral-program/",[q,()=>tv],"/[...lang]/referral-program/",["q-CPQL4AzV.js","q-Bpsthaz0.js"]],["[...lang]/residential/",[q,()=>ov],"/[...lang]/residential/",["q-CPQL4AzV.js","q-6XifxzfZ.js"]],["[...lang]/services-broadbandlabels/",[q,()=>hv],"/[...lang]/services-broadbandlabels/",["q-CPQL4AzV.js","q-Ahz1ZTz7.js"]],["[...lang]/sheridan-bbq/",[q,()=>Lv],"/[...lang]/sheridan-bbq/",["q-CPQL4AzV.js","q-CM5XtxXt.js"]],["[...lang]/support/",[q,()=>Ov],"/[...lang]/support/",["q-CPQL4AzV.js","q-DAzQDDKi.js"]],["[...lang]/testimonials/",[q,()=>Wv],"/[...lang]/testimonials/",["q-CPQL4AzV.js","q-BHsxmz3H.js"]],["[...lang]/texas/",[q,()=>ay],"/[...lang]/texas/",["q-CPQL4AzV.js","q-B-vQGYoY.js"]],["[...lang]/wholesale/",[q,()=>cy],"/[...lang]/wholesale/",["q-CPQL4AzV.js","q-CU3eTlcX.js"]],["[...lang]/winners-circle/",[q,()=>$y],"/[...lang]/winners-circle/",["q-CPQL4AzV.js","q-2Dtc5vx-.js"]],["[...lang]/zane-smith-sponsorship/",[q,()=>qy],"/[...lang]/zane-smith-sponsorship/",["q-CPQL4AzV.js","q-D6HZltJl.js"]],["[...lang]/texas/[slug]/local-blog/",[q,()=>Hy],"/[...lang]/texas/[slug]/local-blog/",["q-CPQL4AzV.js","q-BNUSQ6hj.js"]],["[...lang]/texas/[slug]/",[q,()=>n_],"/[...lang]/texas/[slug]/",["q-CPQL4AzV.js","q-COfcnlV4.js"]],["[...lang]",[q,()=>C_],"/[...lang]",["q-CPQL4AzV.js","q-BRkH08oD.js"]]],A_=[],E_=!0,_o="/",N_=!0,K_={routes:j_,serverPlugins:M_,menus:A_,trailingSlash:E_,basePathname:_o,cacheModules:N_};export{s as A,M_ as B,j_ as C,A_ as D,E_ as E,G as F,_o as G,N_ as H,U_ as Q,V_ as R,ut as S,bu as _,Q_ as a,z_ as b,Rc as c,b as d,rt as e,i as f,n as g,u as h,g as i,F_ as j,Z as k,S as l,Vt as m,qn as n,Ae as o,vn as p,K_ as q,U as r,R_ as s,Tl as t,W_ as u,H_ as v,Z_ as w,G_ as x,pr as y,Y_ as z};
