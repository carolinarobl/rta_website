import"./q-BOplm1XY.js";import{r as e}from"./q-BEBqBiCH.js";import"@supabase/supabase-js";import"marked";import"jspdf";import"html2canvas";export{e as default};
