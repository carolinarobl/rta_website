import"./q-BBAWRbWO.js";import{r as e}from"./q-DEI-V-0K.js";import"marked";import"@supabase/supabase-js";import"jspdf";import"html2canvas";export{e as default};
