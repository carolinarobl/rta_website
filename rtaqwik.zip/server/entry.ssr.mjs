import"./q-BfAyfg26.js";import{r as e}from"./q-Bbrfiwkf.js";import"marked";import"@supabase/supabase-js";import"jspdf";import"html2canvas";export{e as default};
