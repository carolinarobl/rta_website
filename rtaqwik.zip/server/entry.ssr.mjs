import"./assets/@qwik-city-plan-05f0616a.mjs";import{r as p}from"./assets/entry.ssr-04bb37b9.mjs";import"marked";export{p as default};
