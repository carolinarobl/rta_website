import"./q-5Fn9HNlx.js";import{r as e}from"./q-BbgwdiS0.js";import"marked";import"@supabase/supabase-js";import"jspdf";import"html2canvas";export{e as default};
