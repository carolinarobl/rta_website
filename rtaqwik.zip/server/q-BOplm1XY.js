import{createClient as oo}from"@supabase/supabase-js";import{parse as rr}from"marked";import{jsPDF as uo}from"jspdf";import ir from"html2canvas";const co=!0,po=!1;/**
 * @license
 * @builder.io/qwik 1.8.0
 * Copyright Builder.io, Inc. All Rights Reserved.
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/QwikDev/qwik/blob/main/LICENSE
 */const qe=t=>t&&typeof t.nodeType=="number",or=t=>t.nodeType===9,Fe=t=>t.nodeType===1,ze=t=>{const e=t.nodeType;return e===1||e===111},go=t=>{const e=t.nodeType;return e===1||e===111||e===3},Rt=t=>t.nodeType===111,Ql=t=>t.nodeType===3,Ca=t=>t.nodeType===8,Ve=(t,...e)=>Hl(!1,t,...e),ur=(t,...e)=>{throw Hl(!1,t,...e)},Gl=(t,...e)=>Hl(!0,t,...e),Ie=()=>{},fo=t=>t,Hl=(t,e,...a)=>{const l=e instanceof Error?e:new Error(e);return console.error("%cQWIK ERROR","",l.message,...fo(a),l.stack),t&&setTimeout(()=>{throw l},0),l};const ol=t=>`Code(${t}) https://github.com/QwikDev/qwik/blob/main/packages/qwik/src/core/error/error.ts#L${8+t}`,it=(t,...e)=>{const a=ol(t,...e);return Gl(a,...e)},xo=()=>({isServer:co,importSymbol(t,e,a){var o;{const c=$i(a),p=(o=globalThis.__qwik_reg_symbols)==null?void 0:o.get(c);if(p)return p}if(!e)throw it(31,a);if(!t)throw it(30,e,a);const l=mo(t.ownerDocument,t,e).toString(),r=new URL(l);return r.hash="",import(r.href).then(c=>c[a])},raf:t=>new Promise(e=>{requestAnimationFrame(()=>{e(t())})}),nextTick:t=>new Promise(e=>{setTimeout(()=>{e(t())})}),chunkForSymbol:(t,e)=>[t,e??"_"]}),mo=(t,e,a)=>{const l=t.baseURI,r=new URL(e.getAttribute("q:base")??l,l);return new URL(a,r)};let Vl=xo();const Wv=t=>Vl=t,ul=()=>Vl,Tt=()=>Vl.isServer,Ma=t=>{const e=Object.getPrototypeOf(t);return e===Object.prototype||e===null},Ht=t=>!!t&&typeof t=="object",lt=t=>Array.isArray(t),Ee=t=>typeof t=="string",yt=t=>typeof t=="function",ut=t=>t&&typeof t.then=="function",cl=(t,e,a)=>{try{const l=t();return ut(l)?l.then(e,a):e(l)}catch(l){return a(l)}},Z=(t,e)=>ut(t)?t.then(e):e(t),Wl=t=>t.some(ut)?Promise.all(t):t,ea=t=>t.length>0?Promise.all(t):t,cr=t=>t!=null,ho=t=>new Promise(e=>{setTimeout(e,t)}),qt=[],gt={},ja=t=>typeof document<"u"?document:t.nodeType===9?t:t.ownerDocument,bo="q:renderFn",Dt="q:slot",dr="q:s",dl="q:style",$o="q:sstyle",pr="q:instance",gr=(t,e)=>t["qFuncs_"+e]||[],yo="q:id",Pl=Symbol("proxy target"),aa=Symbol("proxy flags"),Ot=Symbol("proxy manager"),s=Symbol("IMMUTABLE"),pl="_qc_",St=(t,e,a)=>t.setAttribute(e,a),Et=(t,e)=>t.getAttribute(e),Ul=t=>t.replace(/([A-Z])/g,"-$1").toLowerCase(),vo=t=>t.replace(/-./g,e=>e[1].toUpperCase()),_o=/^(on|window:|document:)/,fr="preventdefault:",Yl=t=>t.endsWith("$")&&_o.test(t),Jl=t=>{if(t.length===0)return qt;if(t.length===1){const a=t[0];return[[a[0],[a[1]]]]}const e=[];for(let a=0;a<t.length;a++){const l=t[a][0];e.includes(l)||e.push(l)}return e.map(a=>[a,t.filter(l=>l[0]===a).map(l=>l[1])])},Zl=(t,e,a,l)=>{if(e.endsWith("$"),e=kl(e.slice(0,-1)),a)if(lt(a)){const r=a.flat(1/0).filter(o=>o!=null).map(o=>[e,Ns(o,l)]);t.push(...r)}else t.push([e,Ns(a,l)]);return e},Es=["on","window:on","document:on"],wo=["on","on-window","on-document"],kl=t=>{let e="on";for(let a=0;a<Es.length;a++){const l=Es[a];if(t.startsWith(l)){e=wo[a],t=t.slice(l.length);break}}return e+":"+(t=t.startsWith("-")?Ul(t.slice(1)):t.toLowerCase())},Ns=(t,e)=>(t.$setContainer$(e),t),So=(t,e)=>{const a=t.$element$.attributes,l=[];for(let r=0;r<a.length;r++){const{name:o,value:c}=a.item(r);if(o.startsWith("on:")||o.startsWith("on-window:")||o.startsWith("on-document:")){const p=c.split(`
`);for(const d of p){const g=$l(d,e);g.$capture$&&di(g,t),l.push([o,g])}}}return l},To=(t,e)=>{Xl(Kl(t,void 0),e)},Bs=(t,e)=>{Xl(Kl(t,"document"),e)},Do=(t,e)=>{Xl(Kl(t,"window"),e)},Kl=(t,e)=>{const a=e!==void 0?e+":":"";return Array.isArray(t)?t.map(l=>`${a}on-${l}`):`${a}on-${t}`},Xl=(t,e)=>{if(e){const a=xn(),l=vt(a.$hostElement$,a.$renderCtx$.$static$.$containerState$);typeof t=="string"?l.li.push([kl(t),e]):l.li.push(...t.map(r=>[kl(r),e])),l.$flags$|=Ae}},Po=(t,e,a,l)=>{typeof CustomEvent=="function"&&t&&t.dispatchEvent(new CustomEvent(e,{detail:a,bubbles:l,composed:l}))},tn=(t,e,a=0)=>e.$proxyMap$.get(t)||(a!==0&&fl(t,a),Ia(t,e,void 0)),Ia=(t,e,a)=>{Oa(t),e.$proxyMap$.has(t);const l=e.$subsManager$.$createManager$(a),r=new Proxy(t,new xr(e,l));return e.$proxyMap$.set(t,r),r},gl=()=>{const t={};return fl(t,2),t},fl=(t,e)=>{Object.defineProperty(t,aa,{value:e,enumerable:!1})},ko=(t,e)=>{const a={};for(const l in t)e.includes(l)||(a[l]=t[l]);return a};class xr{constructor(e,a){this.$containerState$=e,this.$manager$=a}deleteProperty(e,a){if(2&e[aa])throw it(17);return typeof a=="string"&&delete e[a]&&(this.$manager$.$notifySubs$(lt(e)?void 0:a),!0)}get(e,a){var g;if(typeof a=="symbol")return a===Pl?e:a===Ot?this.$manager$:e[a];const l=e[aa]??0,r=bt(),o=!!(1&l),c=e["$$"+a];let p,d;if(r&&(p=r.$subscriber$),!(2&l)||a in e&&!Lo((g=e[s])==null?void 0:g[a])||(p=null),c?(d=c.value,p=null):d=e[a],p){const x=lt(e);this.$manager$.$addSub$(p,x?void 0:a)}return o?Co(d,this.$containerState$):d}set(e,a,l){if(typeof a=="symbol")return e[a]=l,!0;const r=e[aa]??0;if(2&r)throw it(17);const o=1&r?Oa(l):l;if(lt(e))return e[a]=o,this.$manager$.$notifySubs$(),!0;const c=e[a];return e[a]=o,c!==o&&this.$manager$.$notifySubs$(a),!0}has(e,a){if(a===Pl)return!0;const l=Object.prototype.hasOwnProperty;return!!l.call(e,a)||!(typeof a!="string"||!l.call(e,"$$"+a))}ownKeys(e){if(!(2&(e[aa]??0))){let l=null;const r=bt();r&&(l=r.$subscriber$),l&&this.$manager$.$addSub$(l)}return lt(e)?Reflect.ownKeys(e):Reflect.ownKeys(e).map(l=>typeof l=="string"&&l.startsWith("$$")?l.slice(2):l)}getOwnPropertyDescriptor(e,a){return lt(e)||typeof a=="symbol"?Object.getOwnPropertyDescriptor(e,a):{enumerable:!0,configurable:!0}}}const Lo=t=>t===s||mt(t),Co=(t,e)=>{if(Ht(t)){if(Object.isFrozen(t))return t;const a=Oa(t);if(a!==t||xi(a))return t;if(Ma(a)||lt(a))return e.$proxyMap$.get(a)||tn(a,e,1)}return t},Mo=(t,e=0)=>{for(let a=0;a<t.length;a++)e=(e<<5)-e+t.charCodeAt(a),e|=0;return Number(Math.abs(e)).toString(36)},jo=(t,e)=>`${Mo(t.$hash$)}-${e}`,mr=t=>{const e=t.join("|");if(e.length>0)return e},Ye=()=>{const t=xn(),e=vt(t.$hostElement$,t.$renderCtx$.$static$.$containerState$),a=e.$seq$||(e.$seq$=[]),l=t.$i$++;return{val:a[l],set:r=>a[l]=r,i:l,iCtx:t,elCtx:e}},Vt=t=>Object.freeze({id:Ul(t)}),Ce=(t,e)=>{const{val:a,set:l,elCtx:r}=Ye();if(a!==void 0)return;(r.$contexts$||(r.$contexts$=new Map)).set(t.id,e),l(!0)},da=(t,e)=>{const{val:a,set:l,iCtx:r,elCtx:o}=Ye();if(a!==void 0)return a;const c=hr(t,o,r.$renderCtx$.$static$.$containerState$);if(typeof e=="function")return l(xt(void 0,e,c));if(c!==void 0)return l(c);if(e!==void 0)return l(e);throw it(13,t.id)},Io=(t,e)=>{var r;let a=t,l=1;for(;a&&!((r=a.hasAttribute)!=null&&r.call(a,"q:container"));){for(;a=a.previousSibling;)if(Ca(a)){const o=a.__virtual;if(o){const c=o[pl];if(a===o.open)return c??vt(o,e);if(c!=null&&c.$parentCtx$)return c.$parentCtx$;a=o;continue}if(a.data==="/qv")l++;else if(a.data.startsWith("qv ")&&(l--,l===0))return vt(Aa(a),e)}a=t.parentElement,t=a}return null},Eo=(t,e)=>(t.$parentCtx$===void 0&&(t.$parentCtx$=Io(t.$element$,e)),t.$parentCtx$),hr=(t,e,a)=>{var o;const l=t.id;if(!e)return;let r=e;for(;r;){const c=(o=r.$contexts$)==null?void 0:o.get(l);if(c)return c;r=Eo(r,a)}},No=Vt("qk-error"),en=(t,e,a)=>{const l=Pt(e);if(Tt())throw t;{const r=hr(No,l,a.$static$.$containerState$);if(r===void 0)throw t;r.error=t}},Bo=new Set(["animationIterationCount","aspectRatio","borderImageOutset","borderImageSlice","borderImageWidth","boxFlex","boxFlexGroup","boxOrdinalGroup","columnCount","columns","flex","flexGrow","flexShrink","gridArea","gridRow","gridRowEnd","gridRowStart","gridColumn","gridColumnEnd","gridColumnStart","fontWeight","lineClamp","lineHeight","opacity","order","orphans","scale","tabSize","widows","zIndex","zoom","MozAnimationIterationCount","MozBoxFlex","msFlex","msFlexPositive","WebkitAnimationIterationCount","WebkitBoxFlex","WebkitBoxOrdinalGroup","WebkitColumnCount","WebkitColumns","WebkitFlex","WebkitFlexGrow","WebkitFlexShrink","WebkitLineClamp"]),Ao=t=>Bo.has(t),Va=(t,e,a)=>{e.$flags$&=~oa,e.$flags$|=gn,e.$slots$=[],e.li.length=0;const l=e.$element$,r=e.$componentQrl$,o=e.$props$,c=_t(t.$static$.$locale$,l,void 0,"qRender"),p=c.$waitOn$=[],d=Ea(t);d.$cmpCtx$=e,d.$slotCtx$=void 0,c.$subscriber$=[0,l],c.$renderCtx$=t,r.$setContainer$(t.$static$.$containerState$.$containerEl$);const g=r.getFn(c);return cl(()=>g(o),x=>Z(Tt()?Z(ea(p),()=>Z(yu(t.$static$.$containerState$,t),()=>ea(p))):ea(p),()=>{var h;if(e.$flags$&oa){if(!(a&&a>100))return Va(t,e,a?a+1:1);Ie(`Infinite loop detected. Element: ${(h=e.$componentQrl$)==null?void 0:h.$symbol$}`)}return{node:x,rCtx:d}}),x=>{var h;if(x===Vr){if(!(a&&a>100))return Z(ea(p),()=>Va(t,e,a?a+1:1));Ie(`Infinite loop detected. Element: ${(h=e.$componentQrl$)==null?void 0:h.$symbol$}`)}return en(x,l,t),{node:sn,rCtx:d}})},br=(t,e)=>({$static$:{$doc$:t,$locale$:e.$serverData$.locale,$containerState$:e,$hostElements$:new Set,$operations$:[],$postOperations$:[],$roots$:[],$addSlots$:[],$rmSlots$:[],$visited$:[]},$cmpCtx$:null,$slotCtx$:void 0}),Ea=t=>({$static$:t.$static$,$cmpCtx$:t.$cmpCtx$,$slotCtx$:t.$slotCtx$}),an=(t,e)=>{var a;return(a=e==null?void 0:e.$scopeIds$)!=null&&a.length?e.$scopeIds$.join(" ")+" "+Wa(t):Wa(t)},Wa=t=>{if(!t)return"";if(Ee(t))return t.trim();const e=[];if(lt(t))for(const a of t){const l=Wa(a);l&&e.push(l)}else for(const[a,l]of Object.entries(t))l&&e.push(a.trim());return e.join(" ")},xl=t=>{if(t==null)return"";if(typeof t=="object"){if(lt(t))throw it(0,t,"style");{const e=[];for(const a in t)if(Object.prototype.hasOwnProperty.call(t,a)){const l=t[a];l!=null&&(a.startsWith("--")?e.push(a+":"+l):e.push(Ul(a)+":"+Oo(a,l)))}return e.join(";")}}return String(t)},Oo=(t,e)=>typeof e!="number"||e===0||Ao(t)?e:e+"px",va=t=>Oe(t.$static$.$containerState$.$elementIndex$++),$r=(t,e)=>{const a=va(t);e.$id$=a},_a=t=>mt(t)?_a(t.value):t==null||typeof t=="boolean"?"":String(t);function yr(t){return t.startsWith("aria-")}const vr=(t,e)=>!!e.key&&(!Je(t)||!yt(t.type)&&t.key!=e.key),ht="dangerouslySetInnerHTML";var _r;const Ga="<!--qkssr-f-->";class wr{constructor(e){this.nodeType=e,this[_r]=null}}_r=pl;const Ro=()=>new wr(9),Uv=async(t,e)=>{var D,T,v;const a=e.containerTagName,l=Ua(1).$element$,r=hn(l,e.base??"/");r.$serverData$.locale=(D=e.serverData)==null?void 0:D.locale;const o=Ro(),c=br(o,r),p=e.beforeContent??[],d={$static$:{$contexts$:[],$headNodes$:a==="html"?p:[],$locale$:(T=e.serverData)==null?void 0:T.locale,$textNodes$:new Map},$projectedChildren$:void 0,$projectedCtxs$:void 0,$invocationContext$:void 0},g=(v=e.serverData)==null?void 0:v.locale,x=e.containerAttributes,h=x["q:render"];x["q:container"]="paused",x["q:version"]="1.8.0",x["q:render"]=(h?h+"-":"")+"ssr",x["q:base"]=e.base||"",x["q:locale"]=g,x["q:manifest-hash"]=e.manifestHash,x["q:instance"]=qo();const $=a==="html"?[t]:[p,t];a!=="html"&&(x.class="qc📦"+(x.class?" "+x.class:""));const _=r.$serverData$={...r.$serverData$,...e.serverData};_.containerAttributes={..._.containerAttributes,...x},(d.$invocationContext$=_t(g)).$renderCtx$=c;const k=n(a,null,x,$,oa|Ae,null);r.$hostsRendering$=new Set,await Promise.resolve().then(()=>Fo(k,c,d,e.stream,r,e))},qo=()=>Math.random().toString(36).slice(2),Fo=async(t,e,a,l,r,o)=>{const c=o.beforeClose;return await nn(t,e,a,l,0,c?p=>{const d=c(a.$static$.$contexts$,r,!1,a.$static$.$textNodes$);return jt(d,e,a,p,0,void 0)}:void 0),e},zo=async(t,e,a,l,r)=>{l.write(Ga);const o=t.props.children;let c;if(yt(o)){const p=o({write(d){l.write(d),l.write(Ga)}});if(ut(p))return p;c=p}else c=o;for await(const p of c)await jt(p,e,a,l,r,void 0),l.write(Ga)},Sr=(t,e,a,l,r,o,c,p)=>{var D;const d=t.props,g=d["q:renderFn"];if(g)return e.$componentQrl$=g,Ho(l,r,o,e,t,c,p);let x="<!--qv"+Go(d);const h="q:s"in d,$=t.key!=null?String(t.key):null;h&&((D=l.$cmpCtx$)==null||D.$id$,x+=" q:sref="+l.$cmpCtx$.$id$),$!=null&&(x+=" q:key="+$),x+="-->",o.write(x);const _=t.props[ht];if(_)return o.write(_),void o.write(Sl);if(a)for(const T of a)ln(T.type,T.props,o);const k=Tr(t.children,l,r,o,c);return Z(k,()=>{var v;if(!h&&!p)return void o.write(Sl);let T;if(h){const L=(v=r.$projectedChildren$)==null?void 0:v[$];if(L){const[P,S]=r.$projectedCtxs$,E=Ea(P);E.$slotCtx$=e,r.$projectedChildren$[$]=void 0,T=jt(L,E,S,o,c)}}return p&&(T=Z(T,()=>p(o))),Z(T,()=>{o.write(Sl)})})},Sl="<!--/qv-->",Qo=t=>{let e="";for(const a in t){if(a===ht)continue;const l=t[a];l!=null&&(e+=" "+(l===""?a:a+'="'+l+'"'))}return e},Go=t=>{let e="";for(const a in t){if(a==="children"||a===ht)continue;const l=t[a];l!=null&&(e+=" "+(l===""?a:a+"="+l))}return e},ln=(t,e,a)=>{if(a.write("<"+t+Qo(e)+">"),kr[t])return;const l=e[ht];l!=null&&a.write(l),a.write(`</${t}>`)},Ho=(t,e,a,l,r,o,c)=>(Wo(t,l,r.props.props),Z(Va(t,l),p=>{const d=l.$element$,g=p.rCtx,x=_t(e.$static$.$locale$,d,void 0);x.$subscriber$=[0,d],x.$renderCtx$=g;const h={$static$:e.$static$,$projectedChildren$:Vo(r.children,e),$projectedCtxs$:[t,e],$invocationContext$:x},$=[];if(l.$appendStyles$){const T=4&o?e.$static$.$headNodes$:$;for(const v of l.$appendStyles$)T.push(n("style",{[dl]:v.styleId,[ht]:v.content,hidden:""},null,null,0,null))}const _=va(t),k=l.$scopeIds$?mr(l.$scopeIds$):void 0,D=i(r.type,{[$o]:k,[yo]:_,children:p.node},0,r.key);return l.$id$=_,e.$static$.$contexts$.push(l),Sr(D,l,$,g,h,a,o,T=>{if(l.$flags$&Ae){const P=Ua(1),S=P.li;S.push(...l.li),l.$flags$&=~Ae,P.$id$=va(t);const E={type:"placeholder",hidden:"","q:id":P.$id$};e.$static$.$contexts$.push(P);const B=Jl(S);for(const I of B){const C=Lr(I[0]);E[C]=Dn(I[1],t.$static$.$containerState$,P),Ll(C,t.$static$.$containerState$)}ln("script",E,T)}const v=h.$projectedChildren$;let L;if(v){const P=Object.keys(v).map(I=>{const C=v[I];if(C)return n("q:template",{[Dt]:I||!0,hidden:!0,"aria-hidden":"true"},null,C,0,null)}),[S,E]=h.$projectedCtxs$,B=Ea(S);B.$slotCtx$=l,L=jt(P,B,E,T,0,void 0)}return c?Z(L,()=>c(T)):L})})),Vo=(t,e)=>{const a=Dr(t,e);if(a===null)return;const l={};for(const r of a){let o="";Je(r)&&(o=r.props[Dt]||""),(l[o]||(l[o]=[])).push(r)}return l},Ua=t=>{const e=new wr(t);return hl(e)},nn=(t,e,a,l,r,o)=>{var g;const c=t.type,p=e.$cmpCtx$;if(typeof c=="string"){const x=t.key,h=t.props,$=t.immutableProps||gt,_=Ua(1),k=_.$element$,D=c==="head";let T="<"+c,v=!1,L=!1,P="",S=null;const E=(C,A,W)=>{if(C==="ref")return void(A!==void 0&&(bn(A,k),L=!0));if(Yl(C))return void Zl(_.li,C,A,void 0);if(mt(A)&&(A=Qt(A,W?[1,k,A,p.$element$,C]:[2,p.$element$,A,k,C]),v=!0),C===ht)return void(S=A);let Y;C.startsWith(fr)&&Ll(C.slice(15),e.$static$.$containerState$);const U=C==="htmlFor"?"for":C;U==="class"||U==="className"?P=Wa(A):U==="style"?Y=xl(A):yr(U)||U==="draggable"||U==="spellcheck"?(Y=A!=null?String(A):null,A=Y):Y=A===!1||A==null?null:String(A),Y!=null&&(U==="value"&&c==="textarea"?S=la(Y):Ko(U)||(T+=" "+(A===!0?U:U+'="'+la(Y)+'"')))};for(const C in h){let A=!1,W;C in $?(A=!0,W=$[C],W===s&&(W=h[C])):W=h[C],E(C,W,A)}for(const C in $){if(C in h)continue;const A=$[C];A!==s&&E(C,A,!0)}const B=_.li;if(p){if((g=p.$scopeIds$)!=null&&g.length){const C=p.$scopeIds$.join(" ");P=P?`${C} ${P}`:C}p.$flags$&Ae&&(B.push(...p.li),p.$flags$&=~Ae)}if(D&&(r|=1),c in Uo&&(r|=16),c in Yo&&(r|=8),P&&(T+=' class="'+la(P)+'"'),B.length>0){const C=Jl(B),A=!!(16&r);for(const W of C){const Y=A?Lr(W[0]):W[0];T+=" "+Y+'="'+Dn(W[1],e.$static$.$containerState$,_)+'"',Ll(Y,e.$static$.$containerState$)}}if(x!=null&&(T+=' q:key="'+la(x)+'"'),L||v||B.length>0){if(L||v||Xo(B)){const C=va(e);T+=' q:id="'+C+'"',_.$id$=C}a.$static$.$contexts$.push(_)}if(1&r&&(T+=" q:head"),T+=">",l.write(T),c in kr)return;if(S!=null)return l.write(String(S)),void l.write(`</${c}>`);c==="html"?r|=4:r&=-5,2&t.flags&&(r|=1024);const I=jt(t.children,e,a,l,r);return Z(I,()=>{if(D){for(const C of a.$static$.$headNodes$)ln(C.type,C.props,l);a.$static$.$headNodes$.length=0}if(o)return Z(o(l),()=>{l.write(`</${c}>`)});l.write(`</${c}>`)})}if(c===Ne){const x=Ua(111);return e.$slotCtx$?(x.$parentCtx$=e.$slotCtx$,x.$realParentCtx$=e.$cmpCtx$):x.$parentCtx$=e.$cmpCtx$,p&&p.$flags$&fn&&tu(p,x),Sr(t,x,void 0,e,a,l,r,o)}if(c===Cr)return void l.write(t.props.data);if(c===Mr)return zo(t,e,a,l,r);const d=xt(a.$invocationContext$,c,t.props,t.key,t.flags,t.dev);return vr(d,t)?nn(i(Ne,{children:d},0,t.key),e,a,l,r,o):jt(d,e,a,l,r,o)},jt=(t,e,a,l,r,o)=>{var c;if(t!=null&&typeof t!="boolean"){if(!Ee(t)&&typeof t!="number"){if(Je(t))return nn(t,e,a,l,r,o);if(lt(t))return Tr(t,e,a,l,r);if(mt(t)){const p=8&r,d=(c=e.$cmpCtx$)==null?void 0:c.$element$;let g;if(d){if(!p){const x=va(e);if(g=Qt(t,1024&r?[3,"#"+x,t,"#"+x]:[4,d,t,"#"+x]),Ee(g)){const h=_a(g);a.$static$.$textNodes$.set(h,x)}return l.write(`<!--t=${x}-->`),jt(g,e,a,l,r,o),void l.write("<!---->")}g=xt(a.$invocationContext$,()=>t.value)}return void l.write(la(_a(g)))}return ut(t)?(l.write(Ga),t.then(p=>jt(p,e,a,l,r,o))):void Ie()}l.write(la(String(t)))}},Tr=(t,e,a,l,r)=>{if(t==null)return;if(!lt(t))return jt(t,e,a,l,r);const o=t.length;if(o===1)return jt(t[0],e,a,l,r);if(o===0)return;let c=0;const p=[];return t.reduce((d,g,x)=>{const h=[];p.push(h);const $=jt(g,e,a,d?{write(_){c===x?l.write(_):h.push(_)}}:l,r);if(d||ut($)){const _=()=>{c++,p.length>c&&p[c].forEach(k=>l.write(k))};return ut($)?d?Promise.all([$,d]).then(_):$.then(_):d.then(_)}c++},void 0)},Dr=(t,e)=>{if(t==null)return null;const a=Pr(t,e),l=lt(a)?a:[a];return l.length===0?null:l},Pr=(t,e)=>{if(t==null)return null;if(lt(t))return t.flatMap(a=>Pr(a,e));if(Je(t)&&yt(t.type)&&t.type!==Cr&&t.type!==Mr&&t.type!==Ne){const a=xt(e.$invocationContext$,t.type,t.props,t.key,t.flags);return Dr(a,e)}return t},Wo=(t,e,a)=>{const l=Object.keys(a),r=gl();if(e.$props$=Ia(r,t.$static$.$containerState$),l.length===0)return;const o=r[s]=a[s]??gt;for(const c of l)c!=="children"&&c!==Dt&&(mt(o[c])?r["$$"+c]=o[c]:r[c]=a[c])},Uo={head:!0,style:!0,script:!0,link:!0,meta:!0},Yo={title:!0,style:!0,script:!0,noframes:!0,textarea:!0},kr={area:!0,base:!0,basefont:!0,bgsound:!0,br:!0,col:!0,embed:!0,frame:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0},Jo=/[&<>'"]/g,Ll=(t,e)=>{e.$events$.add(Ur(t))},la=t=>t.replace(Jo,e=>{switch(e){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";case'"':return"&quot;";case"'":return"&#39;";default:return""}}),Zo=/[>/="'\u0009\u000a\u000c\u0020]/,Ko=t=>Zo.test(t),Xo=t=>t.some(e=>e[1].$captureRef$&&e[1].$captureRef$.length>0),tu=(t,e)=>{const a=t.$dynamicSlots$||(t.$dynamicSlots$=[]);a.includes(e)||a.push(e)},Lr=t=>t==="on:qvisible"?"on-document:qinit":t,u=(t,e,a)=>new jl(t,e,a),eu=t=>{const e=t.$funcStr$;let a="";for(let l=0;l<t.$args$.length;l++)a+=`p${l},`;return`(${a})=>(${e})`},n=(t,e,a,l,r,o)=>{const c=o==null?null:String(o);return new pa(t,e||gt,a,l,r,c)},X=(t,e,a,l,r,o)=>{let c=null;return e&&"children"in e&&(c=e.children,delete e.children),n(t,e,a,c,l,r)},i=(t,e,a,l,r)=>{const o=l==null?null:String(l),c=e??{};if(typeof t=="string"&&s in c){const d=c[s];delete c[s];const g=c.children;delete c.children;for(const[x,h]of Object.entries(d))h!==s&&(delete c[x],c[x]=h);return n(t,null,c,g,a,l)}const p=new pa(t,c,null,c.children,a,o);return typeof t=="string"&&e&&delete e.children,p},Yv=(t,e,a)=>{const r=$a(()=>{const c=e.children;return typeof t=="string"&&delete e.children,c});return Ee(t)&&"className"in e&&(e.class=e.className,delete e.className),new pa(t,e,null,r,0,null)};class pa{constructor(e,a,l,r,o,c=null){this.type=e,this.props=a,this.immutableProps=l,this.children=r,this.flags=o,this.key=c}}const Ne=t=>t.children,Je=t=>t instanceof pa,G=t=>t.children,sn=Symbol("skip render"),Cr=()=>null,Mr=()=>null,rn=(t,e,a)=>{const l=!(e.$flags$&gn),r=e.$element$,o=t.$static$.$containerState$;return o.$hostsStaging$.delete(e),o.$subsManager$.$clearSub$(r),Z(Va(t,e),c=>{const p=t.$static$,d=c.rCtx,g=_t(t.$static$.$locale$,r);if(p.$hostElements$.add(r),g.$subscriber$=[0,r],g.$renderCtx$=d,l&&e.$appendStyles$)for(const h of e.$appendStyles$)uc(p,h);const x=Be(c.node,g);return Z(x,h=>{const $=au(r,h),_=on(e);return Z(Xa(d,_,$,a),()=>{e.$vdom$=$})})})},on=t=>(t.$vdom$||(t.$vdom$=tl(t.$element$)),t.$vdom$);class Ft{constructor(e,a,l,r,o,c){this.$type$=e,this.$props$=a,this.$immutableProps$=l,this.$children$=r,this.$flags$=o,this.$key$=c,this.$elm$=null,this.$text$="",this.$signal$=null,this.$id$=e+(c?":"+c:"")}}const jr=(t,e)=>{const{key:a,type:l,props:r,children:o,flags:c,immutableProps:p}=t;let d="";if(Ee(l))d=l;else{if(l!==Ne){if(yt(l)){const x=xt(e,l,r,a,c,t.dev);return vr(x,t)?jr(i(Ne,{children:x},0,a),e):Be(x,e)}throw it(25,l)}d=ua}let g=qt;return o!=null?Z(Be(o,e),x=>(x!==void 0&&(g=lt(x)?x:[x]),new Ft(d,r,p,g,c,a))):new Ft(d,r,p,g,c,a)},au=(t,e)=>{const a=e===void 0?qt:lt(e)?e:[e],l=new Ft(":virtual",{},null,a,0,null);return l.$elm$=t,l},Be=(t,e)=>{if(t!=null&&typeof t!="boolean"){if(Ir(t)){const a=new Ft("#text",gt,null,qt,0,null);return a.$text$=String(t),a}if(Je(t))return jr(t,e);if(mt(t)){const a=new Ft("#signal",gt,null,qt,0,null);return a.$signal$=t,a}if(lt(t)){const a=Wl(t.flatMap(l=>Be(l,e)));return Z(a,l=>l.flat(100).filter(cr))}return ut(t)?t.then(a=>Be(a,e)):t===sn?new Ft(":skipRender",gt,null,qt,0,null):void Ie()}},Ir=t=>Ee(t)||typeof t=="number",Er=t=>{Et(t,"q:container")==="paused"&&(su(t),cu(t))},lu=t=>{const e=ja(t),a=ou(t===e.documentElement?e.body:t,"type");if(a)return JSON.parse(iu(a.firstChild.data)||"{}")},nu=(t,e)=>{const a=JSON.parse(t);if(typeof a!="object")return null;const{_objs:l,_entry:r}=a;if(l===void 0||r===void 0)return null;let o={},c={};if(qe(e)&&ze(e)){const g=mn(e);g&&(c=ga(g),o=g.ownerDocument)}const p=gi(c,o);for(let g=0;g<l.length;g++){const x=l[g];Ee(x)&&(l[g]=x===yl?void 0:p.prepare(x))}const d=g=>l[At(g)];for(const g of l)Nr(g,d,p);return d(r)},su=t=>{if(!Gu(t))return void Ie();const e=t._qwikjson_??lu(t);if(t._qwikjson_=null,!e)return void Ie();const a=ja(t),l=t.getAttribute(pr),r=gr(a,l),o=ga(t),c=new Map,p=new Map;let d=null,g=0;const x=a.createTreeWalker(t,Wr);for(;d=x.nextNode();){const v=d.data;if(g===0){if(v.startsWith("qv ")){const L=du(v);L>=0&&c.set(L,d)}else if(v.startsWith("t=")){const L=v.slice(2),P=At(L),S=uu(d);c.set(P,S),p.set(P,S.data)}}v==="cq"?g++:v==="/cq"&&g--}const h=t.getElementsByClassName("qc📦").length!==0;t.querySelectorAll("[q\\:id]").forEach(v=>{if(h&&v.closest("[q\\:container]")!==t)return;const L=Et(v,"q:id"),P=At(L);c.set(P,v)});const $=gi(o,a),_=new Map,k=new Set,D=v=>(typeof v=="string"&&v.length>0,_.has(v)?_.get(v):T(v)),T=v=>{if(v.startsWith("#")){const B=v.slice(1),I=At(B);c.has(I);const C=c.get(I);if(Ca(C)){if(!C.isConnected)return void _.set(v,void 0);const A=Aa(C);return _.set(v,A),vt(A,o),A}return Fe(C)?(_.set(v,C),vt(C,o),C):(_.set(v,C),C)}if(v.startsWith("@")){const B=v.slice(1),I=At(B);return r[I]}if(v.startsWith("*")){const B=v.slice(1),I=At(B);c.has(I);const C=p.get(I);return _.set(v,C),C}const L=At(v),P=e.objs;P.length>L;let S=P[L];Ee(S)&&(S=S===yl?void 0:$.prepare(S));let E=S;for(let B=v.length-1;B>=0;B--){const I=fd[v[B]];if(!I)break;E=I(E,o)}return _.set(v,E),Ir(S)||k.has(L)||(k.add(L),ru(S,L,e.subs,D,o,$),Nr(S,D,$)),E};o.$elementIndex$=1e5,o.$pauseCtx$={getObject:D,meta:e.ctx,refs:e.refs},St(t,"q:container","resumed"),Po(t,"qresume",void 0,!0)},ru=(t,e,a,l,r,o)=>{const c=a[e];if(c){const p=[];let d=0;for(const g of c)if(g.startsWith("_"))d=parseInt(g.slice(1),10);else{const x=yd(g,l);x&&p.push(x)}if(d>0&&fl(t,d),!o.subs(t,p)){const g=r.$proxyMap$.get(t);g?$t(g).$addSubs$(p):Ia(t,r,p)}}},Nr=(t,e,a)=>{if(!a.fill(t,e)&&t&&typeof t=="object"){if(lt(t))for(let l=0;l<t.length;l++)t[l]=e(t[l]);else if(Ma(t))for(const l in t)t[l]=e(t[l])}},iu=t=>t.replace(/\\x3C(\/?script)/gi,"<$1"),ou=(t,e)=>{let a=t.lastElementChild;for(;a;){if(a.tagName==="SCRIPT"&&Et(a,e)==="qwik/json")return a;a=a.previousElementSibling}},uu=t=>{const e=t.nextSibling;if(Ql(e))return e;{const a=t.ownerDocument.createTextNode("");return t.parentElement.insertBefore(a,t),a}},cu=t=>{t.qwik={pause:()=>Tc(t),state:ga(t)}},du=t=>{const e=t.indexOf("q:id=");return e>0?At(t.slice(e+5)):-1},tt=()=>{const t=Bu();let e=t.$qrl$;if(e)e.$captureRef$;else{const a=t.$element$,l=mn(a);e=$l(decodeURIComponent(String(t.$url$)),l),Er(l);const r=vt(a,ga(l));di(e,r)}return e.$captureRef$},pu=(t,e)=>{try{const a=e[0],l=t.$static$;switch(a){case 1:case 2:{let r,o;a===1?(r=e[1],o=e[3]):(r=e[3],o=e[1]);const c=Pt(r);if(c==null)return;const p=e[4],d=r.namespaceURI===Ba;l.$containerState$.$subsManager$.$clearSignal$(e);let g=Qt(e[2],e.slice(0,-1));p==="class"?g=an(g,Pt(o)):p==="style"&&(g=xl(g));const x=on(c);return p in x.$props$&&x.$props$[p]===g?void 0:(x.$props$[p]=g,yn(l,r,p,g,d))}case 3:case 4:{const r=e[3];if(!l.$visited$.includes(r)){l.$containerState$.$subsManager$.$clearSignal$(e);const o=void 0;let c=Qt(e[2],e.slice(0,-1));const p=wd();Array.isArray(c)&&(c=new pa(Ne,{},null,c,0,null));let d=Be(c,o);if(ut(d))Ve("Rendering promises in JSX signals is not supported");else{d===void 0&&(d=Be("",o));const g=Jr(r),x=gu(e[1]);if(t.$cmpCtx$=vt(x,t.$static$.$containerState$),g.$type$==d.$type$&&g.$key$==d.$key$&&g.$id$==d.$id$)ta(t,g,d,0);else{const h=[],$=g.$elm$,_=Ge(t,d,0,h);h.length&&Ve("Rendering promises in JSX signals is not supported"),p[3]=_,sa(t.$static$,r.parentElement,_,$),$&&_n(l,$)}}}}}}catch{}};function gu(t){for(;t;){if(ze(t))return t;t=t.parentElement}throw new Error("Not found")}const fu=(t,e)=>{if(t[0]===0){const a=t[1];pn(a)?un(a,e):xu(a,e)}else mu(t,e)},xu=(t,e)=>{const a=Tt();a||Er(e.$containerEl$);const l=vt(t,e);if(l.$componentQrl$,!(l.$flags$&oa))if(l.$flags$|=oa,e.$hostsRendering$!==void 0)e.$hostsStaging$.add(l);else{if(a)return void Ie();e.$hostsNext$.add(l),cn(e)}},mu=(t,e)=>{const a=e.$hostsRendering$!==void 0;e.$opsNext$.add(t),a||cn(e)},un=(t,e)=>{t.$flags$&We||(t.$flags$|=We,e.$hostsRendering$!==void 0?e.$taskStaging$.add(t):(e.$taskNext$.add(t),cn(e)))},cn=t=>(t.$renderPromise$===void 0&&(t.$renderPromise$=ul().nextTick(()=>Br(t))),t.$renderPromise$),hu=()=>{const[t]=tt();un(t,ga(mn(t.$el$)))},Br=async t=>{const e=t.$containerEl$,a=ja(e);try{const l=br(a,t),r=l.$static$,o=t.$hostsRendering$=new Set(t.$hostsNext$);t.$hostsNext$.clear(),await $u(t,l),t.$hostsStaging$.forEach(d=>{o.add(d)}),t.$hostsStaging$.clear();const c=Array.from(t.$opsNext$);t.$opsNext$.clear();const p=Array.from(o);_u(p),!t.$styleMoved$&&p.length>0&&(t.$styleMoved$=!0,(e===a.documentElement?a.body:e).querySelectorAll("style[q\\:style]").forEach(d=>{t.$styleIds$.add(Et(d,dl)),ni(r,a.head,d)}));for(const d of p){const g=d.$element$;if(!r.$hostElements$.has(g)&&d.$componentQrl$){g.isConnected,r.$roots$.push(d);try{await rn(l,d,bu(g.parentElement))}catch(x){Ve(x)}}}return c.forEach(d=>{pu(l,d)}),r.$operations$.push(...r.$postOperations$),r.$operations$.length===0?(Vs(r),void await As(t,l)):(await ac(r),Vs(r),As(t,l))}catch(l){Ve(l)}},bu=t=>{let e=0;return t&&(t.namespaceURI===Ba&&(e|=wt),t.tagName==="HEAD"&&(e|=Za)),e},As=async(t,e)=>{const a=e.$static$.$hostElements$;await vu(t,e,(l,r)=>!!(l.$flags$&Ar)&&(!r||a.has(l.$el$))),t.$hostsStaging$.forEach(l=>{t.$hostsNext$.add(l)}),t.$hostsStaging$.clear(),t.$hostsRendering$=void 0,t.$renderPromise$=void 0,t.$hostsNext$.size+t.$taskNext$.size+t.$opsNext$.size>0&&(t.$renderPromise$=Br(t))},Cl=t=>!!(t.$flags$&Or),Os=t=>!!(t.$flags$&Rr),$u=async(t,e)=>{const a=t.$containerEl$,l=[],r=[];t.$taskNext$.forEach(o=>{Cl(o)&&(r.push(Z(o.$qrl$.$resolveLazy$(a),()=>o)),t.$taskNext$.delete(o)),Os(o)&&(l.push(Z(o.$qrl$.$resolveLazy$(a),()=>o)),t.$taskNext$.delete(o))});do if(t.$taskStaging$.forEach(o=>{Cl(o)?r.push(Z(o.$qrl$.$resolveLazy$(a),()=>o)):Os(o)?l.push(Z(o.$qrl$.$resolveLazy$(a),()=>o)):t.$taskNext$.add(o)}),t.$taskStaging$.clear(),r.length>0){const o=await Promise.all(r);Ya(o),await Promise.all(o.map(c=>Ja(c,t,e))),r.length=0}while(t.$taskStaging$.size>0);if(l.length>0){const o=await Promise.all(l);Ya(o);for(const c of o)Ja(c,t,e)}},yu=(t,e)=>{const a=t.$containerEl$,l=t.$taskStaging$;if(!l.size)return;const r=[];let o=20;const c=()=>{if(l.forEach(p=>{Cl(p)&&r.push(Z(p.$qrl$.$resolveLazy$(a),()=>p))}),l.clear(),r.length>0)return Promise.all(r).then(async p=>{if(Ya(p),await Promise.all(p.map(d=>Ja(d,t,e))),r.length=0,--o&&l.size>0)return c();o||Ie(`Infinite task loop detected. Tasks:
${Array.from(l).map(d=>`  ${d.$qrl$.$symbol$}`).join(`
`)}`)})};return c()},vu=async(t,e,a)=>{const l=[],r=t.$containerEl$;t.$taskNext$.forEach(o=>{a(o,!1)&&(o.$el$.isConnected&&l.push(Z(o.$qrl$.$resolveLazy$(r),()=>o)),t.$taskNext$.delete(o))});do if(t.$taskStaging$.forEach(o=>{o.$el$.isConnected&&(a(o,!0)?l.push(Z(o.$qrl$.$resolveLazy$(r),()=>o)):t.$taskNext$.add(o))}),t.$taskStaging$.clear(),l.length>0){const o=await Promise.all(l);Ya(o);for(const c of o)Ja(c,t,e);l.length=0}while(t.$taskStaging$.size>0)},_u=t=>{t.sort((e,a)=>2&e.$element$.compareDocumentPosition(al(a.$element$))?1:-1)},Ya=t=>{const e=Tt();t.sort((a,l)=>e||a.$el$===l.$el$?a.$index$<l.$index$?-1:1:2&a.$el$.compareDocumentPosition(al(l.$el$))?1:-1)},wu=t=>{const e=Au(),a=yt(t)&&!Ln(t)?xt(void 0,t):t;return zu(a,e,0)},Su=t=>{const{val:e,set:a}=Ye();return e??a(t=yt(t)&&!Ln(t)?t():t)},N=t=>Su(()=>wu(t)),Ar=1,Or=2,Rr=4,We=16,dn=(t,e)=>{const{val:a,set:l,iCtx:r,i:o,elCtx:c}=Ye();if(a)return;const p=r.$renderCtx$.$static$.$containerState$,d=new ml(We|Or,o,c.$element$,t,void 0);l(!0),t.$resolveLazy$(p.$containerEl$),c.$tasks$||(c.$tasks$=[]),c.$tasks$.push(d),Ru(r,()=>Fr(d,p,r.$renderCtx$)),Tt()&&Ml(d,e==null?void 0:e.eagerness)},Lt=(t,e)=>{const{val:a,set:l,i:r,iCtx:o,elCtx:c}=Ye(),p=(e==null?void 0:e.strategy)??"intersection-observer";if(a)return void(Tt()&&Ml(a,p));const d=new ml(Ar,r,c.$element$,t,void 0),g=o.$renderCtx$.$static$.$containerState$;c.$tasks$||(c.$tasks$=[]),c.$tasks$.push(d),l(d),Ml(d,p),Tt()||(t.$resolveLazy$(g.$containerEl$),un(d,g))},qr=t=>!!(t.$flags$&Rr),Tu=t=>!!(8&t.$flags$),Ja=async(t,e,a)=>(t.$flags$&We,qr(t)?Du(t,e,a):Tu(t)?Pu(t,e,a):Fr(t,e,a)),Du=(t,e,a,l)=>{t.$flags$&=~We,wa(t);const r=_t(a.$static$.$locale$,t.$el$,void 0,"qTask"),{$subsManager$:o}=e;r.$renderCtx$=a;const c=t.$qrl$.getFn(r,()=>{o.$clearSub$(t)}),p=[],d=t.$state$,g=Oa(d),x={track:(v,L)=>{if(yt(v)){const S=_t();return S.$renderCtx$=a,S.$subscriber$=[0,t],xt(S,v)}const P=$t(v);return P?P.$addSub$([0,t],L):Gl(ol(26),v),L?v[L]:mt(v)?v.value:v},cleanup(v){p.push(v)},cache(v){let L=0;L=v==="immutable"?1/0:v,d._cache=L},previous:g._resolved};let h,$,_=!1;const k=(v,L)=>!_&&(_=!0,v?(_=!0,d.loading=!1,d._state="resolved",d._resolved=L,d._error=void 0,h(L)):(_=!0,d.loading=!1,d._state="rejected",d._error=L,$(L)),!0);xt(r,()=>{d._state="pending",d.loading=!Tt(),d.value=new Promise((v,L)=>{h=v,$=L})}),t.$destroy$=_l(()=>{_=!0,p.forEach(v=>v())});const D=cl(()=>Z(l,()=>c(x)),v=>{k(!0,v)},v=>{k(!1,v)}),T=g._timeout;return T>0?Promise.race([D,ho(T).then(()=>{k(!1,new Error("timeout"))&&wa(t)})]):D},Fr=(t,e,a)=>{t.$flags$&=~We,wa(t);const l=t.$el$,r=_t(a.$static$.$locale$,l,void 0,"qTask");r.$renderCtx$=a;const{$subsManager$:o}=e,c=t.$qrl$.getFn(r,()=>{o.$clearSub$(t)}),p=[];t.$destroy$=_l(()=>{p.forEach(g=>g())});const d={track:(g,x)=>{if(yt(g)){const $=_t();return $.$subscriber$=[0,t],xt($,g)}const h=$t(g);return h?h.$addSub$([0,t],x):Gl(ol(26),g),x?g[x]:mt(g)?g.value:g},cleanup(g){p.push(g)}};return cl(()=>c(d),g=>{yt(g)&&p.push(g)},g=>{en(g,l,a)})},Pu=(t,e,a)=>{t.$state$,t.$flags$&=~We,wa(t);const l=t.$el$,r=_t(a.$static$.$locale$,l,void 0,"qComputed");r.$subscriber$=[0,t],r.$renderCtx$=a;const{$subsManager$:o}=e,c=t.$qrl$.getFn(r,()=>{o.$clearSub$(t)});return cl(c,p=>$a(()=>{const d=t.$state$;d[Sa]&=~Hr,d.untrackedValue=p,d[Ot].$notifySubs$()}),p=>{en(p,l,a)})},wa=t=>{const e=t.$destroy$;if(e){t.$destroy$=void 0;try{e()}catch(a){Ve(a)}}},zr=t=>{32&t.$flags$?(t.$flags$&=-33,(0,t.$qrl$)()):wa(t)},Ml=(t,e)=>{e==="visible"||e==="intersection-observer"?To("qvisible",Tl(t)):e==="load"||e==="document-ready"?Bs("qinit",Tl(t)):e!=="idle"&&e!=="document-idle"||Bs("qidle",Tl(t))},Tl=t=>{const e=t.$qrl$,a=Ra(e.$chunk$,"_hW",hu,null,null,[t],e.$symbol$);return e.dev&&(a.dev=e.dev),a},pn=t=>Ht(t)&&t instanceof ml,ku=(t,e)=>{let a=`${Oe(t.$flags$)} ${Oe(t.$index$)} ${e(t.$qrl$)} ${e(t.$el$)}`;return t.$state$&&(a+=` ${e(t.$state$)}`),a},Lu=t=>{const[e,a,l,r,o]=t.split(" ");return new ml(At(e),At(a),r,l,o)};class ml{constructor(e,a,l,r,o){this.$flags$=e,this.$index$=a,this.$el$=l,this.$qrl$=r,this.$state$=o}}function Cu(t){return Mu(t)&&t.nodeType===1}function Mu(t){return t&&typeof t.nodeType=="number"}const oa=1,Ae=2,gn=4,fn=8,Pt=t=>t[pl],vt=(t,e)=>{const a=Pt(t);if(a)return a;const l=hl(t),r=Et(t,"q:id");if(r){const o=e.$pauseCtx$;if(l.$id$=r,o){const{getObject:c,meta:p,refs:d}=o;if(Cu(t)){const g=d[r];g&&(l.$refMap$=g.split(" ").map(c),l.li=So(l,e.$containerEl$))}else{const g=t.getAttribute("q:sstyle");l.$scopeIds$=g?g.split("|"):null;const x=p[r];if(x){const h=x.s,$=x.h,_=x.c,k=x.w;if(h&&(l.$seq$=h.split(" ").map(c)),k&&(l.$tasks$=k.split(" ").map(c)),_){l.$contexts$=new Map;for(const D of _.split(" ")){const[T,v]=D.split("=");l.$contexts$.set(T,c(v))}}if($){const[D,T]=$.split(" ");if(l.$flags$=gn,D&&(l.$componentQrl$=c(D)),T){const v=c(T);l.$props$=v,fl(v,2),v[s]=ju(v)}else l.$props$=Ia(gl(),e)}}}}}return l},ju=t=>{const e={},a=Ze(t);for(const l in a)l.startsWith("$$")&&(e[l.slice(2)]=a[l]);return e},hl=t=>{const e={$flags$:0,$id$:"",$element$:t,$refMap$:[],li:[],$tasks$:null,$seq$:null,$slots$:null,$scopeIds$:null,$appendStyles$:null,$props$:null,$vdom$:null,$componentQrl$:null,$contexts$:null,$dynamicSlots$:null,$parentCtx$:void 0,$realParentCtx$:void 0};return t[pl]=e,e},Iu=(t,e)=>{var a;(a=t.$tasks$)==null||a.forEach(l=>{e.$clearSub$(l),zr(l)}),t.$componentQrl$=null,t.$seq$=null,t.$tasks$=null};let ra;function Eu(t){if(ra===void 0){const e=bt();return e&&e.$locale$?e.$locale$:t}return ra}function Rs(t,e){const a=ra;try{return ra=t,e()}finally{ra=a}}function Nu(t){ra=t}let ba;const bt=()=>{if(!ba){const t=typeof document<"u"&&document&&document.__q_context__;return t?lt(t)?document.__q_context__=Qr(t):t:void 0}return ba},Bu=()=>{const t=bt();if(!t)throw it(14);return t},xn=()=>{const t=bt();if(!t||t.$event$!=="qRender")throw it(20);return t.$hostElement$,t.$waitOn$,t.$renderCtx$,t.$subscriber$,t},Au=()=>xn().$renderCtx$.$static$.$containerState$;function xt(t,e,...a){return Ou.call(this,t,e,a)}function Ou(t,e,a){const l=ba;let r;try{ba=t,r=e.apply(this,a)}finally{ba=l}return r}const Ru=(t,e)=>{const a=t.$waitOn$;if(a.length===0){const l=e();ut(l)&&a.push(l)}else a.push(Promise.all(a).then(e))},Qr=([t,e,a])=>{const l=t.closest("[q\\:container]"),r=(l==null?void 0:l.getAttribute("q:locale"))||void 0;return r&&Nu(r),_t(r,void 0,t,e,a)},_t=(t,e,a,l,r)=>({$url$:r,$i$:0,$hostElement$:e,$element$:a,$event$:l,$qrl$:void 0,$waitOn$:void 0,$subscriber$:void 0,$renderCtx$:void 0,$locale$:t||(typeof l=="object"&&l&&"locale"in l?l.locale:void 0)}),mn=t=>t.closest("[q\\:container]"),$a=t=>xt(void 0,t),qs=_t(void 0,void 0,void 0,"qRender"),Qt=(t,e)=>(qs.$subscriber$=e,xt(qs,()=>t.value)),qu=()=>{var e;const t=bt();if(t)return t.$element$??t.$hostElement$??((e=t.$qrl$)==null?void 0:e.$setContainer$(void 0))},Fu=()=>{const t=bt();if(t)return t.$event$},V=t=>{const e=bt();return e&&e.$hostElement$&&e.$renderCtx$&&(vt(e.$hostElement$,e.$renderCtx$.$static$.$containerState$).$flags$|=fn),t};var Gr;const zu=(t,e,a,l)=>{const r=e.$subsManager$.$createManager$(l);return new Ta(t,r,a)},Sa=Symbol("proxy manager"),Qu=1,Hr=2,Vr=Symbol("unassigned signal");class Na{}class Ta extends Na{constructor(e,a,l){super(),this[Gr]=0,this.untrackedValue=e,this[Ot]=a,this[Sa]=l}valueOf(){}toString(){return`[Signal ${String(this.value)}]`}toJSON(){return{value:this.value}}get value(){var a;if(this[Sa]&Hr)throw Vr;const e=(a=bt())==null?void 0:a.$subscriber$;return e&&this[Ot].$addSub$(e),this.untrackedValue}set value(e){const a=this[Ot];a&&this.untrackedValue!==e&&(this.untrackedValue=e,a.$notifySubs$())}}Gr=Sa;class jl extends Na{constructor(e,a,l){super(),this.$func$=e,this.$args$=a,this.$funcStr$=l}get value(){return this.$func$.apply(void 0,this.$args$)}}class Il extends Na{constructor(e,a){super(),this.ref=e,this.prop=a}get[Ot](){return $t(this.ref)}get value(){return this.ref[this.prop]}set value(e){this.ref[this.prop]=e}}const mt=t=>t instanceof Na,m=(t,e)=>{var r,o;if(!Ht(t))return t[e];if(t instanceof Na)return t;const a=Ze(t);if(a){const c=a["$$"+e];if(c)return c;if(((r=a[s])==null?void 0:r[e])!==!0)return new Il(t,e)}const l=(o=t[s])==null?void 0:o[e];return mt(l)?l:s},w=(t,e)=>{const a=m(t,e);return a===s?t[e]:a},Fs=Symbol("ContainerState"),ga=t=>{let e=t[Fs];return e||(t[Fs]=e=hn(t,Et(t,"q:base")??"/")),e},hn=(t,e)=>{const a={};if(t){const r=t.attributes;if(r)for(let o=0;o<r.length;o++){const c=r[o];a[c.name]=c.value}}const l={$containerEl$:t,$elementIndex$:0,$styleMoved$:!1,$proxyMap$:new WeakMap,$opsNext$:new Set,$taskNext$:new Set,$taskStaging$:new Set,$hostsNext$:new Set,$hostsStaging$:new Set,$styleIds$:new Set,$events$:new Set,$serverData$:{containerAttributes:a},$base$:e,$renderPromise$:void 0,$hostsRendering$:void 0,$pauseCtx$:void 0,$subsManager$:null,$inlineFns$:new Map};return l.$subsManager$=vd(l),l},bn=(t,e)=>{if(yt(t))return t(e);if(mt(t))return Tt()?t.untrackedValue=e:t.value=e;throw it(32,t)},Wr=128,Gu=t=>Fe(t)&&t.hasAttribute("q:container"),Oe=t=>t.toString(36),At=t=>parseInt(t,36),Ur=t=>{const e=t.indexOf(":");return t&&vo(t.slice(e+1))},Ba="http://www.w3.org/2000/svg",wt=1,Za=2,Ka=[],Xa=(t,e,a,l)=>{e.$elm$;const r=a.$children$;if(r.length===1&&r[0].$type$===":skipRender")return void(a.$children$=e.$children$);const o=e.$elm$;let c=el;e.$children$===Ka&&o.nodeName==="HEAD"&&(c=Wu,l|=Za);const p=Hu(e,c);return p.length>0&&r.length>0?Vu(t,o,p,r,l):p.length>0&&r.length===0?$n(t.$static$,p,0,p.length-1):r.length>0?Kr(t,o,null,r,0,r.length-1,l):void 0},Hu=(t,e)=>{const a=t.$children$;return a===Ka?t.$children$=Yr(t.$elm$,e):a},Vu=(t,e,a,l,r)=>{let o=0,c=0,p=a.length-1,d=a[0],g=a[p],x=l.length-1,h=l[0],$=l[x],_,k,D;const T=[],v=t.$static$;for(;o<=p&&c<=x;)if(d==null)d=a[++o];else if(g==null)g=a[--p];else if(h==null)h=l[++c];else if($==null)$=l[--x];else if(d.$id$===h.$id$)T.push(ta(t,d,h,r)),d=a[++o],h=l[++c];else if(g.$id$===$.$id$)T.push(ta(t,g,$,r)),g=a[--p],$=l[--x];else if(d.$key$&&d.$id$===$.$id$)d.$elm$,g.$elm$,T.push(ta(t,d,$,r)),oc(v,e,d.$elm$,g.$elm$),d=a[++o],$=l[--x];else if(g.$key$&&g.$id$===h.$id$)d.$elm$,g.$elm$,T.push(ta(t,g,h,r)),sa(v,e,g.$elm$,d.$elm$),g=a[--p],h=l[++c];else{if(_===void 0&&(_=sc(a,o,p)),k=_[h.$key$],k===void 0){const P=Ge(t,h,r,T);sa(v,e,P,d==null?void 0:d.$elm$)}else if(D=a[k],D.$type$!==h.$type$){const P=Ge(t,h,r,T);Z(P,S=>{sa(v,e,S,d==null?void 0:d.$elm$)})}else T.push(ta(t,D,h,r)),a[k]=void 0,D.$elm$,sa(v,e,D.$elm$,d.$elm$);h=l[++c]}c<=x&&T.push(Kr(t,e,l[x+1]==null?null:l[x+1].$elm$,l,c,x,r));let L=Wl(T);return o<=p&&(L=Z(L,()=>{$n(v,a,o,p)})),L},na=(t,e)=>{const a=Rt(t)?t.close:null,l=[];let r=t.firstChild;for(;(r=wn(r))&&(e(r)&&l.push(r),r=r.nextSibling,r!==a););return l},Yr=(t,e)=>na(t,e).map(Jr),Jr=t=>{var e;return Fe(t)?((e=Pt(t))==null?void 0:e.$vdom$)??tl(t):tl(t)},tl=t=>{if(ze(t)){const e=new Ft(t.localName,{},null,Ka,0,Nl(t));return e.$elm$=t,e}if(Ql(t)){const e=new Ft(t.nodeName,gt,null,Ka,0,null);return e.$text$=t.data,e.$elm$=t,e}},Wu=t=>{const e=t.nodeType;return e===1?t.hasAttribute("q:head"):e===111},El=t=>t.nodeName==="Q:TEMPLATE",el=t=>{const e=t.nodeType;if(e===3||e===111)return!0;if(e!==1)return!1;const a=t.nodeName;return a!=="Q:TEMPLATE"&&(a==="HEAD"?t.hasAttribute("q:head"):a!=="STYLE"||!t.hasAttribute(dl))},Zr=t=>{const e={};for(const a of t){const l=Uu(a);(e[l]??(e[l]=new Ft(ua,{[dr]:""},null,[],0,l))).$children$.push(a)}return e},ta=(t,e,a,l)=>{e.$type$,a.$type$,e.$key$,a.$key$,e.$id$,a.$id$;const r=e.$elm$,o=a.$type$,c=t.$static$,p=c.$containerState$,d=t.$cmpCtx$;if(a.$elm$=r,o==="#text"){c.$visited$.push(r);const $=a.$signal$;return $&&(a.$text$=_a(Qt($,[4,d.$element$,$,r]))),void Re(c,r,"data",a.$text$)}if(o==="#signal")return;const g=a.$props$,x=a.$flags$,h=vt(r,p);if(o!==ua){let $=!!(l&wt);if($||o!=="svg"||(l|=wt,$=!0),g!==gt){1&x||(h.li.length=0);const _=e.$props$;a.$props$=_;for(const k in g){let D=g[k];if(k!=="ref")if(Yl(k)){const T=Zl(h.li,k,D,p.$containerEl$);ei(c,r,T)}else mt(D)&&(D=Qt(D,[1,d.$element$,D,r,k])),k==="class"?D=an(D,d):k==="style"&&(D=xl(D)),_[k]!==D&&(_[k]=D,yn(c,r,k,D,$));else D!==void 0&&bn(D,r)}}return 2&x||($&&o==="foreignObject"&&(l&=~wt),g[ht]!==void 0)||o==="textarea"?void 0:Xa(t,e,a,l)}if("q:renderFn"in g){const $=g.props;ec(p,h,$);let _=!!(h.$flags$&oa);return _||h.$componentQrl$||h.$element$.hasAttribute("q:id")||($r(t,h),h.$componentQrl$=$["q:renderFn"],h.$componentQrl$,_=!0),_?Z(rn(t,h,l),()=>zs(t,h,a,l)):zs(t,h,a,l)}if("q:s"in g)return d.$slots$,void d.$slots$.push(a);if(ht in g)Re(c,r,"innerHTML",g[ht]);else if(!(2&x))return Xa(t,e,a,l)},zs=(t,e,a,l)=>{if(2&a.$flags$)return;const r=t.$static$,o=Zr(a.$children$),c=ti(e);for(const p in c.slots)if(!o[p]){const d=c.slots[p],g=Yr(d,el);if(g.length>0){const x=Pt(d);x&&x.$vdom$&&(x.$vdom$.$children$=[]),$n(r,g,0,g.length-1)}}for(const p in c.templates){const d=c.templates[p];d&&!o[p]&&(c.templates[p]=void 0,_n(r,d))}return Wl(Object.keys(o).map(p=>{const d=o[p],g=Xr(r,c,e,p,t.$static$.$containerState$),x=on(g),h=Ea(t),$=g.$element$;h.$slotCtx$=g,g.$vdom$=d,d.$elm$=$;let _=l&~wt;$.isSvg&&(_|=wt);const k=r.$addSlots$.findIndex(D=>D[0]===$);return k>=0&&r.$addSlots$.splice(k,1),Xa(h,x,d,_)}))},Kr=(t,e,a,l,r,o,c)=>{const p=[];for(;r<=o;++r){const d=l[r],g=Ge(t,d,c,p);sa(t.$static$,e,g,a)}return ea(p)},$n=(t,e,a,l)=>{for(;a<=l;++a){const r=e[a];r&&(r.$elm$,_n(t,r.$elm$))}},Xr=(t,e,a,l,r)=>{const o=e.slots[l];if(o)return vt(o,r);const c=e.templates[l];if(c)return vt(c,r);const p=si(t.$doc$,l),d=hl(p);return d.$parentCtx$=a,dc(t,a.$element$,p),e.templates[l]=p,d},Uu=t=>t.$props$[Dt]??"",Ge=(t,e,a,l)=>{const r=e.$type$,o=t.$static$.$doc$,c=t.$cmpCtx$;if(r==="#text")return e.$elm$=o.createTextNode(e.$text$);if(r==="#signal"){const T=e.$signal$,v=T.value;if(Je(v)){const L=Be(v);if(mt(L))throw new Error("NOT IMPLEMENTED: Promise");if(Array.isArray(L))throw new Error("NOT IMPLEMENTED: Array");{const P=Ge(t,L,a,l);return Qt(T,4&a?[3,P,T,P]:[4,c.$element$,T,P]),e.$elm$=P}}{const L=o.createTextNode(e.$text$);return L.data=e.$text$=_a(v),Qt(T,4&a?[3,L,T,L]:[4,c.$element$,T,L]),e.$elm$=L}}let p,d=!!(a&wt);d||r!=="svg"||(a|=wt,d=!0);const g=r===ua,x=e.$props$,h=t.$static$,$=h.$containerState$;g?p=hc(o,d):r==="head"?(p=o.head,a|=Za):(p=vn(o,r,d),a&=~Za),2&e.$flags$&&(a|=4),e.$elm$=p;const _=hl(p);if(t.$slotCtx$?(_.$parentCtx$=t.$slotCtx$,_.$realParentCtx$=t.$cmpCtx$):_.$parentCtx$=t.$cmpCtx$,g){if("q:renderFn"in x){const T=x["q:renderFn"],v=gl(),L=$.$subsManager$.$createManager$(),P=new Proxy(v,new xr($,L)),S=x.props;if($.$proxyMap$.set(v,P),_.$props$=P,S!==gt){const B=v[s]=S[s]??gt;for(const I in S)if(I!=="children"&&I!==Dt){const C=B[I];mt(C)?v["$$"+I]=C:v[I]=S[I]}}$r(t,_),_.$componentQrl$=T;const E=Z(rn(t,_,a),()=>{let B=e.$children$;if(B.length===0)return;B.length===1&&B[0].$type$===":skipRender"&&(B=B[0].$children$);const I=ti(_),C=[],A=Zr(B);for(const W in A){const Y=A[W],U=Xr(h,I,_,W,h.$containerState$),rt=Ea(t),ct=U.$element$;rt.$slotCtx$=U,U.$vdom$=Y,Y.$elm$=ct;let nt=a&~wt;ct.isSvg&&(nt|=wt);for(const at of Y.$children$){const pt=Ge(rt,at,nt,C);at.$elm$,at.$elm$,ni(h,ct,pt)}}return ea(C)});return ut(E)&&l.push(E),p}if("q:s"in x)c.$slots$,xc(p,e.$key$),St(p,"q:sref",c.$id$),St(p,"q:s",""),c.$slots$.push(e),h.$addSlots$.push([p,c.$element$]);else if(ht in x)return Re(h,p,"innerHTML",x[ht]),p}else{if(e.$immutableProps$){const T=x!==gt?Object.fromEntries(Object.entries(e.$immutableProps$).map(([v,L])=>[v,L===s?x[v]:L])):e.$immutableProps$;Hs(h,_,c,T,d,!0)}if(x!==gt){_.$vdom$=e;const T=e.$immutableProps$?Object.fromEntries(Object.entries(x).filter(([v])=>!(v in e.$immutableProps$))):x;e.$props$=Hs(h,_,c,T,d,!1)}if(d&&r==="foreignObject"&&(d=!1,a&=~wt),c){const T=c.$scopeIds$;T&&T.forEach(v=>{p.classList.add(v)}),c.$flags$&Ae&&(_.li.push(...c.li),c.$flags$&=~Ae)}for(const T of _.li)ei(h,p,T[0]);if(x[ht]!==void 0)return p;d&&r==="foreignObject"&&(d=!1,a&=~wt)}let k=e.$children$;if(k.length===0)return p;k.length===1&&k[0].$type$===":skipRender"&&(k=k[0].$children$);const D=k.map(T=>Ge(t,T,a,l));for(const T of D)Da(p,T);return p},Yu=t=>{const e=t.$slots$;return e||(t.$element$.parentElement,t.$slots$=Ju(t))},ti=t=>{const e=Yu(t),a={},l={},r=Array.from(t.$element$.childNodes).filter(El);for(const o of e)o.$elm$,a[o.$key$??""]=o.$elm$;for(const o of r)l[Et(o,Dt)??""]=o;return{slots:a,templates:l}},Ju=t=>{const e=t.$element$.parentElement;return vc(e,"q:sref",t.$id$).map(tl)},Zu=(t,e,a)=>(Re(t,e.style,"cssText",a),!0),Qs=(t,e,a)=>(e.namespaceURI===Ba?Pa(t,e,"class",a):Re(t,e,"className",a),!0),Gs=(t,e,a,l)=>l in e&&((e[l]!==a||l==="value"&&!e.hasAttribute(l))&&(l==="value"&&e.tagName!=="OPTION"?ic(t,e,l,a):Re(t,e,l,a)),!0),ha=(t,e,a,l)=>(Pa(t,e,l.toLowerCase(),a),!0),Ku=(t,e,a)=>(Re(t,e,"innerHTML",a),!0),Xu=()=>!0,tc={style:Zu,class:Qs,className:Qs,value:Gs,checked:Gs,href:ha,list:ha,form:ha,tabIndex:ha,download:ha,innerHTML:Xu,[ht]:Ku},yn=(t,e,a,l,r)=>{if(yr(a))return void Pa(t,e,a,l!=null?String(l):l);const o=tc[a];o&&o(t,e,l,a)||(r||!(a in e)?(a.startsWith(fr)&&ai(a.slice(15)),Pa(t,e,a,l)):Re(t,e,a,l))},Hs=(t,e,a,l,r,o)=>{const c={},p=e.$element$;for(const d in l){let g=l[d];if(d!=="ref")if(Yl(d))Zl(e.li,d,g,t.$containerState$.$containerEl$);else{if(mt(g)&&(g=Qt(g,o?[1,p,g,a.$element$,d]:[2,a.$element$,g,p,d])),d==="class"){if(g=an(g,a),!g)continue}else d==="style"&&(g=xl(g));c[d]=g,yn(t,p,d,g,r)}else g!==void 0&&bn(g,p)}return c},ec=(t,e,a)=>{let l=e.$props$;if(l||(e.$props$=l=Ia(gl(),t)),a===gt)return;const r=$t(l),o=Ze(l),c=o[s]=a[s]??gt;for(const p in a)if(p!=="children"&&p!==Dt&&!c[p]){const d=a[p];o[p]!==d&&(o[p]=d,r.$notifySubs$(p))}},ya=(t,e,a,l)=>{if(a.$clearSub$(t),ze(t)){if(l&&t.hasAttribute("q:s"))return void e.$rmSlots$.push(t);const r=Pt(t);r&&Iu(r,a);const o=Rt(t)?t.close:null;let c=t.firstChild;for(;(c=wn(c))&&(ya(c,e,a,!0),c=c.nextSibling,c!==o););}},ac=async t=>{fc(t)},Da=(t,e)=>{Rt(e)?e.appendTo(t):t.appendChild(e)},lc=(t,e)=>{Rt(e)?e.remove():t.removeChild(e)},nc=(t,e,a)=>{Rt(e)?e.insertBeforeTo(t,(a==null?void 0:a.nextSibling)??null):t.insertBefore(e,(a==null?void 0:a.nextSibling)??null)},bl=(t,e,a)=>{Rt(e)?e.insertBeforeTo(t,al(a)):t.insertBefore(e,al(a))},sc=(t,e,a)=>{const l={};for(let r=e;r<=a;++r){const o=t[r].$key$;o!=null&&(l[o]=r)}return l},ei=(t,e,a)=>{a.startsWith("on:")||Pa(t,e,a,""),ai(a)},ai=t=>{var e;{const a=Ur(t);try{((e=globalThis).qwikevents||(e.qwikevents=[])).push(a)}catch{}}},Pa=(t,e,a,l)=>{t.$operations$.push({$operation$:rc,$args$:[e,a,l]})},rc=(t,e,a)=>{if(a==null||a===!1)t.removeAttribute(e);else{const l=a===!0?"":String(a);St(t,e,l)}},Re=(t,e,a,l)=>{t.$operations$.push({$operation$:li,$args$:[e,a,l]})},ic=(t,e,a,l)=>{t.$postOperations$.push({$operation$:li,$args$:[e,a,l]})},li=(t,e,a)=>{try{t[e]=a??"",a==null&&qe(t)&&Fe(t)&&t.removeAttribute(e)}catch(l){Ve(ol(6),e,{node:t,value:a},l)}},vn=(t,e,a)=>a?t.createElementNS(Ba,e):t.createElement(e),sa=(t,e,a,l)=>(t.$operations$.push({$operation$:bl,$args$:[e,a,l||null]}),a),oc=(t,e,a,l)=>(t.$operations$.push({$operation$:nc,$args$:[e,a,l||null]}),a),ni=(t,e,a)=>(t.$operations$.push({$operation$:Da,$args$:[e,a]}),a),uc=(t,e)=>{t.$containerState$.$styleIds$.add(e.styleId),t.$postOperations$.push({$operation$:cc,$args$:[t.$containerState$,e]})},cc=(t,e)=>{const a=t.$containerEl$,l=ja(a),r=l.documentElement===a,o=l.head,c=l.createElement("style");St(c,dl,e.styleId),St(c,"hidden",""),c.textContent=e.content,r&&o?Da(o,c):bl(a,c,a.firstChild)},dc=(t,e,a)=>{t.$operations$.push({$operation$:pc,$args$:[e,a]})},pc=(t,e)=>{bl(t,e,t.firstChild)},_n=(t,e)=>{ze(e)&&ya(e,t,t.$containerState$.$subsManager$,!0),t.$operations$.push({$operation$:gc,$args$:[e,t]})},gc=t=>{const e=t.parentElement;e&&lc(e,t)},si=(t,e)=>{const a=vn(t,"q:template",!1);return St(a,Dt,e),St(a,"hidden",""),St(a,"aria-hidden","true"),a},fc=t=>{for(const e of t.$operations$)e.$operation$.apply(void 0,e.$args$);mc(t)},Nl=t=>Et(t,"q:key"),xc=(t,e)=>{e!==null&&St(t,"q:key",e)},mc=t=>{const e=t.$containerState$.$subsManager$;for(const a of t.$rmSlots$){const l=Nl(a),r=na(a,el);if(r.length>0){const o=a.getAttribute("q:sref"),c=t.$roots$.find(p=>p.$id$===o);if(c){const p=c.$element$;if(p.isConnected)if(na(p,El).some(d=>Et(d,Dt)===l))ya(a,t,e,!1);else{const d=si(t.$doc$,l);for(const g of r)Da(d,g);bl(p,d,p.firstChild)}else ya(a,t,e,!1)}else ya(a,t,e,!1)}}for(const[a,l]of t.$addSlots$){const r=Nl(a),o=na(l,El).find(c=>c.getAttribute(Dt)===r);o&&(na(o,el).forEach(c=>{Da(a,c)}),o.remove())}},Vs=()=>{},hc=(t,e)=>{const a=t.createComment("qv "),l=t.createComment("/qv");return new ri(a,l,e)},bc=t=>{if(!t)return{};const e=t.split(" ");return Object.fromEntries(e.map(a=>{const l=a.indexOf("=");return l>=0?[a.slice(0,l),wc(a.slice(l+1))]:[a,""]}))},$c=t=>{const e=[];return Object.entries(t).forEach(([a,l])=>{e.push(l?`${a}=${_c(l)}`:`${a}`)}),e.join(" ")},yc=(t,e,a)=>t.ownerDocument.createTreeWalker(t,128,{acceptNode(l){const r=Aa(l);return r&&Et(r,e)===a?1:2}}),vc=(t,e,a)=>{const l=yc(t,e,a),r=[];let o=null;for(;o=l.nextNode();)r.push(Aa(o));return r},_c=t=>t.replace(/ /g,"+"),wc=t=>t.replace(/\+/g," "),ua=":virtual";class ri{constructor(e,a,l){this.open=e,this.close=a,this.isSvg=l,this._qc_=null,this.nodeType=111,this.localName=ua,this.nodeName=ua;const r=this.ownerDocument=e.ownerDocument;this.$template$=vn(r,"template",!1),this.$attributes$=bc(e.data.slice(3)),e.data.startsWith("qv "),e.__virtual=this,a.__virtual=this}insertBefore(e,a){const l=this.parentElement;return l?l.insertBefore(e,a||this.close):this.$template$.insertBefore(e,a),e}remove(){const e=this.parentElement;if(e){const a=this.childNodes;this.$template$.childElementCount,e.removeChild(this.open);for(let l=0;l<a.length;l++)this.$template$.appendChild(a[l]);e.removeChild(this.close)}}appendChild(e){return this.insertBefore(e,null)}insertBeforeTo(e,a){const l=this.childNodes;e.insertBefore(this.open,a);for(const r of l)e.insertBefore(r,a);e.insertBefore(this.close,a),this.$template$.childElementCount}appendTo(e){this.insertBeforeTo(e,null)}get namespaceURI(){var e;return((e=this.parentElement)==null?void 0:e.namespaceURI)??""}removeChild(e){this.parentElement?this.parentElement.removeChild(e):this.$template$.removeChild(e)}getAttribute(e){return this.$attributes$[e]??null}hasAttribute(e){return e in this.$attributes$}setAttribute(e,a){this.$attributes$[e]=a,this.open.data=Ws(this.$attributes$)}removeAttribute(e){delete this.$attributes$[e],this.open.data=Ws(this.$attributes$)}matches(e){return!1}compareDocumentPosition(e){return this.open.compareDocumentPosition(e)}closest(e){const a=this.parentElement;return a?a.closest(e):null}querySelectorAll(e){const a=[];return na(this,go).forEach(l=>{ze(l)&&(l.matches(e)&&a.push(l),a.concat(Array.from(l.querySelectorAll(e))))}),a}querySelector(e){for(const a of this.childNodes)if(Fe(a)){if(a.matches(e))return a;const l=a.querySelector(e);if(l!==null)return l}return null}get innerHTML(){return""}set innerHTML(e){const a=this.parentElement;a?(this.childNodes.forEach(l=>this.removeChild(l)),this.$template$.innerHTML=e,a.insertBefore(this.$template$.content,this.close)):this.$template$.innerHTML=e}get firstChild(){if(this.parentElement){const e=this.open.nextSibling;return e===this.close?null:e}return this.$template$.firstChild}get nextSibling(){return this.close.nextSibling}get previousSibling(){return this.open.previousSibling}get childNodes(){if(!this.parentElement)return Array.from(this.$template$.childNodes);const e=[];let a=this.open;for(;(a=a.nextSibling)&&a!==this.close;)e.push(a);return e}get isConnected(){return this.open.isConnected}get parentElement(){return this.open.parentElement}}const Ws=t=>`qv ${$c(t)}`,wn=t=>{if(t==null)return null;if(Ca(t)){const e=Aa(t);if(e)return e}return t},Sc=t=>{let e=t,a=1;for(;e=e.nextSibling;)if(Ca(e)){const l=e.__virtual;if(l)e=l;else if(e.data.startsWith("qv "))a++;else if(e.data==="/qv"&&(a--,a===0))return e}},Aa=t=>{var a;const e=t.__virtual;if(e)return e;if(t.data.startsWith("qv ")){const l=Sc(t);return new ri(t,l,((a=t.parentElement)==null?void 0:a.namespaceURI)===Ba)}return null},al=t=>t==null?null:Rt(t)?t.open:t,Jv=async t=>{const e=hn(null,null),a=ii(e);let l;for(J(t,a,!1);(l=a.$promises$).length>0;){a.$promises$=[];const g=await Promise.allSettled(l);for(const x of g)x.status==="rejected"&&console.error(x.reason)}const r=Array.from(a.$objSet$.keys());let o=0;const c=new Map;for(const g of r)c.set(g,Oe(o)),o++;if(a.$noSerialize$.length>0){const g=c.get(void 0);for(const x of a.$noSerialize$)c.set(x,g)}const p=g=>{let x="";if(ut(g)){const $=oi(g);if(!$)throw it(27,g);g=$.value,x+=$.resolved?"~":"_"}if(Ht(g)){const $=Ze(g);$&&(x+="!",g=$)}const h=c.get(g);if(h===void 0)throw it(27,g);return h+x},d=ci(r,p,null,a,e);return JSON.stringify({_entry:p(t),_objs:d})},Tc=async t=>{const e=ja(t),a=e.documentElement,l=or(t)?a:t;if(Et(l,"q:container")==="paused")throw it(21);const r=l===e.documentElement?e.body:l,o=ga(l),c=Pc(l,Ec);St(l,"q:container","paused");for(const h of c){const $=h.$element$,_=h.li;if(h.$scopeIds$){const k=mr(h.$scopeIds$);k&&$.setAttribute("q:sstyle",k)}if(h.$id$&&$.setAttribute("q:id",h.$id$),Fe($)&&_.length>0){const k=Jl(_);for(const D of k)$.setAttribute(D[0],Dn(D[1],o,h))}}const p=await Dc(c,o,h=>qe(h)&&Ql(h)?Ac(h,o):null),d=e.createElement("script");St(d,"type","qwik/json"),d.textContent=Mc(JSON.stringify(p.state,void 0,void 0)),r.appendChild(d);const g=Array.from(o.$events$,h=>JSON.stringify(h)),x=e.createElement("script");return x.textContent=`(window.qwikevents||=[]).push(${g.join(", ")})`,r.appendChild(x),p},Dc=async(t,e,a,l)=>{var P;const r=ii(e);l==null||l.forEach((S,E)=>{r.$seen$.add(E)});let o=!1;for(const S of t)if(S.$tasks$)for(const E of S.$tasks$)qr(E)&&r.$resources$.push(E.$state$),zr(E);for(const S of t){const E=S.$element$,B=S.li;for(const I of B)if(Fe(E)){const C=I[1],A=C.$captureRef$;if(A)for(const W of A)J(W,r,!0);r.$qrls$.push(C),o=!0}}if(!o)return{state:{refs:{},ctx:{},objs:[],subs:[]},objs:[],funcs:[],qrls:[],resources:r.$resources$,mode:"static"};let c;for(;(c=r.$promises$).length>0;)r.$promises$=[],await Promise.all(c);const p=r.$elements$.length>0;if(p){for(const S of r.$deferElements$)Sn(S,r,S.$element$);for(const S of t)kc(S,r)}for(;(c=r.$promises$).length>0;)r.$promises$=[],await Promise.all(c);const d=new Map,g=Array.from(r.$objSet$.keys()),x=new Map,h=S=>{let E="";if(ut(S)){const C=oi(S);if(!C)return null;S=C.value,E+=C.resolved?"~":"_"}if(Ht(S)){const C=Ze(S);if(C)E+="!",S=C;else if(ze(S)){const A=(W=>{let Y=d.get(W);return Y===void 0&&(Y=Bc(W),Y||console.warn("Missing ID",W),d.set(W,Y)),Y})(S);return A?"#"+A+E:null}}const B=x.get(S);if(B)return B+E;const I=l==null?void 0:l.get(S);return I?"*"+I:a?a(S):null},$=S=>{const E=h(S);if(E===null){if(kn(S)){const B=Oe(x.size);return x.set(S,B),B}throw it(27,S)}return E},_=new Map;for(const S of g){const E=(P=Nc(S,e))==null?void 0:P.$subs$;if(!E)continue;const B=hi(S)??0,I=[];1&B&&I.push(B);for(const C of E){const A=C[1];C[0]===0&&qe(A)&&Rt(A)&&!r.$elements$.includes(Pt(A))||I.push(C)}I.length>0&&_.set(S,I)}g.sort((S,E)=>(_.has(S)?0:1)-(_.has(E)?0:1));let k=0;for(const S of g)x.set(S,Oe(k)),k++;if(r.$noSerialize$.length>0){const S=x.get(void 0);for(const E of r.$noSerialize$)x.set(E,S)}const D=[];for(const S of g){const E=_.get(S);if(E==null)break;D.push(E.map(B=>typeof B=="number"?`_${B}`:$d(B,h)).filter(cr))}D.length,_.size;const T=ci(g,$,h,r,e),v={},L={};for(const S of t){const E=S.$element$,B=S.$id$,I=S.$refMap$,C=S.$props$,A=S.$contexts$,W=S.$tasks$,Y=S.$componentQrl$,U=S.$seq$,rt={},ct=Rt(E)&&r.$elements$.includes(S);if(I.length>0){const nt=He(I,$," ");nt&&(L[B]=nt)}else if(p){let nt=!1;if(ct){const at=h(C);rt.h=$(Y)+(at?" "+at:""),nt=!0}else{const at=h(C);at&&(rt.h=" "+at,nt=!0)}if(W&&W.length>0){const at=He(W,h," ");at&&(rt.w=at,nt=!0)}if(ct&&U&&U.length>0){const at=He(U,$," ");rt.s=at,nt=!0}if(A){const at=[];A.forEach((Nt,Bt)=>{const Ct=h(Nt);Ct&&at.push(`${Bt}=${Ct}`)});const pt=at.join(" ");pt&&(rt.c=pt,nt=!0)}nt&&(v[B]=rt)}}return{state:{refs:L,ctx:v,objs:T,subs:D},objs:g,funcs:r.$inlinedFunctions$,resources:r.$resources$,qrls:r.$qrls$,mode:p?"render":"listeners"}},He=(t,e,a)=>{let l="";for(const r of t){const o=e(r);o!==null&&(l!==""&&(l+=a),l+=o)}return l},Pc=(t,e)=>{const a=[],l=e(t);l!==void 0&&a.push(l);const r=t.ownerDocument.createTreeWalker(t,1|Wr,{acceptNode(o){if(Ic(o))return 2;const c=e(o);return c!==void 0&&a.push(c),3}});for(;r.nextNode(););return a},kc=(t,e)=>{var r;const a=t.$realParentCtx$||t.$parentCtx$,l=t.$props$;if(a&&l&&!ui(l)&&e.$elements$.includes(a)){const o=(r=$t(l))==null?void 0:r.$subs$,c=t.$element$;if(o)for(const[p,d]of o)p===0?(d!==c&&ca($t(l),e,!1),qe(d)?Cc(d,e):J(d,e,!0)):(J(l,e,!1),ca($t(l),e,!1))}},ii=t=>{const e=[];return t.$inlineFns$.forEach((a,l)=>{for(;e.length<=a;)e.push("");e[a]=l}),{$containerState$:t,$seen$:new Set,$objSet$:new Set,$prefetch$:0,$noSerialize$:[],$inlinedFunctions$:e,$resources$:[],$elements$:[],$qrls$:[],$deferElements$:[],$promises$:[]}},Lc=(t,e)=>{const a=Pt(t);e.$elements$.includes(a)||(e.$elements$.push(a),a.$flags$&fn?(e.$prefetch$++,Sn(a,e,!0),e.$prefetch$--):e.$deferElements$.push(a))},Cc=(t,e)=>{const a=Pt(t);if(a){if(e.$elements$.includes(a))return;e.$elements$.push(a),Sn(a,e,t)}},Sn=(t,e,a)=>{if(t.$props$&&!ui(t.$props$)&&(J(t.$props$,e,a),ca($t(t.$props$),e,a)),t.$componentQrl$&&J(t.$componentQrl$,e,a),t.$seq$)for(const l of t.$seq$)J(l,e,a);if(t.$tasks$){const l=e.$containerState$.$subsManager$.$groupToManagers$;for(const r of t.$tasks$)l.has(r)&&J(r,e,a)}if(a===!0&&(Us(t,e),t.$dynamicSlots$))for(const l of t.$dynamicSlots$)Us(l,e)},Us=(t,e)=>{for(;t;){if(t.$contexts$)for(const a of t.$contexts$.values())J(a,e,!0);t=t.$parentCtx$}},Mc=t=>t.replace(/<(\/?script)/gi,"\\x3C$1"),ca=(t,e,a)=>{if(e.$seen$.has(t))return;e.$seen$.add(t);const l=t.$subs$;for(const r of l)if(r[0]>0&&J(r[2],e,a),a===!0){const o=r[1];qe(o)&&Rt(o)?r[0]===0&&Lc(o,e):J(o,e,!0)}},Bl=Symbol(),jc=t=>t.then(e=>(t[Bl]={resolved:!0,value:e},e),e=>(t[Bl]={resolved:!1,value:e},e)),oi=t=>t[Bl],J=(t,e,a)=>{if(t!=null){const l=typeof t;switch(l){case"function":case"object":{if(e.$seen$.has(t))return;if(e.$seen$.add(t),xi(t))return e.$objSet$.add(void 0),void e.$noSerialize$.push(t);const r=t,o=Ze(t);if(o){const c=!(2&hi(t=o));if(a&&c&&ca($t(r),e,a),mi(r))return void e.$objSet$.add(t)}if(pd(t,e,a))return void e.$objSet$.add(t);if(ut(t))return void e.$promises$.push(jc(t).then(c=>{J(c,e,a)}));if(l==="object"){if(qe(t))return;if(lt(t))for(let c=0;c<t.length;c++)J(r[c],e,a);else if(Ma(t))for(const c in t)J(r[c],e,a)}break}}}e.$objSet$.add(t)},Ic=t=>Fe(t)&&t.hasAttribute("q:container"),Ec=t=>{const e=wn(t);if(ze(e)){const a=Pt(e);if(a&&a.$id$)return a}},Nc=(t,e)=>{if(!Ht(t))return;if(t instanceof Ta)return $t(t);const a=e.$proxyMap$.get(t);return a?$t(a):void 0},Bc=t=>{const e=Pt(t);return e?e.$id$:null},Ac=(t,e)=>{const a=t.previousSibling;if(a&&Ca(a)&&a.data.startsWith("t="))return"#"+a.data.slice(2);const l=t.ownerDocument,r=Oe(e.$elementIndex$++),o=l.createComment(`t=${r}`),c=l.createComment(""),p=t.parentElement;return p.insertBefore(o,t),p.insertBefore(c,t.nextSibling),"#"+r},ui=t=>Object.keys(t).length===0;function ci(t,e,a,l,r){return t.map(o=>{if(o===null)return null;const c=typeof o;switch(c){case"undefined":return yl;case"number":if(!Number.isFinite(o))break;return o;case"string":if(o.charCodeAt(0)<32)break;return o;case"boolean":return o}const p=gd(o,e,l,r);if(p!==void 0)return p;if(c==="object"){if(lt(o))return o.map(e);if(Ma(o)){const d={};for(const g in o)if(a){const x=a(o[g]);x!==null&&(d[g]=x)}else d[g]=e(o[g]);return d}}throw it(3,o)})}const f=(t,e,a=qt)=>Ra(null,e,t,null,null,a,null),O=(t,e=qt)=>Ra(null,t,null,null,null,e,null),Tn=(t,e={})=>{var g,x;let a=t.$symbol$,l=t.$chunk$;const r=t.$refSymbol$??a,o=ul();if(o){const h=o.chunkForSymbol(r,l,(g=t.dev)==null?void 0:g.file);h?(l=h[1],t.$refSymbol$||(a=h[0])):console.error("serializeQRL: Cannot resolve symbol",a,"in",l,(x=t.dev)==null?void 0:x.file)}if(l==null)throw it(31,t.$symbol$);if(l.startsWith("./")&&(l=l.slice(2)),Sd(t))if(e.$containerState$){const h=e.$containerState$,$=t.resolved.toString();let _=h.$inlineFns$.get($);_===void 0&&(_=h.$inlineFns$.size,h.$inlineFns$.set($,_)),a=String(_)}else ur("Sync QRL without containerState");let c=`${l}#${a}`;const p=t.$capture$,d=t.$captureRef$;return d&&d.length?e.$getObjId$?c+=`[${He(d,e.$getObjId$," ")}]`:e.$addRefMap$&&(c+=`[${He(d,e.$addRefMap$," ")}]`):p&&p.length>0&&(c+=`[${p.join(" ")}]`),c},Dn=(t,e,a)=>{a.$element$;const l={$containerState$:e,$addRefMap$:r=>Oc(a.$refMap$,r)};return He(t,r=>Tn(r,l),`
`)},$l=(t,e)=>{const a=t.length,l=Ys(t,0,"#"),r=Ys(t,l,"["),o=Math.min(l,r),c=t.substring(0,o),p=l==a?l:l+1,d=p==r?"default":t.substring(p,r),g=r===a?qt:t.substring(r+1,a-1).split(" "),x=Ra(c,d,null,null,g,null,null);return e&&x.$setContainer$(e),x},Ys=(t,e,a)=>{const l=t.length,r=t.indexOf(a,e==l?0:e);return r==-1?l:r},Oc=(t,e)=>{const a=t.indexOf(e);return a===-1?(t.push(e),String(t.length-1)):String(a)},di=(t,e)=>(t.$capture$,t.$captureRef$=t.$capture$.map(a=>{const l=parseInt(a,10),r=e.$refMap$[l];return e.$refMap$.length>l,r})),Zv=(t,e)=>(globalThis.__qwik_reg_symbols===void 0&&(globalThis.__qwik_reg_symbols=new Map),globalThis.__qwik_reg_symbols.set(e,t),t),Rc=t=>({__brand:"resource",value:void 0,loading:!Tt(),_resolved:void 0,_error:void 0,_state:"pending",_timeout:(t==null?void 0:t.timeout)??-1,_cache:0}),qc=t=>Ht(t)&&t.__brand==="resource",Fc=(t,e)=>{const a=t._state;return a==="resolved"?`0 ${e(t._resolved)}`:a==="pending"?"1":`2 ${e(t._error)}`},zc=t=>{const[e,a]=t.split(" "),l=Rc(void 0);return l.value=Promise.resolve(),e==="0"?(l._state="resolved",l._resolved=a,l.loading=!1):e==="1"?(l._state="pending",l.value=new Promise(()=>{}),l.loading=!0):e==="2"&&(l._state="rejected",l._error=a,l.loading=!1),l},dt=t=>i(Ne,{[dr]:""},0,t.name??""),yl="";function st(t){return{$prefixCode$:t.$prefix$.charCodeAt(0),$prefixChar$:t.$prefix$,$test$:t.$test$,$serialize$:t.$serialize$,$prepare$:t.$prepare$,$fill$:t.$fill$,$collect$:t.$collect$,$subs$:t.$subs$}}const Qc=st({$prefix$:"",$test$:t=>kn(t),$collect$:(t,e,a)=>{if(t.$captureRef$)for(const l of t.$captureRef$)J(l,e,a);e.$prefetch$===0&&e.$qrls$.push(t)},$serialize$:(t,e)=>Tn(t,{$getObjId$:e}),$prepare$:(t,e)=>$l(t,e.$containerEl$),$fill$:(t,e)=>{t.$capture$&&t.$capture$.length>0&&(t.$captureRef$=t.$capture$.map(e),t.$capture$=null)}}),Gc=st({$prefix$:"",$test$:t=>pn(t),$collect$:(t,e,a)=>{J(t.$qrl$,e,a),t.$state$&&(J(t.$state$,e,a),a===!0&&t.$state$ instanceof Ta&&ca(t.$state$[Ot],e,!0))},$serialize$:(t,e)=>ku(t,e),$prepare$:t=>Lu(t),$fill$:(t,e)=>{t.$el$=e(t.$el$),t.$qrl$=e(t.$qrl$),t.$state$&&(t.$state$=e(t.$state$))}}),Hc=st({$prefix$:"",$test$:t=>qc(t),$collect$:(t,e,a)=>{J(t.value,e,a),J(t._resolved,e,a)},$serialize$:(t,e)=>Fc(t,e),$prepare$:t=>zc(t),$fill$:(t,e)=>{if(t._state==="resolved")t._resolved=e(t._resolved),t.value=Promise.resolve(t._resolved);else if(t._state==="rejected"){const a=Promise.reject(t._error);a.catch(()=>null),t._error=e(t._error),t.value=a}}}),Vc=st({$prefix$:"",$test$:t=>t instanceof URL,$serialize$:t=>t.href,$prepare$:t=>new URL(t)}),Wc=st({$prefix$:"",$test$:t=>t instanceof Date,$serialize$:t=>t.toISOString(),$prepare$:t=>new Date(t)}),Uc=st({$prefix$:"\x07",$test$:t=>t instanceof RegExp,$serialize$:t=>`${t.flags} ${t.source}`,$prepare$:t=>{const e=t.indexOf(" "),a=t.slice(e+1),l=t.slice(0,e);return new RegExp(a,l)}}),Yc=st({$prefix$:"",$test$:t=>t instanceof Error,$serialize$:t=>t.message,$prepare$:t=>{const e=new Error(t);return e.stack=void 0,e}}),Jc=st({$prefix$:"",$test$:t=>!!t&&typeof t=="object"&&or(t),$prepare$:(t,e,a)=>a}),ll=Symbol("serializable-data"),Zc=st({$prefix$:"",$test$:t=>Ln(t),$serialize$:(t,e)=>{const[a]=t[ll];return Tn(a,{$getObjId$:e})},$prepare$:(t,e)=>{const a=$l(t,e.$containerEl$);return b(a)},$fill$:(t,e)=>{var l;const[a]=t[ll];(l=a.$capture$)!=null&&l.length&&(a.$captureRef$=a.$capture$.map(e),a.$capture$=null)}}),Kc=st({$prefix$:"",$test$:t=>t instanceof jl,$collect$:(t,e,a)=>{if(t.$args$)for(const l of t.$args$)J(l,e,a)},$serialize$:(t,e,a)=>{const l=eu(t);let r=a.$inlinedFunctions$.indexOf(l);return r<0&&(r=a.$inlinedFunctions$.length,a.$inlinedFunctions$.push(l)),He(t.$args$,e," ")+" @"+Oe(r)},$prepare$:t=>{const e=t.split(" "),a=e.slice(0,-1),l=e[e.length-1];return new jl(l,a,l)},$fill$:(t,e)=>{t.$func$,t.$func$=e(t.$func$),t.$args$=t.$args$.map(e)}}),Xc=st({$prefix$:"",$test$:t=>t instanceof Ta,$collect$:(t,e,a)=>(J(t.untrackedValue,e,a),a===!0&&!(t[Sa]&Qu)&&ca(t[Ot],e,!0),t),$serialize$:(t,e)=>e(t.untrackedValue),$prepare$:(t,e)=>{var a;return new Ta(t,(a=e==null?void 0:e.$subsManager$)==null?void 0:a.$createManager$(),0)},$subs$:(t,e)=>{t[Ot].$addSubs$(e)},$fill$:(t,e)=>{t.untrackedValue=e(t.untrackedValue)}}),td=st({$prefix$:"",$test$:t=>t instanceof Il,$collect$(t,e,a){if(J(t.ref,e,a),mi(t.ref)){const l=$t(t.ref);xd(e.$containerState$.$subsManager$,l,a)&&J(t.ref[t.prop],e,a)}return t},$serialize$:(t,e)=>`${e(t.ref)} ${t.prop}`,$prepare$:t=>{const[e,a]=t.split(" ");return new Il(e,a)},$fill$:(t,e)=>{t.ref=e(t.ref)}}),ed=st({$prefix$:"",$test$:t=>typeof t=="number",$serialize$:t=>String(t),$prepare$:t=>Number(t)}),ad=st({$prefix$:"",$test$:t=>t instanceof URLSearchParams,$serialize$:t=>t.toString(),$prepare$:t=>new URLSearchParams(t)}),ld=st({$prefix$:"",$test$:t=>typeof FormData<"u"&&t instanceof globalThis.FormData,$serialize$:t=>{const e=[];return t.forEach((a,l)=>{e.push(typeof a=="string"?[l,a]:[l,a.name])}),JSON.stringify(e)},$prepare$:t=>{const e=JSON.parse(t),a=new FormData;for(const[l,r]of e)a.append(l,r);return a}}),nd=st({$prefix$:"",$test$:t=>Je(t),$collect$:(t,e,a)=>{J(t.children,e,a),J(t.props,e,a),J(t.immutableProps,e,a),J(t.key,e,a);let l=t.type;l===dt?l=":slot":l===G&&(l=":fragment"),J(l,e,a)},$serialize$:(t,e)=>{let a=t.type;return a===dt?a=":slot":a===G&&(a=":fragment"),`${e(a)} ${e(t.props)} ${e(t.immutableProps)} ${e(t.key)} ${e(t.children)} ${t.flags}`},$prepare$:t=>{const[e,a,l,r,o,c]=t.split(" ");return new pa(e,a,l,o,parseInt(c,10),r)},$fill$:(t,e)=>{t.type=md(e(t.type)),t.props=e(t.props),t.immutableProps=e(t.immutableProps),t.key=e(t.key),t.children=e(t.children)}}),sd=st({$prefix$:"",$test$:t=>typeof t=="bigint",$serialize$:t=>t.toString(),$prepare$:t=>BigInt(t)}),rd=st({$prefix$:"",$test$:t=>t instanceof Uint8Array,$serialize$:t=>{let e="";for(const a of t)e+=String.fromCharCode(a);return btoa(e).replace(/=+$/,"")},$prepare$:t=>{const e=atob(t),a=new Uint8Array(e.length);let l=0;for(const r of e)a[l++]=r.charCodeAt(0);return a},$fill$:void 0}),ia=Symbol(),id=st({$prefix$:"",$test$:t=>t instanceof Set,$collect$:(t,e,a)=>{t.forEach(l=>J(l,e,a))},$serialize$:(t,e)=>Array.from(t).map(e).join(" "),$prepare$:t=>{const e=new Set;return e[ia]=t,e},$fill$:(t,e)=>{const a=t[ia];t[ia]=void 0;const l=a.length===0?[]:a.split(" ");for(const r of l)t.add(e(r))}}),od=st({$prefix$:"",$test$:t=>t instanceof Map,$collect$:(t,e,a)=>{t.forEach((l,r)=>{J(l,e,a),J(r,e,a)})},$serialize$:(t,e)=>{const a=[];return t.forEach((l,r)=>{a.push(e(r)+" "+e(l))}),a.join(" ")},$prepare$:t=>{const e=new Map;return e[ia]=t,e},$fill$:(t,e)=>{const a=t[ia];t[ia]=void 0;const l=a.length===0?[]:a.split(" ");l.length%2;for(let r=0;r<l.length;r+=2)t.set(e(l[r]),e(l[r+1]))}}),ud=st({$prefix$:"\x1B",$test$:t=>!!pi(t)||t===yl,$serialize$:t=>t,$prepare$:t=>t}),vl=[Qc,Gc,Hc,Vc,Wc,Uc,Yc,Jc,Zc,Kc,Xc,td,ed,ad,ld,nd,sd,id,od,ud,rd],Js=(()=>{const t=[];return vl.forEach(e=>{const a=e.$prefixCode$;for(;t.length<a;)t.push(void 0);t.push(e)}),t})();function pi(t){if(typeof t=="string"){const e=t.charCodeAt(0);if(e<Js.length)return Js[e]}}const cd=vl.filter(t=>t.$collect$),dd=t=>{for(const e of vl)if(e.$test$(t))return!0;return!1},pd=(t,e,a)=>{for(const l of cd)if(l.$test$(t))return l.$collect$(t,e,a),!0;return!1},gd=(t,e,a,l)=>{for(const r of vl)if(r.$test$(t)){let o=r.$prefixChar$;return r.$serialize$&&(o+=r.$serialize$(t,e,a,l)),o}if(typeof t=="string")return t},gi=(t,e)=>{const a=new Map,l=new Map;return{prepare(r){const o=pi(r);if(o){const c=o.$prepare$(r.slice(1),t,e);return o.$fill$&&a.set(c,o),o.$subs$&&l.set(c,o),c}return r},subs(r,o){const c=l.get(r);return!!c&&(c.$subs$(r,o,t),!0)},fill(r,o){const c=a.get(r);return!!c&&(c.$fill$(r,o,t),!0)}}},fd={"!":(t,e)=>e.$proxyMap$.get(t)??tn(t,e),"~":t=>Promise.resolve(t),_:t=>Promise.reject(t)},xd=(t,e,a)=>{if(typeof a=="boolean")return a;const l=t.$groupToManagers$.get(a);return!!(l&&l.length>0)&&(l.length!==1||l[0]!==e)},md=t=>t===":slot"?dt:t===":fragment"?G:t,Kv=(t,e)=>Al(t,new Set,"_",e),Al=(t,e,a,l)=>{const r=Oa(t);if(r==null)return t;if(hd(r)){if(e.has(r)||(e.add(r),dd(r)))return t;const o=typeof r;switch(o){case"object":if(ut(r)||qe(r))return t;if(lt(r)){let p=0;return r.forEach((d,g)=>{if(g!==p)throw it(3,r);Al(d,e,a+"["+g+"]"),p=g+1}),t}if(Ma(r)){for(const[p,d]of Object.entries(r))Al(d,e,a+"."+p);return t}break;case"boolean":case"string":case"number":return t}let c="";if(c=l||"Value cannot be serialized",a!=="_"&&(c+=` in ${a},`),o==="object")c+=` because it's an instance of "${t==null?void 0:t.constructor.name}". You might need to use 'noSerialize()' or use an object literal instead. Check out https://qwik.dev/docs/advanced/dollar/`;else if(o==="function"){const p=t.name;c+=` because it's a function named "${p}". You might need to convert it to a QRL using $(fn):

const ${p} = $(${String(t)});

Please check out https://qwik.dev/docs/advanced/qrl/ for more information.`}console.error("Trying to serialize",t),ur(c)}return t},Pn=new WeakSet,fi=new WeakSet,hd=t=>!Ht(t)&&!yt(t)||!Pn.has(t),xi=t=>Pn.has(t),mi=t=>fi.has(t),_l=t=>(t!=null&&Pn.add(t),t),bd=t=>(fi.add(t),t),Oa=t=>Ht(t)?Ze(t)??t:t,Ze=t=>t[Pl],$t=t=>t[Ot],hi=t=>t[aa],$d=(t,e)=>{const a=t[0],l=typeof t[1]=="string"?t[1]:e(t[1]);if(!l)return;let r=a+" "+l,o;if(a===0)o=t[2];else{const c=e(t[2]);if(!c)return;a<=2?(o=t[5],r+=` ${c} ${Zs(e(t[3]))} ${t[4]}`):a<=4&&(o=t[4],r+=` ${c} ${typeof t[3]=="string"?t[3]:Zs(e(t[3]))}`)}return o&&(r+=` ${encodeURI(o)}`),r},yd=(t,e)=>{const a=t.split(" "),l=parseInt(a[0],10);a.length>=2;const r=e(a[1]);if(!r||pn(r)&&!r.$el$)return;const o=[l,r];return l===0?(a.length<=3,o.push(Dl(a[2]))):l<=2?(a.length===5||a.length,o.push(e(a[2]),e(a[3]),a[4],Dl(a[5]))):l<=4&&(a.length===4||a.length,o.push(e(a[2]),e(a[3]),Dl(a[4]))),o},Dl=t=>{if(t!==void 0)return decodeURI(t)},vd=t=>{const e=new Map;return{$groupToManagers$:e,$createManager$:l=>new _d(e,t,l),$clearSub$:l=>{const r=e.get(l);if(r){for(const o of r)o.$unsubGroup$(l);e.delete(l),r.length=0}},$clearSignal$:l=>{const r=e.get(l[1]);if(r)for(const o of r)o.$unsubEntry$(l)}}};class _d{constructor(e,a,l){this.$groupToManagers$=e,this.$containerState$=a,this.$subs$=[],l&&this.$addSubs$(l)}$addSubs$(e){this.$subs$.push(...e);for(const a of this.$subs$)this.$addToGroup$(a[1],this)}$addToGroup$(e,a){let l=this.$groupToManagers$.get(e);l||this.$groupToManagers$.set(e,l=[]),l.includes(a)||l.push(a)}$unsubGroup$(e){const a=this.$subs$;for(let l=0;l<a.length;l++)a[l][1]===e&&(a.splice(l,1),l--)}$unsubEntry$(e){const[a,l,r,o]=e,c=this.$subs$;if(a===1||a===2){const p=e[4];for(let d=0;d<c.length;d++){const g=c[d];g[0]===a&&g[1]===l&&g[2]===r&&g[3]===o&&g[4]===p&&(c.splice(d,1),d--)}}else if(a===3||a===4)for(let p=0;p<c.length;p++){const d=c[p];d[0]===a&&d[1]===l&&d[2]===r&&d[3]===o&&(c.splice(p,1),p--)}}$addSub$(e,a){const l=this.$subs$,r=e[1];e[0]===0&&l.some(([o,c,p])=>o===0&&c===r&&p===a)||(l.push(bi=[...e,a]),this.$addToGroup$(r,this))}$notifySubs$(e){const a=this.$subs$;for(const l of a){const r=l[l.length-1];e&&r&&r!==e||fu(l,this.$containerState$)}}}let bi;function wd(){return bi}const Zs=t=>{if(t==null)throw Ve("must be non null",t);return t},kn=t=>typeof t=="function"&&typeof t.getSymbol=="function",Sd=t=>kn(t)&&t.$symbol$=="<sync>",Ra=(t,e,a,l,r,o,c)=>{let p;const d=async function(...v){return await _.call(this,bt())(...v)},g=v=>(p||(p=v),p),x=v=>typeof v!="function"||!(r!=null&&r.length)&&!(o!=null&&o.length)?v:function(...L){let P=bt();if(P){const S=P.$qrl$;P.$qrl$=d;const E=P.$event$;P.$event$===void 0&&(P.$event$=this);try{return v.apply(this,L)}finally{P.$qrl$=S,P.$event$=E}}return P=_t(),P.$qrl$=d,P.$event$=this,xt.call(this,P,v,...L)},h=async v=>{if(a!==null)return a;if(v&&g(v),t===""){const S=p.getAttribute(pr),E=gr(p.ownerDocument,S);return d.resolved=a=E[Number(e)]}const L=Pd(),P=bt();{const S=ul().importSymbol(p,t,e);a=Z(S,E=>d.resolved=a=x(E))}return a.finally(()=>Td(e,P==null?void 0:P.$element$,L)),a},$=v=>a!==null?a:h(v);function _(v,L){return(...P)=>Z($(),S=>{if(!yt(S))throw it(10);if(L&&L()===!1)return;const E=k(v);return xt.call(this,E,S,...P)})}const k=v=>v==null?_t():lt(v)?Qr(v):v,D=c??e,T=$i(D);return Object.assign(d,{getSymbol:()=>D,getHash:()=>T,getCaptured:()=>o,resolve:h,$resolveLazy$:$,$setContainer$:g,$chunk$:t,$symbol$:e,$refSymbol$:c,$hash$:T,getFn:_,$capture$:r,$captureRef$:o,dev:null,resolved:void 0}),a&&(a=Z(a,v=>d.resolved=a=x(v))),d},$i=t=>{const e=t.lastIndexOf("_");return e>-1?t.slice(e+1):t};const Ks=new Set,Td=(t,e,a)=>{Ks.has(t)||(Ks.add(t),Dd("qsymbol",{symbol:t,element:e,reqTime:a}))},Dd=(t,e)=>{Tt()||typeof document!="object"||document.dispatchEvent(new CustomEvent(t,{bubbles:!1,detail:e}))},Pd=()=>Tt()?0:typeof performance=="object"?performance.now():0,kd=function(t,e){return Ra("","<sync>",t,null,null,null,null)},b=t=>{function e(a,l,r){const o=t.$hash$.slice(0,4)+":"+(l||"");return i(Ne,{[bo]:t,[Dt]:a[Dt],[s]:a[s],children:a.children,props:a},r,o)}return e[ll]=[t],e},Ln=t=>typeof t=="function"&&t[ll]!==void 0,Me=(t,e)=>{const{val:a,set:l,iCtx:r}=Ye();if(a!=null)return a;const o=yt(t)?xt(void 0,t):t;if((e==null?void 0:e.reactive)===!1)return l(o),o;{const c=tn(o,r.$renderCtx$.$static$.$containerState$,(e==null?void 0:e.deep)??!0?1:0);return l(c),c}};function Cn(t,e){var l;const a=bt();return((l=a==null?void 0:a.$renderCtx$)==null?void 0:l.$static$.$containerState$.$serverData$[t])??e}const Ld=t=>{Cd(t,e=>e)},Cd=(t,e,a)=>{const{val:l,set:r,iCtx:o,i:c,elCtx:p}=Ye();if(l)return l;const d=jo(t,c),g=o.$renderCtx$.$static$.$containerState$;if(r(d),p.$appendStyles$||(p.$appendStyles$=[]),p.$scopeIds$||(p.$scopeIds$=[]),g.$styleIds$.has(d))return d;g.$styleIds$.add(d);const x=t.$resolveLazy$(g.$containerEl$),h=$=>{p.$appendStyles$,p.$appendStyles$.push({styleId:d,content:e($,d)})};return ut(x)?o.$waitOn$.push(x.then(h)):h(x),d},Xs={defaultLocale:{lang:"en",currency:"USD",timeZone:"America/Los_Angeles"},supportedLocales:[{lang:"en",currency:"USD",timeZone:"America/Los_Angeles"},{lang:"es",currency:"USD",timeZone:"America/Los_Angeles"}],assets:["app"]},Md=({params:t,locale:e})=>{const a=Xs.supportedLocales.find(r=>r.lang===t.lang);console.log(t);const l=a?a.lang:!t.lang&&Xs.defaultLocale.lang;l&&e(l)},jd=Object.freeze(Object.defineProperty({__proto__:null,onRequest:Md},Symbol.toStringTag,{value:"Module"})),Id='((i,a,r,s)=>{r=e=>{const t=document.querySelector("[q\\\\:base]");t&&a.active&&a.active.postMessage({type:"qprefetch",base:t.getAttribute("q:base"),...e})},document.addEventListener("qprefetch",e=>{const t=e.detail;a?r(t):i.push(t)}),navigator.serviceWorker.register("/service-worker.js").then(e=>{s=()=>{a=e,i.forEach(r),r({bundles:i})},e.installing?e.installing.addEventListener("statechange",t=>{t.target.state=="activated"&&s()}):e.active&&s()}).catch(e=>console.error(e))})([])',yi=Vt("qc-s"),Ed=Vt("qc-c"),vi=Vt("qc-ic"),_i=Vt("qc-h"),wi=Vt("qc-l"),Si=Vt("qc-n"),Ti=Vt("qc-a"),Nd=Vt("qc-ir"),Bd=t=>{const e=window,a=location.pathname+location.search,l="_qCitySPA",r="_qCityHistoryPatch",o="_qCityBootstrap",c="_qCityInitPopstate",p="_qCityInitAnchors",d="_qCityInitVisibility",g="_qCityInitScroll",x="_qCityScrollEnabled",h="_qCityScrollDebounce",$="_qCityScroll",_=T=>{T&&e.scrollTo(T.x,T.y)},k=()=>{const T=document.documentElement;return{x:T.scrollLeft,y:T.scrollTop,w:Math.max(T.scrollWidth,T.clientWidth),h:Math.max(T.scrollHeight,T.clientHeight)}},D=T=>{const v=history.state||{};v[$]=T||k(),history.replaceState(v,"")};if(!e[l]&&!e[c]&&!e[p]&&!e[d]&&!e[g]){if(D(),e[c]=()=>{var T;if(!e[l]){if(e[x]=!1,clearTimeout(e[h]),a!==location.pathname+location.search){const L=t.closest("[q\\:container]").querySelector('a[q\\:key="AD_1"]');if(L){const P=L.closest("[q\\:container]"),S=L.cloneNode();S.setAttribute("q:nbs",""),S.style.display="none",P.appendChild(S),e[o]=S,S.click()}else location.reload()}else if(history.scrollRestoration==="manual"){const v=(T=history.state)==null?void 0:T[$];_(v),e[x]=!0}}},!e[r]){e[r]=!0;const T=history.pushState,v=history.replaceState,L=P=>(P===null||typeof P>"u"?P={}:(P==null?void 0:P.constructor)!==Object&&(P={_data:P}),P._qCityScroll=P._qCityScroll||k(),P);history.pushState=(P,S,E)=>(P=L(P),T.call(history,P,S,E)),history.replaceState=(P,S,E)=>(P=L(P),v.call(history,P,S,E))}e[p]=T=>{if(e[l]||T.defaultPrevented)return;const v=T.target.closest("a[href]");if(v&&!v.hasAttribute("preventdefault:click")){const L=v.getAttribute("href"),P=new URL(location.href),S=new URL(L,P),E=S.origin===P.origin,B=S.pathname+S.search===P.pathname+P.search;if(E&&B)if(T.preventDefault(),S.href!==P.href&&history.pushState(null,"",S),!S.hash)S.href.endsWith("#")?window.scrollTo(0,0):(e[x]=!1,clearTimeout(e[h]),D({...k(),x:0,y:0}),location.reload());else{const I=S.hash.slice(1),C=document.getElementById(I);C&&C.scrollIntoView()}}},e[d]=()=>{!e[l]&&e[x]&&document.visibilityState==="hidden"&&D()},e[g]=()=>{e[l]||!e[x]||(clearTimeout(e[h]),e[h]=setTimeout(()=>{D(),e[h]=void 0},200))},e[x]=!0,setTimeout(()=>{addEventListener("popstate",e[c]),addEventListener("scroll",e[g],{passive:!0}),document.body.addEventListener("click",e[p]),e.navigation||document.addEventListener("visibilitychange",e[d],{passive:!0})},0)}},Ad=f(Bd,"s_DyVc0YBIqQU"),Od=()=>{{const[t,e]=ul().chunkForSymbol(Ad.getSymbol(),null),a=io+"build/"+e;return`(${Rd.toString()})('${a}','${t}');`}},Rd=async(t,e)=>{var a;if(!window._qcs&&history.scrollRestoration==="manual"){window._qcs=!0;const l=(a=history.state)==null?void 0:a._qCityScroll;l&&window.scrollTo(l.x,l.y);const r=document.currentScript;(await import(t))[e](r)}},qd=()=>{const t=Od();V();const e=Cn("nonce"),a=da(vi);if(a.value&&a.value.length>0){const l=a.value.length;let r=null;for(let o=l-1;o>=0;o--)a.value[o].default&&(r=i(a.value[o].default,{children:r},1,"zl_0"));return i(G,{children:[r,n("script",{dangerouslySetInnerHTML:t},{nonce:e},null,3,null)]},1,"zl_1")}return sn},Xv=b(f(qd,"s_e0ssiDXoeAM")),Fa=new Map,Di="qaction",tr=t=>t.pathname+t.search+t.hash,je=(t,e)=>new URL(t,e.href),Pi=(t,e)=>t.origin===e.origin,er=t=>t.endsWith("/")?t:t+"/",ki=({pathname:t},{pathname:e})=>{const a=Math.abs(t.length-e.length);return a===0?t===e:a===1&&er(t)===er(e)},Fd=(t,e)=>t.search===e.search,Li=(t,e)=>Fd(t,e)&&ki(t,e),zd=(t,e,a)=>{let l=e??"";return a&&(l+=(l?"&":"?")+Di+"="+encodeURIComponent(a.id)),t+(t.endsWith("/")?"":"/")+"q-data.json"+l},Qd=(t,e)=>{const a=t.href;if(typeof a=="string"&&typeof t.target!="string"&&!t.reload)try{const l=je(a.trim(),e.url),r=je("",e.url);if(Pi(l,r))return tr(l)}catch(l){console.error(l)}else if(t.reload)return tr(je("",e.url));return null},Gd=(t,e)=>{if(t){const a=je(t,e.url),l=je("",e.url);return!Li(a,l)}return!1},Hd=(t,e)=>{if(t){const a=je(t,e.url),l=je("",e.url);return!ki(a,l)}return!1},Vd=t=>t&&typeof t.then=="function",Wd=(t,e,a,l)=>{const r=Ci(),c={head:r,withLocale:p=>Rs(l,p),resolveValue:p=>{const d=p.__id;if(p.__brand==="server_loader"&&!(d in t.loaders))throw new Error("You can not get the returned data of a loader that has not been executed for this request.");const g=t.loaders[d];if(Vd(g))throw new Error("Loaders returning a promise can not be resolved for the head function.");return g},...e};for(let p=a.length-1;p>=0;p--){const d=a[p]&&a[p].head;d&&(typeof d=="function"?ar(r,Rs(l,()=>d(c))):typeof d=="object"&&ar(r,d))}return c.head},ar=(t,e)=>{typeof e.title=="string"&&(t.title=e.title),za(t.meta,e.meta),za(t.links,e.links),za(t.styles,e.styles),za(t.scripts,e.scripts),Object.assign(t.frontmatter,e.frontmatter)},za=(t,e)=>{if(Array.isArray(e))for(const a of e){if(typeof a.key=="string"){const l=t.findIndex(r=>r.key===a.key);if(l>-1){t[l]=a;continue}}t.push(a)}},Ci=()=>({title:"",meta:[],links:[],styles:[],scripts:[],frontmatter:{}});let lr;(function(t){t[t.EOL=0]="EOL",t[t.OPEN_BRACKET=91]="OPEN_BRACKET",t[t.CLOSE_BRACKET=93]="CLOSE_BRACKET",t[t.DOT=46]="DOT",t[t.SLASH=47]="SLASH"})(lr||(lr={}));const Ud=t=>{},Yd=async(t,e,a)=>{const l=t.pathname,r=t.search,o=zd(l,r,a==null?void 0:a.action);let c;a!=null&&a.action||(c=Fa.get(o)),a==null||a.prefetchSymbols;let p;if(!c){const d=Jd(a==null?void 0:a.action);a!=null&&a.action&&(a.action.data=void 0),c=fetch(o,d).then(g=>{const x=new URL(g.url),h=x.pathname.endsWith("/q-data.json");if(x.origin!==location.origin||!h){location.href=x.href;return}if((g.headers.get("content-type")||"").includes("json"))return g.text().then($=>{const _=nu($,e);if(!_){location.href=t.href;return}if(a!=null&&a.clearCache&&Fa.delete(o),_.redirect)location.href=_.redirect;else if(a!=null&&a.action){const{action:k}=a,D=_.loaders[k.id];p=()=>{k.resolve({status:g.status,result:D})}}return _});location.href=t.href}),a!=null&&a.action||Fa.set(o,c)}return c.then(d=>(d||Fa.delete(o),p&&p(),d))},Jd=t=>{const e=t==null?void 0:t.data;if(e)return e instanceof FormData?{method:"POST",body:e}:{method:"POST",body:JSON.stringify(e),headers:{"Content-Type":"application/json, charset=UTF-8"}}},t_=()=>da(_i),ot=()=>da(wi),Mi=()=>da(Si),Zd=()=>da(Ti),ji=()=>_l(Cn("qwikcity")),Kd=":root{view-transition-name:none}",Xd=async(t,e)=>{const[a,l,r,o]=tt(),{type:c="link",forceReload:p=t===void 0,replaceState:d=!1,scroll:g=!0}=typeof e=="object"?e:{forceReload:e},x=r.value.dest,h=t===void 0?x:je(t,o.url);if(Pi(h,x)&&!(!p&&Li(h,x)))return r.value={type:c,dest:h,forceReload:p,replaceState:d,scroll:g},a.value=void 0,o.isNavigating=!0,new Promise($=>{l.r=$})},tp=({track:t})=>{const[e,a,l,r,o,c,p,d,g,x,h]=tt();async function $(){const[k,D]=t(()=>[x.value,e.value]),T=Eu(""),v=h.url,L=D?"form":k.type;k.replaceState;let P,S,E=null;if(P=new URL(k.dest,h.url),E=o.loadedRoute,S=o.response,E){const[B,I,C,A]=E,W=C,Y=W[W.length-1];h.prevUrl=v,h.url=P,h.params={...I},x.untrackedValue={type:L,dest:P};const U=Wd(S,h,W,T);a.headings=Y.headings,a.menu=A,l.value=_l(W),r.links=U.links,r.meta=U.meta,r.styles=U.styles,r.scripts=U.scripts,r.title=U.title,r.frontmatter=U.frontmatter}}return $()},ep=t=>{Ld(f(Kd,"s_RPDJAz33WLA"));const e=ji();if(!(e!=null&&e.params))throw new Error("Missing Qwik City Env Data");const a=Cn("url");if(!a)throw new Error("Missing Qwik URL Env Data");const l=new URL(a),r=Me({url:l,params:e.params,isNavigating:!1,prevUrl:void 0},{deep:!1}),o={},c=bd(Me(e.response.loaders,{deep:!1})),p=N({type:"initial",dest:l,forceReload:!1,replaceState:!1,scroll:!0}),d=Me(Ci),g=Me({headings:void 0,menu:void 0}),x=N(),h=e.response.action,$=h?e.response.loaders[h]:void 0,_=N($?{id:h,data:e.response.formData,output:{result:$,status:e.response.status}}:void 0),k=f(Xd,"s_fX0bDjeJa0E",[_,o,p,r]);return Ce(Ed,g),Ce(vi,x),Ce(_i,d),Ce(wi,r),Ce(Si,k),Ce(yi,c),Ce(Ti,_),Ce(Nd,p),dn(f(tp,"s_02wMImzEAbk",[_,g,x,d,e,k,c,o,t,p,r])),i(dt,null,3,"qY_0")},e_=b(f(ep,"s_TxCFOy819ag")),ap=(t,e)=>{var a;if(!((a=navigator.connection)!=null&&a.saveData)&&e&&e.href){const l=new URL(e.href);Ud(l.pathname),e.hasAttribute("data-prefetch")&&Yd(l,e,{prefetchSymbols:!1})}},lp=async(t,e)=>{const[a,l,r,o]=tt();t.defaultPrevented&&(e.hasAttribute("q:nbs")?await a(location.href,{type:"popstate"}):e.href&&(e.setAttribute("aria-pressed","true"),await a(e.href,{forceReload:l,replaceState:r,scroll:o}),e.removeAttribute("aria-pressed")))},np=t=>{const e=Mi(),a=ot(),{onClick$:l,prefetch:r,reload:o,replaceState:c,scroll:p,...d}=t,g=$a(()=>Qd({...d,reload:o},a));d["link:app"]=!!g,d.href=g||t.href;const x=$a(()=>!!g&&r!==!1&&r!=="js"&&Gd(g,a)||void 0),$=$a(()=>x||!!g&&r!==!1&&Hd(g,a))?f(ap,"s_Osdg8FnYTw4"):void 0,_=g?kd((D,T)=>{D.metaKey||D.ctrlKey||D.shiftKey||D.altKey||D.preventDefault()}):void 0;return X("a",{...d,children:i(dt,null,3,"AD_0"),"data-prefetch":x,onClick$:[_,l,g?f(lp,"s_pIf0khHUxfY",[e,o,c,p]):void 0],onFocus$:[d.onFocus$,$],onMouseOver$:[d.onMouseOver$,$],onQVisible$:[d.onQVisible$,$]},null,0,"AD_1")},zt=b(f(np,"s_8gdLBszqbaM")),a_=t=>n("script",{nonce:w(t,"nonce")},{dangerouslySetInnerHTML:Id},null,3,"1Z_0"),sp=(t={})=>{throw tt(),new Error(`Actions can not be invoked within the server during SSR.
Action.run() can only be called on the browser, for example when a user clicks a button, or submits a form.`)},rp=(t,...e)=>{const{id:a,validators:l}=Ei(e,t);function r(){const o=ot(),c=Zd(),p={actionPath:`?${Di}=${a}`,isRunning:!1,status:void 0,value:void 0,formData:void 0},d=Me(()=>{const x=c.value;if(x&&(x==null?void 0:x.id)===a){const h=x.data;if(h instanceof FormData&&(p.formData=h),x.output){const{status:$,result:_}=x.output;p.status=$,p.value=_}}return p}),g=f(sp,"s_A5bZC7WO00A",[c,a,o,d]);return p.submit=g,d}return r.__brand="server_action",r.__validators=l,r.__qrl=t,r.__id=a,Object.freeze(r),r},Ii=(t,...e)=>{const a=rp(t,...e);return typeof globalThis._qwikActionsMap>"u"&&(globalThis._qwikActionsMap=new Map),globalThis._qwikActionsMap.set(a.__id,a),a},q=(t,...e)=>{const{id:a,validators:l}=Ei(e,t);function r(){return da(yi,o=>{if(!(a in o))throw new Error(`routeLoader$ "${t.getSymbol()}" was invoked in a route where it was not declared.
    This is because the routeLoader$ was not exported in a 'layout.tsx' or 'index.tsx' file of the existing route.
    For more information check: https://qwik.builder.io/qwikcity/route-loader/

    If your are managing reusable logic or a library it is essential that this function is re-exported from within 'layout.tsx' or 'index.tsx file of the existing route otherwise it will not run or throw exception.
    For more information check: https://qwik.builder.io/docs/cookbook/re-exporting-loaders/`);return w(o,a)})}return r.__brand="server_loader",r.__qrl=t,r.__validators=l,r.__id=a,Object.freeze(r),r},ip=async function(...t){var a;const[e]=tt();t.length>0&&t[0]instanceof AbortSignal&&t.shift();{const l=[(a=ji())==null?void 0:a.ev,this,Fu()].find(r=>r&&Object.prototype.hasOwnProperty.call(r,"sharedMap")&&Object.prototype.hasOwnProperty.call(r,"cookie"));return e.apply(l,t)}},l_=t=>{{const a=t.getCaptured();if(a&&a.length>0&&!qu())throw new Error("For security reasons, we cannot serialize QRLs that capture lexical scope.")}function e(){return f(ip,"s_wOIPfiQ04l4",[t])}return e()},Ei=(t,e)=>{let a;const l=[];if(t.length===1){const r=t[0];r&&typeof r=="object"&&("validate"in r?l.push(r):(a=r.id,r.validation&&l.push(...r.validation)))}else t.length>1&&l.push(...t.filter(r=>!!r));return typeof a=="string"?a=`id_${a}`:a=e.getHash(),{validators:l.reverse(),id:a}},op=({action:t,spaReset:e,reloadDocument:a,onSubmit$:l,...r},o)=>(V(),t?X("form",{...r,action:w(t,"actionPath"),"preventdefault:submit":!a,"data-spa-reset":e?"true":void 0,onSubmit$:[a?void 0:t.submit,l]},{method:"post"},0,o):i(dp,{onSubmit$:l,reloadDocument:a,spaReset:e,...r},0,o)),up=async(t,e)=>{const[a]=tt(),l=new FormData(e),r=new URLSearchParams;l.forEach((o,c)=>{typeof o=="string"&&r.append(c,o)}),a("?"+r.toString(),{type:"form",forceReload:!0}).then(()=>{e.getAttribute("data-spa-reset")==="true"&&e.reset(),e.dispatchEvent(new CustomEvent("submitcompleted",{bubbles:!1,cancelable:!1,composed:!1,detail:{status:200}}))})},cp=t=>{const e=ko(t,["action","spaReset","reloadDocument","onSubmit$"]),a=Mi();return X("form",{...e,children:i(dt,null,3,"BC_0"),onSubmit$:f(up,"s_p9MSze0ojs4",[a])},{action:"get","data-spa-reset":u(l=>l.spaReset?"true":void 0,[t],'p0.spaReset?"true":undefined'),"preventdefault:submit":u(l=>!l.reloadDocument,[t],"!p0.reloadDocument")},0,"BC_1")},dp=b(f(cp,"s_Nk9PlpjQm9Y")),pp=t=>n("div",null,{class:"w-fit h-fit flex items-center justify-center",role:"status"},n("svg",null,{"aria-hidden":"true",class:u(e=>`w-[${e.size}] h-[${e.size}] text-gray-200 animate-spin dark:text-blue-300 fill-primary-blue`,[t],"`w-[${p0.size}] h-[${p0.size}] text-gray-200 animate-spin dark:text-blue-300 fill-primary-blue`"),viewBox:"0 0 100 101",fill:"none",xmlns:"http://www.w3.org/2000/svg"},[n("path",null,{d:"M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",fill:"currentColor"},null,3,null),n("path",null,{d:"M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",fill:"currentFill"},null,3,null)],3,null),3,"73_0"),Gt=b(f(pp,"s_kpSoQCQrots")),Ni="https://strapi42.rtatel.com",gp=`${Ni}/graphql`,ft=t=>`${Ni}${t}`,ka=t=>t==="es"?"es-419":t,y=`
data {
    attributes {
        url
        alternativeText
        caption
        formats
    }
}
`,H=t=>{let e=[],a=!0;return t.schema&&(t.schema.includes('<script type="application/ld+json">')&&(a=!1),e=t.schema.split(a?"<script>":'<script type="application/ld+json">').flatMap(l=>l.split(a?"<script>":'<script type="application/ld+json">')).flatMap(l=>l.replace("<\/script>","")).reduce((l,r)=>r?[...l,r]:l,[])),e.flat(),{title:t.MetaTitle,scripts:[...e.map(l=>({props:a?{}:{type:"application/ld+json"},script:l}))],meta:[{name:"description",content:t.MetaDescription},{name:"keywords",content:t.Keywords}]}},z=`
SEO {
    MetaTitle
    MetaDescription
    Keywords
    preventIndexing
    schema
}
`,fa=`
data{
      attributes{
       	Content{
          Titles{
            Text
          }
          TextContent
        }
`,Bi=`
MembersGrid{
           Picture{
         ${y}
        }
        FirstName
        LastName
        Position
        SocialMedia{
          Icon{
            ${y}
          }
          Link
        }
      }
`,fp=t=>`
sectionNetwork (locale:"${t}"){
  data {
    attributes {
      Map {
        MapPicture {
          ${y}
        }
        ServersTitle
        Servers {
          Text
          Link
          Icon{
            ${y}
          }
        }
      }
      Description{
        Title
        Paragraph
      }
    }
  }
}
`,xp=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],mp=["January","February","March","April","May","June","July","August","September","October","November","December"];function Ha(t,e=!0){const a=new Date(t),l=xp[a.getDay()],r=a.getDate(),o=mp[a.getMonth()],c=a.getFullYear();return`${e?l+", ":""}${e?o:o.slice(0,3)} ${r}, ${c}`}const hp=()=>n("div",null,{class:"flex absolute flex-col items-center justify-center m-auto gap-2 h-full w-full bg-gradient-radial from-white via-slate-200 to-slate-300"},[n("img",null,{src:ft("/uploads/RTA_db22afd96e.webp"),alt:"RTA image loading",width:250,height:200},null,3,null),i(Gt,{size:"150px",[s]:{size:s}},3,"yL_0")],1,"yL_1"),bp=b(f(hp,"s_BeMhGs9mjvk")),$p=async({cacheControl:t})=>{t({staleWhileRevalidate:604800,maxAge:5})},yp=()=>({date:new Date().toISOString()}),vp=q(f(yp,"s_GQamrjryd1Y")),_p=()=>{const[t]=tt();t.value=!0},wp=()=>{V();const t=N(!0);return dn(f(_p,"s_lROQwus8zWc",[t])),Lt(O("s_Ku7AU0gi0Go",[t])),i(G,{children:t.value?n("div",null,{id:"splash",class:"h-full w-full flex"},i(bp,null,3,"XF_0"),1,"XF_1"):i(dt,null,3,"XF_2")},1,"XF_3")},Sp=b(f(wp,"s_VkLNXphUh5s")),Tp=Object.freeze(Object.defineProperty({__proto__:null,default:Sp,onGet:$p,useServerTimeLoader:vp},Symbol.toStringTag,{value:"Module"})),Dp=()=>{const t=["https://images.unsplash.com/photo-1693825948507-acd866203fae?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8MXx8fGVufDB8fHx8fA%3D%3D","https://images.unsplash.com/photo-1694476053120-d729a3f6a7ed?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8fA%3D%3D","https://images.unsplash.com/photo-1695256294687-5df561945542?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8MTB8fHxlbnwwfHx8fHw%3D"],e=N(0);return Lt(O("s_aXdoh0xz8cQ",[t,e])),n("div",null,null,n("img",{src:t[e.value]},{class:"transition-opacity duration-2000 ease-in-out opacity-100",alt:"Slider",width:150,height:150},null,3,null),1,"Sz_0")},Pp=b(f(Dp,"s_X6NIVA8H4IM")),kp=()=>i(G,{children:i(Pp,null,3,"Ch_0")},1,"Ch_1"),Lp=b(f(kp,"s_nUdxvD3SCSo")),Cp=Object.freeze(Object.defineProperty({__proto__:null,default:Lp},Symbol.toStringTag,{value:"Module"})),Mp=async(t,e,a)=>{const r=await fetch(`https://autosuggest.search.hereapi.com/v1/autosuggest?apiKey=IbuSA9oJnZ_SSAN3hiD9EFv0fxE0mijeZF2QQjcjl6Y&q=${t}&at=${e},${a}&in=countryCode:USA`);return r.status!==200?[]:(await r.json()).items.map(p=>{var d,g;return{address:p.title,zip:((g=(d=p.title)==null?void 0:d.split(", ")[2])==null?void 0:g.split(" ")[1])||"",position:p.position}})},jp=async({json:t,query:e})=>{const a=e.get("q");if(!a)t(400,{message:"Bad request (need ?q param)"});else{const l=await Mp(a,29.62540053919014,-95.39478748016545);t(200,{data:l})}},Ip=Object.freeze(Object.defineProperty({__proto__:null,onGet:jp},Symbol.toStringTag,{value:"Module"})),Ai=t=>`
query QueryLayout {
    generalMenu(locale: "${t}") {
      data {
        attributes {
          TopOptions {
            Icon {
              ${y}
            }
            Text
            Link
          }
  
          localizations {
            data {
              attributes {
                MainOptions {
                  Text
                  Link
                  SubOption {
                    Text
                    Link
                  }
                }
              }
            }
          }
  
          MainMenu {
            Logo {
              ${y}
            }
            Switcher {
              Text
              Link
              Icon {
                ${y}
              }
            }
          }
          MainOptions {
            Text
            Link
            SubOption {
              Text
              Link
              MenuOption {
                data {
                  attributes {
                    SubOption {
                      Text
                      Link
                    }
                  }
                }
              }
            }
          }
          ClientOptions {
            Text
            Link
          }
          gigfastOptions {
            Text
            Link
            Icon {
              ${y}
            }
          }
        }
      }
    }
    generalFooter(locale: "${t}") {
      data {
        attributes {
          SupportSection {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          CorpInfo {
            Media {
              ${y}
            }
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          Menus {
            Text
            SubOption {
              Text
              Link
            }
          }
          SocialMedia {
            Text
            SubOption {
              Icon {
                ${y}
              }
              Link
            }
          }
        }
      }
    }
    generalHeader {
      data {
        attributes {
          Slide {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
        }
      }
    }
  } 
`;async function La(t){return await(await fetch(gp,{method:"POST",cache:"no-cache",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:t})})).json()}async function Q(t,e="en",a=!0){let l={};a&&(l=await La(Ai(ka(e))));const r=await La(t(ka(e)));return{layoutData:l,pageData:r}}async function qa(t,e="en",a=!0){let l={};a&&(l=await La(Ai(ka(e))));const r=await La(t);return{layoutData:l,pageData:r}}const Ep=async t=>{const e=await t.parseBody(),a=await La(e.query);t.json(200,a)},Np=Object.freeze(Object.defineProperty({__proto__:null,onPost:Ep},Symbol.toStringTag,{value:"Module"}));async function Bp(t,e,a,l,r,o){const p=`https://supa42.rtatel.com/notifications/api${o?"/attachment":""}`,d={action:"rtaMail",subject:e,template:t,mailto:a,variables:l};o&&(d.attachment={filename:"resume.pdf",file:o});try{const g=await fetch(p,{method:"POST",body:JSON.stringify(d),headers:{"Content-Type":"application/json"}});if(g.ok){location.reload();const x=r.includes("es")?"¡Enviado Correctamente!":"Successfully Sent!";alert(x)}else{const x=await g.json(),h=r.includes("es")?"Error al enviar el formulario: ":"Error while trying to send the form: ";alert(`${h} ${x.message}`)}}catch(g){console.error("Error en la solicitud:",g),alert("Hubo un error al enviar el formulario.")}}const Ap=Object.freeze(Object.defineProperty({__proto__:null,sendMail:Bp},Symbol.toStringTag,{value:"Module"})),Op=async({request:t,json:e})=>{const a=await t.json();e(200,{body:a})},Rp=Object.freeze(Object.defineProperty({__proto__:null,onPost:Op},Symbol.toStringTag,{value:"Module"})),qp=t=>n("img",{src:ft(t.media.url),srcset:t.media.formats&&t.media.formats.small&&`${ft(t.media.formats.small.url)} 40w, ${ft(t.media.url)} 800w`},{width:u(e=>e.width??150,[t],"p0.width??150"),height:u(e=>e.height??150,[t],"p0.height??150"),title:u(e=>e.media.caption,[t],'p0.media["caption"]'),alt:u(e=>e.media.alternativeText,[t],'p0.media["alternativeText"]'),class:u(e=>(e.toWhite??!1?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+(e.clasN??""),[t],'(p0.toWhite??false?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+""+(p0.clasN??"")'),sizes:"(max-width: 600px) 40px, 800px"},null,3,"cI_0"),M=b(f(qp,"s_LQFPgtOeNdI")),Fp=t=>X("svg",{...t,children:n("path",null,{d:"M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"xG_0"),zp=t=>X("svg",{...t,children:n("path",null,{d:"M201.4 342.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 274.7 86.6 137.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"xH_0"),Qp=t=>X("svg",{...t,children:n("path",null,{d:"M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"GB_0"),Gp=t=>X("svg",{...t,children:n("path",null,{d:"M96 32V64H48C21.5 64 0 85.5 0 112v48H448V112c0-26.5-21.5-48-48-48H352V32c0-17.7-14.3-32-32-32s-32 14.3-32 32V64H160V32c0-17.7-14.3-32-32-32S96 14.3 96 32zM448 192H0V464c0 26.5 21.5 48 48 48H400c26.5 0 48-21.5 48-48V192z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"nO_0"),Hp=t=>X("svg",{...t,children:n("path",null,{d:"M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"p8_0"),Vp=t=>X("svg",{...t,children:n("path",null,{d:"M0 256a256 256 0 1 0 512 0A256 256 0 1 0 0 256zM281 385c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l71-71L136 280c-13.3 0-24-10.7-24-24s10.7-24 24-24l182.1 0-71-71c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0L393 239c9.4 9.4 9.4 24.6 0 33.9L281 385z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 512 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"tx_0"),Wp=t=>X("svg",{...t,children:n("path",null,{d:"M256 448c141.4 0 256-93.1 256-208S397.4 32 256 32S0 125.1 0 240c0 45.1 17.7 86.8 47.7 120.9c-1.9 24.5-11.4 46.3-21.4 62.9c-5.5 9.2-11.1 16.6-15.2 21.6c-2.1 2.5-3.7 4.4-4.9 5.7c-.6 .6-1 1.1-1.3 1.4l-.3 .3 0 0 0 0 0 0 0 0c-4.6 4.6-5.9 11.4-3.4 17.4c2.5 6 8.3 9.9 14.8 9.9c28.7 0 57.6-8.9 81.6-19.3c22.9-10 42.4-21.9 54.3-30.6c31.8 11.5 67 17.9 104.1 17.9zM128 208a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 0a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm96 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 512 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Bu_0"),Mn=t=>X("svg",{...t,children:n("path",null,{d:"M429.6 92.1c4.9-11.9 2.1-25.6-7-34.7s-22.8-11.9-34.7-7l-352 144c-14.2 5.8-22.2 20.8-19.3 35.8s16.1 25.8 31.4 25.8H224V432c0 15.3 10.8 28.4 25.8 31.4s30-5.1 35.8-19.3l144-352z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 448 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"ak_0"),Oi=t=>X("svg",{...t,children:n("path",null,{d:"M384 192c0 87.4-117 243-168.3 307.2c-12.3 15.3-35.1 15.3-47.4 0C117 435 0 279.4 0 192C0 86 86 0 192 0S384 86 384 192z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 384 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"6Z_0"),Up=t=>X("svg",{...t,children:n("path",null,{d:"M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"},null,3,null)},{"data-qwikest-icon":!0,fill:"currentColor",height:"1em",stroke:"none",viewBox:"0 0 384 512",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"4m_0"),Yp=t=>{const e=N(!1);return n("div",null,{class:"relative w-fit"},[n("span",null,{class:u(a=>`${a.containerClass??""} flex cursor-pointer items-center gap-2`,[t],'`${p0.containerClass??""} flex cursor-pointer items-center gap-2`'),onClick$:O("s_F3aQ057DSxY",[e]),onFocusout$:O("s_eygkshVHA6I",[e])},[n("span",null,null,u(a=>a.title,[t],"p0.title"),3,null),i(zp,null,3,"bO_0")],1,null),n("div",null,{class:u(a=>`absolute bottom-0 left-0 right-0 top-full z-10 min-w-[140px]  rounded-md bg-white shadow-lg transition-all duration-300 ${a.value?"":"hidden"}`,[e],'`absolute bottom-0 left-0 right-0 top-full z-10 min-w-[140px]  rounded-md bg-white shadow-lg transition-all duration-300 ${p0.value?"":"hidden"}`')},i(dt,null,3,"bO_1"),1,null)],1,"bO_2")},nl=b(f(Yp,"s_f0Yr0C5H5Es")),Jp=()=>{const[t]=tt();let e="";t?e="/"+window.location.pathname.split("/es/")[1]:e="/es"+window.location.pathname,window.location.pathname=e},Zp=t=>{var r;const a=(r=ot().prevUrl)==null?void 0:r.pathname.includes("/es/");return n("div",null,{class:"relative flex cursor-pointer items-center justify-center self-center rounded-full bg-gray-100 shadow-sm",onClick$:f(Jp,"s_W5KXXUmo6j8",[a])},[i(M,{get media(){return t.data[0].Icon.data.attributes},clasN:`h-[36px] w-[36px] m-1 rounded-full ${a?"opacity-30":"border-2 border-primary-blue border-opacity-50"}`,[s]:{media:u(o=>o.data[0].Icon.data.attributes,[t],'p0.data[0]["Icon"]["data"]["attributes"]')}},3,"tf_0"),i(M,{get media(){return t.data[1].Icon.data.attributes},clasN:`h-[36px] w-[36px] m-1 rounded-full ${a?"border-2 border-primary-blue border-opacity-50":"opacity-30"}  `,[s]:{media:u(o=>o.data[1].Icon.data.attributes,[t],'p0.data[1]["Icon"]["data"]["attributes"]')}},3,"tf_1")],1,"tf_2")},Kp=b(f(Zp,"s_mIn2RUIc9QU")),Xp=t=>{V();const e=N(!0);return n("div",null,{class:"bg-blue-900 h-[550px] w-full sm:w-4/5 flex flex-col justify-between items-center p-6 rounded-2xl"},[n("h2",null,{class:"text-white font-bold text-xl md:text-4xl mb-2"},"Get in contact with us",3,null),e.value?i(Gt,{size:"250px",[s]:{size:s}},3,"iV_0"):null,n("iframe",null,{id:"portability-request",class:"w-full h-full overflow-x-visible overflow-y-visible",src:u(a=>a.link,[t],"p0.link"),onLoad$:O("s_fXnkVThI4oM",[e])},null,3,null)],1,"iV_1")},tg=b(f(Xp,"s_fvFnDV0yuRY")),eg=t=>X("svg",{...t,children:n("path",null,{d:"M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z","fill-rule":"evenodd"},null,3,null)},{class:"bi bi-arrow-right-short","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Gz_0"),ag=t=>X("svg",{...t,children:n("path",null,{d:"M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.5a1 1 0 0 0-.8.4l-1.9 2.533a1 1 0 0 1-1.6 0L5.3 12.4a1 1 0 0 0-.8-.4H2a2 2 0 0 1-2-2V2zm3.5 1a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm0 2.5a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm0 2.5a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5z"},null,3,null)},{class:"bi bi-chat-square-text-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"yq_0"),Ri=t=>X("svg",{...t,children:n("path",null,{d:"M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"},null,3,null)},{class:"bi bi-check-circle-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"Dp_0"),nr=t=>X("svg",{...t,children:n("path",null,{d:"M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"},null,3,null)},{class:"bi bi-check","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"0U_0"),qi=t=>X("svg",{...t,children:[n("path",null,{d:"M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"},null,3,null),n("path",null,{d:"M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"},null,3,null)]},{class:"bi bi-download","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"ME_0"),lg=t=>X("svg",{...t,children:[n("path",null,{d:"M2 2A2 2 0 0 0 .05 3.555L8 8.414l7.95-4.859A2 2 0 0 0 14 2H2Zm-2 9.8V4.698l5.803 3.546L0 11.801Zm6.761-2.97-6.57 4.026A2 2 0 0 0 2 14h6.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.606-3.446l-.367-.225L8 9.586l-1.239-.757ZM16 9.671V4.697l-5.803 3.546.338.208A4.482 4.482 0 0 1 12.5 8c1.414 0 2.675.652 3.5 1.671Z"},null,3,null),n("path",null,{d:"M15.834 12.244c0 1.168-.577 2.025-1.587 2.025-.503 0-1.002-.228-1.12-.648h-.043c-.118.416-.543.643-1.015.643-.77 0-1.259-.542-1.259-1.434v-.529c0-.844.481-1.4 1.26-1.4.585 0 .87.333.953.63h.03v-.568h.905v2.19c0 .272.18.42.411.42.315 0 .639-.415.639-1.39v-.118c0-1.277-.95-2.326-2.484-2.326h-.04c-1.582 0-2.64 1.067-2.64 2.724v.157c0 1.867 1.237 2.654 2.57 2.654h.045c.507 0 .935-.07 1.18-.18v.731c-.219.1-.643.175-1.237.175h-.044C10.438 16 9 14.82 9 12.646v-.214C9 10.36 10.421 9 12.485 9h.035c2.12 0 3.314 1.43 3.314 3.034v.21Zm-4.04.21v.227c0 .586.227.8.581.8.31 0 .564-.17.564-.743v-.367c0-.516-.275-.708-.572-.708-.346 0-.573.245-.573.791Z"},null,3,null)]},{class:"bi bi-envelope-at-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"9e_0"),Fi=t=>X("svg",{...t,children:n("path",null,{d:"M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"},null,3,null)},{class:"bi bi-geo-alt-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"62_0"),jn=t=>X("svg",{...t,children:[n("path",null,{d:"M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"},null,3,null),n("path",null,{d:"m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6Z"},null,3,null)]},{class:"bi bi-house-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"fX_0"),ng=t=>X("svg",{...t,children:n("path",null,{d:"M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"},null,3,null)},{class:"bi bi-info-circle-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"SU_0"),sg=t=>X("svg",{...t,children:n("path",null,{d:"M2 6a6 6 0 1 1 10.174 4.31c-.203.196-.359.4-.453.619l-.762 1.769A.5.5 0 0 1 10.5 13h-5a.5.5 0 0 1-.46-.302l-.761-1.77a1.964 1.964 0 0 0-.453-.618A5.984 5.984 0 0 1 2 6zm3 8.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1l-.224.447a1 1 0 0 1-.894.553H6.618a1 1 0 0 1-.894-.553L5.5 15a.5.5 0 0 1-.5-.5z"},null,3,null)},{class:"bi bi-lightbulb-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"IC_0"),rg=t=>X("svg",{...t,children:n("path",null,{d:"M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"},null,3,null)},{class:"bi bi-person-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"iB_0"),ig=t=>X("svg",{...t,children:n("path",null,{d:"M0 12V4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm6.79-6.907A.5.5 0 0 0 6 5.5v5a.5.5 0 0 0 .79.407l3.5-2.5a.5.5 0 0 0 0-.814l-3.5-2.5z"},null,3,null)},{class:"bi bi-play-btn-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"YD_0"),Ol=t=>X("svg",{...t,children:n("path",null,{d:"M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"},null,3,null)},{class:"bi bi-star-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"jB_0"),og=t=>X("svg",{...t,children:n("path",null,{d:"M5.354 5.119 7.538.792A.516.516 0 0 1 8 .5c.183 0 .366.097.465.292l2.184 4.327 4.898.696A.537.537 0 0 1 16 6.32a.548.548 0 0 1-.17.445l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256a.52.52 0 0 1-.146.05c-.342.06-.668-.254-.6-.642l.83-4.73L.173 6.765a.55.55 0 0 1-.172-.403.58.58 0 0 1 .085-.302.513.513 0 0 1 .37-.245l4.898-.696zM8 12.027a.5.5 0 0 1 .232.056l3.686 1.894-.694-3.957a.565.565 0 0 1 .162-.505l2.907-2.77-4.052-.576a.525.525 0 0 1-.393-.288L8.001 2.223 8 2.226v9.8z"},null,3,null)},{class:"bi bi-star-half","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"VK_0"),ug=t=>X("svg",{...t,children:n("path",null,{d:"M2 1a1 1 0 0 0-1 1v4.586a1 1 0 0 0 .293.707l7 7a1 1 0 0 0 1.414 0l4.586-4.586a1 1 0 0 0 0-1.414l-7-7A1 1 0 0 0 6.586 1H2zm4 3.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"},null,3,null)},{class:"bi bi-tag-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"vL_0"),zi=t=>X("svg",{...t,children:n("path",null,{d:"M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z","fill-rule":"evenodd"},null,3,null)},{class:"bi bi-telephone-fill","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"nW_0"),cg=t=>X("svg",{...t,children:[n("path",null,{d:"M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"},null,3,null),n("path",null,{d:"M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"},null,3,null)]},{class:"bi bi-upload","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"pX_0"),dg=t=>X("svg",{...t,children:n("path",null,{d:"M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"},null,3,null)},{class:"bi bi-x-lg","data-qwikest-icon":!0,fill:"currentColor",height:"1em",viewBox:"0 0 16 16",width:"1em",xmlns:"http://www.w3.org/2000/svg"},0,"fv_0"),pg=t=>{var g;V();const a=(g=ot().prevUrl)==null?void 0:g.pathname.includes("/es/"),l=N("NONE"),r=N(!1),o=N(!1),c=N(!1),p=N(!1),d=Lt(O("s_azU0komrCE4",[p,r,l,c,o,t]));return n("div",null,{class:"mx-auto flex max-w-lg flex-col rounded-3xl bg-white p-6"},n("form",null,{class:"mt-2",id:"contact_form","preventdefault:submit":!0,onSubmit$:O("s_mKzn6gnXAQk",[d])},[n("div",null,{class:"flex flex-wrap"},[n("div",null,{class:"mb-4 w-full sm:w-2/3"},[n("label",null,{for:"name",class:"block text-base font-medium text-[#2e5899]"},["Name ",n("span",null,{class:"text-red-600"},"*",3,null)," "],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(rg,{style:{color:"#2e5899"},[s]:{style:s}},3,"T4_0"),1,null),n("input",null,{type:"text",name:"from_name",class:"w-full rounded-full border border-[#2e5899] border-opacity-40 p-2 focus:border-blue-500 focus:outline-none",required:!0},null,3,null)],1,null)],1,null),n("div",null,{class:"mb-4 w-2/3 sm:w-1/3"},[n("label",null,{for:"zip_code",class:"block text-base font-medium text-[#2e5899]"},["Zip Code ",n("span",null,{class:"text-red-600"},"*",3,null)," "],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(Fi,{style:{color:"#2e5899"},[s]:{style:s}},3,"T4_1"),1,null),n("input",null,{type:"number",name:"zip_code",class:"w-full rounded-full border border-[#2e5899] border-opacity-40 p-2 focus:border-blue-500 focus:outline-none",minLength:5,maxLength:5,required:!0},null,3,null)],1,null)],1,null)],1,null),n("div",null,{class:"flex flex-wrap items-center md:flex-row"},[n("div",null,{class:"mb-4 w-full sm:w-1/2"},[n("label",null,{for:"email",class:"block text-base font-medium text-[#2e5899]"},["Email ",n("span",null,{class:"text-red-600"},"*",3,null)],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(lg,{style:{color:"#2e5899"},[s]:{style:s}},3,"T4_2"),1,null),n("input",null,{type:"email",name:"from_email",id:"from_email",class:"w-full rounded-full border border-[#2e5899] border-opacity-40 p-2 focus:border-blue-500 focus:outline-none",required:!0},null,3,null)],1,null),n("label",null,{class:u((x,h)=>`text-xs text-red-600 ${x.value==!1&&h.value==!0?"flex":"hidden"} bg-transparent`,[p,c],'`text-xs text-red-600 ${p0.value==false&&p1.value==true?"flex":"hidden"} bg-transparent`')},"email is invalid",3,null)],1,null),n("div",null,{class:"mb-4 w-full md:w-1/2"},[n("label",null,{for:"tel",class:"block text-base font-medium text-[#2e5899]"},"Phone",3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(zi,{style:{color:"#2e5899"},[s]:{style:s}},3,"T4_3"),1,null),n("input",null,{type:"tel",name:"tel",id:"tel",maxLength:10,class:"w-full rounded-full border border-[#2e5899] border-opacity-40 p-2 focus:border-blue-500 focus:outline-none"},null,3,null)],1,null),n("label",null,{class:u((x,h)=>`text-xs text-red-600 ${x.value==!1&&h.value==!0?"flex":"hidden"} bg-transparent`,[r,o],'`text-xs text-red-600 ${p0.value==false&&p1.value==true?"flex":"hidden"} bg-transparent`')},"phone number is invalid",3,null)],1,null)],1,null),n("div",null,{class:"mb-4"},[n("label",null,{for:"message",class:"block text-base font-medium text-[#2e5899]"},["Message",n("span",null,{class:"text-red-600"},"*",3,null)],3,null),n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(ag,{style:{color:"#2e5899"},[s]:{style:s}},3,"T4_4"),1,null),n("textarea",null,{name:"message",class:"w-full rounded-3xl border border-[#2e5899] border-opacity-40 p-2 focus:border-blue-500 focus:outline-none",rows:4,required:!0},null,3,null)],1,null)],1,null),n("button",{class:`flex flex-row items-center justify-center mt-4 bg-secondary-red text-white w-full font-semibold px-4 py-2 rounded-xl hover:bg-blue-600 focus:outline-none ${l.value==="LOADING"?"cursor-wait bg-primary-blue":l.value==="SUCCESS"?"bg-teal-500":""} focus:outline-none`},{type:"submit",disabled:u(x=>x.value==="LOADING"||x.value==="SUCCESS",[l],'p0.value==="LOADING"||p0.value==="SUCCESS"')},l.value==="NONE"?a?"Enviar":"Send":l.value==="LOADING"?i(Gt,{size:"28px",[s]:{size:s}},3,"T4_5"):l.value==="ERROR"?"Error":a?"¡Mensaje enviado!":"Email Sent!",1,null)],1,null),1,"T4_6")},gg=b(f(pg,"s_UlMR3Hqos6E")),fg=()=>{const[t,e]=tt();e.value=t},xg=t=>{var h;const e=new Set(t.data.map($=>$.attributes.Category)),a=t.data.filter($=>$.attributes.Category==="Sports"),l=t.data.filter($=>$.attributes.Category==="Movies"),r=t.data.filter($=>$.attributes.Category==="News"),o=t.data.filter($=>$.attributes.Category==="Music"),c=t.data.filter($=>$.attributes.Category==="Kids"),p=(h=t.planId)==null?void 0:h.slice(0,2),d=N(0),g=$=>$.map((_,k)=>{const D=_.attributes.package_tvs.data.some(v=>v.attributes.package.includes(p)),T=_.attributes.package_tvs.data.some(v=>v.attributes.package.includes("comingSoon"));return n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",{class:`h-[40px] w-[40px] md:h-[60px] md:w-[60px] ${D?"":"opacity-20"} flex flex-col rounded-full border-2 p-1`},null,i(M,{height:50,width:50,get media(){return _.attributes.Image.data.attributes},[s]:{height:s,width:s,media:m(_.attributes.Image.data,"attributes")}},3,"wr_0"),1,null),T?n("div",null,{class:"rounded-full bg-primary-blue p-0.5 text-center text-xs text-white"},"Coming Soon",3,"wr_1"):null,n("p",null,{class:"text-center text-xs text-primary-blue"},w(_.attributes,"Channel_name"),1,null)],1,k)}),x=Array.from(e).map(($,_)=>n("div",null,{class:"grid w-full grid-cols-3 gap-4 py-4 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8"},$==="General"?g(t.data):$==="Sports"?g(a):$==="News"?g(r):$==="Music"?g(o):$==="Movies"?g(l):$==="Kids"?g(c):null,1,_));return n("div",null,{class:"h-[800px] w-full rounded-3xl bg-blue-700 p-5 md:h-[500px] md:w-[800px] md:p-10"},[n("div",null,{class:"flex flex-col content-start items-center justify-start md:flex-row md:justify-between"},[n("h1",null,{class:"text-2xl font-semibold text-white md:text-4xl"},u($=>$.planId,[t],"p0.planId"),3,null),n("p",null,{class:"text-xl font-light text-white md:text-2xl"},u($=>$.channels,[t],"p0.channels"),3,null)],3,null),n("div",null,{class:"my-1 flex h-fit flex-row items-start justify-start gap-4 overflow-x-auto rounded-t-2xl bg-white px-2 py-2 font-bold text-primary-blue md:items-center md:justify-between md:overflow-clip"},Array.from(e).map(($,_)=>n("button",{class:`${d.value==_?"bg-gray-200":""} rounded-xl p-2`,onClick$:f(fg,"s_jPiPOXcEB6E",[_,d])},null,$,0,_)),1,null),n("div",null,{class:"flex h-3/4 w-full items-center justify-center rounded-b-3xl bg-white p-6"},Array.from(e).map(($,_)=>d.value==_?n("div",null,{class:"flex h-full w-full overflow-y-auto overflow-x-hidden rounded-2xl border-2 border-primary-blue bg-white py-4"},x[_],1,_):null),1,null)],1,"wr_2")},mg=b(f(xg,"s_bUc7uFb70ZI")),hg=t=>`query {
        offices (filters:{locations:{ZipCode:{eq:${t}}}}) {
          data {
            attributes {
              InstanceLink
            }
          }
        }
      }`,bg=t=>`query {
        offices(filters: { locations: { ZipCode: { eq: ${t} } } }) {
          data {
            attributes {
              Location
              Phone {
                Link
                Text
              }
            }
          }
        }
      }`,$g=async t=>{let e=null;const a=await qa(hg(t["zip-code"].toString()));return a.pageData.data.offices.data.length>0&&(e=await a.pageData.data.offices.data[0].attributes.InstanceLink),e},yg=Ii(f($g,"s_Aa7HFHe6DLE")),vg=async t=>{let e=null;const a=await qa(bg(t["zip-code"].toString()));return a.pageData.data.offices.data.length>0&&(e=await a.pageData.data.offices.data[0].attributes),e};Ii(f(vg,"s_txZGYKoQ0E8"));const _g=()=>{},wg=t=>{var o;V();const e=yg(),a=N(!1),r=(o=ot().prevUrl)==null?void 0:o.pathname.includes("/es/");return n("div",null,{class:" z-[800] flex h-fit w-[600px] flex-col items-center justify-center gap-4 rounded-full bg-blue-100 p-8"},[n("p",null,{class:"text-center text-4xl font-bold text-primary-blue"},u(c=>c.title,[t],"p0.title"),3,null),n("p",null,{class:"font-light"},u(c=>c.description,[t],"p0.description"),3,null),i(op,{class:"w-full",action:e,onSubmit$:f(_g,"s_SuMdNt0qey8"),children:n("div",null,{class:"flex flex-row items-center justify-center gap-4 px-4"},[n("div",null,{class:"flex items-center rounded p-2"},[n("div",null,{class:"mr-2"},i(Fi,{style:{color:"#2e5899"},[s]:{style:s}},3,"PA_0"),1,null),n("input",null,{type:"text",maxLength:5,name:"zip-code",placeholder:"Zip-code",required:!0,class:"rounded-full border border-gray-300 p-2 placeholder:text-primary-blue focus:border-blue-500 focus:outline-none"},null,3,null)],1,null),n("button",null,{class:"w-1/4 rounded-full border-2 border-teal-500 bg-white px-4 py-2 font-bold text-teal-500 hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",type:"submit",onClick$:O("s_odOkENLwWr0",[a,e])},u(c=>c.btnText,[t],"p0.btnText"),3,null)],1,null),[s]:{class:s,action:s,onSubmit$:s}},1,"PA_1"),t.popup==="login"&&e.isRunning&&i(Gt,{size:"50px",[s]:{size:s}},3,"PA_2"),t.popup==="login"&&!e.isRunning&&e.value!=null&&n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,null,"Portal found",3,null),n("a",null,{href:u(c=>c.value.toString(),[e],"p0.value.toString()")},n("button",null,{class:"w-full rounded-full border-2 border-teal-500 bg-white px-4 py-2 font-bold text-teal-500 hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"},r?"Ir al portal":"Go to portal",1,null),1,null)],1,"PA_3"),t.popup==="login"&&!e.isRunning&&e.value==null&&a.value&&n("p",null,{class:"text-2xl text-secondary-red"},r?"Portal no encontrado":"Portal not found",1,"PA_4"),t.popup!=="login"&&e.isRunning&&i(Gt,{size:"50px",[s]:{size:s}},3,"PA_5"),t.popup!=="login"&&!e.isRunning&&e.value!=null&&n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,null,e.value.Location.toString(),1,null),n("a",null,{href:u(c=>c.value.Phone.Link.toString(),[e],'p0.value["Phone"]["Link"].toString()')},n("button",null,{class:"w-full rounded-full border-2 border-teal-500 bg-white px-4 py-2 font-bold text-teal-500 hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"},u(c=>c.value.Phone.Text,[e],'p0.value["Phone"]["Text"]'),3,null),3,null)],1,"PA_6"),t.popup!=="login"&&!e.isRunning&&e.value==null&&a.value&&n("p",null,{class:"text-xs text-primary-blue"},u(c=>c.notFountText,[t],"p0.notFountText"),3,"PA_7")],1,"PA_8")},Rl=b(f(wg,"s_7GiaINstLc4")),Sg=t=>n("div",null,{class:"fixed bottom-0 left-0 right-0 bg-white top-0 z-[200] transition-all duration-1000 ease-in-out"},n("iframe",null,{src:u(e=>e.route,[t],"p0.route"),class:"h-full w-full",frameBorder:"0"},null,3,null),3,"V0_0"),Qi=b(f(Sg,"s_R079dt5Nweo")),Tg=t=>{const e=N(!1);return Lt(O("s_rTgprikOCoA",[e,t])),n("div",{class:`flex items-center justify-start hover:cursor-pointer ${e.value?"text-white bg-primary-blue":"text-primary-dark-blue bg-white"}  shadow-2xl px-4 rounded-2xl h-[50px] ${t.classN}`},null,[n("input",null,{id:u(a=>a.id,[t],"p0.id"),name:"answer",value:u(a=>a.text,[t],"p0.text"),type:"radio",class:"peer appearance-none border border-primary-dark-blue w-4 h-4 rounded-full mr-[20px] checked:bg-btn-green checked:border-white"},null,3,null),n("label",null,{for:u(a=>a.id,[t],"p0.id"),class:"w-full hover:cursor-pointer h-full flex items-center font-bold"},u(a=>a.text,[t],"p0.text"),3,null)],3,"ss_0")},Dg=b(f(Tg,"s_HFec7A1uToc")),Pg=t=>{const e=N(!1),a=N(!0);return Lt(O("s_nLcxs1o4e5w",[e,t])),n("div",null,{class:u(l=>`flex flex-col w-full shadow-2xl p-3 rounded-2xl ${l.value?"bg-primary-blue text-white":"bg-white text-primary-dark-blue"}`,[e],'`flex flex-col w-full shadow-2xl p-3 rounded-2xl ${p0.value?"bg-primary-blue text-white":"bg-white text-primary-dark-blue"}`')},[n("div",null,{class:u(l=>`flex flex-row items-center gap-3 justify-start hover:cursor-pointer ${l.classN} `,[t],"`flex flex-row items-center gap-3 justify-start hover:cursor-pointer ${p0.classN} `")},[n("input",null,{id:u(l=>l.id,[t],"p0.id"),name:"answer",value:u(l=>"followup-"+l.text,[t],'"followup-"+p0.text'),type:"radio",class:"peer appearance-none border border-primary-dark-blue w-4 h-4 shrink-0 rounded-full checked:bg-btn-green checked:border-white"},null,3,null),n("label",null,{for:u(l=>l.id,[t],"p0.id"),class:"hover:cursor-pointer flex flex-col w-full"},n("span",null,{class:"font-bold"},u(l=>l.text,[t],"p0.text"),3,null),3,null)],3,null),n("div",null,{class:u(l=>`${l.value?"flex flex-col":"hidden"}`,[e],'`${p0.value?"flex flex-col":"hidden"}`')},[n("span",null,null,u(l=>(l.description??"")!=""?`(${l.description??""})`:null,[t],'(p0.description??"")!=""?`(${p0.description??""})`:null'),3,null),n("textarea",{class:`appearance-none border rounded-2xl text-primary-dark-blue px-1
                                ${e.value&&a.value?"border-secondary-red":"border-primary-dark-blue"}`},{rows:3,name:u(l=>`${l.id}-textarea`,[t],"`${p0.id}-textarea`"),id:u(l=>`${l.id}-textarea`,[t],"`${p0.id}-textarea`"),required:u(l=>l.value,[e],"p0.value"),onInput$:O("s_0NlcmIrgrSg",[t])},null,3,null)],1,null)],1,"CH_0")},kg=b(f(Pg,"s_5IvA0RZVpzA")),Lg="https://supa42.rtatel.com",Cg="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ewogICAgInJvbGUiOiAiYW5vbiIsCiAgICAiaXNzIjogInN1cGFiYXNlIiwKICAgICJpYXQiOiAxNjg0ODI1MjAwLAogICAgImV4cCI6IDE4NDI2NzgwMDAKfQ.Atj9wTNbdEEVPOjstsO14DtxbY2SEpnr50elVXBgAmM",In=oo(Lg,Cg,{db:{schema:"rta_surveys"}}),Gi=2,Mg=async()=>{const{data:t,error:e}=await In.from("questions").select("*").eq("survey_id",Gi);if(e)throw console.error("Error en getQuestions: "+e),e;return t},jg=f(Mg,"s_gpAjyx0B0K8"),Ig=async()=>{const{data:t,error:e}=await In.from("survey_answers").insert([{survey_id:Gi,created_at:new Date().toISOString()}]).select("id");if(e)throw console.log("Error en insertSurveyAnswers: "+e),e;return t},Eg=f(Ig,"s_EyLLGHYmCDI"),Ng=async(t,e,a)=>{const{data:l,error:r}=await In.from("answers").insert([{survey_answers_id:t,question_id:e,answer:a,created_at:new Date().toISOString()}]);if(r)throw console.log("Error en insertAnswers: "+r),r;return l},Bg=f(Ng,"s_Pz1fK0TDz5w"),Ag=async()=>{const[t,e]=tt();(await jg()).map(l=>{l.is_radio?e.push({id:l.id,survey_id:l.survey_id,question:l.question,answers:[l.radio1,l.radio2,l.radio3,l.radio4]}):t.push({id:l.id,survey_id:l.survey_id,question:l.question,answers:[l.radio1]})})},Og=async()=>{var $;const[t,e,a,l,r,o]=tt();t.value=!0;const c=document.getElementById("form-leaving"),p=new FormData(c);let d="";const g="followup-",x=[...a,...e];p.forEach((_,k)=>{k.includes("answer")&&(d=_)});const h=d.length>0&&(d.includes(g)&&o.value!==""||!d.includes(g));try{if(h){r.value=!0;const _=d.includes(g)?o.value:d,k=($=x.find(T=>d.includes(g)?T.answers[0]===d.split(g).pop():T.answers.find(v=>v===d)))==null?void 0:$.id,D=await Eg();await Bg(D[0].id,k??0,_),l.signalPopupLeaving.value=!1,l.signalMainPopup.value=!1,window.localStorage.setItem("sendform_leaving","true")}}catch(_){throw console.log("Error: "+_),_}},Rg=t=>{const e=Me([]),a=Me([]),l=N(!1),r=N(!1),o=N("");dn(f(Ag,"s_0QW8yCiluKc",[a,e]));const c=f(Og,"s_q00AFmMZ9Pg",[r,a,e,t,l,o]);return n("div",null,{class:"fixed flex items-center justify-center h-full w-full bottom-0 left-0 right-0 bg-blue-300 bg-opacity-50 top-0 z-[700]"},n("div",null,{class:"flex flex-col items-center justify-evenly md:h-fit md:w-1/2 w-[80%] max-w-[600px] bg-[#DFEDFF] rounded-3xl p-5 pb-4 transition-all duration-1000 ease-in-out"},[n("form",null,{id:"form-leaving",class:"flex flex-col items-center justify-between w-full "},e.map((p,d)=>n("div",null,{class:"w-full"},[n("div",{class:`w-full  ${d==0?"h-[20%] min-h-[100px]":""}  flex flex-col items-center justify-center bg-gradient-to-tr from-primary-blue to-primary-light-blue rounded-2xl text-white mb-6 p-4 text-center`},null,[d==0?n("h2",null,{class:"font-bold sm:text-[35px] text-[24px]"},"Leaving so soon?",3,"O0_0"):"",n("p",null,null,w(p,"question"),1,null)],1,null),n("div",null,{class:"flex flex-col gap-2"},p.answers.map((g,x)=>{V();const h=a.find($=>$.answers[0]===g);return h?i(kg,{get id(){return h.id},text:g,get description(){return h.question},textareaSignal:o,[s]:{id:m(h,"id"),description:m(h,"question"),textareaSignal:s}},3,x):i(Dg,{classN:"w-full",text:g,id:p.id+"-"+x,[s]:{classN:s}},3,x)}),1,null)],1,d)),1,null),n("div",null,{class:u((p,d)=>`w-full rounded-3xl bg-secondary-red bg-opacity-70 text-center mt-1 ${p.value&&d.value==!1?"":"hidden"}`,[r,l],'`w-full rounded-3xl bg-secondary-red bg-opacity-70 text-center mt-1 ${p0.value&&p1.value==false?"":"hidden"}`')},"Please, fill the following:",3,null),n("button",null,{class:"text-white bg-btn-green font-bold py-2 px-4 w-fit h-fit rounded-3xl mt-4",onClick$:O("s_N36GmA7Tgos",[c])},"Submit",3,null)],1,null),1,"O0_1")},Hi=b(f(Rg,"s_F0u0TUxd0sI")),qg=t=>{var c,p;V();const a=(c=ot().prevUrl)==null?void 0:c.pathname.includes("/es/");let l=null;if(t.link.includes("=pConf=")){const d=t.link.replace("=pConf=","");l=i(Qi,{route:d},3,"Y1_0")}else if(t.link.includes("=pIFrame=")){const d=t.link.replaceAll("=pIFrame=","");l=i(tg,{link:d},3,"Y1_1")}else if(t.link.includes("=pContactEmail=")){const d=t.link.split("=");l=i(gg,{templateID:d[2],mailto:d[3],subject:d[4],lang:a?"es":"en"},3,"Y1_2")}else t.link.includes("=pChannelLineup=")?l=i(mg,{get channels(){return t.channels},get planId(){return t.planId},get data(){return t.dataChannels},[s]:{channels:u(d=>d.channels,[t],"p0.channels"),planId:u(d=>d.planId,[t],"p0.planId"),data:u(d=>d.dataChannels,[t],"p0.dataChannels")}},3,"Y1_3"):t.link.includes("=pLogin")?l=i(Rl,{title:a?"Inicia sesión en el portal de tu zona":"Log into the portal of your area",description:a?"Simplemente ingrese su código postal.":"Just enter your Zip code.",btnText:a?"Ir ahora":"Go Now",popup:"login",[s]:{popup:s}},3,"Y1_4"):t.link.includes("=pOfficeCall")&&(l=i(Rl,{popup:"location",title:a?"Llame a su oficina local":"Call your local office",description:a?"Descubra exactamente qué servicios ofrece RTA en su ciudad natal. Ingrese su código postal para el número de teléfono de su oficina local.":"Find out exactly what services RTA has to offer in your hometown. Input your zip code for your local office phone number.",notFountText:a?"Desafortunadamente, RTA no está disponible actualmente en su área. Sin embargo, RTA continúa expandiéndose en todo Estados Unidos. Si está interesado en los servicios de RTA en su área, envíenos un correo electrónico o llame a nuestra oficina principal.":"Find out exactly what services RTA has to offer in your hometown. Input your zip code for your local office phone number.",btnText:a?"Comprobar ahora":"Check Now",[s]:{popup:s}},3,"Y1_5"));const r=N(!1),o=N(!1);return n("div",null,{class:"relative flex"},[t.link.includes("=pConf=")&&(!((p=t.text)!=null&&p.includes("Check"))||!t.text.includes("Buscar"))?n("div",null,{class:"flex w-fit items-center justify-center rounded-full border-2 border-teal-500 border-opacity-70 bg-white p-0.5 px-1 text-btn-green opacity-90 shadow-md transition-all delay-150 ease-in-out hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:O("s_gRyPmBMRMEM",[r])},[n("p",null,{class:"min-sm:text-[13px] mx-2 text-[15px] font-[600] tracking-wide max-md:text-[14px] "},u(d=>d.text,[t],"p0.text"),3,null),n("div",null,{class:"flex h-[25px] w-[25px] items-center justify-center rounded-full bg-teal-500 p-0 opacity-70 "},i(ug,{class:"fill-white font-bold",[s]:{class:s}},3,"Y1_6"),1,null)],1,"Y1_7"):t.hasStyle??!0?n("button",{class:`flex w-fit items-center justify-center gap-2 ${t.link.includes("=pChannelLineup=")?"":"rounded-full border-2 border-teal-500 p-1 px-7 shadow-md transition-all  hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white"}  bg-white  text-[15px] font-[600]  text-btn-green opacity-80 max-md:text-[14px] max-sm:text-[13px] `},{onClick$:O("s_LMY0q14Gz9I",[r])},u(d=>d.text,[t],"p0.text"),3,null):n("div",null,{onClick$:O("s_CtCqQvywDJo",[r])},[i(dt,null,3,"Y1_8")," "],1,"Y1_9"),r.value&&n("div",null,{class:"fixed inset-0 z-[200] flex flex-col items-center justify-center bg-black bg-opacity-40"},n("div",null,{class:u(d=>` ${d.link.includes("=pConf=")?"w-full h-full flex-row-reverse ":"flex-col-reverse md:flex-row w-fit"} animate-zoomIn flex `,[t],'` ${p0.link.includes("=pConf=")?"w-full h-full flex-row-reverse ":"flex-col-reverse md:flex-row w-fit"} animate-zoomIn flex `')},[n("div",null,{class:"flex p-4 flex-wrap overflow-hidden items-center justify-center "},[l,t.link.includes("=pConf=")&&o.value&&window.localStorage.getItem("sendform_leaving")!="true"?i(Hi,{signalMainPopup:r,signalPopupLeaving:o,[s]:{signalMainPopup:s,signalPopupLeaving:s}},3,"Y1_10"):null],1,null),n("button",{class:`${t.link.includes("=pConf=")?"mt-2 mx-0":"w-[30px] p-4"} bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] focus:outline-none z-[600]`},{"aria-label":"Close popup",onClick$:O("s_Hg5lk0TunCg",[t,r,o])},t.link.includes("=pConf=")?n("div",null,{class:"px-3 flex flex-row items-center text-xs gap-2"},["Back to site ",i(jn,null,3,"Y1_11")],1,"Y1_12"):n("div",null,null,i(dg,null,3,"Y1_13"),1,null),1,null)],1,null),1,"Y1_14")],1,"Y1_15")},sl=b(f(qg,"s_G7PwpIAJKRA")),Fg=t=>{var r;V();const a=(r=ot().prevUrl)==null?void 0:r.pathname.includes("/es/"),l=t.link.startsWith("/");return t.link.startsWith("/")||t.link.startsWith("http")||t.link.startsWith("tel:")?i(zt,{get class(){return t.classN??""},href:(a&&l?"/es":"")+t.link,prefetch:!0,get target(){return t.link.startsWith("http")?"_blank":"_self"},children:i(dt,null,3,"8s_0"),[s]:{class:u(o=>o.classN??"",[t],'p0.classN??""'),prefetch:s,target:u(o=>o.link.startsWith("http")?"_blank":"_self",[t],'p0.link.startsWith("http")?"_blank":"_self"')}},1,"8s_1"):t.link.startsWith("=")&&t.link?i(sl,{get link(){return t.link},get text(){return t.text??""},get hasStyle(){return t.hasStyle??!0},children:[" ",n("div",null,{class:u(o=>`${o.classN??""} cursor-pointer`,[t],'`${p0.classN??""} cursor-pointer`')},i(dt,null,3,"8s_2"),1,null)],[s]:{link:u(o=>o.link,[t],"p0.link"),text:u(o=>o.text??"",[t],'p0.text??""'),hasStyle:u(o=>o.hasStyle??!0,[t],"p0.hasStyle??true")}},1,"8s_3"):n("div",null,{class:u(o=>o.classN??"",[t],'p0.classN??""')},i(dt,null,3,"8s_4"),1,"8s_5")},Mt=b(f(Fg,"s_nqL2AObZq60")),zg=t=>n("div",null,{class:"relative z-30 shadow-[0_5px_40px_-25px_rgba(0,0,0,0.2)]"},[n("div",null,{class:" fixed top-0 w-full shadow-[0_5px_40px_-25px_rgba(0,0,0,0.2)]"},[n("div",null,{class:"flex h-[28px] flex-row items-center justify-end gap-4 bg-primary-blue px-5 py-[4px] text-[12px] font-bold text-white max-sm:justify-evenly max-sm:text-[10px] max-sm:font-normal max-[400px]:text-[9px]"},t.data.TopOptions.map((e,a)=>i(Mt,{get link(){return e.Link},hasStyle:!1,get text(){return e.Text},children:n("div",null,{class:"flex flex-row items-center gap-2"},[n("div",null,{class:"w-[12px]"},i(M,{get media(){return e.Icon.data.attributes},toWhite:!0,width:"16",height:"16",[s]:{media:m(e.Icon.data,"attributes"),toWhite:s,width:s,height:s}},3,"Qt_0"),1,null),w(e,"Text")],1,null),[s]:{link:m(e,"Link"),hasStyle:s,text:m(e,"Text")}},1,a)),1,null),n("div",null,{class:"grid grid-cols-3 items-center justify-evenly bg-white px-3 py-1 min-[800px]:flex"},[n("button",null,{class:"mx-4 flex h-fit w-fit items-center justify-center rounded-3xl bg-primary-blue p-2 active:bg-primary-light-blue min-[800px]:hidden"},n("div",null,{onClick$:O("s_EXeZ7SCEUFc",[t])},i(Qp,{class:"fill-white object-fill min-[800px]:hidden",[s]:{class:s}},3,"Qt_1"),1,null),1,null),n("div",null,{class:"flex items-center justify-center"},n("div",null,{class:"w-[125px] py-1"},i(Mt,{link:"/",children:i(M,{get media(){return t.data.MainMenu.Logo.data.attributes},width:150,height:80,[s]:{media:u(e=>e.data.MainMenu.Logo.data.attributes,[t],'p0.data["MainMenu"]["Logo"]["data"]["attributes"]'),width:s,height:s}},3,"Qt_2"),[s]:{link:s}},1,"Qt_3"),1,null),1,null),n("div",null,{class:"flex items-center justify-center gap-4 px-3 text-[15px] max-[1200px]:text-[13px] max-[800px]:hidden"},t.data.MainOptions.map(function(e,a){V();const l=e.SubOption.length>0;return n("div",null,{class:" font-bold text-primary-blue "},l?i(nl,{get title(){return e.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},e.SubOption.map((r,o)=>{V();const c=r.MenuOption.data;return c?i(nl,{get title(){return r.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},c.attributes.SubOption.map((p,d)=>i(Mt,{get link(){return p.Link},children:w(p,"Text"),[s]:{link:m(p,"Link")}},1,d)),1,null),[s]:{title:m(r,"Text")}},1,"Qt_5"):i(Mt,{classN:"text-primary-blue",get link(){return r.Link},hasStyle:!1,children:w(r,"Text"),[s]:{classN:s,link:m(r,"Link"),hasStyle:s}},1,o)}),1,null),[s]:{title:m(e,"Text")}},1,"Qt_6"):i(Mt,{classN:"text-primary-blue",get link(){return e.Link},hasStyle:!1,children:w(e,"Text"),[s]:{classN:s,link:m(e,"Link"),hasStyle:s}},1,"Qt_4"),1,a)}),1,null),n("div",null,{class:"flex items-center justify-center"},i(Kp,{get data(){return t.data.MainMenu.Switcher},[s]:{data:u(e=>e.data.MainMenu.Switcher,[t],'p0.data["MainMenu"]["Switcher"]')}},3,"Qt_7"),1,null)],1,null)],1,null),n("div",null,{class:"mt-[89px] flex h-[32px] flex-row items-center justify-center gap-6 bg-secondary-red py-[2px] text-[14px] font-semibold tracking-[1px] text-white max-sm:text-[11px]"},t.data.ClientOptions.map((e,a)=>i(Mt,{get link(){return e.Link},children:w(e,"Text"),[s]:{link:m(e,"Link")}},1,a)),1,null),n("div",null,{class:"flex flex-row items-center justify-evenly bg-white py-1 max-[800px]:hidden"},t.data.gigfastOptions.map((e,a)=>i(Mt,{get link(){return e.Link},children:n("div",null,{class:"w-[130px] rounded-md p-1 hover:bg-slate-50"},i(M,{get media(){return e.Icon.data.attributes},width:"311",height:"60",[s]:{media:m(e.Icon.data,"attributes"),width:s,height:s}},3,"Qt_8"),1,null),[s]:{link:m(e,"Link")}},1,a)),1,null)],1,"Qt_9"),Qg=b(f(zg,"s_qJ0s4sH5iHo")),Gg=t=>{V();const e=N(!1);return n("div",null,{class:"my-8 mb-2 w-full"},[n("div",{class:`flex cursor-pointer flex-row items-center transition ${t.inFooter??!1?"":e.value?"rounded-b-none rounded-t-2xl":"rounded-full"} justify-between ${t.classContainer} p-2 `},{onClick$:O("s_n7LVHyx9gZ0",[e])},[n("h3",null,{class:"flex w-full items-center justify-center font-bold"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:u(a=>`flex h-[20px] w-[20px] items-center justify-center ${a.inFooter??!1?"":"rounded-full bg-secondary-red text-white"}`,[t],'`flex h-[20px] w-[20px] items-center justify-center ${p0.inFooter??false?"":"rounded-full bg-secondary-red text-white"}`')},n("span",null,{class:"w-1/8 flex items-center justify-end text-xs"},u(a=>a.value?"▲":"▼",[e],'p0.value?"▲":"▼"'),3,null),3,null)],3,null),e.value&&n("div",null,{class:u(a=>`${a.classChild} ${a.inFooter??!1?"":"rounded-b-2xl rounded-t-none border-t-2 bg-white"} p-2 text-center transition-all duration-500 ease-in-out`,[t],'`${p0.classChild} ${p0.inFooter??false?"":"rounded-b-2xl rounded-t-none border-t-2 bg-white"} p-2 text-center transition-all duration-500 ease-in-out`')},i(dt,null,3,"vV_0"),1,"vV_1")],1,"vV_2")},xa=b(f(Gg,"s_znBlgckysPY")),Hg=()=>{const[t]=tt();if(t.link){if(t.link.includes("http"))return window.open(t.link,"_blank");window.location.href=t.link}(t.onClick??(()=>{}))()},Vg=t=>{var a;V();const e=f(Hg,"s_5VUQoQPBpDA",[t]);return(t.type??"link")==="link"?(a=t.link)!=null&&a.startsWith("=")&&t.link?i(sl,{get link(){return t.link},get text(){return t.text},[s]:{link:u(l=>l.link,[t],"p0.link"),text:u(l=>l.text,[t],"p0.text")}},3,"ky_0"):n("div",null,{class:"flex w-fit items-center justify-center rounded-full border-2 border-teal-500 border-opacity-70 bg-white p-0.5 px-1 text-btn-green opacity-90 shadow-md transition transition-all delay-150 ease-in-out hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:O("s_v30BEZ050tM",[e])},[n("p",null,{class:"min-sm:text-[13px] mx-2 text-[15px] font-[600] tracking-wide max-md:text-[14px] "},u(l=>l.text,[t],"p0.text"),3,null),n("div",null,{class:"flex h-[25px] w-[25px] items-center justify-center rounded-full bg-teal-500 p-0 opacity-70 "},i(eg,{class:"fill-white font-bold",[s]:{class:s}},3,"ky_1"),1,null)],1,"ky_2"):n("div",null,{class:"text-btn-white flex w-fit items-center justify-center  rounded-full bg-teal-500 p-1 px-1 opacity-90 shadow-md transition transition-all  delay-150  ease-in-out hover:cursor-pointer hover:bg-teal-600",onClick$:O("s_eSPP9CLbtZw",[e])},[n("p",null,{class:"min-sm:text-[13px] mx-2 text-[15px] font-[600] tracking-wide  text-white max-md:text-[14px] "},u(l=>l.text,[t],"p0.text"),3,null),n("div",null,{class:"flex h-[25px] w-[25px] items-center justify-center rounded-full bg-white p-0 opacity-60 opacity-70 "},i(zi,{class:"w-[12px] fill-teal-500",[s]:{class:s}},3,"ky_3"),1,null)],1,"ky_4")},K=b(f(Vg,"s_FRLwbQyPTTI")),Wg=t=>n("div",{dangerouslySetInnerHTML:rr(t.text),class:`flex list-outside flex-col gap-3 text-primary-blue [&>*>a]:text-secondary-red min-[1000px]:[&>h1]:text-[45px] [&>h1]:text-[15px] [&>h1]:leading-tight [&>h1]:font-[400] [&>h2]:text-[26px] [&>h3]:text-[26px] [&>ul]:flex [&>ul]:flex-col [&>ul]:gap-3  ${t.classN??""}`},null,null,3,"Cb_0"),j=b(f(Wg,"s_RjmVkFh5HBg")),Ug=t=>n("div",null,{id:"footer",class:""},[n("div",null,{class:"flex flex-col items-center bg-primary-blue px-4 py-3 text-white"},[n("p",null,{class:"text-[22px] font-semibold"},u(e=>e.data.SupportSection.Title,[t],'p0.data["SupportSection"]["Title"]'),3,null),n("p",null,{class:"text-s lm:w-1/2 text-center sm:w-3/4"},u(e=>e.data.SupportSection.Paragraph,[t],'p0.data["SupportSection"]["Paragraph"]'),3,null)],3,null),n("div",null,{class:"flex flex-col flex-wrap justify-around bg-primary-dark-blue px-3 py-3 text-white lg:flex-row"},[n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"mb-4 w-[180px]"},i(M,{width:970,height:359,get media(){return t.data.CorpInfo.Media.data.attributes},[s]:{width:s,height:s,media:u(e=>e.data.CorpInfo.Media.data.attributes,[t],'p0.data["CorpInfo"]["Media"]["data"]["attributes"]')}},3,"Zn_0"),1,null),i(j,{get text(){return t.data.CorpInfo.Paragraph},classN:"text-white text-center mb-4 max-w-sm text-center",[s]:{text:u(e=>e.data.CorpInfo.Paragraph,[t],'p0.data["CorpInfo"]["Paragraph"]'),classN:s}},3,"Zn_1"),i(K,{type:"action",get link(){return t.data.CorpInfo.Buttons[0].Link},get text(){return t.data.CorpInfo.Buttons[0].Text},[s]:{type:s,link:u(e=>e.data.CorpInfo.Buttons[0].Link,[t],'p0.data["CorpInfo"]["Buttons"][0]["Link"]'),text:u(e=>e.data.CorpInfo.Buttons[0].Text,[t],'p0.data["CorpInfo"]["Buttons"][0]["Text"]')}},3,"Zn_2")],1,null),n("div",null,{class:"container sm:hidden"},t.data.Menus.map((e,a)=>i(xa,{inFooter:!0,get title(){return e.Text},classContainer:"text-xl text-primary-light-blue font-semibold border-b-2 border-t-2 border-primary-light-blue",children:e.SubOption.map((l,r)=>i(zt,{get href(){return l.Link},class:"mb-4 hover:text-blue-600",children:n("p",null,null,w(l,"Text"),1,null),[s]:{href:m(l,"Link"),class:s}},1,r)),[s]:{inFooter:s,title:m(e,"Text"),classContainer:s}},1,a)),1,null),n("div",null,{class:"flex justify-around"},t.data.Menus.map((e,a)=>n("div",null,{class:"hidden w-1/4 sm:block"},[n("p",null,{class:"text-2xl text-primary-light-blue font-semibold"},w(e,"Text"),1,null),e.SubOption.map((l,r)=>i(zt,{get href(){return l.Link},class:"hover:text-blue-600",children:n("p",null,null,w(l,"Text"),1,null),[s]:{href:m(l,"Link"),class:s}},1,r))],1,a)),1,null)],1,null),n("div",null,{class:"flex flex-col items-center gap-2 bg-primary-dark-blue px-4 py-4 text-white"},[n("p",null,{class:"text-[14px]"},u(e=>e.data.SocialMedia.Text,[t],'p0.data["SocialMedia"]["Text"]'),3,null),n("div",null,{class:"flex flex-row gap-4"},t.data.SocialMedia.SubOption.map((e,a)=>V(i(zt,{get href(){return e.Link},children:[e.Link.includes("facebook")&&n("div",null,{class:"flex h-7 w-7 items-center justify-center rounded-full bg-primary-blue p-2"},i(M,{height:20,width:20,get media(){return e.Icon.data.attributes},toWhite:!0,[s]:{height:s,width:s,media:m(e.Icon.data,"attributes"),toWhite:s}},3,"Zn_3"),1,"Zn_4"),!e.Link.includes("facebook")&&n("div",null,{class:"flex h-7 w-7 items-center justify-center rounded-full bg-primary-blue p-1"},i(M,{height:20,width:20,get media(){return e.Icon.data.attributes},toWhite:!0,[s]:{height:s,width:s,media:m(e.Icon.data,"attributes"),toWhite:s}},3,"Zn_5"),1,"Zn_6")],[s]:{href:m(e,"Link")}},1,a))),1,null)],1,null)],1,"Zn_7"),Yg=b(f(Ug,"s_ecsQS6so2H0")),Vi=({qty:t})=>{if(t!==void 0)return t;if(typeof window<"u"){const e=window.innerWidth;return e>1200?3:e>800?2:1}else return 1},Jg=()=>{const[t,e]=tt();t.value=Vi({qty:e})},Zg=()=>{const[t]=tt();t()},Kg=({slidesQty:t})=>{const e=N(Vi({qty:t})),a=f(Jg,"s_zVG057gY2pI",[e,t]);return Lt(O("s_hQsoJzDpgeo",[a])),Do("resize",f(Zg,"s_WB2t7tmOijA",[a])),e},Xg=t=>{const e=Kg({slidesQty:t.slidesQty});return Lt(O("s_xmo13ab0hsk",[e,t])),i(G,{children:n("section",null,{class:"splide max-w-screen overflow-hidden",id:u(a=>`${a.id?a.id:""}`,[t],'`${p0.id?p0.id:""}`'),"aria-label":"Componente Carousel"},n("div",null,{class:u(a=>` splide__track  ${a.addSpace??!0?"p-8":""}`,[t],'` splide__track  ${p0.addSpace??true?"p-8":""}`')},n("div",null,{class:"splide__list justify-between "},t.slides.map((a,l)=>n("div",null,{class:"splide__slide w-full items-center"},n("div",null,{class:u(r=>`${r.fillSlide??!1?"w-full h-full object-cover":"object-center"} flex items-center  ${r.addSpace??!0?"mx-10":""}  justify-center`,[t],'`${p0.fillSlide??false?"w-full h-full object-cover":"object-center"} flex items-center  ${p0.addSpace??true?"mx-10":""}  justify-center`')},a,1,null),1,l)),1,null),1,null),1,null)},1,"cE_0")},kt=b(f(Xg,"s_UuwASfcxtbw")),tf=()=>{const[t]=tt();t.value=!0},ef=t=>{const[e,a]=tt();return V(),Lt(O("s_4GZYBHap0Wg",[e,t])),n("div",null,{class:"flex flex-col items-center justify-between"},[n("div",null,{class:"z-20 mb-1 flex flex-col justify-center"},[n("span",null,{class:"text-center text-[20px] font-semibold"},u(l=>l.slide.Title,[t],'p0.slide["Title"]'),3,null),n("span",null,{class:"text-[14px] font-light"},i(j,{classN:"text-white",get text(){return t.slide.Paragraph},[s]:{classN:s,text:u(l=>l.slide.Paragraph,[t],'p0.slide["Paragraph"]')}},3,"DG_0"),1,null)],1,null),t.slide.Buttons[0].Link.includes("=pConf=")?i(K,{get text(){return t.slide.Buttons[0].Text},onClick:a,[s]:{text:u(l=>l.slide.Buttons[0].Text,[t],'p0.slide["Buttons"][0]["Text"]'),onClick:s}},3,t.index):i(K,{get link(){return t.slide.Buttons[0].Link},get text(){return t.slide.Buttons[0].Text},[s]:{link:u(l=>l.slide.Buttons[0].Link,[t],'p0.slide["Buttons"][0]["Link"]'),text:u(l=>l.slide.Buttons[0].Text,[t],'p0.slide["Buttons"][0]["Text"]')}},3,t.index)],1,"DG_1")},af=t=>{V();const e=N(!1),a=N(!1),l=f(tf,"s_vj08LuDnaHY",[e]),r=Me({url:""}),o=b(f(ef,"s_3lZ1awB53As",[r,l])),c=t.data.Slide.map((p,d)=>i(o,{slide:p,index:d},3,d));return n("div",null,{class:"mb-4 flex w-[40%] min-w-[350px] max-w-[500px] flex-col items-center justify-center overflow-hidden rounded-full rounded-t-none bg-[#0E4FB0] px-8 py-1 text-white max-[400px]:w-[98%] max-[400px]:min-w-[200px] max-[400px]:pb-10 "},[i(kt,{slides:c,hasPagination:!1,addSpace:!1,duration:4e3,id:"headerCarousel",slidesQty:1,[s]:{hasPagination:s,addSpace:s,duration:s,id:s,slidesQty:s}},3,"DG_2"),e.value&&n("div",null,{class:"fixed inset-0 z-[200] flex flex-col items-center justify-center bg-black bg-opacity-40"},n("div",null,{class:"w-full h-full flex-row-reverse  animate-zoomIn flex "},[n("div",null,{class:"flex p-4 flex-wrap overflow-hidden items-center justify-center "},[i(Qi,{get route(){return r.url},[s]:{route:u(p=>p.url,[r],"p0.url")}},3,"DG_3"),a.value&&window.localStorage.getItem("sendform_leaving")!="true"?i(Hi,{signalMainPopup:e,signalPopupLeaving:a,[s]:{signalMainPopup:s,signalPopupLeaving:s}},3,"DG_4"):null],1,null),n("button",null,{"aria-label":"Close popup",class:"mt-2 mx-0 bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] focus:outline-none z-[600]",onClick$:O("s_uXChW58fn0g",[r,e,a])},n("div",null,{class:"px-3 flex flex-row items-center text-xs gap-2"},["Back to site ",i(jn,null,3,"DG_5")],1,null),1,null)],1,null),1,"DG_6")],1,"DG_7")},lf=b(f(af,"s_BIrsaZMr3LY")),nf=t=>n("div",{class:`fixed left-0 right-0 top-0 z-[500] flex h-screen items-center justify-center bg-primary-dark-blue bg-opacity-30 transition-all duration-300 ${t.showSignal.value?"":"hidden"}`},{id:"modalback",onClick$:O("s_0718nqiE4KE",[t])},[n("div",null,{onClick$:O("s_Wu4a00SV7hw",[t])},i(Up,{class:"absolute right-2 top-2 rounded-full bg-secondary-red p-1 text-[30px] font-[200] text-white hover:cursor-pointer",[s]:{class:s}},3,"kj_0"),1,null),i(dt,null,3,"kj_1")],1,"kj_2"),ql=b(f(nf,"s_oHrF0mun03M")),sf=t=>{var r;const a=(r=ot().prevUrl)==null?void 0:r.pathname.includes("/es/"),l=N(!1);return n("div",null,{class:"flex flex-col gap-4 px-4 py-6 text-[15px] tracking-tight text-white"},[n("div",null,{class:"text-primary-blue"},i(ql,{showSignal:l,children:i(Rl,{title:a?"Inicia sesión en el portal de tu zona":"Log into the portal of your area",description:a?"Ingrese su código postal.":"Just enter your Zip code.",btnText:a?"Ir ahora":"Go Now",popup:"login",[s]:{popup:s}},3,"Ux_0"),[s]:{showSignal:s}},1,"Ux_1"),1,null),t.data.MainOptions.map(function(o,c){V();const p=o.SubOption.length>0;return n("div",null,{class:""},p?i(nl,{get title(){return o.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},o.SubOption.map((d,g)=>{V();const x=d.MenuOption.data;return x?i(nl,{get title(){return d.Text},children:n("div",null,{class:"flex flex-col gap-2 rounded-md bg-white p-3 font-[600] text-primary-blue shadow-md"},x.attributes.SubOption.map((h,$)=>i(Mt,{get link(){return h.Link},hasStyle:!1,children:w(h,"Text"),[s]:{link:m(h,"Link"),hasStyle:s}},1,$)),1,null),[s]:{title:m(d,"Text")}},1,"Ux_4"):d.Link.includes("Login")?n("div",null,{class:"hover:cursor-pointer",onClick$:O("s_SnfOjeOrlzY",[l])},w(d,"Text"),1,"Ux_3"):i(Mt,{get link(){return d.Link},hasStyle:!1,children:w(d,"Text"),[s]:{link:m(d,"Link"),hasStyle:s}},1,g)}),1,null),[s]:{title:m(o,"Text")}},1,"Ux_5"):i(Mt,{get link(){return o.Link},children:w(o,"Text"),[s]:{link:m(o,"Link")}},1,"Ux_2"),1,c)}),n("div",null,{class:"w-full border border-white border-opacity-40"},null,3,null),n("div",null,{class:"flex w-fit flex-col gap-5"},t.data.gigfastOptions.map((o,c)=>i(Mt,{get link(){return o.Link},classN:"rounded-full bg-white px-4 py-1 shadow-lg",children:n("div",null,{class:"w-[130px] rounded-md p-1"},i(M,{get media(){return o.Icon.data.attributes},width:"311",height:"60",[s]:{media:m(o.Icon.data,"attributes"),width:s,height:s}},3,"Ux_6"),1,null),[s]:{link:m(o,"Link"),classN:s}},1,c)),1,null)],1,"Ux_7")},rf=b(f(sf,"s_jSaadUqLWqI")),of=t=>{V();const e=N(!1);return n("div",null,{class:u(a=>`relative overflow-hidden transition-all duration-500 ${a.value?"overflow-y-hidden":"z-50"}`,[e],'`relative overflow-hidden transition-all duration-500 ${p0.value?"overflow-y-hidden":"z-50"}`'),style:u(a=>a.value?{perspective:"9000px"}:{},[e],'p0.value?{perspective:"9000px"}:{}')},[n("div",null,{class:u(a=>`absolute inset-0 ${a.value?"bg-gradient-to-l from-[#2e599a] to-[#182d4d] ":"bg-white !important"}   ${a.value?"overflow-y-hidden":"z-50"}`,[e],'`absolute inset-0 ${p0.value?"bg-gradient-to-l from-[#2e599a] to-[#182d4d] ":"bg-white !important"}   ${p0.value?"overflow-y-hidden":"z-50"}`')},i(rf,{get data(){return t.data.data.generalMenu.data.attributes},[s]:{data:u(a=>a.data.data.generalMenu.data.attributes,[t],'p0.data["data"]["generalMenu"]["data"]["attributes"]')}},3,"m8_0"),1,null),n("div",null,{class:u(a=>`relative transition-all duration-500 ${a.value?"overflow-y-hidden":"z-50"}`,[e],'`relative transition-all duration-500 ${p0.value?"overflow-y-hidden":"z-50"}`'),style:u(a=>a.value?{transform:"rotateY(-30deg) translateX(250px) translateY(200px)",transformStyle:"preserve-3d"}:{},[e],'p0.value?{transform:"rotateY(-30deg) translateX(250px) translateY(200px)",transformStyle:"preserve-3d"}:{}')},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-10 bg-gradient-to-l from-[#FFFFFF] to-[#C8D8ED]"},null,3,null),(t.showMenus??!0)&&i(Qg,{get data(){return t.data.data.generalMenu.data.attributes},mobMenuOpen:e,[s]:{data:u(a=>a.data.data.generalMenu.data.attributes,[t],'p0.data["data"]["generalMenu"]["data"]["attributes"]'),mobMenuOpen:s}},3,"m8_1"),n("div",null,{class:u(a=>`${a.value?"overflow-y-hidden":""}`,[e],'`${p0.value?"overflow-y-hidden":""}`')},[(t.showHeader??!0)&&n("div",null,{class:"flex w-full items-center justify-center"},i(lf,{get data(){return t.data.data.generalHeader.data.attributes},[s]:{data:u(a=>a.data.data.generalHeader.data.attributes,[t],'p0.data["data"]["generalHeader"]["data"]["attributes"]')}},3,"m8_2"),1,"m8_3"),n("div",null,{class:"relative"},i(dt,null,3,"m8_4"),1,null),(t.showMenus??!0)&&i(Yg,{get data(){return t.data.data.generalFooter.data.attributes},[s]:{data:u(a=>a.data.data.generalFooter.data.attributes,[t],'p0.data["data"]["generalFooter"]["data"]["attributes"]')}},3,"m8_5")],1,null)],1,null)],1,"m8_6")},F=b(f(of,"s_vumpf0PbXbo")),uf=t=>{const e=t.customText?t.customText:t.SEOdata.MetaTitle.split(" |")[0];return!t.SEOdata&&!t.customText?n("h1",null,{class:"absolute opacity-0"},"RTA",3,"Yj_0"):n("h1",null,{class:"absolute opacity-0"},e,1,"Yj_1")},et=b(f(uf,"s_SOxRNst40is")),cf=t=>{V();const e=N(!0);return n("div",null,{class:"h-[550px] w-full  flex flex-col items-center justify-center"},[e.value?i(Gt,{size:"250px",[s]:{size:s}},3,"a3_0"):null,n("iframe",null,{id:"iframe-appre-giveaway",class:"w-3/4 my-4 h-full rounded-3xl",src:u(a=>a.data.iFrame_link,[t],'p0.data["iFrame_link"]'),loading:"lazy",onLoad$:O("s_b0xkTBodv54",[e])},null,3,null)],1,"a3_1")},df=b(f(cf,"s_VzseIswtUxM")),pf=t=>`query QueryAprGive {
        pageAprGive(locale:"${t}"){
          data{
            attributes{
              iFrame_link
              ${z}
            }
          }
        }
        }`,gf=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(pf,e)},En=q(f(gf,"s_xcQxq8lbgb0")),ff=()=>{const t=En();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageAprGive.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAprGive.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAprGive"]["data"]["attributes"]["SEO"]')}},3,"kA_0"),i(df,{get data(){return t.value.pageData.data.pageAprGive.data.attributes},[s]:{data:u(e=>e.value.pageData.data.pageAprGive.data.attributes,[t],'p0.value["pageData"]["data"]["pageAprGive"]["data"]["attributes"]')}},3,"kA_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"kA_2")},1,"kA_3")},xf=b(f(ff,"s_Py5O2s07X3c")),mf=({resolveValue:t})=>{const a=t(En).pageData.data.pageAprGive.data.attributes.SEO;return H(a)},hf=Object.freeze(Object.defineProperty({__proto__:null,default:xf,head:mf,usePageData:En},Symbol.toStringTag,{value:"Module"})),bf=t=>{V();const e=t.data.data.pageAprLead.data.attributes,a=N(!0);return n("div",null,{class:"flex flex-wrap px-8 items-center justify-center"},[n("div",null,{class:"flex flex-col items-center justify-center w-full md:w-1/2"},[n("div",null,{class:"relative h-[600px] w-[80%] flex flex-col items-center justify-center"},[i(M,{get media(){return e.zane_lead.bg_pic.data.attributes},width:"650",height:"650",[s]:{media:m(e.zane_lead.bg_pic.data,"attributes"),width:s,height:s}},3,"q7_0"),i(M,{clasN:"absolute flex rounded-full h-3/4 w-auto",get media(){return e.zane_lead.zane_pic.data.attributes},height:250,width:250,[s]:{clasN:s,media:m(e.zane_lead.zane_pic.data,"attributes"),height:s,width:s}},3,"q7_1"),i(M,{clasN:"absolute h-[10%] w-auto top-20 right-10",get media(){return e.zane_lead.tv_pic.data.attributes},height:"50",width:"50",[s]:{clasN:s,media:m(e.zane_lead.tv_pic.data,"attributes"),height:s,width:s}},3,"q7_2"),i(M,{clasN:"absolute bottom-10 h-[10%] w-auto left-5",get media(){return e.zane_lead.wifi_pic.data.attributes},height:"50",width:"50",[s]:{clasN:s,media:m(e.zane_lead.wifi_pic.data,"attributes"),height:s,width:s}},3,"q7_3"),i(M,{clasN:"absolute top-10 left-10 h-[10%] w-auto",get media(){return e.zane_lead.phone_pic.data.attributes.url},height:"50",width:"50",[s]:{clasN:s,media:m(e.zane_lead.phone_pic.data.attributes,"url"),height:s,width:s}},3,"q7_4"),n("div",null,{class:"absolute left-1/2 top-5 flex flex-row text-primary-blue bg-white items-center justify-center p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},i(M,{toWhite:!0,width:20,height:20,get media(){return e.zane_lead.give_pic.data.attributes},[s]:{toWhite:s,width:s,height:s,media:m(e.zane_lead.give_pic.data,"attributes")}},3,"q7_5"),1,null),"Price"],1,null),n("div",null,{class:"absolute w-fit h-fit bottom-0 left-1/2 flex flex-row text-primary-blue bg-white items-center justify-evenly p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},i(M,{toWhite:!0,width:20,height:20,get media(){return e.zane_lead.auto_pic.data.attributes},[s]:{toWhite:s,width:s,height:s,media:m(e.zane_lead.auto_pic.data,"attributes")}},3,"q7_6"),1,null),"Live Events"],1,null),n("div",null,{class:"absolute w-fit h-fit flex flex-row left-3/4 bottom-1/4 text-primary-blue bg-white items-center justify-evenly p-2 rounded-full"},[n("div",null,{class:"h-[25px] w-[25px] rounded-full  bg-secondary-red p-1"},i(M,{toWhite:!0,width:20,height:20,get media(){return e.zane_lead.cota_pic.data.attributes},[s]:{toWhite:s,width:s,height:s,media:m(e.zane_lead.cota_pic.data,"attributes")}},3,"q7_7"),1,null),"Discounts"],1,null),n("div",null,{class:"absolute w-fit h-fit flex flex-row justify-evenly left-0  text-primary-blue bg-white items-center p-2 rounded-full"},[n("div",null,{class:"h-fit w-fit rounded-full  bg-secondary-red p-1"},i(M,{toWhite:!0,width:20,height:20,get media(){return e.zane_lead.auto_pic.data.attributes},[s]:{toWhite:s,width:s,height:s,media:m(e.zane_lead.auto_pic.data,"attributes")}},3,"q7_8"),1,null),"Live Events"],1,null)],1,null),n("div",null,{class:"flex flex-col items-center justify-center"},[n("p",null,{class:"text-xl text-center font-medium text-primary-blue"},w(e,"zane_description"),1,null),i(M,{get media(){return e.zane_banner.banner_pic.data.attributes},width:"400",height:"78",[s]:{media:m(e.zane_banner.banner_pic.data,"attributes"),width:s,height:s}},3,"q7_9"),n("div",null,{class:"flex flex-row items-center gap-5 justify-evenly my-5"},[n("div",null,{class:"bg-primary-blue text-white flex flex-col rounded-full items-center justify-center w-fit px-10 py-2"},[n("h2",null,{class:"text-sm text-center font-bold"},w(e.date_race,"Text"),1,null),n("p",null,{class:"text-sm text-center"},w(e.date_race,"Link"),1,null)],1,null),i(K,{get text(){return e.button_promo.text},get link(){return e.button_promo.link},[s]:{text:m(e.button_promo,"text"),link:m(e.button_promo,"link")}},3,"q7_10")],1,null)],1,null)],1,null),n("div",null,{class:"w-full md:w-2/6 shadow-2xl rounded-2xl h-[500px]"},[a.value?i(Gt,{size:"250px",[s]:{size:s}},3,"q7_11"):null,n("iframe",{src:w(e,"iFrame_link")},{id:"iframe-appre-lead",loading:"lazy",class:"w-full  rounded-2xl h-full",onLoad$:O("s_M94pZoIEeB0",[a])},null,3,null)],1,null)],1,"q7_12")},$f=b(f(bf,"s_0jvpiBD6mW4")),yf=t=>`query QueryPageAprLead {
        pageAprLead(locale:"${t}"){
          data {
            attributes {
              zane_lead {
                zane_pic {
                    ${y}
                }
                give_pic {
                    ${y}
                }
                cota_pic {
                    ${y}
                }
                auto_pic {
                    ${y}
                }
                live_pic {
                    ${y}
                }
                phone_pic {
                    ${y}
                }
                tv_pic {
                    ${y}
                }
                wifi_pic {
                    ${y}
                }
                bg_pic {
                    ${y}
                }
              }
              zane_banner {
                banner_pic {
                    ${y}
                }
              }
              zane_description
              iFrame_link
              date_race {
                Text
                Link
                Icon {
                  ${y}
                }
              }
              button_promo {
                text
                icon {
                  ${y}
                }
                link
              }
              pricing_box {
                Title
                Subtitle
                Pricing
                Period
                bg {
                  ${y}
                }
                Icon {
                  ${y}
                }
              }
              car {
                car_pic {
                  ${y}
                }
              }
              ${z}
              
            }
          }
        }
      }`,vf=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(yf,e)},Nn=q(f(vf,"s_05Sy9vG0VbY")),_f=()=>{const t=Nn();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageAprLead.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageAprLead.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAprLead"]["data"]["attributes"]["SEO"]')}},3,"LY_0"),i($f,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"LY_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"LY_2")},1,"LY_3")},wf=b(f(_f,"s_32Qq7YbePEg")),Sf=({resolveValue:t})=>{const a=t(Nn).pageData.data.pageAprLead.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},Tf=Object.freeze(Object.defineProperty({__proto__:null,default:wf,head:Sf,usePageData:Nn},Symbol.toStringTag,{value:"Module"})),Df=t=>n("div",null,{class:"text-center"},[n("div",null,{class:"bg-primary-blue bg-opacity-40 p-6 h-[310px] w-[310px] inline-block items-center justify-center rounded-full"},n("div",null,{class:"bg-primary-blue flex h-full w-full items-center justify-center  rounded-full bg-opacity-60 px-6 py-6 shadow-md"},n("div",null,{class:"bg-primary-blue flex flex-col h-full w-full items-center justify-around rounded-full shadow-md"},[n("div",null,{class:"flex flex-col items-center"},[i(M,{get media(){return t.award.Icon.data.attributes},height:40,width:40,[s]:{media:u(e=>e.award.Icon.data.attributes,[t],'p0.award["Icon"]["data"]["attributes"]'),height:s,width:s}},3,"5M_0"),n("p",null,{class:"text-l text-white font-semibold text-center"},u(e=>e.award.Title,[t],'p0.award["Title"]'),3,null),n("p",null,{class:"text-center text-sm font-light text-white leading-8"},u(e=>e.award.Award,[t],'p0.award["Award"]'),3,null)],1,null),n("a",null,{class:"text-white font-semibold",target:"_blank",href:u(e=>e.award.Button.Link,[t],'p0.award["Button"]["Link"]')},u(e=>e.award.Button.Text,[t],'p0.award["Button"]["Text"]'),3,null)],1,null),1,null),1,null),n("p",null,{class:"text-3xl font-semibold text-primary-blue"},u(e=>e.award.Year,[t],'p0.award["Year"]'),3,null)],1,"5M_1"),Pf=t=>{const e=t.data.data.pageAward.data.attributes,a=b(f(Df,"s_fwfHmjnV3nY")),l=e.Awards.map((r,o)=>i(a,{award:r},3,o));return n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"w-3/4"},[n("h1",null,{class:"text-center text-4xl font-bold text-primary-blue"},w(e,"Title"),1,null),i(j,{classN:"text-center",get text(){return e.Description},[s]:{classN:s,text:m(e,"Description")}},3,"5M_2")],1,null),n("div",null,{class:"w-full h-[500px] relative items-center justify-center overflow-hidden"},[n("div",null,{class:"h-full w-full absolute bg-opacity-50"},i(M,{clasN:"object-fill opacity-50",get media(){return e.Background.data.attributes},height:500,width:1200,[s]:{clasN:s,media:m(e.Background.data,"attributes"),height:s,width:s}},3,"5M_3"),1,null),n("div",null,{class:"h-full w-full flex items-center justify-center absolute"},i(kt,{slides:l,id:"awardsSlider",hasPagination:!0,duration:3e3,[s]:{id:s,hasPagination:s,duration:s}},3,"5M_4"),1,null)],1,null)],1,"5M_5")},kf=b(f(Pf,"s_DHWUiZRKjUc")),Lf=t=>`query {
        pageAward(locale:"${t}"){
          data {
            attributes {
              Title
              Description
              
              Background {
                ${y}
              }
              
              Awards {
                Title
                Award
                Year
                Background {
                  ${y}
                }
                Icon {
                  ${y}
                }
                Button{
                  Text
                  Link
                }
              }
      
              ${z}
            }
          }
        }
      }`,Cf=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Lf,e)},Bn=q(f(Cf,"s_sqeXWQdLNKw")),Mf=()=>{const t=Bn();return i(F,{get data(){return t.value.layoutData},children:i(kf,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"Q2_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Q2_1")},jf=b(f(Mf,"s_YOAlBnNiDxQ")),If=({resolveValue:t})=>{const a=t(Bn).pageData.data.pageAward.data.attributes.SEO;return H(a)},Ef=Object.freeze(Object.defineProperty({__proto__:null,default:jf,head:If,usePageData:Bn},Symbol.toStringTag,{value:"Module"})),Nf=t=>{const e=(a,l)=>a.slice(0,l)+"...";return n("div",null,{class:"flex max-w-[1200px] flex-row-reverse items-center justify-center self-center px-8 py-4 max-[800px]:flex-col-reverse"},[n("div",null,{class:"flex  flex-col items-center justify-start  gap-4 px-10 min-[800px]:w-[60%]"},[n("div",null,{class:""},[n("div",null,{class:"my-4 text-[32px] font-[600] leading-10 text-[#2E5899] max-sm:text-[24px] max-sm:leading-7"},u(a=>a.post.Title,[t],'p0.post["Title"]'),3,null),n("div",null,null,i(j,{classN:"max-sm:text-[13px] text-[15px] text-[#2E5899] text-justify [&>h1]:text-[15px] [&>h1]:font-[600] [&>h2]:text-[15px] [&>h2]:font-[600] [&>h3]:text-[15px] [&>h3]:font-[600]",text:e(t.post.Description,500),[s]:{classN:s}},3,"su_0"),1,null)],1,null),i(K,{get text(){return t.isES?"Leer Más":"Read More"},get link(){return`/${t.isES?`es/${[t.post.Slug.replace("-es","")]}`:[t.post.Slug]}`},[s]:{text:u(a=>a.isES?"Leer Más":"Read More",[t],'p0.isES?"Leer Más":"Read More"'),link:u(a=>`/${a.isES?`es/${[a.post.Slug.replace("-es","")]}`:[a.post.Slug]}`,[t],'`/${p0.isES?`es/${[p0.post["Slug"].replace("-es","")]}`:[p0.post["Slug"]]}`')}},3,"su_1")],1,null),n("div",null,{class:"flex w-full items-center justify-center self-center p-4 min-[800px]:w-[40%]"},i(M,{get media(){return t.post.Cover.data.attributes},clasN:"rounded-[50px] shadow-2xl",width:"1184",height:"894",[s]:{media:u(a=>a.post.Cover.data.attributes,[t],'p0.post["Cover"]["data"]["attributes"]'),clasN:s,width:s,height:s}},3,"su_2"),1,null)],1,"su_3")},An=b(f(Nf,"s_KKagOAzP0DM")),Bf=t=>{const e=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],a=["January","February","March","April","May","June","July","August","September","October","November","December"];function l(c){const p=e[c.getDay()],d=c.getDate(),g=a[c.getMonth()],x=c.getFullYear();return`${p}, ${g} ${d}, ${x}`}const r=(c,p)=>c.slice(0,p)+"...",o=t.post.attributes.Slug.endsWith("-es");return n("div",null,{id:u(c=>c.id,[t],"p0.id"),class:"mb-8 flex max-w-[300px] flex-col"},[i(M,{width:"1184",height:"894",clasN:"rounded-2xl self-center object-cover h-[200px] w-[300px]",get media(){return t.post.attributes.Cover.data.attributes},[s]:{width:s,height:s,clasN:s,media:u(c=>c.post.attributes.Cover.data.attributes,[t],'p0.post["attributes"]["Cover"]["data"]["attributes"]')}},3,"j0_0"),n("h3",null,{class:"px-3 py-1 font-[600] text-[15px] text-primary-blue "},["  ",r(t.post.attributes.Title,60)],1,null),n("span",null,{class:"px-3 text-[12px] font-[700]  text-primary-blue opacity-70"},l(new Date(t.post.attributes.Date)),1,null),n("span",null,{class:"px-3 text-primary-blue"},n("div",{dangerouslySetInnerHTML:rr(r(t.post.attributes.Description,120))},{class:"flex list-inside flex-col gap-3 text-justify text-[14px]"},null,3,null),1,null),n("div",null,{class:"mt-2 self-center"},i(K,{text:o?"Leer Más":"Read More",link:`/${o?`es/${[t.post.attributes.Slug.replace("-es","")]}`:[t.post.attributes.Slug]}`},3,"j0_1"),1,null)],1,"j0_2")},Wi=b(f(Bf,"s_KUqCzJ00kfw")),Af=t=>{var c;const a=(c=ot().prevUrl)!=null&&c.pathname.includes("/es/")?"es-419":"en",l=N(t.posts.slice(1,(t.loadSize??6)+1)),r=N(!1),o=N(1);return n("div",{"document:onscroll$":O("s_t0DoAQDJl4Y",[a,r,o,t,l])},{id:"postLoader",class:"grid w-full max-w-[1200px] grid-cols-3 justify-evenly gap-4 px-4 max-[800px]:grid-cols-1 [&>*]:justify-self-center"},l.value.map((p,d)=>i(Wi,{post:p,id:`post-${d.toString()}`},3,d)),0,"4a_0")},On=b(f(Af,"s_HS0GyQ0UHYM")),Of=t=>n("div",null,{class:"flex flex-col items-center justify-center w-fit "},n("div",null,{class:"  px-2 mb-8  md:max-h-[150px]  overflow-y-scroll"},i(j,{classN:"text-[12.5px]",get text(){return t.slide.attributes.Content},[s]:{classN:s,text:u(e=>e.slide.attributes.Content,[t],'p0.slide["attributes"]["Content"]')}},3,"9l_0"),1,null),1,"9l_1"),Rf=t=>{const e=t.data.TechTips.data,a=b(f(Of,"s_0D1CtJAueP4")),l=e.map((r,o)=>i(a,{slide:r},3,o));return n("div",null,{class:" gap-2 flex flex-row bg-white p-3 md:rounded-full rounded-3xl md:w-[750px] w-[90%] shadow-lg items-center"},[n("div",null,null,n("div",null,{class:"bg-[#2e5899] p-5 rounded-full shadow-lg md:min-h-[130px] md:max-w-[130px] md:max-h-[130px] max-w-[80px] flex justify-center items-center max-[768px]:hidden	"},n("div",null,{class:"bg-white md:p-5 p-2 w-fit h-fit items-center rounded-full shadow-lg shadow-inner"},i(sg,{class:" md:w-[45px] md:h-[45px] w-[20px] h-[20px] fill-[#2e5899]",[s]:{class:s}},3,"9l_2"),1,null),1,null),1,null),n("div",null,{class:" justify-center items-center  md:w-[650px] max-w-[100%]"},[n("div",null,{class:"text-[18px] tracking-wide font-[600] leading-10 text-[#2E5899]"},u(r=>r.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"h-fit relative flex md:w-[650px] max-w-[90%]  items-center justify-center overflow-hidden   "},i(kt,{slides:l,slidesQty:1,id:"techTipsCarousel",addSpace:!1,hasArrows:!1,[s]:{slidesQty:s,id:s,addSpace:s,hasArrows:s}},3,"9l_3"),1,null)],1,null)],1,"9l_4")},qf=b(f(Rf,"s_600c5npFpQo")),Ff=t=>{var o;const a=(o=ot().prevUrl)==null?void 0:o.pathname.includes("/es/"),l=t.data.pageBlog.data.attributes,r=l.Posts.data[0].attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(qf,{get data(){return l.Tips},[s]:{data:m(l,"Tips")}},3,"LH_0"),i(An,{post:r,isES:a},3,"LH_1"),n("div",null,{class:"my-4"},null,3,null),i(On,{get posts(){return l.Posts.data},loadSize:3,type:"Blog",[s]:{posts:m(l.Posts,"data"),loadSize:s,type:s}},3,"LH_2")],1,"LH_3")},zf=b(f(Ff,"s_lTYqJJcPHc4")),Qf=t=>` query QueryBlog {
        pageBlog(locale:"${t}"){    
          data{
          attributes{
            Tips{
              Title
              TechTips(sort: "Date:desc", pagination: { limit: 10 }){
                data{
                  attributes{
                    Content
                  }
                }
              }
            }
            Posts(sort: "Date:desc", pagination: { limit: 100 }){
                data{
                  attributes{
                    Title
                    Date
                    Cover{
                      ${y}
                    }
                    Description
                    VideoLink
                    Gallery{
                      ${y}
                    }
                    Slug
                  }
                }
              }
          
            ${z}
          }
        }
        }
      }`,Gf=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Qf,e)},Rn=q(f(Gf,"s_PlB05JNPqRo")),Hf=()=>{const t=Rn();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageBlog.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageBlog.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBlog"]["data"]["attributes"]["SEO"]')}},3,"Yn_0"),i(zf,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Yn_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Yn_2")},Vf=b(f(Hf,"s_WiOXv30Ec4Y")),Wf=({resolveValue:t})=>{const a=t(Rn).pageData.data.pageBlog.data.attributes.SEO;return H(a)},Uf=Object.freeze(Object.defineProperty({__proto__:null,default:Vf,head:Wf,usePageData:Rn},Symbol.toStringTag,{value:"Module"})),Yf=t=>n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} bg-opacity-40 p-6 ${e.height??""} ${e.width??""} inline-block items-center justify-center rounded-full`,[t],'`${p0.color??"bg-[#2E5899]"} bg-opacity-40 p-6 ${p0.height??""} ${p0.width??""} inline-block items-center justify-center rounded-full`')},n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md`,[t],'`${p0.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md`')},n("div",null,{class:u(e=>`${e.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md`,[t],'`${p0.color??"bg-[#2E5899]"} flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md`')},i(M,{clasN:"h-full w-full rounded-full object-cover",height:250,width:250,get media(){return t.media},[s]:{clasN:s,height:s,width:s,media:u(e=>e.media,[t],"p0.media")}},3,"03_0"),1,null),1,null),1,"03_1"),Ue=b(f(Yf,"s_CA0rJqJDom0")),Jf=t=>n("div",null,{class:"flex w-fit flex-wrap gap-12 md:gap-20 m-5 items-center justify-center"},t.data.MembersGrid.map((e,a)=>V(n("div",null,{class:"w-[300px] h-[300px] items-center justify-around flex flex-col"},[i(Ue,{width:"w-[200px]",height:"h-[200px]",get media(){return e.Picture.data.attributes},[s]:{width:s,height:s,media:m(e.Picture.data,"attributes")}},3,"Q1_0"),n("h2",null,{class:"font-bold text-primary-blue text-xl"},[w(e,"FirstName")," ",w(e,"LastName")],1,null),n("p",null,{class:"text-sm text-primary-blue"},w(e,"Position"),1,null),e.SocialMedia.length>0&&n("a",{href:w(e.SocialMedia[0],"Link")},null,n("div",null,{class:"h-[30px] w-[30px] flex items-center justify-center bg-white shadow rounded-full p-1.5"},i(Fp,{class:"fill-primary-blue",[s]:{class:s}},3,"Q1_1"),1,null),1,"Q1_2")],1,a))),1,"Q1_3"),Ui=b(f(Jf,"s_fHxbC9gELko")),Zf=t=>`query QueryBoardOfDirectors{
        pageBDirectors(locale:"${t}"){
          data{
            attributes{
              ${Bi}
              ${z}
              }
            }
          }
        }`,Kf=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Zf,e)},qn=q(f(Kf,"s_zIMYdRdJ00w")),Xf=()=>{const t=qn(),e=t.value.pageData.data.pageBDirectors.data.attributes;return i(G,{children:i(F,{get data(){return t.value.layoutData},showHeader:!0,children:[i(et,{get SEOdata(){return t.value.pageData.data.pageBDirectors.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageBDirectors.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBDirectors"]["data"]["attributes"]["SEO"]')}},3,"ts_0"),i(Ui,{data:e},3,"ts_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"ts_2")},1,"ts_3")},t0=b(f(Xf,"s_IBN44L8LT0g")),e0=({resolveValue:t})=>{const a=t(qn).pageData.data.pageBDirectors.data.attributes.SEO;return H(a)},a0=Object.freeze(Object.defineProperty({__proto__:null,default:t0,head:e0,usePageData:qn},Symbol.toStringTag,{value:"Module"})),l0=async(t,e,a)=>{const r=await(await fetch(`https://cblsrvr1.rtatel.com/planbuilder/validate/coverage?lat=${t}&long=${e}&zipcode=${a}`)).json(),o=r.result.coverage,c=r.result.locationgroup,p=r.result.type;return console.log(o),console.log(p),console.log(c),{coverage:o,type:p,locationgroup:c}},n0=async(t,e)=>{const a=await fetch("https://cblsrvr1.rtatel.com/planbuilder/api",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"products",networkType:e,customerType:"residential",locationgroup:t})}),l=await fetch("https://cblsrvr1.rtatel.com/planbuilder/api",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"products",networkType:e,customerType:"business",locationgroup:t})});a.ok||console.error("Error residential products search"),l.ok||console.error("Error business product search");const r=await a.json(),o=await l.json(),{gigfastInternetProductsResidential:c,gigfastVoiceResidential:p}=r.result.reduce((x,h)=>(h.family==="gigFastInternet"?x.gigfastInternetProductsResidential.push(h):h.family==="gigFastVoice"&&x.gigfastVoiceResidential.push(h),x),{gigfastInternetProductsResidential:[],gigfastVoiceResidential:[]}),{gigfastInternetProductsBusiness:d,gigfastVoiceBusiness:g}=o.result.reduce((x,h)=>(h.family==="gigFastInternet"?x.gigfastInternetProductsBusiness.push(h):h.family==="gigFastVoice"&&x.gigfastVoiceBusiness.push(h),x),{gigfastInternetProductsBusiness:[],gigfastVoiceBusiness:[]});return console.log(c),{residentialInternet:c,businessInternet:d,residentialVoice:p,businessVoice:g}};function s0(t){const e=Object.keys(t),a=Object.values(t);return[e.join(","),a.join(",")].join(`
`)}function r0(t,e){const a=s0(t),l=new Blob([a],{type:"text/csv;charset=utf-8;"}),r=document.createElement("a");if(r.download!==void 0){const o=URL.createObjectURL(l);r.setAttribute("href",o),r.setAttribute("download",e),r.style.visibility="hidden",document.body.appendChild(r),r.click(),document.body.removeChild(r)}}const i0=t=>{const e=document.getElementById(t),a=t.replace("div-plan-","");e.querySelectorAll("hr").forEach(l=>{l.style.marginTop="5px",l.style.marginBottom="5px"}),ir(e,{scale:1}).then(l=>{const r=l.toDataURL("image/png"),o=325/96*25.4,c=1300/96*25.4,p=new uo("p","mm",[o,c]),d=o,g=l.height*d/l.width;p.addImage(r,"PNG",0,0,d,g),e.querySelectorAll("a").forEach(h=>{const $=h.getAttribute("href"),_=h.getBoundingClientRect(),k=_.left/96*25.4,D=_.top/96*25.4,T=_.width/96*25.4,v=_.height/96*25.4;p.link(k,D,T,v,{url:$})}),p.save(a+".pdf")}),e.querySelectorAll("hr").forEach(l=>{l.style.marginTop="0px",l.style.marginBottom="0px"})},o0=t=>{const e=document.getElementById(t),a=t.replace("div-plan-","");e.querySelectorAll("hr").forEach(l=>{l.style.marginTop="5px",l.style.marginBottom="5px"}),ir(e,{scale:1}).then(l=>{const r=l.toDataURL("image/png"),o=document.createElement("a");o.href=r,o.download=`${a}.png`,o.style.visibility="hidden",document.body.appendChild(o),o.click(),document.body.removeChild(o)}),e.querySelectorAll("hr").forEach(l=>{l.style.marginTop="0px",l.style.marginBottom="0px"})},u0=()=>{const[t]=tt();return r0(t,`${t.unique_plan_id}.csv`)},c0=()=>{const[t]=tt();return i0("div-plan-"+t.unique_plan_id)},d0=()=>{const[t]=tt();return o0("div-plan-"+t.unique_plan_id)},p0=t=>{var p;const e={unique_plan_id:t.unique_plan_id,provider_name:t.providerName??"Rural Telecommunications of America",service_plan_name:t.service_plan_name,tier_plan_name:t.tier_plan_name,connection_type:t.connection_type,monthly_price:t.monthly_price,intro_rate:t.intro_rate==="N/A"?"NULL":t.intro_rate,intro_rate_price:t.intro_rate_price,intro_rate_time:t.intro_rate_time==="N/A"?"0":t.intro_rate_time,contract_req:t.contract_req==="N/A"?"NULL":t.contract_req,contract_time:t.contract_time==="N/A"?"0":t.contract_time,contract_terms_url:t.contract_terms_url,early_termination_fee:t.early_termination_fee==="N/A"?"NULL":t.early_termination_fee,single_purchase_fee_descr:t.single_purchase_fee_descr==="N/A"?"NULL":t.single_purchase_fee_descr,single_purchase_fees:t.single_purchase_fees==="N/A"?"NULL":t.single_purchase_fees,monthly_provider_fee_descr:t.monthly_provider_fee_descr==="N/A"?"NULL":t.monthly_provider_fee_descr,monthly_provider_fee:t.monthly_provider_fee==="N/A"?"NULL":t.monthly_provider_fee,tax:t.tax,bundle_discounts_url:t.bundle_discounts_url,typical_download_speed:t.typical_download_speed,typical_upload_speed:t.typical_upload_speed,typical_latency:t.typical_latency==="N/A"?"0":t.typical_latency,monthly_data_allow:t.monthly_data_allow==="N/A"?"NULL":t.monthly_data_allow,over_usage_data_price:t.over_usage_data_price==="N/A"?"0":t.over_usage_data_price,additional_data_increment:t.additional_data_increment==="N/A"?"0":t.additional_data_increment,data_allowance_policy_url:t.data_allowance_policy_url,network_management_policy_url:t.network_management_policy_url,privacy_policy_url:t.privacy_policy_url,customer_support_phone:t.customer_support_phone,customer_support_web:t.customer_support_web},l=(p=ot().prevUrl)==null?void 0:p.pathname.includes("/es/"),r=f(u0,"s_dGbD0aEN34E",[e]),o=f(c0,"s_c4OlAowgKj0",[e]),c=f(d0,"s_hkOekiixbYM",[e]);return n("div",null,{class:"flex flex-col items-start"},[n("div",{id:"div-plan-"+e.unique_plan_id},{class:"mx-2 my-5 overflow-hidden w-[325px] min-h-[1000px] p-3 border-4 border-black bg-white shrink-0"},[n("header",null,null,[n("h2",null,{class:"text-2xl font-extrabold text-center"},t.isVoice==!0?l?"Información del Servicio telefónico":"Phone Service Facts":l?"Información de Internet de Banda Ancha":"Broadband Facts",1,null),n("hr",null,{class:"border-black border-2"},null,3,null),n("p",null,{class:"text-base font-bold"},u(d=>d.providerName??"Rural Telecommunications of America",[t],'p0.providerName??"Rural Telecommunications of America"'),3,null),n("p",null,{class:"text-base font-extrabold"},w(e,"service_plan_name"),1,null),n("p",null,{class:"text-base"},l?"Declaración de transparencia para el usuario de servicios de internet de banda ancha fija.":`${t.connection_type} Broadband Consumer Disclosure`,1,null)],1,null),n("hr",null,{class:"border-black border-4"},null,3,null),n("div",null,{class:"grid grid-cols-2 font-extrabold"},[n("p",null,null,l?"Precio mensual":"Monthly Price",1,null),n("p",null,{class:"text-right"},["$ ",w(e,"monthly_price")],1,null)],1,null),n("hr",null,{class:"border-2 border-black"},null,3,null),n("div",null,{class:"grid grid-cols-2 text-sm gap-2"},[n("p",null,null,l?"Este precio mensual corresponde a una tarifa inicial":"This monthly price is an introductory rate",1,null),n("p",null,{class:"text-right"},u(d=>d.intro_rate,[t],"p0.intro_rate"),3,null),n("p",null,null,l?"Lapso al que se aplica la tarifa inicial":"Time the introductory rate applies",1,null),n("p",null,{class:"text-right"},u(d=>d.intro_rate_time,[t],"p0.intro_rate_time"),3,null),n("p",null,null,l?"Precio mensual posterior a la tarifa inicial":"Monthly price after the introductory rate",1,null),n("p",null,{class:"text-right"},["$",w(e,"intro_rate_price")],1,null),n("p",null,null,l?"Duración del contrato":"Length of contract",1,null),n("p",null,{class:"text-right"},u(d=>d.contract_time,[t],"p0.contract_time"),3,null),n("p",null,{class:"col-span-2"},l?"Enlace a los términos del contrato":"Link to Terms of Contract",1,null)],1,null),e.contract_terms_url&&n("p",null,{class:"text-sm"},n("a",{href:w(e,"contract_terms_url")},null,w(e,"contract_terms_url"),1,null),1,"F7_0"),n("hr",null,{class:"border-2 border-black"},null,3,null),n("div",null,{class:"text-sm"},[n("p",null,{class:"font-bold"},l?"Cargos y condiciones adicionales":"Additional Charges & Terms",1,null),n("div",null,{class:"grid grid-cols-[2fr_1fr] gap-1 p-2"},[n("p",null,{class:"col-span-2"},l?"Tarifas mensuales del proveedor":"Provider Monthly Fees",1,null),n("div",null,{class:"col-span-2 h-2"},null,3,null),n("p",null,{class:"col-span-2"},l?"Tarifas cobradas una sola vez":"One-Time Purchase Fees",1,null),n("div",null,{class:"col-span-2 h-2"},null,3,null),n("p",null,null,l?"Tarifa por fin del servicio antes de lo pactado":"Early Termination Fee",1,null),n("p",null,{class:"text-right font-bold"},u(d=>d.early_termination_fee,[t],"p0.early_termination_fee"),3,null),n("p",null,null,l?"Impuestos gubernamentales":"Government Taxes",1,null),n("p",null,{class:"text-right font-bold"},l?"Varía según la ubicación":"Varies by Location",1,null)],1,null)],1,null),n("hr",null,{class:"border-2 border-black"},null,3,null),n("div",null,{class:"text-sm"},[n("p",null,{class:"font-bold"},l?"Descuentos y servicios combinados":"Discounts & Bundles",1,null),n("p",null,null,n("a",{href:w(e,"bundle_discounts_url")},null,[" ",w(e,"bundle_discounts_url")],1,null),1,null)],1,null),n("hr",null,{class:"border-2 border-black"},null,3,null),t.isVoice!=!0&&i(G,{children:[n("div",null,{class:"text-sm"},[n("p",null,{class:"font-bold"},l?"Velocidades de internet proporcionadas con este plan":"Speeds Provided with Plan",1,null),n("div",null,{class:"grid grid-cols-[2fr_1fr] gap-1 p-2"},[n("p",null,null,l?"Velocidad típica de descarga de datos":"Typical Download Speed",1,null),n("p",null,{class:"text-right font-bold"},u(d=>d.typical_download_speed+" Mbps",[t],'p0.typical_download_speed+" Mbps"'),3,null),n("p",null,null,l?"Velocidad típica de carga de datos":"Typical Upload Speed",1,null),n("p",null,{class:"text-right font-bold"},u(d=>d.typical_upload_speed+" Mbps",[t],'p0.typical_upload_speed+" Mbps"'),3,null),n("p",null,null,l?"Latencia típica":"Typical latency",1,null),n("p",null,{class:"text-right font-bold"},[u(d=>d.typical_latency,[t],"p0.typical_latency")," ms"],3,null)],1,null)],1,null),n("hr",null,{class:"border-black"},null,3,null),n("div",null,{class:"text-sm grid grid-cols-[3fr_1fr]"},[n("p",null,{class:"font-bold"},l?"Volumen de datos incluido en este precio mensual":"Data Included with Monthly Price",1,null),n("p",null,{class:"text-right font-bold"},u(d=>d.monthly_data_allow,[t],"p0.monthly_data_allow"),3,null),n("div",null,{class:"p-2 col-span-2"},[n("div",null,{class:"grid grid-cols-2 gap-1"},[n("p",null,null,l?"Cargos por uso adicional de datos ":"Charges for Additional Data Usage",1,null),n("p",null,{class:"text-right font-bold"},["$",u(d=>d.over_usage_data_price,[t],"p0.over_usage_data_price")],3,null)],1,null),t.data_allowance_policy_url!="N/A"&&n("p",null,{class:"text-sm"},n("a",{href:w(e,"data_allowance_policy_url")},null,w(e,"data_allowance_policy_url"),1,null),1,"F7_1")],1,null)],1,null),n("hr",null,{class:"border-2 border-black"},null,3,null)]},1,"F7_2"),n("div",null,{class:"text-sm"},[n("p",null,null,n("strong",null,null,l?"Política de administración de redes":"Network Management Policy",1,null),1,null),n("a",{href:w(e,"network_management_policy_url")},{class:"px-2",target:"_blank",rel:"noreferrer"},w(e,"network_management_policy_url"),1,null),n("p",null,null,n("strong",null,null,l?"Políticas de privacidad":"Privacy Policy",1,null),1,null),n("a",{href:w(e,"privacy_policy_url")},{class:"px-2",target:"_blank",rel:"noreferrer"},w(e,"privacy_policy_url"),1,null)],1,null),n("hr",null,{class:"border-4 border-black"},null,3,null),n("div",null,{class:"text-sm"},[n("p",null,{class:"font-bold"},l?"Política de privacidad":"Customer Support",1,null),n("p",null,{class:"px-2"},[l?"Teléfono:":"Phone:"," ",n("a",{href:`tel:${e.customer_support_phone}`},null,w(e,"customer_support_phone"),1,null)],1,null),n("p",null,{class:"px-2"},[l?"Sitio web:":"Website:"," ",n("a",{href:w(e,"customer_support_web")},{target:"_blank",rel:"noreferrer"},w(e,"customer_support_web"),1,null)],1,null)],1,null),n("hr",null,{class:"border border-black"},null,3,null),n("p",null,{class:"text-sm"},[" ",l?"Familiarícese con el lenguaje utilizado en esta etiqueta. Visite el sitio web del área de recursos para el consumidor, de la Comisión Federal de Comunicaciones (FCC).":"Learn more about the terms used on this label by visiting the Federal Communications Commission's Consumer Resource Center."],1,null),n("p",null,{class:"text-sm text-right"},n("strong",null,null,n("a",null,{href:"https://fcc.gov/consumer",target:"_blank",rel:"noreferrer"},"fcc.gov/consumer",3,null),3,null),3,null),e.unique_plan_id!="N/A"&&n("p",null,{class:"text-sm"},l?`Identificador Único de Plan: ${e.unique_plan_id}`:`Unique Plan Identifier: ${e.unique_plan_id}`,1,"F7_3")],1,null),n("div",null,{class:"flex flex-col items-center justify-evenly gap-2 w-full"},[i(K,{text:"Download as CSV",onClick:r,[s]:{text:s,onClick:s}},3,"F7_4"),i(K,{text:"Download as PDF",onClick:o,[s]:{text:s,onClick:s}},3,"F7_5"),i(K,{text:"Download as PNG",onClick:c,[s]:{text:s,onClick:s}},3,"F7_6")],1,null)],1,"F7_7")},Fl=b(f(p0,"s_bo6y7DBk1eY")),g0=t=>!t.isVisible||t.plans.length===0?null:n("div",null,{class:u(e=>`w-full flex-col gap-2 ${e.isVisible?"flex":"hidden"}`,[t],'`w-full flex-col gap-2 ${p0.isVisible?"flex":"hidden"}`')},[n("div",null,{class:"my-8 max-w-[350px] sm:max-w-[500px] mx-auto"},n("img",{src:ft(t.broadbandPageData.LogoServices.data[t.index].attributes.url)},{width:1230,height:229,alt:u(e=>e.broadbandPageData.LogoServices.data[e.index].attributes.alternativeText,[t],'p0.broadbandPageData["LogoServices"]["data"][p0.index]["attributes"]["alternativeText"]')},null,3,null),1,null),n("h2",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(e=>e.broadbandPageData.CustomerType[e.customerTypeIndex].title,[t],'p0.broadbandPageData["CustomerType"][p0.customerTypeIndex]["title"]'),3,null),n("div",null,{class:"flex w-full overflow-x-auto gap-1 flex-row xl:justify-center mb-4 pb-4"},t.plans.map((e,a)=>{var l,r,o,c,p,d,g,x,h,$,_,k,D,T,v,L,P,S,E,B,I,C,A,W,Y,U,rt,ct,nt,at,pt,Nt,Bt,Ct,Wt,Ut,Yt,Jt,Zt,Kt,Xt,te,ee,ae,le,ne,se,re,ie,oe,ue,ce,de,pe,ge,fe,xe,me,he,be,$e,ye,ve,_e,we,Se,Te,De,Pe,ke,Le;return i(Fl,{tier_plan_name:"NULL",connection_type:((o=(r=(l=e.values)==null?void 0:l.connection_type)==null?void 0:r[0])==null?void 0:o.data)||"N/A",get monthly_price(){return e.price},get service_plan_name(){return e.name},intro_rate:((d=(p=(c=e.values)==null?void 0:c.intro_rate)==null?void 0:p[0])==null?void 0:d.data)||"No",intro_rate_price:((h=(x=(g=e.values)==null?void 0:g.intro_rate_price)==null?void 0:x[0])==null?void 0:h.data)||"0.00",intro_rate_time:((k=(_=($=e.values)==null?void 0:$.intro_rate_time)==null?void 0:_[0])==null?void 0:k.data)||"N/A",contract_req:((v=(T=(D=e.values)==null?void 0:D.contract_req)==null?void 0:T[0])==null?void 0:v.data)||"No",contract_time:((S=(P=(L=e.values)==null?void 0:L.contract_time)==null?void 0:P[0])==null?void 0:S.data)||"N/A",contract_terms_url:((I=(B=(E=e.values)==null?void 0:E.contract_terms_url)==null?void 0:B[0])==null?void 0:I.data)||"",early_termination_fee:((W=(A=(C=e.values)==null?void 0:C.early_termination_fee)==null?void 0:A[0])==null?void 0:W.data)||"0.00",single_purchase_fee_descr:((rt=(U=(Y=e.values)==null?void 0:Y.single_purchase_fee_descr)==null?void 0:U[0])==null?void 0:rt.data)||"",single_purchase_fees:((at=(nt=(ct=e.values)==null?void 0:ct.single_purchase_fees)==null?void 0:nt[0])==null?void 0:at.data)||"",monthly_provider_fee_descr:((Bt=(Nt=(pt=e.values)==null?void 0:pt.monthly_provider_fee_descr)==null?void 0:Nt[0])==null?void 0:Bt.data)||"",monthly_provider_fee:((Ut=(Wt=(Ct=e.values)==null?void 0:Ct.monthly_provider_fee)==null?void 0:Wt[0])==null?void 0:Ut.data)||"",tax:((Zt=(Jt=(Yt=e.values)==null?void 0:Yt.tax)==null?void 0:Jt[0])==null?void 0:Zt.data)||"Varies",bundle_discounts_url:((te=(Xt=(Kt=e.values)==null?void 0:Kt.bundle_discounts_url)==null?void 0:Xt[0])==null?void 0:te.data)||"",get typical_download_speed(){return e.values.typical_download_speed[0].data},get typical_upload_speed(){return e.values.typical_upload_speed[0].data},typical_latency:((le=(ae=(ee=e.values)==null?void 0:ee.typical_latency)==null?void 0:ae[0])==null?void 0:le.data)||"N/A",unique_plan_id:((se=(ne=e.values.unique_plan_id)==null?void 0:ne[0])==null?void 0:se.data)||"N/A",monthly_data_allow:((oe=(ie=(re=e.values)==null?void 0:re.monthly_data_allow)==null?void 0:ie[0])==null?void 0:oe.data)||"Unlimited",over_usage_data_price:((de=(ce=(ue=e.values)==null?void 0:ue.over_usage_data_price)==null?void 0:ce[0])==null?void 0:de.data)||"N/A",additional_data_increment:((fe=(ge=(pe=e.values)==null?void 0:pe.additional_data_increment)==null?void 0:ge[0])==null?void 0:fe.data)||"N/A",data_allowance_policy_url:((he=(me=(xe=e.values)==null?void 0:xe.data_allowance_policy_url)==null?void 0:me[0])==null?void 0:he.data)||"",network_management_policy_url:((ye=($e=(be=e.values)==null?void 0:be.network_management_policy_url)==null?void 0:$e[0])==null?void 0:ye.data)||"",privacy_policy_url:((we=(_e=(ve=e.values)==null?void 0:ve.privacy_policy_url)==null?void 0:_e[0])==null?void 0:we.data)||"",customer_support_phone:((De=(Te=(Se=e.values)==null?void 0:Se.customer_support_phone)==null?void 0:Te[0])==null?void 0:De.data)||"",customer_support_web:((Le=(ke=(Pe=e.values)==null?void 0:Pe.customer_support_web)==null?void 0:ke[0])==null?void 0:Le.data)||"",get isVoice(){return t.isVoice??!1},[s]:{tier_plan_name:s,monthly_price:m(e,"price"),service_plan_name:m(e,"name"),typical_download_speed:m(e.values.typical_download_speed[0],"data"),typical_upload_speed:m(e.values.typical_upload_speed[0],"data"),isVoice:u(Qe=>Qe.isVoice??!1,[t],"p0.isVoice??false")}},3,`Broadband-${t.isVoice??!1?"Voice":"Internet"}-${t.customerTypeIndex}-${a}`)}),1,null)],1,"pq_0"),Qa=b(f(g0,"s_sFxDBHRht1E")),f0=()=>{const[t,e,a,l,r,o,c,p,d,g,x]=tt();a.value!=""&&l.value!=""?(e.value=!0,c.value=[],o.value=[],p.value=[],d.value=[],l0(a.value,l.value,x.value.value).then($=>{t.value=$.coverage,r.value=$.locationgroup,g.value=$.type,t.value&&r.value!=""&&g.value!=""&&n0(r.value,g.value).then(_=>{e.value=!1,c.value=[..._.residentialInternet],o.value=[..._.businessInternet],p.value=[..._.businessVoice],d.value=[..._.residentialVoice]})}),t.value=!0,l.value="",a.value=""):t.value=!1},x0=()=>{const[t,e,a,l]=tt();clearTimeout(l.value),l.value=setTimeout(()=>{t.value.value.length>2&&fetch(`/api/get-streets?q=${encodeURIComponent(t.value.value)}`).then(r=>r.json()).then(r=>{const o=r.data;o.length===0?e.value="notfound":e.value="success",a.value=o})},1e3)},m0=t=>{var B;V();const a=(B=ot().prevUrl)==null?void 0:B.pathname.includes("/es/"),l=t.data.pageBroadbandlabel.data.attributes,r=N(n("input",null,null,null,3,"9H_0")),o=N(n("input",null,null,null,3,null)),c=N(!0),p=N(!1),d=N(""),g=N(""),x=N(!1),h=N(""),$=N(""),_=N([]),k=N([]),D=N([]),T=N([]),v=N(),L=N([]),P=N("none"),S=f(f0,"s_oOiYJTdwxCg",[c,p,h,$,d,k,_,T,D,g,o]),E=f(x0,"s_FHeWve9kCIk",[r,P,L,v]);return n("div",null,{class:"flex flex-col items-center justify-around"},[n("h1",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},w(l,"Title"),1,null),n("div",null,{class:"bg-white md:h-[200px] h-[220px] rounded-full md:w-1/2 w-[90%] flex flex-col items-center justify-around my-5 gap-2"},[n("p",null,{class:"px-8 text-center text-[22px] font-[600] text-primary-blue max-[1000px]:px-12"},w(l.Form,"Title"),1,null),n("form",null,{action:"",class:"w-3/4 flex items-center justify-center gap-4 md:flex-row flex-col"},[n("input",{placeholder:w(l.Form.Fields[0],"Placeholder"),ref:r},{class:"md:w-[50%] w-[80%] rounded-full px-3 py-2 placeholder-primary-blue bg-primary-light-blue/20",required:!0,type:"text",onKeyUp$:E},null,3,null),n("input",{ref:o},{class:"w-[60%] rounded-full px-3 py-2 hidden placeholder-primary-blue",placeholder:"Zip Code",type:"text"},null,3,null),i(K,{get text(){return l.Form.ActionButton.Text},onClick:S,[s]:{text:m(l.Form.ActionButton,"Text"),onClick:s}},3,"9H_1")],1,null),n("p",null,{class:"text-xs text-primary-blue text-center "},a?"Ingresa tu dirección y selecciona la opción correcta de la lista desplegable que aparecerá":"Enter your address and select the correct option from the dropdown list that appears",1,null),n("label",null,{class:u(I=>`${I.value===!0?"flex":"hidden"} inline-flex items-center mb-5 cursor-pointer`,[c],'`${p0.value===true?"flex":"hidden"} inline-flex items-center mb-5 cursor-pointer`')},[n("input",null,{type:"checkbox",checked:u(I=>I.value,[x],"p0.value"),class:"sr-only peer",onChange$:O("s_fwlhznFW0dw",[x])},null,3,null),n("span",null,{class:"me-3 text-sm font-medium text-primary-blue"},w(l.CustomerType[0],"title"),1,null),n("div",null,{class:"relative w-11 h-6 bg-secondary-red peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full  rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:w-5 after:h-5 after:transition-all peer-checked:bg-primary-blue"},null,3,null),n("span",null,{class:"ms-3 text-sm font-medium text-primary-blue"},w(l.CustomerType[1],"title"),1,null)],1,null),n("p",null,{class:u(I=>`${I.value?"hidden":"flex"} text-secondary-red text-xl font-bold`,[c],'`${p0.value?"hidden":"flex"} text-secondary-red text-xl font-bold`')},w(l,"Message"),1,null)],1,null),n("div",{class:`flex max-h-[200px] flex-col gap-3 overflow-y-auto rounded-xl bg-white p-6 text-primary-blue shadow-lg ${P.value==="none"||P.value==="selected"?"hidden":""}`},null,[u(I=>I.value.length===0?"Not found":"",[L],'p0.value.length===0?"Not found":""'),L.value.map((I,C)=>n("div",{onClick$:O("s_Rx2cqo40ueo",[r,h,$,I,P,o])},{class:"grid items-center gap-4 hover:cursor-pointer",style:{gridTemplateColumns:"20px 1fr"}},[i(Oi,{class:"w-6 text-secondary-red",[s]:{class:s}},3,"9H_2"),n("span",null,{class:"text-[14px]"},w(I,"address"),1,null)],0,C))],1,null),p.value&&i(Gt,{size:"100px",[s]:{size:s}},3,"9H_3"),c.value&&i(G,{children:[i(Qa,{get isVisible(){return!x.value},get plans(){return _.value},broadbandPageData:l,index:0,customerTypeIndex:0,[s]:{isVisible:u(I=>!I.value,[x],"!p0.value"),plans:u(I=>I.value,[_],"p0.value"),index:s,customerTypeIndex:s}},3,"9H_4"),i(Qa,{get isVisible(){return x.value},get plans(){return k.value},broadbandPageData:l,index:0,customerTypeIndex:1,[s]:{isVisible:u(I=>I.value,[x],"p0.value"),plans:u(I=>I.value,[k],"p0.value"),index:s,customerTypeIndex:s}},3,"9H_5"),i(Qa,{get isVisible(){return!x.value},get plans(){return D.value},broadbandPageData:l,index:1,customerTypeIndex:0,isVoice:!0,[s]:{isVisible:u(I=>!I.value,[x],"!p0.value"),plans:u(I=>I.value,[D],"p0.value"),index:s,customerTypeIndex:s,isVoice:s}},3,"9H_6"),i(Qa,{get isVisible(){return x.value},get plans(){return T.value},broadbandPageData:l,index:1,customerTypeIndex:1,isVoice:!0,[s]:{isVisible:u(I=>I.value,[x],"p0.value"),plans:u(I=>I.value,[T],"p0.value"),index:s,customerTypeIndex:s,isVoice:s}},3,"9H_7")]},1,"9H_8")],1,null)},h0=b(f(m0,"s_0yKdtlPJIF0")),b0=t=>`query{
  pageBroadbandlabel(locale:"${t}"){
    data{
      attributes{
        Title
        Form{
          Title
          Fields{
            Placeholder
          }
            ActionButton{
            Text
          }
        }
        
        LogoServices{
          data{
            attributes{
              url
              alternativeText
              caption
            }
          }
        }
        
        CustomerType{
          title
        }
        
        Message

        ${z}
      }
    }
  }
}`,$0=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(b0,e)},Fn=q(f($0,"s_gl1xJfSALxI")),y0=()=>{const t=Fn();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageBroadbandlabel.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageBroadbandlabel.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBroadbandlabel"]["data"]["attributes"]["SEO"]')}},3,"LE_0"),i(h0,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"LE_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"LE_2")},v0=b(f(y0,"s_OUtP24mMYqU")),_0=({resolveValue:t})=>{const a=t(Fn).pageData.data.pageBroadbandlabel.data.attributes.SEO;return H(a)},w0=Object.freeze(Object.defineProperty({__proto__:null,default:v0,head:_0,usePageData:Fn},Symbol.toStringTag,{value:"Module"})),S0=t=>(V(),n("div",{class:`flex w-full flex-col items-center justify-center ${t.alt??!1?"bg-white":"bg-[#e2eefa]"}
        ${t.backgroundColor&&`bg-${t.backgroundColor}`}`},null,[(t.alt??!1)&&i(G,{children:[n("div",null,{class:"h-8 w-full bg-[#ebf4fc]"},null,3,null),n("div",null,{class:"h-8 w-full bg-[#f7fafe]"},null,3,null)]},3,"9K_0"),n("div",null,{class:u(e=>`my-4 flex ${e.reverse??!1?"flex-row-reverse":""} max-w-[1200px] items-center justify-center max-[800px]:flex-col`,[t],'`my-4 flex ${p0.reverse??false?"flex-row-reverse":""} max-w-[1200px] items-center justify-center max-[800px]:flex-col`')},[n("div",null,{class:u(e=>`flex ${e.image&&`min-[800px]:w-[${(e.textPercentage??70).toString()}%]`}  flex-col items-center justify-center gap-4 px-10`,[t],"`flex ${p0.image&&`min-[800px]:w-[${(p0.textPercentage??70).toString()}%]`}  flex-col items-center justify-center gap-4 px-10`")},[t.logo&&n("div",null,{class:"max-w-[470px]"},i(M,{get media(){return t.logo},width:"1230",height:"230",[s]:{media:u(e=>e.logo,[t],"p0.logo"),width:s,height:s}},3,"9K_1"),1,"9K_2"),n("div",null,{class:u(e=>`flex ${!(e.hasPricing??!0)&&"flex-col"} justify-center gap-2 text-${e.color??"primary-blue"}`,[t],'`flex ${!(p0.hasPricing??true)&&"flex-col"} justify-center gap-2 text-${p0.color??"primary-blue"}`')},[t.title&&n("h2",null,{class:"text-center text-[38px]  font-bold max-sm:text-[28px]"},u(e=>e.title,[t],"p0.title"),3,"9K_3"),t.subtitle&&n("h3",{class:`text-[28px] font-bold
                  ${t.backgroundColor&&t.backgroundColor.trim()!=="transparent"?"text-white":"text-secondary-red"}
                  ${t.hasPricing??!0?"":"text-center "} max-sm:text-[20px]`},null,u(e=>e.subtitle,[t],"p0.subtitle"),3,"9K_4")],1,null),i(j,{get text(){return t.text},get classN(){return`text-[18px] max-sm:text-[15px] text-${t.color??"primary-blue"}`},[s]:{text:u(e=>e.text,[t],"p0.text"),classN:u(e=>`text-[18px] max-sm:text-[15px] text-${e.color??"primary-blue"}`,[t],'`text-[18px] max-sm:text-[15px] text-${p0.color??"primary-blue"}`')}},3,"9K_5"),n("div",null,{class:"flex gap-4"},t.buttons&&t.buttons.map((e,a)=>i(K,{get text(){return e.Text},get link(){return e.Link},type:e.Link.startsWith("tel:")?"action":"link",children:i(Vp,{color:"#13B295",class:"text-[21px] opacity-60",[s]:{color:s,class:s}},3,"9K_6"),[s]:{text:m(e,"Text"),link:m(e,"Link")}},1,a)),1,null)],1,null),t.image&&n("div",null,{class:u(e=>`flex items-center justify-center self-center ${e.imageLink&&"cursor-pointer"}`,[t],'`flex items-center justify-center self-center ${p0.imageLink&&"cursor-pointer"}`'),onClick$:O("s_0a2swupHwgA",[t])},n("div",null,{class:"flex md:w-[400px] w-[350px] items-center justify-center self-center p-4"},i(M,{get media(){return t.image},width:"400",height:"400",[s]:{media:u(e=>e.image,[t],"p0.image"),width:s,height:s}},3,"9K_7"),1,null),1,"9K_8"),t.customComponent&&n("div",null,{class:u(e=>`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${(100-(e.textPercentage??70)).toString()}%]`,[t],"`flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[${(100-(p0.textPercentage??70)).toString()}%]`")},u(e=>e.customComponent,[t],"p0.customComponent"),3,"9K_9")],1,null),(t.alt??!1)&&i(G,{children:[n("div",null,{class:"h-8 w-full bg-[#f7fafe]"},null,3,null),n("div",null,{class:"h-8 w-full bg-[#ebf4fc]"},null,3,null)]},3,"9K_10")],1,"9K_11")),It=b(f(S0,"s_QAc0HW5bNAE")),T0=t=>i(It,{get logo(){return t.data.Logo&&t.data.Logo.data&&t.data.Logo.data.attributes},get image(){return t.data.Media&&t.data.Media.data&&t.data.Media.data.attributes},get title(){return t.data.Title},get subtitle(){return t.data.Subtitle},get text(){return t.data.Paragraph},get buttons(){return t.data.Buttons},get reverse(){return t.reverse??!1},get color(){return t.color??"primary-blue"},get alt(){return t.alt??!1},get hasPricing(){return t.hasPricing??!0},get textPercentage(){return t.textPercentage??70},get customComponent(){return t.customComponent},get backgroundColor(){return t.backgroundColor},imageLink:t.data.Media&&t.data.Media.data&&t.data.Media.data.attributes.caption.includes("http")?t.data.Media.data.attributes.caption:t.imageLink,[s]:{logo:u(e=>e.data.Logo&&e.data.Logo.data&&e.data.Logo.data.attributes,[t],'p0.data["Logo"]&&p0.data["Logo"]["data"]&&p0.data["Logo"]["data"]["attributes"]'),image:u(e=>e.data.Media&&e.data.Media.data&&e.data.Media.data.attributes,[t],'p0.data["Media"]&&p0.data["Media"]["data"]&&p0.data["Media"]["data"]["attributes"]'),title:u(e=>e.data.Title,[t],'p0.data["Title"]'),subtitle:u(e=>e.data.Subtitle,[t],'p0.data["Subtitle"]'),text:u(e=>e.data.Paragraph,[t],'p0.data["Paragraph"]'),buttons:u(e=>e.data.Buttons,[t],'p0.data["Buttons"]'),reverse:u(e=>e.reverse??!1,[t],"p0.reverse??false"),color:u(e=>e.color??"primary-blue",[t],'p0.color??"primary-blue"'),alt:u(e=>e.alt??!1,[t],"p0.alt??false"),hasPricing:u(e=>e.hasPricing??!0,[t],"p0.hasPricing??true"),textPercentage:u(e=>e.textPercentage??70,[t],"p0.textPercentage??70"),customComponent:u(e=>e.customComponent,[t],"p0.customComponent"),backgroundColor:u(e=>e.backgroundColor,[t],"p0.backgroundColor")}},3,"9K_12"),Ke=b(f(T0,"s_Itm0b43i6oU")),D0=t=>i(G,{children:t.data.map((e,a)=>i(Ke,{data:e,reverse:a%2===0,alt:a%2===0,get color(){return t.color??"primary-blue"},[s]:{color:u(l=>l.color??"primary-blue",[t],'p0.color??"primary-blue"')}},3,a))},1,"9K_13"),Xe=b(f(D0,"s_0DQ5Kmfc4bA")),P0=t=>{const e=t.data.pageBusiness.data.attributes.Services;return n("div",null,null,i(Xe,{data:e},3,"zl_0"),1,"zl_1")},k0=b(f(P0,"s_u188pr8UG0M")),L0=t=>`query QueryBusiness {
    pageBusiness(locale:"${t}"){    
      data{
        attributes{
          Services{
            Logo{
              ${y}
            }
            Media{
              ${y}
            }
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
             ${z}
  
        }
      }
    }
  }`,C0=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(L0,e)},zn=q(f(C0,"s_oQUmv8Ne7NI")),M0=()=>{const t=zn();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageBusiness.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageBusiness.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageBusiness"]["data"]["attributes"]["SEO"]')}},3,"Uj_0"),i(k0,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Uj_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Uj_2")},j0=b(f(M0,"s_JufSC5OrOV4")),I0=({resolveValue:t})=>{const a=t(zn).pageData.data.pageBusiness.data.attributes.SEO;return H(a)},E0=Object.freeze(Object.defineProperty({__proto__:null,default:j0,head:I0,usePageData:zn},Symbol.toStringTag,{value:"Module"})),N0=t=>n("div",null,{class:"relative flex w-full items-center justify-center"},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 z-10 grid",style:{gridTemplateRows:"35px 35px 1fr 35px 35px",gridTemplateColumns:"100%"}},[n("div",null,{class:"bg-white opacity-50"},null,3,null),n("div",null,{class:"bg-white opacity-80"},null,3,null),n("div",null,{class:"bg-white "},null,3,null),n("div",null,{class:"bg-white opacity-80"},null,3,null),n("div",null,{class:"bg-white opacity-50"},null,3,null)],3,null),n("div",null,{class:"z-10 flex flex-wrap items-center justify-center px-8 text-center text-[30px] font-[700] text-primary-blue"},[i(M,{clasN:"w-[300px] max-[1000px]:hidden",get media(){return t.data.HeaderPictures.data[0].attributes},[s]:{clasN:s,media:u(e=>e.data.HeaderPictures.data[0].attributes,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]')}},3,"bE_0"),n("div",null,{class:"flex flex-col"},[n("span",null,null,"Join the",3,null),i(M,{clasN:"w-[200px]",get media(){return t.data.HeaderLogo.data.attributes},[s]:{clasN:s,media:u(e=>e.data.HeaderLogo.data.attributes,[t],'p0.data["HeaderLogo"]["data"]["attributes"]')}},3,"bE_1"),n("span",null,null,"Family",3,null)],1,null),i(M,{clasN:"w-[300px]",get media(){return t.data.HeaderPictures.data[1].attributes},[s]:{clasN:s,media:u(e=>e.data.HeaderPictures.data[1].attributes,[t],'p0.data["HeaderPictures"]["data"][1]["attributes"]')}},3,"bE_2")],1,null)],1,"bE_3"),B0=b(f(N0,"s_YWCAmY4twe0")),A0=t=>n("div",null,{class:"flex h-[250px] w-[170px] flex-col items-center justify-start gap-3 rounded-[16px] bg-white p-3 text-center shadow-lg"},[i(M,{clasN:"h-[80px] w-[100%] object-cover rounded-[16px] bg-primary-blue bg-opacity-10",get media(){return t.offer.Media.data.attributes},width:"240",height:"120",[s]:{clasN:s,media:u(e=>e.offer.Media.data.attributes,[t],'p0.offer["Media"]["data"]["attributes"]'),width:s,height:s}},3,"IA_0"),n("h3",null,{class:"text-[18px] font-[600]"},u(e=>e.offer.Title,[t],'p0.offer["Title"]'),3,null),n("p",null,{class:"text-[14px] font-[400]"},u(e=>e.offer.Paragraph,[t],'p0.offer["Paragraph"]'),3,null)],1,"IA_1"),O0=t=>{const e=b(f(A0,"s_7vgX9wWJy0Y"));return n("div",null,{class:"flex w-full justify-center px-8"},n("div",null,{class:"mt-10 flex max-w-[1400px] items-center justify-center gap-8 px-8 text-center text-primary-blue max-[1000px]:flex-col"},[n("div",null,{class:"flex w-[50%] flex-col max-[1000px]:w-[100%]"},[n("h3",null,{class:"mt-3 text-[40px] font-[700]"},u(a=>a.data.BeliefsTitle,[t],'p0.data["BeliefsTitle"]'),3,null),n("span",null,{class:"text-[28px] font-[600]"},u(a=>a.data.BeliefsSubtitle,[t],'p0.data["BeliefsSubtitle"]'),3,null),n("span",null,{class:"text-[26px] font-[600] text-secondary-red"},u(a=>a.data.Beliefs[0].Text,[t],'p0.data["Beliefs"][0]["Text"]'),3,null),n("p",null,{class:"mt-3 text-[20px]"},u(a=>a.data.BeliefsDescription,[t],'p0.data["BeliefsDescription"]'),3,null)],3,null),n("div",null,{class:"flex w-[50%] flex-col items-center justify-center max-[1000px]:w-[100%]"},[n("h4",null,{class:"text-[40px] font-[700]"},u(a=>a.data.OfferingTitle,[t],'p0.data["OfferingTitle"]'),3,null),n("div",null,{class:"mt-4 flex flex-wrap justify-center gap-6"},t.data.Offerings.map((a,l)=>i(e,{offer:a},3,l)),1,null)],1,null)],1,null),1,"IA_2")},R0=b(f(O0,"s_rLVOk7WyC5I")),q0=t=>{const e=N("duties");return n("div",null,{class:"flex w-[60%] min-w-[310px] max-w-[550px] flex-col items-center rounded-[50px] bg-white p-8 text-primary-blue"},[n("div",null,{class:"mb-2 flex items-center gap-1"},[i(Mn,{class:"text-secondary-red",[s]:{class:s}},3,"H3_0"),n("span",null,{class:"text-[14px] opacity-60"},u(a=>a.data.Location,[t],'p0.data["Location"]'),3,null)],1,null),n("h4",null,{class:"mb-4 text-center text-[20px] font-[600] leading-7 text-primary-dark-blue"},u(a=>a.data.Name,[t],'p0.data["Name"]'),3,null),n("div",null,{class:"relative my-4 flex w-[300px] justify-between gap-2 overflow-hidden rounded-[30px] border border-primary-blue border-opacity-60 px-6 py-2"},[n("div",{class:`absolute bottom-0 transition-all ${e.value==="duties"?"left-0 right-[55%]":"left-[45%] right-0"} top-0 z-[1] rounded-[30px] bg-primary-blue shadow-sm`},null,null,3,null),n("div",null,{class:"z-[2] flex w-[45%] cursor-pointer items-center gap-1 px-2",onClick$:O("s_m2mi5sfy3GQ",[e])},[n("div",null,{class:"flex h-6 w-6 items-center justify-center rounded-full bg-white p-1"},i(Gp,{class:"text-secondary-red",[s]:{class:s}},3,"H3_1"),1,null),n("span",null,{class:u(a=>`font-[400] text-${a.value==="duties"?"white":"primary-blue"}`,[e],'`font-[400] text-${p0.value==="duties"?"white":"primary-blue"}`')},"Duties",3,null)],1,null),n("div",null,{class:"z-[2] flex w-[55%] cursor-pointer items-center gap-1 px-2",onClick$:O("s_ynhdzdQwHCA",[e])},[n("div",null,{class:"flex h-6 w-6 items-center justify-center rounded-full bg-white p-1"},i(Hp,{class:"text-secondary-red",[s]:{class:s}},3,"H3_2"),1,null),n("span",null,{class:u(a=>`font-[400] text-${a.value==="qualifications"?"white":"primary-blue"}`,[e],'`font-[400] text-${p0.value==="qualifications"?"white":"primary-blue"}`')},"Qualifications",3,null)],1,null)],1,null),n("div",null,{class:"relative flex h-[200px] w-full overflow-x-hidden text-[13px] leading-4 transition-all "},[n("div",null,{class:u(a=>`absolute h-[200px] w-full p-4 transition-all ${a.value!=="duties"?"right-full":" right-0"}`,[e],'`absolute h-[200px] w-full p-4 transition-all ${p0.value!=="duties"?"right-full":" right-0"}`')},i(j,{get text(){return t.data.Duties},[s]:{text:u(a=>a.data.Duties,[t],'p0.data["Duties"]')}},3,"H3_3"),1,null),n("div",null,{class:u(a=>`absolute h-[200px] w-full p-4 transition-all ${a.value!=="qualifications"?"left-full":"left-0"}`,[e],'`absolute h-[200px] w-full p-4 transition-all ${p0.value!=="qualifications"?"left-full":"left-0"}`')},i(j,{get text(){return t.data.Qualifications},[s]:{text:u(a=>a.data.Qualifications,[t],'p0.data["Qualifications"]')}},3,"H3_4"),1,null)],1,null)],1,"H3_5")},F0=b(f(q0,"s_kNPEZsb0EOk")),z0=t=>{var g;V();const a=(g=ot().prevUrl)==null?void 0:g.pathname.includes("/es/"),l=N("NONE"),r=N(!1),o=N(!1),c=N(!1),p=N(!1),d=Lt(O("s_hP0gadtF5EA",[p,r,l,c,o,t]));return n("div",null,{class:"flex flex-col w-full md:w-1/2 h-[560px] bg-blue-100 rounded-2xl p-4"},[n("p",null,{class:"text-center font-medium text-color-Primary"},"Fill out the form below and attach your resume to contact us today",3,null),n("form",null,{id:"form_careers",class:"mt-2 overflow-y-auto",onSubmit$:O("s_i05DmpZA0BU",[d])},[n("div",null,{class:"flex-col sm:flex-row flex justify-between"},[n("div",null,{class:"mb-4 gap-2 w-full flex flex-col mr-0 md:mr-4"},[n("label",null,{for:"from_name",class:"block font-medium text-color-Primary"},"Name",3,null),n("input",null,{type:"text",id:"from_name",name:"from_name",class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500"},null,3,null)],3,null),n("div",null,{class:"mb-4 gap-2 w-full flex flex-col"},[n("label",null,{for:"tel",class:"block font-medium text-color-Primary"},"Phone",3,null),n("input",null,{type:"tel",id:"tel",name:"tel",maxLength:14,class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500"},null,3,null),n("label",null,{class:u((x,h)=>`text-xs text-red-600 ${x.value==!1&&h.value==!0?"flex":"hidden"} bg-transparent`,[r,o],'`text-xs text-red-600 ${p0.value==false&&p1.value==true?"flex":"hidden"} bg-transparent`')},"phone number is invalid",3,null)],3,null)],3,null),n("div",null,{class:"mb-4 gap-2 flex flex-col"},[n("label",null,{for:"from_email",class:"block font-medium text-color-Primary"},"Email",3,null),n("input",null,{type:"email",id:"from_email",name:"from_email",class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",required:!0},null,3,null),n("label",null,{class:u((x,h)=>`text-xs text-red-600 ${x.value==!1&&h.value==!0?"flex":"hidden"} bg-transparent`,[p,c],'`text-xs text-red-600 ${p0.value==false&&p1.value==true?"flex":"hidden"} bg-transparent`')},"email is invalid",3,null)],3,null),n("div",null,{class:"mb-4 gap-2 flex flex-col"},[n("label",null,{for:"message",class:"block  font-medium text-color-Primary"},"Message",3,null),n("textarea",null,{id:"message",name:"message",rows:4,class:"w-full border border-gray-300 p-2 rounded-xl focus:outline-none focus:border-blue-500",required:!0},null,3,null)],3,null),n("label",null,{for:"resume",class:"flex w-[200px] text-color-Primary p-2 justify-evenly rounded-md font-medium"},["Upload resume",i(cg,{class:"text-center font-bold",[s]:{class:s}},3,"ty_0")],1,null),n("input",null,{type:"file",required:!0,accept:".pdf",id:"resume",name:"resume",class:"w-full"},null,3,null),n("button",{class:`flex flex-row items-center justify-center mt-4 bg-secondary-red text-white w-full font-semibold px-4 py-2 rounded-xl hover:bg-blue-600 focus:outline-none ${l.value==="LOADING"?"cursor-wait bg-primary-blue":l.value==="SUCCESS"?"bg-teal-500":""} focus:outline-none`},{type:"submit",disabled:u(x=>x.value==="LOADING"||x.value==="SUCCESS",[l],'p0.value==="LOADING"||p0.value==="SUCCESS"')},l.value==="NONE"?a?"Enviar":"Send":l.value==="LOADING"?i(Gt,{size:"28px",[s]:{size:s}},3,"ty_1"):l.value==="ERROR"?"Error":a?"¡Mensaje enviado!":"Email Sent!",1,null)],1,null)],1,"ty_2")},Q0=b(f(z0,"s_34gK8gnZN08")),G0=({positionName:t})=>{const[e,a]=tt();a.value=t,e.value=!0},H0=t=>{const[e,a,l]=tt();return n("div",null,{class:"flex h-[380px] w-[460px] flex-col justify-between rounded-[30px] bg-white p-6 text-center shadow-lg max-[800px]:h-[280px] "},[n("div",null,{class:"flex-col items-center"},[n("div",null,{class:"flex items-center justify-center gap-2"},[i(Mn,null,3,"At_0"),n("span",null,{class:"font-[500] opacity-60"},u(r=>r.position.Location,[t],'p0.position["Location"]'),3,null)],1,null),n("h4",null,{class:"mt-2 text-[19px] font-[700] text-primary-dark-blue"},u(r=>r.position.Name,[t],'p0.position["Name"]'),3,null),i(j,{classN:"text-[15px] max-[800px]:text-[13px]",get text(){return t.position.Summary},[s]:{classN:s,text:u(r=>r.position.Summary,[t],'p0.position["Summary"]')}},3,"At_1")],1,null),n("div",null,{class:"flex flex-col items-center gap-2"},[n("div",null,{class:"flex gap-1 text-[15px]"},[n("span",null,{class:"text-btn-green hover:cursor-pointer",onClick$:O("s_d5LXfHtAyog",[a,t,l])},"Learn more",3,null)," ",n("span",null,{class:"text-black"},"or",3,null)],3,null),n("button",null,{class:"flex w-fit items-center justify-center rounded-full border-2 border-teal-500 border-opacity-70 bg-white p-0.5 px-1 text-btn-green opacity-90 shadow-md delay-150 ease-in-out hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:O("s_O0F0Jjn1jLU",[e,t])}," Submit Resume ",3,null)],3,null)],1,"At_2")},V0=t=>{var h;const e=N(!1),a=N(!1),l=N(t.data.Positions[0].attributes),r=N(""),o=t.data.FormInfo.split("="),p=(h=ot().prevUrl)==null?void 0:h.pathname.includes("/es/"),g=b(f(H0,"s_MLxpYci0h0Y",[f(G0,"s_DxkiX1SABig",[e,r]),a,l])),x=t.data.Positions.map(($,_)=>i(g,{get position(){return $.attributes},[s]:{position:m($,"attributes")}},3,_));return n("div",null,{class:"my-8 flex justify-center text-primary-blue"},[i(ql,{showSignal:e,children:i(Q0,{templateID:o[2],mailto:o[3],subject:o[4],lang:p?"es":"en",get position(){return r.value},[s]:{position:u($=>$.value,[r],"p0.value")}},3,"At_3"),[s]:{showSignal:s}},1,"At_4"),i(ql,{showSignal:a,children:i(F0,{get data(){return l.value},[s]:{data:u($=>$.value,[l],"p0.value")}},3,"At_5"),[s]:{showSignal:s}},1,"At_6"),n("div",null,{class:"flex flex-col "},[n("h3",null,{class:"text-center text-[44px] font-[600]"},u($=>$.data.PositionsTitle,[t],'p0.data["PositionsTitle"]'),3,null),n("div",null,{class:"flex-column flex w-[1200px] "},i(kt,{slides:x,id:"carPositions",hasArrows:!0,[s]:{id:s,hasArrows:s}},3,"At_7"),1,null)],1,null)],1,"At_8")},W0=b(f(V0,"s_Su5lXmtHgW0")),U0=t=>{const e=t.data.pageCareers.data.attributes;return n("div",null,{onClick$:O("s_yJsNttxIAPY")},[i(B0,{data:{HeaderLogo:t.data.pageCareers.data.attributes.HeaderLogo,HeaderTitle:t.data.pageCareers.data.attributes.HeaderTitle,HeaderPictures:t.data.pageCareers.data.attributes.HeaderPictures}},3,"a0_0"),i(R0,{data:{Beliefs:t.data.pageCareers.data.attributes.Beliefs,BeliefsDescription:t.data.pageCareers.data.attributes.BeliefsDescription,BeliefsSubtitle:t.data.pageCareers.data.attributes.BeliefsSubtitle,BeliefsTitle:t.data.pageCareers.data.attributes.BeliefsTitle,Offerings:t.data.pageCareers.data.attributes.Offerings,OfferingTitle:t.data.pageCareers.data.attributes.OfferingTitle}},3,"a0_1"),n("div",null,{class:"flex w-full justify-center px-8"},n("div",null,{class:"max-w-[1200px] text-center text-primary-blue"},[n("h3",null,{class:"mb-4 mt-16 text-[38px] font-[800]"},w(e.FormParagraph,"Title"),1,null),i(j,{get text(){return e.FormParagraph.Paragraph},classN:"text-[18px] font-[400]",[s]:{text:m(e.FormParagraph,"Paragraph"),classN:s}},3,"a0_2")],1,null),1,null),i(W0,{data:{Positions:e.Positions.data,PositionsTitle:e.PositionsTitle,FormInfo:e.FormParagraph.Buttons[0].Link}},3,"a0_3")],1,"a0_4")},Y0=b(f(U0,"s_CHSZKaaPR2c")),J0=t=>`query QueryCareers {
    pageCareers(locale:"${t}"){    
      data{
        attributes{
                  HeaderLogo{
                    ${y}
                  }
          HeaderPictures{
            ${y}
          }
          HeaderBackground{
           ${y}
          }
          HeaderTitle{
            Text
          }
          
          
          BeliefsTitle
          BeliefsSubtitle
          Beliefs{
            Text
          }
          BeliefsDescription
          
          
          OfferingTitle
          Offerings{
            Title
            Paragraph
            Media{
              ${y}
            }
          }
          
          PositionsTitle
          Positions(sort: "Name:Asc"){
            data{
              attributes{
                Location
                Name
                Summary
                Duties
                Qualifications
              }
            }
          }
          
          FormParagraph{
            Title
            Paragraph
            Buttons{
            Link
            }
          }
          FormCareers{
            Title
            Fields{
              Label
              Icon{
                ${y}
              }
            }
            ActionButton{
              Text
              Link
            }
          }
        ${z}
        }
      }
    }
  }`,Z0=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(J0,e)},Qn=q(f(Z0,"s_bBcTtiHl1Tw")),K0=()=>{const t=Qn();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageCareers.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageCareers.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageCareers"]["data"]["attributes"]["SEO"]')}},3,"sa_0"),i(Y0,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"sa_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"sa_2")},X0=b(f(K0,"s_KylSGhTDLNs")),tx=({resolveValue:t})=>{const a=t(Qn).pageData.data.pageCareers.data.attributes.SEO;return H(a)},ex=Object.freeze(Object.defineProperty({__proto__:null,default:X0,head:tx,usePageData:Qn},Symbol.toStringTag,{value:"Module"})),ax=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(j,{get text(){return t.data.TextContent},classN:"markdownTitle markdownh3 markdownHyper text-justify flex text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"27_0")],1,"27_1"),lx=b(f(ax,"s_qLAYw5vO9og")),nx=t=>`query QuerySupplement {
        pageSuppleTerms(locale:"${t}"){    
          ${fa}
          ${z}
            }
          }
        }
      }`,sx=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(nx,e)},Gn=q(f(sx,"s_LHhYaz4wQcQ")),rx=()=>{const t=Gn(),e=t.value.pageData.data.pageSuppleTerms.data.attributes.Content;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(lx,{data:e},3,"NP_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"NP_1")},1,"NP_2")},ix=b(f(rx,"s_2WfoIGYZZ0E")),ox=({resolveValue:t})=>{const a=t(Gn).pageData.data.pageSuppleTerms.data.attributes.SEO;return H(a)},ux=Object.freeze(Object.defineProperty({__proto__:null,default:ix,head:ox,usePageData:Gn},Symbol.toStringTag,{value:"Module"})),cx=t=>n("div",null,{class:"flex flex-col py-10 items-center justify-center"},[n("h1",null,{class:"text-2xl sm:text-4xl font-bold text-primary-blue"},u(e=>e.data.Introduction.Title,[t],'p0.data["Introduction"]["Title"]'),3,null),n("p",null,{class:"text-primary-blue text-center text-[16px] md:text-[18px] m-5"},u(e=>e.data.Introduction.Paragraph,[t],'p0.data["Introduction"]["Paragraph"]'),3,null),i(K,{get text(){return t.data.Introduction.Buttons[0].Text},get link(){return t.data.Introduction.Buttons[0].Link},[s]:{text:u(e=>e.data.Introduction.Buttons[0].Text,[t],'p0.data["Introduction"]["Buttons"][0]["Text"]'),link:u(e=>e.data.Introduction.Buttons[0].Link,[t],'p0.data["Introduction"]["Buttons"][0]["Link"]')}},3,"wL_0"),n("div",null,{class:"flex flex-col items-center gap-2 px-4 py-4 my-10"},[n("h2",null,{class:"text-xl sm:text-2xl font-bold text-primary-blue"},u(e=>e.data.SocialMedia.Text,[t],'p0.data["SocialMedia"]["Text"]'),3,null),n("div",null,{class:"flex flex-row gap-4"},t.data.SocialMedia.SubOption.map((e,a)=>V(i(zt,{get href(){return e.Link},children:[e.Link.includes("facebook")&&n("div",null,{class:"flex w-[50px] h-[50px] items-center justify-center rounded-full bg-primary-blue p-4"},i(M,{get media(){return e.Icon.data.attributes},toWhite:!0,[s]:{media:m(e.Icon.data,"attributes"),toWhite:s}},3,"wL_1"),1,"wL_2"),!e.Link.includes("facebook")&&n("div",null,{class:"flex w-[50px] h-[50px] items-center justify-center rounded-full bg-primary-blue p-3"},i(M,{get media(){return e.Icon.data.attributes},toWhite:!0,[s]:{media:m(e.Icon.data,"attributes"),toWhite:s}},3,"wL_3"),1,"wL_4")],[s]:{href:m(e,"Link")}},1,a))),1,null)],1,null),n("div",null,{class:"flex flex-col items-center justify-center"},[n("h3",null,{class:"text-xl sm:text-2xl font-bold text-primary-blue"},u(e=>e.data.OfficesTitle,[t],'p0.data["OfficesTitle"]'),3,null),n("div",null,{class:"flex flex-wrap gap-8 mt-5 justify-center items-start"},t.data.OfficesLocation.map((e,a)=>n("div",null,{class:"flex flex-col w-[200px]"},[n("a",{href:w(e.Buttons[0],"Link")},{class:"font-bold text-secondary-red"},w(e.Buttons[0],"Text"),1,null),n("a",{href:w(e.Buttons[1],"Link")},{class:"font-bold text-primary-blue"},w(e.Buttons[1],"Text"),1,null),n("p",null,{class:"tracking-wide font-normal text-sm text-primary-blue"},w(e,"Paragraph"),1,null)],1,a)),1,null)],1,null)],1,"wL_5"),dx=b(f(cx,"s_5L0HuXf9QnQ")),px=t=>`query QueryContactUs{
        pageContact(locale:"${t}"){
          data{
            attributes{
              Introduction{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              SocialMedia{
                Text
                SubOption{
                  Text
                  Link
                  Icon{
                    ${y}
                  }
                }
              }
              
              OfficesTitle
              OfficesLocation{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              ${z}
            }
          }
        }
      }`,gx=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(px,e)},Hn=q(f(gx,"s_QdheZerij2w")),fx=()=>{const t=Hn(),e=t.value.pageData.data.pageContact.data.attributes;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(dx,{data:e},3,"yX_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"yX_1")},1,"yX_2")},xx=b(f(fx,"s_FZeWA02p0TI")),mx=({resolveValue:t})=>{const a=t(Hn).pageData.data.pageContact.data.attributes.SEO;return H(a)},hx=Object.freeze(Object.defineProperty({__proto__:null,default:xx,head:mx,usePageData:Hn},Symbol.toStringTag,{value:"Module"})),bx=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(j,{get text(){return t.data.TextContent},classN:"markdownTitle markdownHyper text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"NS_0")],1,"NS_1"),$x=b(f(bx,"s_gvsFRD0Vfkk")),yx=t=>`
query QueryCookies {
  pageCookies(locale:"${t}"){    
    ${fa}
    ${z}
      }
    }
  }
}`,vx=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(yx,e)},Vn=q(f(vx,"s_IqhWiqyXb00")),_x=()=>{const t=Vn(),e=t.value.pageData.data.pageCookies.data.attributes.Content;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i($x,{data:e},3,"wB_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"wB_1")},1,"wB_2")},wx=b(f(_x,"s_OmN9OIo5qbs")),Sx=({resolveValue:t})=>{const a=t(Vn).pageData.data.pageCookies.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},Tx=Object.freeze(Object.defineProperty({__proto__:null,default:wx,head:Sx,usePageData:Vn},Symbol.toStringTag,{value:"Module"})),Dx=t=>(V(),t.media.url.includes(".mp4")?n("video",{src:ft(t.media.url)},{width:u(e=>e.width,[t],"p0.width"),height:u(e=>e.height,[t],"p0.height"),autoplay:u(e=>e.autoplay??!1,[t],"p0.autoplay??false"),controls:u(e=>e.controls??!1,[t],"p0.controls??false"),loop:u(e=>e.loop??!0,[t],"p0.loop??true"),muted:u(e=>e.muted??!0,[t],"p0.muted??true"),class:u(e=>(e.toWhite??!1?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(e.clasN??""),[t],'(p0.toWhite??false?"brightness-110 contrast-100 hue-rotate-[23deg] invert saturate-[7500%] sepia-0 filter":"")+" "+(p0.clasN??"")')},null,3,"kf_0"):i(M,{get media(){return t.media},get width(){return t.width},get height(){return t.height},get toWhite(){return t.toWhite??!1},get clasN(){return t.clasN??""},[s]:{media:u(e=>e.media,[t],"p0.media"),width:u(e=>e.width,[t],"p0.width"),height:u(e=>e.height,[t],"p0.height"),toWhite:u(e=>e.toWhite??!1,[t],"p0.toWhite??false"),clasN:u(e=>e.clasN??"",[t],'p0.clasN??""')}},3,"kf_1")),zl=b(f(Dx,"s_GG0oZTUUfNc")),Px=t=>n("div",null,{class:u(e=>`${e.data.isVisible?"":"hidden"} flex w-full flex-col items-center justify-center text-primary-blue`,[t],'`${p0.data["isVisible"]?"":"hidden"} flex w-full flex-col items-center justify-center text-primary-blue`')},n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center px-10 min-[800px]:w-[70%]"},[n("span",null,{class:"text-center text-[38px] font-[800] text-secondary-red max-[800px]:text-[30px]"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),i(j,{classN:"mb-3 w-full bg-primary-blue p-2 font-[600] text-[26px] max-[800px]:text-[20px] text-white text-center mx-4 rounded-full",get text(){return t.data.Description},[s]:{classN:s,text:u(e=>e.data.Description,[t],'p0.data["Description"]')}},3,"Sf_0"),i(j,{classN:"text-center text-[26px]",get text(){return t.data.Deal},[s]:{classN:s,text:u(e=>e.data.Deal,[t],'p0.data["Deal"]')}},3,"Sf_1"),i(j,{classN:"text-center text-[18px] mb-3",get text(){return t.data.Deals_description},[s]:{classN:s,text:u(e=>e.data.Deals_description,[t],'p0.data["Deals_description"]')}},3,"Sf_2"),n("div",null,{class:"mb-3 flex items-start justify-evenly gap-4 max-[600px]:flex-col"},t.data.Services.map((e,a)=>n("div",null,{class:"flex items-center justify-center gap-1"},[i(zl,{get media(){return e.Icon.data.attributes},clasN:"w-[100px] max-[1000px]:w-[80px] ",muted:!0,[s]:{media:m(e.Icon.data,"attributes"),clasN:s,muted:s}},3,"Sf_3"),n("span",null,{class:"font-[600]"},w(e,"Title"),1,null)],1,a)),1,null),i(K,{get text(){return t.data.Button.Text},get link(){return t.data.Button.Link},[s]:{text:u(e=>e.data.Button.Text,[t],'p0.data["Button"]["Text"]'),link:u(e=>e.data.Button.Link,[t],'p0.data["Button"]["Link"]')}},3,"Sf_4")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 max-[600px]:hidden min-[800px]:w-[30%]"},i(zl,{get media(){return t.data.Media.data.attributes},clasN:"rounded-full  mr-[30px]",autoplay:!0,loop:!0,muted:!0,[s]:{media:u(e=>e.data.Media.data.attributes,[t],'p0.data["Media"]["data"]["attributes"]'),clasN:s,autoplay:s,loop:s,muted:s}},3,"Sf_5"),1,null)],1,null),1,"Sf_6"),kx=b(f(Px,"s_4av0zjglZmk")),Lx=t=>n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"min-h-[200px] w-full bg-gradient-to-br from-primary-light-blue to-[#23477f] !text-white"},i(Ke,{get data(){return t.data},color:"white",backgroundColor:"primary-blue",[s]:{data:u(e=>e.data,[t],"p0.data"),color:s,backgroundColor:s}},3,"tV_0"),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"tV_1"),Cx=b(f(Lx,"s_cJop3g0b1vg")),Mx=t=>n("div",null,{class:"flex w-full items-center justify-center"},n("div",null,{class:"flex max-w-[1200px] flex-wrap items-start justify-evenly gap-6 p-8"},t.data.map((e,a)=>n("div",null,{class:"flex w-[280px] flex-col items-center gap-2"},[i(Ue,{get media(){return e.Media.data.attributes},color:a%2===0?"bg-[#2E5899]":"bg-secondary-red",width:"300px",height:"300px",[s]:{media:m(e.Media.data,"attributes"),width:s,height:s}},3,"lG_0"),i(j,{get text(){return e.Title},classN:"font-[600] text-center text-[18px] tracking-[-1px]",[s]:{text:m(e,"Title"),classN:s}},3,"lG_1"),i(j,{get text(){return e.Paragraph},classN:"text-center text-[16px]",[s]:{text:m(e,"Paragraph"),classN:s}},3,"lG_2")],1,a)),1,null),1,"lG_3"),jx=b(f(Mx,"s_gpmIUuGz0sE")),Ix=t=>{const e=t.data.pageDeals.data.attributes.Deals,a=t.data.pageDeals.data.attributes.RefInfo,l=t.data.pageDeals.data.attributes.Discounts,r=t.data.pageDeals.data.attributes.Disclaimer;return n("div",null,null,[i(kx,{data:e},3,"e6_0"),i(Cx,{data:a},3,"e6_1"),i(jx,{data:l},3,"e6_2"),n("div",null,{class:"flex w-full items-center  justify-center p-8 text-center text-[14px] italic text-primary-dark-blue"},r,1,null)],1,"e6_3")},Ex=b(f(Ix,"s_xtY1ub2ohjs")),Nx=t=>`
  query QueryDeals{
    pageDeals(locale:"${t}"){
      data{
        attributes{
          Deals {
            isVisible
            Title
            Description
            Deal
            Deals_description
            Media {
              ${y}
            }
            Services {
              Title
              Icon {
                ${y}
              }
            }
            Button {
              Text
              Link
            }
          }
  
          RefInfo{
            Title
            Paragraph
            Media{
              ${y}
            }
            Buttons{
              Text
              Link
            }
          }
          RefBackground{
            ${y}
          }
          
          Discounts{
            Title
            Paragraph
            Media{
             ${y}
            }
          }
          Disclaimer
          
          ${z}
        }
      }
    }
  }
    `,Bx=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Nx,e)},Wn=q(f(Bx,"s_2jiG1A0ymzM")),Ax=()=>{const t=Wn();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageDeals.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageDeals.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageDeals"]["data"]["attributes"]["SEO"]')}},3,"B3_0"),i(Ex,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"B3_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"B3_2")},Ox=b(f(Ax,"s_OVAjdqBqgec")),Rx=({resolveValue:t})=>{const a=t(Wn).pageData.data.pageDeals.data.attributes.SEO;return H(a)},qx=Object.freeze(Object.defineProperty({__proto__:null,default:Ox,head:Rx,usePageData:Wn},Symbol.toStringTag,{value:"Module"})),Fx=t=>n("div",null,{class:"my-8"},[n("h1",null,{class:"text-center text-xl font-semibold text-primary-blue"},u(e=>e.data.Introduction.Titles[0].Text,[t],'p0.data["Introduction"]["Titles"][0]["Text"]'),3,null),n("h2",null,{class:"text-center text-primary-blue"},u(e=>e.data.Introduction.TextContent,[t],'p0.data["Introduction"]["TextContent"]'),3,null),n("div",null,{class:"px-4 md:px-10"},t.data.FAQList.map((e,a)=>V(i(xa,{get title(){return e.Title},classContainer:"text-center bg-white text-primary-blue text-base md:text-lg shadow-xl",classChild:" text-sm md:text-base border-primary-blue",children:[i(j,{get text(){return e.Paragraph},classN:"text-primary-blue p-2",[s]:{text:m(e,"Paragraph"),classN:s}},3,"NP_0"),e.Disclaimer!==null?n("div",null,{class:"flex flex-row items-center justify-center gap-2"},[i(ng,{class:"text-secondary-red",[s]:{class:s}},3,"NP_1"),i(j,{get text(){return e.Disclaimer.Text},classN:"text-[12px] text-primary-dark-blue",[s]:{text:m(e.Disclaimer,"Text"),classN:s}},3,"NP_2")],1,"NP_3"):null,e.Table!==null?n("div",null,{class:"flex flex-col item-center justify-center"},n("table",null,{class:"border-collapse border rounded-2xl border-gray-200 w-full"},n("tbody",null,null,e.Table.map((l,r)=>V(n("div",null,null,l.ColumnThree.includes("Title")?n("tr",null,{class:"bg-white text-start"},n("th",null,{colSpan:2},[i(j,{get text(){return l.ColumnOne},classN:"px-2 text-start",[s]:{text:m(l,"ColumnOne"),classN:s}},3,"NP_4")," "],1,null),1,r):n("tr",{class:`${r===0?"text-white bg-primary-blue":r%2===1?"bg-blue-100 text-primary-blue text-[13px]":"bg-blue-200 text-primary-blue text-[13px]"}`},null,[n("td",null,null,[i(j,{get text(){return l.ColumnOne},classN:`text-start px-2 ${r===0?"text-white ":"text-primary-blue"}`,[s]:{text:m(l,"ColumnOne")}},3,"NP_5")," "],1,null),n("td",null,null,i(j,{get text(){return l.ColumnTwo},classN:`text-start px-2 ${r===0?"text-white ":"text-primary-blue"}`,[s]:{text:m(l,"ColumnTwo")}},3,"NP_6"),1,null)],1,r),1,"NP_7"))),1,null),1,null),1,"NP_8"):null],[s]:{title:m(e,"Title"),classContainer:s,classChild:s}},1,a))),1,null)],1,"NP_9"),zx=b(f(Fx,"s_x7ihZ2PZWys")),Qx=t=>`query QueryFAQ {
        pageFaq(locale:"${t}") {
          data{
            attributes{    
              Introduction{
                Titles{
                  Text
                }
                TextContent
              }
      
              FAQList{
                Title
                Paragraph
                Disclaimer{
                Icon{
                    ${y}
                }
                Title
                Text
                Caption
                }

                Table(pagination: { limit: 50 }){
                ColumnOne
                ColumnTwo
                ColumnThree
                }
              }
              
              ${z}
            }
          }
        }
      }`,Gx=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Qx,e)},Un=q(f(Gx,"s_SBnhqZ85K9A")),Hx=()=>{const t=Un(),e=t.value.pageData.data.pageFaq.data.attributes;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(zx,{data:e},3,"k1_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"k1_1")},1,"k1_2")},Vx=b(f(Hx,"s_jDEouB0mRKg")),Wx=({resolveValue:t})=>{const a=t(Un).pageData.data.pageFaq.data.attributes.SEO;return H(a)},Ux=Object.freeze(Object.defineProperty({__proto__:null,default:Vx,head:Wx,usePageData:Un},Symbol.toStringTag,{value:"Module"})),Yx=t=>(V(),n("div",null,{class:"flex md:flex-row flex-col-reverse w-full text-center items-center justify-center md:p-8 md:my-10"},[n("div",null,{class:"relative"},[n("div",null,{class:"flex w-[20vw] h-[20vw] min-w-[300px] min-h-[300px] items-center justify-center"},n("div",null,{class:"bg-[#2E5899] md:h-full h-[285px] md:w-full w-[285px] bg-opacity-40 p-6 inline-block items-center justify-center rounded-full"},n("div",null,{class:"bg-[#2E5899] flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-60 px-6 py-6 shadow-md"},n("div",null,{class:"bg-[#2E5899] flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-opacity-80 shadow-md"},n("div",null,{class:"flex flex-col items-center gap-5"},null,3,null),3,null),3,null),3,null),3,null),n("div",null,{class:"flex gap-3 flex-col absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full items-center justify-center"},[i(j,{get text(){return t.parData.Paragraph},classN:"text-white text-[18px] leading-none md:text-[1.75vw]",[s]:{text:u(e=>e.parData.Paragraph,[t],'p0.parData["Paragraph"]'),classN:s}},3,"nC_0"),t.parData.Buttons&&t.parData.Buttons.map((e,a)=>n("div",null,{class:"z-50"},i(K,{get text(){return e.Text},get link(){return e.Link},[s]:{text:m(e,"Text"),link:m(e,"Link")}},3,"nC_1"),1,a))],1,null)],1,null),n("div",null,{class:"flex flex-col gap-5 md:px-[30px] px-[12vw] py-5"},[n("div",null,{class:"flex flex-col justify-center items-center"},[i(j,{get text(){return t.parData.Title},classN:"[&>h1]:text-[28px]",[s]:{text:u(e=>e.parData.Title,[t],'p0.parData["Title"]'),classN:s}},3,"nC_2"),i(M,{get media(){return t.parData.Logo.data.attributes},width:"400px",height:"100px",[s]:{media:u(e=>e.parData.Logo.data.attributes,[t],'p0.parData["Logo"]["data"]["attributes"]'),width:s,height:s}},3,"nC_3")],1,null),t.parData.Subtitle&&i(j,{get text(){return t.parData.Subtitle},classN:"[&>h2]:text-[18px]",[s]:{text:u(e=>e.parData.Subtitle,[t],'p0.parData["Subtitle"]'),classN:s}},3,"nC_4")],1,null),n("div",null,{class:"w-[20vw] h-[20vw] min-w-[300px] min-h-[300px] max-[930px]:hidden flex"},i(Ue,{get media(){return t.parData.Media.data.attributes},[s]:{media:u(e=>e.parData.Media.data.attributes,[t],'p0.parData["Media"]["data"]["attributes"]')}},3,"nC_5"),1,null)],1,"nC_6")),Yn=b(f(Yx,"s_BQqIfxz8NXA")),Jx=t=>(V(),n("div",null,{class:" flex md:flex-row flex-col-reverse w-full text-center items-center justify-center p-8 bg-gradient-to-r from-blue-600 to-[#2e5899]"},n("div",null,{class:"max-w-[1300px] w-full flex flex-col"},[n("div",null,{class:"flex md:flex-row flex-col"},t.speedList&&t.speedList.map((e,a)=>V(n("div",null,{class:"bg-white/80 grow m-2 rounded-2xl drop-shadow-2xl p-5 flex flex-row items-center justify-center gap-5"},[t.addIcons&&i(Ol,{class:"text-[#d20030]",[s]:{class:s}},3,"uc_0"),n("div",null,null,[n("h3",null,{class:"text-[#d20030] md:text-[28px] text-[22px] font-bold"},w(e,"Title"),1,null),i(j,{get text(){return e.Text},classN:"md:text-[25px] text-[18px]",[s]:{text:m(e,"Text"),classN:s}},3,"uc_1")],1,null),t.addIcons&&i(Ol,{class:"text-[#d20030]",[s]:{class:s}},3,"uc_2"),"                        "],1,a))),1,null),t.parData&&i(It,{color:"white",get title(){return t.parData.Title},get text(){return t.parData.Paragraph},get buttons(){return t.parData.Buttons},backgroundColor:"transparent",[s]:{color:s,title:u(e=>e.parData.Title,[t],'p0.parData["Title"]'),text:u(e=>e.parData.Paragraph,[t],'p0.parData["Paragraph"]'),buttons:u(e=>e.parData.Buttons,[t],'p0.parData["Buttons"]'),backgroundColor:s}},3,"uc_3")],1,null),1,"uc_4")),wl=b(f(Jx,"s_Fo7QUM6aBA8")),Zx=t=>n("div",null,{class:"flex md:flex-row flex-col-reverse w-full text-center items-center justify-center md:py-8 py-2"},i(It,{hasPricing:!1,reverse:!0,get text(){return t.parData.Paragraph},backgroundColor:"transparent",get title(){return t.parData.Title},get subtitle(){return t.parData.Subtitle},get image(){return t.parData.Media.data.attributes},get buttons(){return t.parData.Buttons},[s]:{hasPricing:s,reverse:s,text:u(e=>e.parData.Paragraph,[t],'p0.parData["Paragraph"]'),backgroundColor:s,title:u(e=>e.parData.Title,[t],'p0.parData["Title"]'),subtitle:u(e=>e.parData.Subtitle,[t],'p0.parData["Subtitle"]'),image:u(e=>e.parData.Media.data.attributes,[t],'p0.parData["Media"]["data"]["attributes"]'),buttons:u(e=>e.parData.Buttons,[t],'p0.parData["Buttons"]')}},3,"CM_0"),1,"CM_1"),Jn=b(f(Zx,"s_sknthmsoXlM")),Kx=t=>{const e=t.data.Logo.data.attributes;return n("div",null,{class:"min-h-screen w-full flex flex-col items-center"},[i(M,{width:"200px",media:e,clasN:"p-5",[s]:{width:s,clasN:s}},3,"of_0"),i(Yn,{get parData(){return t.data.SectionHead},[s]:{parData:u(a=>a.data.SectionHead,[t],'p0.data["SectionHead"]')}},3,"of_1"),i(wl,{get parData(){return t.data.SectionSpeed},get speedList(){return t.data.SpeedBullets},[s]:{parData:u(a=>a.data.SectionSpeed,[t],'p0.data["SectionSpeed"]'),speedList:u(a=>a.data.SpeedBullets,[t],'p0.data["SpeedBullets"]')}},3,"of_2"),i(Jn,{get parData(){return t.data.SectionRating},[s]:{parData:u(a=>a.data.SectionRating,[t],'p0.data["SectionRating"]')}},3,"of_3"),n("div",null,{class:"w-full bg-white  flex md:flex-row flex-col items-center justify-between"},[n("div",null,{class:" flex flex-row gap-5 p-1"},t.data.Footer&&t.data.Footer.map((a,l)=>i(zt,{get href(){return a.Link},class:" hover:text-primary-blue/60 text-primary-blue font-bold",children:w(a,"Text"),[s]:{href:m(a,"Link"),class:s}},1,l)),1,null),n("div",null,{class:"text-primary-blue text-center"},"© 2024 Rural Telecommunications of America, Inc. All rights reserved.",3,null)],1,null)],1,"of_4")},Xx=b(f(Kx,"s_GHcg0KcOc4I")),tm=t=>`query QueryLPNeighbor {
        lpNeighbor (locale:"${t}"){    
          data{
            attributes{
              Logo{
                ${y}
              }

              SectionHead{
                Title
                Subtitle
                Paragraph
                Logo{
                    ${y}
                }
                Media{
                    ${y}
                }
                Buttons{
                  Text
                  Link
                }
              }

              SpeedBullets{
                Title
                Text
              }

              SectionSpeed{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }

              SectionRating{
                Title
                Subtitle
                Paragraph
                Buttons{
                  Text
                  Link
                }
                Media{
                    ${y}
                }
              }
              
              Footer{
                Text
                Link
              }
            ${z}
            }
          }
        }
        
      }`,em=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(tm,e)},Zn=q(f(em,"s_yFRGQ10fxJ8")),am=()=>{const t=Zn();return i(G,{children:i(F,{get data(){return t.value.layoutData},showMenus:!1,showHeader:!1,children:i(Xx,{get data(){return t.value.pageData.data.lpNeighbor.data.attributes},[s]:{data:u(e=>e.value.pageData.data.lpNeighbor.data.attributes,[t],'p0.value["pageData"]["data"]["lpNeighbor"]["data"]["attributes"]')}},3,"kh_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showMenus:s,showHeader:s}},1,"kh_1")},1,"kh_2")},lm=b(f(am,"s_goRTr5J9aTM")),nm=({resolveValue:t})=>{const a=t(Zn).pageData.data.lpNeighbor.data.attributes.SEO;return H(a)},sm=Object.freeze(Object.defineProperty({__proto__:null,default:lm,head:nm,usePageData:Zn},Symbol.toStringTag,{value:"Module"})),rm=t=>n("div",null,{class:"relative z-0 h-3/4 w-[250px] text-center items-center justify-center }"},[i(M,{clasN:"object-fill h-full w-full",get media(){return t.update.Picture.data.attributes},height:500,width:250,[s]:{clasN:s,media:u(e=>e.update.Picture.data.attributes,[t],'p0.update["Picture"]["data"]["attributes"]'),height:s,width:s}},3,"2q_0"),n("a",null,{href:u(e=>e.update.Link,[t],'p0.update["Link"]')},n("div",null,{class:"absolute flex items-center justify-center flex-col inset-0 w-full h-full bg-black bg-opacity-30 text-white"},[n("h2",null,{class:"text-2xl font-semibold"},u(e=>e.update.Title,[t],'p0.update["Title"]'),3,null),n("p",null,{class:"text-xl"},u(e=>e.update.Subtitle,[t],'p0.update["Subtitle"]'),3,null)],3,null),3,null)],1,"2q_1"),im=t=>{const e=b(f(rm,"s_SjfOqPww0ks")),a=t.carouselData.map((l,r)=>i(e,{update:l},3,r));return n("div",null,{class:"flex w-full items-center justify-center"},n("div",null,{class:"flex flex-row max-w-[1200px] items-center justify-center max-[800px]:flex-col h-full"},[n("h2",null,{class:"text-center p-5 text-4xl font-bold text-primary-blue max-[800px]:w-[40%]"},u(l=>l.title,[t],"p0.title"),3,null),n("div",null,{class:"h-fit w-[60%] flex items-center justify-center "},i(kt,{slides:a,fillSlide:!0,addSpace:!1,id:"updatesSlider",hasPagination:!1,[s]:{fillSlide:s,addSpace:s,id:s,hasPagination:s}},3,"2q_2"),1,null)],1,null),1,"2q_3")},om=b(f(im,"s_kpGwS0aQJPs")),um=t=>n("iframe",null,{src:u(e=>`https://www.youtube.com/embed/${e.ytURL.split("v=")[1]}`,[t],'`https://www.youtube.com/embed/${p0.ytURL.split("v=")[1]}`'),class:u(e=>`h-full w-full ${e.classN}`,[t],"`h-full w-full ${p0.classN}`"),frameBorder:"0",allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",allowFullscreen:!0},null,3,"Fj_0"),rl=b(f(um,"s_jekwDGWyuec")),cm=t=>n("div",null,{class:"flex flex-col lg:flex-row w-full px-10 items-center justify-center my-8"},[n("div",null,{class:"flex flex-col w-full lg:w-1/3 h-full text-center lg:text-end justify-evenly mr-4 my-4"},[n("h2",null,{class:"text-2xl font-semibold text-secondary-red"},u(e=>e.data.FeatInterview.Title,[t],'p0.data["FeatInterview"]["Title"]'),3,null),n("h3",null,{class:"text-2xl font-[350] text-primary-blue"},u(e=>e.data.FeatInterview.Subtitle,[t],'p0.data["FeatInterview"]["Subtitle"]'),3,null),i(j,{classN:"my-8 ml-4",get text(){return t.data.FeatInterview.Paragraph},[s]:{classN:s,text:u(e=>e.data.FeatInterview.Paragraph,[t],'p0.data["FeatInterview"]["Paragraph"]')}},3,"RS_0"),n("div",null,{class:"flex justify-center lg:justify-end"},n("a",null,{class:"text-end",href:u(e=>e.data.FeatInterview.Buttons[0].Link,[t],'p0.data["FeatInterview"]["Buttons"][0]["Link"]')},n("div",null,{class:"flex px-4 w-fit py-2 justify-evenly items-center rounded-2xl border-2 border-primary-blue"},[i(ig,{class:"fill-secondary-red mr-4 h-full",[s]:{class:s}},3,"RS_1"),n("p",null,null,u(e=>e.data.FeatInterview.Buttons[0].Text,[t],'p0.data["FeatInterview"]["Buttons"][0]["Text"]'),3,null)],1,null),1,null),1,null)],1,null),n("div",null,null,i(rl,{get ytURL(){return t.data.FeatVideo},classN:"rounded-2xl w-[460px] md:w-[530px] md:h-[350px] m-8",[s]:{ytURL:u(e=>e.data.FeatVideo,[t],'p0.data["FeatVideo"]'),classN:s}},3,"RS_2"),1,null)],1,"RS_3"),dm=b(f(cm,"s_liBh70ErorA")),pm={url:"/uploads/youtube_67497ef97d.svg",alternativeText:"A vector of Youtube logo",caption:"Youtube logo icon | RTA"},gm=t=>{const e=t.data.map((a,l)=>n("div",null,{class:"relative z-0 w-350 h-150 rounded-2xl"},[i(M,{clasN:"rounded-2xl",get media(){return a.Picture.data.attributes},width:350,height:150,[s]:{clasN:s,media:m(a.Picture.data,"attributes"),width:s,height:s}},3,"zz_0"),n("a",{href:w(a,"Link")},{class:"absolute inset-0 h-full w-full flex items-center justify-center"},i(M,{get media(){return pm},toWhite:!0,height:50,width:50,[s]:{media:s,toWhite:s,height:s,width:s}},3,"zz_1"),1,null)],1,l));return n("div",null,{class:"w-full flex items-center justify-center"},i(kt,{slides:e,id:"InterviewCarousel",duration:5e3,hasPagination:!1,[s]:{id:s,duration:s,hasPagination:s}},3,"zz_2"),1,"zz_3")},fm=b(f(gm,"s_w6lTa7I5NZ4")),xm=t=>n("div",null,null,[i(Ke,{get data(){return t.data.Introduction},hasPricing:!1,alt:!0,reverse:!0,[s]:{data:u(e=>e.data.Introduction,[t],'p0.data["Introduction"]'),hasPricing:s,alt:s,reverse:s}},3,"NM_0"),i(om,{get title(){return t.data.UpdatesTitle},get carouselData(){return t.data.UpdatesCarousel},[s]:{title:u(e=>e.data.UpdatesTitle,[t],'p0.data["UpdatesTitle"]'),carouselData:u(e=>e.data.UpdatesCarousel,[t],'p0.data["UpdatesCarousel"]')}},3,"NM_1"),i(dm,{get data(){return t.data},[s]:{data:u(e=>e.data,[t],"p0.data")}},3,"NM_2"),i(fm,{get data(){return t.data.Interviews},[s]:{data:u(e=>e.data.Interviews,[t],'p0.data["Interviews"]')}},3,"NM_3")],1,"NM_4"),mm=b(f(xm,"s_bPCxBsh3t6w")),hm=t=>`query queryGfsn{
        pageGfSports(locale:"${t}"){
          data{
            attributes{
              
              Introduction{
                Title
                Subtitle
                Paragraph
                Media{
                 ${y}
                }
               
              }
              
              UpdatesTitle
              
              UpdatesCarousel{
                Picture{
                  ${y}
                }
                Link
                Title
                Subtitle
              }
              
              FeatInterview{
                Title
                Subtitle
                Paragraph
                
                Buttons{
                  Text
                  Link
                  Icon{
                    ${y}
                  }
                }
              }
              
              
              FeatVideo
              
              Interviews{
                Picture{
                  ${y}
                }
                Link
                Title
              }
              ${z}
            }
          }
        }
      }`,bm=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(hm,e)},Kn=q(f(bm,"s_BZfivgZf0o0")),$m=()=>{const t=Kn();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGfSports.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfSports.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfSports"]["data"]["attributes"]["SEO"]')}},3,"7u_0"),i(mm,{get data(){return t.value.pageData.data.pageGfSports.data.attributes},[s]:{data:u(e=>e.value.pageData.data.pageGfSports.data.attributes,[t],'p0.value["pageData"]["data"]["pageGfSports"]["data"]["attributes"]')}},3,"7u_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"7u_2")},1,"7u_3")},ym=b(f($m,"s_KZzsv9nZPuQ")),vm=({resolveValue:t})=>{const a=t(Kn).pageData.data.pageGfSports.data.attributes.SEO;return H(a)},_m=Object.freeze(Object.defineProperty({__proto__:null,default:ym,head:vm,usePageData:Kn},Symbol.toStringTag,{value:"Module"})),wm=t=>{const e=t.data.pageGfCloud.data.attributes,a=t.data.sectionNetwork.data.attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(M,{get media(){return e.GNetworkLogo.data.attributes},width:500,height:95,[s]:{media:m(e.GNetworkLogo.data,"attributes"),width:s,height:s}},3,"JJ_0"),n("div",null,{class:"flex flex-wrap-reverse px-8 py-6 items-center justify-center"},[n("div",null,{class:"h-[450px] w-full md:w-1/2"},i(M,{get media(){return a.Map.MapPicture.data.attributes},width:500,height:490,[s]:{media:m(a.Map.MapPicture.data,"attributes"),width:s,height:s}},3,"JJ_1"),1,null),n("div",null,{class:"flex flex-col w-full md:w-1/2 items-center justify-center"},[i(j,{get text(){return a.Description.Paragraph},classN:"text-primary-blue",[s]:{text:m(a.Description,"Paragraph"),classN:s}},3,"JJ_2"),i(xa,{get title(){return a.Map.ServersTitle},classContainer:"rounded-full bg-white text-primary-blue shadow-xl",children:n("div",null,{class:"flex flex-col py-4 text-primary-blue bg-white rounded-b-2xl"},a.Map.Servers.map((l,r)=>n("a",{href:w(l,"Link")},{class:"hover:text-secondary-red text-primary-blue"},w(l,"Text"),1,r)),1,null),[s]:{title:m(a.Map,"ServersTitle"),classContainer:s}},1,"JJ_3")],1,null)],1,null),i(It,{get title(){return e.GFCloud.Title},get text(){return e.GFCloud.Paragraph},get image(){return e.GFCloud.Media.data.attributes},get logo(){return e.GFCloud.Logo.data.attributes},get buttons(){return e.GFCloud.Buttons},[s]:{title:m(e.GFCloud,"Title"),text:m(e.GFCloud,"Paragraph"),image:m(e.GFCloud.Media.data,"attributes"),logo:m(e.GFCloud.Logo.data,"attributes"),buttons:m(e.GFCloud,"Buttons")}},3,"JJ_4")],1,"JJ_5")},Sm=b(f(wm,"s_ee4CXUkPYJQ")),Tm=t=>`query QueryGFCloud {
        pageGfCloud (locale:"${t}"){    
          data{
            attributes{
              GNetworkLogo{
                ${y}
              }
            GFCloud{
              Title
              Logo{
                ${y}
              }
              Paragraph
              Media{
                ${y}
              }
              Buttons{
                Text
                Link
              }
            }
              
            ${z}
            }
          }
        }
        sectionNetwork (locale:"${t}"){
          data {
            attributes {
              Map {
                MapPicture {
                  ${y}
                }
                ServersTitle
                Servers (pagination:{limit:50}){
                  Text
                  Link
                  Icon{
                    ${y}
                  }
                }
              }
              Description{
                Title
                Paragraph
              }
            }
          }
        }
      }`,Dm=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Tm,e)},Xn=q(f(Dm,"s_imQl8eEcDG0")),Pm=()=>{const t=Xn(),e=t.value.pageData.data;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGfCloud.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageGfCloud.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfCloud"]["data"]["attributes"]["SEO"]')}},3,"Fb_0"),i(Sm,{data:e},3,"Fb_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Fb_2")},1,"Fb_3")},km=b(f(Pm,"s_8q0wwtngnhI")),Lm=({resolveValue:t})=>{const a=t(Xn).pageData.data.pageGfCloud.data.attributes.SEO;return H(a)},Cm=Object.freeze(Object.defineProperty({__proto__:null,default:km,head:Lm,usePageData:Xn},Symbol.toStringTag,{value:"Module"})),Mm=t=>n("div",null,{class:"flex w-full flex-col items-center justify-center gap-3 rounded-xl bg-white p-8 shadow-xl"},[n("div",null,{class:"w-fit rounded-full bg-secondary-red p-2"},i(M,{get media(){return t.tip.Icon.data.attributes},width:17,height:17,toWhite:!0,[s]:{media:u(e=>e.tip.Icon.data.attributes,[t],'p0.tip["Icon"]["data"]["attributes"]'),width:s,height:s,toWhite:s}},3,"Ie_0"),1,null),n("h4",null,{class:"text-center font-[700] text-primary-blue"},u(e=>e.tip.Title,[t],'p0.tip["Title"]'),3,null),i(j,{classN:"text-[14px] font-[500]",get text(){return t.tip.Text},[s]:{classN:s,text:u(e=>e.tip.Text,[t],'p0.tip["Text"]')}},3,"Ie_1")],1,t.tip.Title),jm=t=>{const e=b(f(Mm,"s_YpuX8PZv7fg"));return n("div",null,{class:"mt-6 flex w-full max-w-[1200px] flex-col items-center justify-center gap-4 p-8"},[n("h2",null,{class:"text-center text-[40px] font-[500] text-primary-blue"},u(a=>a.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"grid w-full grid-cols-3 gap-4  max-[800px]:grid-cols-1"},t.data.Bullets.slice(0,3).map((a,l)=>i(e,{tip:a},3,l)),1,null),n("div",null,{class:"grid w-full grid-cols-2 gap-4 max-[800px]:grid-cols-1"},t.data.Bullets.slice(3,5).map((a,l)=>i(e,{tip:a},3,l)),1,null)],1,"Ie_2")},Im=b(f(jm,"s_0W2ahleMHpc")),Em=t=>i(G,{children:t.data.map((e,a)=>i(Ke,{data:e,reverse:a%2===1,textPercentage:60,[s]:{textPercentage:s}},3,a))},1,"mL_0"),Nm=b(f(Em,"s_GQ2BMpdgaAM")),Bm=t=>n("div",null,{class:"relative flex h-full w-full items-center justify-center overflow-hidden"},[!(t.isFirst??!1)&&n("div",null,{class:"absolute bottom-[calc(50%+20px)] top-0 border-l-2 border-secondary-red"},null,3,"9r_0"),!(t.isLast??!1)&&n("div",null,{class:"absolute bottom-0 top-[calc(50%+20px)] border-l-2 border-secondary-red"},null,3,"9r_1"),n("div",null,{class:"flex h-[36px] w-[36px] items-center justify-center self-center rounded-full border border-secondary-red bg-transparent"},n("div",null,{class:"flex h-[30px] w-[30px] items-center justify-center rounded-full bg-secondary-red text-white"},u(e=>e.caption,[t],"p0.caption"),3,null),3,null)],1,"9r_2"),Am=t=>{const e=b(f(Bm,"s_2AZJZ0GqJyo"));return(t.direction??"vertical")==="vertical"?n("div",null,{class:"grid w-fit items-center justify-around",style:u(a=>({gridTemplateColumns:(a.align??"start")==="center"?"1fr 60px 1fr":(a.align??"start")==="end"?"1fr 60px":"60px 1fr"}),[t],'{gridTemplateColumns:(p0.align??"start")==="center"?"1fr 60px 1fr":(p0.align??"start")==="end"?"1fr 60px":"60px 1fr"}')},t.steps.map((a,l)=>V(i(G,{children:[(t.align??"start")!=="center"&&i(G,{children:[(t.align??"start")==="start"&&i(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_3"),n("div",null,{class:u(r=>`my-[20px] ${(r.align??"start")==="end"&&"ml-auto"} flex w-full flex-row items-center justify-center rounded-[50px] bg-white p-6 shadow-xl`,[t],'`my-[20px] ${(p0.align??"start")==="end"&&"ml-auto"} flex w-full flex-row items-center justify-center rounded-[50px] bg-white p-6 shadow-xl`')},i(j,{classN:"text-center",text:a,[s]:{classN:s}},3,"9r_4"),1,l),(t.align??"start")==="end"&&i(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_5")]},1,"9r_6"),(t.align??"start")==="center"&&i(G,{children:[n("div",null,{class:"flex w-fit flex-row items-center rounded-[50px] bg-white px-6 py-10 shadow-lg"},i(j,{classN:"text-center",text:a,[s]:{classN:s}},3,"9r_7"),1,l),l%2===0?i(G,{children:[i(e,{caption:(l+1).toString(),isFirst:l===0,isLast:l===t.steps.length-1},3,"9r_8"),n("div",null,null,null,3,null),n("div",null,null,null,3,null),l+1<t.steps.length&&i(e,{caption:(l+2).toString(),isLast:l===t.steps.length},3,"9r_9")]},1,"9r_10"):i(G,null,3,"9r_11")]},1,"9r_12")]},1,"9r_13"))),1,"9r_14"):n("div",null,{class:"flex flex-row justify-between"},t.steps.map((a,l)=>n("div",null,{class:"flex flex-col items-center"},[n("div",null,{class:"h-2 w-2 rounded-full bg-primary-blue"},null,3,null),n("div",null,{class:"text-primary-blue"},a,1,null)],1,l)),1,null)},il=b(f(Am,"s_Zd6X64AupUo")),Om=t=>{const e=t.data.pageGfIS.data.attributes;let a="";return e.WiFiListing.Bullets.forEach(l=>{a+="- "+l.Text+`
`}),n("div",null,{class:"flex w-full flex-col items-center justify-center",onClick$:O("s_wLQQzX3cS04")},[n("h1",null,{class:"max-w-[800px] px-8 text-center text-[42px] font-[600] text-primary-blue max-[600px]:text-[32px]"},w(e.Introduction,"Paragraph"),1,null),i(Im,{get data(){return e.Tips},[s]:{data:m(e,"Tips")}},3,"5A_0"),i(Nm,{get data(){return e.InternetInfo},[s]:{data:m(e,"InternetInfo")}},3,"5A_1"),n("div",null,{class:"flex max-w-[1200px] items-start justify-center gap-4 p-8 max-[800px]:flex-col"},[n("p",null,{class:"w-[60%] text-[15px] text-primary-blue max-[800px]:w-full"},w(e.InternetExample[0],"Text"),1,null),n("p",null,{class:"w-[40%] text-[15px] font-[600] text-primary-blue max-[800px]:w-full"},w(e.InternetExample[1],"Text"),1,null)],1,null),i(It,{get title(){return e.WiFiListing.Title},text:a,get image(){return e.WiFiPicture.data.attributes},textPercentage:50,reverse:!0,[s]:{title:m(e.WiFiListing,"Title"),image:m(e.WiFiPicture.data,"attributes"),textPercentage:s,reverse:s}},3,"5A_2"),i(Ke,{get data(){return e.TestPar},textPercentage:60,[s]:{data:m(e,"TestPar"),textPercentage:s}},3,"5A_3"),i(il,{steps:e.TestStepss.map(l=>"**"+l.Title+`**

`+l.Text)},3,"5A_4"),i(It,{get text(){return e.TestGlossary.Paragraph},get image(){return e.TestGlossary.Media.data.attributes},textPercentage:60,[s]:{text:m(e.TestGlossary,"Paragraph"),image:m(e.TestGlossary.Media.data,"attributes"),textPercentage:s}},3,"5A_5"),n("h3",null,{class:"text-[40px] font-[600] text-primary-blue"},w(e.TroubleSteps,"Title"),1,null),n("p",null,{class:"my-4 text-primary-blue"},w(e,"TroubleDescription"),1,null),n("div",null,{class:"max-w-[1200px]  px-8"},i(il,{steps:e.TroubleSteps.Bullets.map(l=>l.Title?"**"+l.Title+`**
`+l.Text.replaceAll(`

`,`
`):"**"+l.Text.replaceAll(`

`,`
`)+"**")},3,"5A_6"),1,null)],1,"5A_7")},Rm=b(f(Om,"s_DlDfET88Hb4")),qm=t=>`query {
    pageGfIS(locale:"${t}") {
      data {
        attributes {
          Introduction {
            Paragraph
            Media {
              ${y}
            }
          }
          Tips {
            Title
            Bullets {
              Title
              Text
              Icon {
               ${y}
              }
            }
          }
          InternetInfo {
            Title
            Paragraph
            Media {
              ${y}
            }
          }
          InternetExample {
            Text
          }
          WiFiPicture {
           ${y}
          }
          WiFiListing {
            Title
            Bullets {
              Title
              Text
            }
          }
          TestPar{
            Title
            Paragraph
            Media{
              ${y}
            }
          }
          TestStepss{
            Title
            Text
          }
          TestGlossary {
            Paragraph
            Media {
              ${y}
            }
          }
          TroubleSteps {
            Title
            Bullets {
              Title
              Text
            }
          }
          TroubleDescription
          ${z}
  
        }
      }
    }
  }`,Fm=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(qm,e)},ts=q(f(Fm,"s_YTLZ80iXjpk")),zm=()=>{const t=ts();return i(F,{get data(){return t.value.layoutData},children:i(Rm,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"0g_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"0g_1")},Qm=b(f(zm,"s_sPmm4Hp5SbY")),Gm=({resolveValue:t})=>{const a=t(ts).pageData.data.pageGfIS.data.attributes.SEO;return H(a)},Hm=Object.freeze(Object.defineProperty({__proto__:null,default:Qm,head:Gm,usePageData:ts},Symbol.toStringTag,{value:"Module"})),Vm=t=>(V(),n("div",null,{class:"flex min-h-[600px] w-fit max-w-[300px] flex-col items-center justify-between rounded-[35px] bg-white px-5"},[n("div",null,{class:"mt-8 flex w-fit max-w-full flex-col items-center self-center"},[t.isFullLogo??!1?n("div",null,{class:"flex flex-col justify-center items-center self-center gap-2 "},[i(M,{get media(){return t.logo},height:100,width:300,clasN:" w-full  overflow-hidden object-center",[s]:{media:u(e=>e.logo,[t],"p0.logo"),height:s,width:s,clasN:s}},3,"0s_0"),n("div",null,{class:" text-2xl font-bold leading-6 text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null)],1,"0s_1"):n("div",null,{class:"flex w-full items-start gap-5 self-center"},[i(M,{get media(){return t.logo},height:100,width:100,clasN:"aspect-square w-[70px] max-w-full items-center justify-center self-stretch overflow-hidden object-contain object-center",[s]:{media:u(e=>e.logo,[t],"p0.logo"),height:s,width:s,clasN:s}},3,"0s_2"),n("div",null,{class:"my-auto flex flex-col self-center"},n("div",null,{class:"self-start whitespace-nowrap text-2xl font-bold leading-6 text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),3,null)],1,null),t.price&&t.priceTime&&n("div",null,{class:"mt-2 text-center text-base leading-4 tracking-tighter text-primary-blue"},[n("span",null,{class:"text-2xl font-light text-secondary-red"},"$",3,null),n("span",null,{class:"text-2xl font-light text-primary-blue"},u(e=>e.price,[t],"p0.price"),3,null),n("span",null,{class:" text-2xl text-primary-blue"},u(e=>e.priceTime,[t],"p0.priceTime"),3,null)],3,"0s_3"),n("div",null,{class:"mt-5 text-center text-base text-primary-blue"},i(j,{get text(){return t.description},[s]:{text:u(e=>e.description,[t],"p0.description")}},3,"0s_4"),1,null),n("div",null,{class:"border-gary-500 my-4 h-[1px] w-full border-t-2"},null,3,null),n("div",null,{class:"mt-5 text-base text-primary-blue"},t.features.map((e,a)=>n("span",null,{class:"my-1 flex flex-row items-center justify-start"},[n("div",null,null,i(Ri,{class:"mx-2 h-[20px] w-[20px] fill-primary-blue text-primary-blue",[s]:{class:s}},3,"0s_5"),1,null),n("h3",null,{class:"text-sm font-light"},w(e,"Text"),1,a)],1,a)),1,null)],1,null),n("div",null,{class:"my-4 flex h-[80px] w-full flex-col items-center justify-center"},[n("div",null,{class:"border-gary-500 my-4 h-[1px] w-full border-t-2"},null,3,null),i(K,{get text(){return t.btnText},get link(){return t.btnLink},[s]:{text:u(e=>e.btnText,[t],"p0.btnText"),link:u(e=>e.btnLink,[t],"p0.btnLink")}},3,"0s_6")],1,null)],1,"0s_7")),es=b(f(Vm,"s_Ttt0gCfGtkU")),Wm=t=>n("div",null,{class:"flex flex-col items-center justify-around"},[n("div",null,{class:"mx-4 my-8 max-w-[500px]"},i(M,{get media(){return t.data.Logo.data.attributes},width:1230,height:229,[s]:{media:u(e=>e.data.Logo.data.attributes,[t],'p0.data["Logo"]["data"]["attributes"]'),width:s,height:s}},3,"6h_0"),1,null),n("div",null,{class:"mx-10 my-4 flex max-w-[800px] flex-col items-center justify-center gap-2 text-primary-blue"},[n("span",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(e=>e.data.Introduction.Title,[t],'p0.data["Introduction"]["Title"]'),3,null),i(j,{classN:"text-center",get text(){return t.data.Introduction.Paragraph},[s]:{classN:s,text:u(e=>e.data.Introduction.Paragraph,[t],'p0.data["Introduction"]["Paragraph"]')}},3,"6h_1"),i(K,{get text(){return t.data.Introduction.Buttons[0].Text},get link(){return t.data.Introduction.Buttons[0].Link},[s]:{text:u(e=>e.data.Introduction.Buttons[0].Text,[t],'p0.data["Introduction"]["Buttons"][0]["Text"]'),link:u(e=>e.data.Introduction.Buttons[0].Link,[t],'p0.data["Introduction"]["Buttons"][0]["Link"]')}},3,"6h_2")],1,null),n("div",null,{class:"flex flex-wrap gap-10 justify-center mx-4 my-8 items-start"},t.data.PackTables.map((e,a)=>i(es,{get title(){return e.Title},get logo(){return e.Logo.data.attributes},get description(){return e.Description},get features(){return e.Features},get btnLink(){return e.Button.Link},get btnText(){return e.Button.Text},[s]:{title:m(e,"Title"),logo:m(e.Logo.data,"attributes"),description:m(e,"Description"),features:m(e,"Features"),btnLink:m(e.Button,"Link"),btnText:m(e.Button,"Text")}},3,a)),1,null),i(K,{get text(){return t.data.ButtonConfig.Text},get link(){return t.data.ButtonConfig.Link},[s]:{text:u(e=>e.data.ButtonConfig.Text,[t],'p0.data["ButtonConfig"]["Text"]'),link:u(e=>e.data.ButtonConfig.Link,[t],'p0.data["ButtonConfig"]["Link"]')}},3,"6h_3"),i(j,{classN:"text-primary-blue text-center mx-4 my-8",get text(){return t.data.Disclaimer},[s]:{classN:s,text:u(e=>e.data.Disclaimer,[t],'p0.data["Disclaimer"]')}},3,"6h_4"),i(It,{get text(){return t.data.GFInternetSupport.Paragraph},get title(){return t.data.GFInternetSupport.Title},get logo(){return t.data.GFInternetSupport.Logo.data.attributes},get buttons(){return t.data.GFInternetSupport.Buttons},get image(){return t.data.GFInternetSupport.Media.data.attributes},[s]:{text:u(e=>e.data.GFInternetSupport.Paragraph,[t],'p0.data["GFInternetSupport"]["Paragraph"]'),title:u(e=>e.data.GFInternetSupport.Title,[t],'p0.data["GFInternetSupport"]["Title"]'),logo:u(e=>e.data.GFInternetSupport.Logo.data.attributes,[t],'p0.data["GFInternetSupport"]["Logo"]["data"]["attributes"]'),buttons:u(e=>e.data.GFInternetSupport.Buttons,[t],'p0.data["GFInternetSupport"]["Buttons"]'),image:u(e=>e.data.GFInternetSupport.Media.data.attributes,[t],'p0.data["GFInternetSupport"]["Media"]["data"]["attributes"]')}},3,"6h_5")],1,"6h_6"),Um=b(f(Wm,"s_30f4iq1HkIo")),Ym=t=>`query QueryGFInternet {
        pageGfInternet(locale:"${t}"){
          data {
            attributes {
              Logo {
                ${y}
              }
              Introduction {
                Paragraph
                Buttons {
                  Text
                  Link
                }
              }
              PackTables {
                Logo {
                  ${y}
                }
                Title
                Subtitle
                Price
                Pricetime
                Description
                Features {
                  Text
                  Title
                }
                Button {
                  Link
                  Text
                }
              }
              Disclaimer
              ButtonConfig{
                Text
                Link
              }
              GFInternetSupport {
                Title
                Subtitle
                Paragraph
                Logo {
                  ${y}
                }
                Media {
                  ${y}
                }
                Buttons {
                  Text
                  Link
                }
              }
              ${z}
            }
          }
        }
      }
      `,Jm=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Ym,e)},as=q(f(Jm,"s_PG6JGbvGdSU")),Zm=()=>{const t=as(),e=t.value.pageData.data.pageGfInternet.data.attributes;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGfInternet.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageGfInternet.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfInternet"]["data"]["attributes"]["SEO"]')}},3,"TH_0"),i(Um,{data:e},3,"TH_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"TH_2")},1,"TH_3")},Km=b(f(Zm,"s_cj0XMKyWnnQ")),Xm=({resolveValue:t})=>{const a=t(as).pageData.data.pageGfInternet.data.attributes.SEO;return H(a)},th=Object.freeze(Object.defineProperty({__proto__:null,default:Km,head:Xm,usePageData:as},Symbol.toStringTag,{value:"Module"})),eh=t=>{const e=t.data.pageGfIoT.data.attributes.Services,a=t.data.pageGfIoT.data.attributes.Introduction,l=t.data.pageGfIoT.data.attributes.Logo.data.attributes,r=t.data.pageGfIoT.data.attributes.WeatherAnounce;return n("div",null,{class:"flex flex-col items-center justify-center "},[n("div",null,{class:"m-4 flex items-center justify-center gap-4 rounded-full bg-[#edf6ff] px-8 py-5 shadow-xl max-sm:flex-col"},[n("span",null,{class:"text-center text-[18px] font-[600] text-primary-blue max-md:text-[14px]"},w(r,"Paragraph"),1,null),i(K,{get text(){return r.Buttons[0].Text},get link(){return r.Buttons[0].Link},[s]:{text:m(r.Buttons[0],"Text"),link:m(r.Buttons[0],"Link")}},3,"Ws_0")],1,null),n("div",null,{class:"mx-4 my-8 max-w-[500px]"},i(M,{media:l,width:1230,height:229,[s]:{width:s,height:s}},3,"Ws_1"),1,null),n("div",null,{class:"mx-10 my-4 flex max-w-[800px] flex-col items-center justify-center gap-2 text-primary-blue"},[n("span",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},w(a,"Title"),1,null),i(j,{classN:"text-justify",get text(){return a.Paragraph},[s]:{classN:s,text:m(a,"Paragraph")}},3,"Ws_2")],1,null),i(Xe,{data:e},3,"Ws_3")],1,"Ws_4")},ah=b(f(eh,"s_1kXwT2q88rA")),lh=t=>`
  query QueryGFIoT {
    pageGfIoT(locale:"${t}"){
      data{
        attributes{
          Logo{
            ${y}
          }
          
          Introduction{
            Title
            Paragraph
          }
          
          WeatherAnounce{
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
          
          Services{
            Logo{
             ${y}
            }
            Title
            Paragraph
            Media{
             ${y}
            }
            Buttons{
              Text
              Link
            }
          }
          ${z}
        }
      }
    }
  }
    `,nh=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(lh,e)},ls=q(f(nh,"s_2v03ITQBdcI")),sh=()=>{const t=ls();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGfIoT.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfIoT.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfIoT"]["data"]["attributes"]["SEO"]')}},3,"Mz_0"),i(ah,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Mz_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Mz_2")},rh=b(f(sh,"s_teV3ya9bjBI")),ih=({resolveValue:t})=>{const a=t(ls).pageData.data.pageGfIoT.data.attributes.SEO;return H(a)},oh=Object.freeze(Object.defineProperty({__proto__:null,default:rh,head:ih,usePageData:ls},Symbol.toStringTag,{value:"Module"})),uh=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(j,{get text(){return t.data.TextContent},classN:"markdownTitle markdownh3 markdownHyper text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"Wt_0")],1,"Wt_1"),ch=b(f(uh,"s_wAqfRFn86VY")),dh=t=>`query QuerygftvPrivacyP {
        pageGfTvPp(locale:"${t}"){    
          ${fa}
          ${z}
            }
          }
        }
      }`,ph=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(dh,e)},ns=q(f(ph,"s_o03PAaBI278")),gh=()=>{const t=ns(),e=t.value.pageData.data.pageGfTvPp.data.attributes.Content;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(ch,{data:e},3,"zG_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"zG_1")},1,"zG_2")},fh=b(f(gh,"s_0UMSXuOQgCA")),xh=({resolveValue:t})=>{const a=t(ns).pageData.data.pageGfTvPp.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},mh=Object.freeze(Object.defineProperty({__proto__:null,default:fh,head:xh,usePageData:ns},Symbol.toStringTag,{value:"Module"})),hh=async(t,e)=>{const a=ft(t);try{const l=await fetch(a);if(!l.ok)throw new Error(`Error al descargar el archivo desde ${a}. Estado: ${l.status}`);const r=await l.arrayBuffer(),o=new Blob([r],{type:"application/pdf"}),c=window.URL.createObjectURL(o),p=document.createElement("a");p.href=c,p.download=e,p.click(),window.URL.revokeObjectURL(c)}catch(l){console.error(l)}},Yi=f(hh,"s_Vd02rPSFNlY"),bh=()=>{const[t]=tt();Yi(t.urlDoc,t.nameDoc)},$h=t=>{const e=f(bh,"s_L0UgBFqZ3XI",[t]);return n("div",null,{class:"flex flex-col h-[250px] w-[300px] bg-white shadow-2xl rounded-3xl justify-evenly items-center p-4"},[n("h3",null,{class:"text-2xl flex text-center font-bold text-[#2E5899]"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex w-fit items-center font-semibold justify-center gap-2 rounded-full border-2 border-teal-500 bg-white p-1 px-7 text-btn-green opacity-80 shadow-md transition-all hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:e},n("div",null,{class:"flex flex-row gap-2 items-center font-semibold text-center justify-center"},[u(a=>a.btnText,[t],"p0.btnText"),n("div",null,{class:"h-[25px] w-[25px] flex items-center justify-center font-bold text-white bg-teal-500 hover:text-teal-500 hover:bg-white rounded-full"},i(qi,{class:"stroke-current",[s]:{class:s}},3,"h5_0"),1,null)],1,null),1,null)],1,"h5_1")},Ji=b(f($h,"s_tF7T0UXX4O0")),yh=()=>{const[t]=tt();Yi(t.urlDoc,t.nameDoc)},vh=t=>{const e=f(yh,"s_8SKPRTg50C4",[t]);return n("div",null,{class:"h-[370px] w-[400px] py-8 px-4 bg-white rounded-2xl pb-2 flex flex-col items-center justify-between shadow-2xl"},[n("div",null,{class:"relative flex w-full overflow-hidden"},i(M,{clasN:"object-fill w-full h-full rounded-t-2xl",width:"2076",height:"1500",get media(){return t.image},[s]:{clasN:s,width:s,height:s,media:u(a=>a.image,[t],"p0.image")}},3,"d0_0"),1,null),n("h2",null,{class:"text-2xl flex text-center font-bold text-[#2E5899]"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex w-fit items-center font-semibold justify-center gap-2 rounded-full border-2 border-teal-500 bg-white p-1 text-btn-green opacity-80 shadow-md transition-all hover:cursor-pointer hover:border-transparent hover:bg-teal-500 hover:text-white",onClick$:e},n("div",null,{class:"flex flex-row gap-2 items-center font-semibold text-center justify-center"},[u(a=>a.btnText,[t],"p0.btnText"),n("div",null,{class:"h-[25px] w-[25px] flex items-center justify-center font-bold text-white bg-teal-500 hover:text-teal-500 hover:bg-white rounded-full"},i(qi,{class:"stroke-current",[s]:{class:s}},3,"d0_1"),1,null)],1,null),1,null)],1,"d0_2")},Zi=b(f(vh,"s_OdYDJRaDcFY")),_h=t=>{const e=t.data.pageGfTvS.data.attributes,a=t.data.sectionChGuide.data.attributes;return n("div",null,{class:"flex flex-col justify-center items-center"},[n("div",null,{class:"flex flex-col md:flex-row px-8 items-center justify-center gap-5"},[n("h1",null,{class:"text-2xl text-center font-semibold text-primary-blue"},w(e,"IntroText"),1,null),n("div",null,{class:"h-[150px] relative w-[350px] flex mb-14"},[n("video",{src:ft(e.IntroMedia.data[1].attributes.url)},{class:"absolute pt-2",autoplay:!0,loop:!0,muted:!0},null,3,null),i(M,{clasN:"absolute z-0",get media(){return e.IntroMedia.data[0].attributes},width:"1082",height:"786",[s]:{clasN:s,media:m(e.IntroMedia.data[0],"attributes"),width:s,height:s}},3,"yQ_0")],1,null)],1,null),n("div",null,{class:"flex my-20 w-full py-10 bg-primary-blue bg-opacity-40"},n("div",null,{class:"flex w-full py-10 bg-primary-blue bg-opacity-60"},n("div",null,{class:"flex w-full flex-col py-10 px-8 items-center justify-between bg-primary-blue bg-opacity-80"},[n("h2",null,{class:"font-bold text-3xl md:text-4xl my-5 text-white"},w(e,"DevicesTitle"),1,null),n("div",null,{class:"flex flex-wrap gap-5 items-center justify-center"},e.Devices.map((l,r)=>n("div",null,{class:"h-[300px] w-[300px] p-5 rounded-full bg-white bg-opacity-40"},n("div",null,{class:"h-full w-full p-5 rounded-full bg-white bg-opacity-60"},n("div",null,{class:"h-full w-full object-cover flex flex-col p-8 justify-center items-center rounded-full bg-white"},[n("h2",null,{class:"text-center font-semibold text-2xl text-primary-blue"},w(l,"Title"),1,null),i(j,{classN:"text-s text-primary-dark-blue",get text(){return l.Paragraph},[s]:{classN:s,text:m(l,"Paragraph")}},3,"yQ_1")],1,null),1,null),1,r)),1,null),n("p",null,{class:"text-center justify-end my-5 text-white"},w(e,"DevicesNote"),1,null)],1,null),1,null),1,null),n("div",null,{class:"flex flex-col justify-center px-8 items-center"},[n("div",null,{class:"w-full md:w-2/3 flex flex-col items-center"},[n("h2",null,{class:"text-3xl md:text-4xl text-center font-bold text-primary-blue"},w(e.GuidePar,"Title"),1,null),i(j,{classN:"text-center",get text(){return e.GuidePar.Paragraph},[s]:{classN:s,text:m(e.GuidePar,"Paragraph")}},3,"yQ_2")],1,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-10 my-5"},e.Guides.map((l,r)=>i(Ji,{get urlDoc(){return l.Guide.data.attributes.url},get title(){return l.Title},get btnText(){return l.BtnText},get nameDoc(){return l.Guide.data.attributes.name},[s]:{urlDoc:m(l.Guide.data.attributes,"url"),title:m(l,"Title"),btnText:m(l,"BtnText"),nameDoc:m(l.Guide.data.attributes,"name")}},3,r)),1,null)],1,null),n("div",null,{class:"flex w-full flex-col items-center justify-center"},n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex min-[800px]:w-[70%] flex-col items-center justify-center gap-4 px-10"},[n("div",null,{class:"max-w-[470px]"},i(M,{get media(){return a.Logo.data.attributes},width:"1230",height:"230",[s]:{media:m(a.Logo.data,"attributes"),width:s,height:s}},3,"yQ_3"),1,null),n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},w(a,"Title"),1,null),1,null),i(j,{get text(){return a.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{text:m(a,"Paragraph"),classN:s}},3,"yQ_4")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(Zi,{get nameDoc(){return a.GuideBox.Guide.data.attributes.name},get urlDoc(){return a.GuideBox.Guide.data.attributes.url},get image(){return a.Picture.data.attributes},get title(){return a.GuideBox.Title},get btnText(){return a.GuideBox.BtnText},[s]:{nameDoc:m(a.GuideBox.Guide.data.attributes,"name"),urlDoc:m(a.GuideBox.Guide.data.attributes,"url"),image:m(a.Picture.data,"attributes"),title:m(a.GuideBox,"Title"),btnText:m(a.GuideBox,"BtnText")}},3,"yQ_5"),1,null)],1,null),1,null)],1,"yQ_6")},wh=b(f(_h,"s_L3FZbhALRyo")),Sh=t=>`query gfTvSupport {
        pageGfTvS (locale:"${t}") {
          data {
            attributes {
              IntroText
              IntroMedia {
                ${y}
              }
              DevicesTitle
              Devices {
                Title
                Paragraph
                Buttons {
                  Text
                  Link
                }
              }
              DevicesNote
              GuidePar {
                Title
                Paragraph
              }
              Guides {
                Title
                BtnText
                Guide {
                  data {
                    attributes {
                      url
                      name
                    }
                  }
                }
              }
              ${z}
            }
          }
        }
        sectionChGuide{
          data{
            attributes{
              Logo{
                ${y}
              }
              Picture{
                ${y}
              }
              Title
              Paragraph
              GuideBox{
                Title
                BtnText
                Guide{
                  data{
                    attributes{
                      url
                      name
                    }
                  }
                }
              }
            }
          }
        }
      }
      `,Th=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Sh,e)},ss=q(f(Th,"s_Y5JMYQJnIpI")),Dh=()=>{const t=ss(),e=t.value.pageData.data;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(wh,{data:e},3,"GS_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"GS_1")},1,"GS_2")},Ph=b(f(Dh,"s_sZYBtsmoVg8")),kh=({resolveValue:t})=>{const a=t(ss).pageData.data.pageGfTvS.data.attributes.SEO;return H(a)},Lh=Object.freeze(Object.defineProperty({__proto__:null,default:Ph,head:kh,usePageData:ss},Symbol.toStringTag,{value:"Module"})),Ch=t=>n("div",null,{class:"gap-10 w-ful flex flex-col"},t.data.map((e,a)=>V(a%2==0?n("div",null,{class:"bg-primary-blue bg-opacity-40 py-10"},n("div",null,{class:"bg-primary-blue bg-opacity-60 py-10"},n("div",null,{class:"bg-primary-blue"},i(It,{color:"white",reverse:!0,get text(){return e.Paragraph},get image(){return e.Media.data.attributes},title:e.Title!=null?e.Title:"",textPercentage:50,backgroundColor:"primary-blue",[s]:{color:s,reverse:s,text:m(e,"Paragraph"),image:m(e.Media.data,"attributes"),textPercentage:s,backgroundColor:s}},3,a),1,null),1,null),1,a):i(It,{reverse:!1,get text(){return e.Paragraph},get image(){return e.Media.data.attributes},textPercentage:50,title:e.Title!=null?e.Title:"",[s]:{reverse:s,text:m(e,"Paragraph"),image:m(e.Media.data,"attributes"),textPercentage:s}},3,a))),1,"1n_0"),Mh=b(f(Ch,"s_3YkhEsBDjTI")),jh=t=>n("div",null,{class:"justify-between min-h-[670px] w-[300px] items-center shadow-lg bg-white flex flex-col px-5 pb-4 rounded-[35px]"},[n("div",null,{class:"items-center self-center flex w-[310px] max-w-full flex-col mt-8"},[n("div",null,{class:"items-start self-center flex w-full gap-5"},[i(M,{width:80,height:80,get media(){return t.logo},clasN:"aspect-square object-contain object-center w-[70px] justify-center items-center overflow-hidden self-stretch max-w-full",[s]:{width:s,height:s,media:u(e=>e.logo,[t],"p0.logo"),clasN:s}},3,"Tv_0"),n("div",null,{class:"self-center flex flex-col my-auto"},[n("div",null,{class:"text-blue-800 text-2xl font-bold leading-6 self-start whitespace-nowrap"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"justify-center text-rose-700 text-xl mt-2"},u(e=>e.subtitle,[t],"p0.subtitle"),3,null)],3,null)],1,null),n("div",null,{class:"text-blue-800 flex flex-row mt-5"},[n("span",null,{class:"font-light text-3xl text-rose-700"},"$",3,null),n("span",null,{class:"font-light text-3xl text-blue-800"},u(e=>e.price,[t],"p0.price"),3,null),n("span",null,{class:" text-blue-800"},["/",u(e=>e.priceTime,[t],"p0.priceTime")],3,null)],3,null),n("div",null,{class:"items-start self-stretch flex flex-col mt-5"},[n("div",null,{class:"justify-between items-start self-stretch flex w-full gap-5"},[n("div",null,{class:"text-blue-800 text-center text-base"},u(e=>e.description,[t],"p0.description"),3,null),i(sl,{get link(){return t.btnSeeMoreLink},get dataChannels(){return t.dataChannels},get planId(){return t.title},get channels(){return t.subtitle},get text(){return t.btnSeeMoreText},[s]:{link:u(e=>e.btnSeeMoreLink,[t],"p0.btnSeeMoreLink"),dataChannels:u(e=>e.dataChannels,[t],"p0.dataChannels"),planId:u(e=>e.title,[t],"p0.title"),channels:u(e=>e.subtitle,[t],"p0.subtitle"),text:u(e=>e.btnSeeMoreText,[t],"p0.btnSeeMoreText")}},3,"Tv_1")],1,null),n("div",null,{class:"justify-center items-start self-stretch flex gap-2.5 mt-2.5"},t.channels.map((e,a)=>i(M,{width:50,height:50,get media(){return e.attributes},clasN:"aspect-square object-contain object-center w-full overflow-hidden flex-1",[s]:{width:s,height:s,media:m(e,"attributes"),clasN:s}},3,a)),1,null)],1,null),n("div",null,{class:"border-gary-500 h-[1px] w-full border-t-2"},null,3,null),n("div",null,{class:"self-stretch w-full h-px mt-5 max-md:mx-0.5"},null,3,null),n("div",null,{class:"text-blue-800 text-base mt-5"},t.features.map((e,a)=>n("span",null,{class:"my-1 flex flex-row items-center justify-start"},[n("div",null,null,i(Ri,{class:"mx-2 h-[20px] w-[20px] fill-primary-blue text-primary-blue",[s]:{class:s}},3,"Tv_2"),1,null),n("h3",null,{class:"text-sm font-light"},w(e,"Text"),1,a)],1,a)),1,null)],1,null),i(sl,{get link(){return t.btnLink},get text(){return t.btnText},[s]:{link:u(e=>e.btnLink,[t],"p0.btnLink"),text:u(e=>e.btnText,[t],"p0.btnText")}},3,"Tv_3")],1,"Tv_4"),Ih=b(f(jh,"s_0v0O47RLS1E")),Eh=t=>n("div",null,{class:"flex flex-col items-center justify-center my-8 mx-4"},[n("h2",null,{class:"text-3xl text-center md:text-5xl font-semibold text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-5 lg:gap-10 my-6"},t.data.map((e,a)=>i(Ih,{get logo(){return e.Logo.data.attributes},get title(){return e.Title},get subtitle(){return e.Subtitle},get price(){return e.Price},get priceTime(){return e.Pricetime},get description(){return e.Description},get channels(){return e.Channels.data},get btnSeeMoreLink(){return e.LineupButton.Link},get btnSeeMoreText(){return e.LineupButton.Text},get features(){return e.Features},get btnLink(){return e.Button.Link},get btnText(){return e.Button.Text},get dataChannels(){return t.dataChannels},[s]:{logo:m(e.Logo.data,"attributes"),title:m(e,"Title"),subtitle:m(e,"Subtitle"),price:m(e,"Price"),priceTime:m(e,"Pricetime"),description:m(e,"Description"),channels:m(e.Channels,"data"),btnSeeMoreLink:m(e.LineupButton,"Link"),btnSeeMoreText:m(e.LineupButton,"Text"),features:m(e,"Features"),btnLink:m(e.Button,"Link"),btnText:m(e.Button,"Text"),dataChannels:u(l=>l.dataChannels,[t],"p0.dataChannels")}},3,a)),1,null)],1,"q0_0"),Nh=b(f(Eh,"s_m0jKnAHnXds")),Bh=t=>n("div",null,{class:"flex flex-col items-center justify-center px-6"},[n("h2",null,{class:"text-3xl md:text-5xl my-3 font-semibold text-primary-blue"},u(e=>e.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap gap-8 items-start justify-center my-4"},t.data.map((e,a)=>n("div",null,{class:"flex flex-col w-full md:w-2/5 my-3 md:my-5 p-6 text-center items-center justify-center rounded-2xl bg-white shadow-xl"},[n("h3",null,{class:"text-primary-dark-blue my-4 font-semibold text-xl"},w(e,"Title"),1,null),i(j,{get text(){return e.Paragraph},[s]:{text:m(e,"Paragraph")}},3,"ys_0")],1,a)),1,null),i(j,{classN:"markdownli text-s",get text(){return t.disclaimers},[s]:{classN:s,text:u(e=>e.disclaimers,[t],"p0.disclaimers")}},3,"ys_1")],1,"ys_2"),Ah=b(f(Bh,"s_Sqd58asrM5U")),Oh=t=>{let e=[];return n("div",null,{class:"flex flex-col items-center justify-center"},[n("h2",null,{class:"text-3xl text-center md:text-5xl my-3 font-semibold text-primary-blue"},u(a=>a.title,[t],"p0.title"),3,null),n("div",null,{class:"flex flex-wrap items-start justify-center my-6 gap-5"},t.data.map((a,l)=>n("div",null,{class:"w-[290px] min-h-[300px] py-6 px-2 flex-col items-center justify-center flex rounded-3xl bg-primary-blue"},[n("h2",null,{class:"text-3xl font-semibold text-white"},w(a,"Title"),1,null),n("div",null,{class:"flex flex-row"},[n("h2",null,{class:"text-white text-2xl"},["$ ",w(a,"Price")],1,null),n("p",null,{class:"text-white"},[" ",w(a,"Pricetime")],1,null)],1,null),n("div",null,{class:"flex flex-col bg-white w-full rounded-2xl mt-4 p-4"},a.Features.map((r,o)=>{if(V(),o<3)return e=[],n("div",null,{class:"flex flex-row gap-2 p-1 border-b-2"},[i(nr,{class:"text-secondary-red",[s]:{class:s}},3,"yk_0"),n("p",null,{class:"text-primary-blue"},w(r,"Title"),1,null)],1,o);if(o>=3&&(e.push(n("div",null,{class:"flex flex-row gap-2 p-1 border-b-2"},[i(nr,{class:"text-secondary-red",[s]:{class:s}},3,"yk_1"),n("p",null,{class:"text-primary-blue"},w(r,"Title"),1,null)],1,o)),o==3))return i(xa,{title:"Show all channels",children:e,[s]:{title:s}},1,"yk_2")}),1,null)],1,l)),1,null)],1,"yk_3")},Rh=b(f(Oh,"s_5iYsl7ZjuZc")),qh=t=>{const e=t.data.data.pageGfTv.data.attributes,a=t.data.data.sectionChGuide.data.attributes,l=t.data.data.channelLineups.data;return n("div",null,{class:"flex flex-col justify-around"},[n("div",null,{class:"flex flex-col my-6 items-center justify-center gap-4"},[i(M,{get media(){return e.Logo.data.attributes},height:200,width:500,[s]:{media:m(e.Logo.data,"attributes"),height:s,width:s}},3,"5L_0"),n("h2",null,{class:"text-[50px] font-bold text-center text-primary-blue"},w(e.Titles[0],"Text"),1,null),n("h2",null,{class:"text-[50px] font-bold text-center text-secondary-red"},w(e.Titles[1],"Text"),1,null)],1,null),i(Mh,{get data(){return e.Features},[s]:{data:m(e,"Features")}},3,"5L_1"),n("div",null,{class:"flex flex-col text-center p-4 items-center justify-center my-8"},[n("h2",null,{class:"text-3xl md:text-5xl font-semibold text-primary-blue my-6"},w(e.Feature,"Title"),1,null),i(j,{get text(){return e.Feature.Paragraph},[s]:{text:m(e.Feature,"Paragraph")}},3,"5L_2")],1,null),i(Nh,{dataChannels:l,get data(){return e.ChPackTables},get title(){return e.ChPackTitle},[s]:{data:m(e,"ChPackTables"),title:m(e,"ChPackTitle")}},3,"5L_3"),i(Rh,{get data(){return e.PremiumTables},get title(){return e.PremiumTitle},[s]:{data:m(e,"PremiumTables"),title:m(e,"PremiumTitle")}},3,"5L_4"),n("div",null,{class:"flex w-full flex-col items-center justify-center"},[n("div",null,{class:"my-4 flex max-w-[1200px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex min-[800px]:w-[70%] flex-col items-center justify-center gap-4 px-10"},[n("div",null,{class:"max-w-[470px]"},i(M,{get media(){return a.Logo.data.attributes},width:"1230",height:"230",[s]:{media:m(a.Logo.data,"attributes"),width:s,height:s}},3,"5L_5"),1,null),n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},w(a,"Title"),1,null),1,null),i(j,{get text(){return a.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{text:m(a,"Paragraph"),classN:s}},3,"5L_6")],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(Zi,{get nameDoc(){return a.GuideBox.Guide.data.attributes.name},get urlDoc(){return a.GuideBox.Guide.data.attributes.url},get image(){return a.Picture.data.attributes},get title(){return a.GuideBox.Title},get btnText(){return a.GuideBox.BtnText},[s]:{nameDoc:m(a.GuideBox.Guide.data.attributes,"name"),urlDoc:m(a.GuideBox.Guide.data.attributes,"url"),image:m(a.Picture.data,"attributes"),title:m(a.GuideBox,"Title"),btnText:m(a.GuideBox,"BtnText")}},3,"5L_7"),1,null)],1,null),i(Ah,{get data(){return e.Additionals},get disclaimers(){return e.Disclaimers},get title(){return e.AdditionalsTitle},[s]:{data:m(e,"Additionals"),disclaimers:m(e,"Disclaimers"),title:m(e,"AdditionalsTitle")}},3,"5L_8")],1,null)],1,"5L_9")},Fh=b(f(qh,"s_dsszBuF1I7U")),zh=t=>`sectionChGuide(locale:"${t}"){
        data{
          attributes{
            Logo{
              ${y}
            }
            Title
            Paragraph
            
            GuideBox{
              BtnText
              Guide{
                data{
                  attributes{
                    name
                    url
                  }
                }
              }
            }
            
            Picture{
             ${y}
            }
          }
        }
      }`,Qh=t=>`query {
        pageGfTv(locale:"${t}"){
          data {
            attributes {
              Logo {
               ${y}
              }
              Titles {
                Text
              }
              Features {
                Title
                Subtitle
                Paragraph
                Media {
                  ${y}
                }
              }
              Feature {
                Title
                Subtitle
                Paragraph
              }
              ChPackTitle
              ChPackTables {
                Logo {
                  ${y}
                }
                Title
                Subtitle
                Price
                Pricetime
                Description
                Channels {
                  ${y}
                }
                LineupButton{
                  Text
                  Link
                }
                Features {
                  Title
                  Text
                }
                Button {
                  Text
                  Link
                }
              }
              PremiumTitle
              PremiumTables {
                Title
                Price
                Pricetime
                Features {
                  Title
                }
              }
      
              
              
              AdditionalsTitle
              Additionals {
                Title
                Paragraph
              }
              Disclaimers
              
              ${z}
            }
          }
        }
        
        ${zh(t)}

        channelLineups (pagination:{limit:250}){
          data{
            attributes{
              Channel_name
              Image{
                ${y}
              }
              Category
              package_tvs{
                data{
                  attributes{
                    package
                  }
                }
              }
            }
        }
        }
      }`,Gh=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Qh,e)},rs=q(f(Gh,"s_dLnU84H8AgM")),Hh=()=>{const t=rs();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGfTv.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfTv.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfTv"]["data"]["attributes"]["SEO"]')}},3,"ad_0"),i(Fh,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"ad_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"ad_2")},1,"ad_3")},Vh=b(f(Hh,"s_yF5Z09ey0P4")),Wh=({resolveValue:t})=>{const a=t(rs).pageData.data.pageGfTv.data.attributes.SEO;return H(a)},Uh=Object.freeze(Object.defineProperty({__proto__:null,default:Vh,head:Wh,usePageData:rs},Symbol.toStringTag,{value:"Module"})),Yh=t=>{const e=t.data.pageGfVS.data.attributes,a=t.data.sectionPortGfv.data.attributes.Portability;return n("div",null,{class:"flex flex-col items-center"},[n("div",null,{class:"relative w-full md:w-2/3 h-[210px] md:h-[150px] bg-blue-200 flex flex-row justify-end items-center rounded-full"},[n("div",null,{class:"h-full absolute rounded-full w-3/4 bg-blue-300"},null,3,null),n("div",null,{class:"h-full absolute rounded-full w-2/4 bg-blue-400"},null,3,null),n("div",null,{class:"h-full absolute rounded-full w-1/4 bg-blue-600"},null,3,null),n("div",null,{class:"absolute w-full h-full flex flex-row p-5 justify-between items-center"},[n("h1",null,{class:"text-primary-blue lg:text-3xl md:text-2xl font-bold text-center text-xl"},w(e.Introduction,"Paragraph"),1,null),i(M,{get media(){return e.Introduction.Media.data.attributes},width:200,height:150,[s]:{media:m(e.Introduction.Media.data,"attributes"),width:s,height:s}},3,"T3_0")],1,null)],1,null),n("div",null,{class:"flex flex-col mt-10 justify-center px-8 items-center"},[n("div",null,{class:"w-full md:w-2/3 flex flex-col items-center"},[n("h2",null,{class:"text-3xl md:text-4xl text-center font-bold text-primary-blue"},w(e.GuidesPar,"Title"),1,null),i(j,{classN:"text-center",get text(){return e.GuidesPar.Paragraph},[s]:{classN:s,text:m(e.GuidesPar,"Paragraph")}},3,"T3_1")],1,null),n("div",null,{class:"flex flex-wrap items-center justify-center gap-10 my-5"},e.Guides.map((l,r)=>i(Ji,{get urlDoc(){return l.Guide.data.attributes.url},get title(){return l.Title},get btnText(){return l.BtnText},get nameDoc(){return l.Guide.data.attributes.name},[s]:{urlDoc:m(l.Guide.data.attributes,"url"),title:m(l,"Title"),btnText:m(l,"BtnText"),nameDoc:m(l.Guide.data.attributes,"name")}},3,r)),1,null)],1,null),n("div",null,null,i(It,{get title(){return a.Title},get text(){return a.Paragraph},get logo(){return a.Logo.data.attributes},get image(){return a.Media.data.attributes},backgroundColor:"transparent",get buttons(){return a.Buttons},[s]:{title:m(a,"Title"),text:m(a,"Paragraph"),logo:m(a.Logo.data,"attributes"),image:m(a.Media.data,"attributes"),backgroundColor:s,buttons:m(a,"Buttons")}},3,"T3_2"),1,null)],1,"T3_3")},Jh=b(f(Yh,"s_BWUEQjQaK9s")),Zh=t=>`query queryGFTvSupport{
        pageGfVS(locale:"${t}"){
          data{
            attributes{
              Introduction{
                Paragraph
                Media{
                  ${y}
                }
              }
              GuidesPar{
                Title
                Paragraph
              }
              Guides{
                Title
                BtnText
                Guide{
                  data{
                    attributes{
                      url
                      name
                    }
                  }
                }
              }
              ${z}
            }
          }
        }
        sectionPortGfv(locale:"${t}"){
          data{
            attributes{
              Portability{
                Title
                Logo{
                 ${y}
                }
                Paragraph
                Media{
                 ${y}
                }
                Buttons{
                  Text
                  Link
                }
              }
            }
          }
        }
      }`,Kh=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Zh,e)},is=q(f(Kh,"s_MmL0KO3X80U")),Xh=()=>{const t=is();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(Jh,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Wc_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Wc_1")},1,"Wc_2")},tb=b(f(Xh,"s_MnhzpLl96M8")),eb=({resolveValue:t})=>{const a=t(is).pageData.data.pageGfVS.data.attributes.SEO;return H(a)},ab=Object.freeze(Object.defineProperty({__proto__:null,default:tb,head:eb,usePageData:is},Symbol.toStringTag,{value:"Module"})),lb=t=>n("div",null,{class:"flex w-full justify-center text-primary-blue"},n("div",null,{class:"mx-8 my-8 flex flex-col items-center gap-6 text-center text-[18px]"},[i(M,{get media(){return t.data.Logo.data.attributes},width:"450",clasN:"mb-6",[s]:{media:u(e=>e.data.Logo.data.attributes,[t],'p0.data["Logo"]["data"]["attributes"]'),width:s,clasN:s}},3,"0F_0"),i(j,{get text(){return t.data.Paragraph},[s]:{text:u(e=>e.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"0F_1"),i(K,{get text(){return t.data.Buttons[0].Text},get link(){return t.data.Buttons[0].Link},[s]:{text:u(e=>e.data.Buttons[0].Text,[t],'p0.data["Buttons"][0]["Text"]'),link:u(e=>e.data.Buttons[0].Link,[t],'p0.data["Buttons"][0]["Link"]')}},3,"0F_2")],1,null),1,"0F_3"),nb=b(f(lb,"s_Ue8VWX4F1hY")),sb=t=>n("div",null,{class:"max-w-1200 mx-8 flex flex-wrap justify-evenly gap-6"},t.data.map((e,a)=>i(es,{get title(){return e.Title},get btnText(){return e.Button.Text},get btnLink(){return e.Button.Link},get description(){return e.Description},price:e.Price.toString(),get features(){return e.Features},get logo(){return e.Logo.data.attributes},get priceTime(){return e.Pricetime},[s]:{title:m(e,"Title"),btnText:m(e.Button,"Text"),btnLink:m(e.Button,"Link"),description:m(e,"Description"),features:m(e,"Features"),logo:m(e.Logo.data,"attributes"),priceTime:m(e,"Pricetime")}},3,a)),1,"mV_0"),rb=b(f(sb,"s_2f78m38d8Zo")),ib=t=>{const e={...t.data.pageGfV.data.attributes.Introduction,Logo:t.data.pageGfV.data.attributes.Logo},a=t.data.pageGfV.data.attributes.PackTables,l=t.data.sectionPortGfv.data.attributes.Portability;return n("div",null,null,[i(nb,{data:e},3,"Pl_0"),n("div",null,{class:"mt-6"},i(rb,{data:a},3,"Pl_1"),1,null),n("div",null,{class:"mt-6"},i(Ke,{data:l,color:"primary-blue",backgroundColor:"transparent",[s]:{color:s,backgroundColor:s}},3,"Pl_2"),1,null)],1,"Pl_3")},ob=b(f(ib,"s_S2NF7hg0ZA8")),ub=t=>`
  query {
    pageGfV(locale:"${t}") {
      data {
        attributes {
          Logo {
            ${y}
          }
          Introduction {
            Title
            Paragraph
            Buttons {
              Text
              Link
            }
          }
          PackTables {
            Logo {
              ${y}
            }
            Title
            Subtitle
            Price
            Pricetime
            Description
            Features {
              Title
              Text
            }
            Button {
              Text
              Link
              Icon {
                ${y}
              }
            }
          }
          ${z}
        
        }
      }
    }
    sectionPortGfv(locale:"${t}"){
        data{
          attributes{
            Portability{
              Title
              Logo{
               ${y}
              }
              Paragraph
              Media{
               ${y}
              }
              Buttons{
                Text
                Link
              }
            }
          }
        }
      }
  }
    `,cb=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(ub,e)},os=q(f(cb,"s_ThxJp560MGY")),db=()=>{const t=os();return i(F,{get data(){return t.value.layoutData},showHeader:!1,children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGfV.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGfV.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGfV"]["data"]["attributes"]["SEO"]')}},3,"0t_0"),i(ob,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"0t_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"0t_2")},pb=b(f(db,"s_1bc90Wt0fJ4")),gb=({resolveValue:t})=>{const a=t(os).pageData.data.pageGfV.data.attributes.SEO;return H(a)},fb=Object.freeze(Object.defineProperty({__proto__:null,default:pb,head:gb,usePageData:os},Symbol.toStringTag,{value:"Module"})),xb=t=>{const e=t.data.pageGivingBack.data.attributes.Helping;return n("div",null,{onClick$:O("s_IrVC6P6zSuQ")},i(Xe,{data:e},3,"eb_0"),1,"eb_1")},mb=b(f(xb,"s_g0kQhWSZ3HE")),hb=t=>`
    query QueryGivingBack {
        pageGivingBack(locale:"${t}"){    
          data{
            attributes{
                 Title
              Helping{
                Logo{
                 ${y}
                }
                Media{
                  ${y}
                }
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              ${z}
            }
          }
        }
      }
    `,bb=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(hb,e)},us=q(f(bb,"s_HxhGEMn0sRc")),$b=()=>{const t=us();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageGivingBack.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageGivingBack.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageGivingBack"]["data"]["attributes"]["SEO"]')}},3,"4m_0"),i(mb,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"4m_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"4m_2")},yb=b(f($b,"s_NbmekxDi7Vw")),vb=({resolveValue:t})=>{const a=t(us).pageData.data.pageGivingBack.data.attributes.SEO;return H(a)},_b=Object.freeze(Object.defineProperty({__proto__:null,default:yb,head:vb,usePageData:us},Symbol.toStringTag,{value:"Module"})),wb=t=>{const e=t.data.Logo.data.attributes;return n("div",null,{class:"min-h-screen w-full flex flex-col items-center"},[i(M,{width:"200px",height:"80px",media:e,clasN:"pt-5 px-5",[s]:{width:s,height:s,clasN:s}},3,"mB_0"),i(Yn,{get parData(){return t.data.SectionHead},[s]:{parData:u(a=>a.data.SectionHead,[t],'p0.data["SectionHead"]')}},3,"mB_1"),i(wl,{get speedList(){return t.data.SpeedBullets},[s]:{speedList:u(a=>a.data.SpeedBullets,[t],'p0.data["SpeedBullets"]')}},3,"mB_2"),i(Jn,{get parData(){return t.data.SectionRating},[s]:{parData:u(a=>a.data.SectionRating,[t],'p0.data["SectionRating"]')}},3,"mB_3"),n("div",null,{class:"w-full bg-white  flex md:flex-row flex-col items-center justify-between"},[n("div",null,{class:" flex flex-row gap-5 p-1"},t.data.Footer&&t.data.Footer.map((a,l)=>i(zt,{get href(){return a.Link},class:" hover:text-primary-blue/60 text-primary-blue font-bold",children:w(a,"Text"),[s]:{href:m(a,"Link"),class:s}},1,l)),1,null),n("div",null,{class:"text-primary-blue text-center"},"© 2024 Rural Telecommunications of America, Inc. All rights reserved.",3,null)],1,null)],1,"mB_4")},Sb=b(f(wb,"s_TtLrO4fYqlI")),Tb=t=>`query QueryLPGoldsmith {
        lpGoldsmith (locale:"${t}"){    
          data{
            attributes{
              Logo{
                ${y}
              }

              SectionHead{
                Title
                Subtitle
                Paragraph
                Logo{
                    ${y}
                }
                Media{
                    ${y}
                }
                Buttons{
                  Text
                  Link
                }
              }

              SpeedBullets{
                Title
                Text
              }

              SectionRating{
                Title
                Subtitle
                Paragraph
                Buttons{
                  Text
                  Link
                }
                Media{
                    ${y}
                }
              }
              
              Footer{
                Text
                Link
              }
            ${z}
            }
          }
        }
        
      }`,Db=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Tb,e)},cs=q(f(Db,"s_VvrWzA20lF0")),Pb=()=>{const t=cs();return i(G,{children:i(F,{get data(){return t.value.layoutData},showMenus:!1,showHeader:!1,children:i(Sb,{get data(){return t.value.pageData.data.lpGoldsmith.data.attributes},[s]:{data:u(e=>e.value.pageData.data.lpGoldsmith.data.attributes,[t],'p0.value["pageData"]["data"]["lpGoldsmith"]["data"]["attributes"]')}},3,"BY_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showMenus:s,showHeader:s}},1,"BY_1")},1,"BY_2")},kb=b(f(Pb,"s_WHj3dLp4igs")),Lb=({resolveValue:t})=>{const a=t(cs).pageData.data.lpGoldsmith.data.attributes.SEO;return H(a)},Cb=Object.freeze(Object.defineProperty({__proto__:null,default:kb,head:Lb,usePageData:cs},Symbol.toStringTag,{value:"Module"})),Mb=t=>n("div",null,{class:"w-full flex flex-row items-center justify-center"},n("div",null,{class:"px-4 py-2 md:px-10 md:py-2 max-w-[1200px]"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(j,{get text(){return t.data.TextContent},classN:" text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"YK_0")],1,null),1,"YK_1"),jb=b(f(Mb,"s_kXmVcxHZMiE")),Ib=t=>`query QueryInternetTransparency {
        pageTransparency(locale:"${t}"){    
          ${fa}
          ${z}
            }
          }
        }
      }`,Eb=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Ib,e)},ds=q(f(Eb,"s_6Qn0TGy9U7E")),Nb=()=>{const t=ds(),e=t.value.pageData.data.pageTransparency.data.attributes.Content;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(jb,{data:e},3,"7b_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"7b_1")},1,"7b_2")},Bb=b(f(Nb,"s_lgP2BOg1kq8")),Ab=({resolveValue:t})=>{const a=t(ds).pageData.data.pageTransparency.data.attributes.SEO;return H(a)},Ob=Object.freeze(Object.defineProperty({__proto__:null,default:Bb,head:Ab,usePageData:ds},Symbol.toStringTag,{value:"Module"})),Rb=t=>`query QueryLeadershipTeam{
        pageLeadershipT(locale:"${t}"){
          data{
            attributes{
              ${Bi}
              ${z}
              }
            }
          }
        }`,qb=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Rb,e)},ps=q(f(qb,"s_ZvTItzMmB40")),Fb=()=>{const t=ps(),e=t.value.pageData.data.pageLeadershipT.data.attributes;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageLeadershipT.data.attributes.SEO},[s]:{SEOdata:u(a=>a.value.pageData.data.pageLeadershipT.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageLeadershipT"]["data"]["attributes"]["SEO"]')}},3,"cW_0"),i(Ui,{data:e},3,"cW_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"cW_2")},1,"cW_3")},zb=b(f(Fb,"s_VJGz1Q1nMWA")),Qb=({resolveValue:t})=>{const a=t(ps).pageData.data.pageLeadershipT.data.attributes.SEO;return H(a)},Gb=Object.freeze(Object.defineProperty({__proto__:null,default:zb,head:Qb,usePageData:ps},Symbol.toStringTag,{value:"Module"})),Hb=t=>n("div",null,{class:"px-4 py-2 md:px-10 md:py-2"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),n("h2",null,{class:"text-primary-blue text-center font-semibold text-lg md:text-2xl mb-4"},u(e=>e.data.Titles[1].Text,[t],'p0.data["Titles"][1]["Text"]'),3,null),i(j,{get text(){return t.data.TextContent},classN:" text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"tP_0")],1,"tP_1"),Vb=b(f(Hb,"s_l6pybhQ4d3A")),Wb=t=>`query QueryLegal {
        pageLegal(locale:"${t}"){    
          ${fa}
          ${z}
            }
          }
        }
      }`,Ub=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Wb,e)},gs=q(f(Ub,"s_p9UoBCtfUPo")),Yb=()=>{const t=gs(),e=t.value.pageData.data.pageLegal.data.attributes.Content;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(Vb,{data:e},3,"W8_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"W8_1")},1,"W8_2")},Jb=b(f(Yb,"s_DAHSW75A6dQ")),Zb=({resolveValue:t})=>{const a=t(gs).pageData.data.pageLegal.data.attributes.SEO;return H(a)},Kb=Object.freeze(Object.defineProperty({__proto__:null,default:Jb,head:Zb,usePageData:gs},Symbol.toStringTag,{value:"Module"})),Xb=t=>{const e=t.data.pageLocWeather.data.attributes,a=l=>`https://raw.githubusercontent.com/visualcrossing/WeatherIcons/main/PNG/1st%20Set%20-%20Color/${l}.png`;return n("div",null,{class:"flex flex-wrap items-center justify-center gap-8 px-8 py-8 text-white",onClick$:O("s_VJdTV7fBj8k")},t.data.weatherData.data.map((l,r)=>n("div",null,{class:"relative h-[350px] w-[600px] max-[1200px]:h-[280px] max-[1200px]:w-[500px]"},[n("div",null,{class:"relative flex h-full w-[50%] flex-col justify-between overflow-hidden rounded-[30px] px-4 py-8 "},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-[6] h-full w-full"},i(M,{clasN:"h-[400px]",width:"2622",height:"3086",get media(){return e.LocTables.find(o=>o.Location===l.city).LocationPic.data.attributes},[s]:{clasN:s,width:s,height:s,media:m(e.LocTables.find(o=>o.Location===l.city).LocationPic.data,"attributes")}},3,"tT_0"),1,null),n("div",null,{class:"absolute bottom-0 left-0 right-0 top-0 -z-[5] h-full w-full bg-black opacity-30"},null,3,null),n("div",null,{class:"flex flex-col"},[n("span",null,{class:"text-[20px] font-[700]",onClick$:O("s_K3eGiPS50Ks")},Ha(l.data.days[0].datetime).split(", ")[0],1,null),n("span",null,{class:"text-[12px]"},Ha(l.data.days[0].datetime,!1),1,null),n("div",null,{class:"mt-2 flex items-center gap-3"},[i(Mn,{class:"text-[15px] text-white",[s]:{class:s}},3,"tT_1"),n("span",null,{class:"text-[17px] font-[600] max-[1200px]:text-[15px]"},w(l,"city"),1,null)],1,null)],1,null),n("div",null,null,[n("span",null,{class:"text-[18px] font-[700]"},w(l.data.days[0],"conditions"),1,null),n("img",{src:a(l.data.days[0].icon),alt:`icon-${l.data.days[0].icon}`,title:`icon-${l.data.days[0].icon}`},{width:"50",height:"50"},null,3,null)],1,null),n("div",null,{class:"flex w-full justify-evenly"},[n("div",null,{class:"flex flex-col items-center"},[n("span",null,{class:"text-[14px]"},"Min",3,null),n("span",null,{class:"text-[28px] font-[700] max-[1200px]:text-[20px]"},[w(l.data.days[0],"tempmin"),"°F"],1,null)],1,null),n("div",null,{class:"flex flex-col items-center"},[n("span",null,{class:"text-[14px]"},"Max",3,null),n("span",null,{class:"text-[28px] font-[700] max-[1200px]:text-[20px]"},[w(l.data.days[0],"tempmin"),"°F"],1,null)],1,null)],1,null)],1,null),n("div",null,{class:"absolute bottom-3 right-0 top-3 -z-[7] flex w-[56%] flex-col gap-1 rounded-[30px] bg-[#172c4b] py-8 pl-14 pr-6 text-[17px] max-[1200px]:text-[13px]"},[n("div",null,{class:"flex justify-between font-[700] "},[n("span",null,null,"PRECIPITATION",3,null),n("span",null,{class:"font-[300]"},[w(l.data.days[0],"precipprob"),"%"],1,null)],1,null),n("div",null,{class:"flex justify-between font-[700]"},[n("span",null,null,"HUMIDITY",3,null),n("span",null,{class:"font-[300]"},[w(l.data.days[0],"humidity"),"%"],1,null)],1,null),n("div",null,{class:"flex justify-between font-[700]"},[n("span",null,null,"WIND",3,null),n("span",null,{class:"font-[300]"},[w(l.data.days[0],"windspeed")," mph"],1,null)],1,null),n("div",null,{class:"mt-6 grid grid-cols-3 justify-center gap-1"},[1,2,3].map(o=>n("div",null,{class:"flex flex-col items-center gap-1 text-[12px] max-[1200px]:text-[9px]"},[n("img",{src:a(l.data.days[o].icon),alt:`icon-${l.data.days[o].icon}`,title:`icon-${l.data.days[o].icon}`},{width:"30",height:"30"},null,3,null),n("span",null,{class:""},Ha(l.data.days[o].datetime).split(", ")[0],1,null),n("span",null,{class:"font-[600]"},[w(l.data.days[o],"tempmax"),"°F"],1,null),n("span",null,{class:"font-[600]"},[w(l.data.days[o],"tempmin"),"°F"],1,null)],1,o)),1,null)],1,null)],1,r)),1,"tT_2")},t$=b(f(Xb,"s_Eyqu8EYnqHs")),e$=t=>`query locWeather{
        pageLocWeather(locale:"${t}"){
          data{
            attributes{
              LocTables{
                Location
                LocationPic{
                  ${y}
                }
              }
              ${z}
            }
          }
        }
      }`,a$=async t=>{const e=t.params.lang==""?"en":"es-419",a=await Q(e$,e),l={status:"error",data:[]};for(const r of a.pageData.data.pageLocWeather.data.attributes.LocTables){const o=r.Location,c=await fetch(`https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${o}/next7days?unitGroup=us&include=days%2Ccurrent&key=J8MMBMZC9DTQTVGHBPNEWPPGS&contentType=json`);if(c.ok){const p=await c.json();l.data.push({city:o,data:p})}}return{...a,weatherData:l}},fs=q(f(a$,"s_gwWti8fe82E")),l$=()=>{const t=fs();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageLocWeather.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageLocWeather.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageLocWeather"]["data"]["attributes"]["SEO"]')}},3,"rD_0"),i(t$,{get data(){return{pageLocWeather:t.value.pageData.data.pageLocWeather,weatherData:t.value.weatherData}},[s]:{data:u(e=>({pageLocWeather:e.value.pageData.data.pageLocWeather,weatherData:e.value.weatherData}),[t],'{pageLocWeather:p0.value["pageData"]["data"]["pageLocWeather"],weatherData:p0.value["weatherData"]}')}},3,"rD_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"rD_2")},n$=b(f(l$,"s_VS5ugbSZKZs")),s$=({resolveValue:t})=>{const a=t(fs).pageData.data.pageLocWeather.data.attributes.SEO;return H(a)},r$=Object.freeze(Object.defineProperty({__proto__:null,default:n$,head:s$,usePageData:fs},Symbol.toStringTag,{value:"Module"})),i$=t=>{var o;const a=(o=ot().prevUrl)==null?void 0:o.pathname.includes("/es/"),l=t.data.pageNews.data.attributes,r=l.Posts.data[0].attributes;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(An,{post:r,isES:a},3,"MY_0"),n("div",null,{class:"my-4"},null,3,null),i(On,{get posts(){return l.Posts.data},loadSize:3,type:"News",[s]:{posts:m(l.Posts,"data"),loadSize:s,type:s}},3,"MY_1")],1,"MY_2")},o$=b(f(i$,"s_d8TgHnXz650")),u$=t=>` query QueryNews {
        pageNews(locale:"${t}"){    
          data{
          attributes{
            Posts(sort: "Date:desc", pagination: { limit: 100 }){
                data{
                  attributes{
                    Title
                    Date
                    Cover{
                      ${y}
                    }
                    Description
                    VideoLink
                    Gallery{
                      ${y}
                    }
                    Slug
                  }
                }
              }
            SugPages{
              Title
              Pages{
              Title
              Link
              Picture{
                ${y}
              }
              }
            }
            ${z}
          }
        }
        }
      }`,c$=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(u$,e)},xs=q(f(c$,"s_HdPbxCOsb5s")),d$=()=>{const t=xs();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageNews.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageNews.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageNews"]["data"]["attributes"]["SEO"]')}},3,"7N_0"),i(o$,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"7N_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"7N_2")},p$=b(f(d$,"s_Afg1iFacoB8")),g$=({resolveValue:t})=>{const a=t(xs).pageData.data.pageNews.data.attributes.SEO;return H(a)},f$=Object.freeze(Object.defineProperty({__proto__:null,default:p$,head:g$,usePageData:xs},Symbol.toStringTag,{value:"Module"})),x$=t=>n("div",null,{class:"flex flex-col items-center text-primary-blue"},[n("h2",null,{class:"px-4 md:px-8 text-center font-semibold text-secondary-red text-2xl md:text-3xl"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),n("h3",null,{class:"px-4 md:px-8 text-center text-xl md:text-2xl"},u(e=>e.data.Titles[1].Text,[t],'p0.data["Titles"][1]["Text"]'),3,null),n("div",null,{class:"flex px-4 md:px-8 mt-5 flex-wrap items-center justify-center"},[n("div",null,{class:"flex flex-col w-full lg:w-3/5 mx-5"},[n("h3",null,{class:"font-bold my-4 text-2xl md:text-4xl text-center"},u(e=>e.data.CommitmentPar.Title,[t],'p0.data["CommitmentPar"]["Title"]'),3,null),i(j,{get text(){return t.data.CommitmentPar.Paragraph},classN:"text-justify",[s]:{text:u(e=>e.data.CommitmentPar.Paragraph,[t],'p0.data["CommitmentPar"]["Paragraph"]'),classN:s}},3,"aa_0")],1,null),i(Ue,{height:"h-[350px]",width:"w-[350px]",get media(){return t.data.CommitmentPar.Media.data.attributes},[s]:{height:s,width:s,media:u(e=>e.data.CommitmentPar.Media.data.attributes,[t],'p0.data["CommitmentPar"]["Media"]["data"]["attributes"]')}},3,"aa_1")],1,null),n("div",null,{class:"flex px-8 mt-8 flex-col md:flex-row justify-center md:justify-around items-center md:items-start"},t.data.ColumnsPar.map((e,a)=>n("div",null,{class:"flex flex-col my-5 w-full md:w-1/2 justify-center items-center"},[n("h2",null,{class:"font-bold  text-2xl md:text-4xl text-center"},w(e,"Title"),1,null),i(j,{get text(){return e.Paragraph},[s]:{text:m(e,"Paragraph")}},3,"aa_2")],1,a)),1,null),n("h3",null,{class:"font-bold text-2xl md:text-4xl mt-8 text-center"},u(e=>e.data.SponsorshipsTitle,[t],'p0.data["SponsorshipsTitle"]'),3,null),n("div",null,{class:"flex items-center justify-center w-full my-4"},[n("div",null,{class:"w-full flex bg-primary-blue bg-opacity-30 my-4 h-[350px] py-10"},n("div",null,{class:"w-full bg-primary-blue py-10 bg-opacity-60"},n("div",null,{class:"w-full h-full bg-primary-blue"},null,3,null),3,null),3,null),t.data.Sponsorships.map((e,a)=>n("div",null,{class:"h-[350px] px-6 absolute flex flex-col justify-around items-center w-[250px] bg-white rounded-3xl shadow-xl"},[i(Ue,{height:"h-[200px]",width:"w-[200px]",get media(){return t.data.Sponsorships[0].Media.data.attributes},[s]:{height:s,width:s,media:u(l=>l.data.Sponsorships[0].Media.data.attributes,[t],'p0.data["Sponsorships"][0]["Media"]["data"]["attributes"]')}},3,"aa_3"),n("div",null,{class:"flex flex-col items-center"},[n("h3",null,{class:"text-secondary-red text-xl font-semibold"},w(e,"Title"),1,null),n("h3",null,{class:"text-secondary-red text-xl font-semibold"},w(e,"Subtitle"),1,null)],1,null),i(K,{get text(){return e.Buttons[0].Text},get link(){return e.Buttons[0].Link},[s]:{text:m(e.Buttons[0],"Text"),link:m(e.Buttons[0],"Link")}},3,"aa_4")],1,a))],1,null)],1,"aa_5"),m$=b(f(x$,"s_RH3prNj9z7A")),h$=t=>`query QueryOurStory{
        pageOurStory(locale:"${t}"){
          data{
            attributes{
              Titles{
                Text
              }
              CommitmentPar{
                Title
                Paragraph
                Media{
                ${y}
                }
              }
              
              ColumnsPar{
                Title
                Paragraph
              }
              
              SponsorshipsTitle
              Sponsorships{
                Title
                Subtitle
                Paragraph
                Media{
                ${y}
                }
                Buttons{
                  Text
                  Link
                }
              }
              ${z}
             
            }
          }
        }
      }`,b$=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(h$,e)},ms=q(f(b$,"s_I9YCjFVOHNE")),$$=()=>{const t=ms(),e=t.value.pageData.data.pageOurStory.data.attributes;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return e.SEO},[s]:{SEOdata:m(e,"SEO")}},3,"CH_0"),i(m$,{data:e},3,"CH_1")],[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"CH_2")},1,"CH_3")},y$=b(f($$,"s_ONSPkGdkwcs")),v$=({resolveValue:t})=>{const a=t(ms).pageData.data.pageOurStory.data.attributes.SEO;return H(a)},_$=Object.freeze(Object.defineProperty({__proto__:null,default:y$,head:v$,usePageData:ms},Symbol.toStringTag,{value:"Module"})),w$=t=>{const e=t.data.Logo.data.attributes,a=t.data.Media.data.attributes;return n("div",null,{class:"flex max-w-[1200px] items-center justify-center self-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-4 px-10 min-[800px]:w-[70%]"},[n("div",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(l=>l.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"max-w-[470px]"},i(M,{media:e,width:1230,height:230,[s]:{width:s,height:s}},3,"Y3_0"),1,null),n("div",null,null,i(j,{classN:"max-sm:text-[15px] text-[18px] text-[#2E5899]",get text(){return t.data.Paragraph},[s]:{classN:s,text:u(l=>l.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"Y3_1"),1,null)],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(M,{media:a,width:1e3,height:1e3,[s]:{width:s,height:s}},3,"Y3_2"),1,null)],1,"Y3_3")},S$=b(f(w$,"s_G8eOcGEKYk4")),T$=t=>{const e=t.data.pagePortability.data.attributes.PortabilityActs,a=t.data.pagePortability.data.attributes.Introduction;return n("div",null,{class:"flex flex-col items-center justify-center"},[i(S$,{data:a},3,"C7_0"),i(Xe,{data:e},3,"C7_1")],1,"C7_2")},D$=b(f(T$,"s_OvPpWmexBMU")),P$=t=>`
    query QueryPortability{
        pagePortability(locale:"${t}"){    
          data{
            attributes{
              Introduction{
                Title
                Subtitle
                Logo{
                ${y}
                }
                Paragraph
                Media{
                ${y}
                }
              }
              
              IntroductionBG{
                ${y}
              }
      
              PortabilityActs{
                Title
                Subtitle
                Buttons{
                  Text
                  Link
                }
                Logo{
                ${y}
                }
                Paragraph
                Media{
                ${y}
                }
              }
              ${z}
            }
          }
        }
      }
    `,k$=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(P$,e)},hs=q(f(k$,"s_DV97RmVctT4")),L$=()=>{const t=hs();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pagePortability.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pagePortability.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pagePortability"]["data"]["attributes"]["SEO"]')}},3,"eB_0"),i(D$,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"eB_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"eB_2")},C$=b(f(L$,"s_LbhuqOuteuA")),M$=({resolveValue:t})=>{const a=t(hs).pageData.data.pagePortability.data.attributes.SEO;return H(a)},j$=Object.freeze(Object.defineProperty({__proto__:null,default:C$,head:M$,usePageData:hs},Symbol.toStringTag,{value:"Module"})),Ki=new Date,I$=Ki.toISOString().substring(0,10),E$=Ki.toISOString().substring(11,19),Xi=t=>`
    query QueryHome{
  pageHome(locale:"${t}"){
    data{
      attributes{
        
        VideoBGDesktop{
          ${y}
        }
        VideoBGMobile{
          ${y}
        }
        HeroCarSlideZS{
          Video{
            ${y}
          }
          Description
          Logo{
            ${y}
          }
          RaceDate
        }

        HeroCarSlides{
          Title
          Subtitle
          Logo{
          ${y}
          }
          Paragraph
          Media{
          ${y}
          }
          Buttons{
            Text
            Link
          }
        }
        HeroForm{
          Title
          ActionButton{
            Text
            Link
          }
        }

        Testimonials{
          Name
          Text
          Rating
        }

        ProsPar{
          Title
          Paragraph
        }

        ProsPicture{
          ${y}
        }
        ProsBackground{
          ${y}
        }
        ParACP{
          Title
          Subtitle
          Paragraph
          Logo{
          ${y}
          }
          Media{
          ${y}
          }
          Buttons{
            Text
            Link
          }
        }
        ParGFIPlans{
          Title
          Paragraph
          Disclaimer{
            Title
            Text
            Caption
            Icon{
          ${y}
            }
          }
          Table{
            ColumnOne
            ColumnTwo
            ColumnThree
          }

        }
        ParGFServices{
          Title
          Subtitle
          Logo{
          ${y}
          }
          Paragraph
          Media{
          ${y}
          }
          Buttons{
            Text
            Link
          }
        }
        SugsPages{
          Title
          Paragraph
          Media{
          ${y}
          }
          Buttons{
            Text
            Link
          }
        }
        SugsPagesBG{
          ${y}
        }
        ${z}
      }
    }
  }
  zaneRaces (
    filters: {RaceDay: {gte: "${I$}"}, RaceTime: {gte: "${E$}"}}, 
    locale:"en", 
    sort: "RaceDate"
    pagination: {limit: 1}) {
    data {
      attributes {
        Video {
          ${y}
        }
        Logo {
          ${y}
        }
        Description
        RaceDay
        RaceTime
      }
    }
  }
  sectionProsRta(locale:"${t}") {
    data {
      attributes {
        Pros {
          Icon {
            ${y}
          }
          Title
          Text
          Caption
        }
      }
    }
  }
  sectionNetwork {
    data {
      attributes {
        Map {
          MapPicture {
            ${y}
          }
        }
      }
    }
  }
}
`,N$=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang;return await Q(Xi,e)},B$=q(f(N$,"s_MfWlD1sVVR8")),A$=()=>n("div",null,null,"a",3,"yK_0"),O$=b(f(A$,"s_S2euYekMMCk")),R$=Object.freeze(Object.defineProperty({__proto__:null,default:O$,usePageData:B$},Symbol.toStringTag,{value:"Module"})),q$=t=>n("div",null,{class:"p-6"},[n("h1",null,{class:"text-primary-blue text-center font-semibold text-2xl mb-4"},u(e=>e.data.Titles[0].Text,[t],'p0.data["Titles"][0]["Text"]'),3,null),i(j,{get text(){return t.data.TextContent},classN:"markdownTitle markdownHyper text-justify text-primary-blue font-normal text-sm md:text-base",[s]:{text:u(e=>e.data.TextContent,[t],'p0.data["TextContent"]'),classN:s}},3,"Vp_0")],1,"Vp_1"),F$=b(f(q$,"s_m0xHvviU9eM")),z$=t=>`
query QueryPrivacyP {
  pagePrivacyP(locale:"${t}"){    
    ${fa}
    ${z}
      }
    }
  }
}
`,Q$=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(z$,e)},bs=q(f(Q$,"s_010w2sLh1OQ")),G$=()=>{const t=bs(),e=t.value.pageData.data.pagePrivacyP.data.attributes.Content;return i(F,{get data(){return t.value.layoutData},children:i(F$,{data:e},3,"bX_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"bX_1")},H$=b(f(G$,"s_vRJXLmWn290")),V$=({resolveValue:t})=>{const a=t(bs).pageData.data.pagePrivacyP.data.attributes.SEO;return H(a)},W$=Object.freeze(Object.defineProperty({__proto__:null,default:H$,head:V$,usePageData:bs},Symbol.toStringTag,{value:"Module"})),U$=t=>{const e=t.data.Logo.data.attributes;return n("div",null,{class:"min-h-screen w-full flex flex-col items-center"},[i(M,{width:"200px",height:"80px",media:e,clasN:"pt-5 px-5",[s]:{width:s,height:s,clasN:s}},3,"Hd_0"),i(Yn,{get parData(){return t.data.SectionHead},[s]:{parData:u(a=>a.data.SectionHead,[t],'p0.data["SectionHead"]')}},3,"Hd_1"),i(wl,{get speedList(){return t.data.SpeedBullets},[s]:{speedList:u(a=>a.data.SpeedBullets,[t],'p0.data["SpeedBullets"]')}},3,"Hd_2"),i(Jn,{get parData(){return t.data.SectionRating},[s]:{parData:u(a=>a.data.SectionRating,[t],'p0.data["SectionRating"]')}},3,"Hd_3"),n("div",null,{class:"w-full bg-white  flex md:flex-row flex-col items-center justify-between"},[n("div",null,{class:" flex flex-row gap-5 p-1"},t.data.Footer&&t.data.Footer.map((a,l)=>i(zt,{get href(){return a.Link},class:" hover:text-primary-blue/60 text-primary-blue font-bold",children:w(a,"Text"),[s]:{href:m(a,"Link"),class:s}},1,l)),1,null),n("div",null,{class:"text-primary-blue text-center"},"© 2024 Rural Telecommunications of America, Inc. All rights reserved.",3,null)],1,null)],1,"Hd_4")},Y$=b(f(U$,"s_GrSLBBZP0DM")),J$=t=>`query QueryLPNeighborhood {
        lpNeighborhood (locale:"${t}"){    
          data{
            attributes{
              Logo{
                ${y}
              }

              SectionHead{
                Title
                Subtitle
                Paragraph
                Logo{
                    ${y}
                }
                Media{
                    ${y}
                }
                Buttons{
                  Text
                  Link
                }
              }

              SpeedBullets{
                Title
                Text
              }

              SectionRating{
                Title
                Subtitle
                Paragraph
                Buttons{
                  Text
                  Link
                }
                Media{
                    ${y}
                }
              }
              
              Footer{
                Text
                Link
              }
            ${z}
            }
          }
        }
        
      }`,Z$=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(J$,e)},$s=q(f(Z$,"s_6ulhbKSeU34")),K$=()=>{const t=$s();return i(G,{children:i(F,{get data(){return t.value.layoutData},showMenus:!1,showHeader:!1,children:i(Y$,{get data(){return t.value.pageData.data.lpNeighborhood.data.attributes},[s]:{data:u(e=>e.value.pageData.data.lpNeighborhood.data.attributes,[t],'p0.value["pageData"]["data"]["lpNeighborhood"]["data"]["attributes"]')}},3,"iI_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showMenus:s,showHeader:s}},1,"iI_1")},1,"iI_2")},X$=b(f(K$,"s_GygFChjqq7g")),t1=({resolveValue:t})=>{const a=t($s).pageData.data.lpNeighborhood.data.attributes.SEO;return H(a)},e1=Object.freeze(Object.defineProperty({__proto__:null,default:X$,head:t1,usePageData:$s},Symbol.toStringTag,{value:"Module"})),a1=t=>n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"min-h-[200px] w-full bg-gradient-to-br from-primary-light-blue to-[#23477f] !text-white"},i(Ke,{get data(){return t.data},color:"white",reverse:!0,backgroundColor:"primary-blue",hasPricing:!1,[s]:{data:u(e=>e.data,[t],"p0.data"),color:s,reverse:s,backgroundColor:s,hasPricing:s}},3,"7j_0"),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"7j_1"),l1=b(f(a1,"s_05kJ0dE4eLY")),n1=t=>{const e=t.data.pageReferralP.data.attributes,a=e.Steps.Bullets.map(l=>l.Text);return n("div",null,null,[i(l1,{get data(){return e.RefInfo},[s]:{data:m(e,"RefInfo")}},3,"Kl_0"),n("div",null,{class:"flex items-center justify-center px-8 py-8"},n("div",null,{class:" max-w-[1400px] "},[n("h4",null,{class:"mb-6 text-center text-[20px] font-[500] leading-6 text-primary-blue"},w(e,"StepsIntro"),1,null),n("h3",null,{class:"mb-6 text-center text-[42px] font-[700] leading-10 text-secondary-red"},w(e.Steps,"Title"),1,null),n("div",null,{class:"max-[799px]:hidden"},i(il,{steps:a,direction:"vertical",align:"center",[s]:{direction:s,align:s}},3,"Kl_1"),1,null),n("div",null,{class:"min-[800px]:hidden"},i(il,{steps:a,direction:"vertical",align:"start",[s]:{direction:s,align:s}},3,"Kl_2"),1,null)],1,null),1,null)],1,"Kl_3")},s1=b(f(n1,"s_lTuY9A29ePc")),r1=t=>`
  query QueryReferralProgram{
    pageReferralP(locale:"${t}"){
      data{
        attributes{
            RefInfo{
          Title
          Subtitle
          Paragraph
          Media{
            ${y}
          }
        }
          StepsIntro
          Steps{
            Title
            Bullets{
              Text
              Caption
            }
          }
          ${z}
        }
      }
    }
  }
    `,i1=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(r1,e)},ys=q(f(i1,"s_xJNMjIe9Xxc")),o1=()=>{const t=ys();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageReferralP.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageReferralP.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageReferralP"]["data"]["attributes"]["SEO"]')}},3,"Mu_0"),i(s1,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"Mu_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Mu_2")},u1=b(f(o1,"s_jMvbzO8YesI")),c1=({resolveValue:t})=>{const a=t(ys).pageData.data.pageReferralP.data.attributes.SEO;return H(a)},d1=Object.freeze(Object.defineProperty({__proto__:null,default:u1,head:c1,usePageData:ys},Symbol.toStringTag,{value:"Module"})),p1=t=>{const e=t.data.pageResidential.data.attributes.Services;return n("div",null,null,i(Xe,{data:e},3,"jS_0"),1,"jS_1")},g1=b(f(p1,"s_2a10udsh6KM")),f1=t=>`
  query QueryResidential {
    pageResidential(locale:"${t}"){    
      data{
        attributes{
          Services{
            Logo{
            ${y}
            }
            Media{
            ${y}
            }
            Title
            Paragraph
            Buttons{
              Text
              Link
            }
          }
          ${z}
        }
      }
    }
  }
    `,x1=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(f1,e)},vs=q(f(x1,"s_LcXJ0iBV25I")),m1=()=>{const t=vs();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageResidential.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageResidential.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageResidential"]["data"]["attributes"]["SEO"]')}},3,"O0_0"),i(g1,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"O0_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"O0_2")},h1=b(f(m1,"s_2tXslNmi0k4")),b1=({resolveValue:t})=>{const a=t(vs).pageData.data.pageResidential.data.attributes.SEO;return H(a)},$1=Object.freeze(Object.defineProperty({__proto__:null,default:h1,head:b1,usePageData:vs},Symbol.toStringTag,{value:"Module"})),y1=t=>n("div",null,{class:"flex flex-col items-center justify-around"},[n("h1",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(e=>e.pageData.data.attributes.Title,[t],'p0.pageData["data"]["attributes"]["Title"]'),3,null),n("div",null,{class:"w-full flex-col gap-2 flex px-4"},[n("div",null,{class:"my-8 max-w-[350px] sm:max-w-[500px] mx-auto"},n("img",{src:ft(t.pageData.data.attributes.Services[0].Picture.data.attributes.url)},{width:1230,height:229,alt:u(e=>e.pageData.data.attributes.Services[0].Picture.data.attributes.alternativeText,[t],'p0.pageData["data"]["attributes"]["Services"][0]["Picture"]["data"]["attributes"]["alternativeText"]')},null,3,null),1,null),n("div",null,{class:"flex w-full overflow-x-auto gap-1 flex-row justify-start mb-4 pb-4 px-4",style:"scrollbar-width: thin; scrollbar-color: #2E5698 #f1f1f1;"},t.broadbandlabelnternet.map((e,a)=>{var l,r,o,c,p,d,g,x,h,$,_,k,D,T,v,L,P,S,E,B,I,C,A,W,Y,U,rt,ct,nt,at,pt,Nt,Bt,Ct,Wt,Ut,Yt,Jt,Zt,Kt,Xt,te,ee,ae,le,ne,se,re,ie,oe,ue,ce,de,pe,ge,fe,xe,me,he,be,$e,ye,ve,_e,we,Se,Te,De,Pe,ke,Le,Qe,ma;return i(Fl,{tier_plan_name:"NULL",connection_type:((o=(r=(l=e.values)==null?void 0:l.connection_type)==null?void 0:r[0])==null?void 0:o.data)||"N/A",get monthly_price(){return e.values.price[0].data[0].amount},get service_plan_name(){return e.values.name[0].data},intro_rate:((d=(p=(c=e.values)==null?void 0:c.intro_rate)==null?void 0:p[0])==null?void 0:d.data)||"No",intro_rate_price:((h=(x=(g=e.values)==null?void 0:g.intro_rate_price)==null?void 0:x[0])==null?void 0:h.data)||"0.00",intro_rate_time:((k=(_=($=e.values)==null?void 0:$.intro_rate_time)==null?void 0:_[0])==null?void 0:k.data)||"N/A",contract_req:((v=(T=(D=e.values)==null?void 0:D.contract_req)==null?void 0:T[0])==null?void 0:v.data)||"No",contract_time:((S=(P=(L=e.values)==null?void 0:L.contract_time)==null?void 0:P[0])==null?void 0:S.data)||"N/A",contract_terms_url:((I=(B=(E=e.values)==null?void 0:E.contract_terms_url)==null?void 0:B[0])==null?void 0:I.data)||"",early_termination_fee:((W=(A=(C=e.values)==null?void 0:C.early_termination_fee)==null?void 0:A[0])==null?void 0:W.data)||"0.00",single_purchase_fee_descr:((rt=(U=(Y=e.values)==null?void 0:Y.single_purchase_fee_descr)==null?void 0:U[0])==null?void 0:rt.data)||"",single_purchase_fees:((at=(nt=(ct=e.values)==null?void 0:ct.single_purchase_fees)==null?void 0:nt[0])==null?void 0:at.data)||"",monthly_provider_fee_descr:((Bt=(Nt=(pt=e.values)==null?void 0:pt.monthly_provider_fee_descr)==null?void 0:Nt[0])==null?void 0:Bt.data)||"",monthly_provider_fee:((Ut=(Wt=(Ct=e.values)==null?void 0:Ct.monthly_provider_fee)==null?void 0:Wt[0])==null?void 0:Ut.data)||"",tax:((Zt=(Jt=(Yt=e.values)==null?void 0:Yt.tax)==null?void 0:Jt[0])==null?void 0:Zt.data)||"Varies",bundle_discounts_url:((te=(Xt=(Kt=e.values)==null?void 0:Kt.bundle_discounts_url)==null?void 0:Xt[0])==null?void 0:te.data)||"",typical_download_speed:((ee=e.values.typical_download_speed)==null?void 0:ee[0].data)||"N/A",typical_upload_speed:((ae=e.values.typical_upload_speed)==null?void 0:ae[0].data)||"N/A",typical_latency:((se=(ne=(le=e.values)==null?void 0:le.typical_latency)==null?void 0:ne[0])==null?void 0:se.data)||"N/A",unique_plan_id:((ie=(re=e.values.unique_plan_id)==null?void 0:re[0])==null?void 0:ie.data)||"N/A",monthly_data_allow:((ce=(ue=(oe=e.values)==null?void 0:oe.monthly_data_allow)==null?void 0:ue[0])==null?void 0:ce.data)||"Unlimited",over_usage_data_price:((ge=(pe=(de=e.values)==null?void 0:de.over_usage_data_price)==null?void 0:pe[0])==null?void 0:ge.data)||"N/A",additional_data_increment:((me=(xe=(fe=e.values)==null?void 0:fe.additional_data_increment)==null?void 0:xe[0])==null?void 0:me.data)||"N/A",data_allowance_policy_url:(($e=(be=(he=e.values)==null?void 0:he.data_allowance_policy_url)==null?void 0:be[0])==null?void 0:$e.data)||"",network_management_policy_url:((_e=(ve=(ye=e.values)==null?void 0:ye.network_management_policy_url)==null?void 0:ve[0])==null?void 0:_e.data)||"",privacy_policy_url:((Te=(Se=(we=e.values)==null?void 0:we.privacy_policy_url)==null?void 0:Se[0])==null?void 0:Te.data)||"",customer_support_phone:((ke=(Pe=(De=e.values)==null?void 0:De.customer_support_phone)==null?void 0:Pe[0])==null?void 0:ke.data)||"",customer_support_web:((ma=(Qe=(Le=e.values)==null?void 0:Le.customer_support_web)==null?void 0:Qe[0])==null?void 0:ma.data)||"",isVoice:!1,[s]:{tier_plan_name:s,monthly_price:m(e.values.price[0].data[0],"amount"),service_plan_name:m(e.values.name[0],"data"),isVoice:s}},3,`Broadband-Internet}-${a}`)}),1,null)],1,null),n("div",null,{class:"w-full flex-col gap-2 flex px-4"},[n("div",null,{class:"my-8 max-w-[350px] sm:max-w-[500px] mx-auto"},n("img",{src:ft(t.pageData.data.attributes.Services[1].Picture.data.attributes.url)},{width:1230,height:229,alt:u(e=>e.pageData.data.attributes.Services[1].Picture.data.attributes.alternativeText,[t],'p0.pageData["data"]["attributes"]["Services"][1]["Picture"]["data"]["attributes"]["alternativeText"]')},null,3,null),1,null),n("div",null,{class:"flex w-full overflow-x-auto gap-1 flex-row justify-start mb-4 pb-4 px-4",style:"scrollbar-width: thin; scrollbar-color: #2E5698 #f1f1f1;"},t.braodbandlabelVoice.map((e,a)=>{var l,r,o,c,p,d,g,x,h,$,_,k,D,T,v,L,P,S,E,B,I,C,A,W,Y,U,rt,ct,nt,at,pt,Nt,Bt,Ct,Wt,Ut,Yt,Jt,Zt,Kt,Xt,te,ee,ae,le,ne,se,re,ie,oe,ue,ce,de,pe,ge,fe,xe,me,he,be,$e,ye,ve,_e,we,Se,Te,De,Pe,ke,Le,Qe,ma,js,Is;return i(Fl,{tier_plan_name:"NULL",connection_type:((o=(r=(l=e.values)==null?void 0:l.connection_type)==null?void 0:r[0])==null?void 0:o.data)||"N/A",monthly_price:((p=(c=e.values)==null?void 0:c.monthly_price)==null?void 0:p[0].data)||((g=(d=e.values)==null?void 0:d.price)==null?void 0:g[0].data[0].amount),get service_plan_name(){return e.values.name[0].data},intro_rate:(($=(h=(x=e.values)==null?void 0:x.intro_rate)==null?void 0:h[0])==null?void 0:$.data)||"No",intro_rate_price:((D=(k=(_=e.values)==null?void 0:_.intro_rate_price)==null?void 0:k[0])==null?void 0:D.data)||"0.00",intro_rate_time:((L=(v=(T=e.values)==null?void 0:T.intro_rate_time)==null?void 0:v[0])==null?void 0:L.data)||"N/A",contract_req:((E=(S=(P=e.values)==null?void 0:P.contract_req)==null?void 0:S[0])==null?void 0:E.data)||"No",contract_time:((C=(I=(B=e.values)==null?void 0:B.contract_time)==null?void 0:I[0])==null?void 0:C.data)||"N/A",contract_terms_url:((Y=(W=(A=e.values)==null?void 0:A.contract_terms_url)==null?void 0:W[0])==null?void 0:Y.data)||"",early_termination_fee:((ct=(rt=(U=e.values)==null?void 0:U.early_termination_fee)==null?void 0:rt[0])==null?void 0:ct.data)||"0.00",single_purchase_fee_descr:((pt=(at=(nt=e.values)==null?void 0:nt.single_purchase_fee_descr)==null?void 0:at[0])==null?void 0:pt.data)||"",single_purchase_fees:((Ct=(Bt=(Nt=e.values)==null?void 0:Nt.single_purchase_fees)==null?void 0:Bt[0])==null?void 0:Ct.data)||"",monthly_provider_fee_descr:((Yt=(Ut=(Wt=e.values)==null?void 0:Wt.monthly_provider_fee_descr)==null?void 0:Ut[0])==null?void 0:Yt.data)||"",monthly_provider_fee:((Kt=(Zt=(Jt=e.values)==null?void 0:Jt.monthly_provider_fee)==null?void 0:Zt[0])==null?void 0:Kt.data)||"",tax:((ee=(te=(Xt=e.values)==null?void 0:Xt.tax)==null?void 0:te[0])==null?void 0:ee.data)||"Varies",bundle_discounts_url:((ne=(le=(ae=e.values)==null?void 0:ae.bundle_discounts_url)==null?void 0:le[0])==null?void 0:ne.data)||"",get typical_download_speed(){return e.download_mbps},get typical_upload_speed(){return e.upload_mbps},typical_latency:((ie=(re=(se=e.values)==null?void 0:se.typical_latency)==null?void 0:re[0])==null?void 0:ie.data)||"N/A",unique_plan_id:((ue=(oe=e.values.unique_plan_id)==null?void 0:oe[0])==null?void 0:ue.data)||"N/A",monthly_data_allow:((pe=(de=(ce=e.values)==null?void 0:ce.monthly_data_allow)==null?void 0:de[0])==null?void 0:pe.data)||"Unlimited",over_usage_data_price:((xe=(fe=(ge=e.values)==null?void 0:ge.over_usage_data_price)==null?void 0:fe[0])==null?void 0:xe.data)||"N/A",additional_data_increment:((be=(he=(me=e.values)==null?void 0:me.additional_data_increment)==null?void 0:he[0])==null?void 0:be.data)||"N/A",data_allowance_policy_url:((ve=(ye=($e=e.values)==null?void 0:$e.data_allowance_policy_url)==null?void 0:ye[0])==null?void 0:ve.data)||"",network_management_policy_url:((Se=(we=(_e=e.values)==null?void 0:_e.network_management_policy_url)==null?void 0:we[0])==null?void 0:Se.data)||"",privacy_policy_url:((Pe=(De=(Te=e.values)==null?void 0:Te.privacy_policy_url)==null?void 0:De[0])==null?void 0:Pe.data)||"",customer_support_phone:((Qe=(Le=(ke=e.values)==null?void 0:ke.customer_support_phone)==null?void 0:Le[0])==null?void 0:Qe.data)||"",customer_support_web:((Is=(js=(ma=e.values)==null?void 0:ma.customer_support_web)==null?void 0:js[0])==null?void 0:Is.data)||"",isVoice:!0,[s]:{tier_plan_name:s,service_plan_name:m(e.values.name[0],"data"),typical_download_speed:m(e,"download_mbps"),typical_upload_speed:m(e,"upload_mbps"),isVoice:s}},3,`Broadband-Voice}-${a}`)}),1,null)],1,null)],1,"Dy_0"),v1=b(f(y1,"s_htIyo0LMbVc")),_1=t=>`query {
  pageAllBroadbandlabel (locale:"${t}"){
    data{
      attributes{
        Title
        Services{
          Picture{
            ${y}
          }
          
          Title
        }

        ${z}
        
      }
    }
  }
}`,w1=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(_1,e)},_s=q(f(w1,"s_9IWRh3ruVPY")),S1=async()=>{const e=await(await fetch("https://cblsrvr1.rtatel.com/planbuilder/api",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({apikey:"3cBEFVR4qQleIRO2yWu0FcOCDdyZbuaU",action:"productsBroadbanLabels"})})).json(),{gigfastInternet:a,gigfastVoice:l}=e.result.reduce((r,o)=>(o.family==="gigFastInternet"&&o.values.networkType&&o.values.unique_plan_id?r.gigfastInternet.push(o):o.family==="gigFastVoice"&&o.groups.length==0&&o.values.unique_plan_id&&r.gigfastVoice.push(o),r),{gigfastInternet:[],gigfastVoice:[]});return{gigfastVoice:l,gigfastInternet:a}},to=q(f(S1,"s_gpghoPhX4N8")),T1=()=>{const t=_s(),e=to(),a=e.value.gigfastVoice,l=e.value.gigfastInternet;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageAllBroadbandlabel.data.attributes.SEO},[s]:{SEOdata:u(r=>r.value.pageData.data.pageAllBroadbandlabel.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageAllBroadbandlabel"]["data"]["attributes"]["SEO"]')}},3,"eH_0"),i(v1,{get pageData(){return t.value.pageData.data.pageAllBroadbandlabel},braodbandlabelVoice:a,broadbandlabelnternet:l,[s]:{pageData:u(r=>r.value.pageData.data.pageAllBroadbandlabel,[t],'p0.value["pageData"]["data"]["pageAllBroadbandlabel"]')}},3,"eH_1")],[s]:{data:u(r=>r.value.layoutData,[t],'p0.value["layoutData"]')}},1,"eH_2")},1,"eH_3")},D1=b(f(T1,"s_wWrbrx5LJeU")),P1=({resolveValue:t})=>{const a=t(_s).pageData.data.pageAllBroadbandlabel.data.attributes.SEO;return H(a)},k1=Object.freeze(Object.defineProperty({__proto__:null,default:D1,head:P1,useAllBroadbandLabels:to,usePageData:_s},Symbol.toStringTag,{value:"Module"})),L1=t=>(V(),n("div",null,{class:"flex md:flex-row flex-col-reverse w-full text-center items-center justify-center md:pt-8 md:mt-10 pt-5"},[n("div",null,{class:"flex flex-col gap-5 md:px-[30px] px-[12vw] py-5"},[n("div",null,{class:"flex flex-col justify-center items-center gap-4"},[i(j,{get text(){return t.parData.Title},classN:"[&>h1]:text-[28px]",[s]:{text:u(e=>e.parData.Title,[t],'p0.parData["Title"]'),classN:s}},3,"4I_0"),i(M,{get media(){return t.parData.Logo.data.attributes},width:"200px",height:"100px",[s]:{media:u(e=>e.parData.Logo.data.attributes,[t],'p0.parData["Logo"]["data"]["attributes"]'),width:s,height:s}},3,"4I_1")],1,null),t.parData.Subtitle&&i(j,{get text(){return t.parData.Subtitle},classN:"[&>h2]:text-[18px]",[s]:{text:u(e=>e.parData.Subtitle,[t],'p0.parData["Subtitle"]'),classN:s}},3,"4I_2")],1,null),n("div",null,{class:"w-[20vw] h-[20vw] min-w-[300px] min-h-[300px] motion-safe:animate-[spin_8s_ease-in-out_infinite] flex w-[350px] h-[350px] "},i(Ue,{get media(){return t.parData.Media.data.attributes},color:"bg-[#f6f307]",width:"w-[350px]",height:"h-[350px]",[s]:{media:u(e=>e.parData.Media.data.attributes,[t],'p0.parData["Media"]["data"]["attributes"]'),color:s,width:s,height:s}},3,"4I_3"),1,null)],1,"4I_4")),C1=b(f(L1,"s_xEBb0M1LJb0")),M1=t=>n("div",null,{class:"flex md:flex-row flex-col-reverse w-full text-center items-center justify-center md:py-8 py-2 "},[n("iframe",null,{src:"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1736.3807968615524!2d-96.67390131916709!3d29.49415252000683!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8643c6852e7d344b%3A0x50f1f549eff32e39!2sSheridan%20Community%20Center!5e0!3m2!1sen!2smx!4v1720731455582!5m2!1sen!2smx",class:" md:min-w-[400px] md:h-[300px] h-full rounded-2xl shadow-xl",loading:"lazy"},null,3,null),n("div",null,{class:"mx-5 "},[i(j,{get text(){return`## ${t.parData.Title}`},classN:"text-center [&>h2]:text-[36px] font-bold max-sm:text-[28px]",[s]:{text:u(e=>`## ${e.parData.Title}`,[t],'`## ${p0.parData["Title"]}`'),classN:s}},3,"zf_0"),i(j,{get text(){return`### ${t.parData.Subtitle}`},classN:"text-center text-[38px] text-secondary-red font-bold max-sm:text-[28px]",[s]:{text:u(e=>`### ${e.parData.Subtitle}`,[t],'`### ${p0.parData["Subtitle"]}`'),classN:s}},3,"zf_1"),i(j,{get text(){return t.parData.Paragraph},[s]:{text:u(e=>e.parData.Paragraph,[t],'p0.parData["Paragraph"]')}},3,"zf_2")],1,null)],1,"zf_3"),j1=b(f(M1,"s_fhIN6LW0PY4")),I1=t=>{const e=t.data.Logo.data.attributes;return n("div",null,{class:"min-h-screen w-full flex flex-col items-center"},[i(M,{width:"200px",height:"80px",media:e,clasN:"pt-5 px-5",[s]:{width:s,height:s,clasN:s}},3,"Ja_0"),i(C1,{get parData(){return t.data.SectionHead},[s]:{parData:u(a=>a.data.SectionHead,[t],'p0.data["SectionHead"]')}},3,"Ja_1"),i(j1,{get parData(){return t.data.SectionRating},[s]:{parData:u(a=>a.data.SectionRating,[t],'p0.data["SectionRating"]')}},3,"Ja_2"),i(wl,{get speedList(){return t.data.Bullets},addIcons:!0,[s]:{speedList:u(a=>a.data.Bullets,[t],'p0.data["Bullets"]'),addIcons:s}},3,"Ja_3"),n("div",null,{class:"w-full bg-white  flex md:flex-row flex-col items-center justify-between"},[n("div",null,{class:" flex flex-row gap-5 p-1"},t.data.Footer&&t.data.Footer.map((a,l)=>i(zt,{get href(){return a.Link},class:" hover:text-primary-blue/60 text-primary-blue font-bold",children:w(a,"Text"),[s]:{href:m(a,"Link"),class:s}},1,l)),1,null),n("div",null,{class:"text-primary-blue text-center"},"© 2024 Rural Telecommunications of America, Inc. All rights reserved.",3,null)],1,null)],1,"Ja_4")},E1=b(f(I1,"s_xUsaCVca204")),N1=t=>`query QueryLPSheridan {
        lpSheridan (locale:"${t}"){    
          data{
            attributes{
              Logo{
                ${y}
              }

              SectionHead{
                Title
                Subtitle
                Paragraph
                Logo{
                    ${y}
                }
                Media{
                    ${y}
                }
                Buttons{
                  Text
                  Link
                }
              }

             Bullets{
                Title
                Text
              }

              SectionRating{
                Title
                Subtitle
                Paragraph
                Buttons{
                  Text
                  Link
                }
                Media{
                    ${y}
                }
              }
              
              Footer{
                Text
                Link
              }
            ${z}
            }
          }
        }
        
      }`,B1=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(N1,e)},ws=q(f(B1,"s_FJJL67QA0KE")),A1=()=>{const t=ws();return i(G,{children:i(F,{get data(){return t.value.layoutData},showMenus:!1,showHeader:!1,children:i(E1,{get data(){return t.value.pageData.data.lpSheridan.data.attributes},[s]:{data:u(e=>e.value.pageData.data.lpSheridan.data.attributes,[t],'p0.value["pageData"]["data"]["lpSheridan"]["data"]["attributes"]')}},3,"M0_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showMenus:s,showHeader:s}},1,"M0_1")},1,"M0_2")},O1=b(f(A1,"s_0tltbtVbnp0")),R1=({resolveValue:t})=>{const a=t(ws).pageData.data.lpSheridan.data.attributes.SEO;return H(a)},q1=Object.freeze(Object.defineProperty({__proto__:null,default:O1,head:R1,usePageData:ws},Symbol.toStringTag,{value:"Module"})),F1=t=>{const e=t.data.data.pageSupport.data.attributes,a=t.data.data.sectionContactBoxes.data;return n("div",null,{class:"flex flex-col px-8 justify-center items-center"},[n("div",null,{class:"h-[100px] p-6 flex flex-row justify-evenly items-center shadow-2xl rounded-full w-[350px] mb-5 bg-blue-100"},[n("p",null,{class:"text-primary-blue font-semibold text-xl"},w(e,"WTTTitle"),1,null),i(K,{get text(){return e.WTTButton.Text},get link(){return e.WTTButton.Link},[s]:{text:m(e.WTTButton,"Text"),link:m(e.WTTButton,"Link")}},3,"t0_0")],1,null),n("div",null,{class:"text-center"},[n("h2",null,{class:"text-3xl md:text-[40px] my-4 font-bold text-primary-blue"},w(e.Introduction,"Title"),1,null),n("h3",null,{class:"text-secondary-red my-4 text-2xl font-semibold"},w(e.Introduction,"Subtitle"),1,null),i(j,{get text(){return e.Introduction.Paragraph},[s]:{text:m(e.Introduction,"Paragraph")}},3,"t0_1")],1,null),n("div",null,{class:"flex flex-col md:flex-row my-4 w-full"},a.map((l,r)=>n("div",null,{class:"flex flex-col w-full md:w-1/2 items-center px-4 justify-start"},[l.attributes.Title.map((o,c)=>n("div",null,null,n("p",null,{class:"text-center text-2xl text-primary-blue font-semibold"},w(o,"Text"),1,null),1,c)),l.attributes.BoxContent.map((o,c)=>n("div",null,{class:"min-h-[250px] my-4 w-full flex flex-col gap-5 justify-start items-center py-4 rounded-2xl shadow-xl"},[n("div",{class:`w-full flex justify-center py-2 items-center rounded-t-2xl ${r%2==0?"bg-primary-blue":"bg-secondary-red"}`},null,n("p",null,{class:"text-center text-2xl text-white font-semibold"},w(o,"Title"),1,null),1,null),i(j,{classN:"text-center px-4",get text(){return o.Paragraph},[s]:{classN:s,text:m(o,"Paragraph")}},3,"t0_2"),n("div",null,{class:"flex flex-wrap items-center justify-center gap-2"},o.Buttons.map((p,d)=>{var g;return i(K,{get text(){return p.Text},get link(){return p.Link},type:(g=p.Link)!=null&&g.includes("tel:")?"action":"link",[s]:{text:m(p,"Text"),link:m(p,"Link")}},3,d)}),1,null)],1,c))],1,r)),1,null),n("div",null,{class:"flex flex-col my-4 md:flex-row gap-5"},e.SelfSupport.map((l,r)=>n("div",null,{class:"h-[290px] w-full md:w-[305px] rounded-3xl shadow-2xl flex p-6 flex-col items-center justify-between"},[i(M,{get media(){return l.Media.data.attributes},height:150,width:310,[s]:{media:m(l.Media.data,"attributes"),height:s,width:s}},3,"t0_3"),n("p",null,{class:"text-2xl md:text-3xl text-center font-semibold text-primary-blue"},w(l,"Title"),1,null),i(j,{classN:"text-center",get text(){return l.Paragraph},[s]:{classN:s,text:m(l,"Paragraph")}},3,"t0_4"),i(K,{get text(){return l.Buttons[0].Text},get link(){return l.Buttons[0].Link},[s]:{text:m(l.Buttons[0],"Text"),link:m(l.Buttons[0],"Link")}},3,"t0_5")],1,r)),1,null)],1,"t0_6")},z1=b(f(F1,"s_Vkf3Ha9y0kU")),Q1=t=>`
        sectionContactBoxes(locale:"${t}"){
          data{
            attributes{
              Title{
                Text
              }
              BoxContent{
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
            }
          }
      }`,G1=t=>`query QuerySupport{
        pageSupport(locale:"${t}"){
          data{
            attributes{
              Marquee
              
              WTTTitle
              WTTButton{
                Text
                Link
              }
              
              Introduction{
                Title
                Subtitle
                Paragraph
              }
              
              SelfSupport{
                Media{
                ${y}
                }
                Title
                Paragraph
                Buttons{
                  Text
                  Link
                }
              }
              
              ${z}
            }
          }
        }
        ${Q1(t)}
      }`,H1=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(G1,e)},Ss=q(f(H1,"s_PaoFf3TWb00")),V1=()=>{const t=Ss();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageSupport.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageSupport.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageSupport"]["data"]["attributes"]["SEO"]')}},3,"Ez_0"),i(z1,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"Ez_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"Ez_2")},1,"Ez_3")},W1=b(f(V1,"s_BS8ceDijUKA")),U1=({resolveValue:t})=>{const a=t(Ss).pageData.data.pageSupport.data.attributes.SEO;return H(a)},Y1=Object.freeze(Object.defineProperty({__proto__:null,default:W1,head:U1,usePageData:Ss},Symbol.toStringTag,{value:"Module"})),J1=t=>n("div",null,{class:"flex h-[190px]  max-w-[350px] flex-col items-center justify-center rounded-[20px] bg-white p-6 m-2 text-primary-blue"},[i(Wp,{class:"text-[28px] text-secondary-red",[s]:{class:s}},3,"Gr_0"),n("span",null,{class:"text-[17px] font-[600]"},u(e=>e.testimonial.Title,[t],'p0.testimonial["Title"]'),3,null),i(j,{classN:"text-[12px] text-center",get text(){return t.testimonial.Text},[s]:{classN:s,text:u(e=>e.testimonial.Text,[t],'p0.testimonial["Text"]')}},3,"Gr_1")],1,"Gr_2"),Z1=t=>{const e=t.data.pageTestimon.data.attributes,a=b(f(J1,"s_ikLHAV9ZIuk")),l=e.Testimonials.map((r,o)=>i(a,{testimonial:r},3,o));return n("div",null,{class:"flex w-full items-center justify-center px-8",onClick$:O("s_KMXVxiVFs3M")},n("div",null,{class:"my-16 flex max-w-[1400px] items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex w-[60%] flex-col items-center justify-center gap-2 max-[800px]:w-full"},[n("h2",null,{class:"text-[36px] max-[800px]:text-[20px] font-[600] text-primary-dark-blue"},w(e,"VideoTitle"),1,null),n("video",{src:ft(e.Video.data.attributes.url)},{class:"rounded-[30px] max-[800px]:max-w-[400px]",controls:!0},null,3,null)],1,null),n("div",null,{class:"items-center w-[40%] flex-col px-1 justify-center max-[800px]:w-full max-h-[500px]  "},i(kt,{slides:l,id:"carTestimonials",hasArrows:!1,hasPagination:!0,slidesQty:1,[s]:{id:s,hasArrows:s,hasPagination:s,slidesQty:s}},3,"Gr_3"),1,null)],1,null),1,"Gr_4")},K1=b(f(Z1,"s_HE2Hm2x9r68")),X1=t=>`query queryTestimonials{
    pageTestimon(locale:"${t}"){
      data{
        attributes{
          Testimonials{
            Title
            Text
          }
          VideoTitle
          TestimBG{
           ${y}
          }
          Video{
            ${y}
          }
          ${z}
        }
      }
    }
  }`,ty=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(X1,e)},Ts=q(f(ty,"s_R6fQva4FAkw")),ey=()=>{const t=Ts();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageTestimon.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageTestimon.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageTestimon"]["data"]["attributes"]["SEO"]')}},3,"cR_0"),i(K1,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"cR_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"cR_2")},ay=b(f(ey,"s_jKMCOKr9uSw")),ly=({resolveValue:t})=>{const a=t(Ts).pageData.data.pageTestimon.data.attributes.SEO;return H(a)},ny=Object.freeze(Object.defineProperty({__proto__:null,default:ay,head:ly,usePageData:Ts},Symbol.toStringTag,{value:"Module"})),sy=t=>{var l;const a=(l=ot().prevUrl)==null?void 0:l.pathname.includes("/es/");return n("div",null,{class:"p-8"},[n("h1",null,{class:"text-center font-bold text-4xl mb-6 text-secondary-red"},a?"Encuentra tu locación":"Find your location",1,null),n("table",null,{class:"w-full rounded-2xl"},[n("thead",null,{class:"bg-primary-blue text-white font-semibold"},[n("th",null,null,a?"Nombre":"Name",1,null),n("th",null,null,a?"Código postal":"Zip code",1,null),n("th",null,null,a?"Ubicación de oficina local":"Local Office Location",1,null)],1,null),n("tbody",null,null,t.data.map((r,o)=>n("tr",{class:`text-center text-primary-dark-blue w-full h-full ${o%2==0?"bg-blue-100":"bg-blue-200"}`},null,[n("td",null,{class:"hover:text-secondary-red"},n("a",{href:a?("/es/texas/"+r.attributes.Slug).replace("-es","/"):r.attributes.Slug+"/"},null,[w(r.attributes,"Name"),", TX"],1,null),1,null),n("td",null,null,w(r.attributes,"ZipCode"),1,null),n("td",null,null,w(r.attributes.office.data.attributes,"Location"),1,null)],1,o)),1,null)],1,null)],1,"pd_0")},ry=b(f(sy,"s_YVNQC4aSS0M")),iy=t=>`query{
        locations(locale:"${t}", pagination:{limit:500}){
          data{
            attributes{
              Name
              ZipCode
              Description
              Slug
              office{
                data{
                  attributes{
                    Location
                  }
                }
              }
              ${z}
            }
          }
        }
      }`,oy=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(iy,e)},eo=q(f(oy,"s_0tHKviRSkdY")),uy=async t=>(t.params.lang==""?"en":"es-419").toString(),ao=q(f(uy,"s_5IMJ5tToq0s")),cy=()=>{const t=eo(),e=t.value.pageData.data.locations.data;return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(ry,{data:e},3,"N7_0"),[s]:{data:u(a=>a.value.layoutData,[t],'p0.value["layoutData"]')}},1,"N7_1")},1,"N7_2")},dy=b(f(cy,"s_7yoRSOyY1lA")),py=({resolveValue:t})=>{const e=t(ao),a={MetaTitle:e=="en"?"Areas Served | RTA Rural Telecommunications of America":"Áreas de servicio | RTA Rural Telecommunications of America",MetaDescription:e=="en"?"Discover RTA's extensive service areas and expand your connectivity horizons. Explore reliable telecommunications solutions tailored for diverse regions!":"Descubre áreas de servicio de RTA y expande tus horizontes de conectividad. ¡Explora soluciones de telecomunicaciones confiables para diversas regiones!",Keywords:e=="en"?"Service coverage areas, Regional connectivity, Rural broadband solutions":"Áreas de cobertura de servicios, Conectividad regional, Soluciones de banda ancha rural"};return H(a)},gy=Object.freeze(Object.defineProperty({__proto__:null,default:dy,head:py,useLang:ao,usePageData:eo},Symbol.toStringTag,{value:"Module"})),fy=t=>{const e=t.data.data.pageWholesale.data.attributes,a=t.data.data.sectionNetwork.data.attributes,l=e.NetworkDIA.Features,r=N(0);return Lt(O("s_jeOJGnobZvM",[l,r])),n("div",null,{class:"flex flex-col items-center justify-center"},[n("div",null,{class:"my-8 flex w-full flex-col items-center justify-center px-4 md:w-1/2"},[i(j,{classN:"text-center my-4",get text(){return e.Introduction.Paragraph},[s]:{classN:s,text:m(e.Introduction,"Paragraph")}},3,"Xs_0"),i(K,{get text(){return e.Introduction.Buttons[0].Text},get link(){return e.Introduction.Buttons[0].Link},type:"action",[s]:{text:m(e.Introduction.Buttons[0],"Text"),link:m(e.Introduction.Buttons[0],"Link"),type:s}},3,"Xs_1")],1,null),i(M,{get media(){return e.NetworkLogo.data.attributes},height:180,width:400,[s]:{media:m(e.NetworkLogo.data,"attributes"),height:s,width:s}},3,"Xs_2"),n("div",null,{class:"flex w-full flex-col items-center justify-center"},n("div",null,{class:"my-4 flex max-w-[1200px] flex-row-reverse items-center justify-center max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-4 px-10 min-[800px]:w-[70%]"},[n("div",null,{class:"flex justify-center gap-2 text-primary-blue"},n("span",null,{class:"text-center text-[38px] font-bold max-sm:text-[28px]"},w(e.NetworkDIA,"Title"),1,null),1,null),i(j,{get text(){return e.NetworkDIA.Paragraph},classN:"text-[18px] max-sm:text-[15px] text-primary-blue",[s]:{text:m(e.NetworkDIA,"Paragraph"),classN:s}},3,"Xs_3"),n("div",null,{class:"flex flex-col items-center justify-end text-center"},[n("h2",null,{class:"font-semibold text-primary-blue"},w(e.NetworkDIA,"Subtitle"),1,null),n("p",null,{class:"text-2xl font-bold text-primary-blue"},w(e.NetworkDIA,"FeaturesTitle"),1,null)],1,null),n("div",null,{class:"text-center text-xl font-semibold text-secondary-red"},n("h2",null,{class:"animated-fadein-down animated-fadeout-down"},w(l[r.value],"Text"),1,null),1,null)],1,null),n("div",null,{class:"flex w-[300px] items-center justify-center self-center p-4 min-[800px]:w-[30%]"},i(M,{get media(){return e.NetworkDIA.Media.data.attributes},width:"597",height:"500",[s]:{media:m(e.NetworkDIA.Media.data,"attributes"),width:s,height:s}},3,"Xs_4"),1,null)],1,null),1,null),i(It,{get text(){return e.NetworkCircuits.Paragraph},backgroundColor:"transparent",get title(){return e.NetworkCircuits.Title},get image(){return e.NetworkCircuits.Media.data.attributes},[s]:{text:m(e.NetworkCircuits,"Paragraph"),backgroundColor:s,title:m(e.NetworkCircuits,"Title"),image:m(e.NetworkCircuits.Media.data,"attributes")}},3,"Xs_5"),n("div",null,{class:"my-4 flex flex-wrap-reverse items-center justify-center gap-8 px-8 py-6"},[n("div",{onClick$:O("s_VUkdu4BrA18",[e])},{class:"flex items-center justify-center"},i(M,{get media(){return e.NetworkMap.data.attributes.Map.MapPicture.data.attributes},width:500,height:500,[s]:{media:m(e.NetworkMap.data.attributes.Map.MapPicture.data,"attributes"),width:s,height:s}},3,"Xs_6"),0,null),n("div",null,{class:"flex w-full flex-col items-center justify-center md:w-1/2"},[i(j,{get text(){return a.Description.Paragraph},classN:"text-primary-blue",[s]:{text:m(a.Description,"Paragraph"),classN:s}},3,"Xs_7"),i(xa,{get title(){return a.Map.ServersTitle},classContainer:"rounded-full bg-white text-primary-blue shadow-xl",children:n("div",null,{class:"flex flex-col rounded-b-2xl bg-white py-4 text-primary-blue"},a.Map.Servers.map((o,c)=>n("a",{href:w(o,"Link")},{class:"text-primary-blue hover:text-secondary-red"},w(o,"Text"),1,c)),1,null),[s]:{title:m(a.Map,"ServersTitle"),classContainer:s}},1,"Xs_8")],1,null)],1,null),i(Xe,{get data(){return e.GFServices},[s]:{data:m(e,"GFServices")}},3,"Xs_9")],1,"Xs_10")},xy=b(f(fy,"s_SvASKT7lKMw")),my=t=>`query QueryWholesale {
        pageWholesale(locale:"${t}"){    
          data{
            attributes{
            Introduction{
              Title
              Paragraph
              Buttons{
                Text
                Link
              }
            }
              
            NetworkLogo{
                ${y}
            }
            NetworkDIA{
              Title
              Paragraph
              Subtitle
              FeaturesTitle
              Features{
                Text
              }
              Media{
                ${y}
              }
            }
            NetworkCircuits{
              Title
              Subtitle
              Paragraph
              Media{
                 ${y}
              }
            }
           
              
            GFServices{
              Title
              Logo{
                ${y}
              }
              Paragraph
              Media{
                ${y}
              }
              Buttons{
                Text
                Link
              }
            }
              ${z}
              NetworkMap {
                data {
                  attributes {
                    Map {
                      MapPicture {
                        ${y}
                      }
                    }
                  }
                }
              }
            }
          }
        }
        ${fp(t)}
      }`,hy=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(my,e)},Ds=q(f(hy,"s_odgwpNJ8jW8")),by=()=>{const t=Ds();return i(G,{children:i(F,{get data(){return t.value.layoutData},children:i(xy,{get data(){return t.value.pageData},[s]:{data:u(e=>e.value.pageData,[t],'p0.value["pageData"]')}},3,"3I_0"),[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"3I_1")},1,"3I_2")},$y=b(f(by,"s_W611gmEC5Rk")),yy=({resolveValue:t})=>{const a=t(Ds).pageData.data.pageWholesale.data.attributes.SEO,l=`${a.MetaTitle}`;return{title:l,meta:[{name:"title",content:`${l}`},{name:"description",content:`${a.MetaDescription}`}]}},vy=Object.freeze(Object.defineProperty({__proto__:null,default:$y,head:yy,usePageData:Ds},Symbol.toStringTag,{value:"Module"})),_y=t=>n("div",{style:{backgroundImage:`url(${ft(t.slide.attributes.url)})`}},{class:"h-[350px] my-5 w-[280px] overflow-hidden rounded-[10px] bg-contain bg-no-repeat bg-center"},null,3,"0D_0"),wy=t=>{const e=t.data.pageWinnersC.data.attributes,a=e.Winners.data.reverse(),l=b(f(_y,"s_Kis0UnPgGnE")),r=a.map((o,c)=>i(l,{slide:o},3,c));return n("div",null,{class:"relative flex flex-col items-center justify-center",onClick$:O("s_na2GxJ32Wno")},[n("div",null,{class:"relative flex w-full items-center justify-center overflow-hidden"},[i(M,{width:"1024",height:"603",clasN:"max-w-[1000px] w-fit z-10 object-cover",get media(){return e.WinnersBG.data.attributes},[s]:{width:s,height:s,clasN:s,media:m(e.WinnersBG.data,"attributes")}},3,"0D_1"),n("div",null,{class:"absolute z-20 mb-[160px]  w-[290px] overflow-hidden  rounded-[10px] border border-gray-500 bg-[#171f2a] p-2"},i(kt,{slides:r,id:"carouselWinners",slidesQty:1,hasArrows:!1,addSpace:!1,[s]:{id:s,slidesQty:s,hasArrows:s,addSpace:s}},3,"0D_2"),1,null),n("div",null,{class:"absolute bottom-0 left-0 right-0 h-[30%] bg-black"},null,3,null)],1,null),n("div",null,{class:"flex w-full overflow-hidden bg-cover pt-16 bg-black justify-center"},n("div",null,{class:"flex max-w-[1200px] gap-4  max-[1000px]:flex-col  justify-center items-center"},[n("div",null,{class:"flex w-[30%] flex-col "},[n("h2",null,{class:"text-center text-[36px] font-[600] leading-[36px] text-secondary-red"},w(e,"GiveawayCarTitle"),1,null),n("br",null,null,null,3,null),n("div",null,{class:"mb-6 flex items-center justify-center rounded-xl bg-white p-2"},i(kt,{id:"giveAnswers",hasPagination:!1,slidesQty:1,duration:5e3,addSpace:!1,hasArrows:!0,slides:e.GiveawayAnswers.reverse().map((o,c)=>n("div",null,{class:"flex flex-col items-center justify-center gap-1.5 max-w-[180px]"},[n("p",null,{class:"text-center text-[15px] text-primary-blue"},["This question was answered on"," ",n("br",null,null,null,3,null),Ha(o.AnswerDate,!1)],1,null),n("iframe",{src:`https://www.youtube.com/embed/${o.QuestionVideos.split("v=")[1]}`},{class:"rounded-[20px] shadow-xl",frameBorder:"0",height:270,width:160,allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",allowFullscreen:!0},null,3,null),n("span",null,{class:"text-secondary-red"},"Answer:",3,null),n("span",null,{class:"text-primary-blue"},w(o,"Answer"),1,null)],1,c)),[s]:{id:s,hasPagination:s,slidesQty:s,duration:s,addSpace:s,hasArrows:s}},3,"0D_3"),1,null)],1,null),n("div",null,{class:"flex md:w-[60%] w-[30%] h-full flex-col justify-center  overflow-hidden"},[n("h3",null,{class:"text-center text-[28px] font-[500] leading-[30px] text-primary-blue"},w(e,"TwitterFeedTitle"),1,null),n("br",null,null,null,3,null),n("iframe",{srcdoc:w(e,"TwitterFeedLink")},{class:"h-full",height:"100%",width:"100%"},null,3,null)],1,null)],1,null),1,null)],1,"0D_4")},Sy=b(f(wy,"s_QYIFsZOPjHw")),Ty=t=>`query queryWinnerCircle{
    pageWinnersC(locale:"${t}"){
      data{
        attributes{
          WinnersTitle
  
          WinnersBG{
            ${y}
          }
          
          WinnersCarBG{
           ${y}
          }
          Winners{
            ${y}
          }
         
          GiveawayCarTitle
          
          GiveawayAnswers{
            Description
            AnswerDate
            QuestionVideos
            Answer
          }
          TwitterFeedLink
          TwitterFeedTitle
  
          ${z}
        }
      }
    }
  }`,Dy=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Ty,e)},Ps=q(f(Dy,"s_6WeV0M8I1Do")),Py=()=>{const t=Ps();return i(F,{get data(){return t.value.layoutData},children:[i(et,{get SEOdata(){return t.value.pageData.data.pageWinnersC.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageWinnersC.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageWinnersC"]["data"]["attributes"]["SEO"]')}},3,"00_0"),i(Sy,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"00_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]')}},1,"00_2")},ky=b(f(Py,"s_0m9hLjn9QnA")),Ly=({resolveValue:t})=>{const a=t(Ps).pageData.data.pageWinnersC.data.attributes.SEO;return H(a)},Cy=Object.freeze(Object.defineProperty({__proto__:null,default:ky,head:Ly,usePageData:Ps},Symbol.toStringTag,{value:"Module"})),My=t=>n("div",null,{class:"flex max-w-[400px] flex-col items-center max-[900px]:place-self-center"},[n("section",null,{class:"flex h-fit w-full flex-col rounded-[35px] bg-white text-center shadow-lg"},[n("div",null,{class:"flex w-full items-center justify-center rounded-t-[35px] bg-gradient-to-r from-[#4caafd] to-[#1a7ee4] px-6 py-3 text-center"},i(M,{get media(){return t.data.RaceRepLogo.data.attributes},clasN:"h-[16px] w-fit",[s]:{media:u(e=>e.data.RaceRepLogo.data.attributes,[t],'p0.data["RaceRepLogo"]["data"]["attributes"]'),clasN:s}},3,"QP_0"),1,null),n("div",null,{class:"flex flex-col items-center justify-center p-4"},[i(rl,{get ytURL(){return t.data.RaceRepVids[0].Link},classN:"rounded-[30px] shadow-lg",[s]:{ytURL:u(e=>e.data.RaceRepVids[0].Link,[t],'p0.data["RaceRepVids"][0]["Link"]'),classN:s}},3,"QP_1"),i(j,{get text(){return t.data.RaceRepVids[0].Paragraph},classN:"text-[13px] p-1 mt-2",[s]:{text:u(e=>e.data.RaceRepVids[0].Paragraph,[t],'p0.data["RaceRepVids"][0]["Paragraph"]'),classN:s}},3,"QP_2"),n("div",null,{class:"h-[6px] w-full border-t border-gray-300"},null,3,null),n("div",null,{class:"h-[6px] w-full border-t border-gray-300"},null,3,null),n("div",null,{class:"mb-4 h-[6px] w-full border-t border-gray-300"},null,3,null),i(rl,{get ytURL(){return t.data.RaceRepVids[1].Link},classN:"rounded-[30px] shadow-lg",[s]:{ytURL:u(e=>e.data.RaceRepVids[1].Link,[t],'p0.data["RaceRepVids"][1]["Link"]'),classN:s}},3,"QP_3"),i(j,{get text(){return t.data.RaceRepVids[1].Paragraph},classN:"text-[13px] p-1 mt-2",[s]:{text:u(e=>e.data.RaceRepVids[1].Paragraph,[t],'p0.data["RaceRepVids"][1]["Paragraph"]'),classN:s}},3,"QP_4")],1,null)],1,null),n("a",null,{href:u(e=>e.data.HeaderButtons[0].Link,[t],'p0.data["HeaderButtons"][0]["Link"]'),target:"_blank",class:"mt-8 w-full rounded-full border-[6px] border-[#e7758f] bg-secondary-red px-8 py-1 text-center text-[14px] font-[600] leading-[18px] text-white shadow-lg"},u(e=>e.data.HeaderButtons[0].Text,[t],'p0.data["HeaderButtons"][0]["Text"]'),3,null)],1,"QP_5"),jy=t=>n("div",null,{class:"flex h-fit max-w-[600px] flex-col items-center justify-center  text-center text-white"},[i(M,{get media(){return t.data.LogoCorp.data.attributes},clasN:"h-[80px] w-[215px]",[s]:{media:u(e=>e.data.LogoCorp.data.attributes,[t],'p0.data["LogoCorp"]["data"]["attributes"]'),clasN:s}},3,"QP_6"),n("span",null,{class:"mb-4 text-[46px] font-[700] leading-[50px]"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),i(M,{get media(){return t.data.LogoSponsor.data.attributes},[s]:{media:u(e=>e.data.LogoSponsor.data.attributes,[t],'p0.data["LogoSponsor"]["data"]["attributes"]')}},3,"QP_7"),n("span",null,{class:"my-4 rounded-full bg-white px-4 text-[15px] font-[400] tracking-widest text-primary-blue"},t.data.Subtitle.toUpperCase(),1,null),i(M,{get media(){return t.data.HeaderPictures.data[0].attributes},clasN:"w-full h-fit px-4 pt-4",[s]:{media:u(e=>e.data.HeaderPictures.data[0].attributes,[t],'p0.data["HeaderPictures"]["data"][0]["attributes"]'),clasN:s}},3,"QP_8")],1,"QP_9"),Iy=t=>{V();const e=N(1e3);Lt(O("s_0vxrMcOslm0",[e]));const a=b(f(My,"s_S9x7nXVXxQ0")),l=b(f(jy,"s_YXp1rsg61DU"));return n("div",null,{class:"flex min-h-[500px] w-full items-center justify-center bg-[conic-gradient(at_top,_var(--tw-gradient-stops))] from-[#001536] via-[#0E67BB] to-[#001536]"},n("div",null,{class:"flex max-w-[1200px] flex-col items-center justify-center px-8 pt-12"},n("div",null,{class:"grid items-start justify-center gap-6 max-[900px]:items-center",style:u(r=>({gridTemplateColumns:r.value>900?"250px 1fr 250px":"1fr"}),[e],'{gridTemplateColumns:p0.value>900?"250px 1fr 250px":"1fr"}')},[e.value<=900&&i(l,{get data(){return t.data},[s]:{data:u(r=>r.data,[t],"p0.data")}},3,"QP_10"),i(a,{get data(){return t.data},[s]:{data:u(r=>r.data,[t],"p0.data")}},3,"QP_11"),e.value>900&&i(l,{get data(){return t.data},[s]:{data:u(r=>r.data,[t],"p0.data")}},3,"QP_12"),n("div",null,{class:"flex max-w-[400px] flex-col items-center max-[900px]:place-self-center"},[n("section",null,{class:"flex h-fit w-full flex-col items-center justify-center rounded-[35px] bg-white p-4 text-center shadow-lg"},[n("div",null,{class:"h-[420px]"},i(rl,{get ytURL(){return t.data.GiveawayBox[0].Video.Link},classN:"rounded-[30px] shadow-lg",[s]:{ytURL:u(r=>r.data.GiveawayBox[0].Video.Link,[t],'p0.data["GiveawayBox"][0]["Video"]["Link"]'),classN:s}},3,"QP_13"),1,null),i(j,{get text(){return t.data.GiveawayBox[0].Video.Paragraph},classN:"text-[13px] p-1 mt-2",[s]:{text:u(r=>r.data.GiveawayBox[0].Video.Paragraph,[t],'p0.data["GiveawayBox"][0]["Video"]["Paragraph"]'),classN:s}},3,"QP_14"),i(K,{get text(){return t.data.GiveawayBox[0].Button.Text},get link(){return t.data.GiveawayBox[0].Button.Link},[s]:{text:u(r=>r.data.GiveawayBox[0].Button.Text,[t],'p0.data["GiveawayBox"][0]["Button"]["Text"]'),link:u(r=>r.data.GiveawayBox[0].Button.Link,[t],'p0.data["GiveawayBox"][0]["Button"]["Link"]')}},3,"QP_15")],1,null),n("a",null,{href:u(r=>r.data.HeaderButtons[1].Link,[t],'p0.data["HeaderButtons"][1]["Link"]'),class:"my-8 w-full rounded-full border-[6px] border-[#e7758f] bg-secondary-red px-8 py-1 text-center text-[14px] font-[600] leading-[18px] text-white shadow-lg"},u(r=>r.data.HeaderButtons[1].Text,[t],'p0.data["HeaderButtons"][1]["Text"]'),3,null)],1,null)],1,null),1,null),1,"QP_16")},Ey=b(f(Iy,"s_v9v6ItSeef4")),Ny=t=>n("div",null,{class:"flex flex-col items-center justify-center text-center text-white"},[n("span",null,{class:"text-[24px]"},i(j,{classN:"text-white",get text(){return t.data.QuoteText},[s]:{classN:s,text:u(e=>e.data.QuoteText,[t],'p0.data["QuoteText"]')}},3,"0q_0"),1,null),n("div",null,{class:"mt-4 flex flex-col"},[n("span",null,{class:"text-[19px] font-[600] text-[#7bc8ff]"},u(e=>e.data.QuoteAuthor,[t],'p0.data["QuoteAuthor"]'),3,null),n("span",null,{class:"max-w-[200px] text-[14px] tracking-[2px]"},u(e=>e.data.QuoteADesc,[t],'p0.data["QuoteADesc"]'),3,null)],3,null)],1,"0q_1"),By=b(f(Ny,"s_P6qdCyIENpU")),Ay=t=>n("div",null,{class:"flex items-center justify-center gap-10 px-8 max-[800px]:flex-col"},[n("div",null,{class:"flex min-w-[300px] max-w-[400px] flex-col items-center justify-center rounded-[30px] bg-white p-8 text-primary-blue "},[i(M,{clasN:"h-fit w-[180px]",get media(){return t.data.AboutZane.Media.data.attributes},[s]:{clasN:s,media:u(e=>e.data.AboutZane.Media.data.attributes,[t],'p0.data["AboutZane"]["Media"]["data"]["attributes"]')}},3,"E0_0"),n("h2",null,{class:"mt-4 text-[30px] font-[500] text-secondary-red"},u(e=>e.data.AboutZane.Title,[t],'p0.data["AboutZane"]["Title"]'),3,null),i(j,{classN:"[&>h2]:text-[21px] [&>h2]:leading-10 [&>h2]:font-[600]",get text(){return t.data.AboutZane.Paragraph},[s]:{classN:s,text:u(e=>e.data.AboutZane.Paragraph,[t],'p0.data["AboutZane"]["Paragraph"]')}},3,"E0_1"),n("div",null,{class:"mb-4 flex w-full items-center justify-evenly gap-2 rounded-full bg-primary-blue p-2"},t.data.AboutZane.Buttons.filter(e=>!e.Text).map((e,a)=>n("div",{onClick$:O("s_aBdgclRoL4w",[e])},{class:"hover:cursor-pointer"},i(M,{clasN:"h-[20px]",toWhite:a!==0,get media(){return e.Icon.data.attributes},[s]:{clasN:s,media:m(e.Icon.data,"attributes")}},3,"E0_2"),0,a)),1,null),t.data.AboutZane.Buttons.filter(e=>e.Text).map((e,a)=>n("div",{onClick$:O("s_0qHArrAd29Q",[e])},{class:"flex gap-2 self-start hover:cursor-pointer"},[i(M,{clasN:"h-[24px] w-[24px]",get media(){return e.Icon.data.attributes},[s]:{clasN:s,media:m(e.Icon.data,"attributes")}},3,"E0_3"),n("span",null,{class:"text-[14px] font-[500]"},w(e,"Text"),1,null)],0,a))],1,null),n("div",null,{class:"flex flex-col text-white"},[n("span",null,{class:"mb-4 text-[40px] font-[600]"},u(e=>e.data.Highlights.Title,[t],'p0.data["Highlights"]["Title"]'),3,null),i(j,{classN:"text-white text-justify",get text(){return t.data.Highlights.Paragraph},[s]:{classN:s,text:u(e=>e.data.Highlights.Paragraph,[t],'p0.data["Highlights"]["Paragraph"]')}},3,"E0_4")],1,null)],1,"E0_5"),Oy=b(f(Ay,"s_CpEM5GsNAyg")),Ry=t=>n("div",null,{class:"mt-[80px] flex flex-col items-center justify-center"},[n("div",null,{class:"mb-6 flex items-center justify-center gap-6"},[n("span",null,{class:"text-[40px] font-[600] text-white max-[800px]:hidden"},u(e=>e.data.AboutFRM.Title,[t],'p0.data["AboutFRM"]["Title"]'),3,null),i(M,{get media(){return t.data.AboutFRM.Logo.data.attributes},[s]:{media:u(e=>e.data.AboutFRM.Logo.data.attributes,[t],'p0.data["AboutFRM"]["Logo"]["data"]["attributes"]')}},3,"KU_0")],1,null),n("div",null,{class:"flex gap-8 max-[800px]:flex-col"},[n("div",null,{class:"flex w-[60%] flex-col items-center gap-4 max-[800px]:w-full"},[i(j,{classN:"text-white text-[18px] text-justify",get text(){return t.data.AboutFRM.Paragraph},[s]:{classN:s,text:u(e=>e.data.AboutFRM.Paragraph,[t],'p0.data["AboutFRM"]["Paragraph"]')}},3,"KU_1"),i(M,{clasN:"w-[80%] min-w-[300px] rounded-3xl",get media(){return t.data.FRMChamps.data.attributes},[s]:{clasN:s,media:u(e=>e.data.FRMChamps.data.attributes,[t],'p0.data["FRMChamps"]["data"]["attributes"]')}},3,"KU_2"),i(j,{classN:"text-white text-[12px]",get text(){return t.data.FRMChamps.data.attributes.caption},[s]:{classN:s,text:u(e=>e.data.FRMChamps.data.attributes.caption,[t],'p0.data["FRMChamps"]["data"]["attributes"]["caption"]')}},3,"KU_3"),i(j,{classN:"text-white text-[12px] text-justify",get text(){return t.data.AboutFRMPInfo},[s]:{classN:s,text:u(e=>e.data.AboutFRMPInfo,[t],'p0.data["AboutFRMPInfo"]')}},3,"KU_4")],1,null),n("div",null,{class:"flex w-[40%] flex-col items-center max-[800px]:w-full"},[i(j,{classN:"text-white text-[15px] font-[600]",get text(){return t.data.AboutFRM.Subtitle},[s]:{classN:s,text:u(e=>e.data.AboutFRM.Subtitle,[t],'p0.data["AboutFRM"]["Subtitle"]')}},3,"KU_5"),i(M,{clasN:"w-[80%] min-w-[180px] rounded-3xl my-2",get media(){return t.data.AboutFRM.Media.data.attributes},[s]:{clasN:s,media:u(e=>e.data.AboutFRM.Media.data.attributes,[t],'p0.data["AboutFRM"]["Media"]["data"]["attributes"]')}},3,"KU_6"),i(j,{classN:"text-white text-[13px]",get text(){return t.data.AboutFRM.Media.data.attributes.caption},[s]:{classN:s,text:u(e=>e.data.AboutFRM.Media.data.attributes.caption,[t],'p0.data["AboutFRM"]["Media"]["data"]["attributes"]["caption"]')}},3,"KU_7"),n("div",null,{class:"my-4 flex flex-col items-start justify-start gap-1 self-start"},t.data.AboutFRM.Buttons.map((e,a)=>n("div",{onClick$:O("s_TcbYAUHeCh4",[e])},{class:"flex items-center"},[i(M,{clasN:"h-[16px] w-[16px] mr-2",toWhite:!0,get media(){return e.Icon.data.attributes},[s]:{clasN:s,toWhite:s,media:m(e.Icon.data,"attributes")}},3,"KU_8"),n("span",null,{class:"text-white"},w(e,"Text"),1,null)],0,a)),1,null)],1,null)],1,null)],1,"KU_9"),qy=b(f(Ry,"s_uxm1007Tl9Q")),Fy=t=>n("div",null,{class:"my-[80px] flex flex-col items-center justify-center text-white"},[n("span",null,{class:"text-center text-[40px] font-[600]"},u(e=>e.data.CarouselTitle,[t],'p0.data["CarouselTitle"]'),3,null),n("div",null,{class:"max-w-[1300px] px-8"},i(kt,{direction:"horizontal",addSpace:!0,slidesQty:3,hasArrows:!0,id:"zss_carousel",slides:t.data.CarouselContent.map((e,a)=>n("div",{onClick$:O("s_LReiaiAXvdI",[e])},{class:"relative overflow-hidden rounded-3xl hover:cursor-pointer"},[n("div",null,{class:"absolute inset-0 z-20 flex items-center justify-center bg-black bg-opacity-10 text-[60px] font-[900] text-white"},"▷",3,null),i(M,{get media(){return e.Cover.data.attributes},[s]:{media:m(e.Cover.data,"attributes")}},3,"YI_0")],0,a)),[s]:{direction:s,addSpace:s,slidesQty:s,hasArrows:s,id:s}},3,"YI_1"),1,null)],1,"YI_2"),zy=b(f(Fy,"s_leW0062t5ac")),Qy=t=>{const e=t.data.pageZaneSpon.data.attributes;return n("div",null,{onClick$:O("s_m03OOMoHREo")},[i(Ey,{data:e},3,"5E_0"),n("div",null,{class:"bg-gradient-to-b from-[#041630] to-[#153069]"},n("div",null,{class:" md:flex w-full justify-center items-center"},n("div",null,{class:"max-w-[1200px] px-8 pt-8"},[i(By,{data:e},3,"5E_1"),i(zy,{data:e},3,"5E_2"),i(Oy,{data:e},3,"5E_3"),i(qy,{data:e},3,"5E_4")],1,null),1,null),1,null)],1,"5E_5")},Gy=b(f(Qy,"s_kYGFw8H412s")),Hy=t=>`query {
    pageZaneSpon(locale:"${t}") {
      data {
        attributes {
          Title
          Subtitle
          LogoCorp {
            ${y}
          }
          LogoSponsor {
            ${y}
          }
          HeaderPictures {
            ${y}
          }
          HeaderButtons {
            Text
            Link
          }
          NascarSchedule {
            ${y}
          }
          yt {
            ${y}
          }
          GiveawayBox {
            Video {
              Link
              Paragraph
            }
            Button {
              Text
              Link
            }
          }
          QuoteText
          QuoteAuthor
          QuoteADesc
          RaceRepLogo {
            ${y}
          }
          RaceRepVids {
            Link
            Paragraph
          }
          CarouselTitle
          CarouselContent {
            Link
            Paragraph
            Cover {
                ${y}
            }
          }
          AboutZane {
            Title
            Subtitle
            Paragraph
            Media {
                ${y}
            }
            Buttons {
              Text
              Link
              Icon {
                ${y}
              }
            }
          }
          Highlights {
            Title
            Paragraph
          }
          AboutFRM {
            Title
            Subtitle
            Paragraph
            Buttons {
              Text
              Link
              Icon {
                ${y}
              }
            }
            Logo {
                ${y}
            }
            Media {
                ${y}
            }
          }
  
          Sponsors{
            ${y}
          }
  
            FRMChamps{
                ${y}
            }
  
          AboutFRMPInfo
  
          
          ${z}
          
        }
      }
    }
  }`,Vy=async t=>{const e=t.params.lang==""?"en":"es-419";return await Q(Hy,e)},ks=q(f(Vy,"s_s1m2ueqRceg")),Wy=()=>{const t=ks();return i(F,{get data(){return t.value.layoutData},showHeader:!1,children:[i(et,{get SEOdata(){return t.value.pageData.data.pageZaneSpon.data.attributes.SEO},[s]:{SEOdata:u(e=>e.value.pageData.data.pageZaneSpon.data.attributes.SEO,[t],'p0.value["pageData"]["data"]["pageZaneSpon"]["data"]["attributes"]["SEO"]')}},3,"zi_0"),i(Gy,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"zi_1")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"zi_2")},Uy=b(f(Wy,"s_uWXfycW000o")),Yy=({resolveValue:t})=>{const a=t(ks).pageData.data.pageZaneSpon.data.attributes.SEO;return H(a)},Jy=Object.freeze(Object.defineProperty({__proto__:null,default:Uy,head:Yy,usePageData:ks},Symbol.toStringTag,{value:"Module"})),lo=(t,e)=>`
  query QueryLocalPage {
    locations(
      filters: { Slug: { eq: "${e}${t==="en"?"":"-es"}" } }
      locale: "${t}"
    ) {
      data {
        attributes {
            office {
                data {
                  attributes {
                    Address
                    Schema
                    Phone{
                      Link
                      Text
                    }
                  }
                }
              }
          Name
          ZipCode
          Description
          Slug
          
          posts(sort: "Date:desc", pagination: { limit: 100 }){
            data{
              attributes{
                Title
                Date
                Cover{
                  ${y}
                }
                Description
                VideoLink
                Gallery{
                  ${y}
                }
                Slug
              }
            }
          }
          
          SEO {
            MetaTitle
            MetaDescription
            preventIndexing
            Keywords
          }
        }
      }
    }
    sectionProsRta(locale:"${t}") {
    data {
      attributes {
        Pros {
          Icon {
            ${y}
          }
          Title
          Text
          Caption
        }
      }
    }
  }

  pageHome(locale:"${t}"){
    data{
      attributes{

        ProsPar{
          Title
          Paragraph
        }

        ProsPicture{
          ${y}
        }
      }
    }
  }

    lpPtGroup(locale:"${t}"){
        data{
          attributes{
            PricingTables{
              Logo{
                ${y}
              }
              Title
              Subtitle
              Price
              Pricetime
              Description
              Features{
                Text
              }
              Button{
                Text
                Link
              }
            }
          }
        }
      } 
  }  
    `,Zy=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang,a=t.params.slug;return await qa(lo(ka(e),a),e)},Ls=q(f(Zy,"s_6eBD86DvEZM")),Ky=async t=>(t.params.lang==""?"en":"es-419").toString(),no=q(f(Ky,"s_06oruSNHf7c")),Xy=()=>{var o;V();const t=Ls(),e=t.value.pageData.data.locations.data[0].attributes,a=e.posts.data,r=(o=ot().prevUrl)==null?void 0:o.pathname.includes("/es/");return i(F,{get data(){return t.value.layoutData},children:[i(et,{customText:r?`Blog Local en ${e.Name} | RTA Telecommunications`:`${e.Name} Local Blog | RTA Telecommunications`},3,"xj_0"),a.length==0?n("div",null,{class:"h-full w-full flex items-center justify-center"},n("h2",null,{class:"font-bold text-2xl text-primary-blue p-[25px] text-center"},r==!1?"More news about this location coming soon. Stay tuned!":"Próximamente más noticias sobre esta localidad. ¡Mantente al tanto!",1,null),1,"xj_1"):n("div",null,{class:"flex flex-col items-center justify-center"},[i(An,{get post(){return a[0].attributes},isES:r,[s]:{post:m(a[0],"attributes")}},3,"xj_2"),n("div",null,{class:"my-4"},null,3,null),i(On,{get posts(){return e.posts.data},loadSize:3,type:"locations",isLocalBlog:!0,[s]:{posts:m(e.posts,"data"),loadSize:s,type:s,isLocalBlog:s}},3,"xj_3")],1,null)],[s]:{data:u(c=>c.value.layoutData,[t],'p0.value["layoutData"]')}},1,"xj_4")},tv=b(f(Xy,"s_LRpRHkCbXkY")),ev=({resolveValue:t})=>{const e=t(no),r=t(Ls).pageData.data.locations.data[0].attributes.Name,o={MetaTitle:e=="en"?`${r} Local Blog | RTA Telecommunications`:`Blog Local en ${r} | RTA Telecommunications`,MetaDescription:e=="en"?`Explore the most recent and relevant news in ${r}. Stay informed about events, updates, and local news that impact your community.`:`Explora las noticias más recientes y relevantes en ${r}. Mantente informado sobre eventos y noticias locales que impactan tu comunidad.`,Keywords:e=="en"?"Technology news, Tech updates, Digital trends, Innovation insights, RTA, local blog":"Noticias de tecnología, Actualizaciones tecnológicas, Tendencias digitales, Novedades en innovación, RTA, blog local"};return H(o)},av=Object.freeze(Object.defineProperty({__proto__:null,default:tv,head:ev,useLang:no,usePageData:Ls},Symbol.toStringTag,{value:"Module"})),lv=t=>{const e=t.data.Slug.substring(t.data.Slug.length-3,t.data.Slug.length)==="-es";return n("div",null,{class:"flex max-w-[1200px] gap-5 px-8 py-20 text-primary-blue max-[800px]:flex-col"},[n("div",null,{class:"flex flex-col items-center justify-center gap-1 text-center min-[800px]:w-[40%] md:px-2"},[n("h1",null,{class:"md:text-[36px] text-[28px] font-[700] leading-10"},`gigFAST INTERNET ${e?"e":"i"}n ${t.data.Name}`,1,null),n("span",null,{class:"text-[24px]"},[u(a=>a.data.ZipCode,[t],'p0.data["ZipCode"]'),", TX"],3,null),n("span",null,{class:"text-[28px] font-[600]"},e?"Llama ahora":"Call now",1,null),i(K,{type:"action",get link(){return t.data.office.data.attributes.Phone.Link},get text(){return t.data.office.data.attributes.Phone.Text},[s]:{type:s,link:u(a=>a.data.office.data.attributes.Phone.Link,[t],'p0.data["office"]["data"]["attributes"]["Phone"]["Link"]'),text:u(a=>a.data.office.data.attributes.Phone.Text,[t],'p0.data["office"]["data"]["attributes"]["Phone"]["Text"]')}},3,"pw_0"),n("div",null,{class:"w-full h-full mt-4"},n("iframe",null,{src:u(a=>a.data.office.data.attributes.Address,[t],'p0.data["office"]["data"]["attributes"]["Address"]'),class:"h-full w-full rounded-2xl",loading:"lazy"},null,3,null),3,null)],1,null),n("div",null,{class:"text-justify text-[16px] max-[800px]:text-[13px] min-[800px]:w-[60%]"},i(j,{get text(){return t.data.Description},[s]:{text:u(a=>a.data.Description,[t],'p0.data["Description"]')}},3,"pw_1"),1,null)],1,"pw_2")},nv=b(f(lv,"s_8eJAul3VU0U")),sv=t=>{const e=t.data.locations.data[0].attributes.Slug,a=e.substring(e.length-3,e.length)==="-es",l=t.data.lpPtGroup.data.attributes.PricingTables;return n("div",null,{class:"w-full"},[n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"flex min-h-[200px]  w-full items-center justify-center bg-gradient-to-br from-primary-light-blue to-[#23477f] p-8"},n("div",null,{class:"flex w-full max-w-[1200px] flex-col items-center justify-center"},[n("span",null,{class:"text-center text-[38px] font-[600] leading-10 text-white max-[800px]:text-[28px]"},a?"Encuentra ofertas disponibles en tu área":"Find available offers in your area",1,null),n("div",null,{class:"mt-8 flex w-full items-center justify-center gap-8 max-[1200px]:flex-col"},n("div",null,{class:"flex justify-evenly gap-4 max-[1400px]:flex-wrap"},l.map((r,o)=>i(es,{get btnText(){return r.Button.Text},get btnLink(){return r.Button.Link},get description(){return r.Description},get logo(){return r.Logo.data.attributes},get features(){return r.Features},price:r.Price.toString(),get priceTime(){return r.Pricetime},get title(){return r.Title},isFullLogo:!0,[s]:{btnText:m(r.Button,"Text"),btnLink:m(r.Button,"Link"),description:m(r,"Description"),logo:m(r.Logo.data,"attributes"),features:m(r,"Features"),priceTime:m(r,"Pricetime"),title:m(r,"Title"),isFullLogo:s}},3,o)),1,null),1,null)],1,null),1,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-50"},null,3,null),n("div",null,{class:"h-[30px] w-full bg-primary-blue opacity-20"},null,3,null)],1,"88_0")},rv=b(f(sv,"s_JRh1Z7hA4Tg")),iv=t=>n("div",null,{class:"z-20 flex w-full justify-center bg-gradient-to-br from-[#3d76c2] to-[#2e599a] px-10 py-6 text-white"},n("div",null,{class:"flex max-w-[1100px] items-center justify-center gap-8 max-[1000px]:flex-col"},[n("div",null,{class:"flex w-[50%] flex-col text-justify max-[1000px]:w-[100%]"},[n("div",null,{class:"text-[38px] font-bold max-sm:text-[28px]"},u(e=>e.data.prosPar.Title,[t],'p0.data.prosPar["Title"]'),3,null),n("div",null,{class:"text-[18px] max-sm:text-[15px]"},u(e=>e.data.prosPar.Paragraph,[t],'p0.data.prosPar["Paragraph"]'),3,null),n("div",null,{class:"mt-6 flex flex-col gap-4"},t.data.prosData.map((e,a)=>n("div",null,{class:"flex-row "},n("div",null,{class:"flex flex-col"},[n("div",null,{class:"flex flex-row gap-4 items-center"},[n("div",null,{class:" bg-secondary-red h-fit w-fit rounded-full p-2"},i(M,{toWhite:!0,width:20,height:20,get media(){return e.Icon.data.attributes},[s]:{toWhite:s,width:s,height:s,media:m(e.Icon.data,"attributes")}},3,"l8_0"),1,null),n("span",null,{class:"text-[28px] font-bold"},i(j,{get text(){return e.Title},classN:"text-white",[s]:{text:m(e,"Title"),classN:s}},3,"l8_1"),1,null)],1,null),n("span",null,{class:"text-[18px] "},i(j,{get text(){return e.Text},classN:"text-white",[s]:{text:m(e,"Text"),classN:s}},3,"l8_2"),1,null)],1,null),1,a)),1,null)],1,null),i(M,{width:"656",height:"720",get media(){return t.data.prosMap},clasN:"px-8  min-w-[250px]",[s]:{width:s,height:s,media:u(e=>e.data.prosMap,[t],"p0.data.prosMap"),clasN:s}},3,"l8_3")],1,null),1,"l8_4"),so=b(f(iv,"s_F6ekLiR69OY")),ov=t=>{const e=t.data.locations.data[0].attributes.Slug,a=e.substring(e.length-3,e.length)==="-es",l=t.data.sectionProsRta.data.attributes.Pros,r=t.data.pageHome.data.attributes,o=r.ProsPicture.data.attributes,c=t.data.locations.data[0].attributes.posts.data.slice(0,3);return n("div",null,{class:"flex flex-col items-center justify-center"},[i(nv,{get data(){return t.data.locations.data[0].attributes},[s]:{data:u(p=>p.data.locations.data[0].attributes,[t],'p0.data["locations"]["data"][0]["attributes"]')}},3,"LA_0"),i(so,{data:{prosPar:r.ProsPar,prosData:l,prosMap:o}},3,"LA_1"),n("div",null,{class:"flex flex-col items-center justify-center my-5"},[n("h3",null,{class:"text-center text-[38px] font-[600] leading-10 text-primary-blue max-[800px]:text-[28px]"},a?"Explora la esencia de tu comunidad con RTA":"Explore your community's essence with RTA",1,null),n("div",null,{class:"flex flex-wrap w-full items-top justify-center gap-10 my-5"},c.map((p,d)=>n("div",null,{class:"m-4"},i(Wi,{post:p,id:`post-${d.toString()}`},3,d),1,"LA_2")),1,null),n("p",null,{class:"p-4 text-center text-[16px] text-primary-blue max-[800px]:text-[13px]"},a?"Descubre historias locales, eventos y joyas ocultas, todo impulsado por la tecnología y la innovación.":"Discover local stories, events, and hidden gems, all powered by technology and innovation.",1,null),i(K,{link:"local-blog/",text:a?"Ver más posts":"See more posts",[s]:{link:s}},3,"LA_3")],1,null),i(rv,{get data(){return t.data},[s]:{data:u(p=>p.data,[t],"p0.data")}},3,"LA_4")],1,"LA_5")},uv=b(f(ov,"s_xdmchVEPK4Q")),cv=()=>n("div",null,{class:"flex w-full items-center justify-center px-8 py-12 text-center text-primary-dark-blue"},n("div",null,{class:"flex max-w-[1000px] flex-col items-center justify-center"},[n("span",null,{class:"text-[50px] font-[300]"},"Oops!",3,null),n("span",null,{class:"text-[18px] font-[400]"},"The page you are looking for does not exist.",3,null),n("h1",null,{class:"text-[150px] font-[700] max-[400px]:text-[100px]"},"404",3,null),n("span",null,{class:"text-[30px] font-[500] text-secondary-red"},"Something went wrong.",3,null)],3,null),3,"7k_0"),ro=b(f(cv,"s_6KpdMMBpLyc")),dv=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang,a=t.params.slug;return await qa(lo(ka(e),a),e)},Cs=q(f(dv,"s_1P6SxAujDI0")),pv=()=>{V();const t=Cs(),a=t.value.pageData.data.locations.data.length>0?i(uv,{get data(){return t.value.pageData.data},[s]:{data:u(l=>l.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"jm_1"):i(ro,null,3,"jm_0");return i(F,{get data(){return t.value.layoutData},showHeader:!1,children:a,[s]:{data:u(l=>l.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"jm_2")},gv=b(f(pv,"s_yFB0AuNay2A")),fv=({resolveValue:t})=>{const e=t(Cs);if(e.pageData.data.locations.data.length==0)return H({MetaTitle:"Not Found",MetaDescription:"Error 404, location not found"});const a=e.pageData.data.locations.data[0].attributes.SEO;return a.schema=e.pageData.data.locations.data[0].attributes.office.data.attributes.Schema,H(a)},xv=Object.freeze(Object.defineProperty({__proto__:null,default:gv,head:fv,usePageData:Cs},Symbol.toStringTag,{value:"Module"})),mv=t=>{V();const e=a=>{V();const l=[],r=Math.floor(a);for(let o=0;o<r;o++)l.push(i(Ol,null,3,"sl_0"));return l};return n("div",null,{class:"flex flex-col w-full items-center justify-around mx-10"},[n("div",null,{class:"flex flex-row gap-3 items-center justify-center"},[n("p",null,{class:"text-secondary-red font-bold text-[16px]"},u(a=>a.name,[t],"p0.name"),3,null),n("div",null,{class:"text-yellow-500 flex flex-row"},[e(t.rating),t.rating%1!=0&&i(og,null,3,"sl_1")],1,null)],1,null),n("p",null,{class:"text-primary-blue font-semibold  text-[14px] text-center"},u(a=>a.testimonial,[t],"p0.testimonial"),3,null)],1,"sl_2")},hv=t=>{const e=b(f(mv,"s_ZS48Bh4qLTw")),a=t.testimonials.map((l,r)=>i(e,{index:r,get name(){return l.Name},get testimonial(){return l.Text},get rating(){return l.Rating},[s]:{name:m(l,"Name"),testimonial:m(l,"Text"),rating:m(l,"Rating")}},3,r));return n("div",null,{class:"relative w-full flex items-center justify-center"},n("div",null,{class:"my-5 sm:w-[80%] md:w-[60%] w-full flex items-center bg-white/80 backdrop-blur-sm rounded-full p-2 overflow-hidden"},i(kt,{slides:a,hasPagination:!1,slidesQty:1,addSpace:!1,get id(){return`header_Carousel_testimonials_${t.isMobile??!1?"mobile":"desk"}`},[s]:{hasPagination:s,slidesQty:s,addSpace:s,id:u(l=>`header_Carousel_testimonials_${l.isMobile??!1?"mobile":"desk"}`,[t],'`header_Carousel_testimonials_${p0.isMobile??false?"mobile":"desk"}`')}},3,"sl_3"),1,null),1,"sl_4")},sr=b(f(hv,"s_Kgfw0buq0zs")),bv=()=>{const[t,e,a,l,r]=tt();e.value=!e.value,e.value&&(t.value=a.data.HeroForm.ActionButton.Link.replace("=pConf=","").replace("streetInput",l.value.value).replace("zipInput",r.value.value))},$v=t=>n("div",null,{class:"flex items-center justify-between gap-1"},[n("div",null,{class:"flex flex-col gap-1 max-[1000px]:gap-2"},[i(M,{clasN:"w-[160px]",width:"1667",get media(){return t.slide.Logo.data.attributes},[s]:{clasN:s,width:s,media:u(e=>e.slide.Logo.data.attributes,[t],'p0.slide["Logo"]["data"]["attributes"]')}},3,"2R_1"),n("div",null,{class:"mx-3 max-[1000px]:hidden"},i(j,{classN:"text-[13px]",get text(){return t.slide.Paragraph},[s]:{classN:s,text:u(e=>e.slide.Paragraph,[t],'p0.slide["Paragraph"]')}},3,"2R_2"),1,null),i(K,{get text(){return t.slide.Buttons[0].Text},get link(){return t.slide.Buttons[0].Link},[s]:{text:u(e=>e.slide.Buttons[0].Text,[t],'p0.slide["Buttons"][0]["Text"]'),link:u(e=>e.slide.Buttons[0].Link,[t],'p0.slide["Buttons"][0]["Link"]')}},3,"2R_3")],1,null),i(zl,{clasN:"rounded-full w-[150px] mr-[30px] max-[1000px]:w-[40%]",get media(){return t.slide.Media.data.attributes},get alt(){return t.slide.Media.data.attributes.alternativeText},get title(){return t.slide.Media.data.attributes.caption},autoplay:!0,loop:!0,muted:!0,[s]:{clasN:s,media:u(e=>e.slide.Media.data.attributes,[t],'p0.slide["Media"]["data"]["attributes"]'),alt:u(e=>e.slide.Media.data.attributes.alternativeText,[t],'p0.slide["Media"]["data"]["attributes"]["alternativeText"]'),title:u(e=>e.slide.Media.data.attributes.caption,[t],'p0.slide["Media"]["data"]["attributes"]["caption"]'),autoplay:s,loop:s,muted:s}},3,"2R_4")],1,"2R_5"),yv=t=>{const[e]=tt();return n("div",{class:`flex h-[230px] items-center  justify-center overflow-hidden bg-white   ${t.isMobile??!1?"w-full max-w-[420px] rounded-full min-[1000px]:hidden":"w-[420px] rounded-br-full rounded-tr-full bg-white/60 backdrop-blur-sm border border-white/60 max-[1000px]:hidden"}`},null,i(kt,{slides:e,hasArrows:!1,slidesQty:1,get id(){return`header_car_${t.isMobile??!1?"mobile":"desk"}`},[s]:{hasArrows:s,slidesQty:s,id:u(a=>`header_car_${a.isMobile??!1?"mobile":"desk"}`,[t],'`header_car_${p0.isMobile??false?"mobile":"desk"}`')}},3,"2R_6"),1,"2R_7")},vv=()=>{const[t,e,a,l]=tt();clearTimeout(l.value),l.value=setTimeout(()=>{t.value.value.length>2&&fetch(`/api/get-streets?q=${encodeURIComponent(t.value.value)}`).then(r=>r.json()).then(r=>{const o=r.data;o.length===0?e.value="notfound":e.value="success",a.value=o})},1e3)},_v=t=>{V();const e=t.data.Testimonials.length<1,a=N(n("input",null,null,null,3,"2R_0")),l=N(n("input",null,null,null,3,null)),r=N(""),o=N(!1),c=N(),p=N([]),d=N("none"),g=N(1e3);Lt(O("s_OSAER37KIRU",[g]));const x=f(bv,"s_fq93imJ971Y",[r,o,t,a,l]),h=b(f($v,"s_bR2jjpv9PC0")),$=t.data.HeroCarSlides.map((D,T)=>i(h,{slide:D},3,T)),_=b(f(yv,"s_mBlTNPrtMiQ",[$])),k=f(vv,"s_r2MqT6I0l2Y",[a,d,p,c]);return i(G,{children:[n("div",null,{class:"relative flex h-[80vh] max-h-[750px] w-full items-center"},[n("div",null,{class:u(D=>`fixed bottom-0 left-0 right-0 bg-white top-${D.value?"0 z-[200]":"[100vh] -z-[200]"}  transition-all duration-1000 ease-in-out`,[o],'`fixed bottom-0 left-0 right-0 bg-white top-${p0.value?"0 z-[200]":"[100vh] -z-[200]"}  transition-all duration-1000 ease-in-out`')},[n("button",null,{"aria-label":"Close popup",class:'absolute right-2  mt-2 mx-0" bg-secondary-red flex items-center justify-center text-white rounded-full h-[30px] focus:outline-none z-[600]',onClick$:x},n("div",null,{class:"px-3 flex flex-row items-center text-xs gap-2"},["Back to site ",i(jn,null,3,"2R_8")],1,null),1,null),n("iframe",null,{src:u(D=>D.value,[r],"p0.value"),title:"load popup",class:"h-full w-full",frameBorder:"0"},null,3,null)],1,null),n("video",{poster:ft(t.data.VideoBGDesktop.data.attributes.caption)},{class:"absolute left-0 top-0 -z-10 h-full w-full object-cover",preload:"auto",autoplay:!0,loop:!0,muted:!0},n("source",{src:ft(t.data[`${g.value<=800?"VideoBGMobile":"VideoBGDesktop"}`].data.attributes.url)+"#t=0.1"},{type:"video/mp4"},null,3,null),1,null),n("div",null,{class:"flex flex-col items-center justify-between h-full w-full md:mb-10"},[n("div",null,{class:"flex h-full w-full items-center justify-between max-[1000px]:flex-col-reverse max-[1000px]:px-4"},[i(_,null,3,"2R_9"),n("div",null,{class:"relative flex w-[420px] flex-col items-center justify-center gap-5 rounded-bl-full rounded-tl-full bg-white/60 backdrop-blur-sm max-[1000px]:mb-8 max-[1000px]:w-full max-[1000px]:max-w-[420px] max-[1000px]:rounded-[30px] max-[1000px]:py-2 min-[1000px]:h-[230px] border border-white/60"},[n("div",{class:`absolute left-10 right-10 top-[90%] z-20 flex max-h-[200px] flex-col gap-3 overflow-y-auto rounded-xl bg-white p-6 text-primary-blue shadow-lg ${d.value==="none"||d.value==="selected"?"hidden":""}`},null,[u(D=>D.value.length===0?"Not found":"",[p],'p0.value.length===0?"Not found":""'),p.value.map((D,T)=>n("div",{onClick$:O("s_OVQX0djWFQ4",[a,D,d,l])},{class:"grid items-center gap-4 hover:cursor-pointer",style:{gridTemplateColumns:"20px 1fr"}},[i(Oi,{class:"w-6 text-secondary-red",[s]:{class:s}},3,"2R_10"),n("span",null,{class:"text-[14px]"},w(D,"address"),1,null)],0,T))],1,null),n("div",null,{class:" text-center md:text-[22px] text-[20px] font-[600] text-primary-blue "},u(D=>D.data.HeroForm.Title,[t],'p0.data["HeroForm"]["Title"]'),3,null),n("div",null,{class:"flex w-full items-center gap-3 px-6  "},[n("input",{ref:a},{class:"w-[100%] rounded-full px-3 py-2 placeholder-primary-blue",placeholder:"Address Search",type:"text",onKeyUp$:k},null,3,null),n("input",{ref:l},{class:"w-[60%] rounded-full px-3 py-2 placeholder-primary-blue",placeholder:"Zip Code",type:"text"},null,3,null)],1,null),i(K,{get text(){return t.data.HeroForm.ActionButton.Text},onClick:x,[s]:{text:u(D=>D.data.HeroForm.ActionButton.Text,[t],'p0.data["HeroForm"]["ActionButton"]["Text"]'),onClick:s}},3,"2R_11")],1,null)],1,null),e?null:n("div",null,{class:"block max-[1000px]:hidden w-full"},i(sr,{get testimonials(){return t.data.Testimonials},[s]:{testimonials:u(D=>D.data.Testimonials,[t],'p0.data["Testimonials"]')}},3,"2R_12"),1,"2R_13")],1,null)],1,null),n("div",null,{class:"flex flex-col  justify-evenly items-center bg-gradient-to-r from-[#3d76c1] to-[#3568ae] px-4 pt-4"},[i(_,{isMobile:!0,[s]:{isMobile:s}},3,"2R_14"),e?null:n("div",null,{class:"max-[1000px]:block hidden w-full"},i(sr,{get testimonials(){return t.data.Testimonials},isMobile:!0,[s]:{testimonials:u(D=>D.data.Testimonials,[t],'p0.data["Testimonials"]'),isMobile:s}},3,"2R_15"),1,"2R_16")],1,null)]},1,"2R_17")},wv=b(f(_v,"s_S18xoZmdQUw")),Sv=t=>{const e=t.data.Logo.data.attributes,a=t.data.Media.data.attributes;return n("div",null,{class:"mb-4 flex flex-row-reverse max-w-[1200px] items-center justify-center gap-4 self-center px-8 max-[800px]:flex-col-reverse"},[n("div",null,{class:"flex w-[400px] items-center justify-center self-center p-4 min-[800px]:w-[40%]"},i(M,{media:a,width:400,height:500,[s]:{width:s,height:s}},3,"a2_0"),1,null),n("div",null,{class:"flex flex-col items-center justify-center gap-4 min-[800px]:w-[60%]"},[n("div",null,{class:"max-w-[470px]"},i(M,{media:e,width:1230,height:230,[s]:{width:s,height:s}},3,"a2_1"),1,null),n("div",null,{class:"flex items-start gap-2"},[n("div",null,{class:"text-center text-[38px] font-bold text-[#2E5899] max-sm:text-[28px]"},u(l=>l.data.Title,[t],'p0.data["Title"]'),3,null),n("div",null,{class:"text-center text-[28px] font-bold text-secondary-red max-sm:text-[18px]"},u(l=>l.data.Subtitle,[t],'p0.data["Subtitle"]'),3,null)],3,null),n("div",null,{class:"text-primary-blue"},[i(j,{classN:"text-justify max-sm:text-[15px] text-[18px] text-[#2E5899]",get text(){return t.data.Paragraph},[s]:{classN:s,text:u(l=>l.data.Paragraph,[t],'p0.data["Paragraph"]')}},3,"a2_2"),t.parGFIPlans.map((l,r)=>n("div",null,{class:"text-[22px]"},i(xa,{get title(){return l.Title},classContainer:"bg-white shadow-xl",children:i(j,{classN:"text-[16px] text-justify",get text(){return l.Paragraph},[s]:{classN:s,text:m(l,"Paragraph")}},3,"a2_3"),[s]:{title:m(l,"Title"),classContainer:s}},1,"a2_4"),1,r))],1,null),n("div",null,{class:"flex gap-4"},t.data.Buttons.map((l,r)=>i(K,{get text(){return l.Text},get link(){return l.Link},[s]:{text:m(l,"Text"),link:m(l,"Link")}},3,r)),1,null)],1,null)],1,"a2_5")},Tv=b(f(Sv,"s_M9NFBwXMc48")),Dv=t=>n("div",null,{class:"flex items-center justify-evenly gap-4 px-8 py-6 max-[1200px]:flex-col"},t.data.map((e,a)=>n("div",null,{class:" flex max-w-[400px] flex-col items-center gap-2 text-center text-primary-blue"},[i(Ue,{get media(){return e.Media.data.attributes},width:"w-[360px]",color:"bg-primary-blue",[s]:{media:m(e.Media.data,"attributes"),width:s,color:s}},3,"pO_0"),n("h2",null,{class:"text-[24px] font-[700]"},w(e,"Title"),1,null),n("p",null,{class:"text-[17px] font-[400]"},w(e,"Paragraph"),1,null),i(K,{get text(){return e.Buttons[0].Text},get link(){return e.Buttons[0].Link},[s]:{text:m(e.Buttons[0],"Text"),link:m(e.Buttons[0],"Link")}},3,"pO_1")],1,a)),1,"pO_2"),Pv=b(f(Dv,"s_PyTSx8biYlE")),kv=t=>{const e=t.data.pageHome.data.attributes,a=t.data.sectionProsRta.data.attributes.Pros,l=e.ProsPicture.data.attributes;return n("div",null,{class:"relative ",onClick$:O("s_TkQ204PTgK8")},[n("div",null,{class:"absolute bottom-0 left-0 right-0 top-[100vh] -z-10 bg-white"},null,3,null),i(wv,{data:e},3,"Ee_0"),i(so,{data:{prosPar:e.ProsPar,prosData:a,prosMap:l}},3,"Ee_1"),n("div",null,{class:"flex w-full justify-center bg-[#ebf4fc]"},i(Tv,{data:e.ParGFServices[0],get parGFIPlans(){return e.ParGFIPlans},[s]:{parGFIPlans:m(e,"ParGFIPlans")}},3,"Ee_2"),1,null),i(Xe,{data:e.ParGFServices.slice(1,e.ParGFServices.length)},3,"Ee_3"),n("div",null,{class:"bg-[#ebf4fc]"},i(Pv,{get data(){return e.SugsPages},[s]:{data:m(e,"SugsPages")}},3,"Ee_4"),1,null)],1,"Ee_5")},Lv=b(f(kv,"s_G08oK4nfxwg")),Cv=t=>n("div",null,{class:"flex  w-full flex-col items-center justify-center px-8 text-primary-blue"},[n("div",null,{class:"flex max-w-[1400px] items-center justify-evenly gap-4 py-16 max-[800px]:flex-col"},[n("h1",null,{class:"w-[40%] text-center text-[42px] font-[600]  max-sm:text-[28px] leading-10 max-[800px]:w-full"},u(e=>e.data.Title,[t],'p0.data["Title"]'),3,null),i(M,{width:"833",height:"539",clasN:" rounded-2xl shadow-xl w-[40%] max-[800px]:w-full",get media(){return t.data.Cover.data.attributes},[s]:{width:s,height:s,clasN:s,media:u(e=>e.data.Cover.data.attributes,[t],'p0.data["Cover"]["data"]["attributes"]')}},3,"cD_0")],1,null),n("div",null,{class:"mb-8 max-w-[1400px]"},i(j,{get text(){return t.data.Description},classN:"text-justify",[s]:{text:u(e=>e.data.Description,[t],'p0.data["Description"]'),classN:s}},3,"cD_1"),1,null)],1,"cD_2"),Mv=b(f(Cv,"s_QI52uAygONM")),jv=(t,e)=>`query QueryPostPage {
        posts (filters: {Slug: {eq: "${t}${e==="es-419"?"-es":""}"}} pagination:{limit:1} locale:"${e}") {
          data {
            attributes {
              Title
              Date
              Description
              Slug
              Cover {
                ${y}
              }
              ${z} 
            }
          }
        }
      }`,Iv=async t=>{const e=t.params.lang=="es"?"es-419":t.params.lang==""?"en":t.params.lang;let a={};if(e=="en"||e=="es-419")return a=await Q(Xi,e),{...a,type:"home"};const l=e.includes("es/")?"es-419":"en",r=e.includes("es/")?e.split("es/")[1]:e;return a=await qa(jv(r,l),l),{...a,type:a.pageData.data.posts.data.length>0?"post":"404"}},Ms=q(f(Iv,"s_Up0e7VSBoHc")),Ev=()=>{V();const t=Ms();return i(F,{get data(){return t.value.layoutData},showHeader:!1,children:[t.value.type=="home"&&n("h1",null,{class:"absolute opacity-0"},"Rural Telecommunications of America Inc.",3,"2d_0"),t.value.type=="home"?i(Lv,{get data(){return t.value.pageData.data},[s]:{data:u(e=>e.value.pageData.data,[t],'p0.value["pageData"]["data"]')}},3,"2d_1"):t.value.type=="post"?i(Mv,{get data(){return t.value.pageData.data.posts.data[0].attributes},[s]:{data:u(e=>e.value.pageData.data.posts.data[0].attributes,[t],'p0.value["pageData"]["data"]["posts"]["data"][0]["attributes"]')}},3,"2d_2"):i(ro,null,3,"2d_3")],[s]:{data:u(e=>e.value.layoutData,[t],'p0.value["layoutData"]'),showHeader:s}},1,"2d_4")},Nv=b(f(Ev,"s_0WMiPe1m3D0")),Bv=({resolveValue:t})=>{const e=t(Ms),a=e.type;let l;return a=="home"?l=e.pageData.data.pageHome.data.attributes.SEO:a=="post"?(l=e.pageData.data.posts.data[0].attributes.SEO,l||(l={MetaTitle:e.pageData.data.posts.data[0].attributes.Title,MetaDescription:e.pageData.data.posts.data[0].attributes.Description,preventIndexing:!0,Keywords:e.pageData.data.posts.data[0].attributes.Title})):l={MetaTitle:"Not found"},H(l)},Av=Object.freeze(Object.defineProperty({__proto__:null,default:Nv,head:Bv,usePageData:Ms},Symbol.toStringTag,{value:"Module"})),Ov=[jd],R=()=>Tp,Rv=[["forms/",[R,()=>Cp],"/forms/",["q-CJRdmSTV.js","q-CriNHzM9.js"]],["[...lang]/api/get-streets/",[R,()=>Ip],"/[...lang]/api/get-streets/",["q-CJRdmSTV.js"]],["[...lang]/api/graphql/",[R,()=>Np],"/[...lang]/api/graphql/",["q-CJRdmSTV.js"]],["[...lang]/api/sendmail/",[R,()=>Ap],"/[...lang]/api/sendmail/",["q-CJRdmSTV.js","q-YWUYLNN-.js"]],["[...lang]/api/survey-pre-exit/",[R,()=>Rp],"/[...lang]/api/survey-pre-exit/",["q-CJRdmSTV.js"]],["[...lang]/appreciation-giveaway/",[R,()=>hf],"/[...lang]/appreciation-giveaway/",["q-CJRdmSTV.js","q-B8KIXIOI.js"]],["[...lang]/appreciation-lead/",[R,()=>Tf],"/[...lang]/appreciation-lead/",["q-CJRdmSTV.js","q-DbSl7olY.js"]],["[...lang]/awards/",[R,()=>Ef],"/[...lang]/awards/",["q-CJRdmSTV.js","q-CKfeWWlb.js"]],["[...lang]/blog/",[R,()=>Uf],"/[...lang]/blog/",["q-CJRdmSTV.js","q-BE2A4Cya.js"]],["[...lang]/board-members/",[R,()=>a0],"/[...lang]/board-members/",["q-CJRdmSTV.js","q-Y0K3Wa3r.js"]],["[...lang]/broadbandlabels/",[R,()=>w0],"/[...lang]/broadbandlabels/",["q-CJRdmSTV.js","q-6dErWRFr.js"]],["[...lang]/business/",[R,()=>E0],"/[...lang]/business/",["q-CJRdmSTV.js","q-B4C2b3uM.js"]],["[...lang]/careers/",[R,()=>ex],"/[...lang]/careers/",["q-CJRdmSTV.js","q-RFSvpL2z.js"]],["[...lang]/client-services-agreement-general-terms-and-conditions/",[R,()=>ux],"/[...lang]/client-services-agreement-general-terms-and-conditions/",["q-CJRdmSTV.js","q-C6umpMjb.js"]],["[...lang]/contact-us/",[R,()=>hx],"/[...lang]/contact-us/",["q-CJRdmSTV.js","q-Do8fQT8Q.js"]],["[...lang]/cookies/",[R,()=>Tx],"/[...lang]/cookies/",["q-CJRdmSTV.js","q-DFiTmHKj.js"]],["[...lang]/deals/",[R,()=>qx],"/[...lang]/deals/",["q-CJRdmSTV.js","q-StmpnJ9q.js"]],["[...lang]/faq/",[R,()=>Ux],"/[...lang]/faq/",["q-CJRdmSTV.js","q-B_JXWZIn.js"]],["[...lang]/free-install/",[R,()=>sm],"/[...lang]/free-install/",["q-CJRdmSTV.js","q-v7ZHpyBh.js"]],["[...lang]/gfsn/",[R,()=>_m],"/[...lang]/gfsn/",["q-CJRdmSTV.js","q-CG8gg92k.js"]],["[...lang]/gigfast-cloud/",[R,()=>Cm],"/[...lang]/gigfast-cloud/",["q-CJRdmSTV.js","q-DDcJje3G.js"]],["[...lang]/gigfast-internet-support/",[R,()=>Hm],"/[...lang]/gigfast-internet-support/",["q-CJRdmSTV.js","q-F80uC14M.js"]],["[...lang]/gigfast-internet/",[R,()=>th],"/[...lang]/gigfast-internet/",["q-CJRdmSTV.js","q-CHAQdajM.js"]],["[...lang]/gigfast-iot/",[R,()=>oh],"/[...lang]/gigfast-iot/",["q-CJRdmSTV.js","q-BUhdyDxr.js"]],["[...lang]/gigfast-tv-privacy-policy/",[R,()=>mh],"/[...lang]/gigfast-tv-privacy-policy/",["q-CJRdmSTV.js","q-pgi3bG5B.js"]],["[...lang]/gigfast-tv-support/",[R,()=>Lh],"/[...lang]/gigfast-tv-support/",["q-CJRdmSTV.js","q-de-8RAj0.js"]],["[...lang]/gigfast-tv/",[R,()=>Uh],"/[...lang]/gigfast-tv/",["q-CJRdmSTV.js","q-CvX4fcYA.js"]],["[...lang]/gigfast-voice-support/",[R,()=>ab],"/[...lang]/gigfast-voice-support/",["q-CJRdmSTV.js","q-G5VKOewO.js"]],["[...lang]/gigfast-voice/",[R,()=>fb],"/[...lang]/gigfast-voice/",["q-CJRdmSTV.js","q-BAYvSG4r.js"]],["[...lang]/giving-back/",[R,()=>_b],"/[...lang]/giving-back/",["q-CJRdmSTV.js","q-g2gdDIPV.js"]],["[...lang]/goldsmith-tt/",[R,()=>Cb],"/[...lang]/goldsmith-tt/",["q-CJRdmSTV.js","q-Do4YguFW.js"]],["[...lang]/internet-transparency-statement/",[R,()=>Ob],"/[...lang]/internet-transparency-statement/",["q-CJRdmSTV.js","q-g7ieoZSZ.js"]],["[...lang]/leadership-team/",[R,()=>Gb],"/[...lang]/leadership-team/",["q-CJRdmSTV.js","q-Cpq_Trih.js"]],["[...lang]/legal/",[R,()=>Kb],"/[...lang]/legal/",["q-CJRdmSTV.js","q-DQOGYgdj.js"]],["[...lang]/local-weather-stations/",[R,()=>r$],"/[...lang]/local-weather-stations/",["q-CJRdmSTV.js","q-DUWcp3ga.js"]],["[...lang]/news/",[R,()=>f$],"/[...lang]/news/",["q-CJRdmSTV.js","q-jUWysc8M.js"]],["[...lang]/our-story/",[R,()=>_$],"/[...lang]/our-story/",["q-CJRdmSTV.js","q-DMHagVQT.js"]],["[...lang]/portability/",[R,()=>j$],"/[...lang]/portability/",["q-CJRdmSTV.js","q-CwLx2jdt.js"]],["[...lang]/post_slug/",[R,()=>R$],"/[...lang]/post_slug/",["q-CJRdmSTV.js","q-HnyXixWB.js"]],["[...lang]/privacy-policy/",[R,()=>W$],"/[...lang]/privacy-policy/",["q-CJRdmSTV.js","q-Ds9Lr0O3.js"]],["[...lang]/pumptopper/",[R,()=>e1],"/[...lang]/pumptopper/",["q-CJRdmSTV.js","q-DrUxe-Ac.js"]],["[...lang]/referral-program/",[R,()=>d1],"/[...lang]/referral-program/",["q-CJRdmSTV.js","q-Db7KenlW.js"]],["[...lang]/residential/",[R,()=>$1],"/[...lang]/residential/",["q-CJRdmSTV.js","q-2sRoYdUi.js"]],["[...lang]/services-broadbandlabels/",[R,()=>k1],"/[...lang]/services-broadbandlabels/",["q-CJRdmSTV.js","q-DPEi177B.js"]],["[...lang]/sheridan-bbq/",[R,()=>q1],"/[...lang]/sheridan-bbq/",["q-CJRdmSTV.js","q-VokhDLn_.js"]],["[...lang]/support/",[R,()=>Y1],"/[...lang]/support/",["q-CJRdmSTV.js","q-Dz7C3mBw.js"]],["[...lang]/testimonials/",[R,()=>ny],"/[...lang]/testimonials/",["q-CJRdmSTV.js","q-NxD84z7O.js"]],["[...lang]/texas/",[R,()=>gy],"/[...lang]/texas/",["q-CJRdmSTV.js","q-Bt-SIpJA.js"]],["[...lang]/wholesale/",[R,()=>vy],"/[...lang]/wholesale/",["q-CJRdmSTV.js","q-B5gRLaPW.js"]],["[...lang]/winners-circle/",[R,()=>Cy],"/[...lang]/winners-circle/",["q-CJRdmSTV.js","q-DFRDhj43.js"]],["[...lang]/zane-smith-sponsorship/",[R,()=>Jy],"/[...lang]/zane-smith-sponsorship/",["q-CJRdmSTV.js","q-BXUhxFCW.js"]],["[...lang]/texas/[slug]/local-blog/",[R,()=>av],"/[...lang]/texas/[slug]/local-blog/",["q-CJRdmSTV.js","q-C-f2uueX.js"]],["[...lang]/texas/[slug]/",[R,()=>xv],"/[...lang]/texas/[slug]/",["q-CJRdmSTV.js","q-CtsFkoEl.js"]],["[...lang]",[R,()=>Av],"/[...lang]",["q-CJRdmSTV.js","q-DPzlBf97.js"]]],qv=[],Fv=!0,io="/",zv=!0,n_={routes:Rv,serverPlugins:Ov,menus:qv,trailingSlash:Fv,basePathname:io,cacheModules:zv};export{s as A,Ov as B,Rv as C,qv as D,Fv as E,G as F,io as G,zv as H,e_ as Q,Xv as R,dt as S,nu as _,Jv as a,Uv as b,Dc as c,b as d,ot as e,i as f,n as g,u as h,f as i,Yv as j,X as k,w as l,Vt as m,Cn as n,Ce as o,dn as p,n_ as q,tt as r,Wv as s,_l as t,t_ as u,Kv as v,l_ as w,Zv as x,Xs as y,a_ as z};
